import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { BaseComponent } from 'src/app/common/base.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SearchAccountOutput } from 'src/app/Dtos/searchAccountOutput';
import { PaginatorAndSorterInfo } from 'src/app/common/PaginatorAndSorterInfo';
import { SearchAccountInput } from 'src/app/Dtos/searchAccountInput';
import { SearchAccountService } from 'src/app/service/searchAccountService';
import { UserIdInput } from 'src/app/Dtos/userIdInput';
import { Router } from '@angular/router';
import { NgbModalConfig, NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { UserInput } from '../../Dtos/userInput';
import { UserOutput } from '../../Dtos/userOutput';

declare var jquery:any;
declare var $ :any;

@Component({
  selector: 'list-search-account',
  templateUrl: './list-search-account.component.html',
  providers: [NgbModalConfig, NgbModal],
  styles: [`
  #message-err {
    font-weight: bold;
    color: #ff0000;
    width: 100%;
    padding-top: 5px;
  }
  `]
  
})
export class ListSearchAccountComponent extends BaseComponent {
  
  public messageErr: string = null;
  public userId: string = '';
  public userIdInput: UserIdInput;
  public userInput: UserInput;
  public userOutput: UserOutput;
  public currentUser: UserOutput;
  public submitted: boolean = false;
  public isChangePassword: boolean = false;
  public isInsertNew: boolean = true;
  public checkboxFlg: boolean = false;
  public checkExistUser: boolean = false;

  @Input()
  public searchAccountOutput: SearchAccountOutput[];

  // Paging ----->
  @Input()
  public searchAccountInput: SearchAccountInput;

  @Output()
  public searchAccountEvent: EventEmitter<SearchAccountInput> = new EventEmitter<SearchAccountInput>();

  @Output()
  public deleteAccountEvent: EventEmitter<UserIdInput> = new EventEmitter<UserIdInput>();

  @Output()
  public insertAccountEvent: EventEmitter<UserInput> = new EventEmitter<UserInput>();

  @Output()
  public updateAccountEvent: EventEmitter<UserInput> = new EventEmitter<UserInput>();

  @Input()
  public totalCount: number;

  @Input()
  public isLoading: boolean;

  @Input()
  public paginatorAndSorterInfo: PaginatorAndSorterInfo;
  // <----- Paging

  public form: FormGroup;
  public formInsertOrUpdate: FormGroup;


  constructor(private formBuilder: FormBuilder, public router: Router, private modalService: NgbModal,
    private searchAccountService: SearchAccountService, private config: NgbModalConfig
    ) {
    super();
    config.backdrop = 'static';
    config.keyboard = false;
  }

  ngOnInit() {
   
    super.ngOnInit();
    this.formInsertOrUpdate = this.formBuilder.group({
      userId: ['', [Validators.required, Validators.minLength(1),Validators.maxLength(100)]],
      firstName: ['', [Validators.required, Validators.minLength(1),Validators.maxLength(100)]],
      lastName: ['', [Validators.required,Validators.minLength(1), Validators.maxLength(100)]],
      password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(100)]],
      confirmPassword: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(100)]]
    });
  }
  public initVariables(): void {
    super.initVariables();
    this.userIdInput = {} as UserIdInput;
    this.userInput = {} as UserInput;
    this.userOutput = {} as UserOutput;
    this.currentUser = {} as UserOutput;
  }
  public checkValidate(): boolean {
    
      this.messageErr = "";
      return true;
  }
  public initForm(): void {
    this.form = this.formBuilder.group({
      name: [this.searchAccountInput.name],
      maxResultCount: [this.searchAccountInput.maxResultCount]
    });
  }

  public searchPaging(paginatorAndSorterInfo: PaginatorAndSorterInfo): void {
    this.messageErr = "";
    this.paginatorAndSorterInfo.skipCount = paginatorAndSorterInfo.skipCount;
    this.paginatorAndSorterInfo.sortColumn = paginatorAndSorterInfo.sortColumn;
    this.paginatorAndSorterInfo.sortMode = paginatorAndSorterInfo.sortMode;

    this.searchAccountInput.skipCount = paginatorAndSorterInfo.skipCount;
    this.searchAccountInput.sorting = `${paginatorAndSorterInfo.sortColumn + ' ' + paginatorAndSorterInfo.sortMode}`;
    this.searchAccountEvent.emit(this.searchAccountInput);
  }
  public search(): void {
    $("#messageErr h5").hide();
    this.markFormDirty();
    
    if(!this.checkValidate()) {
      return;
    };

    if (!this.form.valid) {
      return;
    }
    
    this.setValueSearch();
    this.searchAccountEvent.emit(this.searchAccountInput);

  }
  private setValueSearch(): void {
    this.searchAccountInput.name = this.form.value.name;

    this.searchAccountInput.maxResultCount = this.form.value.maxResultCount;
    this.searchAccountInput.skipCount = 0;
  }
  
  open(content, userId:any) {    
    this.modalService.open(content, { centered: true });
    this.messageErr = '';
    this.userId = userId;
  }  

  openFormInsert(content) {
    $("#messageErr h5").hide();
    this.isInsertNew = true;
    this.userOutput = {} as UserOutput;
    this.modalService.open(content, { centered: true });
    this.messageErr = '';
    this.checkboxFlg = false;
    this.isChangePassword = true;
    this.submitted = false;
    this.formInsertOrUpdate = this.formBuilder.group({
      userId: ['', [Validators.required,Validators.minLength(1), Validators.maxLength(100)]],
      firstName: ['', [Validators.required, Validators.minLength(1),Validators.maxLength(100)]],
      lastName: ['', [Validators.required, Validators.minLength(1),Validators.maxLength(100)]],
      password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(100)]],
      confirmPassword: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(100)]]
    });
    $("#userId").focus();
    window.scrollTo(0,0);
  }
  clkCheckbox() {
    this.messageErr = '';
    if ( this.isChangePassword) {

      this.formInsertOrUpdate = this.formBuilder.group({
        userId: [this.formInsertOrUpdate.value.userId, [Validators.required,Validators.minLength(1), Validators.maxLength(100)]],
        firstName: [this.formInsertOrUpdate.value.firstName, [Validators.required, Validators.minLength(1),Validators.maxLength(100)]],
        lastName: [this.formInsertOrUpdate.value.lastName, [Validators.required,Validators.minLength(1), Validators.maxLength(100)]],
        password: [this.userOutput.password, [Validators.required, Validators.minLength(6), Validators.maxLength(100)]],
        confirmPassword: [this.userOutput.password, [Validators.required, Validators.minLength(6), Validators.maxLength(100)]]
      });
    } else {
      
      this.formInsertOrUpdate = this.formBuilder.group({
        userId: [this.formInsertOrUpdate.value.userId, [Validators.required,Validators.minLength(1), Validators.maxLength(100)]],
        firstName: [this.formInsertOrUpdate.value.firstName, [Validators.required, Validators.minLength(1),Validators.maxLength(100)]],
        lastName: [this.formInsertOrUpdate.value.lastName, [Validators.required, Validators.minLength(1),Validators.maxLength(100)]],
        password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(100)]],
        confirmPassword: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(100)]]
      });

    }
    

  }
  async openFormUpdate(content, userId:any) {
    $("#messageErr h5").hide();
    this.isInsertNew = false;
    this.modalService.open(content, { centered: true });
    this.messageErr = '';
    this.checkboxFlg = true;
    this.isChangePassword = false;
    this.submitted = false;
    await this.getUser(userId);
    this.formInsertOrUpdate = this.formBuilder.group({
      userId: [this.userOutput.userId, [Validators.required,Validators.minLength(1), Validators.maxLength(100)]],
      firstName: [this.userOutput.firstName, [Validators.required, Validators.minLength(1),Validators.maxLength(100)]],
      lastName: [this.userOutput.lastName, [Validators.required,Validators.minLength(1), Validators.maxLength(100)]],
      password: [this.userOutput.password, [Validators.required, Validators.minLength(6), Validators.maxLength(100)]],
      confirmPassword: [this.userOutput.password, [Validators.required, Validators.minLength(6), Validators.maxLength(100)]]
    });
    $("#firstName").focus();
  }

  // convenience getter for easy access to form fields
  get f() { return this.formInsertOrUpdate.controls; }
  
  async getUser(userId:any) {
    this.userIdInput.userId = userId;
    const data = await this.searchAccountService.getUserDetail(this.userIdInput).toPromise()
    .catch(function(e) {
      console.log('Not conflicted User' + data);
      return null;
    });
    if (data != null) {
      this.userOutput = JSON.parse(JSON.stringify(data));
      return data;
    }
    return null;
  }

  async checkUserInsert(userId:any) {
     var checkError = false;
    this.userIdInput.userId = userId;
    console.log(this.userIdInput );
    const data = await this.searchAccountService.getUserDetail(this.userIdInput).toPromise()
    .catch(function(e) {
      console.log('Not conflicted User' + data);
    });
    if (data != null) {
      this.userOutput = JSON.parse(JSON.stringify(data));
      console.log('true' );
      this.checkExistUser = true;
    }else {
      console.log('false' );
      this.checkExistUser = false;
    }


  }
  
  public checkPassword(password: string, confirmPassword: string): boolean {
    if(password != confirmPassword) {    
      return true;
    }
    return false;
  }
  
  async insertUser() { 
    this.submitted = true;
    // validate form
    if (this.formInsertOrUpdate.invalid) {
      return;
    }
    // check password mapping
    if(this.checkPassword(this.formInsertOrUpdate.value.password, this.formInsertOrUpdate.value.confirmPassword)) {
      this.messageErr = "Password not matched";
      return;
    }
    // check user existed
   await this.checkUserInsert(this.formInsertOrUpdate.value.userId);
    //console.log(this.checkUserInsert(this.formInsertOrUpdate.value.userId));
    console.log(this.checkExistUser);
    if(this.checkExistUser) {
      this.messageErr = "Account Name is existed";
      this.checkboxFlg = false;
      return;
    }
    // set value
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    this.userInput = this.formInsertOrUpdate.value;
    this.userInput.displayName = this.userInput.firstName + ' ' + this.userInput.lastName;
    this.userInput.createdBy = this.currentUser.userId;   
    this.setValueSearch();
    // action insert
    this.insertAccountEvent.emit(this.userInput);
  }

  public updateUser() {
    this.submitted = true;
    // validate form
    if (this.formInsertOrUpdate.invalid) {
      if (this.f.password.errors || this.f.confirmPassword.errors) {
        this.checkboxFlg = true;
        this.isChangePassword = true;
      }
      return;
    }
    // check password mapping
    if(this.checkPassword(this.formInsertOrUpdate.value.password, this.formInsertOrUpdate.value.confirmPassword)) {
      this.messageErr = "Password not matched";
      return;
    }
    // set value
    this.userInput = this.formInsertOrUpdate.value;
    this.userInput.displayName = this.userInput.firstName + ' ' + this.userInput.lastName;
    this.userInput.createdBy = this.userOutput.createdBy;
    this.userInput.updatedBy = this.currentUser.userId;
    this.setValueSearch();
    // action update
    this.updateAccountEvent.emit(this.userInput);
  }  

  public deleteUser(userId:any) {
    // validate user
    this.userIdInput.userId = userId;
    
    // set value
    this.setValueSearch();
    // action delete
    this.deleteAccountEvent.emit(this.userIdInput);    
  }
}
