import { Component, Input } from '@angular/core';
import { SearchAccountInput } from '../Dtos/searchAccountInput';
import { BaseComponent } from '../common/base.component';
import { SearchAccountOutput } from '../Dtos/searchAccountOutput';
import { PaginatorAndSorterInfo } from '../common/PaginatorAndSorterInfo';
import { AppConfig } from '../common/app.config';
import { SortMode } from '../common/SortMode';
import { SearchAccountService } from '../service/searchAccountService';
import { DateFormatPipe } from '../common/dateFormat.pipe';
import { UserInput } from '../Dtos/userInput';
import { UserOutput } from '../Dtos/userOutput';
import { UserIdInput } from 'src/app/Dtos/userIdInput';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ListSearchAccountComponent } from './listAccount/list-search-account.component';
import { CatchErrorService } from "../common/catchErrorService";
declare var jquery:any;
declare var $ :any;

@Component({
  selector: 'app-account-manager',
  templateUrl: './account-manager.component.html'
})
export class AccountManagerComponent extends BaseComponent {
  public messageErr: string = null;
  public messageColor: string = null;
  public passwordErr: string = null;
  public userId: string = '';
  public userIdInput: UserIdInput;
  public userInput: UserInput;
  public userOutput: UserOutput;
  public currentUser: UserOutput;
  public submitted: boolean = false;
  public isChangePassword: boolean = false;
  // paging --->
  public totalCount: number;
  public paginatorAndSorterInfo: PaginatorAndSorterInfo;
  // <--- paging
  public isLoading: boolean;

  public searchAccountInput: SearchAccountInput;
  public searchAccountOutput: SearchAccountOutput[];

  constructor( 
    private searchAccountService: SearchAccountService,
    private modalService: NgbModal,
    private catchErrorService: CatchErrorService,
   
    ) { 
    super();
  }

  ngOnInit() {
    super.ngOnInit();
  }

  public onInit() {
    super.onInit();   
    this.search(this.searchAccountInput);
  }
  public initVariables(): void {
    super.initVariables();
    this.searchAccountInput = {} as SearchAccountInput; 
    this.searchAccountOutput = [] as SearchAccountOutput[];
    this.paginatorAndSorterInfo = {} as PaginatorAndSorterInfo;
    this.isLoading = true;

    this.initSearchInput();
  }

  public initSearchInput(): void {
    this.searchAccountInput.name = "";

    this.paginatorAndSorterInfo = {
      maxResultCount: AppConfig.settings.pageItems,
      skipCount: 0,
      sortColumn: "userID",
      sortMode: SortMode.Asc
    };
    this.searchAccountInput.maxResultCount = this.paginatorAndSorterInfo.maxResultCount;
    this.searchAccountInput.skipCount = this.paginatorAndSorterInfo.skipCount;
    this.searchAccountInput.sorting = `${this.paginatorAndSorterInfo.sortColumn +
      ' ' +
      this.paginatorAndSorterInfo.sortMode}`;
      
  }

  public search(searchResolutionEvent: SearchAccountInput): void {
    
    this.searchAccountInput = searchResolutionEvent;
    this.searchAccountService.search(this.searchAccountInput).subscribe(
      data => {
      this.searchAccountOutput = data.items;
      this.totalCount = data.totalCount;
      this.isLoading = false;

      this.paginatorAndSorterInfo = {
          maxResultCount: this.searchAccountInput.maxResultCount,
          skipCount: this.searchAccountInput.skipCount,
          sortColumn: this.searchAccountInput.sorting.split(' ', 2)[0],
          sortMode: this.searchAccountInput.sorting.split(' ', 2)[1]
        };
      },
        error => {
          this.messageColor = "red";
            this.messageErr = "500 Internal Server Error";
            this.totalCount = 0;
            this.isLoading = false;
        }
      );
      this.isLoading = true;
  }

  public deleteUser(userIdInput: UserIdInput): void {
    $("#messageErr h5").show();
    this.userIdInput = userIdInput;
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));    
    if(this.userIdInput.userId == this.currentUser.userId) {
      this.messageErr = "Cannot Delete This Account.This account is logged in.";
      this.messageColor = "red";
    }else {
      this.searchAccountService.deleteUser(this.userIdInput)
      .subscribe(
        data => {
         if (data != null && JSON.stringify(data) == 'true') {          
            this.messageErr = "Delete Account Success";
            this.messageColor = "green";
          }
          else {
            this.messageErr = "Delete Account Failed";
            this.messageColor = "red";
          }
          this.search(this.searchAccountInput);
        },
        error => {
          this.messageErr = "500 Internal Server Error";
          this.messageColor = "red";
        });
    }
      
    this.modalService.dismissAll();   
  }
  
  public insertUser(userInput: UserInput) {
    $("#messageErr h5").show();
    this.userInput = userInput;
    this.searchAccountService.insertUser(this.userInput)
    .subscribe(
      data => {
        if (data != null && JSON.stringify(data) == 'true') {
          this.messageErr = "Insert Account Success";
          this.messageColor = "green";
        }
        else {
          this.messageErr = "Insert Account Failed";
          this.messageColor = "red";
        }   
        this.searchAccountInput.sorting = "createdDate DESCENDING";  //userID ASCENDING  
        this.search(this.searchAccountInput);
    },
    error => {
      this.messageErr = "500 Internal Server Error";
      this.messageColor = "red";
    }
    ); 
    this.modalService.dismissAll();
  }

  public updateUser(userInput: UserInput) {  
    $("#messageErr h5").show();
    this.userInput = userInput;
    // check edit current user
    this.searchAccountService.updateUser(this.userInput)
    .subscribe(
      data => {
        this.searchAccountInput.sorting = "updatedDate DESCENDING";  //userID ASCENDING  
        this.messageErr = "Update Account Success";
        this.messageColor = "green";
        this.search(this.searchAccountInput);
      },
      error => {
        this.messageErr = "500 Internal Server Error";
        this.messageColor = "red";
      }
    );
    
    this.modalService.dismissAll();
  }  
  
}

