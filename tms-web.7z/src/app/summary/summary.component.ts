import { Component } from '@angular/core';
import { BaseComponent } from '../common/base.component';
import { DateFormatPipe } from '../common/dateFormat.pipe';
import { PaginatorAndSorterInfo } from '../common/PaginatorAndSorterInfo';
import { AppConfig } from '../common/app.config';
import { SortMode } from '../common/SortMode';
import { Data } from '../common/data-storage';
import { SearchSummaryService } from '../service/searchSummaryService';
import { SearchSummaryInput } from '../Dtos/searchSummaryInput';
import { SearchSummaryOutput } from '../Dtos/searchSummaryOutput';
declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html'
})
export class SummaryComponent extends BaseComponent {
  // paging --->
  public totalCount: number;
  public paginatorAndSorterInfo: PaginatorAndSorterInfo;
  // <--- paging
  public isLoading: boolean;

  public searchHomeInput: SearchSummaryInput;
  public searchHomeOutput: SearchSummaryOutput[];
  constructor(
    private searchSummaryService: SearchSummaryService,
    private dateFormat: DateFormatPipe,
    private data: Data
  ) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
  }

  public onInit() {
    super.onInit();
    this.search(this.searchHomeInput);
  }
  public initVariables(): void {
    super.initVariables();
    this.searchHomeInput = {} as SearchSummaryInput;
    this.searchHomeOutput = [] as SearchSummaryOutput[];
    this.paginatorAndSorterInfo = {} as PaginatorAndSorterInfo;
    this.isLoading = true;

    this.initSearchInput();
  }

  public initSearchInput(): void {
    if (this.data.storage !== undefined) {
      this.searchHomeInput.submittedFrom = this.data.storage.submittedFrom;
      this.searchHomeInput.submittedTo = this.data.storage.submittedTo;
      this.searchHomeInput.status = this.data.storage.status;
      // reset
      this.data.storage = undefined;
    } else {
      this.searchHomeInput.submittedFrom = this.dateFormat.transform(this.dateFormat.getFirstDateStruct(), true);
      this.searchHomeInput.submittedTo = this.dateFormat.transform(this.dateFormat.getDefaultDate(), true);
      this.searchHomeInput.status = "1" // Open
    }
    this.paginatorAndSorterInfo = {
      maxResultCount: AppConfig.settings.pageItems,
      skipCount: 0,
      sortColumn: "pic",
      sortMode: SortMode.Asc
    };
    this.searchHomeInput.maxResultCount = this.paginatorAndSorterInfo.maxResultCount;
    this.searchHomeInput.skipCount = this.paginatorAndSorterInfo.skipCount;
    this.searchHomeInput.sorting = `${this.paginatorAndSorterInfo.sortColumn +
      ' ' +
      this.paginatorAndSorterInfo.sortMode}`;

  }

  public search(searchHomeEvent: SearchSummaryInput): void {

    this.searchHomeInput = searchHomeEvent;
    this.isLoading = true;
    this.searchSummaryService.search(this.searchHomeInput).subscribe(data => {
      this.searchHomeOutput = data.items;
      this.totalCount = data.totalCount;
      this.isLoading = false;

      this.paginatorAndSorterInfo = {
        maxResultCount: this.searchHomeInput.maxResultCount,
        skipCount: this.searchHomeInput.skipCount,
        sortColumn: this.searchHomeInput.sorting.split(' ', 2)[0],
        sortMode: this.searchHomeInput.sorting.split(' ', 2)[1]
      };
    });
  }

}
