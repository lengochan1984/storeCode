import { Component, Input, Output, EventEmitter } from '@angular/core';
import { BaseComponent } from 'src/app/common/base.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DateFormatPipe } from 'src/app/common/dateFormat.pipe';
import { AppConfig } from 'src/app/common/app.config';
import { SearchSummaryInput } from 'src/app/Dtos/searchSummaryInput';
@Component({
  selector: 'search-summary',
  templateUrl: './search-summary.component.html',
  styles: [`
  #message-err {
    font-weight: bold;
    color: #ff0000;
    width: 100%;
    padding-top: 5px;
  }
  `]
})
export class SearchSummaryComponent extends BaseComponent {

  @Input()
  public searchHomeInput: SearchSummaryInput;


  @Output()
  public searchHomeEvent: EventEmitter<SearchSummaryInput> = new EventEmitter<SearchSummaryInput>();


  public form: FormGroup;
  public messageErr: string = '';

  constructor(
    private formBuilder: FormBuilder,
    private dateFormat: DateFormatPipe) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();

  }

  public checkValidate(): boolean {
    var dateFrom = this.dateFormat.transform(this.form.value.submittedFrom, false);
    var dateTo = this.dateFormat.transform(this.form.value.submittedTo, true);
    if (dateFrom !== undefined && !this.dateFormat.isValidDate(dateFrom)) {
      this.messageErr = "Invalid dateFrom";
      return false;
    }
    if (dateTo !== undefined && !this.dateFormat.isValidDate(dateTo)) {
      this.messageErr = "Invalid dateTo";
      return false;
    }
    if (dateFrom > dateTo) {
      this.messageErr = "Invalid date range";
      return false;
    }
    this.messageErr = "";
    return true;
  }
  public initForm(): void {
    this.form = this.formBuilder.group({
      status: [this.searchHomeInput.status],
      submittedFrom: [this.dateFormat.transform(this.searchHomeInput.submittedFrom, true)],
      submittedTo: [this.dateFormat.transform(this.searchHomeInput.submittedTo, true)],
      maxResultCount: [AppConfig.settings.pageItems]
    });
  }

  public search(): void {
    this.markFormDirty();
    
    if (!this.checkValidate()) {
      return;
    };

    if (!this.form.valid) {
      return;
    }
    
    this.setValueSearch();
    this.searchHomeEvent.emit(this.searchHomeInput);

  }
  private setValueSearch(): void {
    this.searchHomeInput.status = this.form.value.status;
    this.searchHomeInput.submittedFrom = this.dateFormat.transform(this.form.value.submittedFrom, true);
    this.searchHomeInput.submittedTo = this.dateFormat.transform(this.form.value.submittedTo, true);

    this.searchHomeInput.maxResultCount = this.form.value.maxResultCount;
    this.searchHomeInput.skipCount = 0;
  }
}
