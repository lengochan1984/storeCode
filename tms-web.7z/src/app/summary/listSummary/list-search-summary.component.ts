import { Component, Input, EventEmitter, Output } from '@angular/core';
import { BaseComponent } from 'src/app/common/base.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PaginatorAndSorterInfo } from 'src/app/common/PaginatorAndSorterInfo';
import { Router } from '@angular/router';
import { Data } from 'src/app/common/data-storage';
import { SearchSummaryInput } from 'src/app/Dtos/searchSummaryInput';
import { SearchSummaryOutput } from 'src/app/Dtos/searchSummaryOutput';

@Component({
  selector: 'list-search-summary',
  templateUrl: './list-search-summary.component.html',
})
export class ListSearchSummaryComponent extends BaseComponent {
  @Input()
  public searchHomeOutput: SearchSummaryOutput[];

  // Paging ----->
  @Input()
  public searchHomeInput: SearchSummaryInput;

  @Output()
  public searchHomeEvent: EventEmitter<SearchSummaryInput> = new EventEmitter<SearchSummaryInput>();

  @Input()
  public totalCount: number;

  @Input()
  public isLoading: boolean;

  @Input()
  public paginatorAndSorterInfo: PaginatorAndSorterInfo;
  // <----- Paging

  public form: FormGroup;


  constructor(
    public router: Router,
    private data: Data) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
  }

  public search(paginatorAndSorterInfo: PaginatorAndSorterInfo): void {
    this.paginatorAndSorterInfo.skipCount = paginatorAndSorterInfo.skipCount;
    this.paginatorAndSorterInfo.sortColumn = paginatorAndSorterInfo.sortColumn;
    this.paginatorAndSorterInfo.sortMode = paginatorAndSorterInfo.sortMode;

    this.searchHomeInput.skipCount = paginatorAndSorterInfo.skipCount;
    this.searchHomeInput.sorting = `${paginatorAndSorterInfo.sortColumn + ' ' + paginatorAndSorterInfo.sortMode}`;
    this.searchHomeEvent.emit(this.searchHomeInput);
  }
  public detailSunmary(item: SearchSummaryOutput, type:string): void {

    this.data.storage = {
        "submittedFrom": this.searchHomeInput.submittedFrom,
        "submittedTo": this.searchHomeInput.submittedTo,
        "status": this.searchHomeInput.status,
        "userId": item.userId,
        "type": type
    }
    this.router.navigate(['dashboard/detailSunmary']);
  }


}