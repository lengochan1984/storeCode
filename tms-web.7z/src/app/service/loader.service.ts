import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class LoaderService {
  private subject: Subject<boolean>;

  constructor() {
    this.subject = new Subject();
  }

  public emit(value: any): void {
    this.subject.next(value);
  }

  public loader(): any {
    return this.subject.asObservable();
  }
}
