import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UpsHttpClient } from '../common/UpsHttpClient';
import { PageResult } from '../Dtos/PageResult';
import { SearchResolutionInput } from '../Dtos/searchResolutionInput';
import { SearchResolutionOutput } from '../Dtos/searchResolutionOutput';

@Injectable()
export class SearchResolutionService {
  constructor(private http: UpsHttpClient) {}

  public search(searchResolutionInput: SearchResolutionInput): Observable<PageResult<SearchResolutionOutput>> {
    return this.http.post('Resolution/SearchResolution', JSON.stringify(searchResolutionInput));
  }
}
