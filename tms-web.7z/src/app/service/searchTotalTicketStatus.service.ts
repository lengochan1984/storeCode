import { Injectable } from "@angular/core";
import { UpsHttpClient } from "../common/UpsHttpClient";
import { SearchTotalTicketInput } from "../Dtos/searchTotalTicketInput";
import { Observable } from "rxjs";
import { TotalTicketOutput } from "../Dtos/totalTicketOutput";
import { SearchStatusResponseInput } from "../Dtos/searchStatusReponseInput";
import { PageResult } from "../Dtos/PageResult";
import { SearchStatusResponseOutput } from "../Dtos/searchStatusResponseOutput";

@Injectable()
export class SearchTotalTicketStatusService{
    constructor(
        private http: UpsHttpClient
    ) {}
    public searchTotalTicketStatus(searchTotalTicketInput: SearchTotalTicketInput): Observable<TotalTicketOutput>{
        return this.http.post("Report/SearchReport",JSON.stringify(searchTotalTicketInput));
    }
    public searchStatusResponse(searchStatusResponseInput: SearchStatusResponseInput): Observable<PageResult<SearchStatusResponseOutput>>{
        return this.http.post("Report/SearchTicketsList",JSON.stringify(searchStatusResponseInput));
    }
}