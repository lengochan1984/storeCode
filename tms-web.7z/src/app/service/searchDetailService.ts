import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UpsHttpClient } from '../common/UpsHttpClient';
import { PageResult } from '../Dtos/PageResult';
import { DetailInput } from '../Dtos/detailInput';
import { DetailOutput } from '../Dtos/detailOutput';
@Injectable()
export class SearchDetailService {
  constructor(private http: UpsHttpClient) {}

  public GetTicketsummaryrecorddetail(detailInput: DetailInput): Observable<PageResult<DetailOutput>> {
    return this.http.post('DetailSummary/GetTicketsummaryrecorddetail', JSON.stringify(detailInput));
  }
}
