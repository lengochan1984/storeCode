import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UpsHttpClient } from '../common/UpsHttpClient';
import { PageResult } from '../Dtos/PageResult';
import { SearchAccountInput } from '../Dtos/searchAccountInput';
import { SearchAccountOutput } from '../Dtos/searchAccountOutput';

import { UserIdInput } from '../Dtos/UserIdInput';
import { UserInput } from '../Dtos/userInput';
import { UserOutput } from '../Dtos/userOutput';

@Injectable()
export class SearchAccountService {
  constructor(private http: UpsHttpClient) {}

  public search(searchAccountInput: SearchAccountInput): Observable<PageResult<SearchAccountOutput>> {
    return this.http.post('User/Search', JSON.stringify(searchAccountInput));
  }
  public deleteUser(userIdInput: UserIdInput): Observable<PageResult<SearchAccountOutput>> {
    return this.http.post('User/deleteUser', JSON.stringify(userIdInput));
  }
  public insertUser(userInput: UserInput): Observable<PageResult<SearchAccountOutput>> {
    return this.http.post('User/insertUser', JSON.stringify(userInput));
  }
  public updateUser(userInput: UserInput): Observable<PageResult<SearchAccountOutput>> {
    return this.http.post('User/updateUser', JSON.stringify(userInput));
  }
  public getUserDetail(userIdInput: UserIdInput): Observable<PageResult<UserOutput>> {
    return this.http.post('User/UserDetail', JSON.stringify(userIdInput));
  }
}
