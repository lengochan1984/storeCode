import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UpsHttpClient } from '../common/UpsHttpClient';
import { PageResult } from '../Dtos/PageResult';
import { SearchSummaryInput } from '../Dtos/searchSummaryInput';
import { SearchSummaryOutput } from '../Dtos/searchSummaryOutput';

@Injectable()
export class SearchSummaryService {
  constructor(private http: UpsHttpClient) {}

  public search(searchHomeInput: SearchSummaryInput): Observable<PageResult<SearchSummaryOutput>> {
    return this.http.post('Summary/Search', JSON.stringify(searchHomeInput));
  }

}
