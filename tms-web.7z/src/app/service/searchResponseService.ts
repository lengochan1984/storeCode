import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UpsHttpClient } from '../common/UpsHttpClient';
import { PageResult } from '../Dtos/PageResult';
import { SearchResponseInput } from '../Dtos/searchResponseInput';
import { SearchResponseOutput } from '../Dtos/searchResponseOutput';

@Injectable()
export class SearchResponseService {
  constructor(private http: UpsHttpClient) {}

  public search(searchResponseInput: SearchResponseInput): Observable<PageResult<SearchResponseOutput>> {
    return this.http.post('Response/SearchResponse', JSON.stringify(searchResponseInput));
  }
}
