import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UpsHttpClient } from '../common/UpsHttpClient';
import { UserLoginInput } from '../Dtos/userLoginInput';
import { UserLoginOutput } from '../Dtos/userLoginOutput';
import { PageResult } from '../Dtos/PageResult';

@Injectable()
export class UserLoginService {
  constructor(private http: UpsHttpClient) {}

  public login(userLoginInput: UserLoginInput): Observable<PageResult<UserLoginOutput>> {
    return this.http.post('Login/CheckLogin', JSON.stringify(userLoginInput));
  }

  public GetUserInformation(userLoginInput: UserLoginInput): Observable<PageResult<UserLoginOutput>> {
    return this.http.post('Login/UserInformation', JSON.stringify(userLoginInput));
  }

  

}
