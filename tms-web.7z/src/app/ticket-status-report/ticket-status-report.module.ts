import { NgModule } from "@angular/core";
import { TicketStatusReportComponent } from "./ticket-status-report.component";
import { SharedModule } from "../common/shared.module";
import { TicketTotalComponent } from "./view-ticket-total/ticket-total.component";
import { ListTicketTotalComponent } from "./view-ticket-total/list-ticket-total/list-ticket-total.component";
import { TicketResponseComponent } from "./view-ticket-response/ticket-response.component";
import { ListTicketResponseComponent } from "./view-ticket-response/list-ticket-response/list-ticket-response.component";
import { SearchTicketResponseComponent } from "./view-ticket-response/search-ticket-response/search-ticket-response.component";

@NgModule
({
    imports: [
        SharedModule,
    ],
    exports: [],
    providers: [],
    declarations: [
        TicketStatusReportComponent,
        TicketTotalComponent,
        ListTicketTotalComponent,

        TicketResponseComponent,
        SearchTicketResponseComponent,
        ListTicketResponseComponent
    ]
})
export class TicketStatusReportModule {};