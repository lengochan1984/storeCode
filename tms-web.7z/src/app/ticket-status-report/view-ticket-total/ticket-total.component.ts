import { Component, Input, Output, EventEmitter } from "@angular/core";
import { BaseComponent } from "src/app/common/base.component";
import { TotalHeaderTicketOutput } from "src/app/Dtos/totalHeaderTicketOutput";
import { TotalTicketByPicOutput } from "src/app/Dtos/totalTicketByPicOutput";
import { SearchStatusResponseInput } from "src/app/Dtos/searchStatusReponseInput";
import { AppConfig } from "src/app/common/app.config";
import { SortMode } from "src/app/common/SortMode";

@Component({
    selector: "ticket-total",
    templateUrl: "ticket-total.component.html"
})
export class TicketTotalComponent extends BaseComponent{
    @Input()
    public totalHeaderTicketOutput: TotalHeaderTicketOutput;

    @Input()
    public totalTicketByPicOutput: TotalTicketByPicOutput[];

    @Output()
    public searchStatusResponseEvent: EventEmitter<SearchStatusResponseInput> = new EventEmitter<SearchStatusResponseInput>();

    @Input()
    public totalCount: number;

    @Input()
    public isLoading: boolean;

    @Input()
    public searchStatusResponseInput: SearchStatusResponseInput;

    public constructor(){
        super();
    }

    public detailTicketStatus(type: string): void {
        this.searchStatusResponseInput.type = type;
        this.searchStatusResponseInput.inputSearch = "";

        this.searchStatusResponseInput.maxResultCount = 20;
        this.searchStatusResponseInput.sorting = "pic " + SortMode.Desc
        this.searchStatusResponseInput.skipCount = 0;

        this.searchStatusResponseEvent.emit(this.searchStatusResponseInput);
    }
}