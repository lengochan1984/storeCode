import { Component, Input } from "@angular/core";
import { BaseComponent } from "src/app/common/base.component";
import { TotalTicketByPicOutput } from "src/app/Dtos/totalTicketByPicOutput";

@Component({
    selector: "list-ticket-total",
    templateUrl: "list-ticket-total.component.html"
})
export class ListTicketTotalComponent extends BaseComponent{

    @Input()
    public totalTicketByPicOutput: TotalTicketByPicOutput[];

    @Input()
    public totalCount: number;
    
    @Input()
    public isLoading: boolean;
    
    public constructor (){
        super();
    }

    public ngOnInit(): void {
        super.ngOnInit();
    }
}