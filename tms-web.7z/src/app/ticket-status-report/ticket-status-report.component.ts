import { Component } from "@angular/core";
import { BaseComponent } from "../common/base.component";
import { SearchTotalTicketInput } from "../Dtos/searchTotalTicketInput";
import { SearchTotalTicketStatusService } from "../service/searchTotalTicketStatus.service";
import { TotalTicketOutput } from "../Dtos/totalTicketOutput";
import { TotalHeaderTicketOutput } from "../Dtos/totalHeaderTicketOutput";
import { TotalTicketByPicOutput } from "../Dtos/totalTicketByPicOutput";
import { PaginatorAndSorterInfo } from "../common/PaginatorAndSorterInfo";
import { AppConfig } from "../common/app.config";
import { SortMode } from "../common/SortMode";
import { SearchStatusResponseInput } from "../Dtos/searchStatusReponseInput";
import { CatchErrorService } from "../common/catchErrorService";
import { SearchStatusResponseOutput } from "../Dtos/searchStatusResponseOutput";

@Component({
    selector: "ticket-status-report",
    templateUrl: "ticket-status-report.component.html"
})
export class TicketStatusReportComponent extends BaseComponent {
    public messageTotalErr: string = "";
    public messageRespErr: string = "";
    /*
    * Search total ticket
    */
    public totalHeaderTicketOutput: TotalHeaderTicketOutput;

    public totalTicketByPicOutput: TotalTicketByPicOutput[];

    public searchTotalTicketInput: SearchTotalTicketInput;

    public totalCount: number;

    public isLoading: boolean;


    private totalTicketOutput: TotalTicketOutput;

    /*
    * Search response
    */
    public searchStatusResponseInput: SearchStatusResponseInput;

    public searchStatusResponseOutput: SearchStatusResponseOutput[];

    public totalRespCount: number;

    public isRespLoading: boolean;

    public paginatorAndSorterInfo: PaginatorAndSorterInfo;

    public constructor(
        private searchTotalTicketStatusService: SearchTotalTicketStatusService,
        private catchErrorService: CatchErrorService,
    ) {
        super();
    }

    public ngOnInit() {
        super.ngOnInit();
        this.searchTotalTicket(this.searchTotalTicketInput);
        this.searchStatusResponse(this.searchStatusResponseInput);
    }

    public initVariables(): void {
        this.initTotalVariables();
        this.initStatusRespVariables();
    }

    private initTotalVariables(): void {
        this.totalHeaderTicketOutput = {} as TotalHeaderTicketOutput;
        this.totalTicketByPicOutput = [] as TotalTicketByPicOutput[];
        this.totalTicketOutput = {} as TotalTicketOutput;
        this.searchTotalTicketInput = {} as SearchTotalTicketInput;

        this.searchTotalTicketInput.maxResultCount = AppConfig.settings.pageItems;
        this.searchTotalTicketInput.skipCount = 0;
        this.searchTotalTicketInput.sorting = `${'totalLate' + ' ' + SortMode.Desc + ' ' + 
            ', totalBeLate' + ' ' + SortMode.Desc + ' ' + 
            ', totalOpen' + ' ' + SortMode.Desc
            }`;
    }

    private initStatusRespVariables(): void {
        this.searchStatusResponseInput = {} as SearchStatusResponseInput;
        this.searchStatusResponseOutput = [] as SearchStatusResponseOutput[];

        this.paginatorAndSorterInfo = {
            maxResultCount: 20,
            skipCount: 0,
            sortColumn: "",
            sortMode: ""
        };

        this.searchStatusResponseInput.maxResultCount = this.paginatorAndSorterInfo.maxResultCount;
        this.searchStatusResponseInput.skipCount = this.paginatorAndSorterInfo.skipCount;
        this.searchStatusResponseInput.sorting = `${'pic' + ' ' + SortMode.Asc }`;
    }

    private searchTotalTicket(searchTotalTicketEvent: SearchTotalTicketInput): void {
        this.isLoading = true;
        this.searchTotalTicketInput = searchTotalTicketEvent;
        this.searchTotalTicketStatusService.searchTotalTicketStatus(this.searchTotalTicketInput).subscribe(
            data => {
                this.totalTicketOutput = data;
                this.totalHeaderTicketOutput = this.totalTicketOutput.totalHeaderTicket;
                this.totalTicketByPicOutput = this.totalTicketOutput.totalTicketByPic;

                this.totalCount = this.totalTicketByPicOutput.length;
                this.isLoading = false;
                this.messageTotalErr = ""
            },
            error => {
                this.messageTotalErr = this.catchErrorService.GetMessageError(error);
                this.totalCount = 0;
                this.isLoading = false;
            }
        );
    }

    public  searchStatusResponse(searchStatusResponseEvent: SearchStatusResponseInput): void {
        this.isRespLoading = true;
        this.searchStatusResponseInput = searchStatusResponseEvent;
        this.searchTotalTicketStatusService.searchStatusResponse(this.searchStatusResponseInput).subscribe(
            data => {
                this.searchStatusResponseOutput = data.items;
                this.totalRespCount = data.totalCount;

                this.isRespLoading = false;
                this.messageRespErr = "";

                this.paginatorAndSorterInfo = {
                    maxResultCount: this.searchStatusResponseInput.maxResultCount,
                    skipCount: this.searchStatusResponseInput.skipCount,
                    sortColumn: this.searchStatusResponseInput.sorting.split(' ', 2)[0],
                    sortMode: this.searchStatusResponseInput.sorting.split(' ', 2)[1]
                  };
            },
            error => {
                this.messageRespErr = this.catchErrorService.GetMessageError(error);
                this.totalRespCount = 0;
                this.isRespLoading = false;
            }
        );
    }
}