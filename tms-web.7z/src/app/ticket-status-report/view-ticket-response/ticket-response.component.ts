import { Component, Input, Output, EventEmitter } from "@angular/core";
import { BaseComponent } from "src/app/common/base.component";
import { SearchStatusResponseInput } from "src/app/Dtos/searchStatusReponseInput";
import { SearchStatusResponseOutput } from "src/app/Dtos/searchStatusResponseOutput";
import { PaginatorAndSorterInfo } from "src/app/common/PaginatorAndSorterInfo";

@Component({
    selector: "ticket-response",
    templateUrl: "ticket-response.component.html"
})
export class TicketResponseComponent extends BaseComponent{
    @Input()
    public searchStatusResponseInput: SearchStatusResponseInput;

    @Input()
    public searchStatusResponseOutput: SearchStatusResponseOutput[];
    
    @Input()
    public paginatorAndSorterInfo: PaginatorAndSorterInfo;
    
    @Input()
    public totalCount: number;

    @Input()
    public isLoading: boolean;
    
    @Output()
    public searchStatusResponseEvent: EventEmitter<SearchStatusResponseInput> = new EventEmitter<SearchStatusResponseInput>();

    public constructor(){
        super();
    }

    public ngOninit(){
        super.ngOnInit();
    };

    public searchResponse(searchTicketResponseEvent: SearchStatusResponseInput){
        this.searchStatusResponseInput = searchTicketResponseEvent;
        this.searchStatusResponseEvent.emit(this.searchStatusResponseInput);
    }
}