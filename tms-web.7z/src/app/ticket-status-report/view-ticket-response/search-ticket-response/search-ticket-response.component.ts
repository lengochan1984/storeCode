import { Component, Output, EventEmitter, Input } from "@angular/core";
import { BaseComponent } from "src/app/common/base.component";
import { FormBuilder, FormGroup } from "@angular/forms";
import { SearchStatusResponseInput } from "src/app/Dtos/searchStatusReponseInput";

@Component({
    selector: "search-ticket-response",
    templateUrl: "search-ticket-response.component.html"
})
export class SearchTicketResponseComponent extends BaseComponent{
    public form: FormGroup;

    @Input()
    public searchStatusResponseInput: SearchStatusResponseInput;

    @Input()
    public isLoading: boolean;

    @Output()
    public searchTicketResponseEvent: EventEmitter<SearchStatusResponseInput> = new EventEmitter<SearchStatusResponseInput>();

    public constructor(
        private formBuilder: FormBuilder,
    ){
        super();
    }

    public ngOnInit(){
        super.ngOnInit();
    }
    public initForm(): void {
        this.form = this.formBuilder.group({
            inputSearch: [""]
        });
    }

    public onChanges(){
        if(this.form){
            this.form.controls["inputSearch"].setValue(this.searchStatusResponseInput.inputSearch);
        }
    }

    public searchResponse(): void {
        this.searchStatusResponseInput.inputSearch = this.form.value.inputSearch;
        this.searchStatusResponseInput.skipCount = 0;
        this.searchTicketResponseEvent.emit(this.searchStatusResponseInput);
    }
}