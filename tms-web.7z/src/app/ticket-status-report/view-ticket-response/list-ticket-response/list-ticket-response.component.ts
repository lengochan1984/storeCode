import { Component, Input, Output, EventEmitter } from "@angular/core";
import { BaseComponent } from "src/app/common/base.component";
import { SearchStatusResponseOutput } from "src/app/Dtos/searchStatusResponseOutput";
import { SearchStatusResponseInput } from "src/app/Dtos/searchStatusReponseInput";
import { PaginatorAndSorterInfo } from "src/app/common/PaginatorAndSorterInfo";

@Component({
    selector: "list-ticket-response",
    templateUrl:"list-ticket-response.component.html"
})
export class ListTicketResponseComponent extends BaseComponent{
    @Input()
    public searchStatusResponseInput: SearchStatusResponseInput;

    @Input()
    public searchStatusResponseOutput: SearchStatusResponseOutput[];
    
    @Input()
    public paginatorAndSorterInfo: PaginatorAndSorterInfo;

    @Input()
    public totalCount: number;

    @Input()
    public isLoading: boolean;

    @Output()
    public searchStatusResponseEvent: EventEmitter<SearchStatusResponseInput> = new EventEmitter<SearchStatusResponseInput>();

    public constructor (

    ){
        super();
    }

    public ngOnInit(){
        super.ngOnInit();
    }

    public search(paginatorAndSorterInfo: PaginatorAndSorterInfo){
        this.paginatorAndSorterInfo.skipCount = paginatorAndSorterInfo.skipCount;
        this.paginatorAndSorterInfo.sortColumn = paginatorAndSorterInfo.sortColumn;
        this.paginatorAndSorterInfo.sortMode = paginatorAndSorterInfo.sortMode;

        this.searchStatusResponseInput.skipCount = this.paginatorAndSorterInfo.skipCount;
        this.searchStatusResponseInput.maxResultCount = this.paginatorAndSorterInfo.maxResultCount;
        this.searchStatusResponseEvent.emit(this.searchStatusResponseInput);
    }
}