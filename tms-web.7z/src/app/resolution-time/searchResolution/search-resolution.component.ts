import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BaseComponent } from 'src/app/common/base.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SearchResolutionInput } from 'src/app/Dtos/searchResolutionInput';
import { DateFormatPipe } from 'src/app/common/dateFormat.pipe';
import { AppConfig } from 'src/app/common/app.config';
declare var jquery: any;
declare var $;
@Component({
  selector: 'search-resolution',
  templateUrl: './search-resolution.component.html',
  styles: [`
  #message-err {
    font-weight: bold;
    color: #ff0000;
    width: 100%;
    padding-top: 5px;
  }
  `]
})
export class SearchResolutionComponent extends BaseComponent {
  
  @Input()
  public searchResolutionInput: SearchResolutionInput;
  
  
  @Output()
  public searchResolutionEvent: EventEmitter<SearchResolutionInput> = new EventEmitter<SearchResolutionInput>();

  
  public form: FormGroup;
  public messageErr: string = '';
  
  constructor(
    private formBuilder: FormBuilder, 
    private dateFormat: DateFormatPipe) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
  }

  public checkValidate(): boolean {
    var dateFrom 	= this.dateFormat.transform(this.form.value.submittedFrom, true);
      var dateTo		= this.dateFormat.transform(this.form.value.submittedTo, true);
      if (dateFrom !== undefined && !this.dateFormat.isValidDate(dateFrom)) {
        this.messageErr = "Invalid dateFrom";
        return false;
      }
      if (dateTo !== undefined && !this.dateFormat.isValidDate(dateTo)) {
        this.messageErr = "Invalid dateTo";
        return false;
      }
			if (dateFrom > dateTo) {
        this.messageErr = "Invalid date range";
        return false;
      }
      this.messageErr = "";
      return true;
  }
  public initForm(): void {
    this.form = this.formBuilder.group({
      status: [this.searchResolutionInput.status],
      submittedFrom: [this.dateFormat.transform(this.searchResolutionInput.submittedFrom,  true)],
      submittedTo: [this.dateFormat.transform(this.searchResolutionInput.submittedTo, true)],
      assignedTo: [this.searchResolutionInput.assignedTo],
      isResponsed: [this.searchResolutionInput.isResponsed],
      maxResultCount: [this.searchResolutionInput.maxResultCount]
    });
  }

  public search(): void {
    this.markFormDirty();
    
    if(!this.checkValidate()) {
      return;
    };

    if (!this.form.valid) {
      return;
    }
    
    this.setValueSearch();
    this.searchResolutionEvent.emit(this.searchResolutionInput);

  }
  private setValueSearch(): void {
    this.searchResolutionInput.status = this.form.value.status;
    this.searchResolutionInput.submittedFrom = this.dateFormat.transform(this.form.value.submittedFrom, true);
    this.searchResolutionInput.submittedTo = this.dateFormat.transform(this.form.value.submittedTo, true);
    this.searchResolutionInput.assignedTo = this.form.value.assignedTo;
    this.searchResolutionInput.isResponsed = this.form.value.isResponsed;

    this.searchResolutionInput.maxResultCount = this.form.value.maxResultCount;
    this.searchResolutionInput.skipCount = 0;
  }

  public changeStatus(): void {
    if(this.form.value.status === "0"){
      this.form.controls["isResponsed"].setValue(1);
      this.disableControl(["isResponsed"]);
    } else {
      this.enableControl(["isResponsed"]);
    } 
  }
}
