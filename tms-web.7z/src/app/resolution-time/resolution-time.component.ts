import { Component } from '@angular/core';
import { SearchResolutionInput } from '../Dtos/searchResolutionInput';
import { BaseComponent } from '../common/base.component';
import { SearchResolutionOutput } from '../Dtos/searchResolutionOutput';
import { DateFormatPipe } from '../common/dateFormat.pipe';
import { PaginatorAndSorterInfo } from '../common/PaginatorAndSorterInfo';
import { AppConfig } from '../common/app.config';
import { SortMode } from '../common/SortMode';
import { SearchResolutionService } from '../service/searchResolutionService';
declare var jquery:any;
declare var $ :any;

@Component({
  selector: 'app-resolution-time',
  templateUrl: './resolution-time.component.html'
})
export class ResolutionTimeComponent extends BaseComponent {
  // paging --->
  public totalCount: number;
  public paginatorAndSorterInfo: PaginatorAndSorterInfo;
  // <--- paging
  public isLoading: boolean;

  public searchResolutionInput: SearchResolutionInput;
  public searchResolutionOutput: SearchResolutionOutput[];
  constructor( 
    private searchResolutionService: SearchResolutionService,
    private dateFormat: DateFormatPipe
    ) { 
    super();
  }

  ngOnInit() {
    super.ngOnInit();
  }

  public onInit() {
    super.onInit();   
    this.search(this.searchResolutionInput);
  }
  public initVariables(): void {
    super.initVariables();
    this.searchResolutionInput = {} as SearchResolutionInput; 
    this.searchResolutionOutput = [] as SearchResolutionOutput[];
    this.paginatorAndSorterInfo = {} as PaginatorAndSorterInfo;
    this.isLoading = true;

    this.initSearchInput();
  }

  public initSearchInput(): void {
    this.searchResolutionInput.submittedFrom = this.dateFormat.transform(this.dateFormat.getFirstDateStruct(), true);
    this.searchResolutionInput.submittedTo = this.dateFormat.transform(this.dateFormat.getDefaultDate(), true);
    this.searchResolutionInput.status = "1";
    this.searchResolutionInput.assignedTo = "tls";
    this.searchResolutionInput.isResponsed = "";

    this.paginatorAndSorterInfo = {
      maxResultCount: AppConfig.settings.pageItems,
      skipCount: 0,
      sortColumn: "groupId",
      sortMode: SortMode.Asc
    };
    this.searchResolutionInput.maxResultCount = this.paginatorAndSorterInfo.maxResultCount;
    this.searchResolutionInput.skipCount = this.paginatorAndSorterInfo.skipCount;
    this.searchResolutionInput.sorting = `${this.paginatorAndSorterInfo.sortColumn +
      ' ' +
      this.paginatorAndSorterInfo.sortMode}`;
      
  }

  public search(searchResolutionEvent: SearchResolutionInput): void {
    
    this.searchResolutionInput = searchResolutionEvent;
    this.isLoading = true;
    this.searchResolutionService.search(this.searchResolutionInput).subscribe(data => {
      
      this.searchResolutionOutput = data.items;
      this.totalCount = data.totalCount;
      this.isLoading = false;

      this.paginatorAndSorterInfo = {
        maxResultCount: this.searchResolutionInput.maxResultCount,
        skipCount: this.searchResolutionInput.skipCount,
        sortColumn: this.searchResolutionInput.sorting.split(' ', 2)[0],
        sortMode: this.searchResolutionInput.sorting.split(' ', 2)[1]
      };
    });
  }
  
}

