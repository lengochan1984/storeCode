import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { BaseComponent } from 'src/app/common/base.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SearchResolutionOutput } from 'src/app/Dtos/searchResolutionOutput';
import { PaginatorAndSorterInfo } from 'src/app/common/PaginatorAndSorterInfo';
import { SearchResolutionInput } from 'src/app/Dtos/searchResolutionInput';

import { Router } from '@angular/router';

@Component({
  selector: 'list-search-resolution',
  templateUrl: './list-search-resolution.component.html',
})
export class ListSearchResolutionComponent extends BaseComponent {
  @Input()
  public searchResolutionOutput: SearchResolutionOutput[];

  // Paging ----->
  @Input()
  public searchResolutionInput: SearchResolutionInput;

  @Output()
  public searchResolutionEvent: EventEmitter<SearchResolutionInput> = new EventEmitter<SearchResolutionInput>();

  @Input()
  public totalCount: number;

  @Input()
  public isLoading: boolean;

  @Input()
  public paginatorAndSorterInfo: PaginatorAndSorterInfo;
  // <----- Paging

  public form: FormGroup;


  constructor(private formBuilder: FormBuilder, public router: Router) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
  }

  public search(paginatorAndSorterInfo: PaginatorAndSorterInfo): void {
    this.paginatorAndSorterInfo.skipCount = paginatorAndSorterInfo.skipCount;
    this.paginatorAndSorterInfo.sortColumn = paginatorAndSorterInfo.sortColumn;
    this.paginatorAndSorterInfo.sortMode = paginatorAndSorterInfo.sortMode;

    this.searchResolutionInput.skipCount = paginatorAndSorterInfo.skipCount;
    this.searchResolutionInput.sorting = `${paginatorAndSorterInfo.sortColumn + ' ' + paginatorAndSorterInfo.sortMode}`;
    this.searchResolutionEvent.emit(this.searchResolutionInput);
  }
}