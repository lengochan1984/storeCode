import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SharedModule } from './common/shared.module';
import { DetailSummaryComponent } from './detailSummary/detail-summary.component';

const appRoutes: Routes = [
    { path: '', redirectTo: 'dashboard', pathMatch: "full" },
    { path: 'login', component: LoginComponent },
    { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboarModule' },
    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [ 
    SharedModule,
    RouterModule.forRoot(appRoutes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}


