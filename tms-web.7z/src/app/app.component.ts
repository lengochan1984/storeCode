import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { LoaderService } from './service/loader.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  title = 'UPS-APP';

  public blocked: boolean;

  constructor(
    private loaderService: LoaderService,
    private cdRef: ChangeDetectorRef,
    private router: Router,
  ) {
    
  }

  public ngOnInit(): void {
    
    this.loaderService.loader().subscribe(state => {
      this.blocked = state;
      // To avoid issue: AppComponent.html:167 ERROR Error: ExpressionChangedAfterItHasBeenCheckedError:
      // Expression has changed after it was checked. Previous value: 'ngIf: false'. Current value: 'ngIf: true'.
      this.cdRef.detectChanges();
    });
    
    
  }

  
}
