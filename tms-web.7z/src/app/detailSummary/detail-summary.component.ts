import { Component, Input } from '@angular/core';
import { BaseComponent } from 'src/app/common/base.component';
import { FormGroup } from '@angular/forms';
import { AppConfig } from 'src/app/common/app.config';
import { DetailInput } from 'src/app/Dtos/detailInput';
import { DetailOutput } from 'src/app/Dtos/detailOutput';
import { Data } from '../common/data-storage';
import { PaginatorAndSorterInfo } from '../common/PaginatorAndSorterInfo';
import { SortMode } from '../common/SortMode';
import { Router } from '@angular/router';
import { SearchDetailService } from '../service/searchDetailService';

@Component({
  selector: 'detail-summary',
  templateUrl: './detail-summary.component.html',
})
export class DetailSummaryComponent extends BaseComponent {
  // paging --->
  public totalCount: number;
  public paginatorAndSorterInfo: PaginatorAndSorterInfo;
  // <--- paging
  public isLoading: boolean;

  public title: string;
  public form: FormGroup;
  public searchDetailInput: DetailInput;
  public searchDetailOutput: DetailOutput[];

  constructor(
    private router: Router,
    private searchDetailService: SearchDetailService,
    private data: Data) {
    super();
    if(!this.data.storage){
      this.router.navigate(['dashboard']);
    }
  }

  public initVariables(): void {
    super.initVariables();
    this.searchDetailInput = {} as DetailInput;
    this.searchDetailOutput = [] as DetailOutput[];

  }

  ngOnInit() {
    super.ngOnInit();
    this.searchDetailInput.submittedFrom = this.data.storage.submittedFrom;
    this.searchDetailInput.submittedTo = this.data.storage.submittedTo;
    this.searchDetailInput.status = this.data.storage.status;
    this.searchDetailInput.type = this.data.storage.type;
    this.searchDetailInput.userId = this.data.storage.userId;


    this.paginatorAndSorterInfo = {
      maxResultCount: AppConfig.settings.pageItems,
      skipCount: 0,
      sortColumn: "",
      sortMode: SortMode.Asc
    };
    this.searchDetailInput.maxResultCount = this.paginatorAndSorterInfo.maxResultCount;
    this.searchDetailInput.skipCount = this.paginatorAndSorterInfo.skipCount;
    this.searchDetailInput.sorting = `${'GroupId' + ' ' + this.paginatorAndSorterInfo.sortMode
    +', SOId' + ' ' + this.paginatorAndSorterInfo.sortMode}`;
    
    this.search(this.searchDetailInput);
  }

  public search(detailInputEvent: DetailInput): void {

    this.searchDetailInput = detailInputEvent;
    this.searchDetailService.GetTicketsummaryrecorddetail(this.searchDetailInput).subscribe(data => {
      this.searchDetailOutput = data.items;
      this.totalCount = data.totalCount;
      this.isLoading = false;

      if(this.searchDetailInput.sorting.indexOf(",") < 0) {
        this.paginatorAndSorterInfo = {
          maxResultCount: this.searchDetailInput.maxResultCount,
          skipCount: this.searchDetailInput.skipCount,
          sortColumn: this.searchDetailInput.sorting.split(' ', 2)[0],
          sortMode: this.searchDetailInput.sorting.split(' ', 2)[1]
        };
      } else {
        this.paginatorAndSorterInfo = {
          maxResultCount: this.searchDetailInput.maxResultCount,
          skipCount: this.searchDetailInput.skipCount,
          sortColumn: `${'GroupId' + ' ' + this.paginatorAndSorterInfo.sortMode
          +', SOId' + ' ' + this.paginatorAndSorterInfo.sortMode}`,
          sortMode: ""
        };
      }
      
      // Title
      if(this.searchDetailInput.type !== "total") {
        this.title = this.searchDetailInput.type.toUpperCase() + " - " + this.searchDetailOutput[0].userName;
      }
      else {
        this.title = this.searchDetailOutput[0].userName
      }
    });
  }

  public backHome(): void {
    this.data.storage = {
      "submittedFrom": this.searchDetailInput.submittedFrom,
      "submittedTo": this.searchDetailInput.submittedTo,
      "status": this.searchDetailInput.status
  }
  this.router.navigate(['dashboard/statusReport']);
  }
}
