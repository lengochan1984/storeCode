import { Component, Input, EventEmitter, Output } from '@angular/core';
import { BaseComponent } from 'src/app/common/base.component';
import { FormGroup } from '@angular/forms';
import { PaginatorAndSorterInfo } from 'src/app/common/PaginatorAndSorterInfo';
import { DetailOutput } from 'src/app/Dtos/detailOutput';
import { DetailInput } from 'src/app/Dtos/detailInput';

@Component({
  selector: 'list-search-detail',
  templateUrl: './list-detail-summary.component.html',
})
export class ListSearchDetailComponent extends BaseComponent {
  @Input()
  public searchDetailOutput: DetailOutput[];

  // Paging ----->
  @Input()
  public searchDetailInput: DetailInput;

  @Output()
  public searchDetailEvent: EventEmitter<DetailInput> = new EventEmitter<DetailInput>();

  @Input()
  public totalCount: number;

  @Input()
  public isLoading: boolean;

  @Input()
  public paginatorAndSorterInfo: PaginatorAndSorterInfo;
  // <----- Paging

  public form: FormGroup;


  constructor() {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
  }

  public search(paginatorAndSorterInfo: PaginatorAndSorterInfo): void {
    this.paginatorAndSorterInfo.skipCount = paginatorAndSorterInfo.skipCount;
    this.paginatorAndSorterInfo.sortColumn = paginatorAndSorterInfo.sortColumn;
    this.paginatorAndSorterInfo.sortMode = paginatorAndSorterInfo.sortMode;

    this.searchDetailInput.skipCount = paginatorAndSorterInfo.skipCount;
    this.searchDetailInput.sorting = `${paginatorAndSorterInfo.sortColumn + ' ' + paginatorAndSorterInfo.sortMode}`;
    this.searchDetailEvent.emit(this.searchDetailInput);
  }
}