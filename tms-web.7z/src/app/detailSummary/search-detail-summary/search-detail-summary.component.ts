import { Component, Input, Output, EventEmitter } from '@angular/core';
import { BaseComponent } from 'src/app/common/base.component';
import { FormGroup, FormBuilder } from '@angular/forms';
import { DateFormatPipe } from 'src/app/common/dateFormat.pipe';
import { AppConfig } from 'src/app/common/app.config';
import { DetailInput } from 'src/app/Dtos/detailInput';

@Component({
    selector: 'search-detail',
    templateUrl: './search-detail-summary.component.html'
})
export class SearchDetailComponent extends BaseComponent {

    @Input()
    public searchDetailInput: DetailInput;


    @Output()
    public searchDetailEvent: EventEmitter<DetailInput> = new EventEmitter<DetailInput>();


    public form: FormGroup;

    constructor(
        private formBuilder: FormBuilder,
        private dateFormat: DateFormatPipe) {
        super();
    }

    ngOnInit() {
        super.ngOnInit();
    }

    public initForm(): void {
        this.form = this.formBuilder.group({
            status: [{value: this.searchDetailInput.status, disabled: true}],
            submittedFrom: [{value: this.dateFormat.transform(this.searchDetailInput.submittedFrom, true), disabled: true}],
            submittedTo: [{value: this.dateFormat.transform(this.searchDetailInput.submittedTo, true), disabled: true}],
            maxResultCount: [AppConfig.settings.pageItems]
        });
    }

    public search(): void {
        this.setValueSearch();
        this.searchDetailEvent.emit(this.searchDetailInput);

    }
    private setValueSearch(): void {
        this.searchDetailInput.maxResultCount = this.form.value.maxResultCount;
        this.searchDetailInput.skipCount = 0;        
    }
}
