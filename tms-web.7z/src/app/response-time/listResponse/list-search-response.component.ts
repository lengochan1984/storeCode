import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { BaseComponent } from 'src/app/common/base.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SearchResponseOutput } from 'src/app/Dtos/searchResponseOutput';
import { PaginatorAndSorterInfo } from 'src/app/common/PaginatorAndSorterInfo';
import { SearchResponseInput } from 'src/app/Dtos/searchResponseInput';

import { Router } from '@angular/router';

@Component({
  selector: 'list-search-response',
  templateUrl: './list-search-Response.component.html',
})
export class ListSearchResponseComponent extends BaseComponent {
  @Input()
  public searchResponseOutput: SearchResponseOutput[];

  // Paging ----->
  @Input()
  public searchResponseInput: SearchResponseInput;

  @Output()
  public searchResponseEvent: EventEmitter<SearchResponseInput> = new EventEmitter<SearchResponseInput>();

  @Input()
  public totalCount: number;

  @Input()
  public isLoading: boolean;

  @Input()
  public paginatorAndSorterInfo: PaginatorAndSorterInfo;
  // <----- Paging

  public form: FormGroup;


  constructor(private formBuilder: FormBuilder, public router: Router) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
  }

  public search(paginatorAndSorterInfo: PaginatorAndSorterInfo): void {
    this.paginatorAndSorterInfo.skipCount = paginatorAndSorterInfo.skipCount;
    this.paginatorAndSorterInfo.sortColumn = paginatorAndSorterInfo.sortColumn;
    this.paginatorAndSorterInfo.sortMode = paginatorAndSorterInfo.sortMode;

    this.searchResponseInput.skipCount = paginatorAndSorterInfo.skipCount;
    this.searchResponseInput.sorting = `${paginatorAndSorterInfo.sortColumn + ' ' + paginatorAndSorterInfo.sortMode}`;
    this.searchResponseEvent.emit(this.searchResponseInput);
  }
 
}