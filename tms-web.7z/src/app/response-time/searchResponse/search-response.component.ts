import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BaseComponent } from 'src/app/common/base.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SearchResponseInput } from 'src/app/Dtos/searchResponseInput';
import { DateFormatPipe } from 'src/app/common/dateFormat.pipe';
declare var jquery: any;
declare var $;
@Component({
  selector: 'search-response',
  templateUrl: './search-response.component.html',
  styles: [`
  #message-err {
    font-weight: bold;
    color: #ff0000;
    width: 100%;
    padding-top: 5px;
  }
  `]
})
export class SearchResponseComponent extends BaseComponent {
  
  @Input()
  public searchResponseInput: SearchResponseInput;
  
  
  @Output()
  public searchResponseEvent: EventEmitter<SearchResponseInput> = new EventEmitter<SearchResponseInput>();

  
  public form: FormGroup;
  public messageErr: string = '';
  
  constructor(
    private formBuilder: FormBuilder, 
    private dateFormat: DateFormatPipe) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
  }

  public checkValidate(): boolean {
    var dateFrom 	= this.dateFormat.transform(this.form.value.submittedFrom, true);
      var dateTo		= this.dateFormat.transform(this.form.value.submittedTo, true);
      if (dateFrom !== undefined && !this.dateFormat.isValidDate(dateFrom)) {
        this.messageErr = "Invalid dateFrom";
        return false;
      }
      if (dateTo !== undefined && !this.dateFormat.isValidDate(dateTo)) {
        this.messageErr = "Invalid dateTo";
        return false;
      }
			if (dateFrom > dateTo) {
        this.messageErr = "Invalid date range";
        return false;
      }
      this.messageErr = "";
      return true;
  }
  public initForm(): void {
    this.form = this.formBuilder.group({
      status: [this.searchResponseInput.status],
      submittedFrom: [this.dateFormat.transform(this.searchResponseInput.submittedFrom,  true)],
      submittedTo: [this.dateFormat.transform(this.searchResponseInput.submittedTo, true)],
      assignedTo: [this.searchResponseInput.assignedTo],
      isResponsed: [this.searchResponseInput.isResponsed],
      maxResultCount: [this.searchResponseInput.maxResultCount]
    });
  }

  public search(): void {
    this.markFormDirty();

    if(!this.checkValidate()) {
      return;
    };
    
    if (!this.form.valid) {
      return;
    }
    this.setValueSearch();
    this.searchResponseEvent.emit(this.searchResponseInput);

  }
  private setValueSearch(): void {
    this.searchResponseInput.status = this.form.value.status;
    this.searchResponseInput.submittedFrom = this.dateFormat.transform(this.form.value.submittedFrom, true);
    this.searchResponseInput.submittedTo = this.dateFormat.transform(this.form.value.submittedTo, true);
    this.searchResponseInput.assignedTo = this.form.value.assignedTo;
    this.searchResponseInput.isResponsed = this.form.value.isResponsed;

    this.searchResponseInput.maxResultCount = this.form.value.maxResultCount;
    this.searchResponseInput.skipCount = 0;
  }
  public changeStatus(): void {
    if(this.form.value.status === "0"){
      this.form.controls["isResponsed"].setValue(1);
      this.disableControl(["isResponsed"]);
    } else {
      this.enableControl(["isResponsed"]);
    } 
  }
}
