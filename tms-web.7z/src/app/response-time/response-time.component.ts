import { Component } from '@angular/core';
import { SearchResponseInput } from '../Dtos/searchResponseInput';
import { BaseComponent } from '../common/base.component';
import { SearchResponseOutput } from '../Dtos/searchResponseOutput';
import { DateFormatPipe } from '../common/dateFormat.pipe';
import { PaginatorAndSorterInfo } from '../common/PaginatorAndSorterInfo';
import { AppConfig } from '../common/app.config';
import { SortMode } from '../common/SortMode';
import { SearchResponseService } from '../service/searchResponseService';

@Component({
  selector: 'app-response-time',
  templateUrl: './response-time.component.html'
})
export class ResponseTimeComponent extends BaseComponent {
  // paging --->
  public totalCount: number;
  public paginatorAndSorterInfo: PaginatorAndSorterInfo;
  // <--- paging
  public isLoading: boolean;

  public searchResponseInput: SearchResponseInput;
  public searchResponseOutput: SearchResponseOutput[];
  constructor( 
    private searchResponseService: SearchResponseService,
    private dateFormat: DateFormatPipe
    ) { 
    super();
  }

  ngOnInit() {
    super.ngOnInit();
  }

  public onInit() {
    super.onInit();   
    this.search(this.searchResponseInput);
  }
  public initVariables(): void {
    super.initVariables();
    this.searchResponseInput = {} as SearchResponseInput; 
    this.searchResponseOutput = [] as SearchResponseOutput[];
    this.paginatorAndSorterInfo = {} as PaginatorAndSorterInfo;
    this.isLoading = true;

    this.initSearchInput();
  }

  public initSearchInput(): void {
    this.searchResponseInput.submittedFrom = this.dateFormat.transform(this.dateFormat.getFirstDateStruct(), true);
    this.searchResponseInput.submittedTo = this.dateFormat.transform(this.dateFormat.getDefaultDate(), true);
    this.searchResponseInput.status = "1";
    this.searchResponseInput.assignedTo = "tls";
    this.searchResponseInput.isResponsed = "";

    this.paginatorAndSorterInfo = {
      maxResultCount: AppConfig.settings.pageItems,
      skipCount: 0,
      sortColumn: "groupId",
      sortMode: SortMode.Asc
    };
    this.searchResponseInput.maxResultCount = this.paginatorAndSorterInfo.maxResultCount;
    this.searchResponseInput.skipCount = this.paginatorAndSorterInfo.skipCount;
    this.searchResponseInput.sorting = `${this.paginatorAndSorterInfo.sortColumn +
      ' ' +
      this.paginatorAndSorterInfo.sortMode}`;
      
  }

  public search(searchResponseEvent: SearchResponseInput): void {
    
    this.searchResponseInput = searchResponseEvent;
    this.isLoading = true;
    this.searchResponseService.search(this.searchResponseInput).subscribe(data => {
      
      this.searchResponseOutput = data.items;
      this.totalCount = data.totalCount;
      this.isLoading = false;

      this.paginatorAndSorterInfo = {
        maxResultCount: this.searchResponseInput.maxResultCount,
        skipCount: this.searchResponseInput.skipCount,
        sortColumn: this.searchResponseInput.sorting.split(' ', 2)[0],
        sortMode: this.searchResponseInput.sorting.split(' ', 2)[1]
      };
    });
  }
  
}

