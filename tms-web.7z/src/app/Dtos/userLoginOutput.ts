
export interface UserLoginOutput {
  idUser: string;
  userName: string;
  password: string;
  }