export interface TotalHeaderTicketOutput{
    totalOpen: number;
    totalResp: number;
    totalImpl: number;
    noAction: number;
    totalLate: number;
    totalBeLate: number;
    totalRespLate: number;
    totalRespBeLate: number;
    totalImplLate: number;
    totalImplBeLate: number;
}