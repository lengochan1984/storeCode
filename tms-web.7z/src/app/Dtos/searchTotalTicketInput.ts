export interface SearchTotalTicketInput {
    maxResultCount: number;
    skipCount: number;
    sorting: string;
}