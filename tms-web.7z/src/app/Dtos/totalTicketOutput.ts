import { TotalHeaderTicketOutput } from "./totalHeaderTicketOutput";
import { TotalTicketByPicOutput } from "./totalTicketByPicOutput";

export interface TotalTicketOutput{
    totalHeaderTicket: TotalHeaderTicketOutput;
    totalTicketByPic: TotalTicketByPicOutput[];
}