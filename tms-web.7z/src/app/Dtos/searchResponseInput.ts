export interface SearchResponseInput {
  status: string;
  submittedFrom: Date;
  submittedTo: Date;
  assignedTo: string;
  isResponsed: string;
  
  maxResultCount: number;
  skipCount: number;
  sorting: string;
}
