export interface PageResult<TItemType> {

    totalCount: number;
    items: TItemType[];
}