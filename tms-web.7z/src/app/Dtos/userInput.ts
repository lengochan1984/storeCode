export interface UserInput {
  userId: string;
  firstName: string;
  lastName: string;
  displayName: string;
  password: string;
  confirmPassword: string;
  createdBy: string;
  updatedBy: string;
}
