export interface SearchSummaryOutput {
  userId: string;
  pic: string;
  sls: number;
  tls: number;
  hwsw: number;
  systemGeneratedAlerts: number;
  total: number;
}
