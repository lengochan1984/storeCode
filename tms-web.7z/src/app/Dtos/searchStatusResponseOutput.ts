export interface SearchStatusResponseOutput {
    soId: string;
    subject: string;
    pic: string;
    isResp: string;
    timeSpent: string;
    responseSLA: string;
    resolutionSLA: string;

    maxResultCount: number;
    skipCount: number;
    sorting: string;
}