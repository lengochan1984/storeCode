export interface DetailOutput {
  userId: string;
  userName: string;
  groupId: Int16Array;
  
  soId: string;
  subject: string;
  severity: string;

}
