export interface DetailInput {
  status: string;
  submittedFrom: Date;
  submittedTo: Date;
  userId: string;
  type: string;
    
  maxResultCount: number;
  skipCount: number;
  sorting: string;
}
