export interface SearchAccountInput {
  name: string;
  
  maxResultCount: number;
  skipCount: number;
  sorting: string;
}
