export interface SearchStatusResponseInput {
    type: string;
    inputSearch: string;

    maxResultCount: number;
    skipCount: number;
    sorting: string;
}