export interface SearchSummaryInput {
  status: string;
  submittedFrom: Date;
  submittedTo: Date;
  
  maxResultCount: number;
  skipCount: number;
  sorting: string;
}
