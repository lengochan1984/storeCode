
export interface UserIdInput {
    userId:string;
  }