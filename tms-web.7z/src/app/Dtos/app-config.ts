export interface IAppConfig {
    apiUrl: string;
    pageItems: number;
}
