export interface SearchResponseOutput {
  groupID: string;	
  soId: string;	
  subject: string;	
  severity: string;	
  assignedTo: string;	
  pic: string;	
  isResp: string;	
  onestRespStatus: string;	
  due: string;	
  onestRespContent: string;
}
