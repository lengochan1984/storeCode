export interface UserOutput {
  userId: string;
  firstName: string;
  lastName: string;
  displayName: string;
  password: string;
  createdBy: string;
  updatedBy: string;
}
