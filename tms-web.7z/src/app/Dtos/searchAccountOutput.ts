export interface SearchAccountOutput {
  userID: string;	
  firstName: string;	
  lastName: string;	
  displayName: string;	
  password: string;	
}
