export interface SearchResolutionOutput {
  groupId: string;	
  soId: string;	
  subject: string;	
  severity: string;	
  assignedTo: string;	
  pic: string;	
  isResolved: string;	
  onestRespStatus: string;	
  due: string;	
  resolutionContent: string;
}
