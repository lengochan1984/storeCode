
export interface UserLoginInput {
    userId:string;
    userName: string;
    passWord: string;
  }