// tslint:disable:no-magic-numbers
import { Component, EventEmitter, Input, Output } from '@angular/core';

import { PaginatorAndSorterInfo } from '../common/PaginatorAndSorterInfo';
import { BaseComponent } from './base.component';

@Component({
    selector: 'ups-paginator',
    template: `
        <div class="pull-right" *ngIf="totalItems > 0">
            <nav>
                <ul class="pagination">
                <li class="page-item" [ngClass]="{'disabled': (isFirstPage())}">
                    <span class="page-link" (click)="changePageToFirst($event)" >Fist</span>
                </li>
                    <li class="page-item" [ngClass]="{'disabled': (isFirstPage())}">
                    <span class="page-link" (click)="changePageToPrev($event)">Previous</span>
                </li>
                <li class="page-item"  *ngFor="let pageLink of pageLinks" [ngClass]="{'active': (pageLink == getPage())}">
                    <a class="page-link" (click)="changePage(pageLink, $event)">{{pageLink}}</a>
                </li>
                
                <li class="page-item" [ngClass]="{'disabled': (isLastPage())}">
                    <a class="page-link" (click)="changePageToNext($event)">Next</a>
                </li>
                <li class="page-item" [ngClass]="{'disabled': (isLastPage())}">
                    <a class="page-link" (click)="changePageToLast($event)">Last</a>
                </li>
                </ul>
            </nav>
            </div>
        `,
    styles: [`
        .pull-right {
            float: right;
        }
        .control-label {
            line-height: 35px;
        }   
        .centered {
            float: none;
            margin-left: auto!important;
            margin-right: auto!important;
        }
    `]
})
export class PaginatorComponent extends BaseComponent {
    @Input()
    public totalItems: number;
    @Input()
    public paginatorAndSorterInfo: PaginatorAndSorterInfo;
    @Input()
    public skipCount: number;
    @Output()
    public onPageChange: EventEmitter<PaginatorAndSorterInfo> = new EventEmitter();

    @Input()
    public currentPage: number;

    public pageLinks: number[];
    public fromItem: number;
    public toItem: number;
    public totalPages: number;

    public onChanges(): void {
        if (this.totalItems === undefined || this.totalItems === 0) {
            return;
        }

        if (this.skipCount === 0) {
            this.currentPage = 1;
            this.paginatorAndSorterInfo.skipCount = 0;
        } else {
            this.currentPage = this.paginatorAndSorterInfo.skipCount / this.paginatorAndSorterInfo.maxResultCount + 1;
        }

        this.totalPages =
            this.totalItems % this.paginatorAndSorterInfo.maxResultCount !== 0
                ? Math.floor(this.totalItems / this.paginatorAndSorterInfo.maxResultCount) + 1
                : this.totalItems / this.paginatorAndSorterInfo.maxResultCount;

        this.calculatePageItems();
        this.updatePageLinks();
    }

    public changePage(pageNumber: number, event: any): void {
        if (this.currentPage === pageNumber) {
            return;
        }

        this.currentPage = pageNumber;

        this.calculatePageItems();
        this.updatePageLinks();

        this.paginatorAndSorterInfo.skipCount = (this.currentPage - 1) * this.paginatorAndSorterInfo.maxResultCount;
        this.onPageChange.emit(this.paginatorAndSorterInfo);
        if (event) {
            event.preventDefault();
        }
    }

    public changePageToFirst(event: any): void {
        if (this.isFirstPage()) {
            return;
        }
        this.changePage(1, event);
    }

    public changePageToLast(event: any): void {
        if (this.isLastPage()) {
            return;
        }
        this.changePage(this.totalPages, event);
    }

    public changePageToNext(event: any): void {
        if (this.isLastPage()) {
            return;
        }
        this.changePage(this.getPage() + 1, event);
    }

    public changePageToPrev(event: any): void {
        if (this.isFirstPage()) {
            return;
        }
        this.changePage(this.getPage() - 1, event);
    }

    public calculatePageLinkBoundaries(): any {
        const pageLinkSize: number = 5;
        const numberOfPages: number = this.totalPages;
        const visiblePages: number = Math.min(pageLinkSize, numberOfPages);
        //calculate range, keep current in middle if necessary
        let start: number = Math.max(0, Math.ceil(this.getPage() - visiblePages / 2));
        const end: number = Math.min(numberOfPages - 1, start + visiblePages - 1);
        //check when approaching to last page
        const delta: number = pageLinkSize - (end - start + 1);
        start = Math.max(0, start - delta);

        return [start, end];
    }

    public updatePageLinks(): void {
        const boundaries: number[] = this.calculatePageLinkBoundaries();
        const start: number = boundaries[0];
        const end: number = boundaries[1];
        this.pageLinks = [];
        for (let i: number = start; i <= end; i++) {
            this.pageLinks.push(i + 1);
        }
    }

    public getPage(): number {
        return this.currentPage;
    }

    public isFirstPage(): boolean {
        return this.getPage() === 1;
    }

    public isLastPage(): boolean {
        return this.getPage() === this.totalPages;
    }

    public calculatePageItems(): void {
        const firstItemInPage = (this.currentPage - 1) * this.paginatorAndSorterInfo.maxResultCount;
        if (this.currentPage === this.totalPages) {
            this.fromItem = firstItemInPage + 1;
            this.toItem = firstItemInPage + (this.totalItems - firstItemInPage);
        } else {
            this.fromItem = firstItemInPage + 1;
            this.toItem = firstItemInPage + this.paginatorAndSorterInfo.maxResultCount;
        }
    }
}
