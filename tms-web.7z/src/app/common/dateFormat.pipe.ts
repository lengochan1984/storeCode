import { Pipe, PipeTransform } from '@angular/core';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

@Pipe({ name: 'UpsDateFormat' })
export class DateFormatPipe implements PipeTransform {
  public transform(date: any, isToDate?: boolean): any {
    let dateString: string;
    if (date) {
      if (date instanceof Date) {
        const year = date.getFullYear();
        const month = date.getMonth() + 1;
        const day = date.getDate();

        return { year: year, month: month, day: day };
      } else if (typeof date === 'object') {
        if (isToDate) {
          dateString = `${date.year}-${this.padLeft(date.month)}-${this.padLeft(date.day)}T23:59:59`;
        } else {
          dateString = `${date.year}-${this.padLeft(date.month)}-${this.padLeft(date.day)}T00:00:00`;
        }

        return new Date(dateString);
      } else if (typeof date === 'string') {
        const dateParts = date.trim().split('/');
        const year = +dateParts[2];
        const month = +dateParts[0];
        const day = +dateParts[1];

        return { year: year, month: month, day: day };
      }
    }
  }

  public getDefaultDate(): NgbDateStruct {
    let currentDate = new Date();
    let currentYear = currentDate.getFullYear();
    let currentMonth = currentDate.getMonth() + 1;
    let currentDay = currentDate.getDate();

    return { year: currentYear, month: currentMonth, day: currentDay };
  }

  public getFirstDateStruct(): NgbDateStruct {
    let currentDate = new Date();
    let currentYear = currentDate.getFullYear();
    let currentMonth = currentDate.getMonth() + 1;
    let currentDay = 1;

    return { year: currentYear, month: currentMonth, day: currentDay };
  }

  public getFirstDate(): Date {
    let currentDate = new Date();
    let currentYear = currentDate.getFullYear();
    let currentMonth = currentDate.getMonth();
    let currentDay = 1;

    return new Date(currentYear, currentMonth, currentDay);
  }

  private padLeft(numberPadLeft: number): string {
    return numberPadLeft < 10 ? `0${numberPadLeft}` : `${numberPadLeft}`;
  }

  public isValidDate(date) {
    return date && Object.prototype.toString.call(date) === "[object Date]" && !isNaN(date);
  }
}
