export interface PaginatorAndSorterInfo {
    maxResultCount: number;
    skipCount: number;
    sortColumn: string;
    sortMode: string;
  }
  