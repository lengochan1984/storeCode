import { Component, EventEmitter, Input, Output } from '@angular/core';

import { PaginatorAndSorterInfo } from '../common/PaginatorAndSorterInfo';
import { SortMode } from '../common/SortMode';

@Component({
  selector: 'table-sorter',
  template: `
      <a style="cursor: pointer;" (click)="sorting($event)">{{title}}
        <i class="fas {{sortIcon()}}"></i>
      </a>
    `
})
export class SorterComponent {

  @Input()
  public title: string;

  @Input()
  public orderColumn: string;

  @Input()
  public paginatorAndSorterInfo: PaginatorAndSorterInfo;

  @Output()
  public onSorting: EventEmitter<PaginatorAndSorterInfo> = new EventEmitter();

  public sorting(event: any): void {
    if (this.isNotSort()) {
      this.paginatorAndSorterInfo.sortMode = SortMode.Asc;
    } else if (this.isAscSort()) {
      this.paginatorAndSorterInfo.sortMode = SortMode.Desc;
    } else {
      this.paginatorAndSorterInfo.sortMode = SortMode.Asc;
    }
    this.paginatorAndSorterInfo.sortColumn = this.orderColumn;
    this.onSorting.emit(this.paginatorAndSorterInfo);
    if (event) {
      event.preventDefault();
    }
  }

  public isNotSort(): boolean {
    if (this.orderColumn !== this.paginatorAndSorterInfo.sortColumn) {
      return true;
    }

    return false;
  }

  public isAscSort(): boolean {
    if (
      this.orderColumn === this.paginatorAndSorterInfo.sortColumn &&
      this.paginatorAndSorterInfo.sortMode === SortMode.Asc
    ) {
      return true;
    }

    return false;
  }

  public isDescSort(): boolean {
    if (
      this.orderColumn === this.paginatorAndSorterInfo.sortColumn &&
      this.paginatorAndSorterInfo.sortMode === SortMode.Desc
    ) {
      return true;
    }

    return false;
  }

  public sortIcon(): string {
    if (!this.paginatorAndSorterInfo) {
      return 'fa-sort';
    }

    if (this.orderColumn !== this.paginatorAndSorterInfo.sortColumn) {
      return 'fa-sort';
    }

    if (
      this.orderColumn === this.paginatorAndSorterInfo.sortColumn &&
      this.paginatorAndSorterInfo.sortMode === SortMode.Asc
    ) {
      return 'fa-sort-up';
    }
    if (
      this.orderColumn === this.paginatorAndSorterInfo.sortColumn &&
      this.paginatorAndSorterInfo.sortMode === SortMode.Desc
    ) {
      return 'fa-sort-down';
    }

    return 'fa-sort';
  }
}
