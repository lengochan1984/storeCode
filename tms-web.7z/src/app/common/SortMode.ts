export enum SortMode {
    Asc = 'ASCENDING',
    Desc = 'DESCENDING'
  }