import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppConfig } from './app.config';

@Injectable()
export class UpsHttpClient {
  constructor(private http: HttpClient) {}

  public get(url: string, options?: any): Observable<any> {
    return this.http.get(this.createRequestUrl(url), options);
  }

  public post(url: string, data: any, options?: any): Observable<any> {
    return this.http.post(this.createRequestUrl(url), data, options);
  }

  public put(url: string, data: any, options?: any): Observable<any> {
    return this.http.put(this.createRequestUrl(url), data, options);
  }

  public delete(url: string, data?: any, options?: any): Observable<any> {
    return this.http.delete(this.createRequestUrl(url), options);
  }

  public createRequestUrl(url: string): string {
    
    return AppConfig.settings.apiUrl + url;
  }
}
