import { HttpErrorResponse } from "@angular/common/http";
import { Pipe } from "@angular/core";

@Pipe({ name: 'UpsCatchErrorService' })
export class CatchErrorService{
    public GetMessageError(err: Error): string{
        if (err instanceof HttpErrorResponse) {
            let errorMessage = 'Something went wrong while processing your request.';
            switch (err.status) {
              case 400:
                errorMessage = 'There is an error when processing your request.';
                break;
  
              case 401:
                errorMessage = 'The request has not been applied because it lacks valid authentication credentials for the target resource.'
                break;
  
              case 404:
                errorMessage = 'The page you are looking for cannot be found.';
                break;
  
              case 415:
                errorMessage = 'The selected file is valid!';
                break;
  
              case 500:
                errorMessage = `Error in response: ${err.message}`;
                break;
  
              case 0:
                errorMessage = `Error in response: ${err.message}`;
                break;
  
              default:
                break;
            }
            return `Error (${err.status}): ` + errorMessage;
          }
        return ""
    }
}