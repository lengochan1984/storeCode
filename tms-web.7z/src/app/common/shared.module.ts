import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserLoginService } from '../service/UserLoginService';
import { UpsHttpClient } from './UpsHttpClient';
import { LoaderService } from '../service/loader.service';
import { DateFormatPipe } from './dateFormat.pipe';
import { PaginatorComponent } from './paginator.component';
import { SorterComponent } from './sorter.component';
import { SearchDetailService } from '../service/searchDetailService';
import { SearchResolutionService } from '../service/searchResolutionService';
import { SearchResponseService } from '../service/searchResponseService';
import { SearchSummaryService } from '../service/searchSummaryService';
import { SearchAccountService } from '../service/searchAccountService';
import { SearchTotalTicketStatusService } from '../service/searchTotalTicketStatus.service';
import { CatchErrorService } from './catchErrorService';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  entryComponents: [],
  providers: [
    DateFormatPipe,
    LoaderService,
    UserLoginService,
    UpsHttpClient,
    SearchSummaryService,
    SearchDetailService,
    SearchResolutionService,
    SearchAccountService,
    SearchResponseService,
    SearchTotalTicketStatusService,
    CatchErrorService
  ],
  exports: [
    DateFormatPipe,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,    
    PaginatorComponent,
    SorterComponent,
    CatchErrorService
  ],
  declarations: [
    DateFormatPipe,    
    PaginatorComponent,
    SorterComponent,
    CatchErrorService
  ]
})
export class SharedModule {}
