import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoaderService } from '../service/loader.service';

export class RequestInterceptor implements HttpInterceptor {
    constructor(private loaderService: LoaderService) { }

    public intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.loaderService.emit(true);

        request = request.clone({
            setHeaders: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Cache-Control': 'no-cache, no-store',
                Pragma: 'no-cache',
                Expires: '-1'
            }
        });

        return next.handle(request);
    }
}
