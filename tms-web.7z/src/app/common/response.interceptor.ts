// tslint:disable:no-magic-numbers
import {
    HttpEvent,
    HttpHandler,
    HttpInterceptor,
    HttpRequest,
    HttpResponse,
    HttpErrorResponse,
} from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { LoaderService } from '../service/loader.service';

export class ResponseInterceptor implements HttpInterceptor {
    constructor(
        private router: Router,
        private loaderService: LoaderService,
    ) { }

    public intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(
          map((event: HttpEvent<any>) => {
            if (event instanceof HttpResponse) {
              const bodyData = event.body.data;
    
              event = event.clone({
                body: bodyData
              });
            }
    
            return event;
          })
        );
    }
}
