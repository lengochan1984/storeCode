import { AfterViewInit, OnChanges, OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

export abstract class BaseComponent implements OnChanges, OnInit, OnDestroy, AfterViewInit {
  public form: FormGroup;

  public ngOnChanges(): void {
    this.onChanges();
  }

  public ngOnInit(): void {
    this.onInit();
  }

  public ngOnDestroy(): void {
    this.onDestroy();
  }

  public ngAfterViewInit(): void {
    this.afterViewInit();
  }

  protected onInit(): void {
    this.initForm();
    this.initVariables();
    this.initMaster();

  }

  protected onChanges(): void {
    // Virtual method
  }

  protected onDestroy(): void {
    // Virtual method
  }

  protected afterViewInit(): void {
    // Virtual method
  }

  protected initForm(): void {
    // Virtual method
  }

  protected initVariables(): void {
    // Virtual method
  }

  protected initMaster(): void {
    // Virtual method
  }

  protected markFormDirty(): void {
    if (this.form) {
      Object.keys(this.form.controls).forEach(key => {
        if (!this.form.controls[key].dirty) {
          this.form.controls[key].markAsDirty();
          this.form.controls[key].updateValueAndValidity();
        }
      });
    }
  }

  protected disableControl(listControl?: string[]): void {
    if (listControl) {
      listControl.forEach(control => {
        this.form.controls[control].disable();
      });

      return;
    }

    Object.keys(this.form.controls).forEach(key => {
      this.form.controls[key].disable();
    });
  }

  protected enableControl(listControl?: string[]): void {
    if (listControl) {
      listControl.forEach(control => {
        this.form.controls[control].enable();
      });

      return;
    }

    Object.keys(this.form.controls).forEach(key => {
      this.form.controls[key].enable();
    });
  }
}
