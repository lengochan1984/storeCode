import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../common/base.component';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { UserLoginService } from '../service/UserLoginService';
import { UserLoginInput } from '../Dtos/userLoginInput';
import { UserLoginOutput } from '../Dtos/userLoginOutput';
import { CatchErrorService } from "../common/catchErrorService";

declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent extends BaseComponent {
  public form: FormGroup;
  private userLoginInput: UserLoginInput;
  loading = false;
  submitted = false;
  returnUrl: string;
  checkLogin = false;
  public messageErr: string = "";

  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    public router: Router,
    private userLoginService: UserLoginService,
    private catchErrorService: CatchErrorService,
    ) {
    super();
  }

  ngOnInit() {

    $(function() {
        $(".preloader").fadeOut();
    });
    super.ngOnInit();
    this.initForm();

    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';

    // reset login status
    this.logout();


  }

  public checkRemember(): void {

    if ($('#checkbox-signup').is(':checked')) {
      // save username and password
        localStorage.username = $('#signinId').val();
        localStorage.pass = $('#signinPwd').val();
        localStorage.chkbox = $('#checkbox-signup').val();
    } else {
        localStorage.username = '';
        localStorage.pass = '';
        localStorage.chkbox = '';
    }
  }
  public initForm(): void {
    
    
    if (localStorage.chkbox && localStorage.chkbox != '') {
        $('#checkbox-signup').attr('checked', 'checked');
        this.form = this.formBuilder.group({
          userName: [localStorage.username, Validators.required],
          passWord: [localStorage.pass, Validators.required]
        });
    } else {
      $('#checkbox-signup').removeAttr('checked');
      this.form = this.formBuilder.group({
        userName: ["", Validators.required],
        passWord: ["", Validators.required]
      });
      
    }
  }

  get f() { return this.form.controls; }

  public login(): void {
    this.checkRemember();
    this.markFormDirty();
    this.submitted = true;
    if (this.form.invalid) {
      return;
    }
    this.userLoginInput = this.form.value;
  
    this.userLoginService.login(this.userLoginInput)
    .subscribe(
      data => {
        //this.userInfoInput.userId = "10018";
        this.userLoginInput.userId = JSON.parse(JSON.stringify(data));
        this.userLoginService.GetUserInformation(this.userLoginInput)
        .subscribe(
          data => {
            localStorage.setItem('currentUser', JSON.stringify(data));
            if(this.returnUrl === "" || this.returnUrl === "/") {
              this.returnUrl = "dashboard";
            }
            this.router.navigate([this.returnUrl]);
          });
        
      },
      error => {
          if (error.status == 404) {
            this.messageErr = "Login Fail";
          } else {
            this.messageErr = "500 Internal Server Error";
          }
          
      }
      )
  }

  logout() {
      // remove user from local storage to log user out
      localStorage.removeItem('currentUser');
      
  }
}
