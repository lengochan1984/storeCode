import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { ResponseTimeComponent } from '../response-time/response-time.component';
import { ResolutionTimeComponent } from '../resolution-time/resolution-time.component';
import { DetailSummaryComponent } from '../detailSummary/detail-summary.component';
import { SummaryComponent } from '../summary/summary.component';
import { AccountManagerComponent } from '../account-manager/account-manager.component';
import { TicketStatusReportComponent } from '../ticket-status-report/ticket-status-report.component';

const dashboardRoutes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    children: [
      {
        path: '',
        redirectTo:"statusReport"
      },
      {
        path: "statusReport",
        component: TicketStatusReportComponent
      },
      {
        path: 'summary',
        component: SummaryComponent
      },  
      { 
        path: 'detailSunmary',
        component: DetailSummaryComponent
      },
      {
        path: 'responseTime',
        component: ResponseTimeComponent
      },
      {
        path: 'resolutionTime',
        component: ResolutionTimeComponent
      },
	  {
        path: 'accountManager',
        component: AccountManagerComponent
      }
      
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(dashboardRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class DashboardRoutingModule { }