import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { LoaderService } from '../service/loader.service';
import { Router } from '@angular/router';
import { Data } from '../common/data-storage';
import { UserLoginInput } from '../Dtos/userLoginInput';
import { UserLoginOutput } from '../Dtos/userLoginOutput';
import { UserLoginService } from '../service/UserLoginService';
import { ValidatorHelper  } from '../common/validator-helper';
import { Validators } from '@angular/forms';

declare var jquery: any;
declare var $;

@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.html'
})
export class DashboardComponent implements OnInit {
  public blocked: boolean;
  public nameUser:String;
  private userLoginInput: UserLoginInput;
  private userLoginOutput : UserLoginOutput[];

  constructor(
    public router: Router,
    private loaderService: LoaderService,
    private data: Data,
    private userLoginService: UserLoginService,
  ) {
    
  }

  public ngOnInit(): void {
    Validators.minLength = ValidatorHelper.minLength;
    
    if (this.ckLogin()) {
      $.getScript("../../assets/js/custom.min.js", function () {});
    
      this.nameUser = JSON.parse(localStorage.getItem('currentUser')).displayName;
  
      this.loaderService.loader().subscribe(state => {
        this.blocked = state;
        // To avoid issue: AppComponent.html:167 ERROR Error: ExpressionChangedAfterItHasBeenCheckedError:
        // Expression has changed after it was checked. Previous value: 'ngIf: false'. Current value: 'ngIf: true'.
        //this.cdRef.detectChanges();
      });
    };
    
  }

  public logout(): void {
    
    localStorage.removeItem('currentUser');
    // not logged in so redirect to login page with the return url
    this.router.navigate(['/login'], { queryParams: { returnUrl: "" }});
    
  }
  public clearData(): void {
    this.data.storage = undefined;
  }

  protected ckLogin(): any {
    
    if (this.router.url != '/login'){

      
      if (localStorage.getItem('currentUser')) {
        this.userLoginInput = {} as UserLoginInput; 
        this.userLoginOutput = [] as UserLoginOutput[];
         this.userLoginInput.userId = JSON.parse(localStorage.getItem('currentUser')).userId;

         this.userLoginService.GetUserInformation(this.userLoginInput)
        .subscribe(
          data => {
          },
          error => {
            localStorage.removeItem('currentUser');
            this.router.navigate(['/login'], { queryParams: { returnUrl: "" }});
            return false;
            
        },
          );

      }else {
      // not logged in so redirect to login page with the return url
      this.router.navigate(['/login'], { queryParams: { returnUrl: "" }});
      return false;
      }
    }
    return true;

  }
}
