import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { SharedModule } from '../common/shared.module';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { RequestInterceptor } from '../common/request.interceptor';
import { LoaderService } from '../service/loader.service';
import { ResponseInterceptor } from '../common/response.interceptor';
import { ResponseTimeComponent } from '../response-time/response-time.component';
import { ResolutionTimeComponent } from '../resolution-time/resolution-time.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { DetailSummaryComponent } from '../detailSummary/detail-summary.component';
import { SearchDetailComponent } from '../detailSummary/search-detail-summary/search-detail-summary.component';
import { ListSearchDetailComponent } from '../detailSummary/list-detail-summary/list-detail-summary.component';
import { SearchResolutionComponent } from '../resolution-time/searchResolution/search-resolution.component';
import { ListSearchResolutionComponent } from '../resolution-time/listResolution/list-search-resolution.component';
import { SearchResponseComponent } from '../response-time/searchResponse/search-response.component';
import { ListSearchResponseComponent } from '../response-time/listResponse/list-search-response.component';
import { DashboardComponent } from './dashboard.component';
import { SummaryComponent } from '../summary/summary.component';
import { SearchSummaryComponent } from '../summary/searchSummary/search-summary.component';
import { ListSearchSummaryComponent } from '../summary/listSummary/list-search-summary.component';
import { TicketStatusReportModule } from '../ticket-status-report/ticket-status-report.module';

import { AccountManagerComponent } from '../account-manager/account-manager.component';
import { ListSearchAccountComponent } from '../account-manager/listAccount/list-search-account.component';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        DashboardRoutingModule,
        NgbModule,
        TicketStatusReportModule,
    ],
    declarations: [
        DashboardComponent,
        SummaryComponent,
        ResponseTimeComponent,
        ResolutionTimeComponent,
        SearchSummaryComponent,
        ListSearchSummaryComponent,
        
        DetailSummaryComponent,
        SearchDetailComponent,
        ListSearchDetailComponent,
        SearchResolutionComponent,
        ListSearchResolutionComponent,
        SearchResponseComponent,
        ListSearchResponseComponent,
		AccountManagerComponent,
    ListSearchAccountComponent
    ],
    providers: [
        {
          provide: HTTP_INTERCEPTORS,
          useClass: RequestInterceptor,
          multi: true,
          deps: [LoaderService]
        },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: ResponseInterceptor,
          multi: true,
          deps: [LoaderService]
        },
      ],
})
export class DashboarModule { }