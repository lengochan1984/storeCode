﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Options;
using UPS_APP.Entities;

namespace UPS_APP.Config 
{
    public partial class UPSDBContext : DbContext
    {
        public UPSDBContext()
        {
        }

        private readonly ConnectConfiguration tableConf;

    
        public UPSDBContext(DbContextOptions<UPSDBContext> options, IOptions<ConnectConfiguration> tableConf)
            : base(options)
        {
            this.tableConf = tableConf.Value;
        }
        public virtual DbSet<Account> Account { get; set; }
        public virtual DbSet<Issues> Issues { get; set; }
        public virtual DbSet<IssueSubTypes> IssueSubTypes { get; set; }
        public virtual DbSet<IssueSubTypes2> IssueSubTypes2 { get; set; }
        public virtual DbSet<IssueTypes> IssueTypes { get; set; }
        public virtual DbSet<Notes> Notes { get; set; }
        public virtual DbSet<ServiceLevelIssues> ServiceLevelIssues { get; set; }
        public virtual DbSet<ServiceLevelSeverities> ServiceLevelSeverities { get; set; }
        public virtual DbSet<Status> Status { get; set; }
        public virtual DbSet<SubStatus> SubStatus { get; set; }
        public virtual DbSet<UsersInfo> UsersInfo { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                var connection = this.tableConf.DefaultConnection;
                optionsBuilder.UseSqlServer(connection);
                // optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=UPSDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Account>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.Property(e => e.UserId)
                    .HasColumnName("UserID")
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.DisplayName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<Issues>(entity =>
            {
                entity.HasKey(e => e.IssueNbrId);

                entity.Property(e => e.IssueNbrId)
                    .HasColumnName("IssueNbrID")
                    .ValueGeneratedNever();

                entity.Property(e => e.ActivityById)
                    .HasColumnName("ActivityByID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ActivityDate).HasColumnType("datetime");

                entity.Property(e => e.AssignedDate).HasColumnType("datetime");

                entity.Property(e => e.AssignedTo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClosedById)
                    .HasColumnName("ClosedByID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClosedDate).HasColumnType("datetime");

                entity.Property(e => e.GlobalId).HasColumnName("GlobalID");

                entity.Property(e => e.IssueDescription)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.IssueSolution)
                    .HasMaxLength(4000)
                    .IsUnicode(false);

                entity.Property(e => e.IssueSubType2Id).HasColumnName("IssueSubType2ID");

                entity.Property(e => e.IssueSubTypeId).HasColumnName("IssueSubTypeID");

                entity.Property(e => e.IssueTypeId).HasColumnName("IssueTypeID");

                entity.Property(e => e.NextActionByDate).HasColumnType("datetime");

                entity.Property(e => e.NextActionById)
                    .HasColumnName("NextActionByID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReopenedById)
                    .HasColumnName("ReopenedByID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReopenedDate).HasColumnType("datetime");

                entity.Property(e => e.RequiredByDate).HasColumnType("datetime");

                entity.Property(e => e.StatusId).HasColumnName("StatusID");

                entity.Property(e => e.SubStatusId).HasColumnName("SubStatusID");

                entity.Property(e => e.SubmittedById)
                    .HasColumnName("SubmittedByID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SubmittedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<IssueSubTypes>(entity =>
            {
                entity.HasKey(e => e.IssueSubTypeId);

                entity.Property(e => e.IssueSubTypeId)
                    .HasColumnName("IssueSubTypeID")
                    .ValueGeneratedNever();

                entity.Property(e => e.IssueSubType2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IssueTypeId).HasColumnName("IssueTypeID");
            });

            modelBuilder.Entity<IssueSubTypes2>(entity =>
            {
                entity.HasKey(e => e.IssueSubType2Id);

                entity.Property(e => e.IssueSubType2Id)
                    .HasColumnName("IssueSubType2ID")
                    .ValueGeneratedNever();

                entity.Property(e => e.IssueSubType2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ParentId).HasColumnName("ParentID");
            });

            modelBuilder.Entity<IssueTypes>(entity =>
            {
                entity.HasKey(e => e.IssueTypeId);

                entity.Property(e => e.IssueTypeId)
                    .HasColumnName("IssueTypeID")
                    .ValueGeneratedNever();

                entity.Property(e => e.IssueType)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Notes>(entity =>
            {
                entity.HasKey(e => e.NoteId);

                entity.Property(e => e.NoteId)
                    .HasColumnName("NoteID")
                    .ValueGeneratedNever();

                entity.Property(e => e.CreatedById)
                    .HasColumnName("CreatedByID")
                    .HasMaxLength(55)
                    .IsUnicode(false);

                entity.Property(e => e.IssueNbrId).HasColumnName("IssueNbrID");

                entity.Property(e => e.ModifiedById)
                    .HasColumnName("ModifiedByID")
                    .HasMaxLength(55)
                    .IsUnicode(false);

                entity.Property(e => e.NoteCreatedDate).HasColumnType("datetime");

                entity.Property(e => e.NoteModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.NoteText)
                    .HasMaxLength(7000)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ServiceLevelIssues>(entity =>
            {
                entity.HasKey(e => e.IssueNbrID);

                entity.Property(e => e.IssueNbrID)
                    .HasColumnName("IssueNbrID")
                    .ValueGeneratedNever();

                entity.Property(e => e.SeverityID).HasColumnName("SeverityID");
            });

            modelBuilder.Entity<ServiceLevelSeverities>(entity =>
            {
                entity.HasKey(e => e.SeverityId);

                entity.Property(e => e.SeverityId)
                    .HasColumnName("SeverityID")
                    .ValueGeneratedNever();

                entity.Property(e => e.Severity)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Status>(entity =>
            {
                entity.Property(e => e.StatusId)
                    .HasColumnName("StatusID")
                    .ValueGeneratedNever();

                entity.Property(e => e.StatusName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SubStatus>(entity =>
            {
                entity.Property(e => e.SubStatusId)
                    .HasColumnName("SubStatusID")
                    .ValueGeneratedNever();

                entity.Property(e => e.SubStatus1)
                    .HasColumnName("SubStatus")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<UsersInfo>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.ToTable("Users_Info");

                entity.Property(e => e.UserId)
                    .HasColumnName("UserID")
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.DisplayName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });
        }
    }
}
