﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UPS_APP.Services;
using UPS_APP.Services.Abstractions;

namespace UPS_APP.Config
{
    public static class UpsServiceConfiguration
    {
        public static IServiceCollection AddUpsServices(this IServiceCollection services)
        {
            // Common services

            services.AddTransient<ISummaryService, SummaryService>();
            services.AddTransient<IReSolutionService, ReSolutionService>();
            services.AddTransient<IResponseService, ResponseService>();
            services.AddTransient<ILoginService, LoginService>();
            services.AddTransient<IDetailSummaryService, DetailSummaryService>();
            services.AddTransient<IReportService, ReportService>();
            services.AddTransient<IUserService , UserService>();
            return services;
        }
    }
}
