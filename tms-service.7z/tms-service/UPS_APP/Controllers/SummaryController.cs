﻿
using Microsoft.AspNetCore.Mvc;
using System;
using Ups.Import2K.WebApi.Controllers;
using UPS_APP.Dtos;
using UPS_APP.Services.Abstractions;

namespace UPS_APP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class SummaryController : BaseController
    {
        private readonly ISummaryService _summaryService;
        public SummaryController(ISummaryService summaryService)
        {
            _summaryService = summaryService;
        }

        [HttpPost("Search")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult Search(SearchSumaryInput input)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var data = _summaryService.Search(input);
                if (data != null && data.TotalCount > 0)
                {
                    return Json(data);
                }
                // return NotFound();
                return Json(data);

            }
            catch (Exception ex)
            {

                return StatusCode(500);
            }
        }

    }
}
