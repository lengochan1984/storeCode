﻿
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using Ups.Import2K.WebApi.Controllers;
using UPS_APP.Dtos;
using UPS_APP.Services.Abstractions;

namespace UPS_APP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : BaseController
    {
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }


        [HttpPost("Search")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult Search(UserSearchInput input)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var data = _userService.Search(input);
                if (data != null && data.TotalCount > 0)
                {
                    return Json(data);
                }
                // return NotFound();
                return Json(data);

            }
            catch (Exception ex)
            {

                return StatusCode(500);
            }
        }

        [HttpPost("deleteUser")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult deleteUser(UserInfoInput input)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var data = _userService.deleteUser(input);

                // return NotFound();
                return Json(data);

            }
            catch (Exception ex)
            {

                return StatusCode(500);
            }
        }
        [HttpPost("updateUser")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult updateUser(UserAddInput input)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var data = _userService.updateUser(input);

                // return NotFound();
                return Json(data);

            }
            catch (Exception ex)
            {

                return StatusCode(500);
            }
        }
        [HttpPost("insertUser")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult insertUser(UserAddInput input)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var data = _userService.insertUser(input);

                // return NotFound();
                return Json(data);

            }
            catch (Exception ex)
            {

                return StatusCode(500);
            }
        }

        [HttpPost("UserDetail")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult GetUserDetail(UserInfoInput user)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                UserDetailOutput userDetail = new UserDetailOutput();

                userDetail = _userService.GetUserDetail(user);
                if (userDetail != null)
                {
                    return Ok(userDetail);
                }
                return null ;
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }
    }
}
