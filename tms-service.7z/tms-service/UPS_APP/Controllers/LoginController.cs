﻿
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using Ups.Import2K.WebApi.Controllers;
using UPS_APP.Dtos;
using UPS_APP.Services.Abstractions;

namespace UPS_APP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : BaseController
    {
        private readonly ILoginService _loginService;
        public LoginController(ILoginService loginService)
        {
            _loginService = loginService;
        }

        [HttpPost("CheckLogin")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult CheckLogin(UserLoginInput user)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var data = _loginService.CheckLogin(user);
                if (!string.IsNullOrEmpty(data))
                {
                    return Json(data);
                }
                else
                {
                    //return Json(data);
                    // return NotFound();
                    return NotFound();
                }
            }
            catch (Exception ex)
            {

                return StatusCode(500);
            }

        }

        [HttpPost("UserInformation")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult GetUserInformation(UserInfoInput user)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                UserInfoOutput userInfoOutput = new UserInfoOutput();

                userInfoOutput = _loginService.GetUserInformation(user);
                if (!string.IsNullOrEmpty(userInfoOutput.UserId))
                {
                    return Ok(userInfoOutput);
                }
                return NotFound();
            }
            catch (Exception ex)
            {

                return StatusCode(500);
            }
        }



    }
}
