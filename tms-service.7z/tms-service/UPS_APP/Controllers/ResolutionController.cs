﻿
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Ups.Import2K.WebApi.Controllers;
using UPS_APP.Dtos;
using UPS_APP.Services.Abstractions;

namespace UPS_APP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResolutionController : BaseController
    {
        private readonly IReSolutionService _reSolutionService;
        public ResolutionController(IReSolutionService reSolutionService)
        {
            _reSolutionService = reSolutionService;
        }

        [HttpPost("SearchResolution")]
        public IActionResult SearchResolution(SearchResolutionInput input)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var data = _reSolutionService.SearchResolution(input);
                if (data != null && data.TotalCount > 0)
                {
                    return Json(data);
                }
                return Json(data);
               // return NotFound();

            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

    }
}
