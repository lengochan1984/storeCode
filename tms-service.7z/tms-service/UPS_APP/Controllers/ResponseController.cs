﻿
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Ups.Import2K.WebApi.Controllers;
using UPS_APP.Dtos;
using UPS_APP.Services.Abstractions;

namespace UPS_APP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResponseController : BaseController
    {
        private readonly IResponseService _responseService;
        public ResponseController(IResponseService responseService)
        {
            _responseService = responseService;
        }


        [HttpPost("SearchResponse")]
        public IActionResult SearchResponse(SearchResponseInput input)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var data = _responseService.SearchResponse(input);
                if (data != null && data.TotalCount > 0)
                {
                    return Json(data);
                }
                return Json(data);
                // return NotFound();

            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }



    }
}
