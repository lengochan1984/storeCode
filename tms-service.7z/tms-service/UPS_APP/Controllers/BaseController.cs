﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using UPS_APP.Common;

namespace Ups.Import2K.WebApi.Controllers
{
    [EnableCors("CorsPolicy")]
    public class BaseController : Controller
    {
        public override JsonResult Json(object data)
        {
            return new JsonResult(new ResponseModel
            {
                Data = data
            });
        }
    }
}
