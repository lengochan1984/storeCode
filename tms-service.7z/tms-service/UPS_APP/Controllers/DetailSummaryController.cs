﻿
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Ups.Import2K.WebApi.Controllers;
using UPS_APP.Dtos;
using UPS_APP.Services.Abstractions;

namespace UPS_APP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DetailSummaryController : BaseController
    {
        private readonly IDetailSummaryService _detailService;
        public DetailSummaryController(IDetailSummaryService detailService)
        {
            _detailService = detailService;
        }

        [HttpPost("GetTicketsummaryrecorddetail")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult GetTicketsummaryrecorddetail(ViewSumaryDetailInput viewSumaryDetailInput)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var data = _detailService.GetTicketsummaryrecorddetail(viewSumaryDetailInput);
                if (data != null && data.TotalCount > 0)
                {
                    return Json(data);
                }
                return Json(data);
                //return NotFound();
            }
            catch (Exception ex)
            {

                return StatusCode(500);
            }
        }
    }
}
