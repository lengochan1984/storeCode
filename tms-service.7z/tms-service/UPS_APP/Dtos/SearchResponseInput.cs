﻿using System;

namespace UPS_APP.Dtos
{
    public class SearchResponseInput : IPagedResultRequest, ISortedResultRequest
    {
        public string userId { get; set; }

        public int status { get; set; }

        public DateTime? submittedFrom { get; set; }

        public DateTime? submittedTo { get; set; }

        public string assignedTo { get; set; }

        public string isResponsed { get; set; }

        public int MaxResultCount { get; set; }

        public int SkipCount { get; set; }

        public string Sorting { get; set; }
    }
}
