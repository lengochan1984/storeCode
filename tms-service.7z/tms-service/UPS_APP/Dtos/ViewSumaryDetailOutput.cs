﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UPS_APP.Dtos
{
    public class ViewSumaryDetailOutput
    {
        public string UserId { get; set; }
        public string UserName{ get; set; }
        public int? GroupId { get; set; }

        public int SOId { get; set; }
        public string Subject { get; set; }
        public string Severity { get; set; }
    }
}
