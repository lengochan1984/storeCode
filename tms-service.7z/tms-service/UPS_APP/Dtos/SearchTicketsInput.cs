﻿using System;

namespace UPS_APP.Dtos
{
    public class SearchTicketsInput : IPagedResultRequest, ISortedResultRequest
    {
        public string inputSearch { get; set; }

        public string type { get; set; }

        public int MaxResultCount { get; set; }

        public int SkipCount { get; set; }

        public string Sorting { get; set; }
    }
}
