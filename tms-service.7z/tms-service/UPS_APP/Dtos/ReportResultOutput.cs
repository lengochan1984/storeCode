﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UPS_APP.Dtos
{
    public class ReportResultOutput
    {
        public ReportOutput totalHeaderTicket { get; set; }
        public List<ReportOutput> totalTicketByPic { get; set; }

    }
}
