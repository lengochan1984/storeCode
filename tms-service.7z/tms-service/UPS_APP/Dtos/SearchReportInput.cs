﻿using System;

namespace UPS_APP.Dtos
{
    public class SearchReportInput : IPagedResultRequest, ISortedResultRequest
    {

        public int MaxResultCount { get; set; }

        public int SkipCount { get; set; }

        public string Sorting { get; set; }
    }
}
