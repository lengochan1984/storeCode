﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UPS_APP.Dtos
{
    public class UserLoginInput
    {
        public string userName { get; set; }

        public string password { get; set; }
    }
}
