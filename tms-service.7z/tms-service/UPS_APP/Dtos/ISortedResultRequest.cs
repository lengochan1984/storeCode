﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UPS_APP.Dtos
{
    public interface ISortedResultRequest
    {
        string Sorting { get; set; }
    }
}
