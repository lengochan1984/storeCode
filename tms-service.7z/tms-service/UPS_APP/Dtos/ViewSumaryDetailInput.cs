﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace UPS_APP.Dtos
{
    public class ViewSumaryDetailInput : IPagedResultRequest, ISortedResultRequest
    {
        [Required]
        public string userId { get; set; }
        [Required]
        public int status { get; set; }

        public string type { get; set; }

        public DateTime? submittedFrom { get; set; }

        public DateTime? submittedTo { get; set; }

        public int MaxResultCount { get; set; }

        public int SkipCount { get; set; }

        public string Sorting { get; set; }
    }
}
