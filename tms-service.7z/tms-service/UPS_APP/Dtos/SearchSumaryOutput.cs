﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UPS_APP.Dtos
{
    public class SearchSumaryOutput
    {
        public string userId { get; set; }

        public string pic { get; set; }

        public int sls { get; set; }

        public int tls { get; set; }

        public int hwsw { get; set; }

        public int systemGeneratedAlerts { get; set; }

        public int total { get; set; }

    }
}
