﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UPS_APP.Dtos
{
    public class ReportOutput
    {
        public string pic { get; set; }

        public int totalOpen { get; set; }
        
        public int totalResp { get; set; }

        public int noAction { get; set; }

        public int totalImpl { get; set; }

        public int totalLate { get; set; }

        public int totalBeLate { get; set; }

        public int totalRespLate { get; set; }

        public int totalRespBeLate { get; set; }

        public int totalImplLate { get; set; }

        public int totalImplBeLate { get; set; }
    }
}
