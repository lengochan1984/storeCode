﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UPS_APP.Dtos;

namespace UPS_APP.Services.Abstractions
{
    public interface ILoginService
    {
        string CheckLogin(UserLoginInput input);

        UserInfoOutput GetUserInformation(UserInfoInput input);
    }
}
