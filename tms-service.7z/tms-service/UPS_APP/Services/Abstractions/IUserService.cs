﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UPS_APP.Dtos;

namespace UPS_APP.Services.Abstractions
{
    public interface IUserService
    {
        PagedResultDto<dynamic> Search(UserSearchInput input);
        bool deleteUser(UserInfoInput input);
        bool updateUser(UserAddInput input);
        bool insertUser(UserAddInput input);
        UserDetailOutput GetUserDetail(UserInfoInput input);
    }
}
