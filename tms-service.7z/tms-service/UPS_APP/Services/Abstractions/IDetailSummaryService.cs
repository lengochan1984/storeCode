﻿using UPS_APP.Dtos;

namespace UPS_APP.Services.Abstractions
{
    public interface IDetailSummaryService
    {
        PagedResultDto<dynamic> GetTicketsummaryrecorddetail(ViewSumaryDetailInput input);
    }
}
