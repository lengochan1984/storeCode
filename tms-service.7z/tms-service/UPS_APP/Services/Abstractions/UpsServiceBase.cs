﻿using System.Linq;
using System.Linq.Dynamic.Core;
using UPS_APP.Common;
using UPS_APP.Dtos;

namespace Ups.Import2K.Services.Services.Abstractions
{
    public abstract class UpsServiceBase
    {
        /// <summary>
        /// Should apply sorting if needed.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="input">The input.</param>
        /// <param name="defaultSortCriteria">The criteria is the combination of column name and ASCENDING/DESCENDING. Example: Id DESCENDING</param>
        protected virtual IQueryable<TEntity> ApplySorting<TEntity, TInput>(IQueryable<TEntity> query, TInput input,
            string defaultSortCriteria = "Id DESCENDING") where TEntity : class
        {
            // Try to sort query if available
            if (input is ISortedResultRequest sortInput)
            {
                return query.OrderBy(!string.IsNullOrEmpty(sortInput.Sorting) ? sortInput.Sorting : defaultSortCriteria);
            }

            // IQueryable.Take requires sorting, so we should sort if Take will be used.
            if (input is ILimitedResultRequest)
            {
                // This will throw exception if there is no Id column in entity class
                // This will happened with PiManagement table because this table doesn't have Id column
                return query.OrderBy(defaultSortCriteria);
            }

            // No sorting
            return query;
        }

        /// <summary>
        /// Should apply paging if needed.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="input">The input.</param>
        protected virtual IQueryable<TEntity> ApplyPaging<TEntity, TInput>(IQueryable<TEntity> query, TInput input)
            where TEntity : class
        {
            // Try to use paging if available
            if (input is IPagedResultRequest pagedInput)
            {
                return query.PageBy(pagedInput);
            }

            // Try to limit query result if available
            if (input is ILimitedResultRequest limitedInput)
            {
                return query.Take(limitedInput.MaxResultCount);
            }

            // No paging
            return query;
        }
    }
}
