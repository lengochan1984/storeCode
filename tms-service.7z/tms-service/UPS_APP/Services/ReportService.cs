﻿using System;
using System.Collections.Generic;
using System.Linq;
using Ups.Import2K.Services.Services.Abstractions;
using UPS_APP.Common;
using UPS_APP.Config;
using UPS_APP.Dtos;
using UPS_APP.Services.Abstractions;
using System.Data;

namespace UPS_APP.Services
{
    public class ReportService : UpsServiceBase, IReportService
    {

        private readonly UPSDBContext _db;

        public ReportService(UPSDBContext db)
        {
            _db = db;
        }

        public ReportResultOutput SearchReport(SearchReportInput input)
        {
            try
            {
                DateTime time = DateTime.Now; // Or whatever

                // Get record NextActionById exist in user
                var queryJoin = from issues in _db.Issues
                                join user in _db.UsersInfo on issues.NextActionById equals user.UserId
                                join subStatus in _db.SubStatus on issues.SubStatusId equals subStatus.SubStatusId
                                join serviceLevelIssues in _db.ServiceLevelIssues on issues.IssueNbrId equals serviceLevelIssues.IssueNbrID
                                join serviceLevelSeverities in _db.ServiceLevelSeverities on serviceLevelIssues.SeverityID equals serviceLevelSeverities.SeverityId
                                join notes in _db.Notes on issues.IssueNbrId equals notes.IssueNbrId into tmpNotes
                                from notes in tmpNotes.DefaultIfEmpty()
                                where !string.IsNullOrEmpty(issues.NextActionById) && (issues.StatusId == true) && (notes.FirstNote == true)
                                select new { issues, user, serviceLevelIssues, serviceLevelSeverities, notes, subStatus };

                //Query data 
                var result = from query in queryJoin
                             select new
                             {
                                 //NoteId = query.notes.NoteId,
                                 NextActionById = query.issues.NextActionById,
                                 pic = query.user.DisplayName,
                                 isResp = (query.notes.NoteId > 0 && (!"Resolved".Equals(query.subStatus.SubStatus1))) ? "Yes" : "No",
                                 isImplemented = ("Resolved".Equals(query.subStatus.SubStatus1)) ? "Yes" : "No",
                                 noAction = ((query.notes.NoteId == 0) && !"Resolved".Equals(query.subStatus.SubStatus1)) ? "Yes" : "No",

                                 respondLate =
                                 ((!string.IsNullOrEmpty(query.notes.NoteId.ToString())  && query.serviceLevelSeverities.ResponseTime.HasValue ) || (!"Resolved".Equals(query.subStatus.SubStatus1 ) && query.serviceLevelSeverities.ResponseTime.HasValue))  ?
                                            (

                                                 ((Convert.ToDateTime(query.notes.NoteCreatedDate.Value)).Subtract(Convert.ToDateTime(query.issues.SubmittedDate.Value)).TotalMinutes
                                                 > (query.serviceLevelSeverities.ResponseTime ?? 0) ? "late" : "Not Yet")

                                            )
                                            : "Not Yet",

                                 resolveLate = query.issues.ClosedDate.HasValue  && query.serviceLevelSeverities.ResolutionTime.HasValue ?
                                            (


                                                 ((query.issues.ClosedDate.Value).Subtract(query.issues.SubmittedDate.Value).TotalMinutes > query.serviceLevelSeverities.ResolutionTime ? "late" : "Not Yet")
                                            )

                                              : query.serviceLevelSeverities.ResolutionTime.HasValue ?(
                                                 ((time).Subtract(query.issues.SubmittedDate.Value).TotalMinutes > query.serviceLevelSeverities.ResponseTime ? "late" : "Not Yet")
                                            ) : "Not Yet",

                                 //resolveLate = (query.issues.ClosedDate.HasValue &&query.serviceLevelSeverities.ResolutionTime.HasValue) ?
                                 //           (
                                 //                ((query.issues.ClosedDate.Value).Subtract(query.issues.SubmittedDate.Value).TotalMinutes > (query.serviceLevelSeverities.ResolutionTime ?? 0) ? "late" : "Not Yet")
                                 //           )
                                 //           : "Not Yet",//totalImplLate
                                 respBeLate = ((query.serviceLevelSeverities.ResponseTime ?? 0) > 0 && !"Resolved".Equals(query.subStatus.SubStatus1) ) ?
                                            (
                                             ((time.Subtract(query.issues.SubmittedDate.Value).TotalMinutes > (3 * Convert.ToInt32(query.serviceLevelSeverities.ResponseTime)) / 4) && (time.Subtract(query.issues.SubmittedDate.Value).TotalMinutes <= Convert.ToInt32(query.serviceLevelSeverities.ResponseTime ?? 0)) ? "late" : "Not Yet")
                                                )
                                            : "Not Yet",
                                 implBeLate = ((query.serviceLevelSeverities.ResolutionTime ?? 0) > 0 && query.issues.ClosedDate.HasValue) ?
                                            (
                                             ((time.Subtract(query.issues.SubmittedDate.Value).TotalMinutes > (3 * Convert.ToInt32(query.serviceLevelSeverities.ResolutionTime)) / 4) && (time.Subtract(query.issues.SubmittedDate.Value).TotalMinutes <= Convert.ToInt32(query.serviceLevelSeverities.ResolutionTime ?? 0)) ? "late" : "Not Yet")
                                                )
                                            : "Not Yet",

                             };
                //Data Tickect total by pic
                var result1 = from queryResult in result
                              group queryResult by queryResult.NextActionById into queryResult1
                              select new ReportOutput
                              {
                                  pic = queryResult1.First().pic,
                                  totalOpen = Convert.ToInt32(queryResult1.Count(q => "Yes".Equals(q.isResp))) + Convert.ToInt32(queryResult1.Count(q => "Yes".Equals(q.isImplemented))) + Convert.ToInt32(queryResult1.Count(q => "Yes".Equals(q.noAction))),
                                  noAction = queryResult1.Count(q => "Yes".Equals(q.noAction)),
                                  totalResp = queryResult1.Count(q => "Yes".Equals(q.isResp)),
                                  totalImpl = queryResult1.Count(q => "Yes".Equals(q.isImplemented)),
                                  totalLate = queryResult1.Count(q => "late".Equals(q.respondLate)) + queryResult1.Count(q => "late".Equals(q.resolveLate)),
                                  totalBeLate = queryResult1.Count(q => "late".Equals(q.respBeLate)) + queryResult1.Count(q => "late".Equals(q.implBeLate)),
                                  totalRespLate = queryResult1.Count(q => "late".Equals(q.respondLate)),
                                  totalRespBeLate = queryResult1.Count(q1 => q1.respBeLate.Equals("late")),
                                  totalImplLate = queryResult1.Count(q => "late".Equals(q.resolveLate)),
                                  totalImplBeLate = queryResult1.Count(q => "late".Equals(q.implBeLate)),
                              };
                // Data Tickect header total
                var result2 =
                    new ReportOutput
                    {
                        totalOpen = Convert.ToInt32(result.Count(q => "Yes".Equals(q.isResp))) + Convert.ToInt32(result.Count(q => "Yes".Equals(q.isImplemented))) + Convert.ToInt32(result.Count(q => "Yes".Equals(q.noAction))),
                        totalResp = result.Count(q => "Yes".Equals(q.isResp)),
                        noAction = result.Count(q => "Yes".Equals(q.noAction)),
                        totalImpl = result.Count(q => "Yes".Equals(q.isImplemented)),
                        totalLate = result.Count(q => "late".Equals(q.respondLate)) + result.Count(q => "late".Equals(q.resolveLate)),
                        totalBeLate = result.Count(q => "late".Equals(q.respBeLate)) + result.Count(q => "late".Equals(q.implBeLate)),
                        totalRespLate = result.Count(q => "late".Equals(q.respondLate)),
                        totalRespBeLate = result.Count(q1 => q1.respBeLate.Equals("late")),
                        totalImplLate = result.Count(q => "late".Equals(q.resolveLate)),
                        totalImplBeLate = result.Count(q => "late".Equals(q.implBeLate)),
                    };




               // result1 = result1.OrderBy(c => c.totalLate).ThenByDescending(d=>d.totalLate).ThenByDescending(p => p.totalBeLate).ThenByDescending(s=>s.totalOpen);
                //result1 = ApplyPaging(result1, input);// Paging
                result1 = ApplySorting(result1, input);//Sorting
                ReportResultOutput resultReport = new ReportResultOutput();
                resultReport.totalHeaderTicket = result2;
                resultReport.totalTicketByPic = result1.ToList();
                return resultReport;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;

            }
        }

        public PagedResultDto<dynamic> SearchTicketsList(SearchTicketsInput input)
        {
            try
            {

                DateTime time = DateTime.Now; // Or whatever

                if (string.IsNullOrEmpty(input.type))
                {
                    // Get record NextActionById exist in user
                    var queryJoin = from issues in _db.Issues
                                    join user in _db.UsersInfo on issues.NextActionById equals user.UserId
                                    join subStatus in _db.SubStatus on issues.SubStatusId equals subStatus.SubStatusId
                                    join serviceLevelIssues in _db.ServiceLevelIssues on issues.IssueNbrId equals serviceLevelIssues.IssueNbrID
                                    join serviceLevelSeverities in _db.ServiceLevelSeverities on serviceLevelIssues.SeverityID equals serviceLevelSeverities.SeverityId
                                    join notes in _db.Notes on issues.IssueNbrId equals notes.IssueNbrId into tmpNotes
                                    from notes in tmpNotes.DefaultIfEmpty()
                                    where !string.IsNullOrEmpty(issues.NextActionById) && (issues.StatusId == true) && (notes.FirstNote == true)
                                    select new { issues, user, serviceLevelIssues, serviceLevelSeverities, notes, subStatus };

                    //Query data 
                    var result = from query in queryJoin
                                 select new
                                 {
                                     timeSpent = query.issues.SubmittedDate.HasValue ?
                                                 (
                                                    ((time).Subtract(query.issues.SubmittedDate.Value).TotalDays / 7 >= 1) ? (Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalDays / 7, 0).ToString() + "w") :
                                                    ((time).Subtract(query.issues.SubmittedDate.Value).TotalDays >= 1) ? (Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalDays, 0).ToString() + " d") :
                                                    ((time).Subtract(query.issues.SubmittedDate.Value).TotalHours >= 1) ? (Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalHours, 0).ToString() + " h") :
                                                    ((time).Subtract(query.issues.SubmittedDate.Value).TotalMinutes >= 1) ? (Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalMinutes, 0).ToString() + "m") :
                                                    Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalSeconds, 0).ToString() + "s"
                                                 )
                                                 :
                                                 (
                                                    ""
                                                ),
                                     responseSLA = query.serviceLevelSeverities.ResponseTime > 0 ?
                                                 (
                                                    (query.serviceLevelSeverities.ResponseTime >= 10080) ? ((query.serviceLevelSeverities.ResponseTime / 10080).ToString() + "w") :
                                                    (query.serviceLevelSeverities.ResponseTime >= 1440 && query.serviceLevelSeverities.ResponseTime < 10080) ? ((query.serviceLevelSeverities.ResponseTime / 1440).ToString() + "d") :
                                                    (query.serviceLevelSeverities.ResponseTime >= 60 && query.serviceLevelSeverities.ResponseTime < 1440) ? ((query.serviceLevelSeverities.ResponseTime / 60).ToString() + "h") :
                                                   query.serviceLevelSeverities.ResponseTime.ToString() + "m"
                                                 )
                                                 :
                                                 (
                                                    ""
                                                ),
                                     resolutionSLA = query.serviceLevelSeverities.ResolutionTime > 0 ?
                                                 (
                                                    (query.serviceLevelSeverities.ResolutionTime >= 10080) ? ((query.serviceLevelSeverities.ResolutionTime / 10080).ToString() + "w") :
                                                    (query.serviceLevelSeverities.ResolutionTime >= 1440 && query.serviceLevelSeverities.ResolutionTime < 10080) ? ((query.serviceLevelSeverities.ResolutionTime / 1440).ToString() + "d") :
                                                    (query.serviceLevelSeverities.ResolutionTime >= 60 && query.serviceLevelSeverities.ResolutionTime < 1440) ? ((query.serviceLevelSeverities.ResolutionTime / 60).ToString() + "h") :
                                                   query.serviceLevelSeverities.ResolutionTime.ToString() + "m"
                                                 )
                                                 :
                                                 (
                                                    ""
                                                ),

                                     pic = query.user.DisplayName,
                                     soId = query.issues.IssueNbrId,
                                     subject = query.issues.IssueDescription,
                                     // NextActionById = query.issues.NextActionById,
                                     isResp = (query.notes.NoteId > 0) ? "Yes" : "No",
                                     // noAction = (query.issues.AssignedDate.HasValue) ? "Yes" : "No",
                                     // isImplemented = (query.issues.StatusId == true && "Resolved".Equals(query.subStatus.SubStatus1)) ? "Yes" : "No",

                                     //respondLate = !string.IsNullOrEmpty(query.notes.NoteId.ToString()) ?
                                     //           (
                                     //                ((query.notes.NoteCreatedDate.Value).Subtract(query.issues.SubmittedDate.Value).TotalMinutes > query.serviceLevelSeverities.ResponseTime ? "late" : "Not Yet")
                                     //           )
                                     //           : "Not Yet",
                                     //resolveLate = query.issues.ClosedDate.HasValue ?
                                     //           (
                                     //                ((query.issues.ClosedDate.Value).Subtract(query.issues.SubmittedDate.Value).TotalMinutes > query.serviceLevelSeverities.ResolutionTime ? "late" : "Not Yet")
                                     //           )
                                     //           : "Not Yet",//totalImplLate
                                     //respBeLate = (query.serviceLevelSeverities.ResponseTime > 0) ?
                                     //           (
                                     //            ((time.Subtract(query.issues.SubmittedDate.Value).TotalMinutes > (3 * query.serviceLevelSeverities.ResponseTime) / 4) && (time.Subtract(query.issues.SubmittedDate.Value).TotalMinutes <= query.serviceLevelSeverities.ResponseTime) ? "late" : "Not Yet")
                                     //               )
                                     //           : "Not Yet",
                                     //implBeLate = (query.serviceLevelSeverities.ResolutionTime > 0) ?
                                     //           (
                                     //            ((time.Subtract(query.issues.SubmittedDate.Value).TotalMinutes > (3 * query.serviceLevelSeverities.ResolutionTime) / 4) && (time.Subtract(query.issues.SubmittedDate.Value).TotalMinutes <= query.serviceLevelSeverities.ResolutionTime) ? "late" : "Not Yet")
                                     //               )
                                     //           : "Not Yet",

                                 };

                    var resultFinal = from query in result
                                      .WhereIf(!string.IsNullOrEmpty(input.inputSearch), s => s.subject.Contains(input.inputSearch))
                                          //.WhereIf(!string.IsNullOrEmpty(input.type) && ("responded".Equals(input.type) ), s => s.isResp.Equals("Yes"))
                                          //.WhereIf(!string.IsNullOrEmpty(input.type) && ("implemented".Equals(input.type)), s => s.isImplemented.Equals("Yes"))
                                          // .WhereIf(!string.IsNullOrEmpty(input.type) && ("respLate".Equals(input.type)), s => s.respondLate.Equals("late"))
                                          // .WhereIf(!string.IsNullOrEmpty(input.type) && ("respBeLate".Equals(input.type)), s => s.respBeLate.Equals("late"))
                                          //  .WhereIf(!string.IsNullOrEmpty(input.type) && ("implLate".Equals(input.type)), s => s.resolveLate.Equals("late"))
                                          //  .WhereIf(!string.IsNullOrEmpty(input.type) && ("implBeLate".Equals(input.type)), s => s.implBeLate.Equals("late"))
                                          // .WhereIf(!string.IsNullOrEmpty(input.type) && ("noAction".Equals(input.type)), s => s.noAction.Equals("Yes"))
                                      select new
                                      {
                                          pic = query.pic,
                                          soId = query.soId,
                                          subject = query.subject,
                                          isResp = query.isResp,
                                          timeSpent = query.timeSpent,
                                          responseSLA = query.responseSLA,
                                          resolutionSLA = query.resolutionSLA,
                                      };

                    var totalCount = resultFinal.Count();

                    result = ApplySorting(result, input);//Sorting
                    resultFinal = ApplyPaging(resultFinal, input);// Paging

                    var entities = resultFinal.ToList();


                    return new PagedResultDto<dynamic>(
                              totalCount,
                              entities
                              );
                }
                else
                {

                    // Get record NextActionById exist in user
                    var queryJoin = from issues in _db.Issues
                                    join user in _db.UsersInfo on issues.NextActionById equals user.UserId
                                    join subStatus in _db.SubStatus on issues.SubStatusId equals subStatus.SubStatusId
                                    join serviceLevelIssues in _db.ServiceLevelIssues on issues.IssueNbrId equals serviceLevelIssues.IssueNbrID
                                    join serviceLevelSeverities in _db.ServiceLevelSeverities on serviceLevelIssues.SeverityID equals serviceLevelSeverities.SeverityId
                                    join notes in _db.Notes on issues.IssueNbrId equals notes.IssueNbrId into tmpNotes
                                    from notes in tmpNotes.DefaultIfEmpty()
                                    where !string.IsNullOrEmpty(issues.NextActionById) && (issues.StatusId == true) && (notes.FirstNote == true )
                                    select new { issues, user, serviceLevelIssues, serviceLevelSeverities, notes, subStatus };

                    //Query data 
                    var result = from query in queryJoin
                                 select new
                                 {
                                     timeSpent = query.issues.SubmittedDate.HasValue ?
                                                 (
                                                    ((time).Subtract(query.issues.SubmittedDate.Value).TotalDays / 7 >= 1) ? (Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalDays / 7, 0).ToString() + "w") :
                                                    ((time).Subtract(query.issues.SubmittedDate.Value).TotalDays >= 1) ? (Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalDays, 0).ToString() + "d") :
                                                    ((time).Subtract(query.issues.SubmittedDate.Value).TotalHours >= 1) ? (Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalHours, 0).ToString() + "h") :
                                                    ((time).Subtract(query.issues.SubmittedDate.Value).TotalMinutes >= 1) ? (Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalMinutes, 0).ToString() + "m") :
                                                    Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalSeconds, 0).ToString() + "s"
                                                 )
                                                 :
                                                 (
                                                    ""
                                                ),
                                     responseSLA = query.serviceLevelSeverities.ResponseTime > 0 ?
                                                 (
                                                    (query.serviceLevelSeverities.ResponseTime >= 10080) ? ((query.serviceLevelSeverities.ResponseTime / 10080).ToString() + "w") :
                                                    (query.serviceLevelSeverities.ResponseTime >= 1440 && query.serviceLevelSeverities.ResponseTime < 10080) ? ((query.serviceLevelSeverities.ResponseTime / 1440).ToString() + "d") :
                                                    (query.serviceLevelSeverities.ResponseTime >= 60 && query.serviceLevelSeverities.ResponseTime < 1440) ? ((query.serviceLevelSeverities.ResponseTime / 60).ToString() + "h") :
                                                   query.serviceLevelSeverities.ResponseTime.ToString() + "m"
                                                 )
                                                 :
                                                 (
                                                    ""
                                                ),
                                     resolutionSLA = query.serviceLevelSeverities.ResolutionTime > 0 ?
                                                 (
                                                    (query.serviceLevelSeverities.ResolutionTime >= 10080) ? ((query.serviceLevelSeverities.ResolutionTime / 10080).ToString() + "w") :
                                                    (query.serviceLevelSeverities.ResolutionTime >= 1440 && query.serviceLevelSeverities.ResolutionTime < 10080) ? ((query.serviceLevelSeverities.ResolutionTime / 1440).ToString() + "d") :
                                                    (query.serviceLevelSeverities.ResolutionTime >= 60 && query.serviceLevelSeverities.ResolutionTime < 1440) ? ((query.serviceLevelSeverities.ResolutionTime / 60).ToString() + "h") :
                                                   query.serviceLevelSeverities.ResolutionTime.ToString() + "m"
                                                 )
                                                 :
                                                 (
                                                    ""
                                                ),

                                     pic = query.user.DisplayName,
                                     soId = query.issues.IssueNbrId,
                                     subject = query.issues.IssueDescription,
                                     // NextActionById = query.issues.NextActionById,
                                    // isResp = (query.notes.NoteId > 0) ? "Yes" : "No",
                                     isResp = (query.notes.NoteId > 0 && (!"Resolved".Equals(query.subStatus.SubStatus1))) ? "Yes" : "No",
                                     noAction = ((query.notes.NoteId == 0) && !"Resolved".Equals(query.subStatus.SubStatus1)) ? "Yes" : "No",
                                     isImplemented = (query.issues.StatusId == true && "Resolved".Equals(query.subStatus.SubStatus1)) ? "Yes" : "No",

                                     respondLate =
                                ((!string.IsNullOrEmpty(query.notes.NoteId.ToString()) && query.serviceLevelSeverities.ResponseTime.HasValue) || (!"Resolved".Equals(query.subStatus.SubStatus1) && query.serviceLevelSeverities.ResponseTime.HasValue)) ?
                                                (
                                                     ((query.notes.NoteCreatedDate.Value).Subtract(query.issues.SubmittedDate.Value).TotalMinutes > (query.serviceLevelSeverities.ResponseTime ?? 0) ? "late" : "Not Yet")
                                                )
                                                : "Not Yet",
                                     resolveLate = query.issues.ClosedDate.HasValue && query.serviceLevelSeverities.ResolutionTime.HasValue ?
                                            (


                                                 ((query.issues.ClosedDate.Value).Subtract(query.issues.SubmittedDate.Value).TotalMinutes > query.serviceLevelSeverities.ResolutionTime ? "late" : "Not Yet")
                                            )

                                              : query.serviceLevelSeverities.ResolutionTime.HasValue ? (
                                                 ((time).Subtract(query.issues.SubmittedDate.Value).TotalMinutes > query.serviceLevelSeverities.ResponseTime ? "late" : "Not Yet")
                                            ) : "Not Yet",
                                     respBeLate = ((query.serviceLevelSeverities.ResponseTime ?? 0) > 0 && !"Resolved".Equals(query.subStatus.SubStatus1)) ?
                                                (
                                                 ((time.Subtract(query.issues.SubmittedDate.Value).TotalMinutes > (3 * (query.serviceLevelSeverities.ResponseTime ?? 0)) / 4) && (time.Subtract(query.issues.SubmittedDate.Value).TotalMinutes <= (query.serviceLevelSeverities.ResponseTime ?? 0)) ? "late" : "Not Yet")
                                                    )
                                                : "Not Yet",
                                     implBeLate = ((query.serviceLevelSeverities.ResolutionTime ?? 0) > 0 && query.issues.ClosedDate.HasValue) ?
                                                (
                                                 ((time.Subtract(query.issues.SubmittedDate.Value).TotalMinutes > (3 * (query.serviceLevelSeverities.ResolutionTime ?? 0)) / 4) && (time.Subtract(query.issues.SubmittedDate.Value).TotalMinutes <= (query.serviceLevelSeverities.ResolutionTime ?? 0)) ? "late" : "Not Yet")
                                                    )
                                                : "Not Yet",

                                 };

                    var resultFinal = from query in result
                                      .WhereIf(!string.IsNullOrEmpty(input.inputSearch), s => s.subject.Contains(input.inputSearch))
                                          .WhereIf(!string.IsNullOrEmpty(input.type) && ("responded".Equals(input.type)), s => s.isResp.Equals("Yes"))
                                          .WhereIf(!string.IsNullOrEmpty(input.type) && ("implemented".Equals(input.type)), s => s.isImplemented.Equals("Yes"))
                                           .WhereIf(!string.IsNullOrEmpty(input.type) && ("respLate".Equals(input.type)), s => s.respondLate.Equals("late"))
                                           .WhereIf(!string.IsNullOrEmpty(input.type) && ("respBeLate".Equals(input.type)), s => s.respBeLate.Equals("late"))
                                            .WhereIf(!string.IsNullOrEmpty(input.type) && ("implLate".Equals(input.type)), s => s.resolveLate.Equals("late"))
                                            .WhereIf(!string.IsNullOrEmpty(input.type) && ("implBeLate".Equals(input.type)), s => s.implBeLate.Equals("late"))
                                           .WhereIf(!string.IsNullOrEmpty(input.type) && ("noAction".Equals(input.type)), s => s.noAction.Equals("Yes"))
                                      select new
                                      {
                                          pic = query.pic,
                                          soId = query.soId,
                                          subject = query.subject,
                                          isResp = query.isResp,
                                          timeSpent = query.timeSpent,
                                          responseSLA = query.responseSLA,
                                          resolutionSLA = query.resolutionSLA,
                                      };

                    var totalCount = resultFinal.Count();

                    result = ApplySorting(result, input);//Sorting
                    resultFinal = ApplyPaging(resultFinal, input);// Paging

                    var entities = resultFinal.ToList();


                    return new PagedResultDto<dynamic>(
                              totalCount,
                              entities
                              );
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new PagedResultDto<dynamic>(
                          0,
                          null
                          );

            }
        }
    }


}
