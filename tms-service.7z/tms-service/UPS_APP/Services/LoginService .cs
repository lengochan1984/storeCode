﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using Ups.Import2K.Services.Services.Abstractions;
using UPS_APP.Common;
using UPS_APP.Config;
using UPS_APP.Dtos;
using UPS_APP.Services.Abstractions;

namespace UPS_APP.Services
{
    public class LoginService : UpsServiceBase, ILoginService
    {

        private readonly UPSDBContext _db;


        public LoginService(UPSDBContext db)
        {
            _db = db;
        }


        public string CheckLogin(UserLoginInput input)
        {
            try
            {
                var result = from user in _db.Account
                             .WhereIf(!string.IsNullOrEmpty(input.userName), s => s.UserId == input.userName)
                             .WhereIf(!string.IsNullOrEmpty(input.password), s => s.Password == input.password)
                             select new
                             {
                                 UserID = user.UserId

                             };


                var entities = result.ToList().FirstOrDefault();
                if (entities != null)
                {
                   
                    return entities.UserID;
                }
                else
                {

                    return null;

                }
            }
            catch (Exception ex)
            {

                return null;
            }
        }

       
        public UserInfoOutput GetUserInformation(UserInfoInput input)
        {

            var result = from user in _db.Account 
                         .WhereIf(!string.IsNullOrEmpty(input.userId), s => s.UserId == input.userId)
                         select new
                         {
                             UserId = user.UserId,
                             FirstName = user.FirstName,
                             LastName = user.LastName,
                             DisplayName = user.DisplayName

                         };
            var entities = result.ToList().FirstOrDefault();
            UserInfoOutput output = new UserInfoOutput();
            output.DisplayName = entities.DisplayName;
            output.FirstName = entities.FirstName;
            output.LastName = entities.LastName;
            output.UserId = entities.UserId;
            return output;
        }


    }
}
