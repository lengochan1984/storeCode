﻿using System.Collections.Generic;
using System.Linq;
using Ups.Import2K.Services.Services.Abstractions;
using UPS_APP.Common;
using UPS_APP.Config;
using UPS_APP.Dtos;
using UPS_APP.Services.Abstractions;

namespace UPS_APP.Services
{
    public class DetailSummaryService : UpsServiceBase, IDetailSummaryService
    {

        private readonly UPSDBContext _db;

        public DetailSummaryService(UPSDBContext db)
        {
            _db = db;
        }

        public PagedResultDto<dynamic> GetTicketsummaryrecorddetail(ViewSumaryDetailInput input)
        {
            var IssuesRepository = _db.Issues
                .Where(s => s.NextActionById == input.userId)
                .Where(s => (input.status != 0 ? s.StatusId == true : s.StatusId == false))
                .Where(s => s.AssignedTo.ToLower().Contains("sls")
                || s.AssignedTo.ToLower().Contains("tls")
                || s.AssignedTo.ToLower().Contains("hwsw")
                || s.AssignedTo.ToLower().Contains("sga"))
                .WhereIf(input.submittedFrom.HasValue, s => s.SubmittedDate.Value.Date >= input.submittedFrom.Value.Date)
                .WhereIf(input.submittedTo.HasValue, s => s.SubmittedDate.Value.Date <= input.submittedTo.Value.Date)
                .WhereIf(!string.IsNullOrEmpty(input.type) && !"total".Equals(input.type), s => s.AssignedTo.ToLower().Contains(input.type));

            var UserRepository = _db.UsersInfo;

            var ServiceLevelIssuesRepository = _db.ServiceLevelIssues;

            var ServiceLevelSeveritiesRepository = _db.ServiceLevelSeverities;

            // Get record NextActionById exist in user
            var queryJoin = from issues in IssuesRepository
                            join user in UserRepository
                            on issues.NextActionById equals user.UserId
                            select new { issues, user };

            // Get record AssignedTo exist in user
            var result = from query in queryJoin
                         join user in UserRepository
                         on query.issues.AssignedTo equals user.UserId

                         join serviceLevelIssues in ServiceLevelIssuesRepository
                         on query.issues.IssueNbrId equals serviceLevelIssues.IssueNbrID

                         join serviceLevelSeverities in ServiceLevelSeveritiesRepository
                         on serviceLevelIssues.SeverityID  equals serviceLevelSeverities.SeverityId

                         select new ViewSumaryDetailOutput
                         {
                             UserName = query.user.DisplayName,
                             UserId = query.issues.NextActionById,
                             GroupId = query.issues.GlobalId,
                             Subject = query.issues.IssueDescription,
                             SOId = query.issues.IssueNbrId,
                             Severity = serviceLevelSeverities.Severity
                         };

            var totalCount = result.Count();

            result = ApplySorting(result, input);
            result = ApplyPaging(result, input);

            var entities = result.ToList();
            return new PagedResultDto<dynamic>(
                      totalCount,
                      entities
                      );
        }
    }


}
