﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using Ups.Import2K.Services.Services.Abstractions;
using UPS_APP.Common;
using UPS_APP.Config;
using UPS_APP.Dtos;
using UPS_APP.Entities;
using UPS_APP.Services.Abstractions;


namespace UPS_APP.Services
{
    public class UserService : UpsServiceBase, IUserService
    {

        private readonly UPSDBContext _db;


        public UserService(UPSDBContext db)
        {
            _db = db;
        }


        public PagedResultDto<dynamic> Search(UserSearchInput input)
        {
            try
            {

                var UserRepository = _db.Account 
                     .WhereIf(!string.IsNullOrEmpty(input.name) , s => s.UserId.ToLower().Contains(input.name));

                // Get record AssignedTo exist in user
                var result = from user in UserRepository
                             select new 
                             {
                                 UserID = user.UserId,
                                 FirstName = user.FirstName,
                                 LastName = user.LastName,
                                 DisplayName = user.DisplayName,
                                 Password = user.Password,
								 createdDate = user.CreatedDate,
                                 updatedDate = user.UpdatedDate,
                             };

                var totalCount = result.Count();

                result = ApplySorting(result, input);
                result = ApplyPaging(result, input);

                var entities = result.ToList();
                return new PagedResultDto<dynamic>(
                          totalCount,
                          entities
                          );
            }
            catch (Exception ex)
            {

                return null;
            }
        }

        public bool deleteUser(UserInfoInput input)
        {

            bool result = false;
            var user_delete = _db.Account .Find(input.userId);

            var delete = _db.Account.Remove(user_delete);
            try
            {
                result = (_db.SaveChanges() > 0);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                // Provide for exceptions.
                result = false;
            }
            return result;
        }

        public bool updateUser(UserAddInput input)
        {
            bool result = false;

            var user = _db.Account .First(a => a.UserId.Equals(input.UserId));
            user.UpdatedDate = DateTime.Now;
            if (!string.IsNullOrEmpty(input.Password)) {user.Password = input.Password;}
            if (!string.IsNullOrEmpty(input.FirstName)) { user.FirstName = input.FirstName; }
            if (!string.IsNullOrEmpty(input.LastName)) { user.LastName = input.LastName; }
            if (!string.IsNullOrEmpty(input.DisplayName)) { user.DisplayName = input.DisplayName; }
            if (!string.IsNullOrEmpty(input.CreatedBy)) { user.CreatedBy = input.CreatedBy; }
            if (!string.IsNullOrEmpty(input.UpdatedBy)) { user.UpdatedBy = input.UpdatedBy; }
            
            try
            {
                result = (_db.SaveChanges() > 0);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                result = false;
                // Provide for exceptions.
            }
            return result;
        }
        public bool insertUser(UserAddInput input)
        {
            bool result = false;
            var author = new Account {
                     UserId = input.UserId,
                     Password = input.Password,
                     FirstName = input.FirstName,
                     LastName = input.LastName,
                     DisplayName = input.DisplayName,
                     CreatedDate = DateTime.Now,
                     CreatedBy = input.CreatedBy,
                     UpdatedBy = input.UpdatedBy,
            };

            _db.Account.Add(author);
            try
            {
                result = (_db.SaveChanges() > 0);
            }
            catch (Exception e)
            {
                result = false;
                Console.WriteLine(e);
                // Provide for exceptions.
            }
            return result;
        }

 		public UserDetailOutput GetUserDetail(UserInfoInput input)
        {
            var UserRepository = _db.Account;
            var result = from user in UserRepository
                         .WhereIf(!string.IsNullOrEmpty(input.userId), s => s.UserId == input.userId)
                         select new
                         {
                             UserId = user.UserId,
                             FirstName = user.FirstName,
                             LastName = user.LastName,
                             DisplayName = user.DisplayName,
                             Password = user.Password,
                             CreatedBy = user.CreatedBy,
                             UpdatedBy = user.UpdatedBy
                         };
            if (result.Count() > 0)
            {
                var entities = result.ToList().FirstOrDefault();
                UserDetailOutput output = new UserDetailOutput();
                output.DisplayName = entities.DisplayName;
                output.FirstName = entities.FirstName;
                output.LastName = entities.LastName;
                output.UserId = entities.UserId;
                output.Password = entities.Password;
                output.CreatedBy = entities.CreatedBy;
                output.UpdatedBy = entities.UpdatedBy;
                return output;
            }
            
            return null;
        }
    }
}
