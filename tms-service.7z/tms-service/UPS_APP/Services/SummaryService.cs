﻿using System;
using System.Collections.Generic;
using System.Linq;
using Ups.Import2K.Services.Services.Abstractions;
using UPS_APP.Common;
using UPS_APP.Config;
using UPS_APP.Dtos;
using UPS_APP.Services.Abstractions;

namespace UPS_APP.Services
{
    public class SummaryService : UpsServiceBase, ISummaryService
    {

        private readonly UPSDBContext _db;

        public SummaryService(UPSDBContext db)
        {
            _db = db;
        }

        public PagedResultDto<dynamic> Search(SearchSumaryInput input)
        {
            try
            {

                //var IssuesRepository = _db.Issues
                //    .Where(s => !string.IsNullOrEmpty(s.NextActionById))
                //    .Where(s => (input.status != 0 ? s.StatusId == true : s.StatusId == false))
                //    .Where(s => s.AssignedTo.ToLower().Contains("sls")
                //    || s.AssignedTo.ToLower().Contains("tls")
                //    || s.AssignedTo.ToLower().Contains("hwsw")
                //    || s.AssignedTo.ToLower().Contains("sga"))
                //    .WhereIf(input.submittedFrom.HasValue, s => s.SubmittedDate.Value.Date >= input.submittedFrom.Value.Date)
                //    .WhereIf(input.submittedTo.HasValue, s => s.SubmittedDate.Value.Date <= input.submittedTo.Value.Date);

                // Get record NextActionById exist in user
                var queryJoin = from issues in _db.Issues
                                join user in _db.UsersInfo on issues.NextActionById equals user.UserId
                                where !string.IsNullOrEmpty(issues.NextActionById) && (issues.StatusId == (input.status != 0)) && (issues.AssignedTo.ToLower().Equals("sls")
                                || issues.AssignedTo.ToLower().Equals("tls") || issues.AssignedTo.ToLower().Equals("hwsw") || issues.AssignedTo.ToLower().Equals("sga"))
                                select new { issues, user };

                // Get record AssignedTo exist in user
                var result = from query in queryJoin
                            //  join user in UserRepository
                            //  on query.issues.AssignedTo equals user.UserId
                            .WhereIf(input.submittedFrom.HasValue, s => s.issues.SubmittedDate.Value.Date >= input.submittedFrom.Value.Date)
                    .WhereIf(input.submittedTo.HasValue, s => s.issues.SubmittedDate.Value.Date <= input.submittedTo.Value.Date)
                             group query by query.issues.NextActionById into queryResult

                             select new SearchSumaryOutput
                             {
                                 userId = queryResult.First().issues.NextActionById,
                                 pic = queryResult.First().user.DisplayName,
                                 sls = queryResult.Count(g => "sls".Equals(g.issues.AssignedTo.ToLower())),
                                 tls = queryResult.Count(g => "tls".Equals(g.issues.AssignedTo.ToLower())),
                                 hwsw = queryResult.Count(g => "hwsw".Equals(g.issues.AssignedTo.ToLower())),
                                 systemGeneratedAlerts = queryResult.Count(g => "sga".Equals(g.issues.AssignedTo.ToLower())),
                                 total = queryResult.Count()
                             };

                var totalCount = result.Count();

                result = ApplySorting(result, input);
                result = ApplyPaging(result, input);

                var entities = result.ToList();
                return new PagedResultDto<dynamic>(
                          totalCount,
                          entities
                          );
            }
            catch (Exception ex)
            {

                return null;
            }
        }


    }

}
