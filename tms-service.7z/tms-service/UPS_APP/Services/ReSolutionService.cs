﻿using System;
using System.Collections.Generic;
using System.Linq;
using Ups.Import2K.Services.Services.Abstractions;
using UPS_APP.Common;
using UPS_APP.Config;
using UPS_APP.Dtos;
using UPS_APP.Services.Abstractions;
using System.Data;


namespace UPS_APP.Services
{
    public class ReSolutionService : UpsServiceBase, IReSolutionService
    {

        private readonly UPSDBContext _db;

        public ReSolutionService(UPSDBContext db)
        {
            _db = db;
        }

        public PagedResultDto<dynamic> SearchResolution(SearchResolutionInput input)
        {
            try
            { 
                DateTime time = DateTime.Now;

                // Get record NextActionById exist in user
                var queryJoin = from issues in _db.Issues
                                join user in _db.UsersInfo on issues.NextActionById equals user.UserId
                                join subStatus in _db.SubStatus on issues.SubStatusId equals subStatus.SubStatusId
                                join serviceLevelIssues in _db.ServiceLevelIssues on issues.IssueNbrId equals serviceLevelIssues.IssueNbrID
                                join serviceLevelSeverities in _db.ServiceLevelSeverities on serviceLevelIssues.SeverityID equals serviceLevelSeverities.SeverityId
                                where !string.IsNullOrEmpty(issues.NextActionById) && (issues.StatusId == (input.status != 0)) 
                                select new { issues, user, serviceLevelIssues, serviceLevelSeverities, subStatus };

                //Query condition status, assignedTo, isResponsed, submittedFrom, submittedTo
                var result = from query in queryJoin
                                  //.WhereIf(!string.IsNullOrEmpty(input.assignedTo), s => s.issues.AssignedTo.ToLower().Equals(input.assignedTo))
                                  //.WhereIf(input.submittedFrom.HasValue, s => s.issues.SubmittedDate.Value.Date >= input.submittedFrom.Value.Date)
                                  //.WhereIf(input.submittedTo.HasValue, s => s.issues.SubmittedDate.Value.Date <= input.submittedTo.Value.Date)
                                  //.WhereIf(!string.IsNullOrEmpty(input.isResponsed) && (input.isResponsed == "1"), s => ("Resolved".Equals(s.subStatus.SubStatus1)))
                                  //.WhereIf(!string.IsNullOrEmpty(input.isResponsed) && (input.isResponsed == "0"), s => (!"Resolved".Equals(s.subStatus.SubStatus1)))
                             select new
                             {
                                 pic = query.user.DisplayName,
                                 groupID = query.issues.GlobalId,
                                 subject = query.issues.IssueDescription,
                                 soId = query.issues.IssueNbrId,
                                 severity = query.serviceLevelSeverities.Severity,
                                 assignedTo = query.issues.AssignedTo,
                                 //isResolved: if exist a ticket has closed is No else Yes
                                 isResolved = ("Resolved".Equals(query.subStatus.SubStatus1)) ? "Yes" : "No",
                                // isResolved =  ? "No" : "Yes",
                                 //onestRespStatus:
                                 onestRespStatus = query.issues.ClosedDate.HasValue ?
                                            (
                                                 ((query.issues.ClosedDate.Value).Subtract(query.issues.SubmittedDate.Value).TotalMinutes > query.serviceLevelSeverities.ResolutionTime ? "late" : "On Time")
                                            )
           
                                              : (
                                                 ((time).Subtract(query.issues.SubmittedDate.Value).TotalMinutes > query.serviceLevelSeverities.ResponseTime ? "late" : "Not Yet")
                                            ),
                                 //due:
                                         //tickketClose : exist ClosedDate
                                         //tính due: getTime - SubmittedDate
                        due = string.IsNullOrEmpty(query.issues.ClosedDate.ToString())&& query.serviceLevelSeverities.ResolutionTime >0
                        && (time).Subtract(query.issues.SubmittedDate.Value).TotalMinutes <= query.serviceLevelSeverities.ResponseTime ?
                                             (
                                                 ((time).Subtract(query.issues.SubmittedDate.Value).TotalDays >= 1) ? (Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalDays, 0).ToString() + " d") :
                                                ((time).Subtract(query.issues.SubmittedDate.Value).TotalHours >= 1) ? (Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalHours, 0).ToString() + " hr") :
                                                ((time).Subtract(query.issues.SubmittedDate.Value).TotalMinutes >= 1) ? (Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalMinutes, 0).ToString() + " m") :
                                                Math.Round((time).Subtract(query.issues.SubmittedDate.Value).TotalSeconds, 0).ToString() + " s"
                                             )
                                             :
                                             (
                                                ""
                                            ) ,
                                 resolutionContent = query.issues.IssueSolution
                             };

                var totalCount = result.Count();

                result = ApplySorting(result, input); //Sorting
                result = ApplyPaging(result, input); // Paging

                var entities = result.ToList();
                return new PagedResultDto<dynamic>(
                          totalCount,
                          entities
                          );
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new PagedResultDto<dynamic>(
                          0,
                          null
                          );

            }
        }
    }


}
