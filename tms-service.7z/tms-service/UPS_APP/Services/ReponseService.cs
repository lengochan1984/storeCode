﻿using System;
using System.Collections.Generic;
using System.Linq;
using Ups.Import2K.Services.Services.Abstractions;
using UPS_APP.Common;
using UPS_APP.Config;
using UPS_APP.Dtos;
using UPS_APP.Services.Abstractions;


namespace UPS_APP.Services
{
    public class ResponseService : UpsServiceBase, IResponseService
    {

        private readonly UPSDBContext _db;

        public ResponseService(UPSDBContext db)
        {
            _db = db;
        }

        public PagedResultDto<dynamic> SearchResponse(SearchResponseInput input)
        {
            try
            {
                DateTime time = DateTime.Now;
                // Get record NextActionById exist in user
                var queryJoin = from issues in _db.Issues
                                join user in _db.UsersInfo on issues.NextActionById equals user.UserId
                                join serviceLevelIssues in _db.ServiceLevelIssues on issues.IssueNbrId equals serviceLevelIssues.IssueNbrID
                                join serviceLevelSeverities in _db.ServiceLevelSeverities on serviceLevelIssues.SeverityID equals serviceLevelSeverities.SeverityId
                                join notes in _db.Notes on issues.IssueNbrId equals notes.IssueNbrId into tmpNotes
                                from notes in tmpNotes.DefaultIfEmpty()
                                where !string.IsNullOrEmpty(issues.NextActionById) && (issues.StatusId == (input.status != 0)) && (notes.FirstNote == true)
                                select new { issues, user, serviceLevelIssues, serviceLevelSeverities, notes };

                //Query condition status, assignedTo, isResponsed, submittedFrom, submittedTo
                var result = from query in queryJoin
                                  //.WhereIf(!string.IsNullOrEmpty(input.isResponsed) && (input.isResponsed == "1"), s => !string.IsNullOrEmpty(s.notes.NoteId.ToString()))
                                  //.WhereIf(!string.IsNullOrEmpty(input.isResponsed) && (input.isResponsed == "0"), s => string.IsNullOrEmpty(s.notes.NoteId.ToString()))
                                  //.WhereIf(!string.IsNullOrEmpty(input.assignedTo), s => s.issues.AssignedTo.ToLower().Equals(input.assignedTo))
                                  //.WhereIf(input.submittedFrom.HasValue, s => s.issues.SubmittedDate.Value.Date >= input.submittedFrom.Value.Date)
                                  //.WhereIf(input.submittedTo.HasValue, s => s.issues.SubmittedDate.Value.Date <= input.submittedTo.Value.Date)
                             select new
                             {
                                 pic = query.user.DisplayName,
                                 groupId = query.issues.GlobalId,
                                 subject = query.issues.IssueDescription,
                                 soId = query.issues.IssueNbrId,
                                 severity = query.serviceLevelSeverities.Severity,
                                 assignedTo = query.issues.AssignedTo,
                                 //isResp: if exist a ticket has Responding is Yes else No
                                 isResp = (query.notes.NoteId > 0) ? "Yes" : "No",
                                 //onestRespStatus = "",
                                 //due=0,
                                 //NotePrivate=query.notes.NotePrivate ,
                                 //FirstNote = query.notes.FirstNote ,
                                 //onestRespStatus:
                                 //not yet là chưa có public note + chưa quá thời gian dựa theo severity
                                 // Ontime là đã có public note, NoteCreatedDate - AsignedDate<Severity Time
                                 //Late1 là chưa có public note và GetDate - AssignedDate > Severity Time
                                 //Late2 là đã có public note và NoteCreatedDate - AssignedDate > Severity Time
                                 //onestRespStatus = query.notes.NoteCreatedDate.HasValue ?
                                 onestRespStatus = !string.IsNullOrEmpty(query.notes.NoteId.ToString()) ?
                                            (
                                                 ((query.notes.NoteCreatedDate.Value).Subtract(query.issues.AssignedDate.Value).TotalMinutes > query.serviceLevelSeverities.ResponseTime ? "late" : "On Time")
                                            )
                                            : (
                                            ((time).Subtract(query.issues.AssignedDate.Value).TotalMinutes > query.serviceLevelSeverities.ResponseTime ? "late" : "Not Yet")),
                                 //(query.serviceLevelSeverities.ResponseTime > 0) ? ((time).Subtract(query.issues.AssignedDate.Value).TotalMinutes > query.serviceLevelSeverities.ResponseTime ? "late" : "Not Yet") :
                                 //"Not Yet"
                                 due = string.IsNullOrEmpty(query.notes.NoteId.ToString()) && (time).Subtract(query.issues.AssignedDate.Value).TotalMinutes <= query.serviceLevelSeverities.ResponseTime ?
                                             (
                                                ((time).Subtract(query.issues.AssignedDate.Value.AddMinutes(query.serviceLevelSeverities.ResponseTime??0)).TotalDays >= 1) ? (Math.Round((time).Subtract(query.issues.AssignedDate.Value.AddMinutes(query.serviceLevelSeverities.ResponseTime??0)).TotalDays, 0).ToString() + " d") :
                                                ((time).Subtract(query.issues.AssignedDate.Value.AddMinutes(query.serviceLevelSeverities.ResponseTime??0)).TotalHours >= 1) ? (Math.Round((time).Subtract(query.issues.AssignedDate.Value.AddMinutes(query.serviceLevelSeverities.ResponseTime??0)).TotalHours, 0).ToString() + " hr") :
                                                ((time).Subtract(query.issues.AssignedDate.Value.AddMinutes(query.serviceLevelSeverities.ResponseTime??0)).TotalMinutes >= 1) ? (Math.Round((time).Subtract(query.issues.AssignedDate.Value.AddMinutes(query.serviceLevelSeverities.ResponseTime??0)).TotalMinutes, 0).ToString() + " m") :
                                                Math.Round((time).Subtract(query.issues.AssignedDate.Value.AddMinutes(query.serviceLevelSeverities.ResponseTime??0)).TotalSeconds, 0).ToString() + " s"
                                             )
                                             :
                                             (
                                                ""
                                            ),
                                 onestRespContent = query.notes.NoteText
                             };

                var totalCount = result.Count();

                result = ApplySorting(result, input);//Sorting
                result = ApplyPaging(result, input);// Paging

                var entities = result.ToList();
                return new PagedResultDto<dynamic>(
                          totalCount,
                          entities
                          );
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new PagedResultDto<dynamic>(
                          0,
                          null
                          );

            }
        }
    }


}
