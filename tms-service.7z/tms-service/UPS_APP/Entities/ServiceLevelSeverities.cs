﻿using System;
using System.Collections.Generic;

namespace UPS_APP.Entities
{
    public partial class ServiceLevelSeverities
    {
        public int SeverityId { get; set; }
        public string Severity { get; set; }
        public int? ResolutionTime { get; set; }
        public int? ResponseTime { get; set; }
    }
}
