﻿using System;
using System.Collections.Generic;

namespace UPS_APP.Entities
{
    public partial class Status
    {
        public int StatusId { get; set; }
        public string StatusName { get; set; }
    }
}
