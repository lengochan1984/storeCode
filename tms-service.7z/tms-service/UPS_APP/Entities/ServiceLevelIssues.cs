﻿using System;
using System.Collections.Generic;

namespace UPS_APP.Entities
{
    public partial class ServiceLevelIssues
    {
        public int IssueNbrID { get; set; }
        public int SeverityID { get; set; }
    }
}
