﻿namespace UPS_APP.Common
{
    public class ErrorModel
    {
        public int ErrorCode { get; set; }

        public string Message { get; set; }
    }
}
