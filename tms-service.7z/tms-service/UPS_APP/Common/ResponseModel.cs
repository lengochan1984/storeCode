﻿namespace UPS_APP.Common
{
    public class ResponseModel
    {
        public object Data { get; set; }
    }
}
