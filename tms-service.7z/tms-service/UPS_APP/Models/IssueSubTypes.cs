﻿using System;
using System.Collections.Generic;

namespace UPS_APP.Config 
{
    public partial class IssueSubTypes
    {
        public int IssueSubTypeId { get; set; }
        public int? IssueTypeId { get; set; }
        public string IssueSubType2 { get; set; }
    }
}
