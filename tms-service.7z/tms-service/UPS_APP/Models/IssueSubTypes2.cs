﻿using System;
using System.Collections.Generic;

namespace UPS_APP.Config
{
    public partial class IssueSubTypes2
    {
        public int IssueSubType2Id { get; set; }
        public int? ParentId { get; set; }
        public string IssueSubType2 { get; set; }
    }
}
