﻿using System;
using System.Collections.Generic;

namespace UPS_APP.Config 
{
    public partial class Issues
    {
        public int? GlobalId { get; set; }
        public int IssueNbrId { get; set; }
        public string IssueDescription { get; set; }
        public string IssueSolution { get; set; }
        public int? IssueTypeId { get; set; }
        public int? IssueSubTypeId { get; set; }
        public bool? StatusId { get; set; }
        public string SubmittedById { get; set; }
        public DateTime? SubmittedDate { get; set; }
        public string AssignedTo { get; set; }
        public DateTime? AssignedDate { get; set; }
        public string ClosedById { get; set; }
        public DateTime? ClosedDate { get; set; }
        public string ActivityById { get; set; }
        public DateTime? ActivityDate { get; set; }
        public string ReopenedById { get; set; }
        public DateTime? ReopenedDate { get; set; }
        public DateTime? RequiredByDate { get; set; }
        public DateTime? NextActionByDate { get; set; }
        public int? SubStatusId { get; set; }
        public string NextActionById { get; set; }
        public int? IssueSubType2Id { get; set; }
    }
}
