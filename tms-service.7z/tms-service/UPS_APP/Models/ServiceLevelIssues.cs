﻿using System;
using System.Collections.Generic;

namespace UPS_APP.Config 
{
    public partial class ServiceLevelIssues
    {
        public int IssueNbrId { get; set; }
        public int? SeverityId { get; set; }
    }
}
