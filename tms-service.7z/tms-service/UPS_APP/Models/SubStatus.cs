﻿using System;
using System.Collections.Generic;

namespace UPS_APP.Config
{
    public partial class SubStatus
    {
        public int SubStatusId { get; set; }
        public string SubStatus1 { get; set; }
    }
}
