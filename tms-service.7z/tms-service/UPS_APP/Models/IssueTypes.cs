﻿using System;
using System.Collections.Generic;

namespace UPS_APP.Config
{
    public partial class IssueTypes
    {
        public int IssueTypeId { get; set; }
        public string IssueType { get; set; }
    }
}
