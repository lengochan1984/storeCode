﻿using System;
using System.Collections.Generic;

namespace UPS_APP.Config
{
    public partial class Notes
    {
        public int? IssueNbrId { get; set; }
        public int NoteId { get; set; }
        public DateTime? NoteCreatedDate { get; set; }
        public string NoteText { get; set; }
        public bool? NotePrivate { get; set; }
        public bool? FirstNote { get; set; }
        public string CreatedById { get; set; }
        public string ModifiedById { get; set; }
        public DateTime? NoteModifiedDate { get; set; }
        public double? NoteTime { get; set; }
        public bool? IsRichText { get; set; }
    }
}
