package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 設備状態ログ
 * 
 */
@Entity
@Table(name = "tr_equip_sts_log")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class TrEquipStsLogEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 登録日時 */
    @Column(nullable = true, unique = false)
    public Timestamp createdOn;

    /** 登録者 */
    @Column(length = 32, nullable = true, unique = false)
    public String createdBy;

    /** 更新日時 */
    @Column(nullable = true, unique = false)
    public Timestamp modifiedOn;

    /** 更新者 */
    @Column(length = 32, nullable = true, unique = false)
    public String modifiedBy;

    /** メインリソース番号 */
    @Id
    @Column(length = 12, nullable = false, unique = false)
    public String mainResNo;

    /** プラントコード */
    @Id
    @Column(length = 10, nullable = false, unique = false)
    public String plantCd;

    /** イベント日時 */
    @Id
    @Column(nullable = false, unique = false)
    public Timestamp eventTime;

    /** 製造ラインコード */
    @Column(length = 10, nullable = true, unique = false)
    public String seizouLnCd;

    /** 製造ライン名 */
    @Column(length = 64, nullable = true, unique = false)
    public String seizouLnNm;

    /** 工程コード */
    @Column(length = 5, nullable = true, unique = false)
    public String processCd;

    /** 工程名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String processNm;

    /** ラインNo */
    @Column(length = 32, nullable = true, unique = false)
    public String lnNo;

    /** ライン名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String lnNm;

    /** ステーションNo */
    @Column(length = 8, nullable = true, unique = false)
    public String stNo;

    /** ステーション名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String stNm;

    /** ｵﾝﾗｲﾝﾌﾗｸﾞ */
    @Column(precision = 1, nullable = true, unique = false)
    public BigDecimal onlineFlg;

    /** 状態コード */
    @Column(length = 10, nullable = true, unique = false)
    public String stsCd;

    /** アラームコード */
    @Column(length = 10, nullable = true, unique = false)
    public String almCd;

    /** 定期保全回数 */
    @Column(precision = 8, nullable = true, unique = false)
    public BigDecimal mainteSkdCnt;

    /** 保全回数 */
    @Column(precision = 8, nullable = true, unique = false)
    public BigDecimal mainteCnt;

    /** 総合稼働時間(秒) */
    @Column(precision = 11, nullable = true, unique = false)
    public BigDecimal uptime;

    /** 数字予備1 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum1;

    /** 数字予備2 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum2;

    /** 数字予備3 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum3;

    /** 文字予備1 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText1;

    /** 文字予備2 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText2;

    /** 文字予備3 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText3;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
