/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2017/03/09| 新規作成                           | C1.01  | H.Nakamura
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.dao;

import java.util.List;

import javax.transaction.TransactionManager;

import jp.ysk.fw.FW00_12_AppException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.visualization.common.dto.CM_ErpDbAccessDto;
import jp.ysk.mmcloud.visualization.common.util.CM_ErpDbAccessManager;

import org.seasar.extension.jdbc.JdbcManager;
import org.seasar.framework.beans.util.BeanMap;

/**
 * ERPスキーマ用共通Dao.<br>
 *<br>
 * 概要:<br>
 *   ERPスキーマのDBにアクセスするための共通Daoクラス
 *<br>
 */
public abstract class CM_BaseErpSchemaDao {

    /**
     * JDBCマネージャー(ERPスキーマ).
     */
    protected JdbcManager jdbcManager;

    /**
     * トランザクション(ERPスキーマ).
     */
    protected TransactionManager transactionMng;

    /**
     * SQLファイルパス(共通).
     */
    public static final String SQL_PATH_COMM = "jp/ysk/mmcloud/visualization/batch/sql/";

    /**
     * コンストラクタ.
     */
    public CM_BaseErpSchemaDao() {
    }

    /**
     *
     * コンストラクタ.<br>
     *<br>
     * @param _strConnectString ERP-DB接続情報
     * @param _strConnectUserName ERP-DBユーザ名
     * @param _strConnectPasswd ERP-DBパスワード
     */
    public CM_BaseErpSchemaDao(
            final String _strConnectString,
            final String _strConnectUserName,
            final String _strConnectPasswd) {

        CM_ErpDbAccessDto erpDbAccess = CM_ErpDbAccessManager.getErpDbAccess(
                _strConnectString,
                _strConnectUserName,
                _strConnectPasswd);

        this.jdbcManager = erpDbAccess.jdbcManager;
        this.transactionMng = erpDbAccess.userTransactionMng;

    }

    /**
     *
     * 初期化.<br>
     *<br>
     * 概要:<br>
     *   初期化処理を実行する
     *<br>
     * @param _strConnectString ERP-DB接続情報
     * @param _strConnectUserId ERP-DBユーザID
     * @param _strConnectPasswd ERP-DBパスワード
     */
    public void setErpDbInfo(final String _strConnectString,
            final String _strConnectUserId,
            final String _strConnectPasswd) {

        CM_ErpDbAccessDto customerDbAccess = CM_ErpDbAccessManager.getErpDbAccess(
                _strConnectString,
                _strConnectUserId,
                _strConnectPasswd);

        this.jdbcManager = customerDbAccess.jdbcManager;
        this.transactionMng = customerDbAccess.userTransactionMng;

    }

    /**
     *
     * ERP-DBトランザクション開始処理.<br>
     *<br>
     * 概要:<br>
     *   ERP-DBトランザクション開始処理を実行する
     *<br>
     */
    public void biginTransaction() {

        try {
            this.transactionMng.begin();

        } catch (Exception ex) {
            CM_LoggerUtil.outputErrorLog(null, ex);
            throw new FW00_12_AppException(FW00_19_Const.EMPTY_STR);
        }
    }

    /**
     *
     * ERP-DBトランザクションコミット処理.<br>
     *<br>
     * 概要:<br>
     *   ERP-DBトランザクションコミット処理を実行する
     *<br>
     */
    public void commitTransaction() {

        try {
            this.transactionMng.commit();

        } catch (Exception ex) {
            CM_LoggerUtil.outputErrorLog(null, ex);
            throw new FW00_12_AppException(FW00_19_Const.EMPTY_STR);
        }
    }

    /**
     *
     * ERP-DBトランザクションロールバック処理.<br>
     *<br>
     * 概要:<br>
     *   ERP-DBトランザクションロールバック処理を実行する
     *<br>
     */
    public void rollbackTransaction() {

        try {
            this.transactionMng.rollback();

        } catch (Exception ex) {
            CM_LoggerUtil.outputErrorLog(null, ex);
            throw new FW00_12_AppException(FW00_19_Const.EMPTY_STR);
        }
    }

    /**
     *
     * ERPデータ取得.<br>
     *<br>
     * 概要:<br>
     * 登録するERPデータを取得する
     *<br>
     * @param _sqlFileName SQLファイル名
     * @param _param パラメータ
     * @return 登録するERPデータ
     */
    public List<BeanMap> selectErpData(final String _sqlFileName, final BeanMap _param) {

        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(BeanMap.class, SQL_PATH_COMM + _sqlFileName, _param).getResultList();

        return ret;
    }

    /**
     *
     * ERPデータ件数取得.<br>
     *<br>
     * 概要:<br>
     * 登録対象のERPデータ件数を取得する
     *<br>
     * @param _sqlFileName SQLファイル名
     * @param _param パラメータ
     * @return 登録対象のERPデータ件数
     */
    public long checkErpData(final String _sqlFileName, final BeanMap _param) {

        long ret = this.jdbcManager.getCountBySqlFile(SQL_PATH_COMM + _sqlFileName, _param);

        return ret;
    }

}
