package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link TrSearchConditionEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class TrSearchConditionEntityNames {

    /**
     * userSidのプロパティ名を返します。
     * 
     * @return userSidのプロパティ名
     */
    public static PropertyName<Integer> userSid() {
        return new PropertyName<Integer>("userSid");
    }

    /**
     * pageIdのプロパティ名を返します。
     * 
     * @return pageIdのプロパティ名
     */
    public static PropertyName<String> pageId() {
        return new PropertyName<String>("pageId");
    }

    /**
     * conditionNumのプロパティ名を返します。
     * 
     * @return conditionNumのプロパティ名
     */
    public static PropertyName<Integer> conditionNum() {
        return new PropertyName<Integer>("conditionNum");
    }

    /**
     * paramNameのプロパティ名を返します。
     * 
     * @return paramNameのプロパティ名
     */
    public static PropertyName<String> paramName() {
        return new PropertyName<String>("paramName");
    }

    /**
     * paramValueのプロパティ名を返します。
     * 
     * @return paramValueのプロパティ名
     */
    public static PropertyName<String> paramValue() {
        return new PropertyName<String>("paramValue");
    }

    /**
     * favoriteNoのプロパティ名を返します。
     * 
     * @return favoriteNoのプロパティ名
     */
    public static PropertyName<Integer> favoriteNo() {
        return new PropertyName<Integer>("favoriteNo");
    }

    /**
     * favoriteNameのプロパティ名を返します。
     * 
     * @return favoriteNameのプロパティ名
     */
    public static PropertyName<String> favoriteName() {
        return new PropertyName<String>("favoriteName");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _TrSearchConditionNames extends PropertyName<TrSearchConditionEntity> {

        /**
         * インスタンスを構築します。
         */
        public _TrSearchConditionNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _TrSearchConditionNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _TrSearchConditionNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * userSidのプロパティ名を返します。
         *
         * @return userSidのプロパティ名
         */
        public PropertyName<Integer> userSid() {
            return new PropertyName<Integer>(this, "userSid");
        }

        /**
         * pageIdのプロパティ名を返します。
         *
         * @return pageIdのプロパティ名
         */
        public PropertyName<String> pageId() {
            return new PropertyName<String>(this, "pageId");
        }

        /**
         * conditionNumのプロパティ名を返します。
         *
         * @return conditionNumのプロパティ名
         */
        public PropertyName<Integer> conditionNum() {
            return new PropertyName<Integer>(this, "conditionNum");
        }

        /**
         * paramNameのプロパティ名を返します。
         *
         * @return paramNameのプロパティ名
         */
        public PropertyName<String> paramName() {
            return new PropertyName<String>(this, "paramName");
        }

        /**
         * paramValueのプロパティ名を返します。
         *
         * @return paramValueのプロパティ名
         */
        public PropertyName<String> paramValue() {
            return new PropertyName<String>(this, "paramValue");
        }

        /**
         * favoriteNoのプロパティ名を返します。
         *
         * @return favoriteNoのプロパティ名
         */
        public PropertyName<Integer> favoriteNo() {
            return new PropertyName<Integer>(this, "favoriteNo");
        }

        /**
         * favoriteNameのプロパティ名を返します。
         *
         * @return favoriteNameのプロパティ名
         */
        public PropertyName<String> favoriteName() {
            return new PropertyName<String>(this, "favoriteName");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
