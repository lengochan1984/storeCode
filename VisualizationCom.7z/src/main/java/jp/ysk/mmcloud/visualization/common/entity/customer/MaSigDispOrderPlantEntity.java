package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * サイネージ表示順序（工場別）
 * 
 */
@Entity
@Table(name = "ma_sig_disp_order_plant")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class MaSigDispOrderPlantEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** サイネージID */
    @Id
    @Column(length = 33, nullable = false, unique = false)
    public String signageId;

    /** プラントコード */
    @Id
    @Column(length = 10, nullable = false, unique = false)
    public String plantCd;

    /** 表示順序 */
    @Id
    @Column(precision = 10, nullable = false, unique = false)
    public Integer displayOrder;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
