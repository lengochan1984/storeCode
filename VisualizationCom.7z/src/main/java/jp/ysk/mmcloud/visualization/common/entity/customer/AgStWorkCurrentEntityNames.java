package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link AgStWorkCurrentEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class AgStWorkCurrentEntityNames {

    /**
     * stIdのプロパティ名を返します。
     * 
     * @return stIdのプロパティ名
     */
    public static PropertyName<BigDecimal> stId() {
        return new PropertyName<BigDecimal>("stId");
    }

    /**
     * updDateのプロパティ名を返します。
     * 
     * @return updDateのプロパティ名
     */
    public static PropertyName<Timestamp> updDate() {
        return new PropertyName<Timestamp>("updDate");
    }

    /**
     * scheduleNumのプロパティ名を返します。
     * 
     * @return scheduleNumのプロパティ名
     */
    public static PropertyName<Integer> scheduleNum() {
        return new PropertyName<Integer>("scheduleNum");
    }

    /**
     * actualNumのプロパティ名を返します。
     * 
     * @return actualNumのプロパティ名
     */
    public static PropertyName<Integer> actualNum() {
        return new PropertyName<Integer>("actualNum");
    }

    /**
     * planNumのプロパティ名を返します。
     * 
     * @return planNumのプロパティ名
     */
    public static PropertyName<Integer> planNum() {
        return new PropertyName<Integer>("planNum");
    }

    /**
     * predictionCompletionTimeのプロパティ名を返します。
     * 
     * @return predictionCompletionTimeのプロパティ名
     */
    public static PropertyName<Timestamp> predictionCompletionTime() {
        return new PropertyName<Timestamp>("predictionCompletionTime");
    }

    /**
     * planCompletionTimeのプロパティ名を返します。
     * 
     * @return planCompletionTimeのプロパティ名
     */
    public static PropertyName<Timestamp> planCompletionTime() {
        return new PropertyName<Timestamp>("planCompletionTime");
    }

    /**
     * preRetentionNumのプロパティ名を返します。
     * 
     * @return preRetentionNumのプロパティ名
     */
    public static PropertyName<Integer> preRetentionNum() {
        return new PropertyName<Integer>("preRetentionNum");
    }

    /**
     * retentionNumのプロパティ名を返します。
     * 
     * @return retentionNumのプロパティ名
     */
    public static PropertyName<Integer> retentionNum() {
        return new PropertyName<Integer>("retentionNum");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _AgStWorkCurrentNames extends PropertyName<AgStWorkCurrentEntity> {

        /**
         * インスタンスを構築します。
         */
        public _AgStWorkCurrentNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _AgStWorkCurrentNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _AgStWorkCurrentNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * stIdのプロパティ名を返します。
         *
         * @return stIdのプロパティ名
         */
        public PropertyName<BigDecimal> stId() {
            return new PropertyName<BigDecimal>(this, "stId");
        }

        /**
         * updDateのプロパティ名を返します。
         *
         * @return updDateのプロパティ名
         */
        public PropertyName<Timestamp> updDate() {
            return new PropertyName<Timestamp>(this, "updDate");
        }

        /**
         * scheduleNumのプロパティ名を返します。
         *
         * @return scheduleNumのプロパティ名
         */
        public PropertyName<Integer> scheduleNum() {
            return new PropertyName<Integer>(this, "scheduleNum");
        }

        /**
         * actualNumのプロパティ名を返します。
         *
         * @return actualNumのプロパティ名
         */
        public PropertyName<Integer> actualNum() {
            return new PropertyName<Integer>(this, "actualNum");
        }

        /**
         * planNumのプロパティ名を返します。
         *
         * @return planNumのプロパティ名
         */
        public PropertyName<Integer> planNum() {
            return new PropertyName<Integer>(this, "planNum");
        }

        /**
         * predictionCompletionTimeのプロパティ名を返します。
         *
         * @return predictionCompletionTimeのプロパティ名
         */
        public PropertyName<Timestamp> predictionCompletionTime() {
            return new PropertyName<Timestamp>(this, "predictionCompletionTime");
        }

        /**
         * planCompletionTimeのプロパティ名を返します。
         *
         * @return planCompletionTimeのプロパティ名
         */
        public PropertyName<Timestamp> planCompletionTime() {
            return new PropertyName<Timestamp>(this, "planCompletionTime");
        }

        /**
         * preRetentionNumのプロパティ名を返します。
         *
         * @return preRetentionNumのプロパティ名
         */
        public PropertyName<Integer> preRetentionNum() {
            return new PropertyName<Integer>(this, "preRetentionNum");
        }

        /**
         * retentionNumのプロパティ名を返します。
         *
         * @return retentionNumのプロパティ名
         */
        public PropertyName<Integer> retentionNum() {
            return new PropertyName<Integer>(this, "retentionNum");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
