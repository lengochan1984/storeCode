/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/06/02| <C1.01>　新規作成                                                    | C1.01  | カイン
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.action;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.common.util.CM_MessageResourceUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.CM_A06_TabInfo;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;
import jp.ysk.mmcloud.visualization.common.form.CM_TabForm;
import jp.ysk.mmcloud.visualization.common.service.CM_TabService;
import jp.ysk.mmcloud.visualization.common.util.CM_CommonUtil;

import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.beans.util.Beans;
import org.seasar.framework.exception.SQLRuntimeException;
import org.seasar.struts.annotation.Execute;

/**
 *
 * タブがある画面用アクション基底クラス.<br>
 *<br8
 * 概要:<br>
 *  タブがある画面用アクションの共通基底クラス
 *<br>
 */
public abstract class CM_A05_TabReportAction extends CM_A04_ListBaseReportAction {

    /**
     * 各タブの表示処理の共通メソッド名.
     */
    protected static final String COMMON_DISPLAY_METHOD_NAME = "Display";

    /**
     *
     * タブ切り替え処理.<br>
     *<br>
     * 概要:<br>
     * タブ切り替え処理
     *<br>
     * @return jsp
     */
    @Execute(validator = false)
    public String toggleTab() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        // サービスの初期化
        this.getService().init(this.cM_A03_SessionDto);

        // 次画面に対する権限取得
        this.getNextPageAuth();

        // 共通設定
        this.commonSetting();

        // 表示処理
        String ret = this.display();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, ret);

        return ret;
    }

    /**
     *
     * 表示データ作成処理.<br>
     *<br>
     * 概要:<br>
     *  表示データ作成処理を実行する<br>
     *  タブ内の表示が一覧の場合、this.listDisplayを呼び出し、一覧共通処理を実行する<br>
     *  タブ内の表示が一覧以外の場合、各画面Actionで実装されているtabId + 「Display」を呼び出す<br>
     *  　例：タブIDがoperationStatusの場合、 operationStatusDisplayのメソッドをActionから呼び出す
     *<br>
     * @return 画面のJSP
     */
    @Override
    protected String display() {

        CM_TabForm tabForm = (CM_TabForm) this.getActionForm();

        // 初期化

        // 日時情報更新処理
        this.setDisplayDateData(tabForm);

        // 詳細検索条件情報を取得
        Map<String, Object> mapSearchCondInfo =
                this.getComDetailSearchInfo(getPageId(), tabForm);

        CM_TabService service = this.getService();

        // ソートキー取得
        this.sortKeyNameMap = service.getSortKeyNames();

        // 検索前処理
        this.preDisplay();

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();
        // フォーム情報にユーザの言語コードを設定
        formMap.put(CM_A04_Const.SQL_PARAM.LOGIN_USER_LANG_CD, this.cM_A03_SessionDto.ssn_UserLangCD);

        // まだセッションに格納されていないメンバの初期化
        initFormMap(formMap);

        // タブIDごとの処理
        CM_A06_TabInfo tabInfo = null;
        if (CM_CommonUtil.isNullOrBlank(tabForm.hdnTabId)) {
            tabInfo = this.getDefaultTabInfo();
            tabForm.hdnTabId = tabInfo.getTabId();
        } else {
            tabInfo = CM_A06_TabInfo.getTabInfo(tabForm.hdnTabId);
        }

        // サービスにタブ情報を設定
        service.setTabInfo(tabInfo);

        // 入力チェック
        String validation = this.validate(formMap, mapSearchCondInfo);
        if (CM_CommonUtil.isNotNullOrBlank(validation)) {
            if (tabInfo.isListFlag()) {
                // 総ページ数
                this.calcPage(this.getActionForm(), 0);
            }
            return validation;
        }

        if (tabInfo.isListFlag()) {
            // 一覧のタブ画面の場合の処理
            this.listDisplay(formMap, mapSearchCondInfo);

        } else {
            // 一覧以外のタブ画面の場合の処理
            try {
                // tabId + 「Display」のメソッドを呼び出し処理 例：タブIDがoperationStatusの場合、 operationStatusDisplayのメソッドをActionから実行する
                Method method = this.getClass().getMethod(tabInfo.getTabId() + COMMON_DISPLAY_METHOD_NAME, new Class[]{BeanMap.class});
                method.invoke(this, new Object[]{formMap});

            } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
                CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, e, "");
            }
        }

        // 検索後処理
        this.afterDisplay(formMap);

        return getJspFileName();
    }

    /**
    *
    * formMapの初期化.<br/>
    * <br/>
    * 概要:<br/>
    *  セッションに登録されていないメンバの初期化<br/>
    * <br/>
    * @param _formMap フォーム情報
    */
    private void initFormMap(final BeanMap _formMap) {
        // 工場
        if (CM_CommonUtil.isNullOrBlank(_formMap.get(CM_BaseForm.COM_PLANT_CODE))) {
            _formMap.put(CM_BaseForm.COM_PLANT_CODE, null);
        }

        // 製造ライン（グループ）
        if (CM_CommonUtil.isNullOrBlank(_formMap.get(CM_BaseForm.COM_SEIZOU_LN_ID))) {
            _formMap.put(CM_BaseForm.COM_SEIZOU_LN_ID, null);
        }

        // 工程
        if (CM_CommonUtil.isNullOrBlank(_formMap.get(CM_BaseForm.COM_PROCESS_ID))) {
            _formMap.put(CM_BaseForm.COM_PROCESS_ID, null);
        }

        // ライン
        if (CM_CommonUtil.isNullOrBlank(_formMap.get(CM_BaseForm.COM_LN_ID))) {
            _formMap.put(CM_BaseForm.COM_LN_ID, null);
        }

        // ST
        if (CM_CommonUtil.isNullOrBlank(_formMap.get(CM_BaseForm.COM_ST_ID))) {
            _formMap.put(CM_BaseForm.COM_ST_ID, null);
        }
    }

    /**
     *
     * 入力チェック処理.<br/>
     * <br/>
     * 概要:<br/>
     *  入力チェック処理を行う。<br/>
     * <br/>
     * @param _formMap フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return エラーAjaxJSP名
     */
    private String validate(final BeanMap _formMap, final Map<String, Object> _mapSearchCondInfo) {
        String res = null;

        try {
            // 入力チェック
            this.getService().validate(_formMap, _mapSearchCondInfo);

        } catch (FW00_12_BusinessException be) {
            // 例外発生時はエラーメッセージ表示
            return this.alertErrorInfo(this.getJspFileName(), be.getMsgKey(), be.getFocusCtlId());

        } catch (SQLRuntimeException re) {
            // SQLエラー時はエラーをスローする
            throw re;
        } catch (Exception e) {
            // 例外発生時はエラーメッセージ表示
            String strErrorMes = CM_MessageResourceUtil.getMessageValue(this.cM_A03_SessionDto.ssn_CustomerCD,
                    this.cM_A03_SessionDto.ssn_UserLangCD, "MMCMCM00000_024");

            // 例外情報はログ出力
            CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, e);

            return this.alertErrorInfo(this.getJspFileName(), strErrorMes, null);
        }

        return res;
    }

    /**
     *
     * 入力チェック処理.<br/>
     * <br/>
     * 概要:<br/>
     *  入力チェック処理を行う。<br/>
     * <br/>
     * @param _formMap フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return エラーAjaxJSP名
     */
    private String csvValidate(final BeanMap _formMap, final Map<String, Object> _mapSearchCondInfo) {
        String res = null;

        try {
            // 入力チェック
            this.getService().csvValidate(_formMap, _mapSearchCondInfo);

        } catch (FW00_12_BusinessException be) {
            // 例外発生時はエラーメッセージ表示
            return this.alertErrorInfoForAjax(be.getMsgKey(), be.getFocusCtlId());

        } catch (SQLRuntimeException re) {
            // SQLエラー時はエラーをスローする
            throw re;
        } catch (Exception e) {
            // 例外発生時はエラーメッセージ表示
            String strErrorMes = CM_MessageResourceUtil.getMessageValue(this.cM_A03_SessionDto.ssn_CustomerCD,
                    this.cM_A03_SessionDto.ssn_UserLangCD, "MMCMCM00000_003");

            // 例外情報はログ出力
            CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, e);

            return this.alertErrorInfoForAjax(strErrorMes, null);
        }

        return res;
    }

    /**
     *
     * CSVダウンロードチェック前処理.<br/>
     *<br/>
     * 概要:<br/>
     *  CSVダウンロードチェックの前処理を行う。<br/>
     *<br/>
     * @param _formMap Form情報
     * @param _mapSearchCondInfo 詳細検索情報
     */
    @Override
    protected void beforeCheckCSVDownload(final BeanMap _formMap, final Map<String, Object> _mapSearchCondInfo) {
        this.loadTabInfo();
    }

    /**
     *
     * CSVダウンロード用入力チェック処理.<br/>
     *<br/>
     * 概要:<br/>
     *  CSVダウンロード用入力チェック処理を行う。<br/>
     *<br/>
     * @param _formMap Form情報
     * @param _mapSearchCondInfo 詳細検索情報
     * @return エラーAjaxJSPファイル
     */
    @Override
    protected String csvValidation(final BeanMap _formMap, final Map<String, Object> _mapSearchCondInfo) {
        return this.csvValidate(_formMap, _mapSearchCondInfo);
    }

    /**
     *
     * CSV出力検索条件値取得.<br>
     *<br>
     * 概要:<br>
     *   CSVに出力する検索条件の値を取得
     *<br>
     * @param _formMap フォーム情報
     * @return CSV出力検索条件値
     */
    @Override
    protected Map<String, String> getCsvSearchConditionData(final BeanMap _formMap) {
        this.loadTabInfo();
        Map<String, String> ret = this.getService().getCsvSearchConditionData(_formMap);
        return ret;
    }

    /**
     *
     * タブ情報取得処理.<br/>
     *<br/>
     * 概要:<br/>
     *  タブ情報取得を行う。<br/>
     *<br/>
     */
    protected void loadTabInfo() {
        CM_TabForm tabForm = (CM_TabForm) this.getActionForm();

        CM_TabService service = this.getService();

        // タブIDごとの処理
        CM_A06_TabInfo tabInfo = null;
        if (CM_CommonUtil.isNullOrBlank(tabForm.hdnTabId)) {
            tabInfo = this.getDefaultTabInfo();
            tabForm.hdnTabId = tabInfo.getTabId();
        } else {
            tabInfo = CM_A06_TabInfo.getTabInfo(tabForm.hdnTabId);
        }
        // サービスにタブ情報を設定
        service.setTabInfo(tabInfo);
    }

    /**
     *
     * 一覧表示用処理.<br>
     *<br>
     * 概要:<br>
     * 一覧表示用処理<br>
     * service.getDataCountで件数を取得後、
     * service.getDataListで一覧を取得する
     *<br>
     * @param _formMap フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     */
    protected void listDisplay(final BeanMap _formMap, final Map<String, Object> _mapSearchCondInfo) {

        // 検索前処理
        this.getService().preGetData(_formMap, _mapSearchCondInfo);

        // 条件に該当する全件数取得を行う
        long listCnt = this.getService().getDataCount(_formMap, _mapSearchCondInfo);

        // 総ページ数の算出
        this.calcPage(this.getActionForm(), listCnt);

        // 表示件数が0件以外の場合は、一覧表示のデータ抽出を行う
        if (listCnt > 0) {
            // 一覧情報取得を行う
            this.listData = this.getService().getDataList(_formMap, _mapSearchCondInfo, this.getOffsetInfo(this.getActionForm()));
        }
    }

    /**
     *
     * 遷移前データ復帰処理.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _data 遷移前データ
     */
    @Override
    protected void setReturnDispInfo(final HashMap<String, Object> _data) {
        super.setReturnDispInfo(_data);
        this.getActionForm().hdnTabId = _data.get(CM_TabForm.CM_TABFORM_HDN_TAB_ID).toString();
    }

    /**
     * 画面のサービスを取得.<br>
     * <br>
     * 概要:<br>
     * 各画面のサービスを取得<br>
     * 各画面のアクションで実装し、サービスを設定する
     *
     * @return 画面のサービス
     */
    @Override
    protected abstract CM_TabService getService();

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.common.action.CM_A03_ListAction#getActionForm()
     */
    @Override
    protected abstract CM_TabForm getActionForm();

    /**
     *
     * JSPファイル名取得.<br>
     *<br>
     * 概要:<br>
     *　JSPファイル名を取得
     *<br>
     * @return JSPファイル名
     */
    @Override
    protected abstract String getJspFileName();

    /**
     *
     * デフォルトのタブ情報を取得.<br>
     *<br>
     * 概要:<br>
     * パラメータからタブIDが取得できなかった場合に表示するタブID情報を取得する
     *<br>
     * @return デフォルトタブ情報
     */
    protected abstract CM_A06_TabInfo getDefaultTabInfo();

}
