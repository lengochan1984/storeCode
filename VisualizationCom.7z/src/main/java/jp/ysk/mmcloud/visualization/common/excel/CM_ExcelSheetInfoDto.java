/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/01| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.excel;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * Excelシートフォーマット情報.<br>
 *<br>
 * 概要:<br>
 *  EXCELのシート単位でのフォーマット情報
 *<br>
 */
public class CM_ExcelSheetInfoDto implements Cloneable {

    /**
     * シート名.
     */
    private String sheetName;

    /**
     * 検索条件出力開始行.<br>
     * デフォルト：1
     */
    private int conditionStartRaw = 1;

    /**
     * 検索条件出力開始列.<br>
     * デフォルト：0
     */
    private int conditionStartCell = 0;

    /**
     * 凡例出力開始行.<br>
     * デフォルト：3
     */
    private int legendStartRaw = 3;

    /**
     * 凡例出力開始列.<br>
     * デフォルト:0
     */
    private int legendStartCell = 0;

    /**
     * データ出力開始行.<br>
     * デフォルト：4
     */
    private int dataStartRaw = 4;

    /**
     * データ出力開始列.<br>
     * デフォルト：0
     */
    private int dataStartCell = 0;

    /**
     * 出力データを取得するメソッド名.<br>
     * ※サービスに実装しているメソッド名を設定する<br>
     * 　定義したメソッドを必ずServiceに実装すること
     */
    private String getDataMethodName;

    /**
     * データフォーマット情報一覧.
     */
    List<CM_ExcelDataInfoDto> dataInfoList = new ArrayList<CM_ExcelDataInfoDto>();

    /**
     * シート名を取得.
     *
     * @return シート名
     */
    public String getSheetName() {
        return this.sheetName;
    }

    /**
     * シート名を設定する.
     *
     * @param _sheetName シート名
     */
    public void setSheetName(final String _sheetName) {
        this.sheetName = _sheetName;
    }

    /**
     * 検索条件出力開始行を取得.
     *
     * @return conditionStartRaw
     */
    public int getConditionStartRaw() {
        return this.conditionStartRaw;
    }

    /**
     * 検索条件出力開始行を設定する.
     *
     * @param _conditionStartRaw 検索条件出力開始行
     */
    public void setConditionStartRaw(final int _conditionStartRaw) {
        this.conditionStartRaw = _conditionStartRaw;
    }

    /**
     * 検索条件出力開始列を取得.
     *
     * @return 検索条件出力開始列
     */
    public int getConditionStartCell() {
        return this.conditionStartCell;
    }

    /**
     * 検索条件出力開始列を設定する.
     *
     * @param _conditionStartCell 検索条件出力開始列
     */
    public void setConditionStartCell(final int _conditionStartCell) {
        this.conditionStartCell = _conditionStartCell;
    }

    /**
     * 凡例出力開始行を取得.
     *
     * @return 凡例出力開始行
     */
    public int getLegendStartRaw() {
        return this.legendStartRaw;
    }

    /**
     * 凡例出力開始行を設定する.
     *
     * @param _legendStartRaw 凡例出力開始行
     */
    public void setLegendStartRaw(final int _legendStartRaw) {
        this.legendStartRaw = _legendStartRaw;
    }

    /**
     * 凡例出力開始列を取得.
     *
     * @return 凡例出力開始列
     */
    public int getLegendStartCell() {
        return this.legendStartCell;
    }

    /**
     * 凡例出力開始列を設定する.
     *
     * @param _legendStartCell 凡例出力開始列
     */
    public void setLegendStartCell(final int _legendStartCell) {
        this.legendStartCell = _legendStartCell;
    }

    /**
     * データ出力開始行を取得.
     *
     * @return データ出力開始行
     */
    public int getDataStartRaw() {
        return this.dataStartRaw;
    }

    /**
     * データ出力開始行を設定する.
     *
     * @param _dataStartRaw データ出力開始行
     */
    public void setDataStartRaw(final int _dataStartRaw) {
        this.dataStartRaw = _dataStartRaw;
    }

    /**
     * データ出力開始列を取得.
     *
     * @return データ出力開始列
     */
    public int getDataStartCell() {
        return this.dataStartCell;
    }

    /**
     * データ出力開始列を設定する.
     *
     * @param _dataStartCell データ出力開始列
     */
    public void setDataStartCell(final int _dataStartCell) {
        this.dataStartCell = _dataStartCell;
    }

    /**
     * 出力データを取得するメソッド名を取得.
     *
     * @return 出力データを取得するメソッド名
     */
    public String getGetDataMethodName() {
        return this.getDataMethodName;
    }

    /**
     * 出力データを取得するメソッド名を設定する.
     *
     * @param _getDataMethodName 出力データを取得するメソッド名
     */
    public void setGetDataMethodName(final String _getDataMethodName) {
        this.getDataMethodName = _getDataMethodName;
    }

    /**
     * データフォーマット情報一覧を取得.
     *
     * @return データフォーマット情報一覧
     */
    public List<CM_ExcelDataInfoDto> getDataInfoList() {
        return this.dataInfoList;
    }

    /**
     * データフォーマット情報一覧を設定する.
     *
     * @param _dataInfoList データフォーマット情報一覧
     */
    public void setDataInfoList(final List<CM_ExcelDataInfoDto> _dataInfoList) {
        this.dataInfoList = _dataInfoList;
    }

    /**
     *
     * データフォーマット情報をデータフォーマット情報一覧に設定.<br>
     *<br>
     * 概要:<br>
     *   データフォーマット情報をデータフォーマット情報一覧に設定する
     *<br>
     * @param _dataInfo データフォーマット情報
     */
    public void addDataInfo(final CM_ExcelDataInfoDto _dataInfo) {
        this.dataInfoList.add(_dataInfo);
    }

    @Override
    public CM_ExcelSheetInfoDto clone() {
        try {
            CM_ExcelSheetInfoDto newOjb = (CM_ExcelSheetInfoDto) super.clone();
            List<CM_ExcelDataInfoDto> newDataInfoList = new ArrayList<CM_ExcelDataInfoDto>();
            newOjb.setDataInfoList(newDataInfoList);
            for (CM_ExcelDataInfoDto dataDto : this.dataInfoList) {
                newDataInfoList.add(dataDto.clone());
            }
            return newOjb;
        } catch (CloneNotSupportedException e) {
            throw new InternalError(e.toString());
        }
    }
}
