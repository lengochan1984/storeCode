package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link TrRepairLogEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class TrRepairLogEntityNames {

    /**
     * createdOnのプロパティ名を返します。
     * 
     * @return createdOnのプロパティ名
     */
    public static PropertyName<Timestamp> createdOn() {
        return new PropertyName<Timestamp>("createdOn");
    }

    /**
     * createdByのプロパティ名を返します。
     * 
     * @return createdByのプロパティ名
     */
    public static PropertyName<String> createdBy() {
        return new PropertyName<String>("createdBy");
    }

    /**
     * modifiedOnのプロパティ名を返します。
     * 
     * @return modifiedOnのプロパティ名
     */
    public static PropertyName<Timestamp> modifiedOn() {
        return new PropertyName<Timestamp>("modifiedOn");
    }

    /**
     * modifiedByのプロパティ名を返します。
     * 
     * @return modifiedByのプロパティ名
     */
    public static PropertyName<String> modifiedBy() {
        return new PropertyName<String>("modifiedBy");
    }

    /**
     * repairNoのプロパティ名を返します。
     * 
     * @return repairNoのプロパティ名
     */
    public static PropertyName<BigDecimal> repairNo() {
        return new PropertyName<BigDecimal>("repairNo");
    }

    /**
     * sasizuNoのプロパティ名を返します。
     * 
     * @return sasizuNoのプロパティ名
     */
    public static PropertyName<String> sasizuNo() {
        return new PropertyName<String>("sasizuNo");
    }

    /**
     * subNoのプロパティ名を返します。
     * 
     * @return subNoのプロパティ名
     */
    public static PropertyName<BigDecimal> subNo() {
        return new PropertyName<BigDecimal>("subNo");
    }

    /**
     * sagyoSeqのプロパティ名を返します。
     * 
     * @return sagyoSeqのプロパティ名
     */
    public static PropertyName<String> sagyoSeq() {
        return new PropertyName<String>("sagyoSeq");
    }

    /**
     * buhinCdのプロパティ名を返します。
     * 
     * @return buhinCdのプロパティ名
     */
    public static PropertyName<String> buhinCd() {
        return new PropertyName<String>("buhinCd");
    }

    /**
     * katasikiのプロパティ名を返します。
     * 
     * @return katasikiのプロパティ名
     */
    public static PropertyName<String> katasiki() {
        return new PropertyName<String>("katasiki");
    }

    /**
     * seihinSnのプロパティ名を返します。
     * 
     * @return seihinSnのプロパティ名
     */
    public static PropertyName<String> seihinSn() {
        return new PropertyName<String>("seihinSn");
    }

    /**
     * occurTimeのプロパティ名を返します。
     * 
     * @return occurTimeのプロパティ名
     */
    public static PropertyName<Timestamp> occurTime() {
        return new PropertyName<Timestamp>("occurTime");
    }

    /**
     * lnIdのプロパティ名を返します。
     * 
     * @return lnIdのプロパティ名
     */
    public static PropertyName<BigDecimal> lnId() {
        return new PropertyName<BigDecimal>("lnId");
    }

    /**
     * stIdのプロパティ名を返します。
     * 
     * @return stIdのプロパティ名
     */
    public static PropertyName<BigDecimal> stId() {
        return new PropertyName<BigDecimal>("stId");
    }

    /**
     * plantCdのプロパティ名を返します。
     * 
     * @return plantCdのプロパティ名
     */
    public static PropertyName<String> plantCd() {
        return new PropertyName<String>("plantCd");
    }

    /**
     * seizouLnCdのプロパティ名を返します。
     * 
     * @return seizouLnCdのプロパティ名
     */
    public static PropertyName<String> seizouLnCd() {
        return new PropertyName<String>("seizouLnCd");
    }

    /**
     * seizouLnNmのプロパティ名を返します。
     * 
     * @return seizouLnNmのプロパティ名
     */
    public static PropertyName<String> seizouLnNm() {
        return new PropertyName<String>("seizouLnNm");
    }

    /**
     * processCdのプロパティ名を返します。
     * 
     * @return processCdのプロパティ名
     */
    public static PropertyName<String> processCd() {
        return new PropertyName<String>("processCd");
    }

    /**
     * processNmのプロパティ名を返します。
     * 
     * @return processNmのプロパティ名
     */
    public static PropertyName<String> processNm() {
        return new PropertyName<String>("processNm");
    }

    /**
     * lnNoのプロパティ名を返します。
     * 
     * @return lnNoのプロパティ名
     */
    public static PropertyName<String> lnNo() {
        return new PropertyName<String>("lnNo");
    }

    /**
     * lnNmのプロパティ名を返します。
     * 
     * @return lnNmのプロパティ名
     */
    public static PropertyName<String> lnNm() {
        return new PropertyName<String>("lnNm");
    }

    /**
     * stNoのプロパティ名を返します。
     * 
     * @return stNoのプロパティ名
     */
    public static PropertyName<String> stNo() {
        return new PropertyName<String>("stNo");
    }

    /**
     * stNmのプロパティ名を返します。
     * 
     * @return stNmのプロパティ名
     */
    public static PropertyName<String> stNm() {
        return new PropertyName<String>("stNm");
    }

    /**
     * sagyokuのプロパティ名を返します。
     * 
     * @return sagyokuのプロパティ名
     */
    public static PropertyName<String> sagyoku() {
        return new PropertyName<String>("sagyoku");
    }

    /**
     * equipCdのプロパティ名を返します。
     * 
     * @return equipCdのプロパティ名
     */
    public static PropertyName<String> equipCd() {
        return new PropertyName<String>("equipCd");
    }

    /**
     * almCdのプロパティ名を返します。
     * 
     * @return almCdのプロパティ名
     */
    public static PropertyName<String> almCd() {
        return new PropertyName<String>("almCd");
    }

    /**
     * repairKaisuのプロパティ名を返します。
     * 
     * @return repairKaisuのプロパティ名
     */
    public static PropertyName<BigDecimal> repairKaisu() {
        return new PropertyName<BigDecimal>("repairKaisu");
    }

    /**
     * stepNoのプロパティ名を返します。
     * 
     * @return stepNoのプロパティ名
     */
    public static PropertyName<String> stepNo() {
        return new PropertyName<String>("stepNo");
    }

    /**
     * seihinLnのプロパティ名を返します。
     * 
     * @return seihinLnのプロパティ名
     */
    public static PropertyName<String> seihinLn() {
        return new PropertyName<String>("seihinLn");
    }

    /**
     * testDefectNoのプロパティ名を返します。
     * 
     * @return testDefectNoのプロパティ名
     */
    public static PropertyName<String> testDefectNo() {
        return new PropertyName<String>("testDefectNo");
    }

    /**
     * testDateのプロパティ名を返します。
     * 
     * @return testDateのプロパティ名
     */
    public static PropertyName<String> testDate() {
        return new PropertyName<String>("testDate");
    }

    /**
     * testTimeのプロパティ名を返します。
     * 
     * @return testTimeのプロパティ名
     */
    public static PropertyName<String> testTime() {
        return new PropertyName<String>("testTime");
    }

    /**
     * testSpecNameのプロパティ名を返します。
     * 
     * @return testSpecNameのプロパティ名
     */
    public static PropertyName<String> testSpecName() {
        return new PropertyName<String>("testSpecName");
    }

    /**
     * testStepNoのプロパティ名を返します。
     * 
     * @return testStepNoのプロパティ名
     */
    public static PropertyName<String> testStepNo() {
        return new PropertyName<String>("testStepNo");
    }

    /**
     * testStepNameのプロパティ名を返します。
     * 
     * @return testStepNameのプロパティ名
     */
    public static PropertyName<String> testStepName() {
        return new PropertyName<String>("testStepName");
    }

    /**
     * testMinValのプロパティ名を返します。
     * 
     * @return testMinValのプロパティ名
     */
    public static PropertyName<String> testMinVal() {
        return new PropertyName<String>("testMinVal");
    }

    /**
     * testMaxValのプロパティ名を返します。
     * 
     * @return testMaxValのプロパティ名
     */
    public static PropertyName<String> testMaxVal() {
        return new PropertyName<String>("testMaxVal");
    }

    /**
     * testDataValのプロパティ名を返します。
     * 
     * @return testDataValのプロパティ名
     */
    public static PropertyName<String> testDataVal() {
        return new PropertyName<String>("testDataVal");
    }

    /**
     * userIdのプロパティ名を返します。
     * 
     * @return userIdのプロパティ名
     */
    public static PropertyName<String> userId() {
        return new PropertyName<String>("userId");
    }

    /**
     * repairCommentのプロパティ名を返します。
     * 
     * @return repairCommentのプロパティ名
     */
    public static PropertyName<String> repairComment() {
        return new PropertyName<String>("repairComment");
    }

    /**
     * spareNum1のプロパティ名を返します。
     * 
     * @return spareNum1のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum1() {
        return new PropertyName<BigDecimal>("spareNum1");
    }

    /**
     * spareNum2のプロパティ名を返します。
     * 
     * @return spareNum2のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum2() {
        return new PropertyName<BigDecimal>("spareNum2");
    }

    /**
     * spareNum3のプロパティ名を返します。
     * 
     * @return spareNum3のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum3() {
        return new PropertyName<BigDecimal>("spareNum3");
    }

    /**
     * spareText1のプロパティ名を返します。
     * 
     * @return spareText1のプロパティ名
     */
    public static PropertyName<String> spareText1() {
        return new PropertyName<String>("spareText1");
    }

    /**
     * spareText2のプロパティ名を返します。
     * 
     * @return spareText2のプロパティ名
     */
    public static PropertyName<String> spareText2() {
        return new PropertyName<String>("spareText2");
    }

    /**
     * spareText3のプロパティ名を返します。
     * 
     * @return spareText3のプロパティ名
     */
    public static PropertyName<String> spareText3() {
        return new PropertyName<String>("spareText3");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _TrRepairLogNames extends PropertyName<TrRepairLogEntity> {

        /**
         * インスタンスを構築します。
         */
        public _TrRepairLogNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _TrRepairLogNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _TrRepairLogNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * createdOnのプロパティ名を返します。
         *
         * @return createdOnのプロパティ名
         */
        public PropertyName<Timestamp> createdOn() {
            return new PropertyName<Timestamp>(this, "createdOn");
        }

        /**
         * createdByのプロパティ名を返します。
         *
         * @return createdByのプロパティ名
         */
        public PropertyName<String> createdBy() {
            return new PropertyName<String>(this, "createdBy");
        }

        /**
         * modifiedOnのプロパティ名を返します。
         *
         * @return modifiedOnのプロパティ名
         */
        public PropertyName<Timestamp> modifiedOn() {
            return new PropertyName<Timestamp>(this, "modifiedOn");
        }

        /**
         * modifiedByのプロパティ名を返します。
         *
         * @return modifiedByのプロパティ名
         */
        public PropertyName<String> modifiedBy() {
            return new PropertyName<String>(this, "modifiedBy");
        }

        /**
         * repairNoのプロパティ名を返します。
         *
         * @return repairNoのプロパティ名
         */
        public PropertyName<BigDecimal> repairNo() {
            return new PropertyName<BigDecimal>(this, "repairNo");
        }

        /**
         * sasizuNoのプロパティ名を返します。
         *
         * @return sasizuNoのプロパティ名
         */
        public PropertyName<String> sasizuNo() {
            return new PropertyName<String>(this, "sasizuNo");
        }

        /**
         * subNoのプロパティ名を返します。
         *
         * @return subNoのプロパティ名
         */
        public PropertyName<BigDecimal> subNo() {
            return new PropertyName<BigDecimal>(this, "subNo");
        }

        /**
         * sagyoSeqのプロパティ名を返します。
         *
         * @return sagyoSeqのプロパティ名
         */
        public PropertyName<String> sagyoSeq() {
            return new PropertyName<String>(this, "sagyoSeq");
        }

        /**
         * buhinCdのプロパティ名を返します。
         *
         * @return buhinCdのプロパティ名
         */
        public PropertyName<String> buhinCd() {
            return new PropertyName<String>(this, "buhinCd");
        }

        /**
         * katasikiのプロパティ名を返します。
         *
         * @return katasikiのプロパティ名
         */
        public PropertyName<String> katasiki() {
            return new PropertyName<String>(this, "katasiki");
        }

        /**
         * seihinSnのプロパティ名を返します。
         *
         * @return seihinSnのプロパティ名
         */
        public PropertyName<String> seihinSn() {
            return new PropertyName<String>(this, "seihinSn");
        }

        /**
         * occurTimeのプロパティ名を返します。
         *
         * @return occurTimeのプロパティ名
         */
        public PropertyName<Timestamp> occurTime() {
            return new PropertyName<Timestamp>(this, "occurTime");
        }

        /**
         * lnIdのプロパティ名を返します。
         *
         * @return lnIdのプロパティ名
         */
        public PropertyName<BigDecimal> lnId() {
            return new PropertyName<BigDecimal>(this, "lnId");
        }

        /**
         * stIdのプロパティ名を返します。
         *
         * @return stIdのプロパティ名
         */
        public PropertyName<BigDecimal> stId() {
            return new PropertyName<BigDecimal>(this, "stId");
        }

        /**
         * plantCdのプロパティ名を返します。
         *
         * @return plantCdのプロパティ名
         */
        public PropertyName<String> plantCd() {
            return new PropertyName<String>(this, "plantCd");
        }

        /**
         * seizouLnCdのプロパティ名を返します。
         *
         * @return seizouLnCdのプロパティ名
         */
        public PropertyName<String> seizouLnCd() {
            return new PropertyName<String>(this, "seizouLnCd");
        }

        /**
         * seizouLnNmのプロパティ名を返します。
         *
         * @return seizouLnNmのプロパティ名
         */
        public PropertyName<String> seizouLnNm() {
            return new PropertyName<String>(this, "seizouLnNm");
        }

        /**
         * processCdのプロパティ名を返します。
         *
         * @return processCdのプロパティ名
         */
        public PropertyName<String> processCd() {
            return new PropertyName<String>(this, "processCd");
        }

        /**
         * processNmのプロパティ名を返します。
         *
         * @return processNmのプロパティ名
         */
        public PropertyName<String> processNm() {
            return new PropertyName<String>(this, "processNm");
        }

        /**
         * lnNoのプロパティ名を返します。
         *
         * @return lnNoのプロパティ名
         */
        public PropertyName<String> lnNo() {
            return new PropertyName<String>(this, "lnNo");
        }

        /**
         * lnNmのプロパティ名を返します。
         *
         * @return lnNmのプロパティ名
         */
        public PropertyName<String> lnNm() {
            return new PropertyName<String>(this, "lnNm");
        }

        /**
         * stNoのプロパティ名を返します。
         *
         * @return stNoのプロパティ名
         */
        public PropertyName<String> stNo() {
            return new PropertyName<String>(this, "stNo");
        }

        /**
         * stNmのプロパティ名を返します。
         *
         * @return stNmのプロパティ名
         */
        public PropertyName<String> stNm() {
            return new PropertyName<String>(this, "stNm");
        }

        /**
         * sagyokuのプロパティ名を返します。
         *
         * @return sagyokuのプロパティ名
         */
        public PropertyName<String> sagyoku() {
            return new PropertyName<String>(this, "sagyoku");
        }

        /**
         * equipCdのプロパティ名を返します。
         *
         * @return equipCdのプロパティ名
         */
        public PropertyName<String> equipCd() {
            return new PropertyName<String>(this, "equipCd");
        }

        /**
         * almCdのプロパティ名を返します。
         *
         * @return almCdのプロパティ名
         */
        public PropertyName<String> almCd() {
            return new PropertyName<String>(this, "almCd");
        }

        /**
         * repairKaisuのプロパティ名を返します。
         *
         * @return repairKaisuのプロパティ名
         */
        public PropertyName<BigDecimal> repairKaisu() {
            return new PropertyName<BigDecimal>(this, "repairKaisu");
        }

        /**
         * stepNoのプロパティ名を返します。
         *
         * @return stepNoのプロパティ名
         */
        public PropertyName<String> stepNo() {
            return new PropertyName<String>(this, "stepNo");
        }

        /**
         * seihinLnのプロパティ名を返します。
         *
         * @return seihinLnのプロパティ名
         */
        public PropertyName<String> seihinLn() {
            return new PropertyName<String>(this, "seihinLn");
        }

        /**
         * testDefectNoのプロパティ名を返します。
         *
         * @return testDefectNoのプロパティ名
         */
        public PropertyName<String> testDefectNo() {
            return new PropertyName<String>(this, "testDefectNo");
        }

        /**
         * testDateのプロパティ名を返します。
         *
         * @return testDateのプロパティ名
         */
        public PropertyName<String> testDate() {
            return new PropertyName<String>(this, "testDate");
        }

        /**
         * testTimeのプロパティ名を返します。
         *
         * @return testTimeのプロパティ名
         */
        public PropertyName<String> testTime() {
            return new PropertyName<String>(this, "testTime");
        }

        /**
         * testSpecNameのプロパティ名を返します。
         *
         * @return testSpecNameのプロパティ名
         */
        public PropertyName<String> testSpecName() {
            return new PropertyName<String>(this, "testSpecName");
        }

        /**
         * testStepNoのプロパティ名を返します。
         *
         * @return testStepNoのプロパティ名
         */
        public PropertyName<String> testStepNo() {
            return new PropertyName<String>(this, "testStepNo");
        }

        /**
         * testStepNameのプロパティ名を返します。
         *
         * @return testStepNameのプロパティ名
         */
        public PropertyName<String> testStepName() {
            return new PropertyName<String>(this, "testStepName");
        }

        /**
         * testMinValのプロパティ名を返します。
         *
         * @return testMinValのプロパティ名
         */
        public PropertyName<String> testMinVal() {
            return new PropertyName<String>(this, "testMinVal");
        }

        /**
         * testMaxValのプロパティ名を返します。
         *
         * @return testMaxValのプロパティ名
         */
        public PropertyName<String> testMaxVal() {
            return new PropertyName<String>(this, "testMaxVal");
        }

        /**
         * testDataValのプロパティ名を返します。
         *
         * @return testDataValのプロパティ名
         */
        public PropertyName<String> testDataVal() {
            return new PropertyName<String>(this, "testDataVal");
        }

        /**
         * userIdのプロパティ名を返します。
         *
         * @return userIdのプロパティ名
         */
        public PropertyName<String> userId() {
            return new PropertyName<String>(this, "userId");
        }

        /**
         * repairCommentのプロパティ名を返します。
         *
         * @return repairCommentのプロパティ名
         */
        public PropertyName<String> repairComment() {
            return new PropertyName<String>(this, "repairComment");
        }

        /**
         * spareNum1のプロパティ名を返します。
         *
         * @return spareNum1のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum1() {
            return new PropertyName<BigDecimal>(this, "spareNum1");
        }

        /**
         * spareNum2のプロパティ名を返します。
         *
         * @return spareNum2のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum2() {
            return new PropertyName<BigDecimal>(this, "spareNum2");
        }

        /**
         * spareNum3のプロパティ名を返します。
         *
         * @return spareNum3のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum3() {
            return new PropertyName<BigDecimal>(this, "spareNum3");
        }

        /**
         * spareText1のプロパティ名を返します。
         *
         * @return spareText1のプロパティ名
         */
        public PropertyName<String> spareText1() {
            return new PropertyName<String>(this, "spareText1");
        }

        /**
         * spareText2のプロパティ名を返します。
         *
         * @return spareText2のプロパティ名
         */
        public PropertyName<String> spareText2() {
            return new PropertyName<String>(this, "spareText2");
        }

        /**
         * spareText3のプロパティ名を返します。
         *
         * @return spareText3のプロパティ名
         */
        public PropertyName<String> spareText3() {
            return new PropertyName<String>(this, "spareText3");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
