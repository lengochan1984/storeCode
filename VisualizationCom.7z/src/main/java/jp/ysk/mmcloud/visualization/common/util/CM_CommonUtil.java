/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+===================================================================================+========+==============
 *  DATE      | Comments                                                                          | Rev    | SIGN
 * ===========+===================================================================================+========+==============
 *  2014/02/19| 新規作成                                                                          | 1.00.00| YSK)鬼丸
 *  2014/06/24| <10000-046> 不具合対応(No.018)                                                    | 1.01.00| YSK)植山
 *  2014/12/15| <20000-019> 変更仕様No.13                                                         | 3.00.00| YSK)中田
 *  2014/01/06| <20000-010> 変更仕様NO.10                                                         | 3.00.00| US)苗
 *  2014/01/06| <20000-015> 変更仕様No.14                                                         | 3.00.00| YSK)中田
 *  2015/01/21| <20000-028> 仕様変更No.32                                                         | 3.00.00| YSK)鬼丸
 *  2015/04/15| <30003-005> 故障苦情No.30002-005                                                  | 3.01.00| US)萩尾
 *  2015/04/22| <30003-006> 故障苦情No.30002-006                                                  | 3.01.00| US)萩尾
 *  2015/06/25| <30003-035> 変更仕様No.13                                                         | 3.01.00| US)楢崎
 *  2015/06/26| <30003-033> 変更仕様No.12                                                         | 3.01.00| US)萩尾
 *  2015/07/08| <30003-037> 変更仕様No.23                                                         | 3.01.00| US)楢崎
 *  2015/07/08| <30003-037> 変更仕様No.23                                                         | 3.01.00| US)萩尾
 *  2015/12/15| <40000-027> Ver.4.00.00 変更仕様No.27                                             | 4.00.00| US)楢崎
 *  2015/12/21| <40000-021> Ver.4.00.00 変更仕様No.21                                             | 4.00.00| US)楢崎
 *  2015/12/24| <40000-025> Ver.4.00.00 変更仕様No.25                                             | 4.00.00| US)萩尾
 *  2016/01/04| <40000-027> Ver.4.00.00 変更仕様No.27                                             | 4.00.00| US)萩尾
 *  2016/01/07| <40000-020> Ver.4.00.00 変更仕様No.20                                             | 4.00.00| US)萩尾
 *  2016/01/13| <40000-005> Ver.4.00.00 変更仕様No.5（故障苦情No.30100-004）                      | 4.00.00| US)清水
 *  2016/01/25| <40000-028> 変更仕様No.28                                                         | 4.00.00| US)安永
 *  2016/01/26| <40000-028> Ver.4.00.00 変更仕様No.28                                             | 4.00.00| US)清水
 *  2016/02/01| <40000-001> Ver.4.00.00 変更仕様No.7（故障苦情No.30003-067・故障苦情No.30003-081）| 4.00.00| US)甲斐
 *  2016/02/12| <40000-021> Ver.4.00.00 変更仕様No.21                                             | 4.00.00| US)甲斐
 *  2016/07/20| <C1.01> 共通化対応取込                                                            | C1.01  | US)萩尾
 * -----------+-----------------------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.util;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SimpleTimeZone;
import java.util.TimeZone;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageOutputStream;
import javax.mail.internet.InternetAddress;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.form.FW01_14_ListForm;
import jp.ysk.fw.util.FW00_08_SendMailUtil;
import jp.ysk.fw.util.FW00_11_UrlEncodeUtil;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.dto.CM_A06_UserGroupDto;
import jp.ysk.mmcloud.common.entity.customer.MstDistributeDataEntity;
import jp.ysk.mmcloud.common.entity.customer.MstDocumentEntity;
import jp.ysk.mmcloud.common.entity.customer.MstMailTemplateEntity;
import jp.ysk.mmcloud.common.entity.customer.SysEnvEntity;
import jp.ysk.mmcloud.common.entity.customer.SysNameEntityNames;
import jp.ysk.mmcloud.common.entity.root.SysEnvEntityNames;
import jp.ysk.mmcloud.common.service.CM_GetMstDataService;
import jp.ysk.mmcloud.common.telecom.CM_TelecomConst;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.common.util.CM_SysEnvDataUtil;
import jp.ysk.mmcloud.common.util.CM_SysNameDataUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.CM_A05_PageInfo;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;

import org.apache.struts.upload.FormFile;
import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.util.StringUtil;



/**
 *
 * 各種ユーティリティ処理.<br>
 *<br>
 * 概要:<br>
 *   各種ユーティリティクラス
 *<br>
 */
public class CM_CommonUtil {

    /**
     * 日時フォーマット.
     */
    private static final String DATE_FORMAT = "yyyy/MM/dd HH:mm:ss.SSS";

    /**
     * 日時フォーマット（資料用）.
     */
    private static final String DATE_FORMAT_FOR_DOC = "yyyyMMddHHmmssSSS";

    /**
     * 型番.
     */
    private static final String DOCTYPESTR_MODEL = "model";

    /**
     * 機器.
     */
    private static final String DOCTYPESTR_DEVICE = "device";

    /**
     * 名称不明ファイルのファイル名.
     */
    private static final String NO_NAME_FILE = "no_name_file";

    /**
     * ダウンロードバッファサイズ.
     */
    private static final int BUF_SIZE = 1024;

    /**
     * 容量単位KB.
     */
    private static final int STORAGE_UNIT_KBYTE = 1;

    /**
     * 容量単位MB.
     */
    private static final int STORAGE_UNIT_MBYTE = 2;

    /**
     * 容量単位GB.
     */
    private static final int STORAGE_UNIT_GBYTE = 3;

    /**
     * 機器稼動状態通信時間：10分刻み.
     */
    private static int DEVICE_STATUS_UNIT = 10;

    /**
     * Colorリスト.
     */
    private static List<BeanMap> lineStatusList = new ArrayList<BeanMap>();
    /**
     * 初期処理判断.
     */
    private static boolean isInit = true;

    /**
     *
     * コンストラクタ.
     *
     */
    protected CM_CommonUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     *
     * 文字列のNULL、ブランクのチェック処理.<br>
     *<br>
     * 概要:<br>
     *   文字列のNULL、ブランクのチェック処理を実行する
     *<br>
     * @param _strValue チェック文字列
     * @return チェック結果（True：NULLまたはブランク、False：NULLまたはブランクではない）
     */
    public static boolean isNullOrBlank(final String _strValue) {

        boolean isRet = false;
        if (_strValue == null || FW00_19_Const.EMPTY_STR.equals(_strValue)) {
            isRet = true;
        }
        return isRet;
    }

    /**
     *
     * オブジェクトを文字列化した際の文字列のNULL、ブランクのチェック処理.<br>
     *<br>
     * 概要:<br>
     *   オブジェクトを文字列化した際の文字列のNULL、ブランクのチェック処理を実行する
     *<br>
     * @param _objValue チェック文字列オブジェクト
     * @return チェック結果（True：NULLまたはブランク、False：NULLまたはブランクではない）
     */
    public static boolean isNullOrBlank(final Object _objValue) {

        boolean isRet = false;
        if (_objValue == null || FW00_19_Const.EMPTY_STR.equals(_objValue.toString())) {
            isRet = true;
        }
        return isRet;
    }

    /**
     *
     * {リストのNULL、空のチェック処理}.<br>
     *<br>
     * 概要:<br>
     *   {リストのNULL、空のチェック処理を実行する}
     *<br>
     * @param <T> リスト型
     * @param _objList チェック対象リスト
     * @return チェック結果（True：NULLまたは空、False：NULLまたは空ではない）
     */
    public static <T> boolean isNullOrEmpty(final List<T> _objList) {
        return _objList == null || _objList.isEmpty();
    }

    /**
     *
     * オブジェクトを文字列化した際の文字列がNULLまたは、ブランクではないチェック処理.<br>
     *<br>
     * 概要:<br>
     *   オブジェクトを文字列化した際の文字列がNULLまたは、ブランクではないチェック処理を実行する
     *<br>
     * @param _objValue チェック文字列オブジェクト
     * @return チェック結果（True：NULLまたはブランクでない、False：NULLまたはブランク）
     */
    public static boolean isNotNullOrBlank(final Object _objValue) {

        return !isNullOrBlank(_objValue);
    }

    /**
     *
     * {リストのNULL、空でないチェック処理}.<br>
     *<br>
     * 概要:<br>
     *   {リストのNULL、空でないチェック処理を実行する}
     *<br>
     * @param <T> リスト型
     * @param _objList チェック対象リスト
     * @return チェック結果（True：NULLまたは空でない、False：NULLまたは空）
     */
    public static <T> boolean isNotNullOrEmpty(final List<T> _objList) {
        return !isNullOrEmpty(_objList);
    }

    /**
     *
     * ユーザの姓、名から表示ユーザ名を作成する処理.<br>
     *<br>
     * 概要:<br>
     *   ユーザの姓、名から表示ユーザ名を作成する
     *<br>
     * @param _strUserLastName ユーザ名（性）
     * @param _strUserFirstName ユーザ名（名）
     * @return ユーザ名
     */
    public static String getDispUserName(final String _strUserLastName, final String _strUserFirstName) {
        String strRetUserName = FW00_19_Const.EMPTY_STR;

        if (isNullOrBlank(_strUserLastName) && !isNullOrBlank(_strUserFirstName)) {
            strRetUserName = _strUserFirstName;
        } else if (!isNullOrBlank(_strUserLastName) && isNullOrBlank(_strUserFirstName)) {
            strRetUserName = _strUserLastName;
        } else if (!isNullOrBlank(_strUserLastName) && !isNullOrBlank(_strUserFirstName)) {
            strRetUserName = _strUserLastName + FW00_19_Const.SPACE + _strUserFirstName;
        }
        return strRetUserName;
    }

    /**
     *
     * SHA-256によるハッシュ暗号化処理.<br>
     *<br>
     * 概要:<br>
     *   文字列をSHA-256による暗号化処理を実行し、暗号化した文字列を返却する
     *<br>
     * @param _strTarget 暗号化する文字列
     * @return 暗号化した文字列
     */
    public static String getSha256(final String _strTarget) {
        MessageDigest md = null;
        StringBuffer buf = new StringBuffer();

        try {
            // SHA-256による暗号化用ダイジェストを生成
            md = MessageDigest.getInstance("SHA-256");
            // パラメータ文字列を暗号化
            md.update(_strTarget.getBytes());
            byte[] digest = md.digest();

            // 暗号化したバイト配列を文字列化
            for (int i = 0; i < digest.length; i++) {
                buf.append(String.format("%02x", digest[i]));
            }

        } catch (Exception e) {
            // エラーログ出力
            CM_LoggerUtil.outputErrorLog(null, e);
        }
        return buf.toString();
    }

    /**
     *
     * タイムゾーン時刻取得処理.<br>
     *<br>
     * 概要:<br>
     *   標準時から指定したタイムゾーン時刻を取得する処理
     *<br>
     * @param _strGmt 変換対象の標準時
     * @param _strTimezone 変換先のタイムゾーン
     * @param _strDateFormatTimezone 変換先のタイムゾーン時間の日時フォーマット
     * @return タイムゾーン時間
     */
    public static String getTimeGmtToTimezone(final String _strGmt,
            final String _strTimezone, final String _strDateFormatTimezone) {

        String strTimeZoneDate = null;
        try {
            // 標準時のDateインスタンス作成
            SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
            TimeZone tzGmt = CM_CommonUtil.getTimeZone(FW00_19_Const.TZ_GMT);

            sdf.setTimeZone(tzGmt);
            Date dtGmt = sdf.parse(_strGmt);

            // タイムゾーン時間へ変換
            TimeZone tz = CM_CommonUtil.getTimeZone(_strTimezone);
            sdf = new SimpleDateFormat(_strDateFormatTimezone);
            sdf.setTimeZone(tz);
            strTimeZoneDate = sdf.format(dtGmt);

        } catch (Exception e) {
            // エラーログ出力
            CM_LoggerUtil.outputErrorLog(null, e);
        }
        return strTimeZoneDate;
    }

    /**
     *
     * タイムゾーン時刻取得処理.<br>
     *<br>
     * 概要:<br>
     *   標準時から指定したタイムゾーン時刻を取得する処理
     *<br>
     * @param _timestampGmt 変換対象の標準時
     * @param _strTimezone 変換先のタイムゾーン
     * @param _strDateFormatTimezone 変換先のタイムゾーン時間の日時フォーマット
     * @return タイムゾーン時間
     */
    public static String getTimeGmtToTimezone(final Timestamp _timestampGmt,
            final String _strTimezone, final String _strDateFormatTimezone) {

        String strTimeZoneDate = null;
        try {
            TimeZone tz = CM_CommonUtil.getTimeZone(_strTimezone);
            SimpleDateFormat sdf = new SimpleDateFormat(_strDateFormatTimezone);
            sdf.setTimeZone(tz);
            strTimeZoneDate = sdf.format(_timestampGmt);

        } catch (Exception e) {
            // エラーログ出力
            CM_LoggerUtil.outputErrorLog(null, e);
        }
        return strTimeZoneDate;
    }


    /**
     *
     * 標準時刻取得処理.<br>
     *<br>
     * 概要:<br>
     *   指定したタイムゾーン時刻から標準時を取得する処理
     *<br>
     * @param _strTimeZoneDate 変換対象のタイムゾーン日時
     * @param _strTimezone 変換対象のタイムゾーン
     * @param _strTimeZoneFormat 変換対象の日時フォーマット
     * @param _strDateFormatGmt 変換先の標準時の日時フォーマット
     * @return 標準時
     */
    public static String getTimeTimezoneToGmt(final String _strTimeZoneDate,
            final String _strTimezone, final String _strTimeZoneFormat, final String _strDateFormatGmt) {

        String strTimeZoneDate = null;
        try {
            // 指定タイムゾーンのDateインスタンス作成
            SimpleDateFormat sdf = new SimpleDateFormat(_strTimeZoneFormat);
            TimeZone tz = CM_CommonUtil.getTimeZone(_strTimezone);
            sdf.setTimeZone(tz);
            Date dt = sdf.parse(_strTimeZoneDate);

            // 標準時文字列へ変換
            TimeZone tzGmt = CM_CommonUtil.getTimeZone(FW00_19_Const.TZ_GMT);
            sdf = new SimpleDateFormat(_strDateFormatGmt);
            sdf.setTimeZone(tzGmt);
            strTimeZoneDate = sdf.format(dt);

        } catch (Exception e) {
            // エラーログ出力
            CM_LoggerUtil.outputErrorLog(null, e);
        }
        return strTimeZoneDate;
    }

    /**
     *
     * 標準時刻取得処理.<br>
     *<br>
     * 概要:<br>
     *   指定したタイムゾーン時刻から標準時を取得する処理
     *<br>
     * @param _strTimeZoneDate 変換対象の標準時
     * @param _strTimezone 変換先のタイムゾーン
     * @param _strTimeZoneFormat 変換対象の日時フォーマット
     * @return 標準時
     */
    public static Date getTimeTimezoneToGmt(
            final String _strTimeZoneDate, final String _strTimezone, final String _strTimeZoneFormat) {

        Date ret = null;
        try {
            // 指定タイムゾーンのDateインスタンス作成
            SimpleDateFormat sdf = new SimpleDateFormat(_strTimeZoneFormat);
            TimeZone tz = CM_CommonUtil.getTimeZone(_strTimezone);

            sdf.setTimeZone(tz);
            ret = sdf.parse(_strTimeZoneDate);

        } catch (Exception e) {
            // エラーログ出力
            CM_LoggerUtil.outputErrorLog(null, e);
        }

        return ret;
    }

    /**
     *
     * タイムゾーン時刻取得処理（日本時間⇒タイムゾーン）.<br>
     *<br>
     * 概要:<br>
     *   日本時から指定したタイムゾーン時刻を取得する処理
     *<br>
     * @param _strGmt 変換対象の日本時
     * @param _strTimezone 変換先のタイムゾーン
     * @param _strDateFormatTimezone 変換先のタイムゾーン時間の日時フォーマット
     * @return タイムゾーン時間
     */
    public static String getTimeJPNToTimezone(final String _strGmt,
            final String _strTimezone, final String _strDateFormatTimezone) {

        String strTimeZoneDate = null;
        try {
            // 標準時のDateインスタンス作成
            SimpleDateFormat sdf = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT);
            TimeZone tzGmt = CM_CommonUtil.getTimeZone(FW00_19_Const.TZ_JPN);
            sdf.setTimeZone(tzGmt);
            Date dtGmt = sdf.parse(_strGmt);

            // タイムゾーン時間へ変換
            TimeZone tz = CM_CommonUtil.getTimeZone(_strTimezone);
            sdf = new SimpleDateFormat(_strDateFormatTimezone);
            sdf.setTimeZone(tz);
            strTimeZoneDate = sdf.format(dtGmt);

        } catch (Exception e) {
            // エラーログ出力
            CM_LoggerUtil.outputErrorLog(null, e);
        }
        return strTimeZoneDate;
    }

    /**
     *
     * Calendarオブジェクト取得処理.<br>
     *<br>
     * 概要:<br>
     *   Calendarオブジェクトを取得する処理
     *<br>
     * @param _strDatetime 変換対象の日時
     * @param _strDateFormat 日時フォーマット
     * @return Calendarオブジェクト
     */
    public static Calendar getCalendarObj(final String _strDatetime, final String _strDateFormat) {

        Calendar ret = Calendar.getInstance();

        try {
            // Dateインスタンス作成
            SimpleDateFormat sdf = new SimpleDateFormat(_strDateFormat);
            Date date = sdf.parse(_strDatetime);

            // Calendar型へ変換
            ret.setTime(date);

        } catch (Exception e) {
            // エラーログ出力
            CM_LoggerUtil.outputErrorLog(null, e);
        }

        return ret;
    }

    /**
     *
     * 日時（文字列）取得処理.<br>
     *<br>
     * 概要:<br>
     *   Calendarオブジェクトから日時（文字列）を取得する処理
     *<br>
     * @param _cal 変換対象のCalendarオブジェクト
     * @param _strDateFormat 日時フォーマット
     * @return 日時（文字列）
     */
    public static String getDatetimeStr(final Calendar _cal, final String _strDateFormat) {

        String ret = null;

        try {
            SimpleDateFormat sdf = new SimpleDateFormat(_strDateFormat);
            ret = sdf.format(_cal.getTime());

        } catch (Exception e) {
            // エラーログ出力
            CM_LoggerUtil.outputErrorLog(null, e);
        }

        return ret;
    }

    /**
     * サーバシステム日付を指定タイムゾーンの標準時に変換して返す.
     * @param _timeZ タイムゾーン
     * @return 標準日時.
     */
    public static Date getUserTimeZoneSysDate(final String _timeZ) {

        try {
            SimpleDateFormat sdf = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT);

            // 現地標準時間
            String todayStr = CM_CommonUtil.getTimeJPNToTimezone(sdf.format(new Date())
                                                                    , _timeZ, CM_A04_Const.DATE_FORMAT);

            return sdf.parse(todayStr);

        } catch (ParseException e) {

            // エラーログ出力
            CM_LoggerUtil.outputErrorLog(null, e);
            return null;
        }
    }

    /**
     *
     * 標準時間 現在日時取得処理.<br>
     *<br>
     * 概要:<br>
     *   標準時間の現在日時を取得する処理
     *<br>
     * @return 標準時間 現在日時
     */
    public static Date getNowGmtDatetime() {
        Date dtGmt = null;
        try {
            // サーバータイムゾーンの現在日時
            Date dt = new Date();

            // 標準時へ変換
            TimeZone tzGmt = CM_CommonUtil.getTimeZone(FW00_19_Const.TZ_GMT);
            SimpleDateFormat gmtSdf = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT_MILLI);
            gmtSdf.setTimeZone(tzGmt);
            dtGmt = gmtSdf.parse(gmtSdf.format(dt));

        } catch (Exception e) {
            // エラーログ出力
            CM_LoggerUtil.outputErrorLog(null, e);
        }
        return dtGmt;
    }

    /**
     *
     * シーケンス取得SQL作成処理.<br>
     *<br>
     * 概要:<br>
     *   シーケンス取得SQLを作成する処理
     *<br>
     * @param _seqName シーケンス名
     * @return シーケンス取得SQL文字列
     */
    public static String getSeqSQL(final String _seqName) {

        String retStr = "select nextval('" + _seqName + "')";
        return retStr;
    }

    /**
     *
     * Like検索用文字エスケープ処理.<br>
     *<br>
     * 概要:<br>
     *   ％と＿をエスケープ処理
     *<br>
     * @param _src 変換対象文字列
     * @return 返還後文字列
     */
    public static String escapeLikeString(final String _src) {
        String strTemp = _src.replace(FW00_19_Const.UNDER_BAR_STR,
                FW00_19_Const.BACK_SLASH_STR + FW00_19_Const.UNDER_BAR_STR);
        strTemp = strTemp.replace(FW00_19_Const.PERCENT_STR, FW00_19_Const.BACK_SLASH_STR + FW00_19_Const.PERCENT_STR);

        return strTemp;
    }

    /**
     *
     * Jsonファイル用エスケープ処理.<br>
     *<br>
     * 概要:<br>
     *   バックスラッシュをエスケープ処理
     *<br>
     * @param _src 変換対象文字列
     * @return 返還後文字列
     */
    public static String escapeForJson(final String _src) {
        String strTemp = _src.replace(FW00_19_Const.BACK_SLASH_STR, FW00_19_Const.BACK_SLASH_STR + FW00_19_Const.BACK_SLASH_STR);

        return strTemp;
    }

    /**
     *
     * Javascriptファイル用エスケープ処理.<br>
     *<br>
     * 概要:<br>
     *   Javascript文字のエスケープ処理<br>
     *<br>
     * @param _src 変換対象文字列
     * @return 返還後文字列
     */
    public static String escapeJavascript(final String _src) {

        // HTML特殊文字を文字コードに変換
        String strData = _src;
        strData = strData.replace(FW00_19_Const.BACK_SLASH_STR, FW00_19_Const.BACK_SLASH_STR + FW00_19_Const.BACK_SLASH_STR);
        strData = strData.replace(FW00_19_Const.SINGLE_QUOTATION_STR, FW00_19_Const.BACK_SLASH_STR + FW00_19_Const.SINGLE_QUOTATION_STR);
        strData = strData.replace(FW00_19_Const.DOUBLE_QUOTATION_STR, FW00_19_Const.BACK_SLASH_STR + FW00_19_Const.DOUBLE_QUOTATION_STR);

        return strData;
    }

    /**
     *
     * HTML文字のエスケープ処理.<br>
     *<br>
     * 概要:<br>
     * HTML文字のエスケープ処理<br>
     * @param _src 置換前文字列
     * @return 置換後文字列
     */
    public static String escapeHtmlTag(final String _src) {

        // HTML特殊文字を文字コードに変換
        String strData = _src;
        strData = strData.replaceAll(FW00_19_Const.AMPERSAND_STR, CM_A04_Const.AMPERSAND_CODE);
        strData = strData.replaceAll(FW00_19_Const.LEFT_ANGLE_BRACKET_STR, CM_A04_Const.LEFT_ANGLE_BRACKET_CODE);
        strData = strData.replaceAll(FW00_19_Const.RIGHT_ANGLE_BRACKET_STR, CM_A04_Const.RIGHT_ANGLE_BRACKET_CODE);
        strData = strData.replaceAll(FW00_19_Const.DOUBLE_QUOTATION_STR, CM_A04_Const.DOUBLE_QUOTATION_CODE);
        strData = strData.replaceAll(FW00_19_Const.SINGLE_QUOTATION_STR, CM_A04_Const.SINGLE_QUOTATION_CODE);

        // 改行コードを<br>に変換
        strData = strData.replaceAll(CM_A04_Const.LINE_END, CM_A04_Const.LINE_END_CODE);
        strData = strData.replaceAll(CM_A04_Const.CARRIAGE_RETURN, CM_A04_Const.LINE_END_CODE);
        strData = strData.replaceAll(CM_A04_Const.LINE_FEED, CM_A04_Const.LINE_END_CODE);

        // Postgresの場合は内部的に\がエスケープされているのでその場合の対処を行う。
        strData = strData.replaceAll("\\\\r\\\\n", CM_A04_Const.LINE_END_CODE);
        strData = strData.replaceAll("\\\\r", CM_A04_Const.LINE_END_CODE);
        strData = strData.replaceAll("\\\\n", CM_A04_Const.LINE_END_CODE);

        return strData;
    }

    /**
     *
     * HTML特殊文字を文字コードに変換.<br>
     *<br>
     * 概要:<br>
     *   HTML特殊文字を文字コードに変換
     *<br>
     * @param _src 置換前文字列
     * @return 置換後文字列
     */
    public static String escapeHtml(final String _src)  {

        // HTML特殊文字を文字コードに変換
        String strData = _src;
        strData = strData.replaceAll(FW00_19_Const.AMPERSAND_STR, CM_A04_Const.AMPERSAND_CODE);
        strData = strData.replaceAll(FW00_19_Const.LEFT_ANGLE_BRACKET_STR, CM_A04_Const.LEFT_ANGLE_BRACKET_CODE);
        strData = strData.replaceAll(FW00_19_Const.RIGHT_ANGLE_BRACKET_STR, CM_A04_Const.RIGHT_ANGLE_BRACKET_CODE);
        strData = strData.replaceAll(FW00_19_Const.DOUBLE_QUOTATION_STR, CM_A04_Const.DOUBLE_QUOTATION_CODE);
        strData = strData.replaceAll(FW00_19_Const.SINGLE_QUOTATION_STR, CM_A04_Const.SINGLE_QUOTATION_CODE);

        return strData;
    }

    /**
     *
     * 改行コードの置換処理.<br>
     *<br>
     * 概要:<br>
     * 改行コードを半角スペースに置換<br>
     * @param _src 置換前文字列
     * @return 置換後文字列
     */
    public static String replaceNewLine(final String _src) {

        // 改行コードを半角スペースに変換
        String strData = _src;
        strData = strData.replaceAll(CM_A04_Const.LINE_END, FW00_19_Const.SPACE);
        strData = strData.replaceAll(CM_A04_Const.CARRIAGE_RETURN, FW00_19_Const.SPACE);
        strData = strData.replaceAll(CM_A04_Const.LINE_FEED, FW00_19_Const.SPACE);

        return strData;
    }

    /**
     *
     * ワイルドカード追加処理.<br>
     *<br>
     * 概要:<br>
     *   Like検索用に、ワイルドカード文字列を付加する。<br>
     *   _forwardと_backをともにtrueにすると、<br>
     *   _src文字列の前後にワイルドカード文字列を追加し、<br>
     *   部分文字列検索になる。
     *<br>
     * @param _src 変換対象文字列
     * @param _forward 前方一致
     * @param _back 後方一致
     * @return 返還後文字列
     */
    public static String addWildcard(final String _src, final boolean _forward, final boolean _back) {
        String strTemp = _src;
        if (_forward) {
            strTemp = strTemp + FW00_19_Const.PERCENT_STR;
        }

        if (_back) {
            strTemp = FW00_19_Const.PERCENT_STR + strTemp;
        }

        return strTemp;
    }

    /**
     *
     * 夏時間オフセットクリア.<br>
     *<br>
     * 概要:<br>
     *   夏時間のオフセットをクリアする
     *   SimpleDateFormatで文字列変換する際に使用すること
     *<br>
     * @param _strTimezone タイムゾーンID
     * @return タイムゾーン
     */
    public static TimeZone getTimeZone(final String _strTimezone) {
        TimeZone tz = SimpleTimeZone.getTimeZone(_strTimezone);

        // サマータイム用オフセットをクリアするため、GMT+XXXX,GMT-XXXXに変換してタイムゾーンを再取得
        Calendar tmpCal = Calendar.getInstance(tz);
        int zoneoffset = tmpCal.get(Calendar.ZONE_OFFSET);

        int diffMinute = Math.round(zoneoffset / (FW00_19_Const.SECOND * FW00_19_Const.MILLI));
        long diffHour = Math.round(Math.ceil(diffMinute / FW00_19_Const.MINUTE));
        diffMinute -= diffHour * FW00_19_Const.MINUTE;
        String strGmtTimezone = "GMT" + String.format("%+03d%02d", diffHour, diffMinute);
        tz = TimeZone.getTimeZone(strGmtTimezone);

        return tz;
    }

    /**
     *
     * 拡張子取得処理.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _strPath ファイル名
     * @return 拡張子文字列
     */
    public static String getExtention(final String _strPath) {
        String strFileName = _strPath.substring(_strPath.lastIndexOf(CM_A04_Const.PATH_DELIMITER) + 1);
        String ret = FW00_19_Const.EMPTY_STR;

        if (strFileName.lastIndexOf(FW00_19_Const.DOT_STR) != (-1)) {
            ret = strFileName.substring(strFileName.lastIndexOf(FW00_19_Const.DOT_STR) + 1);
        }

        return ret;
    }

    /**
     * 資料No生成処理.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _docSid 資料情報SID
     * @return 資料No
     */
    public static String makeDocNo(final Integer _docSid) {
        String docNo = FW00_19_Const.EMPTY_STR;
        if (_docSid != null) {
            docNo = _docSid.toString();
            while (docNo.length() < CM_A04_Const.LENGTH.DOCUMENT_DOCNO_LENGTH) {
                docNo = CM_A04_Const.ZERO_STR.concat(docNo);
            }
        }
        return docNo;
    }

    /**
     * 資料情報ファイルフルパス取得.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _sessionDto セッション情報
     * @param _docData 資料情報エンティティ
     * @return 資料ファイルフルパス
     */
    public static String makeFileFullPath(final CM_A03_SessionDto _sessionDto, final MstDocumentEntity _docData) {

        // アップロード先ファイルパスを取得する。
        String filePath = makeDocSaveFilePath(_sessionDto, _docData);

        String fullpath = filePath + CM_A04_Const.PATH_DELIMITER + _docData.fileName;
        return fullpath;
    }

    /**
     * 資料情報サムネイル画像ファイルフルパス取得.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _sessionDto セッション情報
     * @param _docData 資料情報エンティティ
     * @return 資料ファイルフルパス
     */
    public static String makeThumbnailFileFullPath(final CM_A03_SessionDto _sessionDto, final MstDocumentEntity _docData) {

        // アップロード先ファイルパスを取得する。
        String filePath = makeDocSaveFilePath(_sessionDto, _docData);

        String strFileName = _docData.fileName.substring(0, _docData.fileName.lastIndexOf("."));
        String strExt = getExtention(_docData.fileName);
        String fullpath = filePath + CM_A04_Const.PATH_DELIMITER + strFileName + CM_A04_Const.THUMBNAIL + strExt;
        return fullpath;
    }

    /**
     * 資料用保存ファイル名生成処理.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _uploadFile FormFileオブジェクト
     * @param _entity 資料情報エンティティ
     * @return 保存先フルパス
     */
    public static String makeDocSaveFileName(final FormFile _uploadFile, final MstDocumentEntity _entity) {

        String targetFileName = _uploadFile.getFileName();

        // アップロードファイルの拡張子
        String fileExtention = getExtention(targetFileName);

        Date date = new Date();

        return makeDocSaveFileName(fileExtention, date, _entity);
    }

    /**
     * 資料用保存ファイル名生成処理.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _fileExtention FormFileオブジェクト
     * @param _date 日時
     * @param _entity 資料情報エンティティ
     * @return 保存先フルパス
     */
    public static String makeDocSaveFileName(final String _fileExtention, final Date _date, final MstDocumentEntity _entity) {

        String saveFileName;
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_FOR_DOC);

        saveFileName = _entity.sid + FW00_19_Const.UNDER_BAR_STR + sdf.format(_date);

        if (!CM_CommonUtil.isNullOrBlank(_fileExtention)) {
            saveFileName += FW00_19_Const.DOT_STR + _fileExtention;
        }

        return saveFileName;
    }

    /**
     * 資料用保存先フォルダ名生成処理.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _sessionDto セッション情報
     * @param _entity 資料情報エンティティ
     * @return 保存先フルパス
     */
    public static String makeDocSaveFilePath(final CM_A03_SessionDto _sessionDto, final MstDocumentEntity _entity) {

        // パス取得
        String path = makeDocSaveFilePath(_sessionDto, _entity.docType, _entity.keyCd.toString());

        return path;
    }

    /**
     * 資料用保存先フォルダ名生成処理.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _path 保存先パス
     * @param _entity 資料情報エンティティ
     * @return 保存先フルパス
     */
    public static String makeDocSaveFilePath(final String _path, final MstDocumentEntity _entity) {

        // パス取得
        String path = makeDocSaveFilePath(_path, _entity.docType, _entity.keyCd.toString());

        return path;
    }

    /**
     * 資料用保存先フォルダ名生成処理.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _sessionDto セッション情報
     * @param _docType 文書区分
     * @param _keyCd キーCD
     * @return 保存先フルパス
     */
    public static String makeDocSaveFilePath(final CM_A03_SessionDto _sessionDto, final String _docType, final String _keyCd) {

        // パス取得
        String path = getUploadFilePath(_sessionDto);

        return makeDocSaveFilePath(path, _docType, _keyCd);
    }

    /**
     * 資料用保存先フォルダ名生成処理.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _path 保存先パス
     * @param _docType 文書区分
     * @param _keyCd キーCD
     * @return 保存先フルパス
     */
    public static String makeDocSaveFilePath(final String _path, final String _docType, final String _keyCd) {

        String ret = _path + CM_A04_Const.PATH_DELIMITER;

        if (CM_A04_Const.DOCTYPE.DEVICE.equals(_docType)) {
            ret = ret + DOCTYPESTR_DEVICE + CM_A04_Const.PATH_DELIMITER + _keyCd;
        } else {
            ret = ret + DOCTYPESTR_MODEL + CM_A04_Const.PATH_DELIMITER + _keyCd;
        }

        return ret;
    }

    /**
     * 配信データ用保存先フォルダ名生成処理.<br/>
     * <br/>
     * 概要:<br/>
     *   アップロード送信先ファイルパスを取得する。<br/>
     *   例：/usr/local/mnt/db/顧客ディスク(custXX)/uploadfile/1 <br/>
     *
     * @param _sessionDto セッション情報
     * @param _distributeDataSid 配信データSID
     * @return アップロード送信先ファイルパス
     */
    public static String makeDistributeSaveFilePath(final CM_A03_SessionDto _sessionDto, final Integer _distributeDataSid) {

        // ファイルパス
        String filePath = getUploadSendFilePath(_sessionDto);

        // 型番SIDを取得する。
        final CM_GetMstDataService mstDataService = new CM_GetMstDataService(_sessionDto);
        final MstDistributeDataEntity mstDistributeDataEntity = mstDataService.getMstDistributeData(_distributeDataSid);

        if (CM_CommonUtil.isNotNullOrBlank(mstDistributeDataEntity)) {
            // アップロード送信先フォルダ名 + "/" + 型番SID
            filePath += CM_A04_Const.PATH_DELIMITER + String.valueOf(mstDistributeDataEntity.modelSid);
        }

        return filePath;
    }

    /**
     * アップロード先フォルダ名取得処理.<br/>
     *<br/>
     * 概要:<br/>
     *<br/>
     * @param _sessionDto セッション情報
     * @return アップロード先フルパス
     */
    private static String getUploadFilePath(final CM_A03_SessionDto _sessionDto) {

        // パス取得
        BeanMap sysEnv = CM_SysEnvDataUtil.selectSysEnv(_sessionDto, CM_A04_Const.SYS_ENV_MST_ENV_CD.UPLOAD_FILE_PATH,
                CM_A04_Const.SYS_ENV_MST_ITEM_CD.FILE_PATH);

        String path = FW00_19_Const.EMPTY_STR;
        if (CM_CommonUtil.isNotNullOrBlank(sysEnv) && CM_CommonUtil.isNotNullOrBlank(sysEnv.get(SysEnvEntityNames.name()))) {
            path = String.valueOf(sysEnv.get(SysEnvEntityNames.name()));
        }

        return path;
    }

    /**
     * アップロード送信先フォルダ名取得処理.<br/>
     *<br/>
     * 概要:<br/>
     *<br/>
     * @param _sessionDto セッション情報
     * @return アップロード送信先フルパス
     */
    private static String getUploadSendFilePath(final CM_A03_SessionDto _sessionDto) {

        // パス取得
        BeanMap sysEnv = CM_SysEnvDataUtil.selectSysEnv(_sessionDto, CM_A04_Const.SYS_ENV_MST_ENV_CD.UPLOAD_SEND_FILE_PATH,
                CM_A04_Const.SYS_ENV_MST_ITEM_CD.FILE_PATH);

        String path = FW00_19_Const.EMPTY_STR;
        if (CM_CommonUtil.isNotNullOrBlank(sysEnv) && CM_CommonUtil.isNotNullOrBlank(sysEnv.get(SysEnvEntityNames.name()))) {
            path = String.valueOf(sysEnv.get(SysEnvEntityNames.name()));
        }

        return path;
    }

    /**
     * ユーザアイコンアップロード先フォルダパス生成.
     *
     * @param _modelSid 型番SID
     * @param _sessionDto セッション情報
     * @return ユーザアイコンアップロード先フォルダパス
     */
    public static String makeIconDirPath(final CM_A03_SessionDto _sessionDto, final String _modelSid) {
        // パス取得
        String path = makeDocSaveFilePath(_sessionDto, CM_A04_Const.DOCTYPE.MODEL, _modelSid)
                + CM_A04_Const.PATH_DELIMITER + CM_A04_Const.ICON_DIR_NAME + CM_A04_Const.PATH_DELIMITER;

        return path;
    }

    /**
     * アイコン保管パス生成処理.<br/>
     * <br/>
     * 概要:<br/>
     * 指定された型番のアイコン保管パスを生成する。 <br/>
     *
     * @param _sessionDto セッション情報
     * @param _modelSid 型番SID
     * @param _fileName ファイル名
     * @return アイコン保管パス
     */
    public static String makeMapIconFilePath(final CM_A03_SessionDto _sessionDto, final Integer _modelSid, final String _fileName) {

        return makeMapIconFilePath(_sessionDto, String.valueOf(_modelSid), _fileName);
    }

    /**
     * アイコン保管パス生成処理.<br/>
     * <br/>
     * 概要:<br/>
     * 指定された型番のアイコン保管パスを生成する。 <br/>
     *
     * @param _sessionDto セッション情報
     * @param _modelSid 型番SID
     * @param _fileName ファイル名
     * @return アイコン保管パス
     */
    public static String makeMapIconFilePath(final CM_A03_SessionDto _sessionDto, final String _modelSid, final String _fileName) {
        String path = makeIconDirPath(_sessionDto, _modelSid);

        return path + _fileName;
    }

    /**
     * ファイル保存処理.<br>
     *<br>
     * 概要:<br>
     * 　パスが存在しない場合は生成する
     *<br>
     * @param _uploadFile FormFileオブジェクト
     * @param _destFileName ファイル名
     * @param _destPath 保存先フルパス（ファイル名を含めない）
     * @throws IOException IOエラー
     */
    public static void saveFile(final FormFile _uploadFile, final String _destFileName, final String _destPath) throws IOException {

        // ディレクトリが無い場合は生成する。
        File filePath = new File(_destPath);
        if (!filePath.exists()) {
            filePath.mkdirs();
        }

        String saveFileName = _destPath;

        // 終端がファイル区切り文字ではない場合は、
        if (!CM_A04_Const.PATH_DELIMITER.equals(saveFileName.substring(saveFileName.length() - 1))) {
            saveFileName += CM_A04_Const.PATH_DELIMITER;
        }

        // フルパスのファイル名を生成
        saveFileName += _destFileName;

        InputStream is = _uploadFile.getInputStream();
        BufferedInputStream inBuffer = new BufferedInputStream(is);
        FileOutputStream fos = new FileOutputStream(saveFileName);
        BufferedOutputStream outBuffer = new BufferedOutputStream(fos);
        int contents = 0;

        while ((contents = inBuffer.read()) != -1) {
            outBuffer.write(contents);
        }

        outBuffer.flush();
        inBuffer.close();
        outBuffer.close();
    }

    /**
     * ファイルダウンロード処理.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _response HTTPレスポンス
     * @param _srcFilePath ダウンロード元ファイルパス
     * @param _destFileName ダウンロードファイル名
     * @throws Exception 各種例外
     */
    public static void downloadFile(final HttpServletResponse _response, final String _srcFilePath, final String _destFileName) throws Exception {
        FileInputStream in = new FileInputStream(_srcFilePath);

        ServletOutputStream out = null;
        String encordName = null;
        if (_destFileName != null && !_destFileName.equals(FW00_19_Const.EMPTY_STR)) {
            encordName = FW00_11_UrlEncodeUtil.getUrlEncode(_destFileName);
        } else {
            encordName = NO_NAME_FILE;
        }

        _response.setContentType("application/octet-stream");
        _response.setHeader("Content-Disposition", "attachment; filename=\"" + encordName + "\"");
        _response.setHeader("Cache-Control", "private");
        _response.setHeader("Pragma", "private");

        byte[] b = new byte[BUF_SIZE];
        int len = 0;
        out = _response.getOutputStream();

        while ((len = in.read(b)) != -1) {

            out.write(b, 0, len);
        }

        in.close();
        out.close();
    }

    /**
     * コピー元ファイル[srcPath]から、コピー先ファイル[destPath]へファイルのコピーを行う.
     * @param _srcFile    コピー元ファイル
     * @param _destFile   コピー先ファイル
     * @throws IOException    何らかの入出力処理例外が発生した場合
     */
    @SuppressWarnings("resource")
    public static void copyTransfer(final File _srcFile, final File _destFile) throws IOException {

        FileChannel srcChannel = new FileInputStream(_srcFile).getChannel();
        FileChannel destChannel = new FileOutputStream(_destFile).getChannel();
        try {
            srcChannel.transferTo(0, srcChannel.size(), destChannel);
        } finally {
            srcChannel.close();
            destChannel.close();
        }

    }

    /**
     *
     * ファイルサイズの単位調整および単位文字列の付与.<br>
     * <br>
     * 概要:<br>
     * ファイルサイズの単位調整および単位文字列の付与 <br>
     *
     * @param _flFileSize
     *            ファイルサイズ数値（byte単位）
     * @return サイズ調整後の数値および単位文字列の連結文字
     */
    public static String formatFileSize(final float _flFileSize) {

        float flFileSize = _flFileSize;
        float flTemp = _flFileSize;
        int intCnt = 0;

        // ファイルサイズが1以上の最大単位となるよう単位計算（MByteまで）
        while (flTemp > STORAGE_UNIT_KBYTE && intCnt < STORAGE_UNIT_GBYTE) {
            flTemp = flFileSize / FW00_19_Const.KILO_BYTES;
            if (flTemp >= 1) {
                flFileSize = flTemp;
                intCnt++;
            }
        }

        // ファイルサイズ単位の判定
        String strFileSizeUnit = FW00_19_Const.EMPTY_STR;
        if (intCnt == STORAGE_UNIT_KBYTE) {
            strFileSizeUnit = CM_A04_Const.FILE_SIZE_UNIT.KBYTE;
        } else if (intCnt == STORAGE_UNIT_MBYTE) {
            strFileSizeUnit = CM_A04_Const.FILE_SIZE_UNIT.MBYTE;
        } else if (intCnt == STORAGE_UNIT_GBYTE) {
            strFileSizeUnit = CM_A04_Const.FILE_SIZE_UNIT.GBYTE;
        }

        // フォーマット作成
        DecimalFormat dfm = new DecimalFormat(CM_A04_Const.NUMBER_FORMAT);

        return dfm.format(flFileSize) + strFileSizeUnit;
    }

    /**
     * ファイル削除処理.
     *
     * @param _filePath 削除ファイルパス
     */
    public static void deleteFile(final String _filePath) {
        // 前回ファイルを削除
        File deleteFile = new File(_filePath);
        /*
         * ファイルまたはディレクトリが存在しない場合は何もしない
         */
        if (!deleteFile.exists()) {
            return;
        }

        if (deleteFile.isFile()) {
            /*
             * ファイルの場合は削除する
             */
            deleteFile.delete();

        } else if (deleteFile.isDirectory()) {
            /*
             * 対象ディレクトリ内のファイルおよびディレクトリの一覧を取得
             */
            File[] files = deleteFile.listFiles();
            /*
             * ファイルおよびディレクトリをすべて削除
             */
            for (int i = 0; i < files.length; i++) {
                /*
                 * 自身をコールし、再帰的に削除する
                 */
                deleteFile(files[i].getPath());
            }
            /*
             * 自ディレクトリを削除する
             */
            deleteFile.delete();
        }

    }

    /**
     *
     * {当前時間から1番と2番目の最新稼動状態通信時間を取得する。}.<br>
     * <br>
     * 概要:<br>
     * {当前時間から1番と2番目の最新稼動状態通信時間を取得する。} <br>
     *
     * @return 番と2番目の最新稼動状態通信時間
     */
    public static List<Date> getDateForTenMinute() {
        List<Date> retList = new ArrayList<>(2);
        TimeZone tzGmt = CM_CommonUtil.getTimeZone(FW00_19_Const.TZ_GMT);
        Calendar now = Calendar.getInstance(tzGmt);
        now.set(Calendar.SECOND, 0);
        int minute = now.get(Calendar.MINUTE) - now.get(Calendar.MINUTE) % DEVICE_STATUS_UNIT;
        now.set(Calendar.MINUTE, minute);

        Calendar beforeNow = (Calendar) now.clone();

        beforeNow.add(Calendar.MINUTE, -DEVICE_STATUS_UNIT);
        beforeNow.add(Calendar.SECOND, -1);

        retList.add(now.getTime());
        retList.add(beforeNow.getTime());

        return retList;
    }

    /**
     *
     * 四則演算子かどうかのチェック.<br>
     *<br>
     * 概要:<br>
     *   演算子かどうかチェック
     *<br>
     * @param _val チェック対象
     * @return チェック結果
     */
    public static boolean isOperator(final char _val) {

        for (char op : CM_A04_Const.OPERATOR) {
            if (_val == op) {
                return true;
            }
        }
        return false;
    }

    /**
     *
     * 演算子存在チェック.<br>
     * <br>
     * 概要:<br>
     * 演算子存在チェック <br>
     * "で囲われている文字列は、四則演算子も文字列として扱う<br>
     *
     * @param _val
     *            チェック対象
     * @return チェック結果
     */
    public static boolean existsInOperator(final String _val) {
        char[] paramChar = _val.toCharArray();
        // 文字列として扱うかどうか
        boolean isInStr = false;

        for (char c : paramChar) {
            if (CM_A04_Const.OPERATIONAL_CHARACTER.DOUBLE_QUOTATION_CHAR == c) {
                isInStr = !isInStr;
                continue;
            }
            // "で括られている場合は、演算式を許可する
            if (!isInStr && isOperator(c)) {
                return true;
            }
        }
        return false;
    }

    /**
     *
     * 禁則文字チェック.<br>
     *<br>
     * 概要:<br>
     *   禁則文字を含んでいるかチェックする
     *<br>
     * @param _checkStr チェック対象文字列
     * @param _forbidChar 禁則文字
     * @return チェック対象の文字列に含まれている禁則文字(含まれていない場合は、空文字)
     */
    public static String checkForbidCharExists(final String _checkStr, final String[] _forbidChar) {
        // 禁則文字チェック
        for (int i = 0; i < _forbidChar.length; i++) {
            String forbidChar = _forbidChar[i];
            if (isNullOrBlank(forbidChar)) {
                continue;
            }
            if (_checkStr.indexOf(forbidChar) != -1) {
                return forbidChar;
            }
        }
        return FW00_19_Const.EMPTY_STR;
    }

    /**
     *
     * 必須チェック.<br>
     * <br>
     * 概要:<br>
     * 必須項目の入力チェックを行う <br>
     *
     * @param _strValue チェック対象文字列
     * @param _strPItem メッセージID
     * @param _strForcusItem 項目ID
     * @param _sessionDto セッション情報
     */
    public static void checkNecessary(
            final String _strValue, final String _strPItem, final String _strForcusItem, final CM_A03_SessionDto _sessionDto) {

        if (isNullOrBlank(_strValue)) {
            // 必須項目未入力
            // ⇒例外throw

            String strErrorMes = CM_MessageUtil.getEmptyErrorMessage(_sessionDto, _strPItem);

            throw new FW00_12_BusinessException(strErrorMes, _strForcusItem);
        }
    }

    /**
     *
     * 必須チェック.<br>
     * <br>
     * 概要:<br>
     * 必須項目の入力チェックを行う <br>
     *
     * @param _formInfo フォーム情報
     * @param _strItemName 項目名
     * @param _strPItem メッセージID
     * @param _strForcusItem 項目ID
     * @param _sessionDto セッション情報
     */
    public static void checkNecessary(
            final BeanMap _formInfo, final String _strItemName, final String _strPItem, final String _strForcusItem, final CM_A03_SessionDto _sessionDto) {

        if (!_formInfo.containsKey(_strItemName) || isNullOrBlank(_formInfo.get(_strItemName))) {
            // 必須項目未入力
            // ⇒例外throw

            String strErrorMes = CM_MessageUtil.getEmptyErrorMessage(_sessionDto, _strPItem);

            throw new FW00_12_BusinessException(strErrorMes, _strForcusItem);
        }
    }

    /**
     *
     * コマンドコードを10進数から16進数に変換.<br>
     *<br>
     * 概要:<br>
     *   コマンドコードを10進数から16進数に変換する
     *<br>
     * @param _commandCd コマンドコード(10進数)
     * @return コマンドコード(16進数）
     */
    public static String convertCommandCdToHex(final String _commandCd) {
        return convertCommandCdToHex(Integer.parseInt(_commandCd));
    }

    /**
     *
     * コマンドコードを10進数から16進数に変換.<br>
     *<br>
     * 概要:<br>
     *   コマンドコードを10進数から16進数に変換する
     *<br>
     * @param _commandCd コマンドコード(10進数)
     * @return コマンドコード(16進数）
     */
    public static String convertCommandCdToHex(final int _commandCd) {
        return convertCommandCdToHex(_commandCd, true);
    }

    /**
     *
     * コマンドコードを10進数から16進数に変換.<br>
     *<br>
     * 概要:<br>
     *   コマンドコードを10進数から16進数に変換する
     *<br>
     * @param _commandCd コマンドコード(10進数)
     * @param _header ヘッダ有無
     * @return コマンドコード(16進数）
     */
    public static String convertCommandCdToHex(final int _commandCd, final boolean _header) {

        String hexStr = FW00_19_Const.EMPTY_STR;
        if (_header) {
            hexStr += CM_A04_Const.HEX_PREFIX;
        }
        hexStr += String.format(CM_A04_Const.HEX_COMMAND_FORMT, _commandCd).toUpperCase();

        return hexStr;
    }

    /**
     *
     * セッション情報を元に画面が表示できるかどうかを取得.<br>
     *<br>
     * 概要:<br>
     *   セッション情報の権限コード・グループIDを元に画面が表示できるかどうかを取得
     *<br>
     * @param _pageId 画面ID
     * @param _sessionDto セッション情報
     * @return 画面表示可能かどうか
     */
    public static boolean isEnableDisplayPage(final String _pageId, final CM_A03_SessionDto _sessionDto) {
        CM_A06_UserGroupDto groupDto = _sessionDto.ssn_UserGroupSetting[0];

        return isEnableDisplayPage(_pageId, _sessionDto.ssn_AuthorityCode, groupDto.ssn_GroupId);
    }

    /**
     *
     * 権限コード・グループIDを元に画面が表示できるかどうかを取得.<br>
     *<br>
     * 概要:<br>
     *   権限コード・グループIDを元に画面が表示できるかどうかを取得
     *<br>
     * @param _pageId 画面ID
     * @param _ssn_AuthorityCode 権限コード
     * @param _groupId グループID
     * @return 画面表示可能かどうか
     */
    public static boolean isEnableDisplayPage(final String _pageId, final String _ssn_AuthorityCode, final String _groupId) {
        boolean ret = false;

        CM_A05_PageInfo pageInfo = CM_A05_PageInfo.getPageInfo(_pageId);

        if (CM_CommonUtil.isNotNullOrBlank(pageInfo)) {
            if (CM_A04_Const.SYS_ADMIN_AUTH_CD.equals(_ssn_AuthorityCode)) {
                // システム管理者の場合
                if (CM_A04_Const.GROUP_SYS_ROOT_0.equals(_groupId)
                        || CM_A04_Const.GROUP_SYS_ROOT_1.equals(_groupId)) {
                    // グループ指定なしの場合
                    ret = pageInfo.isEnableSysAdim();
                } else {
                    // グループ指定ありの場合
                    ret = pageInfo.isEnableSysGroupAdmin();
                }
            } else {
                // ユーザの場合
                ret = pageInfo.isEnableUser();
            }
        }

        return ret;
    }


    /**
     *
     * セッション情報を元に表示できない画面ID一覧を取得.<br>
     *<br>
     * 概要:<br>
     *   セッション情報を元に表示できない画面ID一覧を取得
     *<br>
     * @param _sessionDto セッション情報
     * @return ユーザ権限がユーザの場合に表示できない画面一覧
     */
    public static List<String> getDisableDisplayPageList(final CM_A03_SessionDto _sessionDto) {
        List<String> ret = null;


        if (CM_A04_Const.SYS_ADMIN_AUTH_CD.equals(_sessionDto.ssn_AuthorityCode)) {
            // システム管理者の場合
            ret = CM_A04_Const.PageInfo.getDisableSysAdminList();
        } else if (CM_A04_Const.INFO_ADMIN_AUTH_CD.equals(_sessionDto.ssn_AuthorityCode)) {
            // 情報システムの場合
            ret = CM_A04_Const.PageInfo.getDisableInfoAdminList();
        } else if (CM_A04_Const.PRODUCTION_ENGINEERING_AUTH_CD.equals(_sessionDto.ssn_AuthorityCode)) {
            // 生産技術の場合
            ret = CM_A04_Const.PageInfo.getDisableProductionEngineeringList();
        } else if (CM_A04_Const.GYOUMU_AUTH_CD.equals(_sessionDto.ssn_AuthorityCode)) {
            // 業務の場合
            ret = CM_A04_Const.PageInfo.getDisableGyoumuAuthList();
        } else if (CM_A04_Const.MANUFACTURING_AUTH_CD.equals(_sessionDto.ssn_AuthorityCode)) {
            // 製造管理者の場合
            ret = CM_A04_Const.PageInfo.getDisableManufacturingList();
        } else if (CM_A04_Const.USER_AUTH_CD.equals(_sessionDto.ssn_AuthorityCode)) {
            // 一般ユーザの場合
            ret = CM_A04_Const.PageInfo.getDisableUserList();
        } else {
            // 製造作業者の場合
            ret = CM_A04_Const.PageInfo.getDisableWorkerList();
        }

        return ret;
    }


    /**
     *
     * 所属グループ設定チェック.<br>
     * <br>
     * 概要:<br>
     * ログインユーザが所属グループ設定を持っているか否かチェックを行う <br>
     *
     * @param _sessionDto セッション情報
     * @return チェック結果(グループ設定を持っている場合はtrue)
     */
    public static boolean checkHasGroup(final CM_A03_SessionDto _sessionDto) {
        String userGroupId = FW00_19_Const.EMPTY_STR;

        // セッションからログインユーザの所属グループIDを取得
        userGroupId = getUserGroupId(_sessionDto);

        // 所属グループIDが "SYS0" "SYS1" のいずれでもない場合、trueを返す
        return checkHasGroup(userGroupId);
    }

    /**
     *
     * 所属グループ設定チェック.<br>
     * <br>
     * 概要:<br>
     * ログインユーザが所属グループ設定を持っているか否かチェックを行う <br>
     *
     * @param _groupId グループID
     * @return チェック結果(グループ設定を持っている場合はtrue)
     */
    public static boolean checkHasGroup(final String _groupId) {

        // 所属グループIDが "SYS0" "SYS1" のいずれでもない場合、trueを返す
        return !checkSystemGroup(_groupId);
    }

    /**
     *
     * システムグループチェック.<br>
     * <br>
     * 概要:<br>
     * ログインユーザがシステムグループか否かチェックを行う <br>
     *
     * @param _groupId グループID
     * @return チェック結果(システムグループの場合はtrue)
     */
    public static boolean checkSystemGroup(final String _groupId) {

        // 所属グループIDが "SYS0" "SYS1" のいずれかの場合、trueを返す
        return CM_A04_Const.GROUP_SYS_ROOT_0.equals(_groupId)
                || CM_A04_Const.GROUP_SYS_ROOT_1.equals(_groupId);
    }

    /**
     *
     * 所属グループ設定チェック.<br>
     * <br>
     * 概要:<br>
     * ログインユーザが所属グループ設定を持っているか否かチェックを行う <br>
     *
     * @param _sessionDto セッション情報
     * @return チェック結果(グループ設定を持っている場合はtrue)
     */
    public static boolean checkSystemGroup(final CM_A03_SessionDto _sessionDto) {
        String userGroupId = FW00_19_Const.EMPTY_STR;

        // セッションからログインユーザの所属グループIDを取得
        userGroupId = getUserGroupId(_sessionDto);

        // 所属グループIDが "SYS0" "SYS1" のいずれでもない場合、trueを返す
        return checkSystemGroup(userGroupId);
    }

    /**
     *
     * ログインユーザのグループID取得.<br>
     *<br>
     * 概要:<br>
     *   セッション情報からログインユーザのグループ情報を取得
     *<br>
     * @param _sessionDto セッション情報
     * @return グループ情報取得
     */
    public static String getUserGroupId(final CM_A03_SessionDto _sessionDto) {
        String ret = FW00_19_Const.EMPTY_STR;

        CM_A06_UserGroupDto groupInfo = getUserGroupDto(_sessionDto);
        // セッションからログインユーザの所属グループIDを取得
        if (isNotNullOrBlank(groupInfo)) {
            ret = groupInfo.ssn_GroupId;
        }
        return ret;
    }

    /**
     *
     * ログインユーザのグループ情報取得.<br>
     *<br>
     * 概要:<br>
     *   セッション情報からログインユーザのグループ情報を取得
     *<br>
     * @param _sessionDto セッション情報
     * @return グループ情報取得
     */
    public static CM_A06_UserGroupDto getUserGroupDto(final CM_A03_SessionDto _sessionDto) {
        CM_A06_UserGroupDto ret = null;
        // セッションからログインユーザの所属グループIDを取得
        if (_sessionDto.ssn_UserGroupSetting.length > 0) {
            ret = _sessionDto.ssn_UserGroupSetting[0];
        }
        return ret;
    }

    /**
     *
     * ユーザ権限が「システム管理者」かどうかのチェック.<br>
     *<br>
     * 概要:<br>
     *   セッション情報からユーザ権限が「システム管理者」かどうかをチェックします。
     *<br>
     * @param _sessionDto セッション情報
     * @return true:システム管理者 false:ユーザ
     */
    public static boolean checkSysAdminUser(final CM_A03_SessionDto _sessionDto) {
        return checkSysAdminUser(_sessionDto.ssn_AuthorityCode);
    }

    /**
    *
    * ユーザ権限コードが「システム管理者」かどうかのチェック.<br>
    *<br>
    * 概要:<br>
    *   ユーザ権限コードからユーザ権限が「システム管理者」かどうかをチェックします。
    *<br>
    * @param _authCd ユーザ権限コード
    * @return true:システム管理者 false:ユーザ
    */
    public static boolean checkSysAdminUser(final String _authCd) {
        return CM_A04_Const.SYS_ADMIN_AUTH_CD.equals(_authCd);
    }

    /**
    *
    * ユーザ権限が「情報システム」かどうかのチェック.<br>
    *<br>
    * 概要:<br>
    *   セッション情報からユーザ権限が「情報システム」かどうかをチェックします。
    *<br>
    * @param _sessionDto セッション情報
    * @return true:情報システム false:ユーザ
    */
   public static boolean checkInfoAdminUser(final CM_A03_SessionDto _sessionDto) {
       return checkInfoAdminUser(_sessionDto.ssn_AuthorityCode);
   }

   /**
   *
   * ユーザ権限コードが「情報システム」かどうかのチェック.<br>
   *<br>
   * 概要:<br>
   *   ユーザ権限コードからユーザ権限が「情報システム」かどうかをチェックします。
   *<br>
   * @param _authCd ユーザ権限コード
   * @return true:システム管理者 false:ユーザ
   */
   public static boolean checkInfoAdminUser(final String _authCd) {
       return CM_A04_Const.INFO_ADMIN_AUTH_CD.equals(_authCd);
   }

    /**
     * デフォルトのアラームアイコン取得処理.<br/>
     * <br/>
     * 概要:<br/>
     * デフォルトのアラームアイコンデータを取得する。 <br/>
     *
     * @param _alarmLv アラームLv
     * @return アラームアイコンデータ
     */
    public static String getDefaultMapIcon(final String _alarmLv) {

        // 共通パス
        String imgPath = CM_A04_Const.DEFAULT_ICON_COMMON_PATH;

        if (CM_CommonUtil.isNotNullOrBlank(_alarmLv)
            && !CM_A04_Const.AlarmIcon.NO_ALARM.alarmLv.equals(_alarmLv)) {
            // 「アラームなし」以外の場合、アラームLvをファイル名に付加
            imgPath += CM_A04_Const.DEFAULT_ICON_COMMON_NAME + _alarmLv;
        }

        // 拡張子を付加
        imgPath += FW00_19_Const.DOT_STR + CM_A04_Const.PIC_EXT.PNG;

        return imgPath;
    }

    /**
     * デフォルトのアラームアイコン取得処理.<br/>
     * <br/>
     * 概要:<br/>
     * アイコンタイプからデフォルトのアラームアイコンデータを取得する。 <br/>
     *
     * @param _iconType アイコンタイプ
     * @return アラームアイコンパス
     */
    public static String getDefaultMapIconByIconType(final String _iconType) {
        String alarmLv = CM_A04_Const.AlarmIcon.getAlarmLv(_iconType);

        return getDefaultMapIcon(alarmLv);
    }

    /**
     * アイコンパスを生成.
     *
     * @param _baseIconPath パス
     * @param _modelSid 型番SID
     * @param _iconType アイコンタイプ
     * @return アイコンのフルパス
     */
    public static String getMapIconPath(final String _baseIconPath, final Integer _modelSid, final String _iconType) {

        String iconPath = _baseIconPath + FW00_19_Const.QUESTION_STR;
        iconPath = iconPath + FW01_14_ListForm.FW0114FORM_MODELSID + FW00_19_Const.EQUAL_STR + String.valueOf(_modelSid);
        iconPath = iconPath + FW00_19_Const.AMPERSAND_STR + FW01_14_ListForm.FW0114FORM_ICONTYPE + FW00_19_Const.EQUAL_STR + _iconType;

        return iconPath;
    }

    /**
     *
     * 画像転送処理.<br/>
     *<br/>
     * 概要:<br/>
     * 失敗時は例外を出さない。戻り値で判別する。<br/>
     *<br/>
     * @param _response HTTPレスポンス
     * @param _sessionDto セッション情報
     * @param _srcPicFilePath 画像ファイルフルパス
     * @param _ext 拡張子
     * @return true:成功/false:失敗
     */
    public static boolean downloadPicFileNoThrow(final HttpServletResponse _response, final CM_A03_SessionDto _sessionDto,
            final String _srcPicFilePath, final String _ext) {

        boolean ret = true;

        ImageOutputStream ios = null;
        try {

            File picfile = new File(_srcPicFilePath);
            BufferedImage im = ImageIO.read(picfile);

            // 拡張子を小文字に変換
            String ext = _ext.toLowerCase();
            String mimeType;

            if (StringUtil.equals(ext, CM_A04_Const.PIC_EXT.BMP)) {
                mimeType = "image/x-bmp";
            } else if (StringUtil.equals(ext, CM_A04_Const.PIC_EXT.PNG)) {
                mimeType = "image/png";
            } else if (StringUtil.equals(ext, CM_A04_Const.PIC_EXT.GIF)) {
                mimeType = "image/gif";
            } else {
                mimeType = "image/jpeg";
            }

            _response.setContentType(mimeType);
            ServletOutputStream sos = _response.getOutputStream();
            ios = ImageIO.createImageOutputStream(sos);
            ImageIO.write(im, ext, ios);

        } catch (Exception e) {
            // 例外情報はログ出力
            CM_LoggerUtil.outputErrorLog(_sessionDto, e);

            ret = false;
        } finally {
            if (ios != null) {
                try {
                    ios.close();
                } catch (IOException e) {
                    // 例外情報はログ出力
                    CM_LoggerUtil.outputErrorLog(_sessionDto, e);
                }
            }
        }

        return ret;
    }

    /**
     * 入力値がIPアドレスのフォーマットとなっているかどうかのチェック.
     *<br>
     * 概要:<br>
     *   入力値がIPアドレスのフォーマットとなっているかどうかのチェックします。
     *<br>
     * @param _str セッション情報
     * @return チェック結果
     */
    public static boolean checkIpAddressFormat(final String _str) {
        // 正規表現を設定
        Pattern pattern = Pattern.compile(CM_A04_Const.IP_ADDRESS_FORMAT);

        return pattern.matcher(_str).matches();
    }

    /**
     * データ型が数値型かどうか判定する.
     *
     * @param _dataType データ型
     * @return 数値型かどうか(true:数値型 false:数値型でない)
     */
    public static boolean checkDataTypeIsNumber(final String _dataType) {
        boolean ret = false;

        // 整数・実数・ビット・符号なし整数型は、数値型とする
        if (CM_A04_Const.DATA_TYPE.INT.equals(_dataType)
                || CM_A04_Const.DATA_TYPE.DECIMAL.equals(_dataType)
                || CM_A04_Const.DATA_TYPE.BIT.equals(_dataType)
                || CM_A04_Const.DATA_TYPE.UNSIGNED_INT.equals(_dataType)) {
            ret = true;
        }

        return ret;
    }

    /**
     * データ型がトレンドモニタで一覧表示対象でないかどうか判定する.
     *
     * @param _dataType データ型
     * @return 一覧表示対象でないかどうか(true:一覧表示対象データでない false:一覧表示対象データ)
     */
    public static boolean checkTrendMonitorListNotDispData(final String _dataType) {
        boolean ret = false;

        // 座標・ファイルはトレンドモニタ一覧表示対象外
        if (CM_A04_Const.DATA_TYPE.POINT.equals(_dataType)
                || CM_A04_Const.DATA_TYPE.FILE.equals(_dataType)) {
            ret = true;
        }

        return ret;
    }

   /**
    *
    * 空き容量チェック.<br>
    * <br>
    * 概要:<br>
    * 空き容量のチェックする. <br>
    *
    * @param _sessionDto セッション情報
    * @param _fileSize ファイルサイズ
    * @return 処理結果
    */
    public static boolean checkDiskSpace(final CM_A03_SessionDto _sessionDto, final int _fileSize) {


        CM_GetMstDataService mstDataService = new CM_GetMstDataService(_sessionDto);

        // 空き容量チェック
        boolean ret = mstDataService.checkDiskSpace(_fileSize);

        // 閾値越えメールの送信
        CM_CommonUtil.checkDiskThreshold(_sessionDto, _fileSize);


        return ret;

    }

    /**
     * 閾値越えチェック.
     *
     * @param _fileSize ファイルサイズ
     * @param _sessionDto セッション情報
     */
    public static void checkDiskThreshold(final CM_A03_SessionDto _sessionDto, final int _fileSize) {
        CM_GetMstDataService mstDataService = new CM_GetMstDataService(_sessionDto);
        mstDataService.checkDiskThreshold(_fileSize);
    }

   /**
    *
    * 機器登録台数チェック.<br>
    * <br>
    * 概要:<br>
    * 機器登録台数をチェックする. <br>
    *
    * @param _sessionDto セッション情報
    * @param _addCount 登録台数
    * @return 処理結果
    */
    public static boolean checkDeviceCount(final CM_A03_SessionDto _sessionDto, final int _addCount) {


        CM_GetMstDataService mstDataService = new CM_GetMstDataService(_sessionDto);

        // 機器登録台数チェック
        return mstDataService.checkDeviceCount((long) _addCount);

    }

    /**
     * 指定した文字エンコーディングでの文字列のバイト数を取得.<br>
     *
     * @param _value 処理対象となる文字列
     * @param _enc 文字エンコード("Shift_JIS", "UTF-8" etc...)
     * @return 文字列のバイト数
     */
    public static int getByteLength(final String _value, final String _enc) {
        int ret = 0;
        if (isNullOrBlank(_value)) {
            return ret;
        }
        try {
            ret = _value.getBytes(_enc).length;
        } catch (Exception e) {
            ret = 0;
        }
        return ret;
    }

    /**
     * byte型の値をint型に変換する.<br>
     * @param _val byte型の値
     * @return int型の値 (符号なし整数)
     */
    public static int getInt(final byte... _val) {
        byte[] inValByte = new byte[CM_A04_Const.BIT_NUM_4];
        int dif = CM_A04_Const.BIT_NUM_4 - _val.length;
        for (int index = 0; index < CM_A04_Const.BIT_NUM_4; ++index) {
            if (dif <= index) {
                inValByte[index] = _val[index - dif];
            } else {
                inValByte[index] = 0;
            }
        }
        return new BigInteger(inValByte).intValue();
    }

    /**
     * byte配列変換.<br>
     *
     * @param _value
     *            変換対象の値
     * @return byte配列に変換された値
     */
    public static byte[] perseByte(final short _value) {
        int arraySize = Short.SIZE / Byte.SIZE;
        ByteBuffer buffer = ByteBuffer.allocate(arraySize);
        return buffer.putShort(_value).array();
    }

    /**
     * byte配列変換.<br>
     *
     * @param _value
     *            変換対象の値
     * @return byte配列に変換された値
     */
    public static byte[] perseByte(final int _value) {
        int arraySize = Integer.SIZE / Byte.SIZE;
        ByteBuffer buffer = ByteBuffer.allocate(arraySize);
        return buffer.putInt(_value).array();
    }

    /**
     * byte配列変換.<br>
     *
     * @param _value
     *            変換対象の値(16進数: 0x00 ～ 0xFF) ※「0x」は含めない
     * @return byte配列に変換された値
     */
    public static byte perseByteFromHex8(final String _value) {
        int val = Integer.parseInt(_value, CM_A04_Const.RADIX.BASE16);
        return perseByte((short) val)[1];
    }

    /**
     * byte配列変換.<br>
     *
     * @param _value
     *            変換対象の値(16進数: 0x0000 ～ 0xFFFF)
     * @return byte配列に変換された値
     */
    public static byte[] perseByteFromHex16(final String _value) {
        if (isNullOrBlank(_value)) {
            return null;
        }
        int val = Integer.parseInt(_value, CM_A04_Const.RADIX.BASE16);
        return perseByte((short) val);
    }

    /**
     * 16進数文字列変換.<br>
     *
     * @param _value
     *            変換対象の値
     * @return 16進数文字列に変換された値
     */
    public static String toHex(final byte _value) {
        return toHex(getInt(_value));
    }

    /**
     * 16進数文字列変換.<br>
     *
     * @param _value
     *            変換対象の値
     * @return 16進数文字列に変換された値
     */
    public static String toHex(final int _value) {
        int val = _value;
        String hexStr = Integer.toHexString(val & CM_A04_Const.HEX_NUM_LOW_HALF);
        hexStr = paddingZero(hexStr, CM_A04_Const.HEX_LENGTH_2).toUpperCase();
        return hexStr;
    }

    /**
     * エラーチェック値を算出する(LRC方式).<br>
     * @param _input 入力値
     * @return 結果
     */
    public static String getLRC(final List<Byte> _input) {
        if (isNullOrEmpty(_input)) {
            return null;
        }
        int cal = 0;
        for (Byte data : _input) {
            cal += getInt(data);
        }
        int resInt = BigInteger.valueOf(cal).not().add(BigInteger.valueOf(1)).intValue();
        return toHex(resInt);
    }

    /**
     * エラーチェック値を算出する(CRC方式).<br>
     * @param _input 入力値
     * @return 結果（2列）
     */
    public static String[] getCRC(final List<Byte> _input) {
        if (isNullOrEmpty(_input)) {
            return null;
        }
        int polynomial = CM_A04_Const.HEX_NUM_CRC_POLYNOMIAL;

        int cal = CM_A04_Const.HEX_NUM_FULL;
        for (Byte data : _input) {
            int intVal = getInt(data);
            cal = (int) (intVal ^ cal);
            for (int count = 0; count < CM_A04_Const.BIT_NUM_8; ++count) {
                cal >>>= 1;
                if ((cal & 1) == 1) {
                    cal ^= polynomial;
                }
            }
        }

        String[] res = new String[2];
        res[0] = Integer.toHexString(cal & CM_A04_Const.HEX_NUM_LOW_HALF);
        res[0] = paddingZero(res[0], CM_A04_Const.HEX_LENGTH_2).toUpperCase();
        res[1] = Integer.toHexString((cal & CM_A04_Const.HEX_NUM_HIGH_HALF) >> CM_A04_Const.BIT_NUM_8);
        res[1] = paddingZero(res[1], CM_A04_Const.HEX_LENGTH_2).toUpperCase();

        return res;
    }

    /**
     * 文字列ゼロ埋め.<br>
     *
     * @param _value
     *            対象の値
     * @param _length
     *            サイズ
     * @return ゼロ埋めされた値
     */
    public static String paddingZero(final int _value, final int _length) {

        return paddingZero(String.valueOf(_value), _length);
    }

    /**
     * 文字列ゼロ埋め.<br>
     *
     * @param _value
     *            対象の値
     * @param _length
     *            サイズ
     * @return ゼロ埋めされた値
     */
    public static String paddingZero(final String _value, final int _length) {
        String res = _value;
        while (res.length() < _length) {
            res = "0" + res;
        }
        return res;
    }

    /**
     * 文字列変換.<br>
     *<br>
     * 概要:<br>
     *   型を判断し値を文字列に変換する。<br>
     *<br>
     * @param _value
     *            対象の値
     * @return 文字列
     */
    public static String parseString(final Object _value) {
        return parseString(_value, null, null);
    }

    /**
     * 文字列変換.<br>
     *<br>
     * 概要:<br>
     *   型を判断し値を文字列に変換する。<br>
     *<br>
     * @param _value
     *            対象の値
     * @param _scale
     *            BigDecimalの丸め桁数
     * @param _roundingMode
     *            BigDecimalの丸めモード
     * @return 文字列
     */
    public static String parseString(final Object _value, final Integer _scale, final Integer _roundingMode) {
        String res = null;
        if (CM_CommonUtil.isNotNullOrBlank(_value)) {
            if (_value instanceof Integer) {
                Integer val = (Integer) _value;
                res = Integer.toString(val);
            } else if (_value instanceof BigInteger) {
                BigInteger val = (BigInteger) _value;
                res = val.toString();
            } else if (_value instanceof Long) {
                Long val = (Long) _value;
                res = Long.toString(val);
            } else if (_value instanceof Double) {
                Double val = (Double) _value;
                BigDecimal valDec = new BigDecimal(val);
                if (isNotNullOrBlank(_scale) && isNotNullOrBlank(_roundingMode)) {
                    valDec = valDec.setScale(_scale, _roundingMode);
                }
                res = valDec.stripTrailingZeros().toString();
            } else if (_value instanceof BigDecimal) {
                BigDecimal val = (BigDecimal) _value;
                if (isNotNullOrBlank(_scale) && isNotNullOrBlank(_roundingMode)) {
                    val = val.setScale(_scale, _roundingMode);
                }
                res = val.stripTrailingZeros().toPlainString();
            } else if (_value instanceof String) {
                res = (String) _value;
            } else {
                Number val = (Number) _value;
                res = val.toString();
            }
        }
        return res;
    }

    /**
     * Object形式のデータからLong型の値を取得する.
     *
     * @param _value 値(数値)
     * @return 値 (Long型)
     */
    public static Long getLongVal(final Object _value) {
        Long res = null;
        if (isNullOrBlank(_value)) {
            return null;
        }

        if (_value instanceof Integer) {
            res = (Long) _value;
        } else if (_value instanceof Long) {
            res = (Long) _value;
        } else if (_value instanceof BigInteger) {
            BigInteger objBuf = (BigInteger) _value;
            res = objBuf.longValue();
        } else if (_value instanceof BigDecimal) {
            BigDecimal objBuf = (BigDecimal) _value;
            res = objBuf.longValue();
        } else if (_value instanceof Double) {
            Double val = (Double) _value;
            res = val.longValue();
        } else {
            res = Long.valueOf(String.valueOf(_value));
        }
        return res;
    }

    /**
     * Object形式のデータからInteger型の値を取得する.
     *
     * @param _value 値(数値)
     * @return 値 (Long型)
     */
    public static Integer getIntegerVal(final Object _value) {
        Integer res = null;
        if (isNullOrBlank(_value)) {
            return null;
        }

        if (_value instanceof Integer) {
            res = (Integer) _value;
        } else if (_value instanceof Long) {
            res = ((Long) _value).intValue();
        } else if (_value instanceof BigInteger) {
            BigInteger objBuf = (BigInteger) _value;
            res = objBuf.intValue();
        } else if (_value instanceof BigDecimal) {
            BigDecimal objBuf = (BigDecimal) _value;
            res = objBuf.intValue();
        } else if (_value instanceof Double) {
            Double val = (Double) _value;
            res = val.intValue();
        } else {
            res = Integer.valueOf(String.valueOf(_value));
        }
        return res;
    }

    /**
     * 任意データポイント利用可否チェック.<br>
     *
     *
     * @param _sessionDto セッション情報
     * @return 任意データポイント利用可否（true：利用可 false:利用不可）
     */
    public static boolean isUseOptionDataPoint(final CM_A03_SessionDto _sessionDto) {

        boolean ret = false;

        BeanMap sysEnv = CM_SysEnvDataUtil.selectSysEnv(_sessionDto,
                CM_A04_Const.SYS_ENV_MST_ENV_CD.USE_OPTION_DATA_POINT, CM_A04_Const.SYS_ENV_MST_ITEM_CD.OPTION_AVAILABLE);

        if (CM_CommonUtil.isNotNullOrBlank(sysEnv)) {
            String sysName = sysEnv.get(SysEnvEntityNames.name()).toString();
            ret = isUseOptionDataPoint(sysName);
        }

        return ret;
    }

    /**
     * 任意データポイント利用可否チェック.<br>
     *
     *
     * @param _sysEnvEntity 環境マスタ
     * @return 任意データポイント利用可否（true：利用可 false:利用不可）
     */
    public static boolean isUseOptionDataPoint(final SysEnvEntity _sysEnvEntity) {

        boolean ret = false;

        if (CM_CommonUtil.isNotNullOrBlank(_sysEnvEntity)) {

            ret = isUseOptionDataPoint(_sysEnvEntity.name);
        }

        return ret;
    }

    /**
     * 任意データポイント利用可否チェック.<br>
     *
     *
     * @param _sysEnvName 環境マスタ名称
     * @return 任意データポイント利用可否（true：利用可 false:利用不可）
     */
    public static boolean isUseOptionDataPoint(final String _sysEnvName) {

        boolean ret = false;

        if (CM_A04_Const.FLG.ON.equals(_sysEnvName)) {
            ret = true;
        }

        return ret;
    }

    /**
     * 通知フラグ判定.
     *
     * @param _strNoticeFlg 通知フラグ(0or1)
     * @return 通知フラグ
     */
    public static boolean checkNoticeFlg(final String _strNoticeFlg) {
        boolean ret = false;
        if (CM_A04_Const.FLG.ON.equals(_strNoticeFlg)) {
            ret = true;
        }
        return ret;
    }

    /**
     * メール送信処理.
     *
     * @param _sessionDto セッション情報
     * @param _mailTemplateMap メールテンプレートMAP
     * @param _mailAddressList メールアドレス一覧
     * @param _noticeThreshold 閾値
     */
    public static void sendOverCapacityErrorMail(final CM_A03_SessionDto _sessionDto, final Map<String, MstMailTemplateEntity> _mailTemplateMap,
            final List<String> _mailAddressList, final String _noticeThreshold) {
        try {
            // メール設定情報取得
            List<BeanMap> mailSetting = CM_SysEnvDataUtil.selectListSysEnv(_sessionDto, CM_A04_Const.SYS_ENV_MST_ENV_CD.MAIL_SEND_SETTING);
            Map<String, String> mailSettingInfo = new HashMap<String, String>();
            for (BeanMap envEntity : mailSetting) {
                mailSettingInfo.put(envEntity.get(SysEnvEntityNames.itemCd()).toString(), envEntity.get(SysEnvEntityNames.name()).toString());
            }

            // 送信
            Map<String, Object> mailInfo = new HashMap<String, Object>();

            // IPアドレス
            mailInfo.put(FW00_08_SendMailUtil.IP_ADDRESS, mailSettingInfo.get(CM_A04_Const.SYS_ENV_MST_ITEM_CD.IP_ADDRESS));

            // 送信元アドレス
            mailInfo.put(FW00_08_SendMailUtil.FROM_ADDRESS, mailSettingInfo.get(CM_A04_Const.SYS_ENV_MST_ITEM_CD.MAIL_ADDRESS));

            // メールテンプレート取得
            MstMailTemplateEntity templateEntity = _mailTemplateMap.get(CM_A04_Const.CST_LANG_CD_JPN);
            // タイトル
            mailInfo.put(FW00_08_SendMailUtil.SUBJECT, templateEntity.mailTitle);
            // メール本文
            String mailText = templateEntity.mailText.replace("\\r\\n", "\r\n");
            String replaceThresholdStr = CM_TelecomConst.MailParam.PARAM_ID + CM_TelecomConst.MailParam.CONTRACT_THRESHOLD + CM_TelecomConst.MailParam.PARAM_ID;
            mailText = mailText.replace(replaceThresholdStr, _noticeThreshold);
            mailInfo.put(FW00_08_SendMailUtil.TEXT, mailText);

            FW00_08_SendMailUtil sendMail = new FW00_08_SendMailUtil(mailInfo);
            List<InternetAddress> mailAddressInfo = new ArrayList<InternetAddress>();
            for (String mailAddress : _mailAddressList) {
                InternetAddress address = new InternetAddress(mailAddress);
                mailAddressInfo.add(address);
            }

            InternetAddress[] addrArrayTo = (InternetAddress[]) mailAddressInfo.toArray(new InternetAddress[0]);
            InternetAddress[] addrArrayCc = new InternetAddress[]{};
            InternetAddress[] addrArrayBcc = new InternetAddress[]{};
            sendMail.sendMail(addrArrayTo, addrArrayCc, addrArrayBcc);

        } catch (Exception e) {
            CM_LoggerUtil.outputErrorLog(_sessionDto, e);
        }
    }

    /**
     * 現在日付のDateオブジェクトを生成します。 このメソッドが返す時刻の精度は1秒単位です。
     *
     * @return 現在日付のDateオブジェクトを返します。
     */
    public static Date getSysdate() {
        return new Date((System.currentTimeMillis() / 1000) * 1000);
    }

    /**
     * Dateから年(yyyy)を取得します。
     *
     * @param date
     *            対象となるDateオブジェクト
     * @return 年(yyyy)を返します。
     */
    public static String getYYYY(Date date) {

        DateFormat pattern = new SimpleDateFormat("yyyy");
        return pattern.format(date);
    }

    /**
     * Dateから月(MM)を取得します。
     *
     * @param date
     *            対象となるDateオブジェクト
     * @return 月(MM)を返します。
     */
    public static String getMM(Date date) {

        DateFormat pattern = new SimpleDateFormat("MM");
        return pattern.format(date);
    }

    /**
     * Dateから日付(dd)を取得します。
     *
     * @param date
     *            対象となるDateオブジェクト
     *
     * @return 日付(dd)を返します。
     */
    public static String getDD(Date date) {
        DateFormat pattern = new SimpleDateFormat("dd");
        return pattern.format(date);
    }

    /**
     * Dateから、該当年月の最終日を取得します
     *
     * @param date
     *            対象となるDateオブジェクト
     * @return 該当年月の最終日を返します。
     */
    public static String getEndDay( Date date ) {
        SimpleDateFormat format = new SimpleDateFormat( "yyyy/MM" );
        format.format( date );
        Calendar c = format.getCalendar();
        return Integer.toString( c.getActualMaximum( Calendar.DATE ) );
    }

    /**
     * 日付(yyyy/MM/dd)または日付時刻(yyyy/MM/dd HH:mm:ss)文字列からDateオブジェクトを生成します。
     *
     * @param dateString
     *            日付・日付時刻文字列
     * @param isDateTime
     *            日付時刻文字列ならtrue、日付のみならfalse
     * @return 引数で受け取ったオブジェクトをDate型にフォーマットした結果を返します。
     */
    public static Date fromString( String dateString, String format ) {
        return parseString( dateString, format );
    }

    /**
     * 日付文字列、書式文字列からDateオブジェクトを生成します。<br>
     * 引数で受け取ったdateStringがnullまたは空白、あるいはformatStringがnullだった場合、nullを返します。
     *
     * @param dateString
     *            日付・日付時刻文字列
     * @param formatString
     *            書式文字列
     * @return 引数で受け取ったオブジェクトをDate型にフォーマットした結果を返します。
     */
    public static Date parseString( String dateString, String formatString ) {

        Date result = null;
        DateFormat pattern = new SimpleDateFormat( formatString );
        try {
            pattern.setLenient( false );
            result = pattern.parse( dateString );
        } catch ( ParseException | NullPointerException e ) {
            result = null;
        }

        return result;
    }

    /**
     * 日付文字列、書式文字列からTimestampオブジェクトを生成します。<br>
     * 引数で受け取ったdateStringがnullまたは空白、あるいはformatStringがnullだった場合、nullを返します。
     *
     * @param dateString
     *            日付・日付時刻文字列
     * @param formatString
     *            書式文字列
     * @return 引数で受け取ったオブジェクトをTimestamp型にフォーマットした結果を返します。
     */
    public static Timestamp parseStringToTimestamp(String dateString, String formatString) {

        Timestamp result = null;

        try {
            result = new Timestamp(new SimpleDateFormat(formatString).parse(dateString).getTime());;
        } catch ( ParseException | NullPointerException e ) {
            result = null;
        }

        return result;
    }

    /**
     * Dateオブジェクトを規定の書式文字列でフォーマットします。
     *
     * @param d
     *            対象となるDateオブジェクト
     * @param format
     *            書式文字列
     * @return 引数で受け取ったオブジェクトを文字列型にフォーマットした結果を返します。
     */
    public static String toDateTimeString( Date d, String format ) {

        return ( new SimpleDateFormat( format ) ).format( d );
    }
    /**
     * ステータスカラー文字列取得.<br>
     * 概要:<br>
     * ラインステータスリスト内でステータスに対応したカラー文字列を返す<br>
     * 備考:<br>
     *
     * @param _status ステータス
     * @return カラーコードString(#ffffff etc)
     */
    public static String getStatusColor(final Integer _status) {

        if (isInit) {
            return "#ffffff";
        }
        String ret = "#ffffff";
        if (_status != null) {
            for (BeanMap m : lineStatusList) {
                if (m.get(SysNameEntityNames.itemCd().toString()).toString().equals(_status.toString())) {
                    ret = m.get(SysNameEntityNames.name2().toString()).toString();
                    break;
                }
            }
        }

        return ret;
    }
    /**
     * ステータス文字列取得.<br>
     * 概要:<br>
     * ラインステータスリスト内でステータスに対応した文字列を返す<br>
     * 備考:<br>
     *
     * @param _status ステータス
     * @return ステータスString(稼働中 etc)
     */
    public static String getStatusText(final Integer _status) {

        if (isInit) {
            return "";
        }
        String ret = "";
        if (_status != null) {
            for (BeanMap m : lineStatusList) {
                if (m.get(SysNameEntityNames.itemCd().toString()).toString().equals(_status.toString())) {
                    ret = m.get(SysNameEntityNames.name1().toString()).toString();
                    break;
                }
            }
        }

        return ret;
    }

    /**
     * ラインステータスリスト編集.
     * @param _session セッションDTO
     */
    public static void initLineStatusList(final CM_A03_SessionDto _session) {

        if (!isInit) {
            return;
        }

        lineStatusList = CM_SysNameDataUtil.getNameList(_session,
                CM_A04_Const.SYS_NAME_MST_NAME_TYPE.LINE_STATUS , _session.ssn_UserLangCD);

        isInit = false;

    }

    /**
     * BigDecimal型の小数点以下不要0削除.<br>
     * @param _val 値
     * @return 小数点の不要な0無しBigDecimal
     */
    public static BigDecimal trim(final BigDecimal _val) {
        BigDecimal val = _val;
        try {
            while (val.scale() > 0) {
                val = val.setScale(val.scale() - 1);
            }
        } catch (ArithmeticException e) {
            // no more trailing zeroes so exit.
            return val;
        }
        return val;
    }

    /**
     *
     * サーバタイムゾーンとの時差を取得.<br>
     *<br>
     * 概要:<br>
     *   サーバタイムゾーンとログインユーザのタイムゾーンの時差を取得する
     *<br>
     * @param _userTimezone ログインユーザタイムゾーン
     * @return 時差(単位：秒)
     */
    public static int getZoneOffset(final String _userTimezone) {
        // TODO サーバが日本にあることを想定
        String serverTimeZone = FW00_19_Const.TZ_JPN;
        // タイムゾーンオフセット(日本時間との差)
        Calendar calServer = Calendar.getInstance(TimeZone.getTimeZone(serverTimeZone));
        Calendar calUser = Calendar.getInstance(TimeZone.getTimeZone(_userTimezone));
        int offset = calUser.get(Calendar.ZONE_OFFSET) - calServer.get(Calendar.ZONE_OFFSET);
        if (offset != 0) {
            offset = offset / FW00_19_Const.MILLI;
        }

        return offset;
    }

    /**
     * 年月日のフォーマットチェック.<br>
     *<br>
     * 概要:<br>
     *   指定した年月日から前月を取得する
     *<br>
     * @param _year 年
     * @return _month 前月
     */
    public static String dateFormatCheck(final String _date) {
        String tmp;

        String strYear;
        String strMonth;
        String strDay;

        int pos;

        // 年は4桁でくる
        if (_date.length() <= 4) {
            return _date;
        }

        // 年の取得
        strYear= _date.substring(0, 4);
        tmp = _date.substring(5);

        // "-"がでてくるまでの文字数を取得
        pos = tmp.indexOf("-");
        if (pos == 1) {
            // 月が1桁
            strMonth = tmp.substring(0, 1);
            strMonth = "0" + strMonth;
        } else if (pos == 2){
            // 月が2桁
            strMonth = tmp.substring(0, 2);
        } else {
            if (tmp.length() == 2) {
                strMonth = tmp;
                return strYear + "-" + strMonth;
            } else if (tmp.length() == 1) {
                strMonth = "0" + tmp;
                return strYear + "-" + strMonth;
            } else {
                return strYear;
            }
        }

        // 残りの文字列を更新
        tmp = tmp.substring(pos + 1);

        if (tmp.length() == 1) {
            // 日が1桁
            strDay = "0" + tmp;
        } else if (tmp.length() == 2){
            // 日が2桁
            strDay = tmp;
        } else {
            return strYear + "-" + strMonth;
        }

        return strYear + "-" + strMonth + "-" + strDay;
    }

    /**
    *
    * 変数の型の変換.<br/>
    * <br/>
    * 概要:<br/>
    *  フォーム情報内の共通変数の型変換<br/>
    * <br/>
    * @param _formMap フォーム情報
    */
    public static void convertParamType(final BeanMap _formMap) {
        // 製造ラインID
        Long seizouLnId = CM_CommonUtil.getLongVal(_formMap.get(CM_BaseForm.COM_SEIZOU_LN_ID));
        _formMap.put(CM_BaseForm.COM_SEIZOU_LN_ID, seizouLnId);
        // 工程ID
        Long processId = CM_CommonUtil.getLongVal(_formMap.get(CM_BaseForm.COM_PROCESS_ID));
        _formMap.put(CM_BaseForm.COM_PROCESS_ID, processId);
        // ラインID
        Long lnId = CM_CommonUtil.getLongVal(_formMap.get(CM_BaseForm.COM_LN_ID));
        _formMap.put(CM_BaseForm.COM_LN_ID, lnId);
        // STID
        Long stId = CM_CommonUtil.getLongVal(_formMap.get(CM_BaseForm.COM_ST_ID));
        _formMap.put(CM_BaseForm.COM_ST_ID, stId);
    }
}
