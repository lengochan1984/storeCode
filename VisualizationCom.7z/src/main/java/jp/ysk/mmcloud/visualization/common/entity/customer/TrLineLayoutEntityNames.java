package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link TrLineLayoutEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class TrLineLayoutEntityNames {

    /**
     * lnIdのプロパティ名を返します。
     * 
     * @return lnIdのプロパティ名
     */
    public static PropertyName<BigDecimal> lnId() {
        return new PropertyName<BigDecimal>("lnId");
    }

    /**
     * vertPagePosのプロパティ名を返します。
     * 
     * @return vertPagePosのプロパティ名
     */
    public static PropertyName<Integer> vertPagePos() {
        return new PropertyName<Integer>("vertPagePos");
    }

    /**
     * horiPagePosのプロパティ名を返します。
     * 
     * @return horiPagePosのプロパティ名
     */
    public static PropertyName<Integer> horiPagePos() {
        return new PropertyName<Integer>("horiPagePos");
    }

    /**
     * vertFramePosのプロパティ名を返します。
     * 
     * @return vertFramePosのプロパティ名
     */
    public static PropertyName<Integer> vertFramePos() {
        return new PropertyName<Integer>("vertFramePos");
    }

    /**
     * horiFramePosのプロパティ名を返します。
     * 
     * @return horiFramePosのプロパティ名
     */
    public static PropertyName<Integer> horiFramePos() {
        return new PropertyName<Integer>("horiFramePos");
    }

    /**
     * layoutIdのプロパティ名を返します。
     * 
     * @return layoutIdのプロパティ名
     */
    public static PropertyName<Integer> layoutId() {
        return new PropertyName<Integer>("layoutId");
    }

    /**
     * dispAllow1Enableのプロパティ名を返します。
     * 
     * @return dispAllow1Enableのプロパティ名
     */
    public static PropertyName<Integer> dispAllow1Enable() {
        return new PropertyName<Integer>("dispAllow1Enable");
    }

    /**
     * dispAllow2Enableのプロパティ名を返します。
     * 
     * @return dispAllow2Enableのプロパティ名
     */
    public static PropertyName<Integer> dispAllow2Enable() {
        return new PropertyName<Integer>("dispAllow2Enable");
    }

    /**
     * dispAllow3Enableのプロパティ名を返します。
     * 
     * @return dispAllow3Enableのプロパティ名
     */
    public static PropertyName<Integer> dispAllow3Enable() {
        return new PropertyName<Integer>("dispAllow3Enable");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _TrLineLayoutNames extends PropertyName<TrLineLayoutEntity> {

        /**
         * インスタンスを構築します。
         */
        public _TrLineLayoutNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _TrLineLayoutNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _TrLineLayoutNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * lnIdのプロパティ名を返します。
         *
         * @return lnIdのプロパティ名
         */
        public PropertyName<BigDecimal> lnId() {
            return new PropertyName<BigDecimal>(this, "lnId");
        }

        /**
         * vertPagePosのプロパティ名を返します。
         *
         * @return vertPagePosのプロパティ名
         */
        public PropertyName<Integer> vertPagePos() {
            return new PropertyName<Integer>(this, "vertPagePos");
        }

        /**
         * horiPagePosのプロパティ名を返します。
         *
         * @return horiPagePosのプロパティ名
         */
        public PropertyName<Integer> horiPagePos() {
            return new PropertyName<Integer>(this, "horiPagePos");
        }

        /**
         * vertFramePosのプロパティ名を返します。
         *
         * @return vertFramePosのプロパティ名
         */
        public PropertyName<Integer> vertFramePos() {
            return new PropertyName<Integer>(this, "vertFramePos");
        }

        /**
         * horiFramePosのプロパティ名を返します。
         *
         * @return horiFramePosのプロパティ名
         */
        public PropertyName<Integer> horiFramePos() {
            return new PropertyName<Integer>(this, "horiFramePos");
        }

        /**
         * layoutIdのプロパティ名を返します。
         *
         * @return layoutIdのプロパティ名
         */
        public PropertyName<Integer> layoutId() {
            return new PropertyName<Integer>(this, "layoutId");
        }

        /**
         * dispAllow1Enableのプロパティ名を返します。
         *
         * @return dispAllow1Enableのプロパティ名
         */
        public PropertyName<Integer> dispAllow1Enable() {
            return new PropertyName<Integer>(this, "dispAllow1Enable");
        }

        /**
         * dispAllow2Enableのプロパティ名を返します。
         *
         * @return dispAllow2Enableのプロパティ名
         */
        public PropertyName<Integer> dispAllow2Enable() {
            return new PropertyName<Integer>(this, "dispAllow2Enable");
        }

        /**
         * dispAllow3Enableのプロパティ名を返します。
         *
         * @return dispAllow3Enableのプロパティ名
         */
        public PropertyName<Integer> dispAllow3Enable() {
            return new PropertyName<Integer>(this, "dispAllow3Enable");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
