package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ユーザマスタ : 当システムにログインするユーザのアカウントを管理する。
名称系はすべて名前マスタ
 * 
 */
@Entity
@Table(name = "mst_user")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class MstUserEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** SID */
    @Id
    @Column(precision = 10, nullable = false, unique = true)
    public Integer sid;

    /** ユーザID : ログインに使用するユーザアカウントのID */
    @Column(length = 32, nullable = false, unique = true)
    public String id;

    /** ユーザ名（姓） : 必須 */
    @Column(length = 64, nullable = false, unique = false)
    public String userLastname;

    /** ユーザ名（名） : 必須 */
    @Column(length = 64, nullable = false, unique = false)
    public String userFirstname;

    /** ユーザ名（セイ） : NULL許可 */
    @Column(length = 64, nullable = true, unique = false)
    public String userLastnameKana;

    /** ユーザ名（メイ） : NULL許可 */
    @Column(length = 64, nullable = true, unique = false)
    public String userFirstnameKana;

    /** ユーザ権限CD : ユーザの権限。一般ユーザ、システム管理者
名称マスタ（システム用）の名称種別="user_auth"とリンク。 */
    @Column(length = 64, nullable = false, unique = false)
    public String userAuthCd;

    /** パスワード : ユーザのログインパスワード。暗号化する。 */
    @Column(length = 256, nullable = false, unique = false)
    public String passwd;

    /** タイムゾーンCD : タイムゾーンを保持。
環境マスタの環境CD="timezone"とリンク。 */
    @Column(length = 64, nullable = false, unique = false)
    public String timezoneCd;

    /** 言語CD : ユーザの使用言語を保持。
名称マスタ（システム用）の名称種別="language"とリンク。 */
    @Column(length = 64, nullable = false, unique = false)
    public String langCd;

    /** テーマカラーCD : テーマカラー
名称マスタ（システム用）の名称種別="theme_color"とリンク。 */
    @Column(length = 64, nullable = false, unique = false)
    public String themeColorCd;

    /** 時計表示フラグ : 時計の表示形式。
名称マスタ（システム用）の名称種別="clock_disp"とリンク。 */
    @Column(length = 64, nullable = false, unique = false)
    public String clockDispFlag;

    /** 文字サイズ : 画面文字サイズ
名称マスタ（システム用）の名称種別="char_size"とリンク。 */
    @Column(length = 64, nullable = false, unique = false)
    public String charSize;

    /** アカウント無効フラグ : ユーザの有効、無効。
名称マスタ（システム用）の名称種別="invalid_flag"とリンク。
 */
    @Column(length = 64, nullable = false, unique = false)
    public String invalidFlag;

    /** 失効日時 : パスワードの有効期限 */
    @Column(nullable = false, unique = false)
    public Timestamp expTim;

    /** 削除フラグ : true：有効、false：無効 */
    @Column(length = 1, nullable = false, unique = false)
    public Boolean deleteFlag;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
