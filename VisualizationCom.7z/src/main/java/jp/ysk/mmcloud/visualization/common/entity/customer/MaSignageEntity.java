package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * サイネージマスタ
 * 
 */
@Entity
@Table(name = "ma_signage")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class MaSignageEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** サイネージID */
    @Id
    @Column(length = 33, nullable = false, unique = true)
    public String signageId;

    /** 拠点集計区分 */
    @Column(length = 2, nullable = true, unique = false)
    public String facilitySummaryKind;

    /** 製品グループ集計区分 */
    @Column(length = 2, nullable = true, unique = false)
    public String groupSummaryKind;

    /** リードタイム出力期間単位 */
    @Column(length = 2, nullable = true, unique = false)
    public String leadtimePeriodUnit;

    /** リードタイム出力期間 */
    @Column(precision = 10, nullable = true, unique = false)
    public Integer leadtimePeriod;

    /** リードタイム表示単位 */
    @Column(length = 2, nullable = true, unique = false)
    public String leadtimeHistUnit;

    /** リードタイム表示最大値 */
    @Column(precision = 10, nullable = true, unique = false)
    public Integer leadtimeHistMaxNum;

    /** リードタイム表示最小値 */
    @Column(precision = 10, nullable = true, unique = false)
    public Integer leadtimeHistMinNum;

    /** 日別稼働時間出力期間 */
    @Column(precision = 10, nullable = true, unique = false)
    public Integer dailyOpeTimePeriod;

    /** 年別生産台数出力期間 */
    @Column(precision = 10, nullable = true, unique = false)
    public Integer yearlyProductNumPeriod;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
