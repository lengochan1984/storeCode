/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/03/05| 新規作成                           | 1.00.00| YSK)鬼丸
 *  2016/02/25| <40000-025> 変更仕様No.25          | 4.00.00| US)萩尾
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.beans.util.Beans;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.entity.customer.SysEnvEntityNames;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.common.util.CM_ComparatorByDisplayOrder;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.common.util.CM_SysEnvDataUtil;
import jp.ysk.mmcloud.common.util.CM_SysNameDataUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.CM_A05_PageInfo;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_GetMenuAuthInfoDao;
import jp.ysk.mmcloud.visualization.common.dto.CM_MenuConstitutionDto;
import jp.ysk.mmcloud.visualization.common.dto.CM_PageAuthInfoDto;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaMenuItemsEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaSettingMenuItemsEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.SysNameEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSearchConditionEntityNames;


/**
 * 画面共通サービス.<br>
 *<br>
 * 概要:<br>
 *   画面共通処理のサービスクラスの
 *<br>
 */
public class CM_BaseService {

    /**
     * セッション情報.
     */
    protected CM_A03_SessionDto sessionDto = null;

    /**
     * 顧客DB接続文字列.
     */
    private String strConnectString;

    /**
     * 顧客DB接続ユーザ.
     */
    private String strConnectUserId;

    /**
     * 顧客DB接続パスワード.
     */
    private String strConnectPasswd;

    /**
     * コンストラクタ.
     *<br>
     * 概要:<br>
     *   DB接続を行わないサービス処理用コンストラクタ
     */
    public CM_BaseService() {
    }

    /**
     * コンストラクタ.
     *<br>
     * 概要:<br>
     *   DB接続を行うサービス処理用コンストラクタ
     *<br>
     * @param _sessionDto 共通セッション情報
     */
    public CM_BaseService(final CM_A03_SessionDto _sessionDto) {

        // セッション情報をメンバ変数に保存
        this.sessionDto = _sessionDto;

        this.setCustomerDbInfo(_sessionDto.ssn_ConnectString,
                _sessionDto.ssn_ConnectUserID, _sessionDto.ssn_ConnectPassword);
    }


    /**
     *
     * 顧客DB接続情報の設定.<br>
     *<br>
     * 概要:<br>
     *   顧客DB接続情報のセット
     *<br>
     * @param _strConnectString 顧客DB接続情報
     * @param _strConnectUserId 顧客DBユーザID
     * @param _strConnectPasswd 顧客DBパスワード
     */
    public void setCustomerDbInfo(final String _strConnectString,
            final String _strConnectUserId,
            final String _strConnectPasswd) {
        this.strConnectString = _strConnectString;
        this.strConnectUserId = _strConnectUserId;
        this.strConnectPasswd = _strConnectPasswd;

    }

    /**
     *
     * 顧客DB接続初期化処理.<br>
     *<br>
     * 概要:<br>
     *   顧客DB接続の初期化処理を実行する
     *<br>
     * @param _baseDao 顧客DB用Dao
     */
    protected void initCustomerDbDao(final CM_BaseDao _baseDao) {
        _baseDao.setCustomerDbInfo(this.strConnectString, this.strConnectUserId, this.strConnectPasswd);
    }

    /**
     *
     * 顧客DB接続初期化処理.<br>
     *<br>
     * 概要:<br>
     *   顧客DB接続の初期化処理を実行する
     *<br>
     * @param _sessionDto 共通セッション情報
     */
    public void setCustomerDbInfo(final CM_A03_SessionDto _sessionDto) {

        // セッション情報をメンバ変数に保存
        this.sessionDto = _sessionDto;

        this.setCustomerDbInfo(_sessionDto.ssn_ConnectString,
                _sessionDto.ssn_ConnectUserID, _sessionDto.ssn_ConnectPassword);
    }

    /**
     *
     * 初期化処理.<br>
     *<br>
     * 概要:<br>
     *   顧客DB接続初期化処理にDaoを設定
     *<br>
     * @param _sessionDto 共通セッション情報
     */
    public void init(final CM_A03_SessionDto _sessionDto) {

        this.setCustomerDbInfo(_sessionDto);
        // 処理開始
        this.initCustomerDbDao(getCustomerDao());
    }

    /**
     * 画面データアクセスDaoを取得.<br>
     * <br>
     * 概要:<br>
     *   画面データアクセスDaoを取得
     *
     *
     * @return 画面データアクセスDao
     */
    protected CM_BaseDao getCustomerDao() {
        return null;
    }

    /**
     * TOPページURL情報取得.<br>
     * <br>
     * 概要:<br>
     *   TOPページのURL情報を取得
     *
     * @return TOPページのURL情報
     */
    public String getTopPageUrlDef() {
        String res = null;
        List<BeanMap> favoriteList = this.getCustomerDao().selectFavoritePage(this.sessionDto.ssn_UserSID, 0);
        if (favoriteList != null && !favoriteList.isEmpty()) {
            String pageId = (String) favoriteList.get(0).get(TrSearchConditionEntityNames.pageId().toString());
            res = this.getPageUrlStr(pageId);
        }
        return res;
    }

    /**
     * お気に入りリストを取得.<br>
     * <br>
     * 概要:<br>
     *   ユーザーのお気に入り情報を取得
     *
     * @return お気に入り情報
     */
    public List<BeanMap> getFavoriteList() {
        List<BeanMap> favoriteList = this.getCustomerDao().selectFavoritePage(this.sessionDto.ssn_UserSID, null);

        List<BeanMap> resList = new ArrayList<BeanMap>();
        for (BeanMap favorite : favoriteList) {
            String pageId = (String) favorite.get(TrSearchConditionEntityNames.pageId().toString());

            // メニュー情報が取得でき、リンク情報が存在する
            // ログインから直接遷移のみ可能画面ではない
            String strUrl = this.getPageUrlStr(pageId);
            if (CM_CommonUtil.isNotNullOrBlank(strUrl)) {
                // 画面URLをセット
                favorite.put("strUrl", strUrl);
            } else {
                continue;
            }

            // 名称マスタから機能名称情報を取得
            BeanMap pageInfo = CM_SysNameDataUtil.getName(this.sessionDto,
                    CM_A04_Const.SYS_NAME_MST_NAME_TYPE.PAGE_ID,
                    pageId,
                    this.sessionDto.ssn_UserLangCD);
            Object favoriteName = FW00_19_Const.EMPTY_STR;
            if (pageInfo != null) {
                if (CM_CommonUtil.isNullOrBlank((String) favorite.get(TrSearchConditionEntityNames.favoriteName().toString()))) {
                    favoriteName = pageInfo.get(SysNameEntityNames.name1().toString());
                } else {
                    favoriteName = (String) favorite.get(TrSearchConditionEntityNames.favoriteName().toString());
                }
            }
            favorite.put(SysNameEntityNames.name1().toString(), favoriteName);

            resList.add(favorite);
        }

        return resList;
    }

    /**
     * お気に入り情報を取得.<br>
     * <br>
     * 概要:<br>
     *   ユーザーのお気に入り情報を取得
     *
     * @param _favoriteNo お気に入り番号
     * @return お気に入り情報
     */
    public List<BeanMap> getFavoriteInfo(final Integer _favoriteNo) {
        List<BeanMap> ret = this.getCustomerDao().selectFavoriteInfo(this.sessionDto.ssn_UserSID, _favoriteNo);
        return ret;
    }

    /**
     * 画面IDからページのURL文字列定義を取得する.
     * @param _pageId 画面ID
     * @return URL文字列定義
     */
    public String getPageUrlStr(final String _pageId) {
        String res = null;
        BeanMap sysNameInfo = CM_SysEnvDataUtil.selectSysEnv(this.sessionDto, CM_A04_Const.SYS_ENV_MST_ENV_CD.PAGE_ID, _pageId);
        // メニュー情報が取得でき、リンク情報が存在する
        // ログインから直接遷移のみ可能画面ではない
        if (sysNameInfo != null && !CM_CommonUtil.isNullOrBlank(sysNameInfo.get(SysEnvEntityNames.abbName()))
                && (sysNameInfo.get(SysEnvEntityNames.name()) == null
                || !sysNameInfo.get(SysEnvEntityNames.name()).toString().equals(CM_A04_Const.FLG.ON))) {
            // 画面URLをセット
            res = sysNameInfo.get(SysEnvEntityNames.abbName()).toString();
        }

        if (CM_CommonUtil.isNullOrBlank(res)) {
            CM_A05_PageInfo pageInfo = CM_A05_PageInfo.getPageInfo(_pageId);
            if (pageInfo != null) {
                res = "/" + pageInfo.pageName + "/index";
            }
        }

        if (CM_CommonUtil.isNullOrBlank(res)) {
            CM_A04_Const.PageInfo pageInfo = CM_A04_Const.PageInfo.getPageInfo(_pageId);
            if (pageInfo != null) {
                res = "/" + pageInfo.pageName + "/index";
            }
        }

        return res;
    }

    /**
     * DB接続情報があるかどうかを確認.
     * @return 結果
     */
    public boolean hasConnection() {
        boolean res = false;
        if (CM_CommonUtil.isNotNullOrBlank(this.strConnectString)) {
            res = true;
        }
        return res;
    }

    /**
     * 検索条件初期値取得処理.
     * @param _formMap フォーム情報
     */
    public void setDefaultSearchDate(BeanMap _formMap) {
        this.getCustomerDao().exchangeSearchDate(_formMap);
    }

    /**
     * 現在の年度を取得.
     *
     * @param _comPlantCode 工場コード
     * @return 現在の年度(YYYY)
     */
    public String getCurrentYear(final String _comPlantCode) {
        return this.getCustomerDao().getCurrentYear(_comPlantCode);
    }

    /**
    *
    * 指定工場コード権限取得処理.<br>
    *<br>
    * 概要:<br>
    *   パラメータで指定されたSIDの役割が持つ権限のリストを取得する
    *<br>
    * @param _plantCode 工場コード
    * @return 権限リスト
    */
   public List<CM_PageAuthInfoDto> getPageListInfo(final String _plantCode) {
       List<CM_PageAuthInfoDto> listRet = new ArrayList<CM_PageAuthInfoDto>();

       /* **************************************/
       // 画面権限情報リスト取得
       /* **************************************/
       List<CM_PageAuthInfoDto> authPageList = this.getAuthListInfo(_plantCode);

       /* **************************************/
       // 画面権限情報リストを機能別リストに変換
       /* **************************************/
       // 機能名リストを取得
       Map<String, String> functionCdNameMap = new HashMap<String, String>();
       List<BeanMap> functionCdNameList = CM_SysNameDataUtil.getNameList(this.sessionDto,
               CM_A04_Const.SYS_NAME_MST_NAME_TYPE.FUNCTION_CD, this.sessionDto.ssn_UserLangCD);

       // 表示順でソート
       for (BeanMap functionCdNameInfo : functionCdNameList) {
           // 表示順が設定されていない場合、設定
           Integer displayOrder = (Integer) functionCdNameInfo.get(SysNameEntityNames.displayOrder().toString());
           if (CM_CommonUtil.isNullOrBlank(displayOrder)) {
               functionCdNameInfo.put(SysNameEntityNames.displayOrder().toString(), Integer.MAX_VALUE);
           }
       }
       Collections.sort(functionCdNameList, new CM_ComparatorByDisplayOrder());

       Map<String, CM_MenuConstitutionDto> authFuncInfoMap = new LinkedHashMap<String, CM_MenuConstitutionDto>();
       for (BeanMap functionCdNameInfo : functionCdNameList) {
           String functionCd = (String) functionCdNameInfo.get(SysNameEntityNames.itemCd());
           String functionName = (String) functionCdNameInfo.get(SysNameEntityNames.name1());
           functionCdNameMap.put(functionCd, functionName);

           // CM_MenuConstitutionDtoを作成
           CM_MenuConstitutionDto menuConstitutionDto = new CM_MenuConstitutionDto();
           authFuncInfoMap.put(functionCd, menuConstitutionDto);
           // 機能名設定
           menuConstitutionDto.functionName = functionCdNameMap.get(functionCd);
           authFuncInfoMap.put(functionCd, menuConstitutionDto);
       }

       // 機能情報に画面情報を追加
       for (CM_PageAuthInfoDto pageAuthInfo : authPageList) {
           String functionCd = pageAuthInfo.functionCd;
           CM_MenuConstitutionDto menuConstitutionDto = authFuncInfoMap.get(functionCd);
           if (CM_CommonUtil.isNullOrBlank(menuConstitutionDto)) {
               continue;
           }
           pageAuthInfo.functionCdName = menuConstitutionDto.functionName;
           menuConstitutionDto.menuItemList.add(pageAuthInfo);
       }

       // 画面が存在する分だけ設定
       for (CM_MenuConstitutionDto menuConstitutionDto : authFuncInfoMap.values()) {
           if (menuConstitutionDto.menuItemList.size() > 0) {
               listRet.addAll(menuConstitutionDto.menuItemList);
           }
       }

       return listRet;
   }

   /**
   *
   * 画面権限情報リスト取得処理.<br>
   *<br>
   * 概要:<br>
   *   パラメータで指定された工場が持つ権限のリストを取得する
   *<br>
   * @param _plantCode 工場コード
   * @return ページリスト
   */
  private List<CM_PageAuthInfoDto> getAuthListInfo(final String _plantCode) {

      List<CM_PageAuthInfoDto> listRet = new ArrayList<CM_PageAuthInfoDto>();

      try {
          CM_GetMenuAuthInfoDao clsCM_GetRoleAuthInfoDao = new CM_GetMenuAuthInfoDao(
                  this.sessionDto.ssn_ConnectString,
                  this.sessionDto.ssn_ConnectUserID,
                  this.sessionDto.ssn_ConnectPassword);

          // 名称マスタから機能名称情報を取得

          // ファンクション情報取得
          Map<String, BeanMap> fuctionInfoMap = new HashMap<String, BeanMap>();
          List<BeanMap> functionCdList = CM_SysNameDataUtil.getNameList(this.sessionDto,
                  CM_A04_Const.SYS_NAME_MST_NAME_TYPE.FUNCTION_CD, this.sessionDto.ssn_UserLangCD);
          for (BeanMap functionCdDef : functionCdList) {
              String functionCd = (String) functionCdDef.get(SysNameEntityNames.itemCd().toString());
              fuctionInfoMap.put(functionCd, functionCdDef);
          }


          // 画面名リストを取得
          List<BeanMap> listPageIdName = CM_SysNameDataUtil.getNameList(this.sessionDto,
                  CM_A04_Const.SYS_NAME_MST_NAME_TYPE.PAGE_ID, this.sessionDto.ssn_UserLangCD);

          // 表示順でソート
          Collections.sort(listPageIdName, new CM_ComparatorByDisplayOrder());

          // 指定された工場コードの権限情報を取得
          Map<String, MaMenuItemsEntity> pageAuthInfoMap = new HashMap<String, MaMenuItemsEntity>();
          List<MaMenuItemsEntity> mapList = clsCM_GetRoleAuthInfoDao.selectMenuAuthInfoList(_plantCode);
          if (CM_CommonUtil.isNullOrEmpty(mapList)) {
              // 設定がない場合、工場コードをに空を指定し再取得
              mapList = clsCM_GetRoleAuthInfoDao.selectMenuAuthInfoList(null);
          }
          for (MaMenuItemsEntity pageInfoBuf : mapList) {
              pageAuthInfoMap.put(pageInfoBuf.pageId, pageInfoBuf);
          }

          // 設定項目メニューマスタを取得
          List<MaSettingMenuItemsEntity> settingMenuItemsList
              = clsCM_GetRoleAuthInfoDao.selectSettingAuthInfoList(_plantCode, this.sessionDto.ssn_AuthorityCode);
          if (CM_CommonUtil.isNullOrEmpty(settingMenuItemsList)) {
              // 取得できない場合、工場コードをに空を指定し再取得
              settingMenuItemsList = clsCM_GetRoleAuthInfoDao.selectSettingAuthInfoList(null, this.sessionDto.ssn_AuthorityCode);
          }
          Map<String, MaSettingMenuItemsEntity> settingMenuItemsMap = new HashMap<String, MaSettingMenuItemsEntity>();
          for (MaSettingMenuItemsEntity mstMenuItem : settingMenuItemsList) {
              settingMenuItemsMap.put(mstMenuItem.pageId, mstMenuItem);
          }

          // 画面名リストを走査
          for (BeanMap pageInfoData : listPageIdName) {

              if (pageInfoData.get(SysEnvEntityNames.deleteFlag().toString()) == null) {
                  continue;
              }

              boolean deleteFlag = (boolean) pageInfoData.get(SysEnvEntityNames.deleteFlag().toString());
              if (deleteFlag) {
                  continue;
              }

              // 画面名リストの画面IDを取得
              String pageId = pageInfoData.get(SysNameEntityNames.itemCd()).toString();
              CM_A05_PageInfo pageInfo = CM_A05_PageInfo.getPageInfo(pageId);
              if (CM_CommonUtil.isNullOrBlank(pageInfo)) {
                  // ページ定義に存在しない場合
                  continue;
              }

              // ホーム画面及びメニュー構成画面はリストから除く
              if (CM_A04_Const.HOME_PAGE_ID.equals(pageId)
                      || CM_A05_PageInfo.PAGE_ID_MENU_CONSTITUTION.getPageId().equals(pageId)) {
                  continue;
              }

              // 設定項目メニューマスタの存在をチェック
              if (settingMenuItemsMap.containsKey(pageId)) {
                  // 設定項目メニューマスタがある場合、表示しない
                  continue;
              }

              // 画面権限情報取得
              MaMenuItemsEntity mstMenuItems = pageAuthInfoMap.get(pageId);

              // 画面表示情報作成
              CM_PageAuthInfoDto pageAuthInfo = new CM_PageAuthInfoDto();
              if (CM_CommonUtil.isNullOrBlank(mstMenuItems)) {
                  // 探しているページIDのデータが、取得した権限リスト内になかった場合
                  // 権限がないものとしてデータを追加する
                  pageAuthInfo = new CM_PageAuthInfoDto();
                  pageAuthInfo.functionCd = pageInfo.getFunctionCd();
                  pageAuthInfo.pageId = pageId;
                  pageAuthInfo.authSetting = CM_A04_Const.ROLE_AUTH_KIND.NONE;
              } else {
                  pageAuthInfo = Beans.createAndCopy(CM_PageAuthInfoDto.class, mstMenuItems).execute();
                  pageAuthInfo.authSetting = mstMenuItems.enableFlag.toString();
              }

              // 名称
              pageAuthInfo.pageIdName = (String) pageInfoData.get(SysNameEntityNames.name1());

              // システム管理者のみ表示可能か
              pageAuthInfo.enableOnlySysAdmin = !CM_A05_PageInfo.getPageInfo(pageId).isEnableUser();

              // 戻り値用リストに追加
              listRet.add(pageAuthInfo);
          }

      } catch (Exception e) {
          // エラーログ出力
          CM_LoggerUtil.outputErrorLog(null, e);
      }

      return listRet;
  }

}
