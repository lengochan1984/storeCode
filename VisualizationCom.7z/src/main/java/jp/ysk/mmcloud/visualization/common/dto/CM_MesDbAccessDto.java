/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2016/08/28| 新規作成                           | C1.01  | US)萩尾
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.dto;

import javax.transaction.TransactionManager;

import org.seasar.extension.jdbc.manager.JdbcManagerImpl;

/**
 * mesDBアクセス用Dtoクラス.<br>
 *<br>
 * 概要:<br>
 *   mesDBへアクセスするためのJDBCManagerおよびそのトランザクションデータのDtoクラス
 *<br>
 */
public class CM_MesDbAccessDto {

    /**
     * mesDBアクセス用のJDBCManager.
     */
    public JdbcManagerImpl jdbcManager;

    /**
     * データ型(データポイントマスタのデータ型).
     */
    public TransactionManager userTransactionMng;

    /**
     * エラーメッセージ.
     */
    public String errMsg;

    /**
     * コンストラクタ.
     *
     */
    public CM_MesDbAccessDto() {
        this.jdbcManager = null;
        this.userTransactionMng = null;
    }

}
