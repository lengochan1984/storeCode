/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2014/01/20| 新規作成                                                             | 1.00.00| YSK)植山
 *  2014/06/21| <10000-004> ユーザ設定押下処理追加                                   | 1.00.00| YSK)鬼丸
 *  2014/06/21| <10000-008> 説明画面用処理追加                                       | 1.00.00| YSK)中田
 *  2014/06/21| <10000-009> 機器情報画面入力改善                                     | 1.00.00| YSK)中田
 *  2014/06/23| <10000-038> アラーム条件、通信プロファイルの文字数チェック定数追加   | 1.01.00| YSK)植山
 *  2014/06/26| <10000-065> 地図APIのIDをDBに定義し、そのIDを利用するよう機能を改善  | 1.01.00| YSK)鬼丸
 *  2014/06/27| <10000-067> トレンドモニタ期間単位変更対応                           | 1.01.00| YSK)植山
 *  2014/07/10| <10000-111> IT不具合対応(No.172)お知らせ情報を名称マスタから取得　　 | 1.01.00| YSK)森山
 *  2014/09/03| <10101-012> トレンドモニタ改造　　                                   | 1.02.00| YSK)植山
 *  2014/09/22| <10101-015> 点検保守状況画面追加　　                                 | 1.02.00| YSK)中田
 *  2014/09/22| <10101-016> 故障苦情No.10101-003　　                                 | 1.02.00| YSK)中田
 *  2014/10/02| <10101-026> リリース後不具合対応(No.021)                             | 1.02.00| YSK)森山
 *  2014/10/16| <15000-002> アドレス名称登録追加                                     | 2.00.00| YSK)中田
 *  2014/11/13| <15000-101> リソース表示対応    　　                                 | 2.00.00| YSK)中田
 *  2014/11/17| <15000-103> 故障苦情No.15000-009                                     | 2.00.00| YSK)中田
 *  2014/11/26| <20000-001> 仕様変更No.27                                            | 3.00.00| US)馬
 *  2014/11/27| <20000-005> 仕様変更No.11                                            | 3.00.00| US)楢崎
 *  2014/11/27| <20000-010> 変更仕様NO.10                                            | 3.00.00| US)苗
 *  2014/12/11| <20000-006> 変更仕様一覧No.18                                        | 3.00.00| YSK)中田
 *  2014/12/01| <20000-008> データポイント数拡張                                     | 3.00.00| YSK)森山
 *  2014/12/05| <20000-009> 変更仕様No.7                                             | 3.00.00| US)楢崎
 *  2014/12/11| <20000-005> 仕様変更No.11 (改造)                                     | 3.00.00| YSK)森山
 *  2014/12/11| <20000-002> 変更仕様No.21対応                                        | 3.00.00| US)萩尾
 *  2014/12/11| <20000-008> DP数拡張対応                                             | 3.00.00| YSK)植山
 *  2014/12/12| <20000-014> 最終通信日時対応                                         | 3.00.00| YSK)植山
 *  2014/12/15| <20000-019> 変更仕様No.13                                            | 3.00.00| YSK)中田
 *  2014/12/16| <20000-018> ファームウェアアップデート                               | 3.00.00| YSK)植山
 *  2014/12/16| <20000-022> 資料一覧用の資料種別コード定義クラスを修正               | 3.00.00| YSK)中田
 *  2014/12/16| <20000-020> 変更仕様No.8                                             | 3.00.00| US)萩尾
 *  2014/12/17| <20000-021> 仕様変更No.21                                            | 3.00.00| US)馬
 *  2014/12/19| <20000-025> 変更仕様一覧No.17                                        | 3.00.00| YSK)森山
 *  2014/12/21| <20000-026> 仕様変更No.9                                             | 3.00.00| YSK)中田
 *  2014/12/26| <20000-010> 変更仕様NO.10                                            | 3.00.00| US)苗
 *  2015/01/06| <20000-028> 仕様変更No.32                                            | 3.00.00| YSK)鬼丸
 *  2015/01/06| <20000-033> 変更仕様一覧No.26                                        | 3.00.00| YSK)中田
 *  2015/01/06| <20000-034> 故障苦情No.20001-002                                     | 3.00.00| YSK)植山
 *  2015/01/06| <20000-015> 変更仕様No.14                                            | 3.00.00| YSK)中田
 *  2015/01/15| <20000-002> 変更仕様No.21                                            | 3.00.00| YSK)馬
 *  2015/01/09| <20000-028> 仕様変更No.32                                            | 3.00.00| US)苗
 *  2015/01/15| <20000-021> 仕様変更No.21                                            | 3.00.00| US)萩尾
 *  2015/01/19| <20000-012> ステータス通知                                           | 3.00.00| YSK)植山
 *  2015/01/21| <20000-028> 仕様変更No.32                                            | 3.00.00| YSK)鬼丸
 *  2015/02/16| <20000-037> 仕様変更No.38                                            | 3.00.00| YSK)植山
 *  2015/04/13| <30003-005> 故障苦情No.30002-005                                     | 3.01.00| US)萩尾
 *  2015/04/22| <30003-006> 故障苦情No.30002-006                                     | 3.01.00| US)萩尾
 *  2015/06/23| <30003-034> 変更仕様No.1                                             | 3.01.00| YSK)千田
 *  2015/06/25| <30003-035> 変更仕様No.13                                            | 3.01.00| US)楢崎
 *  2015/06/25| <30003-033> 変更仕様No.12                                            | 3.01.00| US)萩尾
 *  2015/07/01| <30003-039> 変更仕様No.14                                            | 3.01.00| YSK)千田
 *  2015/07/08| <30003-037> 変更仕様No.23                                            | 3.01.00| US)楢崎
 *  2015/07/08| <30003-037> 変更仕様No.23                                            | 3.01.00| US)萩尾
 *  2015/08/07| <30003-050> 故障苦情No.30003-060                                     | 3.01.00| US)楢崎
 *  2015/08/07| <30003-052> Ver3.01.00 IT障害No.2-14                                 | 3.01.00| US)楢崎
 *  2015/08/08| <30003-056> Ver3.01.00 IT障害No.2-13                                 | 3.01.00| US)楢崎
 *  2015/08/17| <30003-059> 故障苦情No.30003-065                                     | 3.01.00| US)萩尾
 *  2015/08/24| <30003-062> 故障苦情No.30003-072                                     | 3.01.00| US)萩尾
 *  2015/09/03| <30003-070> 変更仕様No.37                                            | 3.01.00| US)萩尾
 *  2015/12/01| <40000-023> Ver4.00.00 変更仕様No.23                                 | 4.00.00| US)高橋
 *  2015/12/03| <40000-019> Ver.4.00.00 変更仕様No.19                                | 4.00.00| US)楢崎
 *  2015/12/15| <40000-027> Ver.4.00.00 変更仕様No.27                                | 4.00.00| US)楢崎
 *  2015/12/17| <40000-025> Ver.4.00.00 変更仕様No.20                                | 4.00.00| US)甲斐
 *  2015/12/21| <40000-021> Ver.4.00.00 変更仕様No.21                                | 4.00.00| US)楢崎
 *  2016/01/05| <40000-014> Ver.4.00.00 変更仕様No.14                                | 4.00.00| US)萩尾
 *  2016/01/06| <40000-021> Ver.4.00.00 変更仕様No.15                                | 4.00.00| US)甲斐
 *  2016/01/07| <40000-013> Ver.4.00.00 変更仕様No.13                                | 4.00.00| US)清水
 *  2016/01/11| <40000-016> Ver.4.00.00 変更仕様No.16                                | 4.00.00| US)甲斐
 *  2016/01/11| <40000-020> Ver.4.00.00 変更仕様No.20                                | 4.00.00| US)甲斐
 *  2016/01/13| <40000-005> Ver.4.00.00 変更仕様No.5（故障苦情No.30100-004）         | 4.00.00| US)清水
 *  2016/01/18| <40000-028> Ver.4.00.00 変更仕様No.28                                | 4.00.00| US)萩尾
 *  2016/01/20| <40000-028> Ver.4.00.00 変更仕様No.28                                | 4.00.00| US)安永
 *  2016/02/11| <40000-022> Ver.4.00.00 変更仕様No.22                                | 4.00.00| US)萩尾
 *  2016/02/16| <30101-002> 故障苦情No.30100-012                                     | 4.00.00| US)萩尾
 *  2016/02/12| <40000-021> Ver.4.00.00 変更仕様No.21                                | 4.00.00| US)甲斐
 *  2016/02/19| <40000-022> Ver.4.00.00 変更仕様No.22                                | 4.00.00| US)清水
 *  2016/02/23| <40000-022> Ver.4.00.00 変更仕様No.22                                | 4.00.00| US)姫野
 *  2016/05/09| <40000-034> 故障苦情No.40000-001                                     | 4.01.00| US)萩尾
 *  2016/05/31| <40000-042> 機能改造 コマンド実行                                    | 4.01.00| YSK)三村
 *  2016/07/06| <40000-040> 故障苦情No.40000-008                                     | 4.01.00| YSK)三村
 *  2016/07/20| <C1.01> 共通化対応取込                                               | C1.01  | US)萩尾
 *  2016/08/08| <C1.01> ライン状況モニタ画面（指図一覧）対応                         | C1.01  | US)楢崎
 *  2016/08/08| <C1.01> 作業区状況モニタ画面（稼動一覧）対応                         | C1.01  | US)楢崎
 *  2016/08/09| <C1.01> 作業区状況モニタ画面（稼動状況）対応                         | C1.01  | US)萩尾
 *  2016/08/11| <C1.01> 更新タイミング変更 対応                                      | C1.01  | US)松本
 *  2016/08/11| <C1.01> グラフカラー管理 対応                                        | C1.01  | US)松本
 *  2016/08/11| <C1.01> 業務時間管理 対応                                            | C1.01  | US)松本
 *  2016/08/11| <C1.01> 不具合分析画面 対応                                          | C1.01  | US)楢崎
 *  2016/08/12| <C1.01> 不具合一覧画面 対応                                          | C1.01  | US)甲斐
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;

/**
 *
 * 共通定数.<br>
 *<br>
 * 概要:<br>
 *   共通の定数クラスです
 *<br>
 */
public abstract class CM_A04_Const {

    /**
     *
     * フラグ定数.<br>
     *<br>
     * 概要:<br>
     *   フラグの定数クラスです
     *<br>
     */
    public abstract class FLG {
        /**
         * ON : 1.
         */
        public static final String ON = "1";
        /**
         * OFF : 0.
         */
        public static final String OFF = "0";
    }


    /**
     *
     * CSV用ブーリアン型.<br>
     * <br>
     * 概要:<br>
     * フラグの定数クラスです <br>
     */
    public abstract class BOOLEAN_FLG {
        /**
         * TRUE.
         */
        public static final String TRUE = "TRUE";
        /**
         * FALSE.
         */
        public static final String FALSE = "FALSE";
    }

    /**
     *
     * ソート順.<br>
     *<br>
     * 概要:<br>
     *   ソート順の定数クラスです
     *<br>
     */
    public abstract class SORT {
        /**
         * ASC :  asc.
         */
        public static final String ASC = " asc";
        /**
         * DESC :  desc.
         */
        public static final String DESC = " desc";
        /**
         * COMMA :  カンマ.
         */
        public static final String COMMA = ", ";
    }

    //**************************************
    // パス関連
    //**************************************
    /**
     * ファイルパス区切り文字.
     */
    public static final String PATH_DELIMITER = FW00_19_Const.SLASH_STR;
    // TODO [For local debug]
    //public static final String PATH_DELIMITER = "\\";

    /**
     * 親フォルダへの相対パス.
     */
    public static final String PARENT_DIRECTORY_PATH = "../";

    /**
     * 国旗画像の格納パス.
     */
    public static final String COUNTRY_FLAG_FILE_HEADER = "/common/img/flag/24/";
    /**
     * ファイル拡張子（PNG）.
     */
    public static final String COUNTRY_FLAG_BLANK_FILE_NAME = "blank.png";

    /**
     * 資料画像ファイルが存在しない場合のイメージ.
     */
    public static final String NO_EXIST_IMAGE_FILE_PATH = "../../common/img/NoImage.jpg";

    /**
     * 資料画像ファイルが存在しない場合のイメージ（サムネイル）.
     */
    public static final String NO_EXIST_THUMBNAIL_IMAGE_FILE_PATH = "../../common/img/NoImage_thumbnail.jpg";

    /**
     * ホーム画面のURL.
     */
    public static final String HOME_URL = "/c100010MonitorHome/index";

    /**
     * ログイン後画面のURL.
     */
    public static final String LOGIN_HOME_URL = "/c110010LineOperationStatus/index";

    /**
     * ホーム画面ID.
     */
    public static final String HOME_PAGE_ID = "C10-0010";

    /**
     * 拠点設定画面ID.
     */
    public static final String PAGE_ID_PRODUCTION_BASE_SETTING = "C18-0030";

    /**
     * 計画数設定画面ID.
     */
    public static final String PAGE_ID_PLAN_NUMBER_SETTING = "C18-0050";

    /**
     * ラインレイアウト設定画面ID.
     */
    public static final String PAGE_ID_LINE_LAYOUT_SETTING = "C18-0070";

    /**
     * 機器詳細画面画面ID.
     */
    public static final String DEVICE_DESC_PAGE_ID = "A01-0030";

    /**
     * コマンド実行画面画面ID.
     */
    public static final String COMMAND_EXECUTE_PAGE_ID = "A01-0120";

    /**
     * ユーザ情報画面のURL.
     */
    public static final String USER_INFO_URL = "/c180060UserInfo/index";

    /**
     * ユーザ情報画面ID.
     */
    public static final String USER_INFO_ID = "C18-0060";

    /**
     * ユーザ情報画面遷移パラメータのキー（ユーザSID）.
     */
    public static final String A500030FORM_HDN_USERSID = "hdnUserSid";

    /**
     * ユーザ情報画面遷移パラメータのキー（遷移モード）.
     */
    public static final String A500030FORM_HDN_INFOMODE = "hdnUserInfoMode";

    /**
     * データ連携電文_IPアドレス.
     */
    public static final String CST_TELECOM_IP = "ipaddress";

    /**
     * データ連携電文_受信日時.
     */
    public static final String CST_TELECOM_RCVDATE = "receiveDatetime";

    /**
     * （機器マスタ）ポート番号最大値.
     */
    public static final int PORT_NUMBER_MAX_VALUE = 49999;

    /**
     * （機器マスタ）ポート番号最小値.
     */
    public static final int PORT_NUMBER_MIN_VALUE = 40000;

    /**
     * 言語コード（日本語）.
     */
    public static final String CST_LANG_CD_JPN = "JPN";

    /**
     * 言語コード（英語）.
     */
    public static final String CST_LANG_CD_ENG = "ENG";

    /**
     * 画面プログラムCD.
     */
    public static final String CST_PROGRAM_CD = "MMCloudWeb";

    /**
     * 通信プロセスプログラムCD.
     */
    public static final String CST_PROGRAM_TELECOM_CD = "MMCloudTelecom";

    /**
     * ユーザ無効となるパスワードミス回数.
     */
    public static final int CST_INVALID_MISS_CNT = 5;

    /**
     * 日時フォーマット(月).
     */
    public static final String DATE_FORMAT_MONTH_HYPHEN = "yyyy-MM";

    /**
     * 日時フォーマット(日).
     */
    public static final String DATE_FORMAT_FOR_DISP = "yyyy-MM-dd";

    /**
     * 日時フォーマット(時間).
     */
    public static final String DATE_FORMAT_HOUR_HYPHEN = "yyyy-MM-dd HH";

    /**
     * 日時フォーマット(分).
     */
    public static final String DATE_FORMAT_MIN = "yyyy/MM/dd HH:mm";

    /**
     * 日時フォーマット(分).
     */
    public static final String DATE_FORMAT_MIN_HYPHEN = "yyyy-MM-dd HH:mm";

    /**
     * 日時フォーマット(秒).
     */
    public static final String DATE_FORMAT_SEC_HYPHEN = "yyyy-MM-dd HH:mm:ss";

    /**
     * 日時フォーマット(ミリ).
     */
    public static final String DATE_FORMAT_MILLI_HYPHEN = "yyyy-MM-dd HH:mm:ss.SSS";

    /**
     * 日時フォーマット.
     */
    public static final String DATE_FORMAT = "yyyy/MM/dd HH:mm:ss";

    /**
     * 日時フォーマット(ミリ).
     */
    public static final String DATE_FORMAT_MILLI = "yyyy/MM/dd HH:mm:ss.SSS";

    /**
     * 日付フォーマット.
     */
    public static final String DATE_FORMAT_JUSTIFIED = "yyyyMMddHHmmssSSS";

    /**
     * 日付フォーマット(yyyyMMddHHmmss).
     */
    public static final String DATETIME_FORMAT = "yyyyMMddHHmmss";

    /**
     * 日付フォーマット(yyyyMMddHHmm).
     */
    public static final String DATETIME_MINUTE_FORMAT = "yyyyMMddHHmm";

    /**
     * 日付フォーマット(HH:mm).
     */
    public static final String DATETIME_FORMAT_HOUR_MINUTE = "HH:mm";

    /**
     * 日付フォーマット(yyyy/MM/dd).
     */
    public static final String DATETIME_FORMAT_MONTH_DAY = "yyyy/MM/dd";

    /**
     * 日付フォーマット(yyyy:MM).
     */
    public static final String DATETIME_FORMAT_YEAR_MONTH = "yyyy/MM";

    /**
     * 日時フォーマット(月日時分).
     */
    public static final String DATE_FORMAT_MONTH_MIN_HYPHEN = "MM-dd HH:mm";

    /**
     * 日付種別（月次）.
     */
    public static final String DATE_TYPE_GETUJI = "getuji";

    /**
     * 日付種別（日時）.
     */
    public static final String DATE_TYPE_NITIJI = "nitiji";

    /**
     * 日付種別（時間別）.
     */
    public static final String DATE_TYPE_JIKANBETU = "jikanbetu";

    /**
     * 日付種別（週次）.
     */
    public static final String DATE_TYPE_SHUJI = "shuji";

    /**
     * 日付種別（なし）.
     */
    public static final String DATE_TYPE_NONE = "";

    /**
     * 処理実行フラグ(CSV).
     */
    public static final String PROCESS_EXEC_CSV = "csv";

    /**
     * 処理実行フラグ(なし).
     */
    public static final String PROCESS_EXEC_NONE = "";

    /**
     * 日付選択（左ボタンクリック）.
     */
    public static final String CLICK_LEFT_BUTTON = "left_click";

    /**
     * 日付選択（右ボタンクリック）.
     */
    public static final String CLICK_RIGHT_BUTTON = "right_click";

    /**
     * 業務開始時間初期値.
     */
    public static final String DEFAULT_DATE_START_TIME = "07:00";

    /**
     * 業務終了時間初期値.
     */
    public static final String DEFAULT_DATE_END_TIME = ":59:59";

    /**
     * 業務開始時間デフォルト値.
     */
    public static final String DEFAULT_RUNNING_START_DATETIME = "0001-03-21 07:00:00.000";

    /**
     * 業務終了時間（23:）.
     */
    public static final String END_HOUR_23 = "23";
    /**
     * 業務終了時間（00:）.
     */
    public static final String END_HOUR_00 = "00:";

    /**
     * 月度開始日初期値.
     */
    public static final String DEFAULT_MONTH_START_DAY = "21";

    /**
     * 月度終了日（2月）.
     */
    public static final int DEFAULT_MONTH_END_DAY = 28;

    /**
     * 月度終了日（うるう年2月）.
     */
    public static final int DEFAULT_MONTH_END_DAY_LEAPYEAR = 29;

    /**
     * 年度開始月（3月）.
     */
    public static final String START_MONTH_03 = "03";

    /**
     * 年度開始月（2月）.
     */
    public static final String START_MONTH_02 = "02";

    /**
     * 画面上の時間フォーマット.
     */
    public static final String HOUR_FORMAT_FOR_DISP = "HH";

    /**
     * 画面上の分フォーマット.
     */
    public static final String MINUTE_FORMAT_FOR_DISP = "mm";

    /**
     * 日付フォーマット（地図アクセスカウント用）.
     */
    public static final String DATE_FORMAT_FOR_MAP_ACCESS_COUNT = "yyyyMMdd";

    /**
     * 日付フォーマット（画面アクセスログ用）.
     */
    public static final String DATE_FORMAT_FOR_DISP_ACCESS_LOG = "yyyyMMdd HH";

    /**
     * 日付フォーマット(地図アクセス用).
     */
    public static final String DATE_FORMAT_YEAR_MONTH = "yyyyMM";

    /**
     * 日付フォーマット(納期遅れ額画面用).
     */
    public static final String DATE_FORMAT_YEAR_YY_MONTH = "yy/MM";

    /**
     * 日時フォーマット(yyyy/MM/dd).
     */
    public static final String DATE_FORMAT_DATE = "yyyy/MM/dd";

    /**
     * 日時フォーマット(yyyy/MM/dd HH).
     */
    public static final String DATETIME_HOUR_FORMAT = "yyyy/MM/dd HH";

    /**
     * 日時フォーマット(MM/dd).
     */
    public static final String DATE_MMDD_FORMAT = "MM/dd";

    /**
     * 日時フォーマット(MM/dd HH:mm).
     */
    public static final String DATE_HOUR_MINUTE_FORMAT = "MM/dd HH:mm";

    /**
     * 日時フォーマット(MM/dd HH:mm:ss).
     */
    public static final String DATE_HOUR_MINUTE_SECOND_FORMAT = "MM/dd HH:mm:ss";

    /**
     * 時間フォーマット(HHmmss).
     */
    public static final String TIME_FORMAT = "HH:mm:ss";

    /**
     * 時間の基底値.
     */
    public static final String TIME_ZERO = "00";

    /**
     * 秒数の最大値.
     */
    public static final String MAX_SECOND_TIME = "59";

    /**
     * ミリ秒数の最大値.
     */
    public static final String MAX_MILLI_SECOND_TIME = "999";

    /**
     * 時分の最小値.
     */
    public static final String MIN_HOUR_MINUTE = "00:00";

    /**
     * 時分の最大値.
     */
    public static final String MAX_HOUR_MINUTE = "23:59";

    /**
     * 数値フォーマット(#,##0.###).
     */
    public static final String NUMBER_FORMAT = "#,##0.###";

    /**
     * {デシマル表示フォーマット}.
     */
    public static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("##########.#####");

    /**
     * 16進フォーマット(%02x).
     */
    public static final String HEX_FORMT_BYTE = "%1$02x";

    /**
     * 16進フォーマット(%04x).
     */
    public static final String HEX_FORMT_SHORT = "%1$04x";

    /**
     * 10進フォーマット(%3d).
     */
    public static final String DEC_FORMT_BYTE = "%3d";

    /**
     * 10進フォーマット(%1$5d).
     */
    public static final String DEC_FORMT_SHORT = "%5d";

    /**
     * IPアドレスフォーマット.
     */
    public static final String IP_ADDRESS_FORMAT
        = "^(([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$";

    /**
     * 文字コード.
     */
    public static final String CHARACTER_CODE = "ms932";

    /**
     * WebAPI用文字コード.
     **/
    public static final String CHARACTER_CODE_WEBAPI = "UTF-8";

    /**
     * 切り取り時の追加文字列.
     */
    public static final String CUT_APPEND_STR = "...";


    /**
     * マニュアル格納先フォルダ名.
     */
    public static final String MANUAL_DIR = "/usr/local/tomcat/webapps/manual/";
    //public static final String MANUAL_DIR = "C:\\MMCloudDev\\tomcat\\7\\webapps\\manual\\";

    /**
     * マニュアルファイル名.
     */
    public static final String MANUAL_FILENAME = "MMCloudManual.pdf";

    /**
     * アイコン説明用画面ファイル格納先フォルダ名.
     */
    public static final String INFO_PAGE_DIR = "../html/";

    /**
     * 全拠点管理者コード.
     */
    public static final String ALL_BASE_AUTH = "##";

    /**
     * 全拠点名称.
     */
    public static final String ALL_BASE_AUTH_NAME = "全拠点";

    /**
     * システム管理者の権限コード.
     */
    public static final String SYS_ADMIN_AUTH_CD = "90";

    /**
     * 情報システムの権限コード.
     */
    public static final String INFO_ADMIN_AUTH_CD = "10";

    /**
     * 生産技術の権限コード.
     */
    public static final String PRODUCTION_ENGINEERING_AUTH_CD = "20";

    /**
     * 業務の権限コード.
     */
    public static final String GYOUMU_AUTH_CD = "30";

    /**
     * 製造管理者の権限コード.
     */
    public static final String MANUFACTURING_AUTH_CD = "40";

    /**
     * 一般ユーザの権限コード.
     */
    public static final String USER_AUTH_CD = "50";

    /**
     * 製造作業者の権限コード.
     */
    public static final String WORKER_AUTH_CD = "51";

    /**
     * 文字サイズ.
     */
    public static final String CHAR_SIZE = "midddle";

    /**
     * サムネイル名.
     */
    public static final String THUMBNAIL = "_thumbnail.";

    /**
     * デフォルトアイコンの共通パス.
     */
    public static final String DEFAULT_ICON_COMMON_PATH = "../common/img/map/map_markerL";

    /**
     * デフォルトアイコンの共通名称.
     */
    public static final String DEFAULT_ICON_COMMON_NAME = "_lv";

    /**
     * 稼働状況一覧表示項目名 最大個数.
     */
    public static final int STATUS_LIST_NAME_MAX_COUNT = 5;

    /**
     * 検索可能な最大日数.
     */
    public static final int SEARCH_DURATION_MAX_DAY = 7;

    /**
     * 不具合解析画面で検索可能な最大月数.
     */
    public static final int FAILURE_ANALYSIS_DURATION_MAX_MONTH = 3;

    /**
     * 製品別分析画面で検索可能な最大月数.
     */
    public static final int PRODUCT_ANALYSIS_DURATION_MAX_MONTH = 2;

    /**
     * 完了状態のステータス値.
     */
    public static final int STATUS_COMPLETION = 90;

    /**
     * 全工場コード定義文字.
     */
    public static final String ALL_PLANT_CODE = "##";

    /**
     * １年の月数.
     */
    public static final int MONTH_OF_YEAR_COUNT = 12;

    /**
     * 直近の年月日選択定義.
     */
    public static final String DISP_RECENT_FLG = "recent";

    //**************************************
    // データ集計用
    //**************************************
    /**
     * ダミーデータ.
     * (トレンドモニタ一覧ヘッダの計測日時にダミーSIDに設定
     */
    public static final String DUMMY_DATE = "date";
    /**
     * ダミーデータ.
     * (トレンドモニタ一覧ヘッダの計測日時（現地）にダミーSIDに設定
     */
    public static final String DUMMY_LOCAL_DATE = "localDate";

    /**
     * ダミーデータ.
     * (トレンドモニタ一覧ヘッダの警報有無にダミーSIDに設定
     */
    public static final String DUMMY_ALARM = "alarm";

    /**
     * 改行コード：CR+LF.
     */
    public static final String LINE_END = "\r\n";
    /**
     * 改行コード：CR.
     */
    public static final String CARRIAGE_RETURN = "\r";
    /**
     * 改行コード：LF.
     */
    public static final String LINE_FEED = "\n";

    /**
     * HTML特殊文字コード：アンパサンド.
     */
    public static final String AMPERSAND_CODE = "&amp;";
    /**
     * HTML特殊文字コード：半角小なり.
     */
    public static final String LEFT_ANGLE_BRACKET_CODE = "&lt;";
    /**
     * HTML特殊文字コード：半角大なり.
     */
    public static final String RIGHT_ANGLE_BRACKET_CODE = "&gt;";
    /**
     * HTML特殊文字コード：ダブルクォーテーション.
     */
    public static final String DOUBLE_QUOTATION_CODE = "&quot;";
    /**
     * HTML特殊文字コード：シングルクォーテーション.
     */
    public static final String SINGLE_QUOTATION_CODE = "&#039;";
    /**
     * HTMLタグ：改行.
     */
    public static final String LINE_END_CODE = "<br>";

    /**
     * アイコンフォルダ名.
     */
    public static final String ICON_DIR_NAME = "icon";

    /**
     * デフォルトSIMタイプ.
     */
    public static final String DEFAULT_SIM_TYPE = "other";

    /**
     * 率の算出用.
     */
    public static final int RATE = 100;

    /**
     *
     * データ型定数.<br>
     *<br>
     * 概要:<br>
     *   データ型を表す定数クラス
     *<br>
     */
    public abstract class DATA_TYPE {
        /**
         * ワード.
         */
        public static final String WORD = "01";
        /**
         * 整数.
         */
        public static final String INT = "02";
        /**
         * 実数.
         */
        public static final String DECIMAL = "03";
        /**
         * 日付.
         */
        public static final String DATE = "04";
        /**
         * 座標.
         */
        public static final String POINT = "05";
        /**
         * BIT.
         */
        public static final String BIT = "06";
        /**
         * 文字列.
         */
        public static final String STRING = "07";
        /**
         * イベント.
         */
        public static final String EVENT = "08";
        /**
         * 符号なし整数.
         */
        public static final String UNSIGNED_INT = "09";
        /**
         * ファイル.
         */
        public static final String FILE = "10";
    }

    /**
     *
     * 通信日時区分定数.<br>
     *<br>
     * 概要:<br>
     *   データポイント位置マスタの通信日時区分の定数定義
     *<br>
     */
    public abstract class DATETIME_CLASS {
        /**
         * 標準日時 : 0.
         */
        public static final String GMT = "0";
        /**
         * タイムゾーン日時 : 1.
         */
        public static final String ZONE = "1";
    }

    /**
     *
     * 名称マスタ（システム用）の名称種別定数.<br>
     *<br>
     * 概要:<br>
     *   名称マスタ（システム用）の名称種別の定数定義
     *<br>
     */
    public abstract class SYS_NAME_MST_NAME_TYPE {
        /**
         * アラームレベル : alarm_level.
         */
        public static final String ALARM_LEVEL = "alarm_level";
        /**
         * アラーム種別 : alarm_kind.
         */
        public static final String ALARM_KIND = "alarm_kind";
        /**
         * アラームステータス : alarm_status.
         */
        public static final String ALARM_STATUS = "alarm_status";
        /**
         * 権限設定 : auth_setting.
         */
        public static final String AUTH_SETTING = "auth_setting";
        /**
         * ユーザ権限 : user_auth.
         */
        public static final String USER_AUTH = "user_auth";
        /**
         * 言語CD : language.
         */
        public static final String LANGUAGE = "language";
        /**
         * 文字サイズ : char_size.
         */
        public static final String CHAR_SIZE = "char_size";
        /**
         * テーマカラー : theme_color.
         */
        public static final String THEME_COLOR = "theme_color";
        /**
         * 時計表示 : clock_disp.
         */
        public static final String CLOCK_DISP = "clock_disp";
        /**
         * 無効フラグ : invalid_flg.
         */
        public static final String INVALID_FLAG = "invalid_flag";
        /**
         * 稼働状況 : operation_status.
         */
        public static final String OPERATION_STATUS = "operation_status";
        /**
         * 機能CD : function_cd.
         */
        public static final String FUNCTION_CD = "function_cd";
        /**
         * 画面ID : page_id.
         */
        public static final String PAGE_ID = "page_id";
        /**
         * 監視条件 : monitoring_condition.
         */
        public static final String MONITORING_CONDITION = "monitoring_condition";
        /**
         * 結合区分 : join_class.
         */
        public static final String JOIN_CLASS = "join_class";
        /**
         * 比較演算子(数値) : number_compare_kind.
         */
        public static final String NUMBER_COMPARE_KIND = "number_compare_kind";
        /**
         * 比較演算子(文字列) : string_compare_kind.
         */
        public static final String STRING_COMPARE_KIND = "string_compare_kind";
        /**
         * データ形式 : data_form.
         */
        public static final String DATA_FORM = "data_form";

        /**
         * データ型 : data_type.
         */
        public static final String DATA_TYPE = "data_type";

        /**
         * 計測日時区分 : datetime_class.
         */
        public static final String DATETIEM_CLASS = "datetime_class";

        /**
         * 位置取得区分 : position_get_class.
         */
        public static final String POSITION_GET_CLASS = "position_get_class";

        /**
         * お知らせ種別 : info_kind.
         */
        public static final String INFO_KIND = "info_kind";

        /**
         * 点検種別 : mainte_type.
         */
        public static final String MAINTE_TYPE = "mainte_type";

        /**
         * 点検ステータス : mainte_status.
         */
        public static final String MAINTE_STATUS = "mainte_status";

        /**
         * 資料種別 : file_kind.
         */
        public static final String FILE_KIND = "file_kind";

        /**
         * 変換ルール : event_compare_kind.
         */
        public static final String EVENT_COMPARE_KIND = "event_compare_kind";

        /**
         * 稼動状態管理方法：management_type.
         */
        public static final String MANAGEMENT_TYPE = "management_type";

        /**
         * 稼動状態区分：operation_kind.
         */
        public static final String OPERATION_KIND = "operation_kind";

        /**
         * 配信データ種別 : file_type.
         */
        public static final String FILE_TYPE = "file_type";

        /**
         * 公開区分 : public_type.
         */
        public static final String PUBLIC_TYPE = "public_type";

        /**
         * 通信プロセスエラーコード：process_error_cd.
         */
        public static final String PROCESS_ERROR_CD = "process_error_cd";

        /**
         * 通信プロセスステータス：telecom_log_status.
         */
        public static final String TELECOM_LOG_STATUS = "telecom_log_status";

        /**
         * グループ区分:user_group_type.
         */
        public static final String USER_GROUP_TYPE = "user_group_type";

        /**
         * アイコンタイプ:icon_type.
         */
        public static final String ICON_TYPE = "icon_type";

        /**
         * SIMタイプ：sim_type.
         */
        public static final String SIM_TYPE = "sim_type";

        /**
         * コマンド：command_function.
         */
        public static final String COMMAND_FUNCTION = "command_function";

        /**
         * コマンドログデータタイプ : data_type.
         */
        public static final String COMMAND_LOG_DATA_TYPE = "cmd_log_data_type";

        /**
         * 集計方法.
         */
        public static final String COUNT_METHOD_STATUS = "count_method_status";

        /**
         * 集計期間.
         */
        public static final String SUMMARY_TERM_STATUS = "summary_term_status";

        /**
         * 生産状態.
         */
        public static final String SEISAN_JYOTAI = "seisan_jyotai";

        /**
         * ライングループ枠.
         */
        public static final String STATUS_FRAME = "status_frame";

        /**
         * ライングループアイコン.
         */
        public static final String STATUS_ICON = "status_icon";

        /**
         * ライン状態.
         */
        public static final String LINE_STATUS = "line_status";

        /**
         * 設備状態.
         */
        public static final String EQUIPMENT_STATUS = "equipment_status";

        /**
         * 設備状態アイコン.
         */
        public static final String FACILITY_STATUS_ICON = "facility_status_icon";

    }

    /**
     *
     * 名称マスタの名称種別定数.<br>
     *<br>
     * 概要:<br>
     *   名称マスタの名称種別の定数定義
     *<br>
     */
    public abstract class MST_NAME_MST_NAME_TYPE {
        /**
         * 役割名 : role_name.
         */
        public static final String ROLE_NAME = "role_name";

        /**
         * グループ名 : group_name.
         */
        public static final String GROUP_NAME = "group_name";

        /**
         * データポイント名 : datapoint_name.
         */
        public static final String DATAPOINT_NAME = "datapoint_name";

        /**
         * 単位 : unit.
         */
        public static final String UNIT = "unit";

        /**
         * 集計方法 : count_method.
         */
        public static final String COUNT_METHOD = "count_method";

        /**
         * グラフ種別 : graph_kind.
         */
        public static final String GRAPH_KIND = "graph_kind";

        /**
         * 設定値名称：state_setting_name.
         */
        public static final String STATE_SETTING_NAME = "state_setting_name";

        /**
         * 機器付帯情報：device_subinfo.
         */
        public static final String DEVICE_SUBINFO = "device_subinfo";

        /**
         * SIMタイプ：sim_type.
         */
        public static final String SIM_TYPE = "sim_type";
    }

    /**
     *
     * 環境マスタの環境CD定数.<br>
     *<br>
     * 概要:<br>
     *   環境マスタの環境CDの定数定義
     *<br>
     */
    public abstract class SYS_ENV_MST_ENV_CD {
        /**
         * 顧客ロゴのファイルパス : logo_path.
         */
        public static final String LOGO_FILEPATH = "v_logo_path";

        /**
         * ユーザタイムゾーン : timezone.
         */
        public static final String TIMEZONE = "timezone";

        /**
         * 更新タイミングリスト：auto_update_time.
         */
        public static final String  UPDATETIME = "auto_update_time";

        /**
         * 更新タイミングリスト：auto_update_time_m.
         */
        public static final String  UPDATETIMEM = "auto_update_time_m";

        /**
         * 国旗ファイルパス : country_flag.
         */
        public static final String COUNTRY_FLAG = "country_flag";

        /**
         * メール送信設定 : mail_send_setting.
         */
        public static final String MAIL_SEND_SETTING = "mail_send_setting";

        /**
         * 通信方式 : protocol.
         */
        public static final String PROTOCOL = "protocol";

        /**
         * エンコード種別 : encode_kind.
         */
        public static final String ENCODE_KIND = "encode_kind";

        /**
         * 改行コード : change_line.
         */
        public static final String CHANGE_LINE = "change_line";
        /**
         * 画面ID : page_id.
         */
        public static final String PAGE_ID = "page_id";

        /**
         * 言語コード : lang_cd.
         */
        public static final String LANG_CD = "lang_cd";

        /**
         * リソースディレクトリパス : resource_dir_path.
         */
        public static final String RESOURCE_DIR_PATH = "resource_dir_path";

        /**
         * システムバージョン : system_version.
         */
        public static final String SYSTEM_VERSION = "system_version";

        /**
         * 地図APIのID : map_api_id.
         */
        public static final String MAP_API_ID = "map_api_id";

        /**
         * 座標受信フォーマット : receive_format_point.
         */
        public static final String RECEIVE_FORMAT_POINT = "receive_format_point";

        /**
         * 集計単位 : summary_unit.
         */
        public static final String SUMMARY_UNIT = "summary_unit";

        /**
         * 集計期間 : summary_term.
         */
        public static final String SUMMARY_TERM = "summary_term";

        /**
         * 変換ルール最大件数 : v_event_cond_max.
         */
        public static final String EVENT_CONDITION_MAX = "v_event_cond_max";

        /**
         * ファイル最大サイズ : v_max_file_size.
         */
        public static final String MAX_FILE_SIZE = "v_max_file_size";
        /**
         * ファイル最大サイズ : v_upload_file_path.
         */
        public static final String UPLOAD_FILE_PATH = "v_upload_file_path";
        /**
         * データポイント最大登録数: datapoint_max.
         */
        public static final String DATAPOINT_MAX = "v_save_dp_max";

        /**
         * 通信周期[ミリ秒].
         */
        public static final String TELECOM_CYCLE = "v_telecom_cycle";

        /**
         * アップロードファイル種別.
         */
        public static final String FILE_KIND = "file_kind";

        /**
         * 表示カラーコード：disp_color_cd.
         */
        public static final String DISP_COLOR_CD = "disp_color_cd";
        /**
         * 稼動状態設定最大設定値：v_status_set_max.
         */
        public static final String STATUS_SETTING_MAX = "v_status_set_max";

        /**
         * 稼動状態設定条件最大設定値：v_status_cond_max.
         */
        public static final String STATUS_CONDITION_MAX = "v_status_cond_max";

        /**
         * CSV入力エラー最大数：v_csv_error_count.
         */
        public static final String CSV_ERROR_COUNT = "v_csv_error_count";

        /**
         * 検索結果表示上限：v_search_result_max.
         */
        public static final String SEARCH_RESULT_MAX = "v_search_result_max";

        /**
         * トレンドビューデータポイント登録上限：v_trend_view_max_dp.
         */
        public static final String TREND_VIEW_MAX_DP = "v_trend_view_max_dp";


        /**
         * トレンドビュー表示上限：v_trend_view_max_gd.
         */
        public static final String TREND_VIEW_MAX_GD = "v_trend_view_max_gd";

        /**
         * 配信ファイルの格納ディレクトリ：v_distribute_path.
         */
        public static final String DISTRIBUTE_FILE_PATH = "v_distribute_path";

        /**
         * 配信ファイルのアップロード先：v_upload_send_path.
         */
        public static final String UPLOAD_SEND_FILE_PATH = "v_upload_send_path";

        /**
         * 報告書最大追加件数：v_report_max.
         */
        public static final String V_REPORT_MAX = "v_report_max";

        /**
         * グループ管理権限使用フラグ:v_group_admin_option.
         */
        public static final String V_GROUP_ADMIN_OPTION = "v_group_admin_option";

        /**
         * 機器付帯情報最大件数：v_model_subinfo_max.
         */
        public static final String V_MODEL_SUBINFO_MAX = "v_model_subinfo_max";

        /**
         * FTPファイル名連結文字.
         */
        public static final String V_FTP_FILE_DELIMITER = "v_ftp_file_delimiter";

        /**
         * FTPファイル名連結文字最大桁数.
         */
        public static final String V_FTP_FILE_DELIMITER_MAXSIZE = "v_ftp_delimiter_size";

        /**
         * 稼働状況一覧表示項目名.
         */
        public static final String V_STATUS_LIST_NAME = "v_status_list_name";

        /**
         * 収集データの保持期間.
         */
        public static final String V_DATA_STORE_DAYS = "v_data_store_days";

        /**
         * 通信ログの保持期間.
         */
        public static final String V_LOG_STORE_DAYS = "v_log_store_days";

        /**
         * 容量オーバー.
         */
        public static final String OVER_CAPACITY = "v_over_capacity";

        /**
         * 受信ファイルの上限サイズ(MB).
         */
        public static final String RECEIVE_FILE_MAX_SIZE = "v_rec_file_max_size";

        /**
         * 週初めの曜日 : v_first_day_of_week.
         */
        public static final String V_FIRST_DAY_OF_WEEK = "v_first_day_of_week";

        /**
         * CSV出力最大出力件数：v_csv_max_export_cnt.
         */
        public static final String CSV_MAX_EXPORT_CNT = "v_csv_max_export_cnt";

        /**
         * トレンドモニタ検索結果最大表示件数.
         */
        public static final String TREND_DISP_MAX_CNT = "v_trend_disp_max_cnt";

        /**
         * （WebAPI  SNS送信）接続先のIPアドレス、ポート番号.
         */
        public static final String V_API_IP_PORT = "v_api_ip_port";

        /**
         * （WebAPI  SNS送信）ログイン用のID.
         */
        public static final String V_API_ID = "v_api_id";

        /**
         * （WebAPI  SNS送信）ログイン用のパスワード.
         */
        public static final String V_API_PW = "v_api_pw";

        /**
         * （WebAPI  SNS送信）ログインURL.
         */
        public static final String V_API_LOGIN_URL = "v_api_login_url";

        /**
         * （WebAPI  SNS送信）FenicsId取得URL.
         */
        public static final String V_API_FENICS_ID_URL = "v_api_fenics_id_url";

        /**
         * （WebAPI  SNS送信）通信機器 センターPUSH URL.
         */
        public static final String V_API_CENTERPUSH_URL = "v_api_centerpush_url";

        /**
         * （WebAPI  SNS送信）ログアウトURL.
         */
        public static final String V_API_LOGOUT_URL = "v_api_logout_url";

        /**
         * 任意データポイント利用フラグ.
         */
        public static final String USE_OPTION_DATA_POINT = "v_use_option_dp";

        /**
         * 契約に対する使用率の閾値.
         */
        public static final String CONTRACT_THRESHOLD = "v_contract_threshold";

        /**
         * 受信ファイル転送情報.
         */
        public static final String RCV_FILE_XFER_INFO = "v_rcv_file_xfer_info";

        /**
         * 受信ファイル転送用ディレクトリ(FTP).
         */
        public static final String RCV_FTP_XFER_DIR = "v_rcv_ftp_xfer_dir";

        /**
         * 受信ファイル転送用ディレクトリ(TCP).
         */
        public static final String RCV_TCP_XFER_DIR = "v_rcv_tcp_xfer_dir";

        /**
         * MMCloudアクセスURL.
         */
        public static final String MMCLOUD_ACCESS_URL = "v_mmcloud_access_url";

        /**
         * Excel出力情報.
         */
        public static final String EXPORT_EXCEL_INFO = "v_export_excel_info";

        /**
         * Excel種別.
         */
        public static final String EXCEL_TYPE = "excel_type";

        /**
         * プログレスバー色閾値.
         */
        public static final String BAR_THRESHOLD = "v_bar_threshold";

        /**
         * グラフ要素色.
         */
        public static final String GRAPH_ELEMENT_COLOR = "v_element_color";

        /**
         * グラフ要素色 -- 前詰負荷平準.
         */
        public static final String GRAPH_ELEMENT_COLOR_FOR_C140030 = "v_color_C140030";

        /**
         * グラフ要素色 -- 納期遵守率.
         */
        public static final String GRAPH_ELEMENT_COLOR_FOR_C140040 = "v_color_C140040";

        /**
         * グラフ要素色 -- 納期遅れ額.
         */
        public static final String GRAPH_ELEMENT_COLOR_FOR_C140050 = "v_color_C140050";

        /**
         * グラフ要素色 -- 欠品額.
         */
        public static final String GRAPH_ELEMENT_COLOR_FOR_C140060 = "v_color_C140060";

        /**
         * グラフ要素色 -- 材完率.
         */
        public static final String GRAPH_ELEMENT_COLOR_FOR_C140070 = "v_color_C140070";

        /**
         * グラフ要素色 -- 材完率詳細.
         */
        public static final String GRAPH_ELEMENT_COLOR_FOR_C140080 = "v_color_C140080";

        /**
         * グラフ要素色 -- 欠品品目数.
         */
        public static final String GRAPH_ELEMENT_COLOR_FOR_C140090 = "v_color_C140090";

        /**
         * 業務開始時間.
         */
        public static final String BUSINESS_START_TIME = "v_biz_start_time";
        /**
         * 業務終了時間.
         */
        public static final String BUSINESS_END_TIME = "v_biz_end_time";

        /**
         * 月度開始日.
         */
        public static final String MONTHLY_START_DAY = "v_monthly_start_day";

        /**
         * ライングループ枠.
         */
        public static final String STATUS_FRAME_INFO = "v_status_frame_info";

        /**
         * ライングループアイコン.
         */
        public static final String STATUS_ICON_INFO = "v_status_icon_info";

        /**
         * リードタイム算出用母数.
         */
        public static final String LEAD_TIME_PARAMETER = "v_lead_time_param";

        /**
         * MES-DB接続情報.
         */
        public static final String MES_DB_CONNECT = "v_mes_db_connect";

        /**
         * MES連携接続時間.
         */
        public static final String MES_CONNECT_TIME = "v_mes_connect_time";

        /**
         * ERP-DB接続情報.
         */
        public static final String ERP_DB_CONNECT = "v_erp_db_connect";

        /**
         * ERP連携接続時間.
         */
        public static final String ERP_CONNECT_TIME = "v_erp_connect_time";
    }

    /**
     *
     * 環境マスタの項目CD定数.<br>
     *<br>
     * 概要:<br>
     *   環境マスタの項目CDの定数定義
     *<br>
     */
    public abstract class SYS_ENV_MST_ITEM_CD {
        /**
         * 企業ロゴファイルパス.
         */
        public static final String PATH = "path";

        /**
         * グループ管理権限使用フラグ.
         */
        public static final String AVAILABLE = "available";

        /**
         * アップロードファイルパス.
         */
        public static final String FILE_PATH = "0";

        /**
         * 最大値.
         */
        public static final String MAX = "max";

        /**
         * 最大値(FTPファイル名連結文字用).
         */
        public static final String MAX_SIZE = "max_size";

        /**
         * 収集データの保持期間.
         */
        public static final String V_DATA_STORE_DAYS = "0";

        /**
         * 通信ログの保持期間.
         */
        public static final String V_LOG_STORE_DAYS = "0";

        /**
         * メール送信設定IPアドレス.
         */
        public static final String IP_ADDRESS = "00";

        /**
         * メール送信設定送信元メールアドレス.
         */
        public static final String MAIL_ADDRESS = "01";

        /**
         * 容量オーバー通知周期.
         */
        public static final String NOTICE_PERIOD = "notice_period";

        /**
         * 容量オーバー通知日時（yyyy/MM/dd HH:mm).
         */
        public static final String NOTICE_DATETIME = "notice_datetime";

        /**
         * 容量オーバー通知閾値.
         */
        public static final String NOTICE_THRESHOLD = "notice_threshold";

        /**
         * 地図アクセスオーバー通知周期（分).
         */
        public static final String YLOP_ACCESS_PERIOD = "ylop_access_period";

        /**
         * 地図アクセスオーバー通知閾値.
         */
        public static final String YLOP_NOTICE_DATETIME = "ylop_notice_datetime";

        /**
         * 地図アクセスオーバー通知閾値.
         */
        public static final String YLOP_NOTICE_THRESHOLD = "ylop_notice_threshold";

        /**
         * 閾値メール通知有無フラグ(0:非通知 1:通知).
         */
        public static final String NOTICE_FLAG = "notice_flag";

        /**
         * 週の初めの曜日.
         */
        public static final String FIRST_DAY_OF_WEEK = "0";

        /**
         * 一覧.
         */
        public static final String LIST = "list";

        /**
         * グラフ.
         */
        public static final String GRAPH = "graph";

        /**
         * 地図.
         */
        public static final String MAP = "map";

        /**
         * ログイン用のID.
         */
        public static final String API_IP_PORT = "0";

        /**
         * ログイン用のID.
         */
        public static final String API_ID = "0";

        /**
         * ログイン用のパスワード.
         */
        public static final String API_PW = "0";

        /**
         * ログインURL.
         */
        public static final String API_LOGIN_URL = "0";

        /**
         * FenicsId取得URL.
         */
        public static final String API_FENICS_ID_URL = "0";

        /**
         * 通信機器 センターPUSH URL.
         */
        public static final String API_CENTERPUSH_URL = "0";

        /**
         * 通信機器 センターPUSH URL.
         */
        public static final String API_LOGOUT_URL = "0";

        /**
         * 使用フラグ.
         */
        public static final String OPTION_AVAILABLE = "available";
        /**
         * ホスト名.
         */
        public static final String HOST = "host";

        /**
         * ポート番号.
         */
        public static final String PORT = "port";

        /**
         * URL.
         */
        public static final String URL = "url";

        /**
         * テンプレート配置パス.
         */
        public static final String TEMPLATE_PATH = "template_path";
        /**
         * 滞留分析業務開始時間.
         */
        public static final String START_RET = "1";
        /**
         * 生産進捗業務開始時間.
         */
        public static final String START_PRO = "2";
        /**
         * 生産進捗業務終了時間.
         */
        public static final String END_PRO = "1";
        /**
         * リードタイム計算用母数（時間）.
         */
        public static final String LEAD_TIME_PARAMETER_HOUR = "1";

        /**
         * DB接続文字列.
         */
        public static final String CONNECTION_STRING = "connect_string";

        /**
         * DB接続文字列1(ERP用).
         */
        public static final String CONNECTION_STRING1 = "connect_string1";

        /**
         * DB接続文字列2(ERP用).
         */
        public static final String CONNECTION_STRING2 = "connect_string2";

        /**
         * ユーザID.
         */
        public static final String USER_ID = "user_id";

        /**
         * パスワード.
         */
        public static final String PASSWORD = "password";

        /**
         * MES連携接続時間.
         */
        public static final String MES_CONNECT_DEF = "timeout";
    }

    /**
     *
     * データポイントマスタのデータポイント種別定数.<br>
     *<br>
     * 概要:<br>
     *   データポイントマスタのデータポイント種別定数定義
     *<br>
     */
    public abstract class SAVE_KIND {
        /**
         * 保存しない演算用のデータポイント : 0.
         */
        public static final String SKIP = "0";
        /**
         * 保存するデータポイント : 1.
         */
        public static final String SAVE = "1";
    }

    /**
     *
     * データポイント位置マスタのデータ形式CD定数.<br>
     *<br>
     * 概要:<br>
     *   データポイント位置マスタのデータ形式CD定数定義
     *<br>
     */
    public abstract class DATA_FORM {
        /**
         * CSV.
         */
        public static final String FORM_CSV = "csv";
        /**
         * XML.
         */
        public static final String FORM_XML = "xml";
        /**
         * 固定長.
         */
        public static final String FORM_FIX = "fix";
        /**
         * 単一データ.
         */
        public static final String FORM_MONO = "mono";
        /**
         * 受信ファイル.
         */
        public static final String FORM_FILE = "file";
    }

    /**
     *
     * データポイントマスタの値受信フォーマット(座標)定数.<br>
     *<br>
     * 概要:<br>
     *   データポイントマスタの値受信フォーマット(座標)定数定義
     *<br>
     */
    public abstract class RECEIVE_FORMAT_POINT {
        /**
         * DEG形式：d,d.
         */
        public static final String DEG_D_D = "d,d";
        /**
         * DEG形式：dL,dL.
         */
        public static final String DEG_DL_DL = "dL,dL";
        /**
         * DEG形式：d,L,d,L.
         */
        public static final String DEG_D_L_D_L = "d,L,d,L";

        /**
         * DMM形式：dmL,dmL.
         */
        public static final String DMM_DML_DML = "dmL,dmL";
        /**
         * DMM形式：dm,L,dm,L.
         */
        public static final String DMM_DM_L_DM_L = "dm,L,dm,L";

        /**
         * DMS形式：d,m,s,L,d,m,s,L.
         */
        public static final String DMS_D_M_S_L_D_M_S_L = "d,m,s,L,d,m,s,L";
        /**
         * DMS形式：d°m's",d°m's".
         */
        public static final String DMS_DMS_DMS = "d°m's\",d°m's\"";
    }

    /**
     *
     * 条件結合区分定数.<br>
     *<br>
     * 概要:<br>
     *   条件結合区分を表す定数クラス
     *<br>
     */
    public abstract class JOIN_CLASS {
        /**
         * and条件.
         */
        public static final String AND = "0";
        /**
         * or条件.
         */
        public static final String OR = "1";
    }

    /**
     *
     * 比較種別定数.<br>
     *<br>
     * 概要:<br>
     *   比較種別を表す定数クラス
     *<br>
     */
    public abstract class COMPARE_KIND {

        /**
         *
         * 比較種別定数(数値).<br>
         *<br>
         * 概要:<br>
         *   数値型の比較種別を表す定数クラス
         *<br>
         */
        public abstract class NUM {
            /**
             * 等しい.
             */
            public static final String EQ = "eq";
            /**
             * 等しくない.
             */
            public static final String NE = "ne";
            /**
             * 以上.
             */
            public static final String GE = "ge";
            /**
             * より大きい.
             */
            public static final String GT = "gt";
            /**
             * 以下.
             */
            public static final String LE = "le";
            /**
             * より小さい.
             */
            public static final String LT = "lt";
        }

        /**
         *
         * 比較種別定数(文字列).<br>
         *<br>
         * 概要:<br>
         *   文字列型の比較種別を表す定数クラス
         *<br>
         */
        public abstract class STR {
            /**
             * 等しい.
             */
            public static final String EQ = "eq";
            /**
             * 等しくない.
             */
            public static final String NE = "ne";
            /**
             * 含まれる.
             */
            public static final String IN = "in";
            /**
             * 含まれない.
             */
            public static final String NI = "ni";
        }

    }

    /**
     *
     * アラーム種別定数.<br>
     *<br>
     * 概要:<br>
     *   アラーム種別を表す定数クラス
     *<br>
     */
    public abstract class ALARM_TYPE {
        /**
         * 発生型.
         */
        public static final String GENERATE = "01";
        /**
         * 復帰型.
         */
        public static final String RECOVER = "02";
    }

    /**
     *
     * アラーム状態定数.<br>
     *<br>
     * 概要:<br>
     *   アラーム状態を表す定数クラス
     *<br>
     */
    public abstract class ALARM_STATUS {
        /**
         * 発生中.
         */
        public static final String GENERATE = "01";
        /**
         * 発生中(確認済).
         */
        public static final String GENERATE_CHECK = "02";
        /**
         * 復帰済(未確認).
         */
        public static final String RECOVER = "51";
        /**
         * 復帰済.
         */
        public static final String RECOVER_CHECK = "52";
        /**
         * 完了.
         */
        public static final String END = "91";
    }

    /**
     *
     * アラーム ステータス定数.<br>
     *<br>
     * 概要:<br>
     *   アラームのステータスを表す定数クラス。<br>
     *   ※アラーム判定データのステータスに対応。<br>
     *<br>
     */
    public abstract class ALARM_JUDGE_STATUS {
        /**
         * 発生型.
         */
        public static final String GENERATE = "1";
        /**
         * 復帰型.
         */
        public static final String RECOVER = "2";
    }

    /**
     *
     * アラームレベル定数.<br>
     *<br>
     * 概要:<br>
     *   アラームレベルを表す定数クラス
     *<br>
     */
    public abstract class ALARM_LEVEL {
        /**
         * 低.
         */
        public static final String ROW = "1";
        /**
         * 中.
         */
        public static final String MIDDLE = "2";
        /**
         * 高.
         */
        public static final String HIGH = "3";
        /**
         * 重大.
         */
        public static final String CRITICAL = "4";

        /**
         * アラームLVの種類数.
         */
        public static final int ALARM_LEVEL_NUM = 4;
    }

    /**
     *
     * 監視条件定数.<br>
     *<br>
     * 概要:<br>
     *   監視条件を表す定数クラス
     *<br>
     */
    public abstract class MONITORING_CONDITION {
        /**
         * 監視する.
         */
        public static final String DO = "00";
        /**
         * 監視しない.
         */
        public static final String NOT = "01";
    }

    /**
     *
     * アドレス種別定数.<br>
     *<br>
     * 概要:<br>
     *   アラーム送信アドレスのアドレス種別を表す定数クラス
     *<br>
     */
    public abstract class ADDRESS_KIND {
        /**
         * TO.
         */
        public static final String TO = "To";
        /**
         * CC.
         */
        public static final String CC = "Cc";
        /**
         * BCC.
         */
        public static final String BCC = "Bcc";
    }

    /**
     *
     * 発生・復帰区分定数.<br>
     *<br>
     * 概要:<br>
     *   発生・復帰区分を表す定数クラス
     *<br>
     */
    public abstract class GENERATE_RECOVER_KIND {
        /**
         * 発生.
         */
        public static final String GENERATE = "0";
        /**
         * 復帰.
         */
        public static final String RECOVER = "1";
    }

    /**
     *
     * シーケンス定数.<br>
     *<br>
     * 概要:<br>
     *   シーケンス名を定義する定数クラス
     *<br>
     */
    public abstract class SEQ {
        /**
         * アラームマスタ.
         */
        public static final String ALARM = "seq_alarm_sid";
        /**
         * アラーム条件マスタ.
         */
        public static final String ALARM_CONDITION = "seq_alarm_condition_sid";
        /**
         * アラーム送信アドレスマスタ.
         */
        public static final String ALARM_SEND_ADDRESS = "seq_alarm_send_address_sid";
        /**
         * 通信端末マスタ.
         */
        public static final String COM_TERMINAL = "seq_com_terminal_sid";
        /**
         * コマンドマスタ.
         */
        public static final String COMMAND = "seq_command_sid";
        /**
         * データポイントマスタ.
         */
        public static final String DATA_POINT = "seq_data_point_sid";
        /**
         * データポイント演算マスタ.
         */
        public static final String DATA_POINT_CALC = "seq_data_point_calc_sid";
        /**
         * データポイント位置(CSV)マスタ.
         */
        public static final String DATA_POINT_POSITION_CSV = "seq_data_point_position_csv_sid";
        /**
         * データポイント位置(固定長)マスタ.
         */
        public static final String DATA_POINT_POSITION_FIX = "seq_data_point_position_fix_sid";
        /**
         * データポイント位置(XML)マスタ.
         */
        public static final String DATA_POINT_POSITION_XML = "seq_data_point_position_xml_sid";
        /**
         * 計測日時マスタ.
         */
        public static final String DATETIME = "seq_datetime_sid";
        /**
         * 機器マスタ.
         */
        public static final String DEVICE = "seq_device_sid";
        /**
         * 機器付帯情報マスタ.
         */
        public static final String DEVICE_SUBINFO = "seq_device_subinfo_sid";
        /**
         * メールアドレスマスタ.
         */
        public static final String MAIL_ADDRESS = "seq_mail_address_sid";
        /**
         * メールテンプレートマスタ.
         */
        public static final String MAIL_TEMPLATE = "seq_mail_template_sid";
        /**
         * 型番マスタ.
         */
        public static final String MODEL = "seq_model_sid";
        /**
         * 通信プロファイルマスタ.
         */
        public static final String PROFILE = "seq_profile_sid";
        /**
         * 通信プロトコルマスタ.
         */
        public static final String PROTOCOL = "seq_protocol_sid";
        /**
         * 役割マスタ.
         */
        public static final String ROLE = "seq_role_sid";
        /**
         * 役割設定マスタ.
         */
        public static final String ROLE_SETTING = "seq_role_setting_sid";
        /**
         * ユーザマスタ.
         */
        public static final String USER = "seq_user_sid";
        /**
         * アラーム状態データ.
         */
        public static final String ALARM_STATE_DATA = "seq_alarm_state_data_sid";
        /**
         * お気に入りデータ.
         */
        public static final String FAVORITE = "seq_favorite_sid";
        /**
         * お気に入り詳細データ.
         */
        public static final String FAVORITE_DETAIL = "seq_favorite_detail_sid";
        /**
         * お知らせ情報データ.
         */
        public static final String INFOMATION = "seq_infomation_sid";
        /**
         * 地図アクセスカウントデータ.
         */
        public static final String MAP_ACCESS_COUNT_DATA = "seq_map_access_count_data_sid";
        /**
         * 通信プロセスログデータ.
         */
        public static final String TELECOM_LOG = "seq_telecom_log_sid";
        /**
         * 電文送信ログデータ.
         */
        public static final String TELECOM_SEND_LOG = "seq_telecom_send_log_sid";
        /**
         * 通信電文データ.
         */
        public static final String TELEGRAM_DATA = "seq_telegram_data_sid";

        /**
         * データポイント名称用項目CD(名称マスタ).
         */
        public static final String SYSNAME_DATAPOINT_NAME_CD = "seq_sysname_datapoint_name_cd";
        /**
         * 単位用項目CD(名称マスタ).
         */
        public static final String SYSNAME_UNIT_CD = "seq_sysname_unit_cd";

        /**
         * 設定値名称用項目CD(名称マスタ).
         */
        public static final String SYSNAME_SETTING_NAME_CD = "seq_sysname_setting_name_cd";

        /**
         * 点検保守SID.
         */
        public static final String MAINTE = "seq_mainte_status_sid";

        /**
         * コメントSID.
         */
        public static final String COMMENT = "seq_comment_sid";

        /**
         * ドキュメントマスタ.
         */
        public static final String EVENT_CONVERT = "seq_event_convert_sid";
        /**
         * ドキュメントマスタ.
         */
        public static final String EVENT_CONVERT_CONDITION = "seq_event_convert_condition_sid";
        /**
         * ドキュメントマスタ.
         */
        public static final String DOCUMENT = "seq_document_sid";

        /**
         * トレンドビューマスタ.
         */
        public static final String TREND_VIEW = "seq_trend_view_sid";

        /**
         * 状態値設定マスタ.
         */
        public static final String DEVICE_STATUS_SETTING = "seq_device_status_setting_sid";

        /**
         * 配信データマスタ.
         */
        public static final String DISTRIBUTE_DATA = "seq_distribute_data_sid";

        /**
         * 配信状態テーブル.
         */
        public static final String DISTRIBUTE_STATUS = "seq_distribute_status_sid";

        /**
         * 配信履歴テーブル.
         */
        public static final String DISTRIBUTE_HISTORY = "seq_distribute_history_sid";

        /**
         * 機器稼動状態マスタ.
         */
        public static final String DEVICE_STATUS = "seq_device_status_sid";

        /**
         * 通信状況テーブル.
         */
        public static final String TELECOM_STATUS = "seq_telecom_status_sid";

        /**
         * 型番付帯情報マスタ.
         */
        public static final String MODEL_SUBINFO = "seq_model_subinfo_sid";

        /**
         * 機器付帯情報用項目CD(名称マスタ).
         */
        public static final String MSTNAME_MODEL_SUBINFO = "seq_mstname_model_subinfo_cd";

        /**
         * アラーム条件判定データ.
         */
        public static final String ARARM_JUDGU_DATA = "seq_alarm_judge_data_sid";

        /**
         * ルートDBお知らせ情報SID SEQ.
         */
        public static final String ROOT_INFORMATION = "seq_customer_infomation_sid";

        /**
         * 製品計画数手入力SID SEQ.
         */
        public static final String SEIHIN_PLAN_MANUAL_SETTING = "seq_seihin_plan_manual_setting_sid";
    }

    /**
     *
     * 権限区分定数.<br>
     *<br>
     * 概要:<br>
     *   役割設定マスタの権限設定区分を表す定数クラス
     *<br>
     */
    public abstract class ROLE_AUTH_KIND {
        /**
         * 権限なし.
         */
        public static final String NONE = "0";
        /**
         * 1：利用可能（閲覧可能）.
         */
        public static final String DISP_ENABLE = "1";
        /**
         * 2：利用可能（更新可能）.
         */
        public static final String UPDATE_ENABLE = "2";

    }

    /**
     *
     * 曜日定数.<br>
     *<br>
     * 概要:<br>
     *   アラーム条件の監視曜日を表す定数クラス
     *<br>
     */
    public abstract class DAY_OF_WEEK {
        /**
         * 月曜.
         */
        public static final short MON = 1;
        /**
         * 火曜.
         */
        public static final short TUE = 2;
        /**
         * 水曜.
         */
        public static final short WED = 4;
        /**
         * 木曜.
         */
        public static final short THR = 8;
        /**
         * 金曜.
         */
        public static final short FRI = 16;
        /**
         * 土曜.
         */
        public static final short SAT = 32;
        /**
         * 日曜.
         */
        public static final short SUN = 64;

    }

    /**
     *
     * 通信形式定数.<br>
     *<br>
     * 概要:<br>
     *   通信形式を表す定数クラス
     *<br>
     */
    public abstract class PROTOCOL {
        /**
         * TCP.
         */
        public static final String TCP = "tcp";
        /**
         * FTP.
         */
        public static final String FTP = "ftp";
        /**
         * MMLP(MmLinkProtocol).
         */
        public static final String MMLP = "mmlp";
    }

    /**
     *
     * ユーザ公開フラグ項目定数.<br>
     *<br>
     * 概要:<br>
     *   デフォルトフラグ項目定数定義
     *<br>
     */
    public abstract class PUBLISH_FLAG_KIND {
        /**
         * ユーザ公開しする : 0.
         */
        public static final String PUBLISH_OFF = "0";
        /**
         * ユーザ公開する : 1.
         */
        public static final String PUBLISH_ON = "1";
    }

    /**
     *
     * デフォルトフラグ項目定数.<br>
     *<br>
     * 概要:<br>
     *   デフォルトフラグ項目定数定義
     *<br>
     */
    public abstract class DEFAULT_FLAG_KIND {
        /**
         * デフォルトではない : 0.
         */
        public static final String DEFAULT_OFF = "0";
        /**
         * デフォルト : 1.
         */
        public static final String DEFAULT_ON = "1";
    }

    /**
     *
     * 位置取得区分項目定数.<br>
     *<br>
     * 概要:<br>
     *   位置取得区分項目定数定義
     *<br>
     */
    public abstract class POSITION_GET_CLASS {
        /**
         * 機器マスタの位置情報:0.
         */
        public static final String FROM_DEVICE_MST = "0";
        /**
         * データポイントデータの位置データ:1.
         */
        public static final String FROM_DATA_POINT = "1";
    }

    /**
     *
     * 稼働状態項目定数.<br>
     *<br>
     * 概要:<br>
     *   稼働状態項目定数定義
     *<br>
     */
    public abstract class OPERATION_STATUS {
        /**
         * 停止中：0.
         */
        public static final String STOP = "0";
        /**
         * 運転中：1.
         */
        public static final String RUN = "1";
        /**
         * メンテナンス中：2.
         */
        public static final String MAINTENANCE = "2";
        /**
         * 出荷待ち：3.
         */
        public static final String STANDBY = "3";
    }

    /**
     *
     * メール通知フラグ項目定数.<br>
     *<br>
     * 概要:<br>
     *   メール通知フラグ項目定数定義
     *<br>
     */
    public abstract class MAIL_SEND_FLAG {
        /**
         * デフォルトではない : 0.
         */
        public static final String MAIL_SEND_OFF = "0";
        /**
         * デフォルト : 1.
         */
        public static final String MAIL_SEND_ON = "1";
    }



    /**
     *
     * データ長定数.<br>
     *<br>
     * 概要:<br>
     *   各入力項目、ID等の最大、最小長または固定長定義。
     *<br>
     */
    public abstract class LENGTH {
        /**
         * 機能CD（例:A01）の長さ : 3.
         */
        public static final int FUNCTION_CD_LENGTH = 3;

        /**
         * 型番IDの最大長 : 20.
         */
        public static final int MODEL_ID_MAX_LENGTH = 20;

        /**
         * 型番名称の最大長 : 32.
         */
        public static final int MODEL_NAME_MAX_LENGTH = 32;

        /**
         * 機器付帯情報（項目名）の最大長 : 64.
         */
        public static final int DEVICE_SUBINFO_ITEM_MAX_LENGTH = 64;

        /**
         * 機器付帯情報（項目値）の最大長 : 128.
         */
        public static final int DEVICE_SUBINFO_VALUE_MAX_LENGTH = 128;

        /**
         * プロファイル名称の最大長 : 64.
         */
        public static final int PROFILE_NAME_MAX_LENGTH = 64;

        /**
         * 位置取得区分名の最大長 : 20.
         */
        public static final int POSITION_GET_CLASS_NAME_MAX_LENGTH = 20;

        /**
         * 通信端末名称の最大長 : 64.
         */
        public static final int TERMINAL_NAME_MAX_LENGTH = 64;

        /**
         * タイムゾーン名称の最大長 : 20.
         */
        public static final int TIMEZONE_NAME_MAX_LENGTH = 20;

        /**
         * 稼働状態名称の最大長 : 20.
         */
        public static final int OPERATION_STATUS_NAME_MAX_LENGTH = 20;

        /**
         * SIMタイプの最大長 : 20.
         */
        public static final int SIM_TYPE_MAX_LENGTH = 20;

        /**
         * アラーム名称の最大長 : 64.
         */
        public static final int ALARM_NAME_MAX_LENGTH = 64;

        /**
         * メールテンプレート名の最大長 : 16.
         */
        public static final int MAIL_TEMPLATE_NAME_MAX_LENGTH = 16;

        /**
         * 役割名称 : 32.
         */
        public static final int ROLE_NAME_MAX_LENGTH = 32;

        /**
         * 表示順 : 10.
         */
        public static final int DISPLAY_ORDER_MAX_LENGTH = 10;

        /**
         * メールアドレス : 1024.
         */
        public static final int MAIL_ADDRESS_MAX_LENGTH = 1024;

        /**
         * メールアドレス名称 : 20.
         */
        public static final int MAIL_ADDRESS_NAME_MAX_LENGTH = 20;

        /**
         * （機器マスタ）機器IDの最大長 : 20.
         */
        public static final int DEVICE_ID_MAX_LENGTH = 20;

        /**
         * （機器マスタ）機器名称の最大長 : 32.
         */
        public static final int DEVICE_NAME_MAX_LENGTH = 32;

        /**
         * （機器マスタ）バージョンの最大長 : 32.
         */
        public static final int VERSION_MAX_LENGTH = 32;

        /**
         * （機器マスタ）シリアルNoの最大長 : 32.
         */
        public static final int SERIAL_NO_MAX_LENGTH = 32;

        /**
         * （機器マスタ）位置取得区分の最大長 : 1.
         */
        public static final int POSITION_GET_CLASS_MAX_LENGTH = 1;

        /**
         * （機器マスタ）位置情報の最大長 : (32-1)/2=15.
         */
        public static final int POSITION_INFO_MAX_LENGTH = 15;

        /**
         * （機器マスタ）アドレスの最大長 : 128.
         */
        public static final int ADDRESS_MAX_LENGTH = 128;

        /**
         * （機器マスタ）タイムゾーンCDの最大長 : 64.
         */
        public static final int TIMEZONE_CD_MAX_LENGTH = 64;

        /**
         * （機器マスタ）稼働状態の最大長 : 1.
         */
        public static final int OPERATION_STATUS_MAX_LENGTH = 1;

        /**
         * （機器マスタ）IPアドレスの最大長 : 15.
         */
        public static final int IP_ADDRESS_MAX_LENGTH = 15;

        /**
         * （機器マスタ）ポート番号の最大長 : 5.
         */
        public static final int PORT_NUMBER_MAX_LENGTH = 5;

        /**
         * （アラームマスタ）最短アラーム間隔の最大長 : 5.
         */
        public static final int FORBID_REALARM_TIME_MAX_LENGTH = 5;

        /**
         * （アラーム条件マスタ）閾値の最大長 : 8.
         */
        public static final int BORDER_VALUE_MAX_LENGTH = 8;

        /**
         * （データポイントマスタ）閾値の最大長 : 16.
         */
        public static final int DATAPOINT_CD_MAX_LENGTH = 16;

        /**
         * （データポイント位置マスタ）項目番号の最大長 : 3.
         */
        public static final int VALUE_COLUMN_NUM_MAX_LENGTH = 3;

        /**
         * （通信コマンド、データポイント位置マスタ）XPATHの最大長 : 128.
         */
        public static final int XPATH_MAX_LENGTH = 128;

        /**
         * （データポイント位置マスタ）値開始位置の最大長 : 5.
         */
        public static final int VALUE_START_POSITION_MAX_LENGTH = 5;

        /**
         * （データポイント位置マスタ）値長さの最大長 : 3.
         */
        public static final int VALUE_LENGTH_MAX_LENGTH = 3;

        /**
         * （データポイントマスタ）受信フォーマットの最大長 : 32.
         */
        public static final int RECEIVE_FORMAT_MAX_LENGTH = 32;

        /**
         * （データポイントマスタ）データ有効時間の最大長 : 5.
         */
        public static final int DATA_EFFECT_TIME_MAX_LENGTH = 5;

        /**
         * （データポイントマスタ）最大値(最小値)の最大長 : 10.
         */
        public static final int MAX_VALUE_MAX_LENGTH = 10;

        /**
         * （通信コマンドマスタ）コマンドCDの最大長 : 4.
         */
        public static final int COMMAND_CD_MAX_LENGTH = 4;

        /**
         * （通信コマンドマスタ）コマンド名称の最大長 : 64.
         */
        public static final int COMMAND_NAME_MAX_LENGTH = 64;

        /**
         * （通信コマンドマスタ）ヘッダ行数の最大長 : 5.
         */
        public static final int HEADER_LINE_NUM_MAX_LENGTH = 5;

        /**
         * （通信コマンドマスタ）繰返しデータ長の最大長 : 5.
         */
        public static final int CHANGE_LINE_LENGTH_MAX_LENGTH = 5;

        /**
         * （名称マスタ）表示名称の最大長 : 64.
         */
        public static final int NAME_MAX_LENGTH = 64;

        /**
         * （点検保守マスタ）種別の最大長（プルダウン用） : 32.
         */
        public static final int MAINTE_TYPE_STRING_MAX_LENGTH = 32;

        /**
         * （点検保守マスタ）ステータスの最大長（プルダウン用） : 32.
         */
        public static final int MAINTE_STATUS_STRING_MAX_LENGTH = 32;

        /**
         * （点検保守マスタ）報告書名称の最大長 : 256（DB:1024）.
         */
        public static final int REPORT_NAME_MAX_LENGTH = 256;

        /**
         * （点検保守マスタ）点検種別の最大長 : 1（DB:1）.
         */
        public static final int MAINTE_TYPE_MAX_LENGTH = 1;

        /**
         * （点検保守マスタ）点検状態の最大長 : 1（DB:1）.
         */
        public static final int MAINTE_STATUS_MAX_LENGTH = 1;

        /**
         * （点検保守マスタ）報告書NOの最大長 : 32（DB:128）.
         */
        public static final int MAINTE_NO_MAX_LENGTH = 32;

        /**
         * （点検保守マスタ）実施担当者の最大長 : 64（DB:256）.
         */
        public static final int MAINTE_USER_MAX_LENGTH = 64;

        /**
         * （点検保守マスタ）点検項目の最大長 : 1024（DB:4096）.
         */
        public static final int MAINTE_OUTLINE_MAX_LENGTH = 1024;

        /**
         * （点検保守マスタ）点検結果の最大長 : 1024（DB:4096）.
         */
        public static final int MAINTE_RESULT_MAX_LENGTH = 1024;

        /**
         * （点検保守マスタ）故障状況の最大長 : 1024（DB:4096）.
         */
        public static final int FAILUER_OUTLINE_MAX_LENGTH = 1024;

        /**
         * （点検保守マスタ）処置・確認方法の最大長 : 1024（DB:4096）.
         */
        public static final int ACTION_OUTLINE_MAX_LENGTH = 1024;

        /**
         * （点検保守マスタ）原因・対策の最大長 : 1024（DB:4096）.
         */
        public static final int COUSE_OUTLINE_MAX_LENGTH = 1024;

        /**
         * （点検保守マスタ）備考の最大長 : 1024（DB:4096）.
         */
        public static final int APPENDIX_MAX_LENGTH = 1024;

        /**
         * （コメントマスタ）履歴コメントの最大長 : 1024（DB:4096）.
         */
        public static final int APPROVAL_COMMENT_MAX_LENGTH = 1024;

        /**
         * （コメントマスタ）コメントの最大長 : 1024（DB:4096）.
         */
        public static final int MAINTE_COMMENT_MAX_LENGTH = 1024;

        /**
         * 資料種別.
         */
        public static final int EVENT_CONVERT_NAME_MAX_LENGTH = 256;

        /**
         * 比較値.
         */
        public static final int COMPARE_VALUE_MAX_LENGTH = 256;

        /**
         * イベントデータ値.
         */
        public static final int CONVERT_VALUE_MAX_LENGTH = 10;

        /**
         * キーCD.
         */
        public static final int DOCMENT_KEYCD_MAX_LENGTH = 64;
        /**
         * 文書区分.
         */
        public static final int DOCMENT_DOCTYPE_MAX_LENGTH = 1;
        /**
         * 資料名称.
         */
        public static final int DOCMENT_DOCNAME_MAX_LENGTH = 256;
        /**
         * 資料No（DB保存時の最大長）.
         */
        public static final int DOCMENT_DOCNO_MAX_LENGTH = 32;
        /**
         * 資料No（0詰めの桁数）.
         */
        public static final int DOCUMENT_DOCNO_LENGTH = 6;
        /**
         * メモ.
         */
        public static final int DOCMENT_MEMO_MAX_LENGTH = 1024;
        /**
         * 資料種別.
         */
        public static final int DOCMENT_FILEKIND_MAX_LENGTH = 2;

        /**
         * ファイル種別文字列最大長.
         */
        public static final int DOCMENT_FILEKIND_STRING_MAX_LENGTH = 40;

        /**
         * {トレンド名称長さ}.
         */
        public static final int TREND_NAME_LEN = 32;

        /**
         * {表示範囲長さ}.
         */
        public static final int DISP_RANGE_LEN = 17;

        /**
         * 最大パスの長さ.
         */
        public static final int FILE_PATH_LEN = 256;

        /**
         * (稼動状態設定情報)状態継続時間.
         */
        public static final int STATE_DURATION_MAX_LENGTH = 5;

        /**
         * グループID最大長.
         */
        public static final int GROUP_ID_MAX_LENGTH = 4;

        /**
         * （ユーザマスタ）ユーザID最大の長さ : 12.
         */
        public static final int USER_ID_MAX_LENGTH = 12;

        /**
         * （ユーザマスタ）ユーザID最小の長さ : 5.
         */
        public static final int USER_ID_MIN_LENGTH = 5;

        /**
         * （ユーザマスタ）ユーザ姓最大の長さ : 20.
         */
        public static final int USER_LAST_NAME_MAX_LENGTH = 20;

        /**
         * （ユーザマスタ）ユーザ名最大の長さ : 20.
         */
        public static final int USER_FIRST_NAME_MAX_LENGTH = 20;

        /**
         * （ユーザマスタ）ユーザ姓カナ最大の長さ : 40.
         */
        public static final int USER_LAST_NAME_KANA_MAX_LENGTH = 40;

        /**
         * （ユーザマスタ）ユーザ名カナ最大の長さ : 40.
         */
        public static final int USER_FIRST_NAME_KANA_MAX_LENGTH = 40;

        /**
         * ファイル種別文字列最大長.
         */
        public static final int DISTRIBUTION_DATA_FILETYPE_STRING_MAX_LENGTH = 20;

        /**
         * 配信データ名称文字列最大長.
         */
        public static final int DISTRIBUTION_DATA_NAME_STRING_MAX_LENGTH = 32;

        /**
         * 配信データバージョン文字列最大長.
         */
        public static final int DISTRIBUTION_DATA_VERSION_STRING_MAX_LENGTH = 32;

        /**
         * 配信ファイル名最大長.
         */
        public static final int DISTRIBUTION_DATA_FILE = 128;

        /**
         * コマンド名称最大長.
         */
        public static final int DISTRIBUTION_COMMAND_NAME = 256;

        /**
         * データポイント最大長.
         */
        public static final int DISTRIBUTION_DATA_POINT_NAME = 64;

        /**
         * 集計方法最大長.
         */
        public static final int DISTRIBUTION_COUNT_METHOD_STATUS = 64;

        /**
         * 集計期間最大長.
         */
        public static final int DISTRIBUTION_SUMMARY_TERM_STATUS = 64;

        /**
         * 製造ライン名の最大長 : 100.
         */
        public static final int SEIZO_LINE_NAME_MAX_LENGTH = 100;

        /**
         * 工程名称の最大長 : 256.
         */
        public static final int PROCESS_NAME_MAX_LENGTH = 256;

        /**
         * ステーション番号の最大長 : 8.
         */
        public static final int STATION_NO_MAX_LENGTH = 8;

        /**
         * 無制限.
         */
        public static final int UNLIMITED_LENGTH = -1;

        /**
         * 機種カテゴリ名称の最大長 : 256.
         */
        public static final int KISHU_NAME = 256;
    }

    /**
     *
     * 緯度・経度定数.<br>
     *<br>
     * 概要:<br>
     *   緯度・経度定数定義
     *<br>
     */
    public abstract class POSITION_INFO_VALUE {
        /**
         * 緯度最大値.
         */
        public static final double LATITUDE_MAX_VALUE = 90.0;
        /**
         * 緯度最小値.
         */
        public static final double LATITUDE_MIN_VALUE = -90.0;
        /**
         * 経度最大値.
         */
        public static final double LONGITUDE_MAX_VALUE = 180.0;
        /**
         * 経度最小値.
         */
        public static final double LONGITUDE_MIN_VALUE = -180.0;

        /**
         * 小数点以下桁数.
         */
        public static final int NUM_OF_DECIMAL_PLACES = 6;

    }

    /**
     *
     * タブINDEX定数.<br>
     *<br>
     * 概要:<br>
     *   タブINDEX定数定義
     *<br>
     */
    public abstract class TAB_INDEX {
        /**
         * 一覧タブ：0.
         */
        public static final String LIST = "0";
        /**
         * 地図タブ：1.
         */
        public static final String MAP = "1";
        /**
         * グラフタブ：2.
         */
        public static final String GRAPH = "2";
    }

    /**
     *
     * 画像の拡張子.<br>
     *<br>
     * 概要:<br>
     *   画像の拡張子
     *<br>
     */
    public abstract class PIC_EXT {
        /**
         * jpg.
         */
        public static final String JPG = "jpg";
        /**
         * jpeg.
         */
        public static final String JPEG = "jpeg";
        /**
         * gif.
         */
        public static final String GIF = "gif";
        /**
         * png.
         */
        public static final String PNG = "png";
        /**
         * bmp.
         */
        public static final String BMP = "bmp";

    }


    /**
     *
     * グラフ定数.<br>
     *<br>
     * 概要:<br>
     *   グラフ描画用の定数クラス
     *<br>
     */
    public static class GRAPH {

        /**
         *
         * 期間定数.<br>
         *<br>
         * 概要:<br>
         *   期間を表す定数クラス
         *<br>
         */
        public enum Term {
            /**
             * 1分.
             */
            OneMinute("1min", Calendar.MINUTE, 1),
            /**
             * 5分.
             */
            FiveMinute("5min", Calendar.MINUTE, 5),
            /**
             * 10分.
             */
            TenMinute("10min", Calendar.MINUTE, 10),
            /**
             * 30分.
             */
            ThirtyMinute("30min", Calendar.MINUTE, 30),
            /**
             * 1時間.
             */
            OneHour("1hour", Calendar.HOUR_OF_DAY, 1),
            /**
             * 6時間.
             */
            SixHour("6hour", Calendar.HOUR_OF_DAY, 6),
            /**
             * 12時間.
             */
            TwelveHour("12hour", Calendar.HOUR_OF_DAY, 12),
            /**
             * 1日.
             */
            OneDay("1day", Calendar.DAY_OF_MONTH, 1),
            /**
             * 7日.
             */
            SevenDay("7day", Calendar.DAY_OF_MONTH, 7),
            /**
             * 1ヶ月.
             */
            OneMonth("1month", Calendar.MONTH, 1),
            /**
             * 1年.
             */
            OneYear("1year", Calendar.YEAR, 1);

            /**
             * キー.
             */
            public final String key;
            /**
             * フィールド値.
             */
            public final int field;
            /**
             * 値.
             */
            public final int num;

            /**
             *
             * コンストラクタ.
             *
             * @param _key キー
             * @param _field フィールド値
             * @param _num 値
             */
            private Term(final String _key, final int _field, final int _num) {
                this.key = _key;
                this.field = _field;
                this.num = _num;
            }

            /**
             *
             * 該当Enum取得.<br>
             *<br>
             * 概要:<br>
             *   指定したキーに該当するEnumを取得する
             *<br>
             * @param _key キー
             * @return Enum
             */
            public static Term getEnum(final String _key) {
                Term ret = Term.OneMinute;

                for (Term term : Term.values()) {
                    if (term.key.equals(_key)) {
                        ret = term;
                        break;
                    }
                }

                return ret;
            }

        }

        /**
         *
         * 単位定数.<br>
         *<br>
         * 概要:<br>
         *   単位を表す定数クラス
         *<br>
         */
        public enum Unit {
            /**
             * 1秒.
             */
            OneSecond("1second", Calendar.SECOND, 1, 1000),
            /**
             * 1分.
             */
            OneMinute("1min", Calendar.MINUTE, 1, 60000),
            /**
             * 30分.
             */
            ThirtyMinute("30min", Calendar.MINUTE, 30, 1800000),
            /**
             * 1時間.
             */
            OneHour("1hour", Calendar.HOUR_OF_DAY, 1, 3600000),
            /**
             * 6時間.
             */
            SixHour("6hour", Calendar.HOUR_OF_DAY, 6, 21600000),
            /**
             * 12時間.
             */
            TwelveHour("12hour", Calendar.HOUR_OF_DAY, 12, 43200000),
            /**
             * 1日.
             */
            OneDay("1day", Calendar.DAY_OF_MONTH, 1, 86400000),
            /**
             * 1週間.
             */
            OneWeek("1week", Calendar.DAY_OF_MONTH, 7, 604800000),
            /**
             * 1ヶ月.
             */
            OneMonth("1month", Calendar.MONTH, 1, 2678400000L);

            /**
             * キー.
             */
            public final String key;
            /**
             * モード.
             */
            public final int field;
            /**
             * 単位数.
             */
            public final int num;

            /**
             * 単位(ミリ秒).
             */
            public final long numMill;

            /**
             *
             * コンストラクタ.
             *
             * @param _key キー
             * @param _field フィールド値
             * @param _num 単位数
             * @param _numMill 単位(ミリ秒)
             */
            private Unit(final String _key, final int _field, final int _num, final long _numMill) {
                this.key = _key;
                this.field = _field;
                this.num = _num;
                this.numMill = _numMill;
            }

            /**
             *
             * 該当Enum取得.<br>
             *<br>
             * 概要:<br>
             *   指定したキーに該当するEnumを取得する
             *<br>
             * @param _key キー
             * @return Enum
             */
            public static Unit getEnum(final String _key) {
                Unit ret = Unit.OneMinute;

                for (Unit unit : Unit.values()) {
                    if (unit.key.equals(_key)) {
                        ret = unit;
                        break;
                    }
                }

                return ret;
            }

        }

    }

    /**
     *
     * 移動方向.<br>
     *<br>
     * 概要:<br>
     *   起点日、期間などの移動方向
     *<br>
     */
    public abstract class MOVE_DIRECTION {
        /**
         * 進む >.
         */
        public static final String AHEAD = "ahead";
        /**
         * 進む >>.
         */
        public static final String AHEAD2 = "ahead2";
        /**
         * 戻る <.
         */
        public static final String NEXT = "next";
        /**
         * 戻る <<.
         */
        public static final String NEXT2 = "next2";
        /**
         * 現在日時.
         */
        public static final String CURRENT = "current";
    }

    /**
     *
     * 点検保守状況用定義.<br>
     *<br>
     * 概要:<br>
     *<br>
     */
    public abstract class MST_MAINTE_STATUS_CONST {
        /**
         * ステータス：実施済.
         */
        public static final String MAINTE_STATUS_EXECUTED = "1";

        /**
         * 承認コメント.
         */
        public static final String APPROVAL_COMMENT = "1";

        /**
         * 通常コメント.
         */
        public static final String MAINTE_COMMENT = "0";

        /**
         * 点検種別：点検.
         */
        public static final String MAINTE_TYPE_CHECK = "0";

        /**
         * 点検種別：整備.
         */
        public static final String MAINTE_TYPE_MAINTENUNCE = "1";

        /**
         * 点検種別：故障修理.
         */
        public static final String MAINTE_TYPE_REPAIR = "2";
    }

    /**
     *
     * トレンドモニタASCIIコード.<br>
     *<br>
     * 概要:<br>
     *   ASCIIコードクラスです
     *<br>
     */
    public abstract class ASCIICODE {
        /**
         * SPACE.
         */
        public static final int SPACE = 0x20;
        /**
         * TILDE.
         */
        public static final int TILDE = 0x7e;

    }

    /**
     *
     * トレンドモニタ制御コード.<br>
     *<br>
     * 概要:<br>
     *   制御コード定義
     *<br>
     */
    public abstract class CTRLCODE {
        /**
         * NBSP.
         */
        public static final int NBSP = 0x00A0;

        /**
         * SHY.
         */
        public static final int SHY = 0x00AD;
    }

    /**
     *
    * リソース種別項目定数.<br>
    *<br>
    * 概要:<br>
    *   リソース種別定数定義
    *<br>
    */
    public abstract class RESOURCE_TYPE_KIND {
       /**
        * DBサーバ : 0.
        */
        public static final String RESOURCE_TYPE_DB = "0";
       /**
        * FTP : 1.
        */
        public static final String RESOURCE_TYPE_FTP = "1";
    }

   /**
    *
    * リソース表示用定数.<br>
    *<br>
    * 概要:<br>
    *<br>
    */
    public abstract class RESOURCE_AMOUNT_CONST {
       /**
        * DBサーバ : 0.
        */
        public static final double CONV_PERCENTAGE = 100.0;
       /**
        * FTP : 1.
        */
        public static final double CONV_AMOUNT_UNIT = 1024.0;
    }

    /**
     *
     * 文書区分.<br>
     * <br>
     * 概要:<br>
     * 文書区分クラスです <br>
     */
    public abstract class DOCTYPE {
        /**
         * 0：型番.
         */
        public static final String MODEL = "0";

        /**
         * 1：機器.
         */
        public static final String DEVICE = "1";
    }

    /**
     * 資料種別.<br>
     * <br>
     * 概要:<br>
     * 資料種別クラスです <br>
     */
    public abstract class FILEKIND {
        /**
         * 1：マニュアル.
         */
        public static final String MANUAL = "1";

        /**
         * 2：図面.
         */
        public static final String DRAWING = "2";

        /**
         * 3：その他.
         */
        public static final String OTHER = "3";

        /**
         * 4：設計書.
         */
        public static final String DESIGN_SPECIFICATIONS = "4";

        /**
         * 5：報告書添付資料.
         */
        public static final String ATTACHED_PAPERS = "5";

        /**
         * 6：画像.
         */
        public static final String PICTURE = "6";

        /**
         * 7：テンプレート.
         */
        public static final String TEMPLATE = "7";

        /**
         * 8：受信ファイル.
         */
        public static final String RECEPTION_FILE = "8";
    }

    /**
     *
     * 比較値.<br>
     *<br>
     * 概要:<br>
     *   比較値のクラスです
     *<br>
     */
    public abstract class EVENT_COMPARE_KIND {
        /**
         * 1:=.
         */
        public static final String EQUAL = "1";

        /**
         * 2:≠.
         */
        public static final String NOT_EQUAL = "2";
    }

    /**
     *
     * トレンドグラフ表示範囲.<br>
     * <br>
     * 概要:<br>
     * トレンドグラフ表示範囲値のクラスです。 <br>
     */
    public abstract class TREND_VIEW_DISP_RANGE_LIMIT {
        /**
         * {表示範囲最小}.
         */
        public static final double DISP_RANGE_MAX = 9999999999.99999;

        /**
         * {表示範囲最大}.
         */
        public static final double DISP_RANGE_MIN = -9999999999.99999;
    }

    /**
     *
     * 登録最大数.<br>
     *<br>
     * 概要:<br>
     *   最大登録数のクラスです
     *<br>
     */
    public abstract class SAVE_UPPER_LIMIT {

        /**
         * データポイント登録初期値.
         */
        public static final int DATAPOINT_NUM_DEFAULT = 100;
    }

    /**
     *
     * 稼動状態管理方法.<br>
     *<br>
     * 概要:<br>
     *   稼動状態管理方法の定義
     *<br>
     */
    public abstract class MANAGEMENT_TYPE {
        /**
         * 1:手動で管理する.
         */
        public static final String MANUAL = "1";

        /**
         * 2:データポイント値に連動.
         */
        public static final String DATA_POINT = "2";

        /**
         * 3:通信状態連動.
         */
        public static final String COMMUNICATION_STATE = "3";

    }

    /**
     *
     * 稼動状態区分.<br>
     * <br>
     * 概要:<br>
     * 稼動状態区分の定義 <br>
     */
    public abstract class OPERATION_KIND {
        /**
         * 1:稼動状態.
         */
        public static final String RUN = "1";

        /**
         * 0:停止状態.
         */
        public static final String STOP = "0";
    }

    /**
     *
     * 稼働状態項目のデフォルト設定.<br>
     * <br>
     * 概要:<br>
     * デフォルトで使用する稼働状態項目のデフォルト設定定義 <br>
     */
    public enum OperationStatusDefaultSetting {

        /**
         * 停止中.
         */
        Stop(OPERATION_STATUS.STOP, "1", OPERATION_KIND.STOP),

        /**
         * 稼働中.
         */
        Run(OPERATION_STATUS.RUN, "2", OPERATION_KIND.RUN),

        /**
         * メンテナンス中.
         */
        Maintenance(OPERATION_STATUS.MAINTENANCE, "3", OPERATION_KIND.STOP),

        /**
         * 出荷待ち.
         */
        Standby(OPERATION_STATUS.STANDBY, "4", OPERATION_KIND.STOP);

        /**
         * 稼働状態項目定数.
         */
        public final String operationStatus;

        /**
         * 環境マスタの項目コード(環境CD：disp_color_cd).
         */
        public final String colorItemCd;

        /**
         * 稼動状態区分.
         */
        public final String operationKind;

        /**
         *
         * コンストラクタ.
         *
         * @param _operationStatus 稼働状態項目定数
         * @param _colorItemCd 環境マスタの項目コード(環境CD：disp_color_cd)
         * @param _operationKind 稼動状態区分
         */
        private OperationStatusDefaultSetting(final String _operationStatus, final String _colorItemCd, final String _operationKind) {
            this.operationStatus = _operationStatus;
            this.colorItemCd = _colorItemCd;
            this.operationKind = _operationKind;
        }

        /**
         *
         * 該当enumを取得.<br>
         *<br>
         * 概要:<br>
         *   指定した稼働状態項目定数に該当するenumを取得する
         *<br>
         * @param _operationStatus 稼働状態項目定数
         * @return String 項目コード
         */
        public static OperationStatusDefaultSetting getEnum(final String _operationStatus) {
            OperationStatusDefaultSetting ret = Run;

            for (OperationStatusDefaultSetting defaultSetting : OperationStatusDefaultSetting.values()) {
                if (defaultSetting.operationStatus.equals(_operationStatus)) {
                    ret = defaultSetting;
                    break;
                }
            }

            return ret;
        }

        /**
         *
         * 環境マスタの項目コード取得.<br>
         *<br>
         * 概要:<br>
         *   環境マスタの項目コードを取得
         *<br>
         * @return 項目コード
         */
        public String getColorItemCd() {
            return this.colorItemCd;
        }

        /**
         *
         * 稼動状態区分.<br>
         *<br>
         * 概要:<br>
         *   稼動状態区分を取得
         *<br>
         * @return 稼動状態区分
         */
        public String getOperationKind() {
            return this.operationKind;
        }

    }

    /**
     * 稼動状態設定最大設定値の項目CD.
     */
    public abstract class STATUS_SETTING_ITEM_CD {
        /**
         * 10件.
         */
        public static final String TEM = "10";
    }

    /**
     * 稼動状態設定条件最大設定値の項目CD.
     */
    public abstract class STATUS_CONDITION_ITEM_CD {
        /**
         * 3件.
         */
        public static final String THREE = "3";
    }

    /**
     *
     * 登録最大数.<br>
     *<br>
     * 概要:<br>
     *   最大登録数のクラスです
     *<br>
     */
    public abstract class DEVICE_DATETIME_TYPE {

        /**
         * 最終通信日時.
         */
        public static final int LAST_TELECOM = 1;
    }

    /**
     *
     * 配信状況種別.<br>
     * <br>
     * 概要:<br>
     * 配信状況種別の定義 <br>
     */
    public abstract class DISTRIBUTE_STATUS_KIND {
        /**
         * 配信データ情報画面操作系(0x)
         */

        /**
         * 00:新規作成.
         */
        public static final String INSERT = "00";

        /**
         * 01:更新.
         */
        public static final String UPDATE = "01";

        /**
         * 02:削除.
         */
        public static final String DELETE = "02";

        /**
         * 配信状況一覧画面操作系(1x)
         */

        /**
         * 10:配信設定.
         */
        public static final String SETTING = "10";

        /**
         * 11:配信取消.
         */
        public static final String CANCEL = "11";

        /**
         * 通信プロセス系(2x)
         */

        /**
         * 20:バージョン確認.
         */
        public static final String CHECK = "20";

        /**
         * 21:期限切れ削除.
         */
        public static final String LIMIT = "21";
    }

    /**
     *
     * ファイルサイズ単位.<br>
     * <br>
     * 概要:<br>
     * ファイルサイズ単位の定義 <br>
     */
    public abstract class FILE_SIZE_UNIT {
        /**
         * Byte.
         */
        public static final String BYTE = "Byte";

        /**
         * KByte.
         */
        public static final String KBYTE = "K";

        /**
         * MByte.
         */
        public static final String MBYTE = "M";

        /**
         * GByte.
         */
        public static final String GBYTE = "G";

    }

    /**
    *
    * 画面ID.<br>
    *<br>
    * 概要:<br>
    * 表示／非表示される画面<br>
    *
    *<br>
    */
    public enum PageInfo {

           /**
            * 画面ID：メニュー構成.
            */
            PAGE_ID_MENU_CONSTITUTION("C18-0010", "c180010MenuConstitution", true, true, true, true, true, true, true),

           /**
            * 画面ID：ユーザ一覧.
            */
            PAGE_ID_USER_LIST("C18-0020", "c180020UserList", true, true, true, true, true, true, true),

           /**
            * 画面ID：拠点設定.
            */
            PAGE_ID_PRODUCTION_BASE_SETTING("C18-0030", "c180030ProductionBaseSetting", true, true, true, true, true, true, true),

           /**
            * 画面ID：製造ライン設定.
            */
            PAGE_ID_MANUFACTURING_LINE_SETTING("C18-0040", "c180040ManufacturingLineSetting", true, true, true, true, true, true, true),

           /**
            * 画面ID：計画数設定.
            */
            PAGE_ID_PLAN_NUMBER_SETTING("C18-0050", "c180050PlanNumberSetting", true, true, true, true, true, true, true),

           /**
            * 画面ID：ユーザ設定.
            */
            PAGE_ID_USER_INFO("C18-0060", "c180060UserInfo", true, true, true, true, true, true, true),

           /**
            * 画面ID：ラインレイアウト設定.
            */
            PAGE_ID_LINE_LAYOUT_SETTING("C18-0070", "c180070LineLayoutSetting", true, true, true, true, true, true, true);

        /**
         * 画面ID.
         */
        public String pageId;

        /**
         * 画面名.
         */
        public String pageName;

        /**
         * システム管理者（グループ:SYS0)での表示可能フラグ.
         */
        public boolean enableSysAdim;

        /**
         * システム管理者（グループ：SYS0以外)での表示可能フラグ.
         */
        public boolean enableSysGroupAdmin;

        /**
         * ユーザでの表示可能フラグ.
         */
        public boolean enableUser;

        /**
         * 情報システムでの表示可能フラグ.
         */
        public boolean enableInfoAdmin;

        /**
         * 生産技術での表示可能フラグ.
         */
        public boolean enableProductionEngineeringAuth;

        /**
         * 業務での表示可能フラグ.
         */
        public boolean enableGyomuAuth;

        /**
         * 製造管理者での表示可能フラグ.
         */
        public boolean enableManufacturingAuth;

        /**
         * 製造作業者での表示可能フラグ.
         */
        public boolean enableWorkerAuth;

        /**
        *
        * コンストラクタ.
        *
        * @param _pageId 画面ID
        * @param _pageName 画面名称
        * @param _enableSysAdim システム管理者（グループ:SYS0)での表示可能フラグ
        * @param _enableSysGroupAdmin システム管理者（グループ:SYS0以外)での表示可能フラグ
        * @param _enableUser ユーザでの表示可能フラグ
        */
       private PageInfo(final String _pageId, final String _pageName, final boolean _enableSysAdim, final boolean _enableInfoAdmin, final boolean _enableProductionEngineeringAuth, final boolean _enableGyomuAuth, final boolean _enableManufacturingAuth, final boolean _enableUserAuth, final boolean _enableWorkerAuth) {
           this.pageId = _pageId;
           this.pageName = _pageName;
           this.enableSysAdim = _enableSysAdim;
           this.enableInfoAdmin = _enableInfoAdmin;
           this.enableProductionEngineeringAuth = _enableProductionEngineeringAuth;
           this.enableGyomuAuth = _enableGyomuAuth;
           this.enableManufacturingAuth = _enableManufacturingAuth;
           this.enableUser = _enableUserAuth;
           this.enableWorkerAuth = _enableWorkerAuth;
       }

        /**
         * 画面ID取得.
         *
         * @return pageId 画面ID
         */
        public String getPageId() {
            return this.pageId;
        }

        /**
         * 画面名取得.
         *
         * @return pageName 画面名
         */
        public String getPageName() {
            return this.pageName;
        }

        /**
         * システム管理者（グループ:SYS0)での表示可能かどうかを取得.
         *
         * @return enableSysAdim システム管理者（グループ:SYS0)での表示可能かどうか
         */
        public boolean isEnableSysAdim() {
            return this.enableSysAdim;
        }

        /**
         * 情報システムでの表示可能かどうかを取得.
         *
         * @return enableInfoAdmin 情報システムでの表示可能かどうか
         */
        public boolean isEnableInfoAdim() {
            return this.enableInfoAdmin;
        }

        /**
         * システム管理者（グループ:SYS0以外)での表示可能かどうかを取得.
         *
         * @return enableSysGroupAdmin システム管理者（グループ:SYS0)での表示可能かどうか
         */
        public boolean isEnableSysGroupAdmin() {
            return this.enableSysGroupAdmin;
        }

        /**
         * 生産技術での表示可能かどうかを取得.
         *
         * @return enableProductionEngineeringAuth 生産技術での表示可能かどうか
         */
        public boolean isEnableProductionEngineeringAuth() {
            return this.enableProductionEngineeringAuth;
        }

        /**
         * 業務での表示可能かどうかを取得.
         *
         * @return enableGyomuAuth 業務での表示可能かどうか
         */
        public boolean isEnableGyomuAuth() {
            return this.enableGyomuAuth;
        }

        /**
         * 製造管理者での表示可能かどうかを取得.
         *
         * @return enableManufacturingAuth 製造管理者での表示可能かどうか
         */
        public boolean isEnableManufacturingAuth() {
            return this.enableManufacturingAuth;
        }

        /**
         * ユーザでの表示可能かどうかを取得.
         *
         * @return enableUser ユーザでの表示可能かどうか
         */
        public boolean isEnableUser() {
            return this.enableUser;
        }

        /**
         * 製造作業者での表示可能かどうかを取得.
         *
         * @return enableWorkerAuth 製造作業者での表示可能かどうか
         */
        public boolean isEnableWorkerAuth() {
            return this.enableWorkerAuth;
        }

        /**
         *
         * 画面IDをを元に画面情報取得.<br>
         *<br>
         * 概要:<br>
         *   画面IDをを元に画面情報取得処理
         *<br>
         * @param _pageId 画面ID
         * @return 画面情報
         */
        public static PageInfo getPageInfo(final String _pageId) {
            PageInfo ret = null;

            for (PageInfo pageInfo : PageInfo.values()) {
                if (pageInfo.getPageId().equals(_pageId)) {
                    return pageInfo;
                }
            }

            return ret;
        }

        /**
         *
         * ユーザ権限がユーザの場合に表示できない画面一覧を取得.<br>
         *<br>
         * 概要:<br>
         *   ユーザ権限がユーザの場合に表示できない画面一覧を取得
         *<br>
         * @return ユーザ権限がユーザの場合に表示できない画面ID一覧
         */
        public static List<String> getDisableUserList() {
            List<String> ret = new ArrayList<String>();

            for (CM_A04_Const.PageInfo pageInfo : CM_A04_Const.PageInfo.values()) {
                if (!pageInfo.isEnableUser()) {
                    ret.add(pageInfo.pageId);
                }
            }
            return ret;
        }

        /**
         *
         * ユーザ権限がシステム管理者の場合に表示できない画面一覧を取得.<br>
         *<br>
         * 概要:<br>
         *   ユーザ権限がシステム管理者の場合に表示できない画面一覧を取得
         *<br>
         * @return ユーザ権限がシステム管理者の場合に表示できない画面ID一覧
         */
        public static List<String> getDisableSysAdminList() {
            List<String> ret = new ArrayList<String>();

            for (CM_A04_Const.PageInfo pageInfo : CM_A04_Const.PageInfo.values()) {
                if (!pageInfo.isEnableSysAdim()) {
                    ret.add(pageInfo.pageId);
                }
            }
            return ret;
        }

        /**
        *
        * ユーザ権限が情報システムの場合に表示できない画面一覧を取得.<br>
        *<br>
        * 概要:<br>
        *   ユーザ権限が情報システムの場合に表示できない画面一覧を取得
        *<br>
        * @return ユーザ権限が情報システムの場合に表示できない画面ID一覧
        */
        public static List<String> getDisableInfoAdminList() {
            List<String> ret = new ArrayList<String>();

            for (CM_A04_Const.PageInfo pageInfo : CM_A04_Const.PageInfo.values()) {
                if (!pageInfo.isEnableInfoAdim()) {
                    ret.add(pageInfo.pageId);
                }
            }
            return ret;
        }

        /**
        *
        * ユーザ権限が生産技術の場合に表示できない画面一覧を取得.<br>
        *<br>
        * 概要:<br>
        *   ユーザ権限が生産技術の場合に表示できない画面一覧を取得
        *<br>
        * @return ユーザ権限が生産技術の場合に表示できない画面ID一覧
        */
        public static List<String> getDisableProductionEngineeringList() {
            List<String> ret = new ArrayList<String>();

            for (CM_A04_Const.PageInfo pageInfo : CM_A04_Const.PageInfo.values()) {
                if (!pageInfo.isEnableProductionEngineeringAuth()) {
                    ret.add(pageInfo.pageId);
                }
            }
            return ret;
        }

        /**
        *
        * ユーザ権限が業務の場合に表示できない画面一覧を取得.<br>
        *<br>
        * 概要:<br>
        *   ユーザ権限が業務の場合に表示できない画面一覧を取得
        *<br>
        * @return ユーザ権限が業務の場合に表示できない画面ID一覧
        */
        public static List<String> getDisableGyoumuAuthList() {
            List<String> ret = new ArrayList<String>();

            for (CM_A04_Const.PageInfo pageInfo : CM_A04_Const.PageInfo.values()) {
                if (!pageInfo.isEnableGyomuAuth()) {
                    ret.add(pageInfo.pageId);
                }
            }
            return ret;
        }

        /**
        *
        * ユーザ権限が製造管理者の場合に表示できない画面一覧を取得.<br>
        *<br>
        * 概要:<br>
        *   ユーザ権限が製造管理者の場合に表示できない画面一覧を取得
        *<br>
        * @return ユーザ権限が製造管理者の場合に表示できない画面ID一覧
        */
        public static List<String> getDisableManufacturingList() {
            List<String> ret = new ArrayList<String>();

            for (CM_A04_Const.PageInfo pageInfo : CM_A04_Const.PageInfo.values()) {
                if (!pageInfo.isEnableManufacturingAuth()) {
                    ret.add(pageInfo.pageId);
                }
            }
            return ret;
        }

        /**
        *
        * ユーザ権限が製造作業者の場合に表示できない画面一覧を取得.<br>
        *<br>
        * 概要:<br>
        *   ユーザ権限が製造作業者の場合に表示できない画面一覧を取得
        *<br>
        * @return ユーザ権限が製造作業者の場合に表示できない画面ID一覧
        */
        public static List<String> getDisableWorkerList() {
            List<String> ret = new ArrayList<String>();

            for (CM_A04_Const.PageInfo pageInfo : CM_A04_Const.PageInfo.values()) {
                if (!pageInfo.isEnableWorkerAuth()) {
                    ret.add(pageInfo.pageId);
                }
            }
            return ret;
        }
    }

    /**
    *
    * ユーザ権限が情報システムの場合に表示できない画面一覧を取得.<br>
    *<br>
    * 概要:<br>
    *   ユーザ権限が情報システムの場合に表示できない画面一覧を取得
    *<br>
    * @return ユーザ権限が情報システムの場合に表示できない画面ID一覧
    */
    public static List<String> getDisableSysGroupAdminList() {
        List<String> ret = new ArrayList<String>();

        for (CM_A04_Const.PageInfo pageInfo : CM_A04_Const.PageInfo.values()) {
            if (!pageInfo.isEnableSysGroupAdmin()) {
                ret.add(pageInfo.pageId);
            }
        }
        return ret;
    }


    /**
     * 共通SQLパラメータ.
     */
    public abstract class SQL_PARAM {
        /**
         * ログインユーザSID用文字列.
         */
        public static final String LOGIN_USER_SID = "LoginUserSid";
        /**
         * 所属グループ有無フラグ用文字列.
         */
        public static final String HAS_GROUP = "hasGroup";

        /**
         * グループの制御をするかフラグ用文字列.
         */
        public static final String GROUP_LIMIT = "isGroupLimit";

        /**
         * 削除フラグ使用可否.
         */
        public static final String ENABLE_DELETE_FLG = "enableDeleteFlg";

        /**
         * ログインユーザ言語コード.
         */
        public static final String LOGIN_USER_LANG_CD = "loginUserLangCd";

        /**
         * 計測日時かどうかのフラグ用文字列.
         */
        public static final String MEASURE_DATETIME = "isMeasureDatetime";

        /** ログインユーザ工場コード用文字列. */
        public static final String PLANT_CODE = "plant_code";

        /** 製造ライン（グループ）用文字列. */
        public static final String SEIZOU_LN_ID = "seizou_ln_id";

        /** 工程用文字列. */
        public static final String PROCESS_ID = "process_id";

        /** 品目コード用文字列. */
        public static final String BUHIN_CD = "buhin_cd";

        /** 機種群名用文字列. */
        public static final String KISHUGUN_NAME = "kishugun_name";

        /** シリーズ用文字列. */
        public static final String SERIES_NAME = "series_name";

        /** 作業区用文字列. */
        public static final String SAGYOKU = "sagyoku";

        /** ラインID用文字列. */
        public static final String LN_ID = "ln_id";

        /** 完成日(From)用文字例. */
        public static final String CON_DATA_DATE_FROM = "condDataDateFrom";

        /** 完成日(To)用文字例. */
        public static final String CON_DATA_DATE_TO = "condDataDateTo";

        /**
         * 検索日時をずらす秒数(SQLパラメータ).
         */
        public static final String PARAM_SEARCH_DATE_SHIFT_TIME = "searchDateShiftTime";

        /**
         * ユーザタイムゾーン.
         */
        public static final String PARAM_USER_TIMEZONE = "userTimezone";

        /** 製品ID. */
        public static final String PARAM_PRODUCT_ID = "productId";

    }

    /**
     * エラーページ.
     */
    public abstract class ERROR_PAGE {
        /**
         * 404.
         */
        public static final String ERROR_PAGE_404 = "/FW01_20_Error_404.jsp";

    }

    /**
     * 検索結果上限値の項目CD.
     */
    public abstract class SEARCH_RESULT_ITEM_CD {
        /**
         * 10件.
         */
        public static final String SEARCH_RESULT_MAX_ITEM_CD = "10000";
    }

    /**
     * 集計方法.
     */
    public abstract class COUNT_METHOD {
        /**
         * {平均}.
         */
        public static final String AVERAGE = "1";
        /**
         * {最大}.
         */
        public static final String MAXIMUM = "2";
        /**
         * {最小}.
         */
        public static final String MINIMUM = "3";
        /**
         * {合計}.
         */
        public static final String TOTAL = "4";
        /**
         * {最新瞬時}.
         */
        public static final String LATEST_INSTANT = "5";

    }

    /**
     * 集計方法.
     */
    public enum SUMMARY_METHOD {

        /**
         * {平均}.
         */
        AVERAGE("1", "avg"),
        /**
         * {最大}.
         */
        MAXIMUM("2", "max"),
        /**
         * {最小}.
         */
        MINIMUM("3", "min"),
        /**
         * {合計}.
         */
        TOTAL("4", "sum"),
        /**
         * {最新瞬時}.
         */
        LATEST_INSTANT("5", "new");

        /**
         * 項目CD.
         */
        private String itemCd;

        /**
         * 集計方法名.
         */
        private String summaryName;

        /**
         * コンストラクタ.
         *
         * @param _itemCd 項目CD
         * @param _summaryName 集計方法名
         */
        SUMMARY_METHOD(final String _itemCd, final String _summaryName) {
            this.itemCd = _itemCd;
            this.summaryName = _summaryName;
        }

        /**
         * @return itemCd
         */
        public String getItemCd() {
            return this.itemCd;
        }

        /**
         * @return summaryName
         */
        public String getSummaryName() {
            return this.summaryName;
        }

        /**
         * 集計方法名を取得.
         *
         * @param _itemCd 名称マスタの項目CD
         * @return 集計方法名
         */
        public static String getSummaryName(final String _itemCd) {
            String ret = FW00_19_Const.EMPTY_STR;
            for (SUMMARY_METHOD e : SUMMARY_METHOD.values()) {
                if (e.getItemCd().equals(_itemCd)) {
                    ret = e.getSummaryName();
                    break;
                }
            }
            return ret;
        }
    }

    /**
     * グラフ種別.
     */
    public abstract class GRAPH_KIND {
        /**
         * {折れ線}.
         */
        public static final String POLYGONAL_LINE = "1";
        /**
         * {棒}.
         */
        public static final String HISTOGRAM = "2";

    }

    /**
     * グラフ種別.
     */
    public enum SUMMARY_GRAPH {
        /**
         * 折れ線.
         */
        POLYGON("1", "polygon"),
        /**
         * 棒.
         */
        HISTOGRAM("2", "bar");

        /**
         * 項目CD.
         */
        private String itemCd;

        /**
         * グラフ種別.
         */
        private String graphKind;

        SUMMARY_GRAPH(final String _itemCd, final String _graphKind) {
            this.itemCd = _itemCd;
            this.graphKind = _graphKind;
        }

        /**
         * @return itemCd
         */
        public String getItemCd() {
            return this.itemCd;
        }

        /**
         * @return graphKind
         */
        public String getGraphKind() {
            return this.graphKind;
        }

        /**
         * グラフ種別取得.
         *
         * @param _itemCd 項目CD
         * @return グラフ種別
         */
        public static String getGtaphKind(final String _itemCd) {
            String ret = FW00_19_Const.EMPTY_STR;
            for (SUMMARY_GRAPH e : SUMMARY_GRAPH.values()) {
                if (e.getItemCd().equals(_itemCd)) {
                    ret = e.getGraphKind();
                    break;
                }
            }
            return ret;
        }
    }

    /**
     * 進数.
     */
    public abstract class RADIX {
        /**
         * {2進数}.
         */
        public static final int BASE2 = 2;

        /**
         * {8進数}.
         */
        public static final int BASE8 = 8;
        /**
         * {10進数}.
         */
        public static final int BASE10 = 10;
        /**
         * {16進数}.
         */
        public static final int BASE16 = 16;

    }

    /**
     * 0詰め用.
     */
    public static final String ZERO_STR = "0";

    /**
     * グループ階層のシステム階層数.
     */
    public static final int GROUP_TREE_SYS_NUM = 2;

    /**
     * グループ最大階層数.
     */
    public static final int GROUP_TREE_MAX_NUM = 6;


    /**
     *
     * 演算式定数.<br>
     *<br>
     * 概要:<br>
     *   演算式の定数クラスです
     *<br>
    */
    public abstract class OPERATIONAL_CHARACTER {
        /**
         * 加算.
         */
        public static final char PLUS = '+';

        /**
         * 減算.
         */
        public static final char MINUS = '-';

        /**
         * 乗算.
         */
        public static final char MULTIPLY = '*';

        /**
         * 除算.
         */
        public static final char DIVIDE = '/';

        /**
         * 左括弧.
         */
        public static final char BRACKETS_LEFT = '(';

        /**
         * 右括弧.
         */
        public static final char BRACKETS_RIGHT = ')';

        /**
         * 文字列連結子.
         */
        public static final char STR_CONTACT = '&';

        /**
         * 引用符.
         */
        public static final String QUOTE = "\"";

        /**
         * bit型の合演算.
         */
        public static final String AND = "AND";

        /**
         * ダブルクォーテーション(char型).
         */
        public static final char DOUBLE_QUOTATION_CHAR = '\"';
    }

    /**
     * 演算子.
     */
    public static final char[] OPERATOR = new char[]{
        OPERATIONAL_CHARACTER.PLUS,
        OPERATIONAL_CHARACTER.MINUS,
        OPERATIONAL_CHARACTER.MULTIPLY,
        OPERATIONAL_CHARACTER.DIVIDE,
        OPERATIONAL_CHARACTER.BRACKETS_LEFT,
        OPERATIONAL_CHARACTER.BRACKETS_RIGHT,
    };

    /**
     * インデックス.
     */
    public static class INDEX {
        /**
         * 0.
         */
        public static final int INDEX_0 = 0;
        /**
         * 1.
         */
        public static final int INDEX_1 = 1;
        /**
         * 2.
         */
        public static final int INDEX_2 = 2;
        /**
         * 3.
         */
        public static final int INDEX_3 = 3;
        /**
         * 4.
         */
        public static final int INDEX_4 = 4;
        /**
         * 5.
         */
        public static final int INDEX_5 = 5;
        /**
         * 6.
         */
        public static final int INDEX_6 = 6;
        /**
         * 7.
         */
        public static final int INDEX_7 = 7;
        /**
         * 8.
         */
        public static final int INDEX_8 = 8;
        /**
         * 9.
         */
        public static final int INDEX_9 = 9;
        /**
         * 10.
         */
        public static final int INDEX_10 = 10;
        /**
         * 11.
         */
        public static final int INDEX_11 = 11;
        /**
         * 12.
         */
        public static final int INDEX_12 = 12;
        /**
         * 13.
         */
        public static final int INDEX_13 = 13;
        /**
         * 14.
         */
        public static final int INDEX_14 = 14;
    }

    /**
     *
     * フラグ定数.<br>
     * <br>
     * 概要:<br>
     * フラグの定数クラスです <br>
     */
    public abstract class CSV_RESULT {
        /**
         * SUCCESS : 1.
         */
        public static final int SUCCESS = 1;
        /**
         * FAILED : 0.
         */
        public static final int FAILED = 0;

        /**
         * OPERATION_EMPTY : 2.
         */
        public static final int OPERATION_EMPTY = 2;

        /**
         * WARNING：3.
         */
        public static final int WARNING = 3;
    }

    /**
     * 稼働状態の間隔[分].
     */
    public static final int OPERATION_STATUS_SPAN = 10;

    /**
     * ユーザメールアドレス登録可能件数.
     */
    public static final int MAX_ADD_MAIL_ADDRESS = 10;

    /**
     * バージョンファイル名の分割子.
     */
    public static final String SPLIT_STR_VERSION_FILE = "#sprt#";

    /**
     * バージョンファイルの拡張子.
     */
    public static final String EXTENSION_VERSION_FILE = ".txt";

    /**
     * デフォルト名称.
     */
    public static final String DEFAULT_NAME = "none";

    // TODO 将来拡張予定
    /**
     * BigDecimalの丸め桁数.
     */
    public static final int ROUND_NUM = 5;

    /**
     * SYS0(system rootのグループID).
     */
    public static final String GROUP_SYS_ROOT_0 = "SYS0";

    /**
     * SYS1(groupのグループID).
     */
    public static final String GROUP_SYS_ROOT_1 = "SYS1";

    /**
     * root(rootのグループID).
     */
    public static final String GROUP_ROOT = "0000";

    /**
     * 禁則文字(\).
     */
    public static final String[] DEFAULT_FORBID_CHAR = {FW00_19_Const.BACK_SLASH_STR};

    /**
     * ソケット接続・切断リトライ回数上限.
     */
    public static final int SOCKET_RETRY_LIMIT = 3;

    /**
     * 接続タイムアウト時間(milliseconds).
     */
    public static final int CONNECT_TIMEOUT = 10000;

    /**
     * WebAPI接続タイムアウト時間(milliseconds).
     */
    public static final int CONNECT_TIMEOUT_WEBAPI = 10000;

    /**
     * WebAPIソケットタイムアウト時間(milliseconds).
     */
    public static final int SOCKET_TIMEOUT_WEBAPI = 10000;

    /**
     * 応答タイムアウト時間(milliseconds).
     */
    public static final int RESPONSE_TIMEOUT = 10000;

    /**
     *
     * SIMタイプ種別判断パターン定義.<br>
     * <br>
     * 概要:<br>
     * SIMタイプの種別判断に使用する定義です <br>
     */
    public enum SIM_TYPE_PATTERN {
        /** 接続不可のSIMタイプ（コードの最後が'0'）. */
        UNCONNECTABLE(Pattern.compile(".*0$")),
        /** ショートメール(API)を使用するSIMタイプ（コードの最後が'11'）. */
        SMS_API(Pattern.compile(".*11$"));

        /**
         * 比較パターン.
         */
        Pattern pattern = null;

        /**
         * コンストラクタ.
         * @param _pattern 比較パターン
         */
        private SIM_TYPE_PATTERN(final Pattern _pattern) {
            this.pattern = _pattern;
        }

        /**
         * 一致判断.
         * @param _simType SIMタイプ
         * @return 結果
         */
        public boolean isMatch(final String _simType) {
            if (CM_CommonUtil.isNullOrBlank(_simType)) {
                return false;
            }
            Matcher m = this.pattern.matcher(_simType);
            return m.find();
        }
    }

    /**
     *
     * 禁則文字.<br>
     * <br>
     * 概要:<br>
     * 禁則文字クラスです <br>
     */
    public abstract static class FORBID_STR {

        /**
         * 禁則文字（基底）.
         */
        public static final String[] BASE_FORBID_STR = new String[]{
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.DOUBLE_QUOTATION_STR,
        };

        /**
         * 禁則文字(名称用).
         */
        public static final String[] NAME = new String[]{
            FW00_19_Const.COMMA_STR,
            FW00_19_Const.SEMICOLON_STR,
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.DOUBLE_QUOTATION_STR,
        };

        /**
         * 禁則文字(ユーザID用).
         */
        public static final String[] USER_ID = new String[]{
            FW00_19_Const.COMMA_STR,
            FW00_19_Const.SEMICOLON_STR,
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.DOUBLE_QUOTATION_STR,
        };

        /**
         * 禁則文字.
         */
        public static final String[] MODEL = new String[]{
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.DOUBLE_QUOTATION_STR,
        };

        /**
         * 禁則文字(機器名称、機器バージョン、機器シリアルNo.用).
         */
        public static final String[] DEVICE = new String[]{
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.DOUBLE_QUOTATION_STR,
        };

        /**
         * 禁則文字(機器ID用).
         */
        public static final String[] DEVICE_ID = new String[]{
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.SLASH_STR,
            FW00_19_Const.COLON_STR,
            FW00_19_Const.ASTERISK_STR,
            FW00_19_Const.QUESTION_STR,
            FW00_19_Const.LEFT_ANGLE_BRACKET_STR,
            FW00_19_Const.RIGHT_ANGLE_BRACKET_STR,
            FW00_19_Const.VERTICAL_BAR_STR,
        };

        /**
         * 禁則文字(機器付帯情報用).
         */
        public static final String[] DEVICE_SUBINFO = new String[]{
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.DOUBLE_QUOTATION_STR,
        };

        /**
         * 禁則文字(アドレス名称用).
         */
        public static final String[] ADDRESS_NAME = new String[]{
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.DOUBLE_QUOTATION_STR,
            FW00_19_Const.SLASH_STR,
        };

        /**
         * 禁則文字(グループ名称用).
         */
        public static final String[] GROUP_NAME = new String[]{
            FW00_19_Const.COMMA_STR,
            FW00_19_Const.SEMICOLON_STR,
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.DOUBLE_QUOTATION_STR,
            FW00_19_Const.DOT_STR,
            FW00_19_Const.HYPHEN_STR,
        };

        /**
         * 禁則文字(トレンドビュー名称用).
         */
        public static final String[] TREND_VIEW_NAME = new String[]{
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.DOUBLE_QUOTATION_STR,
            FW00_19_Const.SLASH_STR,
            FW00_19_Const.COMMA_FULL_STR,
            FW00_19_Const.QUESTION_STR,
            FW00_19_Const.ASTERISK_STR,
            FW00_19_Const.LEFT_ANGLE_BRACKET_STR,
            FW00_19_Const.RIGHT_ANGLE_BRACKET_STR,
            FW00_19_Const.VERTICAL_BAR_STR,

        };

        /**
         * 禁則文字(イベント変換名称用).
         */
        public static final String[] EVENT_CHANGE_NAME = new String[]{
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.DOUBLE_QUOTATION_STR,
            FW00_19_Const.COMMA_STR,
            FW00_19_Const.SEMICOLON_STR,
        };

        /**
         * 禁則文字(イベント変換ルール用).
         */
        public static final String[] EVENT_CHANGE_CONDITION = new String[]{
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.COMMA_STR,
            FW00_19_Const.SEMICOLON_STR,
        };

        /**
         * 禁則文字(ファイル名称用).
         */
        public static final String[] FTP_FILE_NAME_CONDITION = new String[]{
            FW00_19_Const.ASTERISK_STR,
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.COLON_STR,
            FW00_19_Const.QUESTION_STR,
            FW00_19_Const.SLASH_STR,
            FW00_19_Const.LEFT_ANGLE_BRACKET_STR,
            FW00_19_Const.RIGHT_ANGLE_BRACKET_STR,
            FW00_19_Const.VERTICAL_BAR_STR,
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "a",
            "b",
            "c",
            "d",
            "e",
            "f",
        };

        /**
         * 禁則文字(XPath用).
         */
        public static final String[] XPATH = new String[]{
            FW00_19_Const.COMMA_STR,
            FW00_19_Const.SEMICOLON_STR,
            FW00_19_Const.SPACE,
            FW00_19_Const.BACK_SLASH_STR,
            FW00_19_Const.DOUBLE_QUOTATION_STR,
        };

        /**
         * 禁則文字(受信フォーマット用).
         */
        public static final String[] RECEIVE_FORMAT = new String[]{
            FW00_19_Const.COMMA_STR,
            FW00_19_Const.SEMICOLON_STR,
            FW00_19_Const.BACK_SLASH_STR,
        };

        /**
         * 禁則文字(演算式用).
         */
        public static final String[] CALC_FORMULA = new String[]{
            FW00_19_Const.SEMICOLON_STR,
            FW00_19_Const.BACK_SLASH_STR,
        };
    }

    /**
     *
     * 公開区分.<br>
     * <br>
     * 概要:<br>
     * 公開区分クラスです <br>
     */
    public abstract class PUBLICTYPE {
        /**
         * 0：全ユーザ.
         */
        public static final String ALL = "0";

        /**
         * 1：グループ指定.
         */
        public static final String SELECT = "1";
    }

    /**
     *
     * 受信種別.<br>
     * <br>
     * 概要:<br>
     * 受信種別クラスです <br>
     */
    public abstract class RECEIVETYPE {
        /**s
         * 1：最終通信日時.
         */
        public static final int FINALCONNECT = 1;

        /**
         * 2：アラーム発生日時.
         */
        public static final int ALARM = 2;
    }

    /**
     *
     * グループ区分定数.<br>
     *<br>
     * 概要:<br>
     *   グループ区分を表す定数クラス
     *<br>
     */
    public enum GroupType {
        /**
         * ルートグループ.
         */
        ROOT_GROUP("1", false),

        /**
         * 担当グループ指定.
         */
        SET_GROUP("2", true);

        /**
         * 名称マスタの項目CD（名称種別：user_group_type）.
         */
        public final String itemCd;

        /**
         * グループ有無フラグ.
         */
        public final boolean hasGroup;

        /**
         *
         * コンストラクタ.
         *
         * @param _itemCd 項目CD
         * @param _hasGroup グループ有無フラグ
         */
        private GroupType(final String _itemCd, final boolean _hasGroup) {
            this.itemCd = _itemCd;
            this.hasGroup = _hasGroup;
        }

        /**
         *
         * 項目CD取得.<br>
         *<br>
         * 概要:<br>
         *   指定したグループ有無フラグに該当する項目CDを取得する
         *<br>
         * @param _hasGroup グループ有無フラグ
         * @return 項目CD
         */
        public static String getItemCd(final boolean _hasGroup) {
            String ret = FW00_19_Const.EMPTY_STR;

            for (GroupType groupType : GroupType.values()) {
                // グループ有無フラグが引数と一致する場合、項目CDを取得する
                if (groupType.hasGroup == _hasGroup) {
                    ret = groupType.itemCd;
                    break;
                }
            }

            return ret;
        }

        /**
         * @return itemCd 名称マスタの項目CD
         */
        public final String getItemCd() {
            return this.itemCd;
        }

        /**
         * @return hasGroup グループ有無フラグ
         */
        public final boolean isHasGroup() {
            return this.hasGroup;
        }
    }

    /**
     * アイコンタイプ-アラームLv関連定数.<br>
     *<br>
     * 概要:<br>
     *   アイコンタイプとアラームLvの対応定義
     */
    public static enum AlarmIcon {
        /**
         * アラームなし.
         */
        NO_ALARM("1", "0"),

        /**
         * アラーム低.
         */
        ALARM_LOW("2", "1"),

        /**
         * アラーム中.
         */
       ALARM_MID("3", "2"),

        /**
         * アラーム高.
         */
        ALARM_HIGH("4", "3"),

        /**
         * アラーム重大.
         */
        ALARM_CRITICAL("5", "4");

        /**
         * アイコンタイプ.
         */
        public final String iconType;

        /**
         * アラームLv.
         */
        public final String alarmLv;

        /**
         * コンストラクタ.
         *
         * @param _iconType アイコンタイプ
         * @param _alarmLv アラームLv
         */
        private AlarmIcon(final String _iconType, final String _alarmLv) {
            this.iconType = _iconType;
            this.alarmLv = _alarmLv;
        }

        /**
         *
         * アイコンタイプを取得.<br>
         *<br>
         * 概要:<br>
         *   アラームLvに該当するアイコンタイプを取得する
         *<br>
         * @param _alarmLv アラームLv
         * @return アイコンタイプ
         */
        public static String getIconType(final String _alarmLv) {
            // 返却値を初期化
            String ret = FW00_19_Const.EMPTY_STR;

            if (CM_CommonUtil.isNullOrBlank(_alarmLv)) {
                return NO_ALARM.iconType;
            }

            for (AlarmIcon alarmIcon : AlarmIcon.values()) {
                if (alarmIcon.alarmLv.equals(_alarmLv)) {
                    // 引数のアラームLvと一致する場合、アイコンタイプを取得
                    ret = alarmIcon.iconType;
                    break;
                }
            }

            return ret;
        }

        /**
         * アラームLvを取得.<br>
         *<br>
         * 概要:<br>
         *   アイコンタイプに該当するアラームLvを取得する
         *<br>
         * @param _iconType アイコンタイプ
         * @return アラームLv         */
        public static String getAlarmLv(final String _iconType) {
            // 返却値を初期化
            String ret = FW00_19_Const.EMPTY_STR;

            for (AlarmIcon alarmIcon : AlarmIcon.values()) {
                if (alarmIcon.iconType.equals(_iconType)) {
                    // 引数のアイコンタイプと一致する場合、アラームLvを取得
                    ret = alarmIcon.alarmLv;
                    break;
                }
            }

            return ret;
        }
    }

    /**
     * 16進数接頭辞(0x).
     */
    public static final String HEX_PREFIX = "0x";

    /**
     * コマンドコード16進フォーマット(%04x).
     */
    public static final String HEX_COMMAND_FORMT = "%04x";

    /**
     * 16進数 16bitフル桁.
     */
    public static final int  HEX_NUM_FULL = 0xFFFF;

    /**
     * 16進数 16bit上位桁.
     */
    public static final int  HEX_NUM_HIGH_HALF = 0xFF00;

    /**
     * 16進数 16bit下位桁.
     */
    public static final int  HEX_NUM_LOW_HALF = 0x00FF;

    /**
     * 16進数 16bit Modbus CRCチェック多項式定義値.
     */
    public static final int  HEX_NUM_CRC_POLYNOMIAL = 0xA001;

    /**
     * 16進数 8bitフル桁.
     */
    public static final int  HEX_NUM_FULL_8 = 0xFF;

    /**
     * MODBUSヘッダサイズ（ASCII）.
     */
    public static final int  MODBUS_H_SIZE_ASCII = 6;

    /**
     * MODBUSヘッダサイズ（BIN）.
     */
    public static final int  MODBUS_H_SIZE_BIN = 3;

    /**
     * MODBUSコマンドサイズ.
     */
    public static final int  MODBUS_CMD_SIZE = 6;

    /**
     * MODBUSレスポンスMAXサイズ.
     */
    public static final int  MODBUS_RSP_SIZE_MAX = 258;

    /**
     * MODBUSエラーレスポンス.
     */
    public static final int  MODBUS_ERROR_CODE = 0x80;

    /**
     * ビットシフト.
     */
    public static final int  BIT_SHIFT_8 = 8;

    /**
     *
     * 通信ログステータス定数.<br>
     *<br>
     * 概要:<br>
     *   データポイント位置マスタの通信日時区分の定数定義
     *<br>
     */
    public abstract class TELECOM_LOG_STATUS {
        /**
         * 正常 : 1.
         */
        public static final String SUCCESS = "1";
        /**
         * 異常 : 2.
         */
        public static final String FAILURE = "2";
    }

    /**
     *  改行タグ.
     */
    public static final String HTML_BR_CODE = "<br />";

    /**
     * 16進桁数(2桁).
     */
    public static final int HEX_LENGTH_2 = 2;

    /**
     * 基数(16進).
     */
    public static final int RADIX_NUM_HEX = 16;

    /**
     * ビット数(4bit).
     */
    public static final int BIT_NUM_4 = 4;

    /**
     * ビット数(8bit).
     */
    public static final int BIT_NUM_8 = 8;

    /**
     *
     * 通信エラーCDとMessageResourceのメッセージIDの対応関係.<br>
     *<br>
     * 概要:<br>
     *   通信エラーCDとMessageResourceのメッセージIDの対応関係
     *<br>
     */
    public enum TelecomErrorCdRelInfo {
        /**
         * TER000: MMCMA010110_002.
         */
        TER000("TER000", "MMCMA010110_002"),
        /**
         * TER001: MMCMA010110_003.
         */
        TER001("TER001", "MMCMA010110_003"),
        /**
         * TER002: MMCMA010110_004.
         */
        TER002("TER002", "MMCMA010110_004"),
        /**
         * TER003: MMCMA010110_005.
         */
        TER003("TER003", "MMCMA010110_005"),
        /**
         * TER004: MMCMA010110_006.
         */
        TER004("TER004", "MMCMA010110_006"),
        /**
         * TER100: MMCMA010110_007.
         */
        TER100("TER100", "MMCMA010110_007"),
        /**
         * TER101: MMCMA010110_008.
         */
        TER101("TER101", "MMCMA010110_008"),
        /**
         * TER102: MMCMA010110_009.
         */
        TER102("TER102", "MMCMA010110_009"),
        /**
         * TER103: MMCMA010110_010.
         */
        TER103("TER103", "MMCMA010110_010"),
        /**
         * TER104: MMCMA010110_011.
         */
        TER104("TER104", "MMCMA010110_011"),
        /**
         * TER105: MMCMA010110_012.
         */
        TER105("TER105", "MMCMA010110_012"),
        /**
         * TER200: MMCMA010110_013.
         */
        TER200("TER200", "MMCMA010110_013"),
        /**
         * TER201: MMCMA010110_014.
         */
        TER201("TER201", "MMCMA010110_014"),
        /**
         * TER202: MMCMA010110_015.
         */
        TER202("TER202", "MMCMA010110_015"),
        /**
         * TER203: MMCMA010110_016.
         */
        TER203("TER203", "MMCMA010110_016"),
        /**
         * TER204: MMCMA010110_017.
         */
        TER204("TER204", "MMCMA010110_017"),
        /**
         * TER205: MMCMA010110_018.
         */
        TER205("TER205", "MMCMA010110_018"),
        /**
         * TER206: MMCMA010110_039.
         */
        TER206("TER206", "MMCMA010110_039"),
        /**
         * TER300: MMCMA010110_019.
         */
        TER300("TER300", "MMCMA010110_019"),
        /**
         * TER301: MMCMA010110_020.
         */
        TER301("TER301", "MMCMA010110_020"),
        /**
         * TER302: MMCMA010110_021.
         */
        TER302("TER302", "MMCMA010110_021"),
        /**
         * TER303: MMCMA010110_022.
         */
        TER303("TER303", "MMCMA010110_022"),
        /**
         * TER304: MMCMA010110_023.
         */
        TER304("TER304", "MMCMA010110_023"),
        /**
         * TER305: MMCMA010110_038.
         */
        TER305("TER305", "MMCMA010110_038"),
        /**
         * TER306: MMCMA010110_040.
         */
        TER306("TER306", "MMCMA010110_040"),
        /**
         * TER400: MMCMA010110_024.
         */
        TER400("TER400", "MMCMA010110_024"),
        /**
         * TER401: MMCMA010110_025.
         */
        TER401("TER401", "MMCMA010110_025"),
        /**
         * TER402: MMCMA010110_026.
         */
        TER402("TER402", "MMCMA010110_026"),
        /**
         * TER403: MMCMA010110_027.
         */
        TER403("TER403", "MMCMA010110_027"),
        /**
         * TER404: MMCMA010110_028.
         */
        TER404("TER404", "MMCMA010110_028"),
        /**
         * TER405: MMCMA010110_029.
         */
        TER405("TER405", "MMCMA010110_029"),
        /**
         * TER406: MMCMA010110_030.
         */
        TER406("TER406", "MMCMA010110_030"),
        /**
         * TER407: MMCMA010110_031.
         */
        TER407("TER407", "MMCMA010110_031"),
        /**
         * TER408: MMCMA010110_032.
         */
        TER408("TER408", "MMCMA010110_032"),
        /**
         * TER409: MMCMA010110_033.
         */
        TER409("TER409", "MMCMA010110_033"),
        /**
         * TER410: MMCMA010110_034.
         */
        TER410("TER410", "MMCMA010110_034"),
        /**
         * TER411: MMCMA010110_035.
         */
        TER411("TER411", "MMCMA010110_035"),
        /**
         * TER412: MMCMA010110_036.
         */
        TER412("TER412", "MMCMA010110_036"),
        /**
         * TER413: MMCMA010110_037.
         */
        TER413("TER413", "MMCMA010110_037");

        /**
         * 通信エラーCD.
         */
        public final String errorCd;

        /**
         * MessageResourceのメッセージID.
         */
        public final String messageId;

        /**
         * コンストラクタ.
         *
         * @param _errorCd 通信エラーCD
         * @param _messageId MessageResourceのメッセージID
         */
        private TelecomErrorCdRelInfo(final String _errorCd, final String _messageId) {
            this.errorCd = _errorCd;
            this.messageId = _messageId;
        }

        /**
         * @return 通信エラーCD
         */
        public final String getErrorCd() {
            return this.errorCd;
        }

        /**
         * @return MessageResourceのメッセージID
         */
        public final String getMessageId() {
            return this.messageId;
        }

        /**
         * 指定したエラーCDに対応するメッセージIDを取得する.
         *<br>
         * 概要:<br>
         *   指定したエラーCDに対応するメッセージIDを取得する
         *<br>
         * @param _errorCd 通信エラーCD
         * @return MessageResourceのメッセージID
         */
        public static String getMessageId(final String _errorCd) {
            String ret = FW00_19_Const.EMPTY_STR;

            for (TelecomErrorCdRelInfo telecomError : TelecomErrorCdRelInfo.values()) {
                // 通信エラーCDが引数と一致する場合、MessageResourceのメッセージIDを取得する
                if (telecomError.getErrorCd().equals(_errorCd)) {
                    ret = telecomError.getMessageId();
                    break;
                }
            }

            return ret;
        }
    }

    /**
     *
     * 無効フラグ定数.<br>
     *<br>
     * 概要:<br>
     *   無効フラグの定数定義
     *<br>
     */
    public abstract class INVALID_FLAG {
        /**
         * 有効: 0.
         */
        public static final String VALID = "0";
        /**
         * 無効 : 1.
         */
        public static final String INVALID = "1";
    }

    /**
     * 改行コード.
     */
    public static enum CHANGE_LINE_CODE {
        /**
         * CR+LF.
         */
        CRLF("CR+LF", LINE_END),
        /**
         * CR.
         */
        CR("CR", CARRIAGE_RETURN),
        /**
         * LF.
         */
        LF("LF", LINE_FEED);

        /**
         *
         * コンストラクタ.
         *
         * @param _dspStr 表示文字列
         * @param _code 文字コード
         */
        private CHANGE_LINE_CODE(final String _dspStr, final String _code) {
            this.dspStr = _dspStr;
            this.code = _code;
        }

        /**
         * 表示文字列.
         */
        private String dspStr;

        /**
         *
         * 表示文字列取得.<br>
         *<br>
         * 概要:<br>
         *   表示文字列を取得する
         *<br>
         * @return 表示文字列
         */
        public String getDspStr() {
            return this.dspStr;
        }

        /**
         * 改行コード.
         */
        private String code;

        /**
         *
         * 改行コード取得.<br>
         *<br>
         * 概要:<br>
         *   改行コードを取得する
         *<br>
         * @return 改行コード
         */
        public String getCode() {
            return this.code;
        }

        /**
         *
         * 表示文字列から改行コード取得.<br>
         *<br>
         * 概要:<br>
         *   表示文字列から改行コードを取得する
         *<br>
         * @param _dspStr 表示文字列
         * @return 改行コード
         */
        public static String getCodeFromDspStr(final String _dspStr) {
            String ret = FW00_19_Const.EMPTY_STR;
            CHANGE_LINE_CODE[] changeLineCodeArray = CHANGE_LINE_CODE.values();
            for (CHANGE_LINE_CODE changeLineCode : changeLineCodeArray) {
                if (changeLineCode.getDspStr().equals(_dspStr)) {
                    ret = changeLineCode.getCode();
                    break;
                }
            }

            return ret;
        }
    }

    /**
     *
     * グループ管理権限使用フラグ定数.<br>
     *<br>
     * 概要:<br>
     *   グループ管理権限使用フラグの定数定義
     *<br>
     */
    public abstract class GROUP_ADMIN_OPTION {
        /**
         * 使用しない: 0.
         */
        public static final String NOT_USE = "0";
        /**
         * 使用する : 1.
         */
        public static final String USE = "1";
    }

    /**
     *
     * アラーム履歴用定数定義クラス.<br/>
     *<br/>
     * 概要:<br/>
     *   アラーム履歴用定数定義クラス<br/>
     *<br/>
     */
    public abstract class ALARM_HISTORY {
        /**
         * 報告書 最大件数.
         */
        public static final int REPORT_MAX_NUM = 3;
    }

    /**
     *
     * アラーム履歴用マップキー定義クラス.<br/>
     *<br/>
     * 概要:<br/>
     *   アラーム履歴用マップキー定義クラス<br/>
     *<br/>
     */
    public abstract class ALARM_HISTORY_MAPKEY {
        /**
         * アラーム履歴Listプロパティ:Mapキー[アラーム状態データSID].
         */
        public static final String ALARM_STATE_DATA_SID = "alarmStateDataSid";

        /**
         * アラーム履歴Listプロパティ:Mapキー[判定日時（ユーザのタイムゾーン表示）].
         */
        public static final String ALARM_JUDGE_DATETIME_U = "alarmJudgeDatetime_U";

        /**
         * アラーム履歴Listプロパティ:Mapキー[判定日時（機器のタイムゾーン表示）].
         */
        public static final String ALARM_JUDGE_DATETIME_M = "alarmJudgeDatetime_M";

        /**
         * アラーム履歴Listプロパティ:Mapキー[発生日時（ユーザのタイムゾーン表示）].
         */
        public static final String ALARM_ON_DATETIME_U = "alarmOnDatetime_U";

        /**
         * アラーム履歴Listプロパティ:Mapキー[発生日時（機器のタイムゾーン表示）].
         */
        public static final String ALARM_ON_DATETIME_M = "alarmOnDatetime_M";

        /**
         * アラーム履歴Listプロパティ:Mapキー[アラーム名称].
         */
        public static final String ALARM_NAME = "alarmName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[アラームLV].
         */
        public static final String ALARM_LEVEL = "alarmLevel";

        /**
         * アラーム履歴Listプロパティ:Mapキー[アラーム種別].
         */
        public static final String ALARM_KIND = "alarmKind";

        /**
         * アラーム履歴Listプロパティ:Mapキー[自動確認済みフラグ].
         */
        public static final String AUTO_CONFIRM_FLAG = "autoConfirmFlag";

        /**
         * アラーム履歴Listプロパティ:Mapキー[状態].
         */
        public static final String ALARM_STATUS = "alarmStatus";

        /**
         * アラーム履歴Listプロパティ:Mapキー[復帰日時（ユーザのタイムゾーン表示）].
         */
        public static final String ALARM_OFF_DATETIME_U = "alarmOffDatetime_U";

        /**
         * アラーム履歴Listプロパティ:Mapキー[復帰日時（機器のタイムゾーン表示）].
         */
        public static final String ALARM_OFF_DATETIME_M = "alarmOffDatetime_M";

        /**
         * アラーム履歴Listプロパティ:Mapキー[完了日時（ユーザのタイムゾーン表示）].
         */
        public static final String COMPLETE_DATETIME_U = "completeDatetime_U";

        /**
         * アラーム履歴Listプロパティ:Mapキー[完了日時（機器のタイムゾーン表示）].
         */
        public static final String COMPLETE_DATETIME_M = "completeDatetime_M";

        /**
         * アラーム履歴Listプロパティ:Mapキー[機器ID].
         */
        public static final String DEVICE_ID = "deviceId";

        /**
         * アラーム履歴Listプロパティ:Mapキー[機器名称].
         */
        public static final String DEVICE_NAME = "deviceName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[発生確認者ID].
         */
        public static final String CONFIRM_ON_USER_ID = "confirmOnUserId";

        /**
         * アラーム履歴Listプロパティ:Mapキー[発生確認者名].
         */
        public static final String CONFIRM_ON_USER_NAME = "confirmOnUserName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[発生確認者名（姓）].
         */
        public static final String CONFIRM_ON_USER_LASTNAME = "confirmOnUserLastName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[発生確認者名（名）].
         */
        public static final String CONFIRM_ON_USER_FIRSTNAME = "confirmOnUserFirstName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[強制復帰実施者ID].
         */
        public static final String ALARM_OFF_USER_ID = "alarmOffUserId";

        /**
         * アラーム履歴Listプロパティ:Mapキー[強制復帰実施者名].
         */
        public static final String ALARM_OFF_USER_NAME = "alarmOffUserName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[強制復帰実施者名（姓）].
         */
        public static final String ALARM_OFF_USER_LASTNAME = "alarmOffUserLastName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[強制復帰実施者名（名）].
         */
        public static final String ALARM_OFF_USER_FIRSTNAME = "alarmOffUserFirstName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[復帰確認者ID].
         */
        public static final String CONFIRM_OFF_USER_ID = "confirmOffUserId";

        /**
         * アラーム履歴Listプロパティ:Mapキー[復帰確認者名].
         */
        public static final String CONFIRM_OFF_USER_NAME = "confirmOffUserName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[復帰確認者名（姓）].
         */
        public static final String CONFIRM_OFF_USER_LASTNAME = "confirmOffUserLastName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[復帰確認者名（名）].
         */
        public static final String CONFIRM_OFF_USER_FIRSTNAME = "confirmOffUserFirstName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[完了実施者ID].
         */
        public static final String COMPLETE_USER_ID = "completeUserId";

        /**
         * アラーム履歴Listプロパティ:Mapキー[完了実施者名].
         */
        public static final String COMPLETE_USER_NAME = "completeUserName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[完了実施者名（姓）].
         */
        public static final String COMPLETE_USER_LASTNAME = "completeUserLastName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[完了実施者名（名）].
         */
        public static final String COMPLETE_USER_FIRSTNAME = "completeUserFirstName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[発生確認日時（ユーザのタイムゾーン表示）].
         */
        public static final String ALARM_ON_CONFIRM_DATETIME_U = "alarmOnConfirmDatetime_U";

        /**
         * アラーム履歴Listプロパティ:Mapキー[発生確認日時（機器のタイムゾーン表示）].
         */
        public static final String ALARM_ON_CONFIRM_DATETIME_M = "alarmOnConfirmDatetime_M";

        /**
         * アラーム履歴Listプロパティ:Mapキー[復帰確認日時（ユーザのタイムゾーン表示）].
         */
        public static final String ALARM_OFF_CONFIRM_DATETIME_U = "alarmOffConfirmDatetime_U";

        /**
         * アラーム履歴Listプロパティ:Mapキー[復帰確認日時（機器のタイムゾーン表示）].
         */
        public static final String ALARM_OFF_CONFIRM_DATETIME_M = "alarmOffConfirmDatetime_M";

        /**
         * アラーム履歴Listプロパティ:Mapキー[報告書SID].
         */
        public static final String REPORT_SID = "reportSid";

        /**
         * アラーム履歴Listプロパティ:Mapキー[報告書名].
         */
        public static final String REPORT_NAME = "reportName";

        /**
         * アラーム履歴Listプロパティ:Mapキー[アラーム判定データ].
         */
        public static final String ALARM_JUDGE_DATA = "alarmJudgeData";
    }

    /**
     *
     * アラーム履歴用SQLパラメータキー定義クラス.<br/>
     *<br/>
     * 概要:<br/>
     *   アラーム履歴用SQLパラメータキー定義クラス<br/>
     *<br/>
     */
    public abstract class ALARM_HISTORY_SQL_PARAM {
        /**
         * SQL変数キー :cond_AlarmOnDatetime_from.
         */
        public static final String COND_ALARM_ON_DATETIME_FROM = "cond_AlarmOnDatetime_from";

        /**
         * SQL変数キー :cond_AlarmOnDatetime_from_hour.
         */
        public static final String COND_ALARM_ON_DATETIME_FROM_HOUR = "cond_AlarmOnDatetime_from_hour";

        /**
         * SQL変数キー :cond_AlarmOnDatetime_from_minute.
         */
        public static final String COND_ALARM_ON_DATETIME_FROM_MINUTE = "cond_AlarmOnDatetime_from_minute";

        /**
         * SQL変数キー :cond_AlarmOnDatetime_from_second.
         */
        public static final String COND_ALARM_ON_DATETIME_FROM_SECOND = "cond_AlarmOnDatetime_from_second";

        /**
         * SQL変数キー :cond_AlarmOnDatetime_to.
         */
        public static final String COND_ALARM_ON_DATETIME_TO = "cond_AlarmOnDatetime_to";

        /**
         * SQL変数キー :cond_AlarmOnDatetime_to_hour.
         */
        public static final String COND_ALARM_ON_DATETIME_TO_HOUR = "cond_AlarmOnDatetime_to_hour";

        /**
         * SQL変数キー :cond_AlarmOnDatetime_to_minute.
         */
        public static final String COND_ALARM_ON_DATETIME_TO_MINUTE = "cond_AlarmOnDatetime_to_minute";

        /**
         * SQL変数キー :cond_AlarmOnDatetime_to_second.
         */
        public static final String COND_ALARM_ON_DATETIME_TO_SECOND = "cond_AlarmOnDatetime_to_second";

        /**
         * SQL変数キー :cond_AlarmOffDatetime_from.
         */
        public static final String COND_ALARM_OFF_DATETIME_FROM = "cond_AlarmOffDatetime_from";

        /**
         * SQL変数キー :cond_AlarmOffDatetime_from_hour.
         */
        public static final String COND_ALARM_OFF_DATETIME_FROM_HOUR = "cond_AlarmOffDatetime_from_hour";

        /**
         * SQL変数キー :cond_AlarmOffDatetime_from_minute.
         */
        public static final String COND_ALARM_OFF_DATETIME_FROM_MINUTE = "cond_AlarmOffDatetime_from_minute";

        /**
         * SQL変数キー :cond_AlarmOffDatetime_from_second.
         */
        public static final String COND_ALARM_OFF_DATETIME_FROM_SECOND = "cond_AlarmOffDatetime_from_second";

        /**
         * SQL変数キー :cond_AlarmOffDatetime_to.
         */
        public static final String COND_ALARM_OFF_DATETIME_TO = "cond_AlarmOffDatetime_to";

        /**
         * SQL変数キー :cond_AlarmOffDatetime_to_hour.
         */
        public static final String COND_ALARM_OFF_DATETIME_TO_HOUR = "cond_AlarmOffDatetime_to_hour";

        /**
         * SQL変数キー :cond_AlarmOffDatetime_to_minute.
         */
        public static final String COND_ALARM_OFF_DATETIME_TO_MINUTE = "cond_AlarmOffDatetime_to_minute";

        /**
         * SQL変数キー :cond_AlarmOffDatetime_to_second.
         */
        public static final String COND_ALARM_OFF_DATETIME_TO_SECOND = "cond_AlarmOffDatetime_to_second";

        /**
         * SQL変数キー :cond_CompleteDatetime_from.
         */
        public static final String COND_COMPLETE_DATETIME_FROM = "cond_CompleteDatetime_from";

        /**
         * SQL変数キー :cond_CompleteDatetime_from_hour.
         */
        public static final String COND_COMPLETE_DATETIME_FROM_HOUR = "cond_CompleteDatetime_from_hour";

        /**
         * SQL変数キー :cond_CompleteDatetime_from_minute.
         */
        public static final String COND_COMPLETE_DATETIME_FROM_MINUTE = "cond_CompleteDatetime_from_minute";

        /**
         * SQL変数キー :cond_CompleteDatetime_to.
         */
        public static final String COND_COMPLETE_DATETIME_TO = "cond_CompleteDatetime_to";

        /**
         * SQL変数キー :cond_CompleteDatetime_to_hour.
         */
        public static final String COND_COMPLETE_DATETIME_TO_HOUR = "cond_CompleteDatetime_to_hour";

        /**
         * SQL変数キー :cond_CompleteDatetime_to_minute.
         */
        public static final String COND_COMPLETE_DATETIME_TO_MINUTE = "cond_CompleteDatetime_to_minute";
    }

    /**
     *
     * 稼働状況分析用マップキー定義クラス.<br/>
     *<br/>
     * 概要:<br/>
     *   稼働状況分析用マップキー定義クラス<br/>
     *<br/>
     */
    public abstract class OPERATION_STATUS_ANALYSIS_MAPKEY {

        /**
         * 稼働状況分析プロパティ:Mapキー[日].
         */
        public static final String DAY_OF_MONTH = "dayOfMonth";

        /**
         * 稼働状況分析プロパティ:Mapキー[状態継続時間].
         */
        public static final String DURATION = "duration";

        /**
         * 稼働状況分析プロパティ:Mapキー[稼働時間合計].
         */
        public static final String RUN_TIME = "runTime";

        /**
         * 稼働状況分析プロパティ:Mapキー[グループパス].
         */
        public static final String TREE_PATH = "treePath";

        /**
         * 稼働状況分析プロパティ:Mapキー[グループパス名称].
         */
        public static final String TREE_PATH_NAME = "treePathName";

        /**
         * 稼働状況分析プロパティ:Mapキー[稼動状態リスト].
         */
        public static final String STATUS_LIST = "statusDetailList";

        /**
         * 稼働状況分析プロパティ:Mapキー[総合稼動状態情報].
         */
        public static final String TOTAL_STATUS_INFO = "totalStatusInfo";

        /**
         * 稼働状況分析プロパティ:Mapキー[機器稼動状態].
         */
        public static final String OPERATION_STATUS = "operationStatus";

        /**
         * 稼働状況分析プロパティ:Mapキー[型番SID].
         */
        public static final String MODEL_SID = "modelSid";

        /**
         * 稼働状況分析プロパティ:Mapキー[型番名称].
         */
        public static final String MODEL_NAME = "modelName";

        /**
         * 稼働状況分析プロパティ:Mapキー[機器SID].
         */
        public static final String DEVICE_SID = "deviceSid";

        /**
         * 稼働状況分析プロパティ:Mapキー[機器名称].
         */
        public static final String DEVICE_NAME = "deviceName";

    }

    /**
     *
     * 稼働状況分析用SQLパラメータキー定義クラス.<br/>
     *<br/>
     * 概要:<br/>
     *   稼働状況分析用SQLパラメータキー定義クラス<br/>
     *<br/>
     */
    public abstract class OPERATION_STATUS_ANALYSIS_SQL_PARAM {

        /**
         * ユーザSIDのSQL変数キー :userSid.
         */
        public static final String USER_SID = "userSid";

        /**
         * 型番SIDのSQL変数キー :modelSid.
         */
        public static final String MODEL_SID = "modelSid";

        /**
         * 機器SIDのSQL変数キー :deviceSid.
         */
        public static final String DEVICE_SID = "deviceSid";

        /**
         * グループIDのSQL変数キー :treePath.
         */
        public static final String TREE_PATH = "treePath";

        /**
         * 詮索日FROMのSQL変数キー :fromDate.
         */
        public static final String FROM_DATE = "fromDate";

        /**
         * 詮索日TOのSQL変数キー :toDate.
         */
        public static final String TO_DATE = "toDate";

        /**
         * 言語コードのSQL変数キー :langCd.
         */
        public static final String LANG_CD = "langCd";

    }

    /**
     *
     * アラーム状況分析用マップキー定義クラス.<br/>
     *<br/>
     * 概要:<br/>
     *   アラーム状況分析用マップキー定義クラス<br/>
     *<br/>
     */
    public abstract class ALARM_STATUS_ANALYSIS_MAPKEY {

        /**
         * アラーム状況分析プロパティ:Mapキー[日].
         */
        public static final String DAY_OF_MONTH = "dayOfMonth";

        /**
         * アラーム状況分析プロパティ:Mapキー[アラーム名称].
         */
        public static final String ALARM_NAME = "alarmName";

        /**
         * アラーム状況分析プロパティ:Mapキー[アラーム発生日].
         */
        public static final String ALARM_ON_DATETIME = "alarmOnDatetime";

        /**
         * アラーム状況分析プロパティ:Mapキー[発生回数].
         */
        public static final String COUNT = "count";

        /**
         * アラーム状況分析プロパティ:Mapキー[アラーム発生回数リスト].
         */
        public static final String ALARM_COUNT_LIST = "alarmCountList";

        /**
         * アラーム状況分析プロパティ:Mapキー[IDX].
         */
        public static final String IDX = "idx";

        /**
         * アラーム状況分析プロパティ:Mapキー[色].
         */
        public static final String COLOR = "color";

        /**
         * アラーム状況分析プロパティ:Mapキー[アラームSID].
         */
        public static final String ALARM_SID = "alarmSid";

        /**
         * アラーム状況分析プロパティ:Mapキー[アラーム日時（ユーザのタイムゾーン表示）].
         */
        public static final String ALARM_DATETIME_U = "alarmDatetime_U";

        /**
         * アラーム状況分析プロパティ:Mapキー[アラーム日時（機器のタイムゾーン表示）].
         */
        public static final String ALARM_DATETIME_M = "alarmDatetime_M";

        /**
         * アラーム状況分析プロパティ:Mapキー[計測日時（ユーザのタイムゾーン表示）].
         */
        public static final String MEAS_DATETIME_U = "measDatetime_U";

        /**
         * アラーム状況分析プロパティ:Mapキー[計測日時（機器のタイムゾーン表示）].
         */
        public static final String MEAS_DATETIME_M = "measDatetime_M";

        /**
         * アラーム状況分析プロパティ:Mapキー[最新計測日時].
         */
        public static final String MAX_MEAS_DATETIME = "maxMeasureDate";

        /**
         * アラーム状況分析プロパティ:Mapキー[計測データ].
         */
        public static final String DATA_POINT_VALUE = "dataPointValue";

        /**
         * アラーム状況分析プロパティ:Mapキー[型番ID].
         */
        public static final String MODEL_ID = "modelId";

        /**
         * 稼働状態名称.
         */
        public static final String OPERATION_STATUS_NAME = "operationStatusName";

        /**
         * アラーム状況分析プロパティ:Mapキー[最終通信日時].
         */
        public static final String COMMUNICATION_DATETIME = "communicationDatetime";

        /**
         * アラーム状況分析プロパティ:Mapキー[最終通信日時（ユーザのタイムゾーン表示）].
         */
        public static final String COMMUNICATION_DATETIME_U = "communicationDatetime_U";

        /**
         * アラーム状況分析プロパティ:Mapキー[最終通信日時（機器のタイムゾーン表示）].
         */
        public static final String COMMUNICATION_DATETIME_M = "communicationDatetime_M";

        /**
         * アラーム状況分析プロパティ:Mapキー[機器稼働時間].
         */
        public static final String OPERATION_TIME = "operationTime";

       /**
        * アラーム状況分析プロパティ:Mapキー[機器稼動状態].
        */
        public static final String OPERATION_STATUS = "operationStatus";

        /**
         * アラーム状況分析プロパティ:Mapキー[(カラム名の別名)機器の国コード].
         */
        public static final String COUNTRY_CD = "countryCd";

        /**
         * アラーム状況分析プロパティ:Mapキー[(カラム名の別名)機器の国名称].
         */
        public static final String COUNTRY_NAME = "countryName";

        /**
         * アラーム状況分析プロパティ:Mapキー[位置情報].
         */
        public static final String POSITION_GET_CLASS = "positionGetClass";

        /**
         * アラーム状況分析プロパティ:Mapキー[位置情報（緯度）].
         */
        public static final String POSITION_INFO_LAT = "positionInfoLat";

        /**
         * アラーム状況分析プロパティ:Mapキー[位置情報（経度）].
         */
        public static final String POSITION_INFO_LONG = "positionInfoLong";

        /**
         * アラーム状況分析プロパティ:Mapキー[タイトル用機器名称].
         */
        public static final String CUT_DEVICE_NAME = "cutDeviceName";

        /**
         * アラーム状況分析プロパティ:Mapキー[タイトル用型番名称].
         */
        public static final String CUT_MODEL_NAME = "cutModelName";

        /**
         * アラーム状況分析プロパティ:Mapキー[タイトル用グループ名称].
         */
        public static final String CUT_GROUP_NAME = "cutGroupName";

        /**
         * アラーム状況分析プロパティ:Mapキー[グループ名称].
         */
        public static final String GROUP_NAME = "groupName";

        /**
         * アラーム状況分析プロパティ:Mapキー[起点日].
         */
        public static final String BASE_DATETIME_FROM = "txtBaseDateTimeFrom";

        /**
         * アラーム状況分析プロパティ:Mapキー[検索日From].
         */
        public static final String SEARCH_DATE_FROM = "searchDateFrom";

        /**
         * アラーム状況分析プロパティ:Mapキー[検索日To].
         */
        public static final String SEARCH_DATE_TO = "searchDateTo";

        /**
         * アラーム状況分析プロパティ:Mapキー[機器SID].
         */
        public static final String DEVICE_SID = "deviceSid";

        /**
         * アラーム状況分析プロパティ:Mapキー[機器名称].
         */
        public static final String DEVICE_NAME = "deviceName";

        /**
         * アラーム状況分析プロパティ:Mapキー[グループパス].
         */
        public static final String TREE_PATH = "treePath";

        /**
         * アラーム状況分析プロパティ:Mapキー[グループパス名称].
         */
        public static final String TREE_PATH_NAME = "treePathName";

    }

    /**
     *
     * アラーム状況分析用SQLパラメータキー定義クラス.<br/>
     *<br/>
     * 概要:<br/>
     *   アラーム状況分析用SQLパラメータキー定義クラス<br/>
     *<br/>
     */
    public abstract class ALARM_STATUS_ANALYSIS_SQL_PARAM {

        /**
         * ユーザSIDのSQL変数キー :userSid.
         */
        public static final String USER_SID = "userSid";

        /**
         * 型番SIDのSQL変数キー :modelSid.
         */
        public static final String MODEL_SID = "modelSid";

        /**
         * グループIDのSQL変数キー :treePath.
         */
        public static final String TREE_PATH = "treePath";

        /**
         * 機器SIDのSQL変数キー :deviceSid.
         */
        public static final String DEVICE_SID = "deviceSid";

        /**
         * 開始日付のSQL変数キー :startDate.
         */
        public static final String START_DATE = "startDate";

        /**
         * 終了日付のSQL変数キー :endDate.
         */
        public static final String END_DATE = "endDate";

        /**
         * タイムゾーンオフセットのSQL変数キー :zoneOffset.
         */
        public static final String ZONE_OFFSET = "zoneOffset";

        /**
         * アラームSIDのSQL変数キー :alarmSid.
         */
        public static final String ALARM_SID = "alarmSid";

    }

    /**
     * コマンドコードの有効範囲定義.
     */
    public abstract class COMMAND_RANGE {

        /**
         * デフォルト範囲(FROM).
         * 0x1000
         */
        public static final int DEFAULT_FROM = 4096;

        /**
         * デフォルト範囲(TO).
         * 0x1FFF
         */
        public static final int DEFAULT_TO = 8191;

        /**
         * データ形式「受信ファイル｣の範囲(FROM).
         * 0x2000
         */
        public static final int DATA_FORM_FILE_FROM =  8192;

        /**
         * データ形式「受信ファイル｣の範囲(TO).
         * 0x20FF
         */
        public static final int DATA_FORM_FILE_TO = 8447;
    }

    /**
     * 最大値.
     */
    public abstract class MAX_VALUE {
        /**
         * 表示順の最大値.
         */
        public static final int DISPLAY_ORDER_MAX_VALUE = Integer.MAX_VALUE;

        /**
         * 符号なし整数型の最大値.
         */
        public static final long UNSIGNED_INT_MAX_VALUE = 4294967295L;
    }

    /**
     * 正規表現.
     */
    public static class REGULAR_EXPRESSION {
        /**
         * 16進数の正規表現.
         */
        public static final String HEXA_DECIMAL = "[0-9A-Fa-f]";
    }

    /**
     * アラーム判定条件タグ区分.
     */
    public abstract class ALARM_JUDGE_DATA_TAG {

        /**
         * データポイント.
         */
        public static final String DATA_POINT = "dp";

        /**
         * アラーム条件.
         */
        public static final String ALARM_CONDITION = "ac";
    }

    /**
     *
     * 顧客補足情報マスタの補足情報CD定数.<br>
     *<br>
     * 概要:<br>
     *   顧客補足情報マスタの補足情報CDの定数定義
     *<br>
     */
    public abstract class MST_CUSTOMER_SUBINFO_CD {
        /**
         * 地図アクセス上限値.
         */
        public static final String PV_COUNT = "pv_count";

        /**
         * Disk容量上限値.
         */
        public static final String STORAGE_MAX = "storage_max";

        /**
         * OEM事業者顧客コード.
         */
        public static final String OEM_CUSTOMER_CD = "oem_customer_cd";
    }

    /**
     *
     * 受信ファイル形式用の固定データポイントコード.
     *
     */
    public abstract class FORM_FILE_FIXED_DATAPOINT_CD {

        /**
         * 計測日時.
         */
        public static final String DATETIME = "@DP1@";

        /**
         * 受信データ.
         */
        public static final String FILE_DATA = "@DP2@";

    }

    /**
     *
     * メールテンプレートアラーム種別定数.<br>
     *<br>
     * 概要:<br>
     *   アラーム種別を表す定数クラス
     *<br>
     */
    public abstract class MAIL_ALARM_KIND {
        /**
         * 発生型.
         */
        public static final String GENERATE = "01";
        /**
         * 復帰型.
         */
        public static final String RECOVER = "02";

        /**
         * 容量オーバー.
         */
        public static final String OVER_CAPACITY = "91";

        /**
         * 地図アクセスカウントオーバー.
         */
        public static final String OVER_MAP_ACCESS_CNT = "92";
    }


    /**
     *
     * お知らせ種別定数.<br>
     *<br>
     * 概要:<br>
     *   お知らせ種別を表す定数クラス
     *<br>
     *
     */
    public abstract class INFO_KIND {

        /**
         * 通常.
         */
        public static final String INFORMATION = "0";

        /**
         * 警告.
         */
        public static final String WARNING = "1";

        /**
         * 重要.
         */
        public static final String IMPORTANT = "2";

        /**
         * 容量オーバー.
         */
        public static final String OVER_CAPACITY = "9";
    }

    /**
     *
     * コマンド実行画面用マップキー定義クラス.<br/>
     *<br/>
     * 概要:<br/>
     *   コマンド実行画面用マップキー定義クラス<br/>
     *<br/>
     */
    public abstract class COMMAND_SEND_MAPKEY {
        /**
         * コマンド実行プロパティ:Mapキー[要求日時（ユーザのタイムゾーン表示）].
         */
        public static final String SEND_DATETIME_U = "sendDatetime_U";

        /**
         * コマンド実行プロパティ:Mapキー[要求日時（機器のタイムゾーン表示）].
         */
        public static final String SEND_DATETIME_M = "sendDatetime_M";

        /**
         * コマンド実行プロパティ:Mapキー[実行者].
         */
        public static final String PRACTITIONER = "practitioner";

        /**
         * コマンド実行プロパティ:Mapキー[コマンド].
         */
        public static final String COMMAND = "command";

        /**
         * コマンド実行プロパティ:Mapキー[ノード番号].
         */
        public static final String NODE_ADDRESS = "nodeAddress";

        /**
         * コマンド実行プロパティ:Mapキー[ファンクションコード].
         */
        public static final String FUNC_CODE = "funcCode";

        /**
         * コマンド実行プロパティ:Mapキー[レジスタ番号].
         */
        public static final String REG_ADDRESS = "regAddress";

        /**
         * コマンド実行プロパティ:Mapキー[レジスタサイズ].
         */
        public static final String REG_SIZE = "regSize";

        /**
         * コマンド実行プロパティ:Mapキー[値].
         */
        public static final String WRITE_VALUE = "writeValue";

        /**
         * コマンド実行プロパティ:Mapキー[レスポンス].
         */
        public static final String RESPONSE = "response";

        /**
         * コマンド実行プロパティ:Mapキー[レスポンス].
         */
        public static final String READ_VALUE = "readValue";

        /**
         * コマンド実行プロパティ:Mapキー[2進データ].
         */
        public static final String READ_BIN = "readBin";

        /**
         * コマンド実行プロパティ:Mapキー[符号なしデータ].
         */
        public static final String READ_UNSIGNED = "readUnsigned";

        /**
         * コマンド実行プロパティ:Mapキー[符号ありデータ].
         */
        public static final String READ_SIGNED = "readSigned";

        /**
         * コマンド実行プロパティ:Mapキー[16進データ].
         */
        public static final String READ_HEX = "readHex";

        /**
         * コマンド実行プロパティ:Mapキー[ASCIIデータ].
         */
        public static final String READ_ASCII = "readAscii";

        /**
         * コマンド実行プロパティ:Mapキー[状態].
         */
        public static final String STATE = "state";

        /**
         * コマンド実行プロパティ:Mapキー[エラーメッセージ].
         */
        public static final String ERROR_MESSAGE = "errorMessage";
    }

    /**
     *
     * コマンド実行画面入力用マップキー定義クラス.<br/>
     *<br/>
     * 概要:<br/>
     *   コマンド実行画面入力用マップキー定義クラス<br/>
     *<br/>
     */
    public abstract class COMMAND_SEND_INPUT_MAPKEY {
        /**
         * コマンド実行プロパティ:Mapキー[ファンクションコード].
         */
        public static final String FUNCTION_CD = "functionCd";

        /**
         * コマンド実行プロパティ:Mapキー[ノード番号].
         */
        public static final String NODE_NO = "nodeNo";

        /**
         * コマンド実行プロパティ:Mapキー[アドレス].
         */
        public static final String ADDRESS = "address";

        /**
         * コマンド実行プロパティ:Mapキー[サイズ].
         */
        public static final String REGSIZE = "regsize";

        /**
         * コマンド実行プロパティ:Mapキー[値].
         */
        public static final String VALUE = "value";

        /**
         * コマンド実行プロパティ:Mapキー[送信データ].
         */
        public static final String SEND_DATA = "sendData";

        /**
         * コマンド実行プロパティ:Mapキー[レスポンス有無].
         */
        public static final String RESPONSE_EXISTS = "responseExists";

        /**
         * コマンド実行プロパティ:Mapキー[送信データ形式].
         */
        public static final String SEND_DATA_TYPE = "sendDataType";
    }

    /**
     *
     * 電文送信ログエラーCDとMessageResourceのメッセージIDの対応関係.<br>
     *<br>
     * 概要:<br>
     *   電文送信ログエラーCDとMessageResourceのメッセージIDの対応関係
     *<br>
     */
    public enum COMMAND_LOG_ERROR_CODE_MSGKEY {
        /** 接続に失敗した旨のメッセージ. */
        SER100("SER100", "MMCMA010120_100"),
        /** 接続確認に失敗した旨のメッセージ. */
        SER101("SER101", "MMCMA010120_101"),
        /** SNS送信に失敗した旨のメッセージ. */
        SER102("SER102", "MMCMA010120_102"),
        /** 接続に失敗・SNS送信に成功した旨のメッセージ. */
        SER103("SER103", "MMCMA010120_103"),
        /** コマンド送信時の接続情報が不正である旨のメッセージ. */
        SER200("SER200", "MMCMA010120_200"),
        /** コマンド送信時の接続確認に失敗した旨のメッセージ. */
        SER201("SER201", "MMCMA010120_201"),
        /** コマンド送信に失敗した旨のメッセージ. */
        SER202("SER202", "MMCMA010120_202"),
        /** レスポンス待ちがタイムアウトになった旨のメッセージ. */
        SER203("SER203", "MMCMA010120_203"),
        /** 切断に失敗した旨のメッセージ. */
        SER204("SER204", "MMCMA010120_204");

        /**
         * エラーコード.
         */
        private String errorCd;

        /**
         * メッセージID.
         */
        private String messageId;

        /**
         * コンストラクタ.
         * @param _errorCd エラーコード
         * @param _messageId メッセージコード
         */
        private COMMAND_LOG_ERROR_CODE_MSGKEY(final String _errorCd, final String _messageId) {
            this.errorCd = _errorCd;
            this.messageId = _messageId;
        }

        /**
         * エラーコードを取得.
         * @return エラーコード
         */
        public String getErrorCd() {
            return this.errorCd;
        }

        /**
         * メッセージIDを取得.
         * @return メッセージID
         */
        public String getMessageId() {
            return this.messageId;
        }
    }

    /**
    *
    * 電文送信データタイプ種別定数.<br>
    *<br>
    * 概要:<br>
    *   電文送信データタイプを表す定数クラス
    *<br>
    *
    */
    public abstract class COMMAND_LOG_DATA_TYPE {

        /**
         * 接続成功.
         */
        public static final String CONNECT_SUCCESS = "10";

        /**
         * 接続失敗.
         */
        public static final String CONNECT_FAILURE = "11";

        /**
         * 切断成功.
         */
        public static final String DISCONNECT_SUCCESS = "20";

        /**
         * 切断失敗.
         */
        public static final String DISCONNECT_FAILURE = "21";

        /**
         * 電文送信成功.
         */
        public static final String SEND_COMMAND_SUCCESS = "30";

        /**
         * 電文送信失敗.
         */
        public static final String SEND_COMMAND_FAILURE = "31";

        /**
         * 電文送信成功 レスポンス待ち.
         */
        public static final String SEND_COMMAND_SUCCESS_WAIT = "32";

    }

    /**
    *
    * ファンクションコード 実行種別定義.<br>
    *<br>
    * 概要:<br>
    *   ファンクションコード 実行種別を表す定義
    *<br>
    *
    */
    public enum COMMAND_FUNCTION_TYPE {
        /** Modbus読み出し系. */
        READ,
        /** Modbus書き込み系. */
        WRITE,
        /** コマンド送信. */
        COMMAND_SEND;

        /**
         * 引数のファンクションコード（名称マスタ 項目コード）の実行種別が一致するかどうかを判断.<BR>
         * @param _itemCd ファンクションコード（名称マスタ 項目コード）
         * @return 結果
         */
        public boolean isType(final String _itemCd) {
            boolean res = false;
            for (COMMAND_FUNCTION function : COMMAND_FUNCTION.values()) {
                if (function.getItemCd().equals(_itemCd)) {
                    res = this.equals(function.getType());
                    break;
                }
            }
            return res;
        }
    }

    /**
    * コマンド実行入力値 指定可能範囲定義.<br>
    *<br>
    * 概要:<br>
    *   コマンド実行入力値の指定可能範囲を定義
    *<br>
    */
    public static class COMMAND_CHECK {
        /**
         * チェック種別インターフェイス.
         */
        public interface CHECK {
        };

        /**
         * ノード番号チェック範囲定義.
         */
        public enum NODE_NO implements CHECK {
            /** ノード番号(0 ～ 247). */
            NODE_NO_01("0", "247"),
            /** ノード番号(0 ～ 247). */
            NODE_NO_02("0", "247");

            /**
             * 下限.
             */
            private String from;

            /**
             * 上限.
             */
            private String to;

            /**
             * コンストラクタ.<BR>
             * @param _from 下限
             * @param _to 上限
             */
            private NODE_NO(final String _from, final String _to) {
                this.from = _from;
                this.to = _to;
            }

            /**
             * @return from
             */
            public String getFrom() {
                return this.from;
            }

            /**
             * @return to
             */
            public String getTo() {
                return this.to;
            }
        }

        /**
         * アドレスチェック範囲定義.
         */
        public enum ADDRESS implements CHECK {
            /** アドレス(00001 ～ 09999). */
            ADDRESS_01("1", "9999"),
            /** アドレス(10001 ～ 19999). */
            ADDRESS_02("10001", "19999"),
            /** アドレス(30001 ～ 39999). */
            ADDRESS_03("30001", "39999"),
            /** アドレス(40001 ～ 49999). */
            ADDRESS_04("40001", "49999");

            /**
             * 下限.
             */
            private String from;

            /**
             * 上限.
             */
            private String to;

            /**
             * コンストラクタ.<BR>
             * @param _from 下限
             * @param _to 上限
             */
            private ADDRESS(final String _from, final String _to) {
                this.from = _from;
                this.to = _to;
            }

            /**
             * @return from
             */
            public String getFrom() {
                return this.from;
            }

            /**
             * @return to
             */
            public String getTo() {
                return this.to;
            }
        }

        /**
         * レジスタサイズチェック範囲定義.
         */
        public enum REG_SIZE implements CHECK {
            /** ビット(1 ～ 2040). */
            REG_SIZE_BIT("1", "2040"),
            /** レジスタ(1 ～ 127). */
            REG_SIZE_REG("1", "127");

            /**
             * 下限.
             */
            private String from;

            /**
             * 上限.
             */
            private String to;

            /**
             * コンストラクタ.<BR>
             * @param _from 下限
             * @param _to 上限
             */
            private REG_SIZE(final String _from, final String _to) {
                this.from = _from;
                this.to = _to;
            }

            /**
             * @return from
             */
            public String getFrom() {
                return this.from;
            }

            /**
             * @return to
             */
            public String getTo() {
                return this.to;
            }
        }

        /**
         * 値チェック範囲定義.
         */
        public enum VALUE implements CHECK {
            /** 値(0, 255). */
            VALUE_01(new String[]{"0x00", "0xFF"}),
            /** 値(0 ～ 65535). */
            VALUE_02("0x0000", "0xFFFF");

            /**
             * 下限.
             */
            private String from;

            /**
             * 上限.
             */
            private String to;

            /**
             * 可能な値.
             */
            private List<String> avali;

            /**
             * コンストラクタ.<BR>
             * @param _from 下限
             * @param _to 上限
             */
            private VALUE(final String _from, final String _to) {
                this.from = _from;
                this.to = _to;
            }

            /**
             * コンストラクタ.<BR>
             * @param _avail 可能な値
             */
            private VALUE(final String[] _avail) {
                this.avali = new ArrayList<String>();
                for (String val : _avail) {
                    this.avali.add(val);
                }
            }

            /**
             * @return from
             */
            public String getFrom() {
                return this.from;
            }

            /**
             * @return to
             */
            public String getTo() {
                return this.to;
            }

            /**
             * @return avali
             */
            public List<String> getAvali() {
                return this.avali;
            }
        }

        /**
         * 送信データチェック範囲定義.
         */
        public enum SEND_DATA implements CHECK {
            /** 送信データ(最大255byte). */
            SEND_DATA_01(255);

            /**
             * 上限値.
             */
            private int limit;

            /**
             * コンストラクタ.<BR>
             * @param _limit 上限
             */
            private SEND_DATA(final int _limit) {
                this.limit = _limit;
            }

            /**
             * @return 上限値
             */
            public int getLimit() {
                return this.limit;
            }
        }
    }

    /**
    *
    * ファンクションコード種別定数.<br>
    *<br>
    * 概要:<br>
    *   ファンクションコード種別を表す定義
    *<br>
    *
    */
    public enum COMMAND_FUNCTION_CODE {
        /** Modbus読込み(コイル、DOの読出し). */
        FUNCTION_CODE_01("01", 0x01, COMMAND_FUNCTION.FUNCTION_11, COMMAND_CHECK.ADDRESS.ADDRESS_01),
        /** Modbus読込み(入力ステータス、DIの読出し). */
        FUNCTION_CODE_02("02", 0x02, COMMAND_FUNCTION.FUNCTION_11, COMMAND_CHECK.ADDRESS.ADDRESS_02),
        /** Modbus読込み(保持レジスタの読出し). */
        FUNCTION_CODE_03("03", 0x03, COMMAND_FUNCTION.FUNCTION_12, COMMAND_CHECK.ADDRESS.ADDRESS_04),
        /** Modbus読込み(入力レジスタの読出し). */
        FUNCTION_CODE_04("04", 0x04, COMMAND_FUNCTION.FUNCTION_12, COMMAND_CHECK.ADDRESS.ADDRESS_03),
        /** Modbus書込み(コイル、DOへの１点書込み). */
        FUNCTION_CODE_05("05", 0x05, COMMAND_FUNCTION.FUNCTION_21),
        /** Modbus書込み(保持レジスタへの書込み). */
        FUNCTION_CODE_06("06", 0x06, COMMAND_FUNCTION.FUNCTION_22),
        /** Modbus書込み(コイル、DOへの複数書込み). */
        FUNCTION_CODE_0F("0F", 0x0F, COMMAND_FUNCTION.FUNCTION_23),
        /** Modbus書込み(保持レジスタへの複数書込み). */
        FUNCTION_CODE_10("10", 0x10, COMMAND_FUNCTION.FUNCTION_24),
        /** コマンド送信. */
        FUNCTION_CODE_50("50", 0xA0, COMMAND_FUNCTION.FUNCTION_31);

        /**
         * ファンクションコード.
         */
        private String functionCode;

        /**
         * コード.
         */
        private int code;

        /**
         * ファンクション.
         */
        private COMMAND_FUNCTION function;

        /**
         * チェック定義.
         */
        private COMMAND_CHECK.CHECK acceptCheck;

        /**
         * コンストラクタ.<BR>
         * @param _functionCode ファンクションコード
         * @param _code コード
         * @param _function ファンクション
         */
        private COMMAND_FUNCTION_CODE(final String _functionCode, final int _code, final COMMAND_FUNCTION _function) {
            this.functionCode = _functionCode;
            this.code = _code;
            this.function = _function;
        }

        /**
         * コンストラクタ.<BR>
         * @param _functionCode ファンクションコード
         * @param _code コード
         * @param _function ファンクション
         * @param _acceptCheck 分類条件
         */
        private COMMAND_FUNCTION_CODE(final String _functionCode, final int _code, final COMMAND_FUNCTION _function
                , final COMMAND_CHECK.CHECK _acceptCheck) {
            this.functionCode = _functionCode;
            this.code = _code;
            this.function = _function;
            this.acceptCheck = _acceptCheck;
        }

        /**
         * 名称マスタ 項目コードを取得.<BR>
         * @return 項目コード
         */
        public String getFunctionCode() {
            return this.functionCode;
        }

        /**
         * コードを取得.<BR>
         * @return コード(16進数)
         */
        public int getCode() {
            return this.code;
        }

        /**
         * ファンクションを取得.<BR>
         * @return ファンクション
         */
        public COMMAND_FUNCTION getFunction() {
            return this.function;
        }

        /**
         * 条件を取得.<BR>
         * @return 条件
         */
        public COMMAND_CHECK.CHECK getAcceptCheck() {
            return this.acceptCheck;
        }

        /**
         * アドレス範囲を取得.<BR>
         * @return アドレス範囲
         */
        public COMMAND_CHECK.ADDRESS getAddressRange() {
            COMMAND_CHECK.ADDRESS address = null;

            if (CM_CommonUtil.isNotNullOrBlank(this.acceptCheck) && this.acceptCheck instanceof COMMAND_CHECK.ADDRESS) {
                // アドレス範囲チェックがある場合
                address = (COMMAND_CHECK.ADDRESS) this.acceptCheck;
            } else {
                // アドレス範囲チェックがない場合は、ファンクションからアドレス範囲を取得
                for (List<COMMAND_CHECK.CHECK> checkItems : this.function.getCheck())  {
                    COMMAND_CHECK.CHECK check = checkItems.get(0);
                    if (check instanceof COMMAND_CHECK.ADDRESS) {
                        address = (COMMAND_CHECK.ADDRESS) check;
                    }
                }
            }
            return address;
        }
    }

    /**
    *
    * ファンクション種別定数.<br>
    *<br>
    * 概要:<br>
    *   ファンクション種別を表す定義
    *<br>
    *
    */
    public enum COMMAND_FUNCTION {
        /** Modbus読出(ビット). */
        FUNCTION_11("11", COMMAND_FUNCTION_TYPE.READ
                , COMMAND_CHECK.NODE_NO.NODE_NO_01, COMMAND_CHECK.ADDRESS.ADDRESS_01, COMMAND_CHECK.ADDRESS.ADDRESS_02, COMMAND_CHECK.REG_SIZE.REG_SIZE_BIT),
        /** Modbus読出. */
        FUNCTION_12("12", COMMAND_FUNCTION_TYPE.READ
                , COMMAND_CHECK.NODE_NO.NODE_NO_01, COMMAND_CHECK.ADDRESS.ADDRESS_04, COMMAND_CHECK.ADDRESS.ADDRESS_03, COMMAND_CHECK.REG_SIZE.REG_SIZE_REG),
        /** Modbus書込(ビット). */
        FUNCTION_21("21", COMMAND_FUNCTION_TYPE.WRITE
                , COMMAND_CHECK.NODE_NO.NODE_NO_02, COMMAND_CHECK.ADDRESS.ADDRESS_01, COMMAND_CHECK.VALUE.VALUE_01, COMMAND_CHECK.REG_SIZE.REG_SIZE_BIT),
        /** Modbus書込. */
        FUNCTION_22("22", COMMAND_FUNCTION_TYPE.WRITE
                , COMMAND_CHECK.NODE_NO.NODE_NO_02, COMMAND_CHECK.ADDRESS.ADDRESS_04, COMMAND_CHECK.VALUE.VALUE_02, COMMAND_CHECK.REG_SIZE.REG_SIZE_REG),
        /** Modbus書込(複数ビット). */
        FUNCTION_23("23", COMMAND_FUNCTION_TYPE.WRITE
                , COMMAND_CHECK.NODE_NO.NODE_NO_02, COMMAND_CHECK.ADDRESS.ADDRESS_01, COMMAND_CHECK.VALUE.VALUE_01, COMMAND_CHECK.REG_SIZE.REG_SIZE_BIT),
        /** Modbus書込(複数レジスタ). */
        FUNCTION_24("24", COMMAND_FUNCTION_TYPE.WRITE
                , COMMAND_CHECK.NODE_NO.NODE_NO_02, COMMAND_CHECK.ADDRESS.ADDRESS_04, COMMAND_CHECK.VALUE.VALUE_02, COMMAND_CHECK.REG_SIZE.REG_SIZE_REG),
        /** コマンド送信. */
        FUNCTION_31("31", COMMAND_FUNCTION_TYPE.COMMAND_SEND
                , COMMAND_CHECK.NODE_NO.NODE_NO_01, COMMAND_CHECK.SEND_DATA.SEND_DATA_01);

        /**
         * 名称マスタ 項目コード.
         */
        private String itemCd;

        /**
         * 実行種別.
         */
        private COMMAND_FUNCTION_TYPE type;

        /**
         * チェック定義.
         */
        private List<List<COMMAND_CHECK.CHECK>> check;

        /**
         * コンストラクタ.<BR>
         * @param _itemCd 名称マスタ 項目コード
         * @param _type 実行種別
         * @param _check チェック定義
         */
        private COMMAND_FUNCTION(final String _itemCd, final COMMAND_FUNCTION_TYPE _type
                , final COMMAND_CHECK.CHECK... _check) {
            this.itemCd = _itemCd;
            this.type = _type;

            this.check = new ArrayList<List<COMMAND_CHECK.CHECK>>();
            COMMAND_CHECK.CHECK beforeItem = null;
            List<COMMAND_CHECK.CHECK> checkList = new ArrayList<COMMAND_CHECK.CHECK>();
            this.check.add(checkList);
            for (COMMAND_CHECK.CHECK checkItem : _check) {
                if (CM_CommonUtil.isNotNullOrBlank(beforeItem)) {
                    if (checkItem.getClass().equals(beforeItem.getClass())) {
                        checkList.add(checkItem);
                    } else {
                        checkList = new ArrayList<COMMAND_CHECK.CHECK>();
                        this.check.add(checkList);
                        checkList.add(checkItem);
                    }
                } else {
                    checkList.add(checkItem);
                }
                beforeItem = checkItem;
            }
        }

        /**
         * 名称マスタ 項目コードを取得.<BR>
         * @return 項目コード
         */
        public String getItemCd() {
            return this.itemCd;
        }

        /**
         * 実行種別を取得.<BR>
         * @return 実行種別
         */
        public COMMAND_FUNCTION_TYPE getType() {
            return this.type;
        }

        /**
         * チェック定義を取得.<BR>
         * @return チェック定義
         */
        public List<List<COMMAND_CHECK.CHECK>> getCheck() {
            return this.check;
        }
    }

    /**
     * コマンド実行送信種別定義.<br>
     */
    public enum COMMAND_SEND_DATA_TYPE {
        /** ASCII. */
        ascii,
        /** バイナリ. */
        binary;
    }

    /**
    *
    * WebAPIタグ定義.<br>
    *<br>
    * 概要:<br>
    *   WebAPIで使用されるタグ名を定義
    *<br>
    *
    */
    public abstract class WEBAPI_TAG_NAME {

        /**
         * ログイン応答.
         */
        public static final String LOGIN_RESPONSE = "ns:loginResponse";

        /**
         * 結果.
         */
        public static final String RETURN = "return";
    }

    /**
    *
    * WebAPI変数定義.<br>
    *<br>
    * 概要:<br>
    *   WebAPIで使用されるパラメータ名を定義
    *<br>
    *
    */
    public abstract class WEBAPI_PARAM_NAME {

        /**
         * 認証ID.
         */
        public static final String ID = "id";

        /**
         * パスワード.
         */
        public static final String PASSWORD = "password";

        /**
         * 結果レベル.
         */
        public static final String RESULT_LEVEL = "resultLevel";

        /**
         * 結果コード.
         */
        public static final String RESULT_CODE = "resultCode";

        /**
         * 認証情報.
         */
        public static final String AUTHENTICATE_INFO = "authenticateInfo";

        /**
         * FENICS ID.
         */
        public static final String FENICS_ID = "fenicsId";

    }

    /**
    *
    * WebAPI結果レベル定義.<br>
    *<br>
    * 概要:<br>
    *   WebAPIで使用される結果レベルを定義
    *<br>
    *
    */
    public abstract class WEBAPI_RESULT_LEVEL {

        /**
         * 正常.
         */
        public static final String CORRECT = "0";

    }

    /**
    *
    * WebAPI 通信用URL置換文字列定義.<br>
    *<br>
    * 概要:<br>
    *   WebAPIで使用されるURLの置換文字列を定義
    *<br>
    *
    */
    public abstract class WEBAPI_URL_PARAM {

        /**
         * 接続先のIPアドレス、ポート番号.
         */
        public static final String API_IP_PORT = "%api_ip_port%";

        /**
         * ログイン用のID.
         */
        public static final String API_ID = "%api_id%";

        /**
         * ログイン用のパスワード.
         */
        public static final String API_PW = "%api_pw%";

        /**
         * IPアドレス.
         */
        public static final String IP_ADDRESS = "%ipAddress%";

        /**
         * ログインID.
         */
        public static final String LOGIN_ID = "%login_id%";

        /**
         * FenicsId.
         */
        public static final String FENICS_ID = "%fenicsId%";
    }

    /**
     * 集計期間.
     */
    public abstract class SUMMARY_TERM_STATUS {
        /**
         * {RAW}.
         */
        public static final String RAW = "1";
        /**
         * {1時間}.
         */
        public static final String HOUR = "2";
        /**
         * {1日}.
         */
        public static final String DAY = "3";
        /**
         * {1週間}.
         */
        public static final String WEEK = "4";
        /**
         * {1ヶ月}.
         */
        public static final String MONTH = "5";
        /**
         * {永久}.
         */
        public static final String FOREVER = "9";

    }

    /**
     *
     * 受信ファイル転送レスポンスタグ定義.<br>
     *<br>
     * 概要:<br>
     *   受信ファイル転送レスポンスタグ定義
     *<br>
     */
    public abstract class INTERNAL_TOOLS_RESPONSE_TAG {

        /**
         * 処理結果.
         */
        public static final String TAG_RESULT = "result";

        /**
         * エラーメッセージ.
         */
        public static final String TAG_ERROR_MSG = "errorMessage";

    }

    /**
     *
     * 受信ファイル転送結果.<br>
     *<br>
     * 概要:<br>
     *   受信ファイル転送結果
     *<br>
     */
    public abstract class INTERNAL_TOOLS_RESPONSE_RESULT {

        /**
         * 成功.
         */
        public static final String RESULT_SUCCESS = "success";

        /**
         * エラー.
         */
        public static final String RESULT_ERROR = "error";

    }

    /**
     * 画面表示モード.
     *
     */
    public abstract class PAGE_DISP_MODE {
        /**
         * 情報状態 - 参照(0).
         */
        public static final String MODE_DISP = "0";

        /**
         * 情報状態 - 更新(1).
         */
        public static final String MODE_UPDATE = "1";

        /**
         * 情報状態 - 新規/登録(2).
         */
        public static final String MODE_NEW = "2";

        /**
         * 情報状態 - 削除(3).
         */
        public static final String MODE_DELETE = "3";
    }

    /**
     * 製品検索モード.
     *
     */
    public abstract class PRODUCTION_SEARCH_MODE {
        /**
         * 機種群名 - 0.
         */
        public static final String KISHUGUN_NAME = "0";

        /**
         * シリーズ名 - 1.
         */
        public static final String SERIES_NAME = "1";

        /**
         * 品目コード（親品目コード） - 2.
         */
        public static final String BUHIN_CD = "2";
    }


    /**
     * 画面イベントタイプ.
     *
     */
    public abstract class PAGE_EVENT_TYPE {
        /**
         * イベント（コピー）.
         */
        public static final int EVENT_COPY = 1;

        /**
         * イベント（編集）.
         */
        public static final int EVENT_EDIT = 2;

        /**
         * イベント（登録）.
         */
        public static final int EVENT_REGIST = 3;

        /**
         * イベント（キャンセル）.
         */
        public static final int EVENT_CANCEL = 4;

        /**
         * イベント（削除）.
         */
        public static final int EVENT_DELETE = 5;
    }

    /**
     * アラーム - 状態 定義.
     */
    public abstract class ALARM_WORK_STATUS {

        /**
         * アラーム発生.
         */
        public static final int OCCUR = 1;

        /**
         * アラーム解除.
         */
        public static final int RELEASE = 0;
    }

    /**
     *
     * SQLのintervalで使用するフィールド.<br>
     *<br>
     * 概要:<br>
     *  SQLのintervalで使用するフィールド
     *<br>
     */
    public abstract class SQL_INTERVAL_FIELD {

        /**
         * ミリ秒.
         */
        public static final String MILLISECONDS = FW00_19_Const.EMPTY_STR + "milliseconds";

        /**
         * 秒.
         */
        public static final String SECOND = FW00_19_Const.EMPTY_STR + "second";

        /**
         * 分.
         */
        public static final String MINUTE = FW00_19_Const.EMPTY_STR + "minutes";

    }

    /* ********************************************/
    // 共通検索項目 プルダウン状態種別
    /* ********************************************/
    /**
    *
    * 共通検索項目 プルダウン状態種別.<br>
    *<br>
    * 概要:<br>
    *  共通検索項目のプルダウン状態種別を定義する。
    *<br>
    */
    public static enum COM_SEARCH_PLD_TYPE {
        /** 必須選択. */
        REQUIRED(false),
        /** 選択可 */
        SELECTABLE(false),
        /** 選択不可 */
        DISABLED(true);

        /** 項目有効状態. */
        private boolean disabled;

        /**
         * コンストラクタ.
         * @param _type 種別
         */
        private COM_SEARCH_PLD_TYPE(final boolean _disabled) {
            this.disabled = _disabled;
        }

        /**
         * @return disabled
         */
        public boolean isDisabled() {
            return disabled;
        }
    }

    /**
    *
    * 共通検索項目 日時選択(月次、日次、時間別)種別.<br>
    *<br>
    * 概要:<br>
    *  共通検索項目の有効状態を定義する。
    *<br>
    */
    public static enum COM_SEARCH_DATE_TYPE {
        /** 有効かつデフォルト選択. */
        DEFAULT(false),
        /** 有効. */
        SELECTABLE(false),
        /** 無効. */
        DISABLED(true);

        /** 項目有効状態. */
        private boolean disabled;

        /**
         * コンストラクタ.
         * @param _disabled 非活性フラグ
         */
        private COM_SEARCH_DATE_TYPE(final boolean _disabled) {
            this.disabled = _disabled;
        }

        /**
         * @return disabled
         */
        public boolean isDisabled() {
            return this.disabled;
        }
    }
}