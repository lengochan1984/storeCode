package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link MaHinmokuEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class MaHinmokuEntityNames {

    /**
     * createdOnのプロパティ名を返します。
     * 
     * @return createdOnのプロパティ名
     */
    public static PropertyName<Timestamp> createdOn() {
        return new PropertyName<Timestamp>("createdOn");
    }

    /**
     * createdByのプロパティ名を返します。
     * 
     * @return createdByのプロパティ名
     */
    public static PropertyName<String> createdBy() {
        return new PropertyName<String>("createdBy");
    }

    /**
     * modifiedOnのプロパティ名を返します。
     * 
     * @return modifiedOnのプロパティ名
     */
    public static PropertyName<Timestamp> modifiedOn() {
        return new PropertyName<Timestamp>("modifiedOn");
    }

    /**
     * modifiedByのプロパティ名を返します。
     * 
     * @return modifiedByのプロパティ名
     */
    public static PropertyName<String> modifiedBy() {
        return new PropertyName<String>("modifiedBy");
    }

    /**
     * invalidFlagのプロパティ名を返します。
     * 
     * @return invalidFlagのプロパティ名
     */
    public static PropertyName<Integer> invalidFlag() {
        return new PropertyName<Integer>("invalidFlag");
    }

    /**
     * matnrのプロパティ名を返します。
     * 
     * @return matnrのプロパティ名
     */
    public static PropertyName<String> matnr() {
        return new PropertyName<String>("matnr");
    }

    /**
     * mbrshのプロパティ名を返します。
     * 
     * @return mbrshのプロパティ名
     */
    public static PropertyName<String> mbrsh() {
        return new PropertyName<String>("mbrsh");
    }

    /**
     * mtartのプロパティ名を返します。
     * 
     * @return mtartのプロパティ名
     */
    public static PropertyName<String> mtart() {
        return new PropertyName<String>("mtart");
    }

    /**
     * werksのプロパティ名を返します。
     * 
     * @return werksのプロパティ名
     */
    public static PropertyName<String> werks() {
        return new PropertyName<String>("werks");
    }

    /**
     * bismtのプロパティ名を返します。
     * 
     * @return bismtのプロパティ名
     */
    public static PropertyName<String> bismt() {
        return new PropertyName<String>("bismt");
    }

    /**
     * laborのプロパティ名を返します。
     * 
     * @return laborのプロパティ名
     */
    public static PropertyName<String> labor() {
        return new PropertyName<String>("labor");
    }

    /**
     * prdhaのプロパティ名を返します。
     * 
     * @return prdhaのプロパティ名
     */
    public static PropertyName<String> prdha() {
        return new PropertyName<String>("prdha");
    }

    /**
     * mstaeのプロパティ名を返します。
     * 
     * @return mstaeのプロパティ名
     */
    public static PropertyName<String> mstae() {
        return new PropertyName<String>("mstae");
    }

    /**
     * mstdeのプロパティ名を返します。
     * 
     * @return mstdeのプロパティ名
     */
    public static PropertyName<String> mstde() {
        return new PropertyName<String>("mstde");
    }

    /**
     * mtposMaraのプロパティ名を返します。
     * 
     * @return mtposMaraのプロパティ名
     */
    public static PropertyName<String> mtposMara() {
        return new PropertyName<String>("mtposMara");
    }

    /**
     * ferthのプロパティ名を返します。
     * 
     * @return ferthのプロパティ名
     */
    public static PropertyName<String> ferth() {
        return new PropertyName<String>("ferth");
    }

    /**
     * normtのプロパティ名を返します。
     * 
     * @return normtのプロパティ名
     */
    public static PropertyName<String> normt() {
        return new PropertyName<String>("normt");
    }

    /**
     * zeinrのプロパティ名を返します。
     * 
     * @return zeinrのプロパティ名
     */
    public static PropertyName<String> zeinr() {
        return new PropertyName<String>("zeinr");
    }

    /**
     * zeiarのプロパティ名を返します。
     * 
     * @return zeiarのプロパティ名
     */
    public static PropertyName<String> zeiar() {
        return new PropertyName<String>("zeiar");
    }

    /**
     * zeivrのプロパティ名を返します。
     * 
     * @return zeivrのプロパティ名
     */
    public static PropertyName<String> zeivr() {
        return new PropertyName<String>("zeivr");
    }

    /**
     * aesznのプロパティ名を返します。
     * 
     * @return aesznのプロパティ名
     */
    public static PropertyName<String> aeszn() {
        return new PropertyName<String>("aeszn");
    }

    /**
     * blanzのプロパティ名を返します。
     * 
     * @return blanzのプロパティ名
     */
    public static PropertyName<BigDecimal> blanz() {
        return new PropertyName<BigDecimal>("blanz");
    }

    /**
     * meinsのプロパティ名を返します。
     * 
     * @return meinsのプロパティ名
     */
    public static PropertyName<String> meins() {
        return new PropertyName<String>("meins");
    }

    /**
     * matklのプロパティ名を返します。
     * 
     * @return matklのプロパティ名
     */
    public static PropertyName<String> matkl() {
        return new PropertyName<String>("matkl");
    }

    /**
     * geweiのプロパティ名を返します。
     * 
     * @return geweiのプロパティ名
     */
    public static PropertyName<String> gewei() {
        return new PropertyName<String>("gewei");
    }

    /**
     * tragrのプロパティ名を返します。
     * 
     * @return tragrのプロパティ名
     */
    public static PropertyName<String> tragr() {
        return new PropertyName<String>("tragr");
    }

    /**
     * rbnrmのプロパティ名を返します。
     * 
     * @return rbnrmのプロパティ名
     */
    public static PropertyName<String> rbnrm() {
        return new PropertyName<String>("rbnrm");
    }

    /**
     * spartのプロパティ名を返します。
     * 
     * @return spartのプロパティ名
     */
    public static PropertyName<String> spart() {
        return new PropertyName<String>("spart");
    }

    /**
     * wrkstのプロパティ名を返します。
     * 
     * @return wrkstのプロパティ名
     */
    public static PropertyName<String> wrkst() {
        return new PropertyName<String>("wrkst");
    }

    /**
     * dwerkのプロパティ名を返します。
     * 
     * @return dwerkのプロパティ名
     */
    public static PropertyName<String> dwerk() {
        return new PropertyName<String>("dwerk");
    }

    /**
     * sktofのプロパティ名を返します。
     * 
     * @return sktofのプロパティ名
     */
    public static PropertyName<String> sktof() {
        return new PropertyName<String>("sktof");
    }

    /**
     * versgのプロパティ名を返します。
     * 
     * @return versgのプロパティ名
     */
    public static PropertyName<String> versg() {
        return new PropertyName<String>("versg");
    }

    /**
     * kondmのプロパティ名を返します。
     * 
     * @return kondmのプロパティ名
     */
    public static PropertyName<String> kondm() {
        return new PropertyName<String>("kondm");
    }

    /**
     * mtposのプロパティ名を返します。
     * 
     * @return mtposのプロパティ名
     */
    public static PropertyName<String> mtpos() {
        return new PropertyName<String>("mtpos");
    }

    /**
     * prodhのプロパティ名を返します。
     * 
     * @return prodhのプロパティ名
     */
    public static PropertyName<String> prodh() {
        return new PropertyName<String>("prodh");
    }

    /**
     * mvgr1のプロパティ名を返します。
     * 
     * @return mvgr1のプロパティ名
     */
    public static PropertyName<String> mvgr1() {
        return new PropertyName<String>("mvgr1");
    }

    /**
     * mvgr2のプロパティ名を返します。
     * 
     * @return mvgr2のプロパティ名
     */
    public static PropertyName<String> mvgr2() {
        return new PropertyName<String>("mvgr2");
    }

    /**
     * mtvfpのプロパティ名を返します。
     * 
     * @return mtvfpのプロパティ名
     */
    public static PropertyName<String> mtvfp() {
        return new PropertyName<String>("mtvfp");
    }

    /**
     * ladgrのプロパティ名を返します。
     * 
     * @return ladgrのプロパティ名
     */
    public static PropertyName<String> ladgr() {
        return new PropertyName<String>("ladgr");
    }

    /**
     * prctrのプロパティ名を返します。
     * 
     * @return prctrのプロパティ名
     */
    public static PropertyName<String> prctr() {
        return new PropertyName<String>("prctr");
    }

    /**
     * mmstaのプロパティ名を返します。
     * 
     * @return mmstaのプロパティ名
     */
    public static PropertyName<String> mmsta() {
        return new PropertyName<String>("mmsta");
    }

    /**
     * dismmのプロパティ名を返します。
     * 
     * @return dismmのプロパティ名
     */
    public static PropertyName<String> dismm() {
        return new PropertyName<String>("dismm");
    }

    /**
     * dispoのプロパティ名を返します。
     * 
     * @return dispoのプロパティ名
     */
    public static PropertyName<String> dispo() {
        return new PropertyName<String>("dispo");
    }

    /**
     * dislsのプロパティ名を返します。
     * 
     * @return dislsのプロパティ名
     */
    public static PropertyName<String> disls() {
        return new PropertyName<String>("disls");
    }

    /**
     * beskzのプロパティ名を返します。
     * 
     * @return beskzのプロパティ名
     */
    public static PropertyName<String> beskz() {
        return new PropertyName<String>("beskz");
    }

    /**
     * sobslのプロパティ名を返します。
     * 
     * @return sobslのプロパティ名
     */
    public static PropertyName<String> sobsl() {
        return new PropertyName<String>("sobsl");
    }

    /**
     * dzeitのプロパティ名を返します。
     * 
     * @return dzeitのプロパティ名
     */
    public static PropertyName<BigDecimal> dzeit() {
        return new PropertyName<BigDecimal>("dzeit");
    }

    /**
     * fhoriのプロパティ名を返します。
     * 
     * @return fhoriのプロパティ名
     */
    public static PropertyName<String> fhori() {
        return new PropertyName<String>("fhori");
    }

    /**
     * eisbeのプロパティ名を返します。
     * 
     * @return eisbeのプロパティ名
     */
    public static PropertyName<BigDecimal> eisbe() {
        return new PropertyName<BigDecimal>("eisbe");
    }

    /**
     * perkzのプロパティ名を返します。
     * 
     * @return perkzのプロパティ名
     */
    public static PropertyName<String> perkz() {
        return new PropertyName<String>("perkz");
    }

    /**
     * strgrのプロパティ名を返します。
     * 
     * @return strgrのプロパティ名
     */
    public static PropertyName<String> strgr() {
        return new PropertyName<String>("strgr");
    }

    /**
     * vrmodのプロパティ名を返します。
     * 
     * @return vrmodのプロパティ名
     */
    public static PropertyName<String> vrmod() {
        return new PropertyName<String>("vrmod");
    }

    /**
     * vint1のプロパティ名を返します。
     * 
     * @return vint1のプロパティ名
     */
    public static PropertyName<BigDecimal> vint1() {
        return new PropertyName<BigDecimal>("vint1");
    }

    /**
     * vint2のプロパティ名を返します。
     * 
     * @return vint2のプロパティ名
     */
    public static PropertyName<BigDecimal> vint2() {
        return new PropertyName<BigDecimal>("vint2");
    }

    /**
     * wzeitのプロパティ名を返します。
     * 
     * @return wzeitのプロパティ名
     */
    public static PropertyName<BigDecimal> wzeit() {
        return new PropertyName<BigDecimal>("wzeit");
    }

    /**
     * sbdkzのプロパティ名を返します。
     * 
     * @return sbdkzのプロパティ名
     */
    public static PropertyName<String> sbdkz() {
        return new PropertyName<String>("sbdkz");
    }

    /**
     * fevorのプロパティ名を返します。
     * 
     * @return fevorのプロパティ名
     */
    public static PropertyName<String> fevor() {
        return new PropertyName<String>("fevor");
    }

    /**
     * sfcpfのプロパティ名を返します。
     * 
     * @return sfcpfのプロパティ名
     */
    public static PropertyName<String> sfcpf() {
        return new PropertyName<String>("sfcpf");
    }

    /**
     * losgrのプロパティ名を返します。
     * 
     * @return losgrのプロパティ名
     */
    public static PropertyName<BigDecimal> losgr() {
        return new PropertyName<BigDecimal>("losgr");
    }

    /**
     * ekgrpのプロパティ名を返します。
     * 
     * @return ekgrpのプロパティ名
     */
    public static PropertyName<String> ekgrp() {
        return new PropertyName<String>("ekgrp");
    }

    /**
     * kautbのプロパティ名を返します。
     * 
     * @return kautbのプロパティ名
     */
    public static PropertyName<String> kautb() {
        return new PropertyName<String>("kautb");
    }

    /**
     * webazのプロパティ名を返します。
     * 
     * @return webazのプロパティ名
     */
    public static PropertyName<BigDecimal> webaz() {
        return new PropertyName<BigDecimal>("webaz");
    }

    /**
     * kordbのプロパティ名を返します。
     * 
     * @return kordbのプロパティ名
     */
    public static PropertyName<String> kordb() {
        return new PropertyName<String>("kordb");
    }

    /**
     * usequのプロパティ名を返します。
     * 
     * @return usequのプロパティ名
     */
    public static PropertyName<String> usequ() {
        return new PropertyName<String>("usequ");
    }

    /**
     * mtverのプロパティ名を返します。
     * 
     * @return mtverのプロパティ名
     */
    public static PropertyName<String> mtver() {
        return new PropertyName<String>("mtver");
    }

    /**
     * disgrのプロパティ名を返します。
     * 
     * @return disgrのプロパティ名
     */
    public static PropertyName<String> disgr() {
        return new PropertyName<String>("disgr");
    }

    /**
     * maabcのプロパティ名を返します。
     * 
     * @return maabcのプロパティ名
     */
    public static PropertyName<String> maabc() {
        return new PropertyName<String>("maabc");
    }

    /**
     * minbeのプロパティ名を返します。
     * 
     * @return minbeのプロパティ名
     */
    public static PropertyName<BigDecimal> minbe() {
        return new PropertyName<BigDecimal>("minbe");
    }

    /**
     * lfrhyのプロパティ名を返します。
     * 
     * @return lfrhyのプロパティ名
     */
    public static PropertyName<String> lfrhy() {
        return new PropertyName<String>("lfrhy");
    }

    /**
     * fxhorのプロパティ名を返します。
     * 
     * @return fxhorのプロパティ名
     */
    public static PropertyName<BigDecimal> fxhor() {
        return new PropertyName<BigDecimal>("fxhor");
    }

    /**
     * bstmiのプロパティ名を返します。
     * 
     * @return bstmiのプロパティ名
     */
    public static PropertyName<BigDecimal> bstmi() {
        return new PropertyName<BigDecimal>("bstmi");
    }

    /**
     * bstmaのプロパティ名を返します。
     * 
     * @return bstmaのプロパティ名
     */
    public static PropertyName<BigDecimal> bstma() {
        return new PropertyName<BigDecimal>("bstma");
    }

    /**
     * bstfeのプロパティ名を返します。
     * 
     * @return bstfeのプロパティ名
     */
    public static PropertyName<BigDecimal> bstfe() {
        return new PropertyName<BigDecimal>("bstfe");
    }

    /**
     * rdprfのプロパティ名を返します。
     * 
     * @return rdprfのプロパティ名
     */
    public static PropertyName<String> rdprf() {
        return new PropertyName<String>("rdprf");
    }

    /**
     * bstrfのプロパティ名を返します。
     * 
     * @return bstrfのプロパティ名
     */
    public static PropertyName<BigDecimal> bstrf() {
        return new PropertyName<BigDecimal>("bstrf");
    }

    /**
     * plifzのプロパティ名を返します。
     * 
     * @return plifzのプロパティ名
     */
    public static PropertyName<BigDecimal> plifz() {
        return new PropertyName<BigDecimal>("plifz");
    }

    /**
     * fabkzのプロパティ名を返します。
     * 
     * @return fabkzのプロパティ名
     */
    public static PropertyName<String> fabkz() {
        return new PropertyName<String>("fabkz");
    }

    /**
     * lgproのプロパティ名を返します。
     * 
     * @return lgproのプロパティ名
     */
    public static PropertyName<String> lgpro() {
        return new PropertyName<String>("lgpro");
    }

    /**
     * lgfsbのプロパティ名を返します。
     * 
     * @return lgfsbのプロパティ名
     */
    public static PropertyName<String> lgfsb() {
        return new PropertyName<String>("lgfsb");
    }

    /**
     * eprioのプロパティ名を返します。
     * 
     * @return eprioのプロパティ名
     */
    public static PropertyName<String> eprio() {
        return new PropertyName<String>("eprio");
    }

    /**
     * miskzのプロパティ名を返します。
     * 
     * @return miskzのプロパティ名
     */
    public static PropertyName<String> miskz() {
        return new PropertyName<String>("miskz");
    }

    /**
     * kausfのプロパティ名を返します。
     * 
     * @return kausfのプロパティ名
     */
    public static PropertyName<BigDecimal> kausf() {
        return new PropertyName<BigDecimal>("kausf");
    }

    /**
     * matgrのプロパティ名を返します。
     * 
     * @return matgrのプロパティ名
     */
    public static PropertyName<String> matgr() {
        return new PropertyName<String>("matgr");
    }

    /**
     * qmataのプロパティ名を返します。
     * 
     * @return qmataのプロパティ名
     */
    public static PropertyName<String> qmata() {
        return new PropertyName<String>("qmata");
    }

    /**
     * taxm1のプロパティ名を返します。
     * 
     * @return taxm1のプロパティ名
     */
    public static PropertyName<String> taxm1() {
        return new PropertyName<String>("taxm1");
    }

    /**
     * alandのプロパティ名を返します。
     * 
     * @return alandのプロパティ名
     */
    public static PropertyName<String> aland() {
        return new PropertyName<String>("aland");
    }

    /**
     * maktxのプロパティ名を返します。
     * 
     * @return maktxのプロパティ名
     */
    public static PropertyName<String> maktx() {
        return new PropertyName<String>("maktx");
    }

    /**
     * revlvのプロパティ名を返します。
     * 
     * @return revlvのプロパティ名
     */
    public static PropertyName<String> revlv() {
        return new PropertyName<String>("revlv");
    }

    /**
     * raubeのプロパティ名を返します。
     * 
     * @return raubeのプロパティ名
     */
    public static PropertyName<String> raube() {
        return new PropertyName<String>("raube");
    }

    /**
     * bstmeのプロパティ名を返します。
     * 
     * @return bstmeのプロパティ名
     */
    public static PropertyName<String> bstme() {
        return new PropertyName<String>("bstme");
    }

    /**
     * ueetkのプロパティ名を返します。
     * 
     * @return ueetkのプロパティ名
     */
    public static PropertyName<String> ueetk() {
        return new PropertyName<String>("ueetk");
    }

    /**
     * lgradのプロパティ名を返します。
     * 
     * @return lgradのプロパティ名
     */
    public static PropertyName<BigDecimal> lgrad() {
        return new PropertyName<BigDecimal>("lgrad");
    }

    /**
     * schgtのプロパティ名を返します。
     * 
     * @return schgtのプロパティ名
     */
    public static PropertyName<String> schgt() {
        return new PropertyName<String>("schgt");
    }

    /**
     * lvorm1のプロパティ名を返します。
     * 
     * @return lvorm1のプロパティ名
     */
    public static PropertyName<String> lvorm1() {
        return new PropertyName<String>("lvorm1");
    }

    /**
     * lvorm2のプロパティ名を返します。
     * 
     * @return lvorm2のプロパティ名
     */
    public static PropertyName<String> lvorm2() {
        return new PropertyName<String>("lvorm2");
    }

    /**
     * tdlineのプロパティ名を返します。
     * 
     * @return tdlineのプロパティ名
     */
    public static PropertyName<String> tdline() {
        return new PropertyName<String>("tdline");
    }

    /**
     * vtextInfo1のプロパティ名を返します。
     * 
     * @return vtextInfo1のプロパティ名
     */
    public static PropertyName<String> vtextInfo1() {
        return new PropertyName<String>("vtextInfo1");
    }

    /**
     * vtextInfo2のプロパティ名を返します。
     * 
     * @return vtextInfo2のプロパティ名
     */
    public static PropertyName<String> vtextInfo2() {
        return new PropertyName<String>("vtextInfo2");
    }

    /**
     * eanCodeのプロパティ名を返します。
     * 
     * @return eanCodeのプロパティ名
     */
    public static PropertyName<String> eanCode() {
        return new PropertyName<String>("eanCode");
    }

    /**
     * gensankokuのプロパティ名を返します。
     * 
     * @return gensankokuのプロパティ名
     */
    public static PropertyName<String> gensankoku() {
        return new PropertyName<String>("gensankoku");
    }

    /**
     * gensankokuNmのプロパティ名を返します。
     * 
     * @return gensankokuNmのプロパティ名
     */
    public static PropertyName<String> gensankokuNm() {
        return new PropertyName<String>("gensankokuNm");
    }

    /**
     * erpHenkoDateのプロパティ名を返します。
     * 
     * @return erpHenkoDateのプロパティ名
     */
    public static PropertyName<Timestamp> erpHenkoDate() {
        return new PropertyName<Timestamp>("erpHenkoDate");
    }

    /**
     * spareNum1のプロパティ名を返します。
     * 
     * @return spareNum1のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum1() {
        return new PropertyName<BigDecimal>("spareNum1");
    }

    /**
     * spareNum2のプロパティ名を返します。
     * 
     * @return spareNum2のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum2() {
        return new PropertyName<BigDecimal>("spareNum2");
    }

    /**
     * spareNum3のプロパティ名を返します。
     * 
     * @return spareNum3のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum3() {
        return new PropertyName<BigDecimal>("spareNum3");
    }

    /**
     * spareText1のプロパティ名を返します。
     * 
     * @return spareText1のプロパティ名
     */
    public static PropertyName<String> spareText1() {
        return new PropertyName<String>("spareText1");
    }

    /**
     * spareText2のプロパティ名を返します。
     * 
     * @return spareText2のプロパティ名
     */
    public static PropertyName<String> spareText2() {
        return new PropertyName<String>("spareText2");
    }

    /**
     * spareText3のプロパティ名を返します。
     * 
     * @return spareText3のプロパティ名
     */
    public static PropertyName<String> spareText3() {
        return new PropertyName<String>("spareText3");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _MaHinmokuNames extends PropertyName<MaHinmokuEntity> {

        /**
         * インスタンスを構築します。
         */
        public _MaHinmokuNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _MaHinmokuNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _MaHinmokuNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * createdOnのプロパティ名を返します。
         *
         * @return createdOnのプロパティ名
         */
        public PropertyName<Timestamp> createdOn() {
            return new PropertyName<Timestamp>(this, "createdOn");
        }

        /**
         * createdByのプロパティ名を返します。
         *
         * @return createdByのプロパティ名
         */
        public PropertyName<String> createdBy() {
            return new PropertyName<String>(this, "createdBy");
        }

        /**
         * modifiedOnのプロパティ名を返します。
         *
         * @return modifiedOnのプロパティ名
         */
        public PropertyName<Timestamp> modifiedOn() {
            return new PropertyName<Timestamp>(this, "modifiedOn");
        }

        /**
         * modifiedByのプロパティ名を返します。
         *
         * @return modifiedByのプロパティ名
         */
        public PropertyName<String> modifiedBy() {
            return new PropertyName<String>(this, "modifiedBy");
        }

        /**
         * invalidFlagのプロパティ名を返します。
         *
         * @return invalidFlagのプロパティ名
         */
        public PropertyName<Integer> invalidFlag() {
            return new PropertyName<Integer>(this, "invalidFlag");
        }

        /**
         * matnrのプロパティ名を返します。
         *
         * @return matnrのプロパティ名
         */
        public PropertyName<String> matnr() {
            return new PropertyName<String>(this, "matnr");
        }

        /**
         * mbrshのプロパティ名を返します。
         *
         * @return mbrshのプロパティ名
         */
        public PropertyName<String> mbrsh() {
            return new PropertyName<String>(this, "mbrsh");
        }

        /**
         * mtartのプロパティ名を返します。
         *
         * @return mtartのプロパティ名
         */
        public PropertyName<String> mtart() {
            return new PropertyName<String>(this, "mtart");
        }

        /**
         * werksのプロパティ名を返します。
         *
         * @return werksのプロパティ名
         */
        public PropertyName<String> werks() {
            return new PropertyName<String>(this, "werks");
        }

        /**
         * bismtのプロパティ名を返します。
         *
         * @return bismtのプロパティ名
         */
        public PropertyName<String> bismt() {
            return new PropertyName<String>(this, "bismt");
        }

        /**
         * laborのプロパティ名を返します。
         *
         * @return laborのプロパティ名
         */
        public PropertyName<String> labor() {
            return new PropertyName<String>(this, "labor");
        }

        /**
         * prdhaのプロパティ名を返します。
         *
         * @return prdhaのプロパティ名
         */
        public PropertyName<String> prdha() {
            return new PropertyName<String>(this, "prdha");
        }

        /**
         * mstaeのプロパティ名を返します。
         *
         * @return mstaeのプロパティ名
         */
        public PropertyName<String> mstae() {
            return new PropertyName<String>(this, "mstae");
        }

        /**
         * mstdeのプロパティ名を返します。
         *
         * @return mstdeのプロパティ名
         */
        public PropertyName<String> mstde() {
            return new PropertyName<String>(this, "mstde");
        }

        /**
         * mtposMaraのプロパティ名を返します。
         *
         * @return mtposMaraのプロパティ名
         */
        public PropertyName<String> mtposMara() {
            return new PropertyName<String>(this, "mtposMara");
        }

        /**
         * ferthのプロパティ名を返します。
         *
         * @return ferthのプロパティ名
         */
        public PropertyName<String> ferth() {
            return new PropertyName<String>(this, "ferth");
        }

        /**
         * normtのプロパティ名を返します。
         *
         * @return normtのプロパティ名
         */
        public PropertyName<String> normt() {
            return new PropertyName<String>(this, "normt");
        }

        /**
         * zeinrのプロパティ名を返します。
         *
         * @return zeinrのプロパティ名
         */
        public PropertyName<String> zeinr() {
            return new PropertyName<String>(this, "zeinr");
        }

        /**
         * zeiarのプロパティ名を返します。
         *
         * @return zeiarのプロパティ名
         */
        public PropertyName<String> zeiar() {
            return new PropertyName<String>(this, "zeiar");
        }

        /**
         * zeivrのプロパティ名を返します。
         *
         * @return zeivrのプロパティ名
         */
        public PropertyName<String> zeivr() {
            return new PropertyName<String>(this, "zeivr");
        }

        /**
         * aesznのプロパティ名を返します。
         *
         * @return aesznのプロパティ名
         */
        public PropertyName<String> aeszn() {
            return new PropertyName<String>(this, "aeszn");
        }

        /**
         * blanzのプロパティ名を返します。
         *
         * @return blanzのプロパティ名
         */
        public PropertyName<BigDecimal> blanz() {
            return new PropertyName<BigDecimal>(this, "blanz");
        }

        /**
         * meinsのプロパティ名を返します。
         *
         * @return meinsのプロパティ名
         */
        public PropertyName<String> meins() {
            return new PropertyName<String>(this, "meins");
        }

        /**
         * matklのプロパティ名を返します。
         *
         * @return matklのプロパティ名
         */
        public PropertyName<String> matkl() {
            return new PropertyName<String>(this, "matkl");
        }

        /**
         * geweiのプロパティ名を返します。
         *
         * @return geweiのプロパティ名
         */
        public PropertyName<String> gewei() {
            return new PropertyName<String>(this, "gewei");
        }

        /**
         * tragrのプロパティ名を返します。
         *
         * @return tragrのプロパティ名
         */
        public PropertyName<String> tragr() {
            return new PropertyName<String>(this, "tragr");
        }

        /**
         * rbnrmのプロパティ名を返します。
         *
         * @return rbnrmのプロパティ名
         */
        public PropertyName<String> rbnrm() {
            return new PropertyName<String>(this, "rbnrm");
        }

        /**
         * spartのプロパティ名を返します。
         *
         * @return spartのプロパティ名
         */
        public PropertyName<String> spart() {
            return new PropertyName<String>(this, "spart");
        }

        /**
         * wrkstのプロパティ名を返します。
         *
         * @return wrkstのプロパティ名
         */
        public PropertyName<String> wrkst() {
            return new PropertyName<String>(this, "wrkst");
        }

        /**
         * dwerkのプロパティ名を返します。
         *
         * @return dwerkのプロパティ名
         */
        public PropertyName<String> dwerk() {
            return new PropertyName<String>(this, "dwerk");
        }

        /**
         * sktofのプロパティ名を返します。
         *
         * @return sktofのプロパティ名
         */
        public PropertyName<String> sktof() {
            return new PropertyName<String>(this, "sktof");
        }

        /**
         * versgのプロパティ名を返します。
         *
         * @return versgのプロパティ名
         */
        public PropertyName<String> versg() {
            return new PropertyName<String>(this, "versg");
        }

        /**
         * kondmのプロパティ名を返します。
         *
         * @return kondmのプロパティ名
         */
        public PropertyName<String> kondm() {
            return new PropertyName<String>(this, "kondm");
        }

        /**
         * mtposのプロパティ名を返します。
         *
         * @return mtposのプロパティ名
         */
        public PropertyName<String> mtpos() {
            return new PropertyName<String>(this, "mtpos");
        }

        /**
         * prodhのプロパティ名を返します。
         *
         * @return prodhのプロパティ名
         */
        public PropertyName<String> prodh() {
            return new PropertyName<String>(this, "prodh");
        }

        /**
         * mvgr1のプロパティ名を返します。
         *
         * @return mvgr1のプロパティ名
         */
        public PropertyName<String> mvgr1() {
            return new PropertyName<String>(this, "mvgr1");
        }

        /**
         * mvgr2のプロパティ名を返します。
         *
         * @return mvgr2のプロパティ名
         */
        public PropertyName<String> mvgr2() {
            return new PropertyName<String>(this, "mvgr2");
        }

        /**
         * mtvfpのプロパティ名を返します。
         *
         * @return mtvfpのプロパティ名
         */
        public PropertyName<String> mtvfp() {
            return new PropertyName<String>(this, "mtvfp");
        }

        /**
         * ladgrのプロパティ名を返します。
         *
         * @return ladgrのプロパティ名
         */
        public PropertyName<String> ladgr() {
            return new PropertyName<String>(this, "ladgr");
        }

        /**
         * prctrのプロパティ名を返します。
         *
         * @return prctrのプロパティ名
         */
        public PropertyName<String> prctr() {
            return new PropertyName<String>(this, "prctr");
        }

        /**
         * mmstaのプロパティ名を返します。
         *
         * @return mmstaのプロパティ名
         */
        public PropertyName<String> mmsta() {
            return new PropertyName<String>(this, "mmsta");
        }

        /**
         * dismmのプロパティ名を返します。
         *
         * @return dismmのプロパティ名
         */
        public PropertyName<String> dismm() {
            return new PropertyName<String>(this, "dismm");
        }

        /**
         * dispoのプロパティ名を返します。
         *
         * @return dispoのプロパティ名
         */
        public PropertyName<String> dispo() {
            return new PropertyName<String>(this, "dispo");
        }

        /**
         * dislsのプロパティ名を返します。
         *
         * @return dislsのプロパティ名
         */
        public PropertyName<String> disls() {
            return new PropertyName<String>(this, "disls");
        }

        /**
         * beskzのプロパティ名を返します。
         *
         * @return beskzのプロパティ名
         */
        public PropertyName<String> beskz() {
            return new PropertyName<String>(this, "beskz");
        }

        /**
         * sobslのプロパティ名を返します。
         *
         * @return sobslのプロパティ名
         */
        public PropertyName<String> sobsl() {
            return new PropertyName<String>(this, "sobsl");
        }

        /**
         * dzeitのプロパティ名を返します。
         *
         * @return dzeitのプロパティ名
         */
        public PropertyName<BigDecimal> dzeit() {
            return new PropertyName<BigDecimal>(this, "dzeit");
        }

        /**
         * fhoriのプロパティ名を返します。
         *
         * @return fhoriのプロパティ名
         */
        public PropertyName<String> fhori() {
            return new PropertyName<String>(this, "fhori");
        }

        /**
         * eisbeのプロパティ名を返します。
         *
         * @return eisbeのプロパティ名
         */
        public PropertyName<BigDecimal> eisbe() {
            return new PropertyName<BigDecimal>(this, "eisbe");
        }

        /**
         * perkzのプロパティ名を返します。
         *
         * @return perkzのプロパティ名
         */
        public PropertyName<String> perkz() {
            return new PropertyName<String>(this, "perkz");
        }

        /**
         * strgrのプロパティ名を返します。
         *
         * @return strgrのプロパティ名
         */
        public PropertyName<String> strgr() {
            return new PropertyName<String>(this, "strgr");
        }

        /**
         * vrmodのプロパティ名を返します。
         *
         * @return vrmodのプロパティ名
         */
        public PropertyName<String> vrmod() {
            return new PropertyName<String>(this, "vrmod");
        }

        /**
         * vint1のプロパティ名を返します。
         *
         * @return vint1のプロパティ名
         */
        public PropertyName<BigDecimal> vint1() {
            return new PropertyName<BigDecimal>(this, "vint1");
        }

        /**
         * vint2のプロパティ名を返します。
         *
         * @return vint2のプロパティ名
         */
        public PropertyName<BigDecimal> vint2() {
            return new PropertyName<BigDecimal>(this, "vint2");
        }

        /**
         * wzeitのプロパティ名を返します。
         *
         * @return wzeitのプロパティ名
         */
        public PropertyName<BigDecimal> wzeit() {
            return new PropertyName<BigDecimal>(this, "wzeit");
        }

        /**
         * sbdkzのプロパティ名を返します。
         *
         * @return sbdkzのプロパティ名
         */
        public PropertyName<String> sbdkz() {
            return new PropertyName<String>(this, "sbdkz");
        }

        /**
         * fevorのプロパティ名を返します。
         *
         * @return fevorのプロパティ名
         */
        public PropertyName<String> fevor() {
            return new PropertyName<String>(this, "fevor");
        }

        /**
         * sfcpfのプロパティ名を返します。
         *
         * @return sfcpfのプロパティ名
         */
        public PropertyName<String> sfcpf() {
            return new PropertyName<String>(this, "sfcpf");
        }

        /**
         * losgrのプロパティ名を返します。
         *
         * @return losgrのプロパティ名
         */
        public PropertyName<BigDecimal> losgr() {
            return new PropertyName<BigDecimal>(this, "losgr");
        }

        /**
         * ekgrpのプロパティ名を返します。
         *
         * @return ekgrpのプロパティ名
         */
        public PropertyName<String> ekgrp() {
            return new PropertyName<String>(this, "ekgrp");
        }

        /**
         * kautbのプロパティ名を返します。
         *
         * @return kautbのプロパティ名
         */
        public PropertyName<String> kautb() {
            return new PropertyName<String>(this, "kautb");
        }

        /**
         * webazのプロパティ名を返します。
         *
         * @return webazのプロパティ名
         */
        public PropertyName<BigDecimal> webaz() {
            return new PropertyName<BigDecimal>(this, "webaz");
        }

        /**
         * kordbのプロパティ名を返します。
         *
         * @return kordbのプロパティ名
         */
        public PropertyName<String> kordb() {
            return new PropertyName<String>(this, "kordb");
        }

        /**
         * usequのプロパティ名を返します。
         *
         * @return usequのプロパティ名
         */
        public PropertyName<String> usequ() {
            return new PropertyName<String>(this, "usequ");
        }

        /**
         * mtverのプロパティ名を返します。
         *
         * @return mtverのプロパティ名
         */
        public PropertyName<String> mtver() {
            return new PropertyName<String>(this, "mtver");
        }

        /**
         * disgrのプロパティ名を返します。
         *
         * @return disgrのプロパティ名
         */
        public PropertyName<String> disgr() {
            return new PropertyName<String>(this, "disgr");
        }

        /**
         * maabcのプロパティ名を返します。
         *
         * @return maabcのプロパティ名
         */
        public PropertyName<String> maabc() {
            return new PropertyName<String>(this, "maabc");
        }

        /**
         * minbeのプロパティ名を返します。
         *
         * @return minbeのプロパティ名
         */
        public PropertyName<BigDecimal> minbe() {
            return new PropertyName<BigDecimal>(this, "minbe");
        }

        /**
         * lfrhyのプロパティ名を返します。
         *
         * @return lfrhyのプロパティ名
         */
        public PropertyName<String> lfrhy() {
            return new PropertyName<String>(this, "lfrhy");
        }

        /**
         * fxhorのプロパティ名を返します。
         *
         * @return fxhorのプロパティ名
         */
        public PropertyName<BigDecimal> fxhor() {
            return new PropertyName<BigDecimal>(this, "fxhor");
        }

        /**
         * bstmiのプロパティ名を返します。
         *
         * @return bstmiのプロパティ名
         */
        public PropertyName<BigDecimal> bstmi() {
            return new PropertyName<BigDecimal>(this, "bstmi");
        }

        /**
         * bstmaのプロパティ名を返します。
         *
         * @return bstmaのプロパティ名
         */
        public PropertyName<BigDecimal> bstma() {
            return new PropertyName<BigDecimal>(this, "bstma");
        }

        /**
         * bstfeのプロパティ名を返します。
         *
         * @return bstfeのプロパティ名
         */
        public PropertyName<BigDecimal> bstfe() {
            return new PropertyName<BigDecimal>(this, "bstfe");
        }

        /**
         * rdprfのプロパティ名を返します。
         *
         * @return rdprfのプロパティ名
         */
        public PropertyName<String> rdprf() {
            return new PropertyName<String>(this, "rdprf");
        }

        /**
         * bstrfのプロパティ名を返します。
         *
         * @return bstrfのプロパティ名
         */
        public PropertyName<BigDecimal> bstrf() {
            return new PropertyName<BigDecimal>(this, "bstrf");
        }

        /**
         * plifzのプロパティ名を返します。
         *
         * @return plifzのプロパティ名
         */
        public PropertyName<BigDecimal> plifz() {
            return new PropertyName<BigDecimal>(this, "plifz");
        }

        /**
         * fabkzのプロパティ名を返します。
         *
         * @return fabkzのプロパティ名
         */
        public PropertyName<String> fabkz() {
            return new PropertyName<String>(this, "fabkz");
        }

        /**
         * lgproのプロパティ名を返します。
         *
         * @return lgproのプロパティ名
         */
        public PropertyName<String> lgpro() {
            return new PropertyName<String>(this, "lgpro");
        }

        /**
         * lgfsbのプロパティ名を返します。
         *
         * @return lgfsbのプロパティ名
         */
        public PropertyName<String> lgfsb() {
            return new PropertyName<String>(this, "lgfsb");
        }

        /**
         * eprioのプロパティ名を返します。
         *
         * @return eprioのプロパティ名
         */
        public PropertyName<String> eprio() {
            return new PropertyName<String>(this, "eprio");
        }

        /**
         * miskzのプロパティ名を返します。
         *
         * @return miskzのプロパティ名
         */
        public PropertyName<String> miskz() {
            return new PropertyName<String>(this, "miskz");
        }

        /**
         * kausfのプロパティ名を返します。
         *
         * @return kausfのプロパティ名
         */
        public PropertyName<BigDecimal> kausf() {
            return new PropertyName<BigDecimal>(this, "kausf");
        }

        /**
         * matgrのプロパティ名を返します。
         *
         * @return matgrのプロパティ名
         */
        public PropertyName<String> matgr() {
            return new PropertyName<String>(this, "matgr");
        }

        /**
         * qmataのプロパティ名を返します。
         *
         * @return qmataのプロパティ名
         */
        public PropertyName<String> qmata() {
            return new PropertyName<String>(this, "qmata");
        }

        /**
         * taxm1のプロパティ名を返します。
         *
         * @return taxm1のプロパティ名
         */
        public PropertyName<String> taxm1() {
            return new PropertyName<String>(this, "taxm1");
        }

        /**
         * alandのプロパティ名を返します。
         *
         * @return alandのプロパティ名
         */
        public PropertyName<String> aland() {
            return new PropertyName<String>(this, "aland");
        }

        /**
         * maktxのプロパティ名を返します。
         *
         * @return maktxのプロパティ名
         */
        public PropertyName<String> maktx() {
            return new PropertyName<String>(this, "maktx");
        }

        /**
         * revlvのプロパティ名を返します。
         *
         * @return revlvのプロパティ名
         */
        public PropertyName<String> revlv() {
            return new PropertyName<String>(this, "revlv");
        }

        /**
         * raubeのプロパティ名を返します。
         *
         * @return raubeのプロパティ名
         */
        public PropertyName<String> raube() {
            return new PropertyName<String>(this, "raube");
        }

        /**
         * bstmeのプロパティ名を返します。
         *
         * @return bstmeのプロパティ名
         */
        public PropertyName<String> bstme() {
            return new PropertyName<String>(this, "bstme");
        }

        /**
         * ueetkのプロパティ名を返します。
         *
         * @return ueetkのプロパティ名
         */
        public PropertyName<String> ueetk() {
            return new PropertyName<String>(this, "ueetk");
        }

        /**
         * lgradのプロパティ名を返します。
         *
         * @return lgradのプロパティ名
         */
        public PropertyName<BigDecimal> lgrad() {
            return new PropertyName<BigDecimal>(this, "lgrad");
        }

        /**
         * schgtのプロパティ名を返します。
         *
         * @return schgtのプロパティ名
         */
        public PropertyName<String> schgt() {
            return new PropertyName<String>(this, "schgt");
        }

        /**
         * lvorm1のプロパティ名を返します。
         *
         * @return lvorm1のプロパティ名
         */
        public PropertyName<String> lvorm1() {
            return new PropertyName<String>(this, "lvorm1");
        }

        /**
         * lvorm2のプロパティ名を返します。
         *
         * @return lvorm2のプロパティ名
         */
        public PropertyName<String> lvorm2() {
            return new PropertyName<String>(this, "lvorm2");
        }

        /**
         * tdlineのプロパティ名を返します。
         *
         * @return tdlineのプロパティ名
         */
        public PropertyName<String> tdline() {
            return new PropertyName<String>(this, "tdline");
        }

        /**
         * vtextInfo1のプロパティ名を返します。
         *
         * @return vtextInfo1のプロパティ名
         */
        public PropertyName<String> vtextInfo1() {
            return new PropertyName<String>(this, "vtextInfo1");
        }

        /**
         * vtextInfo2のプロパティ名を返します。
         *
         * @return vtextInfo2のプロパティ名
         */
        public PropertyName<String> vtextInfo2() {
            return new PropertyName<String>(this, "vtextInfo2");
        }

        /**
         * eanCodeのプロパティ名を返します。
         *
         * @return eanCodeのプロパティ名
         */
        public PropertyName<String> eanCode() {
            return new PropertyName<String>(this, "eanCode");
        }

        /**
         * gensankokuのプロパティ名を返します。
         *
         * @return gensankokuのプロパティ名
         */
        public PropertyName<String> gensankoku() {
            return new PropertyName<String>(this, "gensankoku");
        }

        /**
         * gensankokuNmのプロパティ名を返します。
         *
         * @return gensankokuNmのプロパティ名
         */
        public PropertyName<String> gensankokuNm() {
            return new PropertyName<String>(this, "gensankokuNm");
        }

        /**
         * erpHenkoDateのプロパティ名を返します。
         *
         * @return erpHenkoDateのプロパティ名
         */
        public PropertyName<Timestamp> erpHenkoDate() {
            return new PropertyName<Timestamp>(this, "erpHenkoDate");
        }

        /**
         * spareNum1のプロパティ名を返します。
         *
         * @return spareNum1のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum1() {
            return new PropertyName<BigDecimal>(this, "spareNum1");
        }

        /**
         * spareNum2のプロパティ名を返します。
         *
         * @return spareNum2のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum2() {
            return new PropertyName<BigDecimal>(this, "spareNum2");
        }

        /**
         * spareNum3のプロパティ名を返します。
         *
         * @return spareNum3のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum3() {
            return new PropertyName<BigDecimal>(this, "spareNum3");
        }

        /**
         * spareText1のプロパティ名を返します。
         *
         * @return spareText1のプロパティ名
         */
        public PropertyName<String> spareText1() {
            return new PropertyName<String>(this, "spareText1");
        }

        /**
         * spareText2のプロパティ名を返します。
         *
         * @return spareText2のプロパティ名
         */
        public PropertyName<String> spareText2() {
            return new PropertyName<String>(this, "spareText2");
        }

        /**
         * spareText3のプロパティ名を返します。
         *
         * @return spareText3のプロパティ名
         */
        public PropertyName<String> spareText3() {
            return new PropertyName<String>(this, "spareText3");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
