package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 作業STEP実績
 * 
 */
@Entity
@Table(name = "tr_work_step_jsk")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class TrWorkStepJskEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 登録日時 */
    @Column(nullable = true, unique = false)
    public Timestamp createdOn;

    /** 登録者 */
    @Column(length = 32, nullable = true, unique = false)
    public String createdBy;

    /** 更新日時 */
    @Column(nullable = true, unique = false)
    public Timestamp modifiedOn;

    /** 更新者 */
    @Column(length = 32, nullable = true, unique = false)
    public String modifiedBy;

    /** 指図番号 */
    @Id
    @Column(length = 12, nullable = false, unique = false)
    public String sasizuNo;

    /** 指図追番 */
    @Id
    @Column(precision = 5, nullable = false, unique = false)
    public BigDecimal subNo;

    /** 作業順序 */
    @Id
    @Column(length = 6, nullable = false, unique = false)
    public String sagyoSeq;

    /** ステーションID */
    @Id
    @Column(precision = 8, nullable = false, unique = false)
    public BigDecimal stId;

    /** 作業STEP */
    @Id
    @Column(length = 8, nullable = false, unique = false)
    public String stepNo;

    /** 生産開始時刻 */
    @Id
    @Column(nullable = false, unique = false)
    public Timestamp startTime;

    /** 生産完了時刻 */
    @Column(nullable = true, unique = false)
    public Timestamp endTime;

    /** 作業時間(msec） */
    @Column(precision = 11, nullable = true, unique = false)
    public BigDecimal workTime;

    /** プラントコード */
    @Column(length = 10, nullable = true, unique = false)
    public String plantCd;

    /** 製造ラインコード */
    @Column(length = 10, nullable = true, unique = false)
    public String seizouLnCd;

    /** 製造ライン名 */
    @Column(length = 64, nullable = true, unique = false)
    public String seizouLnNm;

    /** 工程コード */
    @Column(length = 5, nullable = true, unique = false)
    public String processCd;

    /** 工程名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String processNm;

    /** ラインNo */
    @Column(length = 32, nullable = true, unique = false)
    public String lnNo;

    /** ライン名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String lnNm;

    /** ステーションNo */
    @Column(length = 8, nullable = true, unique = false)
    public String stNo;

    /** ステーション名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String stNm;

    /** 作業区 */
    @Column(length = 8, nullable = true, unique = false)
    public String sagyoku;

    /** 設備プログラム番号 */
    @Column(length = 32, nullable = true, unique = false)
    public String pgmNo;

    /** ユーザID */
    @Column(length = 16, nullable = true, unique = false)
    public String userId;

    /** 器具符号 */
    @Column(length = 20, nullable = true, unique = false)
    public String kiguFugou;

    /** 部材 */
    @Column(length = 60, nullable = true, unique = false)
    public String partsMaterial;

    /** 部品コード */
    @Column(length = 20, nullable = true, unique = false)
    public String partsCode;

    /** 部品シリアルNO */
    @Column(length = 36, nullable = true, unique = false)
    public String partSn;

    /** トルクセンサー */
    @Column(length = 20, nullable = true, unique = false)
    public String torqueId;

    /** 締めトルク回数 */
    @Column(precision = 5, nullable = true, unique = false)
    public BigDecimal torqueCount;

    /** トルク指令回数 */
    @Column(precision = 5, nullable = true, unique = false)
    public BigDecimal torqueNeedCount;

    /** 試験DEV */
    @Column(length = 20, nullable = true, unique = false)
    public String testDevice;

    /** 試験DEV結果 */
    @Column(length = 20, nullable = true, unique = false)
    public String testDeviceRst;

    /** チェックBOX結果 */
    @Column(length = 20, nullable = true, unique = false)
    public String checkBox;

    /** 現在棚センサー */
    @Column(length = 60, nullable = true, unique = false)
    public String senserNow;

    /** 次の棚センサー */
    @Column(length = 60, nullable = true, unique = false)
    public String senserNext;

    /** ログ種別ID */
    @Column(length = 8, nullable = true, unique = false)
    public String logTypeId;

    /** 作業ログ付加情報 */
    @Column(length = 255, nullable = true, unique = false)
    public String logData;

    /** 作業モード */
    @Column(precision = 1, nullable = true, unique = false)
    public BigDecimal sagyoMode;

    /** 数字予備1 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum1;

    /** 数字予備2 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum2;

    /** 数字予備3 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum3;

    /** 文字予備1 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText1;

    /** 文字予備2 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText2;

    /** 文字予備3 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText3;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
