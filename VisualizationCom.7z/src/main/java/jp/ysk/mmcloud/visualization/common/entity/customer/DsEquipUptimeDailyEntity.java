package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * [サイネージ用]設備稼働時間(日別)
 * 
 */
@Entity
@Table(name = "ds_equip_uptime_daily")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class DsEquipUptimeDailyEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** ステーションID */
    @Id
    @Column(precision = 8, nullable = false, unique = false)
    public BigDecimal stId;

    /** データ日時 */
    @Id
    @Column(nullable = false, unique = false)
    public Timestamp dataDate;

    /** 設備状態 */
    @Id
    @Column(precision = 5, nullable = false, unique = false)
    public Short equipSts;

    /** 稼働時間 */
    @Column(precision = 10, nullable = true, unique = false)
    public Integer uptime;

    /** プラントコード */
    @Column(length = 10, nullable = true, unique = false)
    public String plantCd;

    /** 製造ラインコード */
    @Column(length = 10, nullable = true, unique = false)
    public String seizouLnCd;

    /** 製造ライン名 */
    @Column(length = 64, nullable = true, unique = false)
    public String seizouLnNm;

    /** 工程コード */
    @Column(length = 5, nullable = true, unique = false)
    public String processCd;

    /** 工程名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String processNm;

    /** ラインNo */
    @Column(length = 32, nullable = true, unique = false)
    public String lnNo;

    /** ライン名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String lnNm;

    /** ステーションNo */
    @Column(length = 8, nullable = true, unique = false)
    public String stNo;

    /** ステーション名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String stNm;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
