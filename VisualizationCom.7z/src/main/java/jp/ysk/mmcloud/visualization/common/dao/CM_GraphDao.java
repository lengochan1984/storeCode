/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/10/03| <C1.01>　新規作成                                                    | C1.01  | US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.dao;

import java.util.List;
import java.util.Map;

import org.seasar.framework.beans.util.BeanMap;

/**
 * グラフ画面共通Dao.<br>
 *<br>
 * 概要:<br>
 *   顧客スキーマのDBにアクセスするための一覧画面共通Daoクラス
 *<br>
 */
public abstract class CM_GraphDao extends CM_ListBaseDao {


    /**
     *
     * 一覧件数取得.<br>
     *<br>
     * 概要:<br>
     *   一覧の件数取得
     *<br>
     * @param _formInfo  Form情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return データ件数
     */
    public long selectListCount(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        return 0;
    }

    /**
     *
     * グラフ表示データ一覧取得.<br>
     *<br>
     * 概要:<br>
     *    検索条件に該当する一覧の件数を取得する
     *<br>
     * @param _formInfo  Form情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return データ一覧
     */
    public abstract List<?> selectList(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo);

}
