package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 工程マスタ
 * 
 */
@Entity
@Table(name = "ma_process")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class MaProcessEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 登録日時 */
    @Column(nullable = true, unique = false)
    public Timestamp createdOn;

    /** 登録者 */
    @Column(length = 32, nullable = true, unique = false)
    public String createdBy;

    /** 更新日時 */
    @Column(nullable = true, unique = false)
    public Timestamp modifiedOn;

    /** 更新者 */
    @Column(length = 32, nullable = true, unique = false)
    public String modifiedBy;

    /** 無効フラグ */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer invalidFlag;

    /** 工程ID */
    @Id
    @Column(precision = 8, nullable = false, unique = true)
    public BigDecimal processId;

    /** 工程コード */
    @Column(length = 5, nullable = false, unique = false)
    public String processCd;

    /** 工程名称 */
    @Column(length = 64, nullable = false, unique = false)
    public String processNm;

    /** 工程順序 */
    @Column(precision = 5, nullable = true, unique = false)
    public Short processSeq;

    /** 順不同ｸﾞﾙｰﾌﾟ識別子 */
    @Column(length = 2, nullable = false, unique = false)
    public String randSeqGr;

    /** ﾏﾙﾁﾗｲﾝｸﾞﾙｰﾌﾟ識別子 */
    @Column(length = 2, nullable = false, unique = false)
    public String multiLnGr;

    /** 製造ラインID */
    @Column(precision = 8, nullable = false, unique = false)
    public BigDecimal seizouLnId;

    /** 数字予備1 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum1;

    /** 数字予備2 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum2;

    /** 数字予備3 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum3;

    /** 文字予備1 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText1;

    /** 文字予備2 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText2;

    /** 文字予備3 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText3;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
