/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+=======================================+========+==============
 *  DATE      | Comments                              | Rev    | SIGN
 * ===========+=======================================+========+==============
 *  2014/04/19| 新規作成                              | 1.00.00| YSK)鬼丸
 *  2014/09/29| <10101-015> 点検保守状況画面追加      | 1.02.00| YSK)中田
 *  2014/12/11| <20000-006> 変更仕様一覧No.18         | 3.00.00| YSK)中田
 *  2014/12/15| <20000-019> 変更仕様No.13             | 3.00.00| YSK)中田
 *  2014/12/17| <20000-005> 変更仕様No.11             | 3.00.00| YSK)中田
 *  2014/12/21| <20000-026> 仕様変更No.9              | 3.00.00| YSK)中田
 *  2015/04/27| <30003-012> 故障苦情No.30003-009      | 3.01.00| US)萩尾
 *  2015/05/13| <30003-019> 変更仕様No.7              | 3.01.00| US)楢崎
 *  2015/07/08| <30003-037> 変更仕様No.23             | 3.01.00| US)楢崎
 *  2015/12/15| <40000-025> Ver.4.00.00 変更仕様No.25 | 4.00.00| US)楢崎
 *  2015/12/22| <40000-025> Ver.4.00.00 変更仕様No.25 | 4.00.00| US)萩尾
 *  2016/01/04| <40000-027> Ver.4.00.00 変更仕様No.27 | 4.00.00| US)萩尾
 *  2016/01/21| <40000-028> 変更仕様No.28             | 4.00.00| US)安永
 *  2016/01/26| <40000-028> Ver.4.00.00 変更仕様No.28 | 4.00.00| US)清水
 *  2016/08/10| <C1.01>作業区状況モニタ対応           | C1.01  | US)萩尾
 *  2016/08/11| <C1.01> 不具合分析画面 対応           | C1.01  | US)楢崎
 * -----------+---------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.ysk.mmcloud.common.entity.customer.MstAlarmEntity;
import jp.ysk.mmcloud.common.entity.customer.MstAlarmEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstCommandEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstDataPointEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstDeviceEntity;
import jp.ysk.mmcloud.common.entity.customer.MstDeviceEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstDeviceStatusSettingEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstDistributeDataEntity;
import jp.ysk.mmcloud.common.entity.customer.MstDistributeDataEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstDistributeDataVersionEntity;
import jp.ysk.mmcloud.common.entity.customer.MstDistributeDataVersionEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstEventConvertEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstGroupEntity;
import jp.ysk.mmcloud.common.entity.customer.MstGroupEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstMainteStatusEntity;
import jp.ysk.mmcloud.common.entity.customer.MstMainteStatusEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstModelEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstProfileEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstTrendViewEntity;
import jp.ysk.mmcloud.common.entity.customer.MstTrendViewEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstUserEntity;
import jp.ysk.mmcloud.common.entity.customer.MstUserEntityNames;
import jp.ysk.mmcloud.common.entity.customer.RelDeviceGroupEntityNames;
import jp.ysk.mmcloud.common.entity.customer.RelModelGroupEntityNames;
import jp.ysk.mmcloud.common.entity.customer.RelModelIconEntity;
import jp.ysk.mmcloud.common.entity.customer.RelModelIconEntityNames;
import jp.ysk.mmcloud.common.entity.customer.RelUserGroupEntityNames;
import jp.ysk.mmcloud.common.entity.customer.RelUserRoleEntityNames;
import jp.ysk.mmcloud.common.entity.customer.TblDistributeStatusEntity;
import jp.ysk.mmcloud.common.entity.customer.TblDistributeStatusEntityNames;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaHinmokuEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaLineEntityNames;
//import jp.ysk.mmcloud.visualization.common.entity.customer.MstLineGroupEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantMierukaEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantMierukaEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaProcessEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaProcessEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaSeizouLineEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaUserEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaUserEntityNames;

import org.seasar.extension.jdbc.where.SimpleWhere;
import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.beans.util.Beans;

/**
 * 環境マスタ処理Dao.<br>
 * <br>
 * 概要:<br>
 * 環境マスタのDBアクセスを実行する <br>
 */
public class CM_GetMstDataDao extends CM_BaseDao {

    /**
     * コンストラクタ.
     */
    public CM_GetMstDataDao() {
        super();
    }

    /**
     * コンストラクタ.
     *
     * @param _strConnectString
     *            顧客DB接続情報
     * @param _strConnectUserId
     *            顧客DBユーザID
     * @param _strConnectPasswd
     *            顧客DBパスワード
     */
    public CM_GetMstDataDao(final String _strConnectString,
            final String _strConnectUserId, final String _strConnectPasswd) {
        super(_strConnectString, _strConnectUserId, _strConnectPasswd);
    }

//    /**
//     *
//     * 役割マスタ情報取得処理.<br>
//     * <br>
//     * 概要:<br>
//     * 役割マスタ情報を取得する <br>
//     *
//     * @return 役割マスタ情報
//     */
//    public List<MstRoleEntity> getMstRoleList() {
//        OrderByItem displayOrder = new OrderByItem(
//                MstRoleEntityNames.displayOrder(), OrderingSpec.ASC);
//        OrderByItem roleName = new OrderByItem(MstRoleEntityNames.roleName(),
//                OrderingSpec.ASC);
//        return this.jdbcManager.from(MstRoleEntity.class)
//                .where("delete_flag <> 'true'").orderBy(displayOrder, roleName)
//                .getResultList();
//    }
//
//    /**
//     *
//     * 役割マスタ情報（ユーザ公開対象限定）取得処理.<br>
//     * <br>
//     * 概要:<br>
//     * 役割マスタ情報（ユーザ公開対象限定）を取得する <br>
//     *
//     * @return 役割マスタ情報
//     */
//    public List<MstRoleEntity> getMstRolePublishList() {
//        OrderByItem displayOrder = new OrderByItem(
//                MstRoleEntityNames.displayOrder(), OrderingSpec.ASC);
//        OrderByItem roleName = new OrderByItem(MstRoleEntityNames.roleName(),
//                OrderingSpec.ASC);
//        return this.jdbcManager
//                .from(MstRoleEntity.class)
//                .where("delete_flag <> 'true' AND publish_flag = ? ",
//                        CM_A04_Const.PUBLISH_FLAG_KIND.PUBLISH_ON)
//                .orderBy(displayOrder, roleName).getResultList();
//    }

    /**
     *
     * ユーザマスタ情報取得処理.<br>
     * <br>
     * 概要:<br>
     * ユーザマスタ情報を取得する <br>
     *
     * @return ユーザマスタ情報
     */
    public List<MstUserEntity> getMstUserList() {
        return this.jdbcManager.from(MstUserEntity.class)
                .where("delete_flag <> 'true'")
                .orderBy("user_lastname, user_firstname, sid").getResultList();
    }

    /**
     *
     * 機器マスタ情報取得処理.<br>
     * <br>
     * 概要:<br>
     * 機器マスタ情報を取得する <br>
     *
     * @return 機器マスタ情報
     */
    public List<MstDeviceEntity> getMstDeviceList() {
        return this.jdbcManager.from(MstDeviceEntity.class)
                .where("delete_flag <> 'true'").orderBy("name, sid")
                .getResultList();
    }

    /**
     *
     * 対象機器の情報取得.<br>
     * <br>
     * 概要:<br>
     * 検索対象の機器情報を取得する。 <br>
     *
     * @param _deviceSid
     *            機器SID
     * @return 機器情報
     */
    public BeanMap selectMachineInfo(final int _deviceSid) {

        // 該当機器SIDのデータを取得する
        List<MstDeviceEntity> listEntity = this.jdbcManager
                .from(MstDeviceEntity.class).where("sid = ?", _deviceSid)
                .getResultList();
        if (CM_CommonUtil.isNullOrEmpty(listEntity)) {
            return null;
        }

        BeanMap bm = Beans.createAndCopy(BeanMap.class, listEntity.get(0))
                .execute();

        return bm;
    }

    /**
     *
     * 対象SIDの型番情報取得.<br>
     * <br>
     * 概要:<br>
     * 対象SIDの型番データを取得する。 <br>
     *
     * @param _sid
     *            型番SID
     * @return 対象SIDのデータ
     */
    public BeanMap selectModelInfo(final int _sid) {

        CM_LoggerUtil.outputDaoInputParamLog("_sid", _sid);

        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectModelInfo.sql";

        BeanMap param = new BeanMap();
        param.put(MstModelEntityNames.sid().toString(), _sid);

        BeanMap bm = this.jdbcManager.selectBySqlFile(BeanMap.class, path,
                param).getSingleResult();

        CM_LoggerUtil.outputDaoOutputParamLog(bm);

        return bm;
    }

    /**
     *
     * グループマスタ情報取得処理.<br>
     * <br>
     * 概要:<br>
     * グループマスタ情報を取得する <br>
     *
     * @return グループマスタ情報
     */
    public List<MstGroupEntity> getMstGroupList() {
        return this.jdbcManager.from(MstGroupEntity.class)
                .where("delete_flag <> 'true'").orderBy("display_order")
                .getResultList();
    }

    /**
     *
     * グループツリー情報取得処理.<br>
     * <br>
     * 概要:<br>
     * グループツリー情報を取得する <br>
     *
     * @param _userSid
     *            ユーザSID
     * @return グループツリー情報
     */
    public List<BeanMap> getGroupTreeInfoList(final int _userSid) {

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();
        param.put(MstUserEntityNames.sid().toString(), _userSid);
        String path = CM_BaseCustomerSchemaDao.SQL_PATH
                + "A000000/SelectGroupTreeInfoList.sql";

        // データの抽出
        return this.jdbcManager.selectBySqlFile(BeanMap.class, path, param)
                .getResultList();
    }

    /**
     *
     * 親グループツリー情報取得処理.<br>
     * <br>
     * 概要:<br>
     * 親グループツリー情報を取得する <br>
     *
     * @param _strGroupIdList
     *            親グループID
     * @return 親グループツリー情報
     */
    public List<BeanMap> getParentGroupTreeInfoList(
            final String[] _strGroupIdList) {

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();
        param.put(MstGroupEntityNames.groupId().toString(), _strGroupIdList);
        String path = CM_BaseCustomerSchemaDao.SQL_PATH
                + "A000000/SelectParentGroupTreeInfoList.sql";

        // データの抽出
        return this.jdbcManager.selectBySqlFile(BeanMap.class, path, param)
                .getResultList();
    }

    /**
     *
     * 機器名称リスト取得.<br>
     * <br>
     * 概要:<br>
     * 機器名称とSIDのリストを取得する <br>
     *
     * @param _loginUserSid
     *            ログインユーザのSID
     * @return 機器名称リスト
     */
    public List<BeanMap> getDeviceNameList(final int _loginUserSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_loginUserSid", _loginUserSid);

        // データの抽出
        BeanMap param = new BeanMap();
        param.put(CM_A04_Const.SQL_PARAM.LOGIN_USER_SID, _loginUserSid);

        // TODO 仕様変更によりグループに複数所属可能になった場合は、SQLの見直しが必要
        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(
                BeanMap.class,
                CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                        + "selectDeviceNameList.sql", param).getResultList();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * 製品名称リスト取得.<br>
     * <br>
     * 概要:<br>
     * 製品名称と工場コードのリストを取得する <br>
     *
     * @param _plantCode 工場コード
     *
     * @return 製品名称リスト
     */
    public List<BeanMap> getSeiHinNameList(final String _plantCode) {

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();

        // パラメータのセット
        String paramName = CM_A04_Const.SQL_PARAM.PLANT_CODE;
        param.put(paramName, _plantCode);
        param.put(paramName, _plantCode);
        param.put(paramName, _plantCode);
        // SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstHinmokuInfo.sql";

        // データの抽出
        return this.jdbcManager.selectBySqlFile(BeanMap.class, path, param)
                .getResultList();

    }

   /**
   *
   * 工場名称リスト取得.<br>
   *<br>
   * 概要:<br>
   *   工場名称と工場コードのリストを取得する
   *<br>
   * @return 工場名称リスト
     * @param _userSid ユーザーSID
   */
    public List<BeanMap> getMstPlantNameList(final Integer _userSid) {

        return getMstPlantNameListCore(false, _userSid);
    }

    /**
    *
    * 物理的工場名称リスト取得.<br>
    *<br>
    * 概要:<br>
    *   マスタに登録されている全ての工場名称と工場コードのリストを取得する.<br>
    *   論理削除データを含む.
    *<br>
    * @return 工場名称リスト
    */
    public List<BeanMap> getPhysicalMstPlantNameList() {
        return getMstPlantNameListCore(true, null);
    }

    /**
     *
     * 工場名称リスト取得.<br>
     *<br>
     * 概要:<br>
     *   工場名称と工場コードのリストを取得する
     *<br>
     * @param _isPhysical 物理データ取得判断
     * @param _userSid ユーザーSID
     * @return 工場名称リスト
     */
    private List<BeanMap> getMstPlantNameListCore(final boolean _isPhysical, final Integer _userSid) {

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("isPhysical", _isPhysical);
        param.put("userSid", _userSid);
        param.put("allBaseAuth", CM_A04_Const.ALL_BASE_AUTH);

        //SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstPlantInfo.sql";

        // データの抽出
        return this.jdbcManager.selectBySqlFile(BeanMap.class, path, param)
              .getResultList();
    }

    /**
     *
     * ライン名称リスト取得.<br>
     *<br>
     * 概要:<br>
     *   ライン名称とコード値のリストを取得する
     *<br>
     * @param _plantCode 工場コード
     * @return ライン名称リスト
     */
    public List<BeanMap> getMstLineGroupNameList(final String _plantCode) {

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();

        // パラメータのセット
        String paramName = CM_A04_Const.SQL_PARAM.PLANT_CODE;
        param.put(paramName, _plantCode);
        //SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstLineGroupInfo.sql";

        // データの抽出
        return this.jdbcManager.selectBySqlFile(BeanMap.class, path, param)
             .getResultList();
    }

    /**
    *
    * ライン名称リスト取得.<br>
    *<br>
    * 概要:<br>
    *   ライン名称とコード値のリストを取得する
    *<br>
    * @param _plantCode 工場コード
    * @param _seizouLnId 製造ライン（グループ）
    * @return ライン名称リスト
    */
    public List<BeanMap> getMstLineNameList(final String _plantCode, final Long _seizouLnId, final Long _processId) {

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();

        // パラメータのセット 工場
        String paramName;
        paramName = CM_A04_Const.SQL_PARAM.PLANT_CODE;
        param.put(paramName, _plantCode);

        // パラメータのセット 製造ライン（グループ）
        paramName = CM_A04_Const.SQL_PARAM.SEIZOU_LN_ID;
        param.put(paramName, _seizouLnId);

        // パラメータのセット 工程
        paramName = CM_A04_Const.SQL_PARAM.PROCESS_ID;
        param.put(paramName, _processId);

        //SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstLineInfo.sql";

        // データの抽出
        return this.jdbcManager.selectBySqlFile(BeanMap.class, path, param)
             .getResultList();
    }

    /**
    *
    * ライン名称リスト取得.<br>
    *<br>
    * 概要:<br>
    *   ライン名称とコード値のリストを取得する
    *<br>
    * @param _plantCode 工場コード
    * @param _seizouLnId 製造ライン（グループ）
    * @return ライン名称リスト
    */
    public List<BeanMap> getMstLineList(final String _plantCode, final Long _seizouLnId, final Long _processId, final Long _lineId) {

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();

        // パラメータのセット 工場
        String paramName;
        paramName = CM_A04_Const.SQL_PARAM.PLANT_CODE;
        param.put(paramName, _plantCode);

        // パラメータのセット 製造ライン（グループ）
        paramName = CM_A04_Const.SQL_PARAM.SEIZOU_LN_ID;
        param.put(paramName, _seizouLnId);

        // パラメータのセット 工程
        paramName = CM_A04_Const.SQL_PARAM.PROCESS_ID;
        param.put(paramName, _processId);

        // パラメータのセット ライン
        paramName = CM_A04_Const.SQL_PARAM.LN_ID;
        param.put(paramName, _lineId);

        //SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstLineList.sql";

        // データの抽出
        return this.jdbcManager.selectBySqlFile(BeanMap.class, path, param)
             .getResultList();
    }

    /**
     *
     * 設備名称リスト取得.<br>
     *<br>
     * 概要:<br>
     *   設備名称とコード値のリストを取得する
     *<br>
     * @param _plantCode 工場コード
     * @param _condLnId ラインID
     * @return 設備名称リスト
     */
    public List<BeanMap> getMstEquipmentNameList(final String _plantCode, final String _condLnId) {

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();

        // パラメータのセット
        param.put(MaPlantEntityNames.plantCd().toString(), _plantCode);
        String condLnId = null;
        if (CM_CommonUtil.isNotNullOrBlank(_condLnId)) {
            condLnId = _condLnId;
        }
        param.put(MaLineEntityNames.lnId().toString(), condLnId);

        //SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstEquipmentInfo.sql";

        // データの抽出
        return this.jdbcManager.selectBySqlFile(BeanMap.class, path, param)
             .getResultList();
    }

    /**
    *
    * 機種群名リスト取得.<br>
    *<br>
    * 概要:<br>
    *  機種群名のリストを取得する
    *<br>
    * @param _plantCode 工場コード
    * @return 機種群名リスト
    */
    public List<BeanMap> getMstModelGroupNameList(final String _plantCode) {

        List<BeanMap> ret = new ArrayList<BeanMap>();

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();

        // パラメータのセット
        param.put(MaPlantEntityNames.plantCd().toString(), _plantCode);

        //SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstModelGroup.sql";

        // データの抽出
        ret = this.jdbcManager.selectBySqlFile(BeanMap.class, path, param).getResultList();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * ライン名称リスト取得(製品別画面専用).<br>
     * <br>
     * 概要:<br>
     * ライン名称とコード値のリストを取得する <br>
     *
     * @param _plantCode
     *            工場コード
     * @return ライン名称リスト
     */
    public List<BeanMap> getTblLineGroupPulldownNameList(final String _plantCode) {

        List<BeanMap> ret = new ArrayList<BeanMap>();

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();

        // パラメータのセット
        String paramName = CM_A04_Const.SQL_PARAM.PLANT_CODE;
        param.put(paramName, _plantCode);
        // SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectTblLineGroupPulldownInfo.sql";

        // データの抽出
        ret = this.jdbcManager.selectBySqlFile(BeanMap.class, path, param).getResultList();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * TKNファイル名一覧取得.<br>
     *<br>
     * 概要:<br>
     *  TKNファイル名一覧取得処理
     *<br>
     * @return TKNファイル名一覧
     */
    public List<BeanMap> getMstWorkStepTknFileNameList() {
        CM_LoggerUtil.outputDaoInputParamLog();

        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstWorkStepTknFileNameList.sql";

        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(BeanMap.class, path).getResultList();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * 機器名称リスト（削除済機器含む）取得.<br>
     * <br>
     * 概要:<br>
     * 機器名称とSIDのリスト（削除済機器含む）を取得する <br>
     *
     * @param _loginUserSid
     *            ログインユーザのSID
     * @return 機器名称リスト（削除済機器含む）
     */
    public List<BeanMap> getDeviceNameListIncludeDeleted(final int _loginUserSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_loginUserSid", _loginUserSid);

        // データの抽出
        BeanMap param = new BeanMap();
        param.put(CM_A04_Const.SQL_PARAM.LOGIN_USER_SID, _loginUserSid);

        // TODO 仕様変更によりグループに複数所属可能になった場合は、SQLの見直しが必要
        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(
                BeanMap.class,
                CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                        + "selectDeviceNameListIncludeDeleted.sql", param)
                .getResultList();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * 機器名称リストデータ取得処理.<br>
     * <br>
     * 概要:<br>
     * 機器名称リストデータを取得する <br>
     *
     * @param _loginUserSid
     *            ログインユーザSID
     * @param _includeDeleted
     *            削除機器を含めるか
     * @param _modelSid
     *            nullでなければ、型番SIDに紐づく機器名称リストを取得する <br>
     * @return 機器名称リスト
     */
    public List<BeanMap> selectDeviceNameList(final int _loginUserSid,
            final boolean _includeDeleted, final Integer _modelSid) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_loginUserSid", _loginUserSid);
        CM_LoggerUtil
                .outputDaoInputParamLog("_includeDeleted", _includeDeleted);
        CM_LoggerUtil.outputDaoInputParamLog("_modelSid", _modelSid);

        // データの抽出
        BeanMap param = new BeanMap();
        param.put(CM_A04_Const.SQL_PARAM.LOGIN_USER_SID, _loginUserSid);
        param.put("includeDeleted", _includeDeleted);
        param.put(MstDeviceEntityNames.modelSid().toString(), _modelSid);

        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(BeanMap.class,
                SQL_PATH_COMM + "selectDeviceNameListByModelSid.sql", param)
                .getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);
        return ret;
    }

    /**
     *
     * 機器名称リストデータ取得処理（型番SID、グループIDでの絞込みあり）.<br>
     * <br>
     * 概要:<br>
     * 機器名称リストデータを取得する <br>
     *
     * @param _modelSid
     *            型番SID
     * @param _groupId
     *            グループID
     * @param _userSid
     *            ログインユーザSID <br>
     * @return 機器名称リスト
     */
    public List<BeanMap> selectDeviceNameListByModelSidGroupId(
            final Integer _modelSid, final String _groupId, final int _userSid) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_modelSid", _modelSid);
        CM_LoggerUtil.outputDaoInputParamLog("_groupId", _groupId);
        CM_LoggerUtil.outputDaoInputParamLog("_userSid", _userSid);

        // データの抽出
        BeanMap param = new BeanMap();
        param.put("userSid", _userSid);
        param.put(MstModelEntityNames.sid().toString(), _modelSid);
        if (!CM_CommonUtil.isNullOrBlank(_groupId)) {
            param.put(RelDeviceGroupEntityNames.groupId().toString(), _groupId);
        }

        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(BeanMap.class,
                SQL_PATH_COMM + "selectDeviceNameListByModelSidGroupId.sql",
                param).getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);
        return ret;
    }

    /**
     *
     * 機器名称リストデータ取得処理（型番SID、グループパス配下での絞込みあり）.<br>
     * <br>
     * 概要:<br>
     * 機器名称リストデータを取得する <br>
     *
     * @param _modelSid
     *            型番SID
     * @param _groupPath
     *            グループパス
     * @param _userSid
     *            ログインユーザSID <br>
     * @return 機器名称リスト
     */
    public List<BeanMap> selectDeviceNameListByModelSidGroupPath(
            final Integer _modelSid, final String _groupPath,
            final Integer _userSid) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_modelSid", _modelSid);
        CM_LoggerUtil.outputDaoInputParamLog("_groupPath", _groupPath);
        CM_LoggerUtil.outputDaoInputParamLog("_userSid", _userSid);

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();
        param.put(RelUserGroupEntityNames.userSid().toString(), _userSid);
        param.put(MstDeviceEntityNames.modelSid().toString(), _modelSid);
        param.put(MstGroupEntityNames.treePath().toString(), _groupPath);
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectDeviceNameListByModelSidGroupPath.sql";

        // データの抽出
        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(BeanMap.class,
                path, param).getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * 型番名称リストデータ取得処理.<br>
     * <br>
     * 概要:<br>
     * 型番名称リストデータを取得する <br>
     *
     * @param _profileRelated
     *            プロファイル連結済みデータ限定フラグ（true:限定する、false:全て）
     * @param _loginUserSid
     *            ログインユーザSID
     * @param _includeDeleted
     *            削除済み対象フラグ(true:含む、false：含まない)
     * @param _deviceRelated
     *            機器に紐づく型番連結フラグ（true:連結する、false:連結しない）
     * @return 型番名称リスト
     */
    public List<BeanMap> selectModelNameList(final boolean _profileRelated,
            final Integer _loginUserSid, final boolean _includeDeleted,
            final boolean _deviceRelated) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_isProfileRelated",
                _profileRelated);
        CM_LoggerUtil.outputDaoInputParamLog("_loginUserSid", _loginUserSid);
        CM_LoggerUtil
                .outputDaoInputParamLog("_includeDeleted", _includeDeleted);
        CM_LoggerUtil.outputDaoInputParamLog("_deviceRelated", _deviceRelated);

        BeanMap param = new BeanMap();
        param.put("profileRelated", _profileRelated);
        param.put(CM_A04_Const.SQL_PARAM.LOGIN_USER_SID, _loginUserSid);
        param.put("includeDeleted", _includeDeleted);
        param.put("deviceRelated", _deviceRelated);

        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(BeanMap.class,
                SQL_PATH_COMM + "selectModelNameListDeviceGroup.sql", param)
                .getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);
        return ret;
    }

    /**
     *
     * 型番SID取得処理.<br>
     * <br>
     * 概要:<br>
     * 機器SIDに紐づく型番SIDを取得する <br>
     *
     * @param _deviceSid
     *            機器SID
     * @return 型番ID
     */
    public String getModelSid(final String _deviceSid) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_deviceSid", _deviceSid);

        MstDeviceEntity ret = this.jdbcManager
                .from(MstDeviceEntity.class)
                .where(new SimpleWhere().eq(MstDeviceEntityNames.sid(),
                        _deviceSid)).getSingleResult();

        if (ret != null) {
            // メソッド出力ログ出力
            CM_LoggerUtil.outputDaoOutputParamLog(ret);
            return ret.modelSid.toString();
        }

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(null);
        return null;
    }

//    /**
//     * 役割情報取得処理.<br>
//     * <br>
//     * 概要:<br>
//     * <br>
//     *
//     * @param _roleSid
//     *            役割SID
//     * @return 役割情報データ
//     */
//    public BeanMap selectMstRoleInfo(final Integer _roleSid) {
//        // メソッド開始ログ出力
//        CM_LoggerUtil.outputDaoInputParamLog("_roleSid", _roleSid);
//
//        MstRoleEntity listEntity = this.jdbcManager
//                .from(MstRoleEntity.class)
//                .where(new SimpleWhere().eq(MstRoleEntityNames.sid(), _roleSid))
//                .getSingleResult();
//
//        BeanMap bm = Beans.createAndCopy(BeanMap.class, listEntity).execute();
//
//        // メソッド出力ログ出力
//        CM_LoggerUtil.outputDaoOutputParamLog(bm);
//
//        return bm;
//    }

    /**
     * 指定された役割を使用している一般ユーザ数を取得する.<br>
     * <br>
     * 概要:<br>
     * <br>
     *
     * @param _roleSid
     *            役割SID
     * @return 指定された役割に紐づく一般ユーザ数
     */
    public long countUserListByRole(final Integer _roleSid) {
        CM_LoggerUtil.outputDaoInputParamLog("_roleSid", _roleSid);

        // DB更新処理
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "countUserListByRole.sql";

        BeanMap param = new BeanMap();
        param.put(RelUserRoleEntityNames.roleSid().toString(), _roleSid);

        // DB更新処理
        long cnt = this.jdbcManager.getCountBySqlFile(path, param);

        CM_LoggerUtil.outputDaoOutputParamLog(cnt);

        return cnt;
    }

    /**
     *
     * 配信データ名称リストデータ取得処理.<br>
     * <br>
     * 概要:<br>
     * 配信データ名称リストデータを取得する <br>
     *
     * @param _modelSid
     *            型番SID <br>
     * @return 配信データ名称リスト
     */
    public List<BeanMap> selectDistributionDataNameListByModelSid(
            final Integer _modelSid) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_modelSid", _modelSid);

        // データの抽出
        BeanMap param = new BeanMap();
        param.put(MstDistributeDataEntityNames.modelSid().toString(), _modelSid);

        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(BeanMap.class,
                SQL_PATH_COMM + "selectDistributionDataNameListByModelSid.sql",
                param).getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);
        return ret;
    }

    /**
     *
     * 配信データバージョンリストデータ取得処理.<br>
     * <br>
     * 概要:<br>
     * 配信データバージョンリストデータを取得する <br>
     *
     * @param _distSid
     *            配信データSID <br>
     * @return 配信データ名称リスト
     */
    public List<BeanMap> selectDistributionDataVersionList(
            final Integer _distSid) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_distSid", _distSid);

        // データの抽出
        BeanMap param = new BeanMap();
        param.put(MstDistributeDataVersionEntityNames.distributeDataSid()
                .toString(), _distSid);

        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(BeanMap.class,
                SQL_PATH_COMM + "selectDistributionDataVersionList.sql", param)
                .getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);
        return ret;
    }

    /**
     *
     * 機器に対するグループIDおよびグループ情報（ツリーパス名称、グループ名称）取得処理.<br>
     * <br>
     * 概要:<br>
     * 機器に対するグループIDおよびグループ情報（ツリーパス名称、グループ名称）取得を取得する <br>
     *
     * @param _deviceSid
     *            機器SID
     * @return グループ情報MAP
     */
    public BeanMap getGroupInfoForDeviceSid(final int _deviceSid) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_deviceSid", _deviceSid);

        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectGroupInfoForDeviceSid.sql";

        BeanMap param = new BeanMap();
        param.put(RelDeviceGroupEntityNames.deviceSid().toString(), _deviceSid);

        BeanMap bm = this.jdbcManager.selectBySqlFile(BeanMap.class, path,
                param).getSingleResult();

        CM_LoggerUtil.outputDaoOutputParamLog(bm);

        return bm;
    }

    /**
     *
     * 型番に対するグループIDおよびグループ情報（ツリーパス、ツリーパス名称、グループ名称）取得処理.<br>
     * <br>
     * 概要:<br>
     *
     * @param _modelSid
     *            型番SID
     * @return グループ情報MAP
     */
    public BeanMap getGroupInfoForModelSid(final int _modelSid) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_modelSid", _modelSid);

        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectGroupInfoForModelSid.sql";

        BeanMap param = new BeanMap();
        param.put(RelModelGroupEntityNames.modelSid().toString(), _modelSid);

        BeanMap bm = this.jdbcManager.selectBySqlFile(BeanMap.class, path,
                param).getSingleResult();

        CM_LoggerUtil.outputDaoOutputParamLog(bm);

        return bm;
    }

    /**
     *
     * 型番に対するグループIDおよびグループ情報（ツリーパス、ツリーパス名称、グループ名称）取得処理.<br>
     * <br>
     * 概要:<br>
     *
     * @param _profileSid
     *            通信プロファイルSID
     * @return グループ情報MAP
     */
    public BeanMap getGroupInfoForProfileSid(final int _profileSid) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_profileSid", _profileSid);

        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectGroupInfoForProfileSid.sql";

        BeanMap param = new BeanMap();
        param.put(MstProfileEntityNames.sid().toString(), _profileSid);

        BeanMap bm = this.jdbcManager.selectBySqlFile(BeanMap.class, path,
                param).getSingleResult();

        CM_LoggerUtil.outputDaoOutputParamLog(bm);

        return bm;
    }

    /**
     * グループ情報取得処理.<br>
     * <br>
     * 概要:<br>
     * <br>
     *
     * @param _groupId
     *            グループID
     * @return グループ情報
     */
    public MstGroupEntity getGroupInfo(final String _groupId) {
        CM_LoggerUtil.outputDaoInputParamLog("_groupId", _groupId);

        MstGroupEntity entity = this.jdbcManager
                .from(MstGroupEntity.class)
                .where(new SimpleWhere().eq(MstGroupEntityNames.groupId(),
                        _groupId).eq(MstGroupEntityNames.deleteFlag(), false))
                .getSingleResult();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(entity);
        return entity;
    }

    /**
     *
     * システム管理者権限ユーザ数取得.<br>
     * <br>
     * 概要:<br>
     * 指定したユーザID以外のシステム管理者権限のユーザ数を取得する<br>
     *
     * @param _id
     *            ユーザID
     * @return システム管理者権限ユーザ数
     */
    public long selectAdminUserNum(final String _id) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_id", _id);

        // SQLパラメータ作成
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("user_id", _id);
        param.put("authcd", CM_A04_Const.SYS_ADMIN_AUTH_CD);

        // ユーザ数をカウント
        long ret = this.jdbcManager.getCountBySqlFile(
                CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                        + "selectSystemGroupUserList.sql", param);

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * ユーザマスタ情報取得.<br>
     * <br>
     * 概要:<br>
     * SIDを元にユーザマスタ情報を取得 <br>
     *
     * @param _sid
     *            ユーザSID
     * @return ユーザマスタ情報
     */
    public MstUserEntity getMstUserInfo(final Integer _sid) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_sid", _sid);

        MstUserEntity ret = this.jdbcManager.from(MstUserEntity.class)
                .where(new SimpleWhere().eq(MstUserEntityNames.sid(), _sid))
                .getSingleResult();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * コマンドSID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 通信プロファイルに紐付くコマンドSIDを取得する。 <br/>
     *
     * @param _profileSid
     *            通信プロファイルSID
     * @return コマンドSIDリスト
     */
    public List<Integer> getCommandSidList(final Integer _profileSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_profileSid", _profileSid);

        // 検索条件の設定
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectCommandSidList.sql";
        BeanMap param = new BeanMap();
        param.put(MstCommandEntityNames.profileSid().toString(), _profileSid);

        // 検索実行
        List<Integer> ret = this.jdbcManager.selectBySqlFile(Integer.class,
                path, param).getResultList();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * データポイントSID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 通信コマンドに紐付くデータポイントSIDを取得する。 <br/>
     *
     * @param _commandSidList
     *            コマンドSIDリスト
     * @return データポイントSIDリスト
     */
    public List<Integer> getDataPointSidList(final List<Integer> _commandSidList) {

        // メソッド開始ログ出力
        CM_LoggerUtil
                .outputDaoInputParamLog("_commandSidList", _commandSidList);

        // 検索条件の設定
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectDatapointSidList.sql";
        BeanMap param = new BeanMap();
        param.put(MstDataPointEntityNames.commandSid().toString(),
                _commandSidList);

        // 検索実行
        List<Integer> ret = this.jdbcManager.selectBySqlFile(Integer.class,
                path, param).getResultList();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * イベント変換SID取得.<br/>
     * <br/>
     * 概要:<br/>
     * データポイントに紐付くイベント変換SIDを取得する。 <br/>
     *
     * @param _datapointSidList
     *            データポイントSIDリスト
     * @return イベント変換SIDリスト
     */
    public List<Integer> getEventConvertSidList(
            final List<Integer> _dataPointSidList) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_dataPointSidList",
                _dataPointSidList);

        // 検索条件の設定
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectEventConvertSidList.sql";
        BeanMap param = new BeanMap();
        param.put(MstEventConvertEntityNames.dataPointSid().toString(),
                _dataPointSidList);

        // 検索実行
        List<Integer> ret = this.jdbcManager.selectBySqlFile(Integer.class,
                path, param).getResultList();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * 稼動状態SID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 通信プロファイルに紐付く稼動状態SIDを取得する。 <br/>
     *
     * @param _profileSid
     *            通信プロファイルSID
     * @return 稼動状態SIDリスト
     */
    public List<Integer> getDeviceStatusSidList(final Integer _profileSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_profileSid", _profileSid);

        // 検索条件の設定
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectDeviceStatusSidList.sql";
        BeanMap param = new BeanMap();
        param.put(MstCommandEntityNames.profileSid().toString(), _profileSid);

        // 検索実行
        List<Integer> ret = this.jdbcManager.selectBySqlFile(Integer.class,
                path, param).getResultList();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * 状態値設定SID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 稼動状態に紐付く状態値設定SIDを取得する。 <br/>
     *
     * @param _deviceStatusSidList
     *            稼動状態SIDリスト
     * @return 状態値設定SIDリスト
     */
    public List<Integer> getDeviceStatusSettingSidList(
            final List<Integer> _deviceStatusSidList) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_deviceStatusSidList",
                _deviceStatusSidList);

        // 検索条件の設定
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectDeviceStatusSettingSidList.sql";
        BeanMap param = new BeanMap();
        param.put(MstDeviceStatusSettingEntityNames.mstDeviceStatusSid()
                .toString(), _deviceStatusSidList);

        // 検索実行
        List<Integer> ret = this.jdbcManager.selectBySqlFile(Integer.class,
                path, param).getResultList();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * トレンドビューSID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 通信プロファイルに紐付くトレンドビューSIDを取得する。 <br/>
     *
     * @param _profileSid
     *            通信プロファイルSID
     * @return トレンドビューSIDリスト
     */
    public List<Integer> getTrendViewSidList(final Integer _profileSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_profileSid", _profileSid);

        // 検索条件の設定
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectTrendViewSidList.sql";
        BeanMap param = new BeanMap();
        param.put(MstCommandEntityNames.profileSid().toString(), _profileSid);

        // 検索実行
        List<Integer> ret = this.jdbcManager.selectBySqlFile(Integer.class,
                path, param).getResultList();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * アラームSID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 通信プロファイルに紐付くアラームSIDを取得する。 <br/>
     *
     * @param _profileSid
     *            通信プロファイルSID
     * @return アラームSIDリスト
     */
    public List<Integer> getAlarmSidList(final Integer _profileSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_profileSid", _profileSid);

        // 検索条件の設定
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectAlarmSidList.sql";
        BeanMap param = new BeanMap();
        param.put(MstCommandEntityNames.profileSid().toString(), _profileSid);

        // 検索実行
        List<Integer> ret = this.jdbcManager.selectBySqlFile(Integer.class,
                path, param).getResultList();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * 配信データSID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 型番に紐付く配信データSIDを取得する。 <br/>
     *
     * @param _modelSid
     *            型番SID
     * @return 配信データSIDリスト
     */
    public List<Integer> getDistributeDataSidList(final Integer _modelSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_modelSid", _modelSid);

        // 検索条件の設定
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectDistributeDataSidList.sql";
        BeanMap param = new BeanMap();
        param.put(MstDistributeDataEntityNames.modelSid().toString(), _modelSid);

        // 検索実行
        List<Integer> ret = this.jdbcManager.selectBySqlFile(Integer.class,
                path, param).getResultList();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * 配信データバージョン取得.<br/>
     * <br/>
     * 概要:<br/>
     * 配信データSIDに紐付く配信データバージョンを取得する。 <br/>
     *
     * @param _distributeDataSidList
     *            配信データSIDリスト
     * @return 配信データバージョンリスト
     */
    public List<MstDistributeDataVersionEntity> getDistributeDataVersionList(
            final List<Integer> _distributeDataSidList) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_distributeDataSidList",
                _distributeDataSidList);

        // 検索実行
        List<MstDistributeDataVersionEntity> ret = this.jdbcManager
                .from(MstDistributeDataVersionEntity.class)
                .where(new SimpleWhere().in(
                        MstDistributeDataVersionEntityNames.distributeDataSid(),
                        _distributeDataSidList)).getResultList();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * アラームアイコンデータ取得処理.<br/>
     * <br/>
     * 概要:<br/>
     * 指定された型番に紐付くアラームアイコンデータを取得する。 <br/>
     *
     * @param _modelSid
     *            型番SID
     * @return アラームアイコンデータ
     */
    public List<RelModelIconEntity> getAlarmIconData(final Integer _modelSid) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_modelSid", _modelSid);

        // 項目CDの生成
        List<RelModelIconEntity> ret = this.jdbcManager
                .from(RelModelIconEntity.class)
                .where(new SimpleWhere().eq(RelModelIconEntityNames.modelSid(),
                        _modelSid)).getResultList();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * プロファイルに紐付くアラーム条件の件数を取得する.
     *
     * @param _profileSid
     *            プロファイルSID
     * @return プロファイルに紐付くアラーム条件数
     */
    public long getRelProfileAlarmCnt(final Integer _profileSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_profileSid", _profileSid);

        // 検索実行
        long ret = this.jdbcManager
                .from(MstAlarmEntity.class)
                .where(new SimpleWhere().eq(MstAlarmEntityNames.profileSid(),
                        _profileSid)).getCount();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * プロファイルに紐付くイベント変換情報の件数を取得する.
     *
     * @param _profileSid
     *            プロファイルSID
     * @return イベント変換情報の件数
     */
    public long getRelProfileEventCnt(final Integer _profileSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_profileSid", _profileSid);

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();
        param.put(MstCommandEntityNames.profileSid().toString(), _profileSid);
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectEventConvertListByProfileSid.sql";

        // 検索実行
        long ret = this.jdbcManager.getCountBySqlFile(path, param);

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * プロファイルに紐付くトレンドビューの件数を取得する.
     *
     * @param _profileSid
     *            プロファイルSID
     * @return プロファイルに紐付くトレンドビュー数
     */
    public long getRelProfileTrendCnt(final Integer _profileSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_profileSid", _profileSid);

        // 検索実行
        long ret = this.jdbcManager
                .from(MstTrendViewEntity.class)
                .where(new SimpleWhere().eq(
                        MstTrendViewEntityNames.profileSid(), _profileSid))
                .getCount();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * 型番に紐付く配信データの件数を取得する.
     *
     * @param _modelSid
     *            型番SID
     * @return 型番に紐付く配信データ数
     */
    public long getRelModelDistributeCnt(final Integer _modelSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_modelSid", _modelSid);

        // 検索実行
        long ret = this.jdbcManager
                .from(MstDistributeDataEntity.class)
                .where(new SimpleWhere().eq(
                        MstDistributeDataEntityNames.modelSid(), _modelSid))
                .getCount();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;

    }

    /**
     * 機器に紐付く報告書の数を取得.
     *
     * @param _deviceSid
     *            機器SID
     * @return 機器に紐付く報告書数
     */
    public long getRelDeviceReportCnt(final Integer _deviceSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_deviceSid", _deviceSid);

        // 検索実行
        long ret = this.jdbcManager
                .from(MstMainteStatusEntity.class)
                .where(new SimpleWhere().eq(MstMainteStatusEntityNames.deviceSid(), _deviceSid))
                .getCount();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;

    }

    /**
     * 機器に紐付く配信状況の件数を取得.
     *
     * @param _deviceSid
     *            機器SID
     * @return 機器に紐付く配信状況件数
     */
    public long getRelDeviceDistributeStatusCnt(final Integer _deviceSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_deviceSid", _deviceSid);

        // 検索実行
        long ret = this.jdbcManager
                .from(TblDistributeStatusEntity.class)
                .where(new SimpleWhere().eq(TblDistributeStatusEntityNames.deviceSid(), _deviceSid))
                .getCount();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;

    }

    /**
     * 配信データ情報を取得する.<br/>
     * <br/>
     * 概要:<br/>
     *   配信データマスタ情報を取得する。 <br/>
     * @param _sid 配信データSID
     * @return 配信データマスタ情報
     */
    public MstDistributeDataEntity getMstDistributeData(final Integer _sid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_sid", _sid);

        // 検索実行
        MstDistributeDataEntity ret = this.jdbcManager
                .from(MstDistributeDataEntity.class)
                .where(new SimpleWhere().eq(
                        MstDistributeDataEntityNames.sid().toString(), _sid))
                .getSingleResult();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * 型番とアイコンタイプに関連するアイコン情報を取得.
     *
     * @param _modelSid
     *            型番SID
     * @param _iconType
     *            アイコンタイプ
     * @return アイコン情報
     */
    public RelModelIconEntity getRelModelIconEntity(final Integer _modelSid,
            final String _iconType) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_modelSid", _modelSid);
        CM_LoggerUtil.outputDaoInputParamLog("_iconType", _iconType);

        RelModelIconEntity ret = this.jdbcManager
                .from(RelModelIconEntity.class)
                .where(new SimpleWhere().eq(
                        RelModelIconEntityNames.modelSid().toString(),
                        _modelSid).eq(
                        RelModelIconEntityNames.iconType().toString(),
                        _iconType)).getSingleResult();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * 機器SIDに関連するアイコン情報リストを取得.
     *
     * @param _deviceSid
     *            機器SID
     * @return アイコン情報リスト
     */
    public List<RelModelIconEntity> getRelModelIconListByDeviceSid(final Integer _deviceSid) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_deviceSid", _deviceSid);

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();
        param.put(MstDeviceEntityNames.sid().toString(), _deviceSid);
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectRelModelIconListByDeviceSid.sql";

        // 検索実行
        List<RelModelIconEntity> ret = this.jdbcManager.selectBySqlFile(RelModelIconEntity.class, path, param).getResultList();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * 使用量取得.<br>
     * <br>
     * 概要:<br>
     * ディスク使用量を取得する. <br>
     *
     * @return 使用量
     */
    public Integer  getAmountUsed() {

        BeanMap param = new BeanMap();

        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM
                + "selectAmountUsed.sql";

        // データの抽出
        Integer amountUsed = this.jdbcManager.selectBySqlFile(Integer.class, path , param).getSingleResult();

        CM_LoggerUtil.outputDaoOutputParamLog(amountUsed);

        return amountUsed;
    }

    /**
     *
     * 機器マスタ件数取得.<br>
     * <br>
     * 概要:<br>
     * 機器マスタの件数を取得する. <br>
     *
     * @return カウント結果
     */
    public long getDeviceCount() {

        // 機器マスタ件数取得（論理削除は含まない）
        long ret =  this.jdbcManager.from(MstDeviceEntity.class).where(
                new SimpleWhere().eq(MstDeviceEntityNames.deleteFlag(), false)).getCount();

        return ret;
    }

    /**
     *
     * 工場マスタ取得.<br>
     *<br>
     * 概要:<br>
     *  工場マスタ取得処理
     *<br>
     * @param _plantCode 工場コード
     * @return
     */
    public MaPlantEntity getPlantEntity(final String _plantCode) {
        CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);

        SimpleWhere where = new SimpleWhere();
        where.eq(MaPlantEntityNames.plantCd().toString(),_plantCode);

        MaPlantEntity ret = this.jdbcManager.from(MaPlantEntity.class).where(where).getSingleResult();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * 工場マスタ(見える化専用)取得.<br>
     *<br>
     * 概要:<br>
     *  工場マスタ(見える化専用)取得処理
     *<br>
     * @param _plantCode 工場コード
     * @return
     */
    public MaPlantMierukaEntity getPlantMierukaEntity(final String _plantCode) {
        CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);

        SimpleWhere where = new SimpleWhere();
        where.eq(MaPlantMierukaEntityNames.plantCd().toString(),_plantCode);

        MaPlantMierukaEntity ret = this.jdbcManager.from(MaPlantMierukaEntity.class).where(where).getSingleResult();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * 工程マスタ取得.<br>
     *<br>
     * 概要:<br>
     * 工程マスタ取得処理
     *<br>
     * @param _processId 工程ID
     * @return 工程マスタ
     */
    public MaProcessEntity getProcessEntity(final Long _processId) {
        CM_LoggerUtil.outputDaoInputParamLog("_processId", _processId);
        SimpleWhere where = new SimpleWhere();
        where.eq(MaProcessEntityNames.processId(), _processId);

        MaProcessEntity ret = this.jdbcManager.from(MaProcessEntity.class).where(where).getSingleResult();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * 製品名称取得.<br>
     * <br>
     * 概要:<br>
     * 製品プルダウンに表示される製品名を取得
     *
     * @param _plantCode 工場コード
     * @param _productId 製品ID(製品プルダウンのvalue値)
     * @return 製品名称
     */
    public String getDispProductName(final String _plantCode, final String _productId) {

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();

        // パラメータのセット
        param.put(MaHinmokuEntityNames.werks().toString(), _plantCode);
        param.put(CM_A04_Const.SQL_PARAM.PARAM_PRODUCT_ID, _productId);
        // SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectDispHinmokuName.sql";

        String ret = this.jdbcManager.selectBySqlFile(String.class, path, param).getSingleResult();

        // データの抽出
        return ret;
    }

    /**
     *
     * ライン名称取得.<br>
     *<br>
     * 概要:<br>
     *   ラインプルダウンに表示されるライン名称を取得する
     *<br>
     * @param _plantCode 工場コード
     * @param _lnId ラインID(ラインプルダウンのvalue値)
     * @return ライン名称
     */
    public String getDispLineGroupName(final String _plantCode, final Long _lnId) {

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();

        // パラメータのセット
//        param.put(MstLineGroupEntityNames.plantCode().toString(), _plantCode);
//        param.put(MaSeizouLineEntityNames.lnId().toString(), _lnId);
        param.put(MaSeizouLineEntityNames.plantCd().toString(), _plantCode);
        param.put(MaLineEntityNames.lnId().toString(), _lnId);

        //SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectDispLineGroupName.sql";

        String ret = this.jdbcManager.selectBySqlFile(String.class, path, param).getSingleResult();

        // データの抽出
        return ret;
    }


    /**
     *
     * 製造ライン名称リスト取得.<br>
     *<br>
     * 概要:<br>
     *   製造ラインのリストを取得する
     *<br>
     * @param _plantCode 工場コード
     * @return 製造ライン名称リスト
     */
    public List<BeanMap> getMstSeizouLineNameList(final String _plantCode) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);

        //SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstSeizouLineNameList.sql";

        // データの抽出
        List<BeanMap> res = this.jdbcManager.selectBySqlFile(BeanMap.class, path, _plantCode)
                .getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(res);

        return res;
    }

    /**
    *
    * 製造ライン名称リスト取得（未来生産負荷状況用）.<br>
    *<br>
    * 概要:<br>
    *   製造ラインのリストを取得する
    *<br>
    * @param _plantCode 工場コード
    * @return 製造ライン名称リスト
    */
   public List<BeanMap> getMstSeizouLineNameListForMirai(final String _plantCode) {
       // メソッド開始ログ出力
       CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);

       //SQLの生成する
       String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstSeizouLineNameListForMirai.sql";

       // データの抽出
       List<BeanMap> res = this.jdbcManager.selectBySqlFile(BeanMap.class, path, _plantCode)
               .getResultList();

       // メソッド出力ログ出力
       CM_LoggerUtil.outputDaoOutputParamLog(res);

       return res;
   }

    /**
     *
     * 機種カテゴリ名称リスト取得.<br>
     * <br>
     * 概要:<br>
     * 機種カテゴリ名称のリストを取得する <br>
     *
     * @param _plantCode
     *            工場コード
     * @return 機種カテゴリ名称名称リスト
     */
    public List<BeanMap> getMstKishuCtlgNameList(final String _plantCode) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);

        // SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstErpModelGroupCategoryInfo.sql";

        // データの抽出
        List<BeanMap> res = this.jdbcManager.selectBySqlFile(BeanMap.class, path, _plantCode).getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(res);

        return res;
    }

    /**
    *
    * 工程ID取得.<br>
    *<br>
    * 概要:<br>
    *   工程IDを取得する
    *<br>
    * @param _plantCode 工場コード
    * @param _seizouLnId 製造ラインID
    * @param _lineId ラインID
    * @return 工程ID
    */
    public List<BeanMap> getMstProcessId(final String _plantCode, final Long _seizouLnId, final Long _lineId) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);
        CM_LoggerUtil.outputDaoInputParamLog("_seizouLnId", _seizouLnId);
        CM_LoggerUtil.outputDaoInputParamLog("_lineId", _lineId);

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();

        // パラメータのセット
        String paramName = CM_A04_Const.SQL_PARAM.PLANT_CODE;
        // 工場コード
        param.put(paramName, _plantCode);
        // 製造ラインID
        param.put(MaSeizouLineEntityNames.seizouLnId().toString(), _seizouLnId);
        // ラインNo
        if (CM_CommonUtil.isNotNullOrBlank(_lineId)) {
            param.put(MaLineEntityNames.lnId().toString(), _lineId);
        } else {
            param.put(MaLineEntityNames.lnId().toString(), null);
        }

        //SQLを生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstProcessId.sql";

        // データの抽出
        List<BeanMap> res = this.jdbcManager.selectBySqlFile(BeanMap.class, path, param)
                .getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(res);

        return res;
    }

    /**
     *
     * 工程名称リスト取得.<br>
     *<br>
     * 概要:<br>
     *   工程のリストを取得する
     *<br>
     * @param _plantCode 工場コード
     * @param _seizouLnId 製造ラインID
     * @return 工程名称リスト
     */
    public List<BeanMap> getMstProcessNameList(final String _plantCode, final Long _seizouLnId) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);
        CM_LoggerUtil.outputDaoInputParamLog("_seizouLnId", _seizouLnId);

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();

        // パラメータのセット
        String paramName = CM_A04_Const.SQL_PARAM.PLANT_CODE;
        // 工場コード
        param.put(paramName, _plantCode);
        // 製造ラインID
//        if (CM_CommonUtil.isNotNullOrBlank(_seizouLnId)) {
            param.put(MaSeizouLineEntityNames.seizouLnId().toString(), _seizouLnId);
//        }

        //SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstProcessNameList.sql";

        // データの抽出
        List<BeanMap> res = this.jdbcManager.selectBySqlFile(BeanMap.class, path, param)
                .getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(res);

        return res;
    }

    /**
     *
     * ステーション名称リスト取得.<br>
     *<br>
     * 概要:<br>
     *   ステーションのリストを取得する
     *<br>
     * @param _plantCode 工場コード
     * @param _seizouLineId 製造ラインID
     * @param _processId 工程ID
     * @param _lnId ラインID
     * @return ステーション名称リスト
     */
    public List<BeanMap> getMstStationNameList(
            final String _plantCode, final Long _seizouLineId, final Long _processId, final Long _lnId) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);
        CM_LoggerUtil.outputDaoInputParamLog("_seizouLineId", _seizouLineId);
        CM_LoggerUtil.outputDaoInputParamLog("_processId", _processId);
        CM_LoggerUtil.outputDaoInputParamLog("_lnId", _lnId);

        // 検索条件のセット
        Map<String, Object> param = new HashMap<String, Object>();

        // パラメータのセット
        String paramName = CM_A04_Const.SQL_PARAM.PLANT_CODE;
        // 工場コード
        param.put(paramName, _plantCode);
        // 製造ラインID
        if (CM_CommonUtil.isNotNullOrBlank(_seizouLineId)) {
            param.put(MaSeizouLineEntityNames.seizouLnId().toString(), _seizouLineId);
        }
        // 工程ID
        if (CM_CommonUtil.isNotNullOrBlank(_processId)) {
            param.put(MaProcessEntityNames.processId().toString(), _processId);
        }
        // ラインID
        if (CM_CommonUtil.isNotNullOrBlank(_lnId)) {
            param.put(MaLineEntityNames.lnId().toString(), _lnId);
        }

        //SQLの生成する
        String path = CM_BaseCustomerSchemaDao.SQL_PATH_COMM + "selectMstStationNameList.sql";

        // データの抽出
        List<BeanMap> res = this.jdbcManager.selectBySqlFile(BeanMap.class, path, param)
                .getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(res);

        return res;
    }

    /**
    *
    * 作業者マスタ取得.<br>
    *<br>
    * 概要:<br>
    *  作業者マスタ取得処理
    *<br>
    * @param _userSid ユーザーSID
    * @return 作業者マスタリスト
    */
   public List<MaUserEntity> getWorkerEntityList(final int _userSid) {
       CM_LoggerUtil.outputDaoInputParamLog("_userSid", _userSid);

       SimpleWhere where = new SimpleWhere();
       where.eq(MaUserEntityNames.userSid().toString(),_userSid);
       where.eq(MaUserEntityNames.invalidFlag().toString(), CM_A04_Const.INVALID_FLAG.VALID);

       List<MaUserEntity> ret = this.jdbcManager.from(MaUserEntity.class).where(where).getResultList();

       CM_LoggerUtil.outputDaoOutputParamLog(ret);

       return ret;
   }
}
