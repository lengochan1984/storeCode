/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+======================================+========+==============
 *  DATE      | Comments                             | Rev    | SIGN
 * ===========+======================================+========+==============
 *  2014/01/27| 新規作成                             | 1.00.00| YSK)森山
 *  2014/06/21| <10000-004> ユーザ設定押下処理追加   | 1.00.00| YSK)鬼丸
 *  2014/06/21| <10000-008> 説明画面用処理追加       | 1.00.00| YSK)中田
 *  2014/06/23| <10000-023> 戻る処理の不具合修正     | 1.00.00| YSK)鬼丸
 *  2014/09/03| <10101-012> トレンドモニタ改造　  　 | 1.02.00| YSK)植山
 *  2014/10/03| <10101-029> リリース後不具合対応     | 1.02.00| YSK)大山
 *  2014/12/05| <20000-009> 変更仕様No.7             | 3.00.00| US)楢崎
 *  2014/01/06| <20000-006> 変更仕様No.18            | 3.00.00| YSK)中田
 *  2015/02/20| <20000-037>　仕様変更No.38           | 3.00.00| YSK)植山
 *  2015/12/01| <40000-025> Ver4.00.00 変更仕様No.25 | 4.00.00| US)高橋
 *  2016/01/11| <40000-013> Ver.4.00.00 変更仕様No.13| 4.00.00| US)甲斐
 *  2016/01/14| <40000-025> 変更仕様No.25            | 4.00.00| US)萩尾
 *  2016/01/18| <40000-027> Ver.4.00.00 変更仕様No.27| 4.00.00| US)甲斐
 *  2016/01/25| <40000-028> 変更仕様No.28            | 4.00.00| US)安永
 *  2016/01/26| <30101-002> 故障苦情No.30100-012 　  | 4.00.00| US)萩尾
 *  2016/07/20| <C1.01> 共通化対応取込               | C1.01  | US)萩尾
 * -----------+--------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.action;

import java.util.Map;

import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.fw.form.FW01_17_BaseForm;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.common.util.CM_MessageResourceUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;
import jp.ysk.mmcloud.visualization.common.service.CM_ListService;
import jp.ysk.mmcloud.visualization.common.util.CM_CommonUtil;

import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.beans.util.Beans;
import org.seasar.framework.exception.SQLRuntimeException;

/**
 *
 * 一覧用アクション基底クラス.<br>
 *<br>
 * 概要:<br>
 *   一覧用アクション用の共通基底クラス
 *<br>
 */
public abstract class CM_A03_ListAction extends CM_A04_ListBaseAction {

    /**
     *
     * 表示データ作成処理.<br>
     *<br>
     * 概要:<br>
     *  表示データ作成処理を実行する<br>
     *  service.getDataCountで件数を取得後、
     *  service.getDataListで一覧を取得する
     *<br>
     * @return 画面のJSP
     */
    @Override
    protected String display() {

        // 日時情報更新処理
        this.setDisplayDateData(this.getActionForm());

        // 詳細検索条件情報を取得
        Map<String, Object> mapSearchCondInfo = this.getComDetailSearchInfo(getPageId(), (FW01_17_BaseForm) this.getActionForm());

        CM_ListService service = this.getService();

        // ソートキー取得
        this.sortKeyNameMap = service.getSortKeyNames();

        // 検索前処理
        this.preDisplay();

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        // パラメータ型変換
        CM_CommonUtil.convertParamType(formMap);

        // まだセッションに格納されていないメンバの初期化
        initFormMap(formMap);

        // フォーム情報にユーザの言語コードを設定
        formMap.put(CM_A04_Const.SQL_PARAM.LOGIN_USER_LANG_CD, this.cM_A03_SessionDto.ssn_UserLangCD);

        // 検索前処理
        service.preGetData(formMap, mapSearchCondInfo);

        // 入力チェック
        String validation = this.validate(formMap, mapSearchCondInfo);
        if (CM_CommonUtil.isNotNullOrBlank(validation)) {
            // 総ページ数の算出
            this.calcPage(this.getActionForm(), 0);
            return validation;
        }

        // 条件に該当する全件数取得を行う
        long listCnt = service.getDataCount(formMap, mapSearchCondInfo);

        // 総ページ数の算出
        this.calcPage(this.getActionForm(), listCnt);

        // 表示件数が0件以外の場合は、一覧表示のデータ抽出を行う
        if (listCnt > 0) {
            // 一覧情報取得を行う
            this.listData = service.getDataList(formMap, mapSearchCondInfo, this.getOffsetInfo(this.getActionForm()));
        }

        // 検索後処理
        this.afterDisplay(formMap);

        return getJspFileName();
    }

    /**
    *
    * formMapの初期化.<br/>
    * <br/>
    * 概要:<br/>
    *  セッションに登録されていないメンバの初期化<br/>
    * <br/>
    * @param _formMap フォーム情報
    */
    private void initFormMap(final BeanMap _formMap) {
        // 工場
        if (CM_CommonUtil.isNullOrBlank(_formMap.get(CM_BaseForm.COM_PLANT_CODE))) {
            _formMap.put(CM_BaseForm.COM_PLANT_CODE, null);
        }

        // 製造ライン（グループ）
        if (CM_CommonUtil.isNullOrBlank(_formMap.get(CM_BaseForm.COM_SEIZOU_LN_ID))) {
            _formMap.put(CM_BaseForm.COM_SEIZOU_LN_ID, null);
        }

        // 工程
        if (CM_CommonUtil.isNullOrBlank(_formMap.get(CM_BaseForm.COM_PROCESS_ID))) {
            _formMap.put(CM_BaseForm.COM_PROCESS_ID, null);
        }

        // ライン
        if (CM_CommonUtil.isNullOrBlank(_formMap.get(CM_BaseForm.COM_LN_ID))) {
            _formMap.put(CM_BaseForm.COM_LN_ID, null);
        }

        // ST
        if (CM_CommonUtil.isNullOrBlank(_formMap.get(CM_BaseForm.COM_ST_ID))) {
            _formMap.put(CM_BaseForm.COM_ST_ID, null);
        }
    }

    /**
     *
     * 入力チェック処理.<br/>
     * <br/>
     * 概要:<br/>
     *  入力チェック処理を行う。<br/>
     * <br/>
     * @param _formMap フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return エラーAjaxJSP名
     */
    protected String validate(final BeanMap _formMap, final Map<String, Object> _mapSearchCondInfo) {
        String res = null;

        try {
            CM_ListService service = this.getService();

            // 処理開始
            service.init(this.cM_A03_SessionDto);
            // 入力チェック
            service.validate(_formMap, _mapSearchCondInfo);

        } catch (FW00_12_BusinessException be) {
            // 例外発生時はエラーメッセージ表示
            return this.alertErrorInfo(this.getJspFileName(), be.getMsgKey(), be.getFocusCtlId());

        } catch (SQLRuntimeException re) {
            // SQLエラー時はエラーをスローする
            throw re;
        } catch (Exception e) {
            // 例外発生時はエラーメッセージ表示
            String strErrorMes = CM_MessageResourceUtil.getMessageValue(this.cM_A03_SessionDto.ssn_CustomerCD,
                    this.cM_A03_SessionDto.ssn_UserLangCD, "MMCMCM00000_024");

            // 例外情報はログ出力
            CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, e);

            return this.alertErrorInfo(this.getJspFileName(), strErrorMes, null);
        }

        return res;
    }

    /**
     *
     * CSVダウンロード用入力チェック処理.<br/>
     *<br/>
     * 概要:<br/>
     *  CSVダウンロード用入力チェック処理を行う。<br/>
     *<br/>
     * @param _formMap Form情報
     * @param _mapSearchCondInfo 詳細検索情報
     * @return エラーAjaxJSPファイル
     */
    @Override
    protected String csvValidation(final BeanMap _formMap, final Map<String, Object> _mapSearchCondInfo) {
        return this.csvValidate(_formMap, _mapSearchCondInfo);
    }

    /**
     *
     * 入力チェック処理.<br/>
     * <br/>
     * 概要:<br/>
     *  入力チェック処理を行う。<br/>
     * <br/>
     * @param _formMap フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return エラーAjaxJSP名
     */
    private String csvValidate(final BeanMap _formMap, final Map<String, Object> _mapSearchCondInfo) {
        String res = null;

        try {
            // 入力チェック
            this.getService().csvValidate(_formMap, _mapSearchCondInfo);

        } catch (FW00_12_BusinessException be) {
            // 例外発生時はエラーメッセージ表示
            return this.alertErrorInfoForAjax(be.getMsgKey(), be.getFocusCtlId());

        } catch (SQLRuntimeException re) {
            // SQLエラー時はエラーをスローする
            throw re;
        } catch (Exception e) {
            // 例外発生時はエラーメッセージ表示
            String strErrorMes = CM_MessageResourceUtil.getMessageValue(this.cM_A03_SessionDto.ssn_CustomerCD,
                    this.cM_A03_SessionDto.ssn_UserLangCD, "MMCMCM00000_003");

            // 例外情報はログ出力
            CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, e);

            return this.alertErrorInfoForAjax(strErrorMes, null);
        }

        return res;
    }

    /**
     * 画面のサービスを取得.<br>
     * <br>
     * 概要:<br>
     * 各画面のサービスを取得<br>
     * 各画面のアクションで実装し、サービスを設定する
     *
     * @return 画面のサービス
     */
    @Override
    protected abstract CM_ListService getService();

}
