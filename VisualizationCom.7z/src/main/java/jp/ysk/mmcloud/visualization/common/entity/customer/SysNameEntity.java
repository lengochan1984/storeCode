package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 名称マスタ（システム用） : 多言語対応のため、システムが使用する項目の名称は言語に応じてこのマスタから取得する。
たとえば、汎用マスタの言語ごとの名称はここから取得する。
<リンク条件>
汎用マスタ.汎用コード=名称マスタ.名称種別 AND 汎用マスタ.項目コード=名称マスタ.項目コード

新しい名称種別が発生した場合は追記すること。
 * 
 */
@Entity
@Table(name = "sys_name")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class SysNameEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 名称種別（システム用） : 名称の種類を区別するために使用する。
汎用マスタとリンクする際は、汎用コード。 */
    @Id
    @Column(length = 20, nullable = false, unique = false)
    public String nameType;

    /** 項目CD */
    @Id
    @Column(length = 64, nullable = false, unique = false)
    public String itemCd;

    /** 言語CD : ユーザの使用言語を保持。
名称マスタ（システム用）の名称種別="language"とリンク。 */
    @Id
    @Column(length = 64, nullable = false, unique = false)
    public String langCd;

    /** 表示名称1 : 画面に表示する名称 */
    @Column(length = 128, nullable = false, unique = false)
    public String name1;

    /** 表示名称2 : 画面に表示する名称 */
    @Column(length = 128, nullable = true, unique = false)
    public String name2;

    /** デフォルトフラグ : 1:デフォルト
0:デフォルトでない
※1以外はデフォルトでないとみなす。 */
    @Column(length = 1, nullable = false, unique = false)
    public String defaultFlag;

    /** 表示順 : データポイントコードの表示順 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer displayOrder;

    /** 削除フラグ : true：有効、false：無効 */
    @Column(length = 1, nullable = false, unique = false)
    public Boolean deleteFlag;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
