/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2017/03/09| 新規作成                           | C1.01  | H.Nakamura
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.util;

import java.util.HashMap;

import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.visualization.common.dto.CM_ErpDbAccessDto;

import org.seasar.extension.datasource.impl.DataSourceFactoryImpl;
import org.seasar.extension.dbcp.impl.ConnectionPoolImpl;
import org.seasar.extension.dbcp.impl.DataSourceImpl;
import org.seasar.extension.dbcp.impl.XADataSourceImpl;
import org.seasar.extension.jdbc.dialect.OracleDialect;
import org.seasar.extension.jdbc.manager.JdbcManagerImpl;
import org.seasar.extension.jdbc.meta.ColumnMetaFactoryImpl;
import org.seasar.extension.jdbc.meta.EntityMetaFactoryImpl;
import org.seasar.extension.jdbc.meta.PropertyMetaFactoryImpl;
import org.seasar.extension.jdbc.meta.TableMetaFactoryImpl;
import org.seasar.extension.jta.TransactionManagerImpl;
import org.seasar.extension.jta.TransactionSynchronizationRegistryImpl;
import org.seasar.framework.convention.PersistenceConvention;
import org.seasar.framework.convention.impl.PersistenceConventionImpl;

/**
 *
 * ERP-DBへの接続管理処理.<br>
 *<br>
 * 概要:<br>
 *   ERP-DBへの接続管理クラス
 *<br>
 */
public class CM_ErpDbAccessManager {

    /**
     *
     * コンストラクタ.
     *
     */
    protected CM_ErpDbAccessManager() {
        throw new UnsupportedOperationException();
    }

    /**
     * コネクションプール格納Map（ERP毎の管理）.
     */
    private static HashMap<String, CM_ErpDbAccessDto> mapErpDbAccessDto = null;

    /**
     * コネクションプールのタイムアウト時間.
     */
    private static final int CONNECTION_POOL_TIMEOUT = 600;

    /**
     * コネクションプールの最大プールサイズ.
     */
    private static final int CONNECTION_POOL_MAX_SIZE = 10;

    /**
     * クエリタイムアウト(秒).
     * s2jdbc.diconのqueryTimeoutと設定をあわせること
     */
    private static final int QUERY_TIMEOUT = 55;

    /**
     *
     * ERP-DB接続の取得処理.<br>
     *<br>
     * 概要:<br>
     *   指定されたERP-DBへの接続確立を行う
     *<br>
     * @param _strDataSource ERPコード
     * @param _strUser ERPコード
     * @param _strPassword ERPコード
     * @return ERP-DB接続用JdbcManager
     */
    public static CM_ErpDbAccessDto getErpDbAccess(final String _strDataSource,
            final String _strUser,
            final String _strPassword) {

        CM_ErpDbAccessDto erpDbAccessDto = null;

        try {

            if (mapErpDbAccessDto == null) {
                mapErpDbAccessDto = new HashMap<String, CM_ErpDbAccessDto>();
            }

            erpDbAccessDto = mapErpDbAccessDto.get(_strUser);
            if (erpDbAccessDto == null) {
                // トランザクションマネージャの初期化
                TransactionManagerImpl transactionManager = new TransactionManagerImpl();
                XADataSourceImpl xaDataSource = new XADataSourceImpl();
                xaDataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
                xaDataSource.setURL("jdbc:oracle:thin:@" + _strDataSource);
                xaDataSource.setUser(_strUser);
                xaDataSource.setPassword(_strPassword);

                ConnectionPoolImpl connectionPool = new ConnectionPoolImpl();
                connectionPool.setXADataSource(xaDataSource);
                connectionPool.setTransactionManager(transactionManager);
                connectionPool.setTimeout(CONNECTION_POOL_TIMEOUT);
                connectionPool.setMaxPoolSize(CONNECTION_POOL_MAX_SIZE);
                connectionPool.setAllowLocalTx(true);

                TransactionSynchronizationRegistryImpl syncRegistry = new TransactionSynchronizationRegistryImpl();
                syncRegistry.setTransactionManager(transactionManager);

                // データソースの初期化
                DataSourceImpl dataSource = new DataSourceImpl(connectionPool);

                // エンティティメタファクトリの初期化
                EntityMetaFactoryImpl entityMetaFactory = new EntityMetaFactoryImpl();
                PersistenceConvention persistenceConvention = new PersistenceConventionImpl();
                entityMetaFactory.setPersistenceConvention(persistenceConvention);
                PropertyMetaFactoryImpl propertyMetaFactory = new PropertyMetaFactoryImpl();
                ColumnMetaFactoryImpl columnMetaFactory = new ColumnMetaFactoryImpl();
                columnMetaFactory.setPersistenceConvention(persistenceConvention);
                propertyMetaFactory.setColumnMetaFactory(columnMetaFactory);
                propertyMetaFactory.setPersistenceConvention(persistenceConvention);
                entityMetaFactory.setPropertyMetaFactory(propertyMetaFactory);
                TableMetaFactoryImpl tableMetaFactory = new TableMetaFactoryImpl();
                tableMetaFactory.setPersistenceConvention(persistenceConvention);
                entityMetaFactory.setTableMetaFactory(tableMetaFactory);

                // ダイアレクトの初期化
                OracleDialect oracleDialect = new OracleDialect();

                // データソースの初期化
                DataSourceFactoryImpl dataSourceFactory = new DataSourceFactoryImpl();

                // JdbcManagerの初期化
                JdbcManagerImpl jdbcManager = new JdbcManagerImpl();
                jdbcManager.setSyncRegistry(syncRegistry);
                jdbcManager.setPersistenceConvention(persistenceConvention);
                jdbcManager.setEntityMetaFactory(entityMetaFactory);
                jdbcManager.setDataSource(dataSource);
                jdbcManager.setDataSourceFactory(dataSourceFactory);
                jdbcManager.setDialect(oracleDialect);
                jdbcManager.setQueryTimeout(QUERY_TIMEOUT);

                erpDbAccessDto = new CM_ErpDbAccessDto();
                erpDbAccessDto.jdbcManager = jdbcManager;
                erpDbAccessDto.userTransactionMng = transactionManager;

                mapErpDbAccessDto.put(_strUser, erpDbAccessDto);
            }

        } catch (Exception e) {
            // エラーログ出力
            CM_LoggerUtil.outputErrorLog(null, e);
        }

        return erpDbAccessDto;
    }
}
