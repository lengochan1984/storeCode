package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link MaSigMultilangModelGroupEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class MaSigMultilangModelGroupEntityNames {

    /**
     * signageIdのプロパティ名を返します。
     * 
     * @return signageIdのプロパティ名
     */
    public static PropertyName<String> signageId() {
        return new PropertyName<String>("signageId");
    }

    /**
     * vtextInfo1のプロパティ名を返します。
     * 
     * @return vtextInfo1のプロパティ名
     */
    public static PropertyName<String> vtextInfo1() {
        return new PropertyName<String>("vtextInfo1");
    }

    /**
     * vtextInfo1Jpのプロパティ名を返します。
     * 
     * @return vtextInfo1Jpのプロパティ名
     */
    public static PropertyName<String> vtextInfo1Jp() {
        return new PropertyName<String>("vtextInfo1Jp");
    }

    /**
     * vtextInfo1Enのプロパティ名を返します。
     * 
     * @return vtextInfo1Enのプロパティ名
     */
    public static PropertyName<String> vtextInfo1En() {
        return new PropertyName<String>("vtextInfo1En");
    }

    /**
     * vtextInfo1Zhのプロパティ名を返します。
     * 
     * @return vtextInfo1Zhのプロパティ名
     */
    public static PropertyName<String> vtextInfo1Zh() {
        return new PropertyName<String>("vtextInfo1Zh");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _MaSigMultilangModelGroupNames extends PropertyName<MaSigMultilangModelGroupEntity> {

        /**
         * インスタンスを構築します。
         */
        public _MaSigMultilangModelGroupNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _MaSigMultilangModelGroupNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _MaSigMultilangModelGroupNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * signageIdのプロパティ名を返します。
         *
         * @return signageIdのプロパティ名
         */
        public PropertyName<String> signageId() {
            return new PropertyName<String>(this, "signageId");
        }

        /**
         * vtextInfo1のプロパティ名を返します。
         *
         * @return vtextInfo1のプロパティ名
         */
        public PropertyName<String> vtextInfo1() {
            return new PropertyName<String>(this, "vtextInfo1");
        }

        /**
         * vtextInfo1Jpのプロパティ名を返します。
         *
         * @return vtextInfo1Jpのプロパティ名
         */
        public PropertyName<String> vtextInfo1Jp() {
            return new PropertyName<String>(this, "vtextInfo1Jp");
        }

        /**
         * vtextInfo1Enのプロパティ名を返します。
         *
         * @return vtextInfo1Enのプロパティ名
         */
        public PropertyName<String> vtextInfo1En() {
            return new PropertyName<String>(this, "vtextInfo1En");
        }

        /**
         * vtextInfo1Zhのプロパティ名を返します。
         *
         * @return vtextInfo1Zhのプロパティ名
         */
        public PropertyName<String> vtextInfo1Zh() {
            return new PropertyName<String>(this, "vtextInfo1Zh");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
