/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/07/20| <C1.01>　新規作成（共通化対応取込）                                  | C1.01  | US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.action;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.action.FW01_15_BaseAction;
import jp.ysk.fw.form.FW01_17_BaseForm;
import jp.ysk.fw.util.FW01_03_CreateSingleSelectTagUtil;
import jp.ysk.mmcloud.common.action.CM_A03_InfoAction;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.dto.CM_A07_BreadCrumbDto;
import jp.ysk.mmcloud.common.util.CM_DisplayCharResourceUtil;
import jp.ysk.mmcloud.common.util.CM_HeaderUtil;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.CM_A05_PageInfo;
import jp.ysk.mmcloud.visualization.common.CM_A09_ComSearchInfo;
import jp.ysk.mmcloud.visualization.common.CM_A10_SearchPldTypeInfo;
import jp.ysk.mmcloud.visualization.common.CM_A11_SearchDateTypeInfo;
import jp.ysk.mmcloud.visualization.common.CM_A12_HomeSearchInfo;
import jp.ysk.mmcloud.visualization.common.dto.AndongInfoDto;
import jp.ysk.mmcloud.visualization.common.dto.CM_PageAuthInfoDto;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantMierukaEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantMierukaEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSearchConditionEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSearchConditionEntityNames;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;
import jp.ysk.mmcloud.visualization.common.form.CM_ListForm;
import jp.ysk.mmcloud.visualization.common.service.CM_GetMstDataService;
import jp.ysk.mmcloud.visualization.common.service.CM_TopHeaderService;
import jp.ysk.mmcloud.visualization.common.service.CM_VisualizationBaseService;
import jp.ysk.mmcloud.visualization.common.util.CM_CodeUtil;
import jp.ysk.mmcloud.visualization.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.visualization.common.util.CM_MenuAuthInfoUtil;

import org.seasar.extension.jdbc.where.SimpleWhere;
import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.beans.util.Beans;
import org.seasar.framework.util.StringUtil;
import org.seasar.struts.annotation.Execute;

/**
 *
 * アクション基底クラス.<br>
 *<br>
 * 概要:<br>
 *   アクション用の共通基底クラス
 *<br>
 */
public abstract class CM_A01_BaseAction extends FW01_15_BaseAction {

    /**
     * セッション情報.
     */
    @Resource
    public CM_A03_SessionDto cM_A03_SessionDto;

    /**
     * 共通ヘッダ情報.
     */
    public BeanMap mapTopHeader = null;

    /**
     * 情報ファイルリンク先.
     */
    public String infoFileLink = null;

    /**
     * 情報画面閲覧権限.
     */
    public boolean enableInfoDisp = false;

    /**
     * 情報画面変更権限.
     */
    public boolean enableInfoChange = false;

    /**
     * 共通検索項目 現在検索条件リスト
     */
    public List<String> comDisplaySearchConditionList = new ArrayList<String>();

    /**
     * 共通検索情報.
     */
    public CM_A09_ComSearchInfo comSearchInfo;

    /**
     * HOME検索項目 現在検索条件リスト
     */
    public List<String> homeDisplaySearchConditionList = new ArrayList<String>();

    /**
     * HOME検索情報.
     */
    public CM_A12_HomeSearchInfo homeSearchInfo;

    /**
     * お気に入りTOP.
     */
    public BeanMap favoriteTop = null;

    /** お気に入り登録可能フラグ. */
    public boolean favoriteSaveAvail = false;

    /**
     * お気に入りリストマップ.
     */
    public Map<Integer, BeanMap> favoriteListMap = new LinkedHashMap<Integer, BeanMap>();

    /** お気に入りJSP. */
    public static final String COM_FAVORITE_AREA_JSP = "../common/com_favoriteArea.jsp";

    /**
     * アンドン用データ.
     */
    public AndongInfoDto andongInfoDto;

    /**
     * MES連携チェック用データ.
     */
    public long mesConnectInfoDto;

    /**
     * 共通エリア(検索、アンドン)情報.
     */
    public BeanMap comAreaMap = null;

    /**
     * 日付検索条件保持キー.
     */
    public static final String DATE_SERCH_TYPE_KEY = "dateSerchTypeKey";

    /**
     * 現在の年度.
     */
    public String currentYear;

    /**
     *
     * 初期表示.<br>
     *<br>
     * 概要:<br>
     *   初期表示処理を実行する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String index() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        if (CM_CommonUtil.isNotNullOrBlank(this.cM_A03_SessionDto)) {
            // サービスの初期化
            if (CM_CommonUtil.isNotNullOrBlank(this.getService())) {
                this.getService().init(this.cM_A03_SessionDto);
            }

            // 画面アクセス頻度ログの登録
            if (CM_CommonUtil.isNotNullOrBlank(this.getPageId())) {
                this.getService().countUpAccessCount(this.getPageId());
            }
        }
        // 共通設定
        this.commonSetting();

        // 初期処理
        this.preIndex();

        // 初期表示処理
        this.init();

        // 初期処理後処理
        this.afterInit();

        // 表示処理
        String ret = this.display();

        // 後処理
        this.afterIndex();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, ret);

        return ret;
    }

    /**
     *
     * 初期表示 初期処理.<br>
     *<br>
     * 概要:<br>
     *   初期表示 初期処理を実行する
     *<br>
     */
    protected void preIndex() {
        return;
    }

    /**
     *
     * 初期表示処理 後処理.<br>
     *<br>
     * 概要:<br>
     *   初期表示処理 後処理
     *<br>
     */
    protected void afterInit() {
        return;
    }

    /**
     *
     * 初期表示 後処理.<br>
     *<br>
     * 概要:<br>
     *   初期表示 後処理を実行する
     *<br>
     */
    protected void afterIndex() {
        return;
    }

    /**
     * 画面のサービスを取得.<br>
     * <br>
     * 概要:<br>
     * 各画面のサービスを取得<br>
     * 各画面のアクションで実装し、サービスを設定する
     *
     * @return 画面のサービス
     */
    protected abstract CM_VisualizationBaseService getService();

    /**
     * 画面のページ情報を取得.<br>
     * <br>
     * 概要:<br>
     * 各画面のページ情報を取得<br>
     * 各画面のアクションで実装し、ページ情報を設定する
     *
     * @return 画面のページID
     */
    protected abstract CM_A05_PageInfo getPageInfo();

    /**
     * 画面のページIDを取得.<br>
     * <br>
     * 概要:<br>
     * 各画面のページIDを取得<br>
     * 各画面のアクションで実装し、ページIDを設定する
     *
     * @return 画面のページID
     */
    protected String getPageId() {
        return this.getPageInfo().getPageId();
    };

    /**
     * 初期表示処理.<br>
     * <br>
     * 概要:<br>
     * 各画面の初期表示処理を実行<br>
     * 各画面のアクションで実装し、初期表示処理を行う
     *
     * @return 画面のJSP
     */
    protected String init() {
        return null;
    }

    /**
     * 表示処理.<br>
     * <br>
     * 概要:<br>
     * 各画面の表示処理を実行<br>
     * 各画面のアクションで実装し、表示処理を行う
     *
     * @return 画面のJSP
     */
    protected abstract String display();

    /**
     *
     * 画面表示 後処理.<br>
     *<br>
     * 概要:<br>
     *   初期表示 後処理を実行する
     *<br>
     */
    protected void preDisplay() {
        return;
    }

    /**
     *
     * 画面表示 後処理.<br>
     *<br>
     * 概要:<br>
     *   初期表示 後処理を実行する
     *<br>
     * @param _formMap フォーム情報
     */
    protected void afterDisplay(final BeanMap _formMap) {
        return;
    }

    /**
     *
     * JSPファイル名取得.<br>
     *<br>
     * 概要:<br>
     *　JSPファイル名を取得
     *<br>
     * @return JSPファイル名
     */
    protected abstract String getJspFileName();

    /**
     *
     * Ajax用JSPファイル名取得.<br>
     *<br>
     * 概要:<br>
     *　Ajax用JSPファイル名を取得
     *<br>
     * @return Ajax用JSPファイル名
     */
    protected String getJspFileNameAjax() {
        return FW00_19_Const.EMPTY_STR;
    }

    /**
     *
     * 共通設定.<br>
     *<br>
     * 概要:<br>
     *   共通設定処理を行う
     *<br>
     */
    protected void commonSetting() {
        this.initServiceIfNot();

        makeInfoFileLink();

        // 共通ヘッダのデータセット
        CM_TopHeaderService s000050TopHeaderService = new CM_TopHeaderService();
        this.mapTopHeader = s000050TopHeaderService.getHeaderData(this.cM_A03_SessionDto, this.getActionForm());

        // お気に入り情報取得
        if (this.favoriteListMap == null || this.favoriteListMap.isEmpty()) {
            this.loadFavoriteInfo();
        }

        // 共通エリアのデータセット
        if (this.comAreaMap == null || this.comAreaMap.isEmpty()) {
            this.loadComAreaInfo(this.getActionForm());
        }
    }

    /**
     * サービスが初期化されていない場合初期化.
     */
    private void initServiceIfNot() {
        if (CM_CommonUtil.isNotNullOrBlank(this.cM_A03_SessionDto)) {
            if (CM_CommonUtil.isNotNullOrBlank(this.getService())) {
                if (!this.getService().hasConnection()) {
                    // サービスの初期化
                    this.getService().init(this.cM_A03_SessionDto);
                }
            }
        }
    }

    /**
     * 情報ページリンク先の生成.<br>
     *<br>
     * 概要:<br>
     *<br>
     */
    private void makeInfoFileLink() {
        this.infoFileLink = CM_A04_Const.INFO_PAGE_DIR + this.getPageId() + ".html";
    }

    /**
     *
     * ヘッダーメニューのユーザ設定押下の処理.<br>
     *<br>
     * 概要:<br>
     *   ユーザ情報画面へ遷移する
     *<br>
     * @return JSP名
     * @throws IllegalAccessException アクセス権限違反例外
     */
    @Execute(validator = false)
    public String menu_userSetting_click() throws IllegalAccessException {

        FW01_17_BaseForm baseForm = null;
        for (Field field : this.getClass().getFields()) {

            Object prop = field.get(this);

            // フォーム情報を検索
            if (prop instanceof FW01_17_BaseForm) {
                baseForm = (FW01_17_BaseForm) prop;
                break;
            }
        }

        String linkUrl = CM_A04_Const.USER_INFO_URL;

        // パンくずメニュークリア
        CM_HeaderUtil.removeAllBreadCrumbList(this.cM_A03_SessionDto);

        // パンくず先頭にホーム画面をセット
        CM_HeaderUtil.addBreadCrumbList(this.cM_A03_SessionDto, CM_A04_Const.HOME_PAGE_ID);
        CM_HeaderUtil.setReturnInfo(this.cM_A03_SessionDto, CM_A04_Const.HOME_PAGE_ID, CM_A04_Const.HOME_URL, null);

        // 遷移パラメータ作成
        HashMap<String, String> param = new HashMap<String, String>();
        param.put(CM_A04_Const.A500030FORM_HDN_USERSID, Integer.toString(this.cM_A03_SessionDto.ssn_UserSID));
        param.put(CM_A04_Const.A500030FORM_HDN_INFOMODE, CM_A03_InfoAction.MODE_DISP);

        // 検索エリア、アンドンエリア表示情報
        String hdnSearchAreaOpen = ((CM_BaseForm) baseForm).hdnSearchAreaOpen;
        String hdnAndonAreaOpen = ((CM_BaseForm) baseForm).hdnAndonAreaOpen;
        param.put(CM_BaseForm.HDN_SEARCH_OPEN, hdnSearchAreaOpen);
        param.put(CM_BaseForm.HDN_ANDON_OPEN, hdnAndonAreaOpen);

        return this.redirectPage(linkUrl, param, baseForm);
    }

    /**
     *
     * ヘッダーメニューのリンク押下の処理.<br>
     *<br>
     * 概要:<br>
     *   押下したメニューの画面へ遷移する
     *<br>
     * @return JSP名
     * @throws IllegalAccessException アクセス権限違反例外
     */
    @Execute(validator = false)
    public String menu_link_click() throws IllegalAccessException {

        FW01_17_BaseForm baseForm = null;
        for (Field field : this.getClass().getFields()) {

            Object prop = field.get(this);

            // フォーム情報を検索
            if (prop instanceof FW01_17_BaseForm) {
                baseForm = (FW01_17_BaseForm) prop;
                break;
            }
        }

        CM_A05_PageInfo homePageInfo = CM_A05_PageInfo.getHomePageInfo();
        String linkUrl = homePageInfo.getIndexPageUrl();
        if (baseForm != null && !CM_CommonUtil.isNullOrBlank(baseForm.hdnComHeaderMenuLink)) {
            linkUrl = baseForm.hdnComHeaderMenuLink;
        }

        // パンくずメニュークリア
        CM_HeaderUtil.removeAllBreadCrumbList(this.cM_A03_SessionDto);

        // ホーム画面遷移の以外場合は、パンくず先頭にホーム画面をセット
        if (!linkUrl.equals(homePageInfo.getIndexPageUrl())) {
            CM_HeaderUtil.addBreadCrumbList(this.cM_A03_SessionDto, homePageInfo.getPageId());
            CM_HeaderUtil.setReturnInfo(this.cM_A03_SessionDto, homePageInfo.getPageId(), homePageInfo.getIndexPageUrl(), null);
        }

        Map<String, String> param = new HashMap<String, String>();
        if (baseForm != null) {
            if (baseForm instanceof CM_BaseForm) {
                String hdnFavoriteAccessFlg = ((CM_BaseForm) baseForm).hdnFavoriteAccessNo;
                String hdnSearchAreaOpen = ((CM_BaseForm) baseForm).hdnSearchAreaOpen;
                String hdnAndonAreaOpen = ((CM_BaseForm) baseForm).hdnAndonAreaOpen;
                Map<String, String> redirectParamMap = this.getActionForm().hdnRedirectParamMap;

                if (CM_CommonUtil.isNotNullOrBlank(hdnFavoriteAccessFlg)) {
                    // お気に入り遷移フラグがある場合は付加
                    param.put(CM_BaseForm.HDN_FAVORITE_ACCESS_NO, hdnFavoriteAccessFlg);

                    //------------------------------------------
                    // 工場が変わるとメニュー構成が変わるため、
                    // お気に入りに登録されている工場を取得し、
                    // ページ権限情報を取得し直す
                    //------------------------------------------
                    // サービス初期化
                    this.initServiceIfNot();
                    // お気に入り情報取得
                    Map<String, Object> favoriteInfo = this.loadFavoriteInfoDetails(Integer.parseInt(hdnFavoriteAccessFlg));
                    if (favoriteInfo != null && !favoriteInfo.isEmpty()) {
                        if (CM_CommonUtil.isNotNullOrBlank(favoriteInfo.get(CM_BaseForm.COM_PLANT_CODE))) {
                            ((CM_BaseForm) baseForm).comPlantCode = favoriteInfo.get(CM_BaseForm.COM_PLANT_CODE).toString();

                            // ページ権限情報取得
                            CM_MenuAuthInfoUtil.loadSessionPageAuthInfo(this.cM_A03_SessionDto, this.getActionForm().comPlantCode);
                        }
                    }

                } else if (redirectParamMap != null && !redirectParamMap.isEmpty()) {
                    // 画面遷移パラメータがある場合はそちらを使用
                    param = this.makeRedirectParam();
                }
                // 検索エリア、アンドンエリア表示情報
                param.put(CM_BaseForm.HDN_SEARCH_OPEN, hdnSearchAreaOpen);
                param.put(CM_BaseForm.HDN_ANDON_OPEN, hdnAndonAreaOpen);
            }
        }

        return this.redirectPage(linkUrl, param, baseForm);
    }


    /**
     *
     * ヘッダーのパンくずリストリンク押下の処理.<br>
     *<br>
     * 概要:<br>
     *   押下したパンくずリストの画面へ遷移する
     *<br>
     * @return JSP名
     * @throws IllegalAccessException アクセス権限違反例外
     */
    @Execute(validator = false)
    public String bread_crumb_link_click() throws IllegalAccessException {

        // フォーム情報を取得
        FW01_17_BaseForm baseForm = null;
        for (Field field : this.getClass().getFields()) {

            Object prop = field.get(this);

            // フォーム情報を検索
            if (prop instanceof FW01_17_BaseForm) {
                baseForm = (FW01_17_BaseForm) prop;
                break;
            }
        }

        String linkUrl = CM_A05_PageInfo.getHomePageInfo().getIndexPageUrl();
        // 遷移情報が取得できない場合はホーム画面に遷移
        if (baseForm == null || CM_CommonUtil.isNullOrBlank(baseForm.hdnComHeaderBreadCrumbIndex)) {
            // パンくずメニュークリア
            CM_HeaderUtil.removeAllBreadCrumbList(this.cM_A03_SessionDto);

            return this.redirectPage(linkUrl, new HashMap<String, String>(), new FW01_17_BaseForm());
        }

        // 押下されたパンくずリストのINDEX番号を取得
        String strBreadCrumbIndex = baseForm.hdnComHeaderBreadCrumbIndex;
        int intBreadCrumbIndex = Integer.parseInt(strBreadCrumbIndex);

        // 指定されたパンくずリストが存在しない場合はホーム画面に遷移
        int intListCount = this.cM_A03_SessionDto.ssn_BreadCrumbList.size();
        if (intListCount <= intBreadCrumbIndex) {
            return this.redirectPage(linkUrl, new HashMap<String, String>(), new FW01_17_BaseForm());
        }

        // 対象のパンくずリスト情報を取得
        CM_A07_BreadCrumbDto breadCrumbInfo = this.cM_A03_SessionDto.ssn_BreadCrumbList.get(intBreadCrumbIndex);

        // 遷移先情報作成
        linkUrl = breadCrumbInfo.ssn_ReturnMethod;
        HashMap<String, String> returnDispInfo = new HashMap<String, String>();

        // 遷移先画面以降のパンくずリスト削除
        for (int i = intListCount - 1; i > intBreadCrumbIndex; i--) {
            this.cM_A03_SessionDto.ssn_BreadCrumbList.remove(i);
        }

        // 遷移先画面のリンク情報をクリア
        breadCrumbInfo.ssn_ReturnMethod = FW00_19_Const.EMPTY_STR;

        return this.redirectPage(linkUrl, returnDispInfo, baseForm);
    }

    /**
     *
     * ヘッダーメニューのログアウト押下の処理.<br>
     *<br>
     * 概要:<br>
     *   ログイン画面へ遷移する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String logout_click() {

        FW01_17_BaseForm baseForm = new FW01_17_BaseForm();

        // セッション情報クリア
        this.cM_A03_SessionDto.initialize();

        return this.redirectPage("/a000010Login/index", new HashMap<String, String>(), baseForm);
    }

    /**
     *
     * ヘッダーメニューのHelpボタン押下の処理.<br>
     *<br>
     * 概要:<br>
     *   マニュアルダウンロードする
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String download_help_click() {

        // ファイルパス取得
        String fileDirectory = CM_A04_Const.MANUAL_DIR;
        // ファイル名取得
        String fileName = CM_A04_Const.MANUAL_FILENAME;

        return super.download(fileName, fileDirectory + fileName);
    }

    /**
     *
     * 画面権限取得処理.<br>
     *<br>
     * 概要:<br>
     *  画面に対する変更権限の有無を取得する
     *<br>
     */
    public void getAuth() {
        String auth = this.cM_A03_SessionDto.getPageAuth(this.getPageId());

        if (auth.equals(CM_A04_Const.ROLE_AUTH_KIND.UPDATE_ENABLE)) {
          this.enableInfoChange = true;
          this.enableInfoDisp = true;

        } else if (auth.equals(CM_A04_Const.ROLE_AUTH_KIND.DISP_ENABLE)) {
            this.enableInfoChange = false;
            this.enableInfoDisp = true;

        } else {
          this.enableInfoChange = false;
          this.enableInfoDisp = false;

        }

//        if (auth.equals(CM_A04_Const.ROLE_AUTH_KIND.UPDATE_ENABLE)) {
//          this.enableInfoChange = true;
//          this.enableInfoDisp = true;
//
//        } else if (auth.equals(CM_A04_Const.ROLE_AUTH_KIND.DISP_ENABLE)) {
//            this.enableInfoChange = false;
//            this.enableInfoDisp = true;
//
//        } else {
//          this.enableInfoChange = false;
//            this.enableInfoDisp = false;
//
//        }

        this.afterAuth(auth);
    }

    /**
     *
     * 画面権限取得後処理.<br>
     *<br>
     * 概要:<br>
     *  画面権限取得後処理
     *<br>
     * @param _auth 権限設定
     */
    protected void afterAuth(final String _auth) {
        return;
    }

    /**
     *
     * モード変更処理.<br>
     *<br>
     * 概要:<br>
     *  現在の状態とイベントによりモードを変更する
     *<br>
     * @param _intEvent イベントコード
     */
    public void modeChange(final int _intEvent) {
        String nextMode = this.getActionForm().hdnPageDispMode;

        if (CM_A04_Const.PAGE_DISP_MODE.MODE_DISP.equals(nextMode)) {
            switch (_intEvent) {
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_COPY:
                    nextMode = CM_A04_Const.PAGE_DISP_MODE.MODE_NEW;
                    break;
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_EDIT:
                    nextMode = CM_A04_Const.PAGE_DISP_MODE.MODE_UPDATE;
                    break;
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_DELETE:
                    break;
                default:
                    break;
            }

        } else if (CM_A04_Const.PAGE_DISP_MODE.MODE_UPDATE.equals(nextMode)) {
            switch (_intEvent) {
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_REGIST:
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_CANCEL:
                    nextMode = CM_A04_Const.PAGE_DISP_MODE.MODE_DISP;
                    break;
                default:
                    break;
            }

        } else {
            switch (_intEvent) {
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_REGIST:
                    nextMode = CM_A04_Const.PAGE_DISP_MODE.MODE_DISP;
                    break;
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_CANCEL:
                    break;
                default:
                    break;
            }
        }

        this.getActionForm().hdnPageDispMode = nextMode;
    }
    /**
     *
     * (お気に入り)モード変更処理.<br>
     *<br>
     * 概要:<br>
     *  現在の状態とイベントによりモードを変更する
     *<br>
     * @param _intEvent イベントコード
     */
    public void modeChangeFavorite(final int _intEvent) {
        String nextMode = this.getActionForm().hdnFavoritePageDispMode;

        if (CM_A04_Const.PAGE_DISP_MODE.MODE_DISP.equals(nextMode)) {
            switch (_intEvent) {
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_COPY:
                    nextMode = CM_A04_Const.PAGE_DISP_MODE.MODE_NEW;
                    break;
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_EDIT:
                    nextMode = CM_A04_Const.PAGE_DISP_MODE.MODE_UPDATE;
                    break;
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_DELETE:
                    break;
                default:
                    break;
            }

        } else if (CM_A04_Const.PAGE_DISP_MODE.MODE_UPDATE.equals(nextMode)) {
            switch (_intEvent) {
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_REGIST:
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_CANCEL:
                    nextMode = CM_A04_Const.PAGE_DISP_MODE.MODE_DISP;
                    break;
                default:
                    break;
            }

        } else {
            switch (_intEvent) {
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_REGIST:
                    nextMode = CM_A04_Const.PAGE_DISP_MODE.MODE_DISP;
                    break;
                case CM_A04_Const.PAGE_EVENT_TYPE.EVENT_CANCEL:
                    break;
                default:
                    break;
            }
        }

        this.getActionForm().hdnFavoritePageDispMode = nextMode;
    }

    /**
     * Actionクラス権限チェック処理.<br>
     *<br>
     * 概要:<br>
     *
     * @return チェック結果
     */
    protected boolean checkAction() {

        boolean ret = true;
        String needAuth = FW00_19_Const.EMPTY_STR;

        switch (this.getActionForm().hdnPageDispMode) {
            case CM_A04_Const.PAGE_DISP_MODE.MODE_NEW:
            case CM_A04_Const.PAGE_DISP_MODE.MODE_UPDATE:
                needAuth = CM_A04_Const.ROLE_AUTH_KIND.UPDATE_ENABLE;
                break;
            case CM_A04_Const.PAGE_DISP_MODE.MODE_DISP:
                needAuth = CM_A04_Const.ROLE_AUTH_KIND.DISP_ENABLE;
                break;
            default:
                // 想定外のモード
                return false;
        }

        //////////////////////////////////////////
        // Action関数権限チェック
        if (!this.checkActionAuth(needAuth)) {
            // 対象関数の権限が無い
            return false;
        }

        return ret;
    }

    /**
     *
     * Action関数権限確認処理.<br>
     *<br>
     * 概要:<br>
     *  Actionクラスの各関数に対する権限を確認する
     *<br>
     * @param _needAuth 対象Actionに必要な権限（1:閲覧権限、2：更新権限）
     * @return チェック結果
     */
    public boolean checkActionAuth(final String _needAuth) {

        String auth = this.cM_A03_SessionDto.getPageAuth(this.getPageId());

        if (auth.equals(CM_A04_Const.ROLE_AUTH_KIND.DISP_ENABLE) && _needAuth.equals(CM_A04_Const.ROLE_AUTH_KIND.UPDATE_ENABLE)) {
            // 閲覧権限しかないのに、更新権限が必要となるActionが呼ばれた場合
            return false;
        }
        return true;
    }

    /**
     * 各画面のフォームクラス取得.<br>
     *<br>
     * 概要:<br>
     * 各画面のフォームクラスを取得<br>
     * 各画面のアクションでオーバーライドし、フォームクラスを設定する
     *
     * @return 画面のフォームクラス
     */
    @Override
    protected abstract CM_BaseForm getActionForm();

    /**
     *
     * フォームに工場CDを設定.<br>
     *<br>
     * 概要:<br>
     *   ログイン情報を元に工場CDを取得し、フォームに設定する
     *<br>
     */
    protected void setPlantCode() {
        CM_BaseForm actionForm = this.getActionForm();
        if (CM_CommonUtil.isNullOrBlank(actionForm.comPlantCode)) {
            actionForm.comPlantCode = this.getService().getUserPlantCode();
        }
    }

    /**
     *
     * 登録検索条件の設定処理.<br>
     *<br>
     * 概要:<br>
     *   登録検索条件の設定処理
     *<br>
     * @param _searchConditionList 登録検索条件一覧
     */
    protected void setParamRegisterSearchCondition(final List<TrSearchConditionEntity> _searchConditionList) {
        for (TrSearchConditionEntity entity : _searchConditionList) {
            try {
                Field field = this.getActionForm().getClass().getField(entity.paramName);
                field.setAccessible(true);
                // フィールドの型を判定
                if (field.getGenericType() instanceof ParameterizedType) {
                    // リスト形式の場合
                    @SuppressWarnings("unchecked")
                    List<String> object = (List<String>) field.get(this.getActionForm());
                    if (CM_CommonUtil.isNullOrEmpty(object)) {
                        object = new ArrayList<String>();
                    }
                    object.add(entity.paramValue);
                    field.set(this.getActionForm(), object);
                } else if (field.getType().isArray()) {
                    // 配列型の場合
                    String[] object = (String[]) field.get(this.getActionForm());
                    if (CM_CommonUtil.isNullOrBlank(object)) {
                        object = new String[]{};
                    }
                    List<String> tmp = new ArrayList<String>(Arrays.asList(object));
                    tmp.add(entity.paramValue);
                    field.set(this.getActionForm(), tmp.toArray(new String[tmp.size()]));
                } else {
                    field.set(this.getActionForm(), entity.paramValue);
                }


            } catch (NoSuchFieldException | IllegalAccessException e) {
                // ログ出力のみ
                CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, e);
            }

        }
    }

    /**
     * 共通検索情報初期処理.
     */
    protected void initComSearchInfo(final boolean _isRedirect) {
        CM_BaseForm form = this.getActionForm();
        if (_isRedirect) {
            // リダイレクトパラメータ反映
            loadRedirectParam();
        } else {
            // セッションより共通検索情報を復元
            this.getComSearchInfo().restorComSearchCond(form);
        }
        // 工場コード設定
        this.setPlantCode();

        // プルダウン作成
        this.getComSearchPld();
        // 検索条件日時の設定
        this.setInitDateInfo();

        // 日時情報設定
        this.setSearchDate(form);
    }

    /**
     * セッションより共通検索情報を取得.
     * @return 共通検索情報
     */
    protected CM_A09_ComSearchInfo getComSearchInfo() {
        HttpSession session = this.request.getSession(false);
        if (session == null) {
            // セッションがない場合
            return new CM_A09_ComSearchInfo();
        }
        CM_A09_ComSearchInfo comSearchInfoDto = (CM_A09_ComSearchInfo) session.getAttribute(CM_A09_ComSearchInfo.class.getName());
        if (comSearchInfoDto == null) {
            comSearchInfoDto = new CM_A09_ComSearchInfo();
            session.setAttribute(CM_A09_ComSearchInfo.class.getName(), comSearchInfoDto);
        }
        return comSearchInfoDto;
    }

    /**
     * セッションより共通検索情報を取得.
     * @return 共通検索情報
     */
    protected CM_A12_HomeSearchInfo getHomeSearchInfo() {
        HttpSession session = this.request.getSession(false);
        if (session == null) {
            // セッションがない場合
            return new CM_A12_HomeSearchInfo();
        }
        CM_A12_HomeSearchInfo homeSearchInfoDto = (CM_A12_HomeSearchInfo) session.getAttribute(CM_A12_HomeSearchInfo.class.getName());
        if (homeSearchInfoDto == null) {
            homeSearchInfoDto = new CM_A12_HomeSearchInfo();
            session.setAttribute(CM_A12_HomeSearchInfo.class.getName(), homeSearchInfoDto);
        }
        return homeSearchInfoDto;
    }

    /**
     * HOME検索用プルダウン作成.<br>
     * <br>
     * 概要:<br>
     * プルダウンの作成
     * <br>
     * @return 結果
     */
    public String getHomeSearchPld(final boolean _search) {
        CM_BaseForm form = this.getActionForm();

        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);

        // HOME検索条件を取得
        this.homeSearchInfo = this.getHomeSearchInfo();

        if (!_search) {
            // HOMEボタン押下のときはセッションから読み出し
            this.loadHomeDisplaySearchConditionList();
        } else {
            // HOMEプルダウンの変更時はそのFormで作成
        }

        /* **************************************/
        // プルダウン作成
        /* **************************************/
        // 工場プルダウン取得
        this.homeSearchInfo.pldPlantList = mstDataService.getPlantPld();

        if (CM_CommonUtil.isNotNullOrBlank(form.comPlantCode)) {

            /* ***************/
            // グループ(製造ライン)
            /* ***************/
            // 製造ラインプルダウン取得
            this.homeSearchInfo.pldSeizouLineList = mstDataService.getMstSeizouLinePld(form.comPlantCode, false);

            // 未指定の場合、プルダウンの先頭を選択
            if (CM_CommonUtil.isNullOrBlank(form.comSeizouLnId) && !this.homeSearchInfo.pldSeizouLineList.isEmpty()) {
                form.comSeizouLnId = this.homeSearchInfo.pldSeizouLineList.get(0)
                        .get(FW01_03_CreateSingleSelectTagUtil.FW01_03_KEY_OPT_VALUE);
            }

            // プルダウン結果から再設定
            form.comSeizouLnId = checkPldData(this.homeSearchInfo.pldSeizouLineList, form.comSeizouLnId);

            /* ***************/
            // 工程
            /* ***************/
            // 工程プルダウン取得
            this.homeSearchInfo.pldProcessList
                = mstDataService.getMstProcessPld(form.comPlantCode, form.comSeizouLnId, true);

            // プルダウン結果から再設定
            form.comProcessId = checkPldData(this.homeSearchInfo.pldProcessList, form.comProcessId);

            /* ***************/
            // ライン
            /* ***************/
            // ラインプルダウン取得
            this.homeSearchInfo.pldLineList = mstDataService.getLinePld(form.comPlantCode, form.comSeizouLnId, form.comProcessId, true);

            // プルダウン結果から再設定
            form.comLnId = checkPldData(this.homeSearchInfo.pldLineList, form.comLnId);
        } else {
            // グループプルダウン
            this.homeSearchInfo.pldSeizouLineList.clear();
            // 工程プルダウン
            this.homeSearchInfo.pldProcessList.clear();
            // ラインプルダウン
            this.homeSearchInfo.pldLineList.clear();
        }

        // セッションに保存
        if (_search) {
            // HOMEプルダウンの変更時はセッションに保存
            this.homeSearchInfo.saveHomeSearchCondRem(form);
        }

        return null;
    }

    /**
     * 共通検索用プルダウン作成.<br>
     * <br>
     * 概要:<br>
     * プルダウンの作成
     * <br>
     * @return 結果
     */
    public String getComSearchPld() {
        CM_BaseForm form = this.getActionForm();

        // リンクから遷移された場合は、プルダウンの作成やセッション保存は行わない
        if (CM_CommonUtil.isNotNullOrBlank(form.hdnLinkJump)) {
            if (CM_CommonUtil.isNotNullOrBlank(form.comLnId)) {
                String processId = null;
                List<BeanMap> processIdList;
                processIdList = this.setFormForLink(form);
                if (processIdList != null && !processIdList.isEmpty()) {
                    if (CM_CommonUtil.isNotNullOrBlank(((BigDecimal) processIdList.get(0).get("processId")))) {
                        processId = ((BigDecimal) processIdList.get(0).get("processId")).toString();
                    }
                }
                if (CM_CommonUtil.isNotNullOrBlank(processId)) {
                    form.comProcessId = processId;
                }
            } else {
                form.comProcessId = null;
            }
        }

        CM_A10_SearchPldTypeInfo searchPldType = form.getComSearchPldType();
        if (searchPldType == null) {
            return "ERROR:CM_A10_SearchPldTypeInfo is not defined.";
        }
        this.comSearchInfo = this.getComSearchInfo();

        if (CM_CommonUtil.isNotNullOrBlank(form.hdnIsLoginFirstFlg) &&
                form.hdnIsLoginFirstFlg.equalsIgnoreCase("1")) {
            // 初回ログイン時は各情報をクリアする
            form.comPlantCode = this.getService().getUserPlantCode();
            this.clearComSearchCondition();
        } else {
            if (CM_CommonUtil.isNullOrBlank(form.hdnLinkJump)) {
                // リンクから遷移されなかったときは、チェックする。
                if (this.comSearchInfo.isSameComSearchCondRem(form) && this.comSearchInfo.hasPldData()) {

                    boolean isSame = true;

                    // 工場プルダウン取得
                    CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
                    List<Map<String, String>> tmpPlantList = mstDataService.getPlantPld();
                    if (tmpPlantList.size() != this.comSearchInfo.pldPlantList.size()) {
                        isSame = false;
                    }

                    // 製造ラインプルダウン取得
                    List<Map<String, String>> tmpList = mstDataService.getMstSeizouLinePld(form.comPlantCode, false);
                    if (tmpList.size() != this.comSearchInfo.pldSeizouLineList.size()) {
                        isSame = false;
                    }
                    if (isSame) {

                        // 検索条件に変更なし 且つ プルダウンデータが存在する場合
                        this.loadComDisplaySearchConditionList();

                        if (CM_A04_Const.COM_SEARCH_PLD_TYPE.DISABLED.equals(searchPldType.comPlantCdType)) {
                            this.comSearchInfo.pldPlantList.clear();
                        }
                        return null;
                    }
                }
            }
        }

        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);

        /* **************************************/
        // プルダウン作成
        /* **************************************/
        // 工場プルダウン取得
        if (CM_A04_Const.COM_SEARCH_PLD_TYPE.DISABLED.equals(searchPldType.comPlantCdType)) {
            this.comSearchInfo.pldPlantList.clear();
        } else {
            this.comSearchInfo.pldPlantList = mstDataService.getPlantPld();
        }

        Map<String,String> checkPlant;
        if (this.comSearchInfo.pldPlantList.size() > 0) {
            for (int i =0; i < this.comSearchInfo.pldPlantList.size(); i++) {
                checkPlant = this.comSearchInfo.pldPlantList.get(i);
                List<CM_PageAuthInfoDto> pageList = this.getService().getPageListInfo(checkPlant.get("value"));

                // 現在のページIDを取得
                String pageId = this.getPageId();
                for (int j = 0; j < pageList.size(); j++) {
                    CM_PageAuthInfoDto pageInfo = pageList.get(j);
                    if (pageInfo.pageId.equals(pageId)) {
                        // ページIDが一致したときの権限をチェック
                        if (pageInfo.authSetting.equals("0")) {
                            // 権限が"0（閲覧不可）"だったらリストから削除する
                            this.comSearchInfo.pldPlantList.remove(i);
                        }
                    }
                }
            }
        }

        // 取得したページIDが閲覧不可の場合は工場プルダウンリストから削除する
        List<CM_PageAuthInfoDto> pageList = this.getService().getPageListInfo(form.comPlantCode);

        if (CM_CommonUtil.isNotNullOrBlank(form.comPlantCode)) {

            /* ***************/
            // グループ(製造ライン)
            /* ***************/
            if (CM_A04_Const.COM_SEARCH_PLD_TYPE.REQUIRED.equals(searchPldType.comSeizouLnIdType)) {
                // 必須選択

                // 製造ラインプルダウン取得
                this.comSearchInfo.pldSeizouLineList = mstDataService.getMstSeizouLinePld(form.comPlantCode, false);

                // 未指定の場合、プルダウンの先頭を選択
                if (CM_CommonUtil.isNullOrBlank(form.comSeizouLnId) && !this.comSearchInfo.pldSeizouLineList.isEmpty()) {
                    form.comSeizouLnId = this.comSearchInfo.pldSeizouLineList.get(0)
                            .get(FW01_03_CreateSingleSelectTagUtil.FW01_03_KEY_OPT_VALUE);
                }

                // プルダウン結果から再設定
                form.comSeizouLnId = checkPldData(this.comSearchInfo.pldSeizouLineList, form.comSeizouLnId);

            } else if (CM_A04_Const.COM_SEARCH_PLD_TYPE.SELECTABLE.equals(searchPldType.comSeizouLnIdType)) {
                // 選択可

                // 製造ラインプルダウン取得
                this.comSearchInfo.pldSeizouLineList = mstDataService.getMstSeizouLinePld(form.comPlantCode, true);

                // プルダウン結果から再設定
                form.comSeizouLnId = checkPldData(this.comSearchInfo.pldSeizouLineList, form.comSeizouLnId);
            } else {
                // 選択不可

                this.comSearchInfo.pldSeizouLineList.clear();
            }

            /* ***************/
            // 工程
            /* ***************/
            if (CM_A04_Const.COM_SEARCH_PLD_TYPE.REQUIRED.equals(searchPldType.comProcessIdType)) {
                // 必須選択

                // 工程プルダウン取得
                this.comSearchInfo.pldProcessList
                    = mstDataService.getMstProcessPld(form.comPlantCode, form.comSeizouLnId, false);

                // 未指定の場合、プルダウンの先頭を選択
                if (CM_CommonUtil.isNullOrBlank(form.comProcessId) && !this.comSearchInfo.pldProcessList.isEmpty()) {
                    form.comProcessId = this.comSearchInfo.pldProcessList.get(0)
                            .get(FW01_03_CreateSingleSelectTagUtil.FW01_03_KEY_OPT_VALUE);
                }

                // プルダウン結果から再設定
                form.comProcessId = checkPldData(this.comSearchInfo.pldProcessList, form.comProcessId);

            } else if (CM_A04_Const.COM_SEARCH_PLD_TYPE.SELECTABLE.equals(searchPldType.comProcessIdType)) {
                // 選択可

                // 工程プルダウン取得
                this.comSearchInfo.pldProcessList
                    = mstDataService.getMstProcessPld(form.comPlantCode, form.comSeizouLnId, true);

                // プルダウン結果から再設定
                form.comProcessId = checkPldData(this.comSearchInfo.pldProcessList, form.comProcessId);
            } else {
                // 選択不可

                this.comSearchInfo.pldProcessList.clear();
            }

            /* ***************/
            // ライン
            /* ***************/
            if (CM_A04_Const.COM_SEARCH_PLD_TYPE.REQUIRED.equals(searchPldType.comLnIdType)) {
                // 必須選択

                // ラインプルダウン取得
                this.comSearchInfo.pldLineList = mstDataService.getLinePld(form.comPlantCode, form.comSeizouLnId, form.comProcessId, false);

                // 未指定の場合、プルダウンの先頭を選択
                if (CM_CommonUtil.isNullOrBlank(form.comLnId) && !this.comSearchInfo.pldLineList.isEmpty()) {
                    form.comLnId = this.comSearchInfo.pldLineList.get(0)
                            .get(FW01_03_CreateSingleSelectTagUtil.FW01_03_KEY_OPT_VALUE);
                }

                // プルダウン結果から再設定
                form.comLnId = checkPldData(this.comSearchInfo.pldLineList, form.comLnId);

            } else if (CM_A04_Const.COM_SEARCH_PLD_TYPE.SELECTABLE.equals(searchPldType.comLnIdType)) {
                // 選択可

                // ラインプルダウン取得
                this.comSearchInfo.pldLineList = mstDataService.getLinePld(form.comPlantCode, form.comSeizouLnId, form.comProcessId, true);

                // プルダウン結果から再設定
                if (CM_CommonUtil.isNotNullOrBlank(form.comProcessId)) {
                    form.comLnId = checkPldData(this.comSearchInfo.pldLineList, form.comLnId);
                } else {
                    // 選択可の場合、上位（工程）が未選択の場合は空にする。
                    form.comLnId = "";
                    this.comSearchInfo.pldLineList.clear();
                }
            } else {
                // 選択不可

                this.comSearchInfo.pldLineList.clear();
            }

            /* ***************/
            // ST
            /* ***************/
            if (CM_A04_Const.COM_SEARCH_PLD_TYPE.REQUIRED.equals(searchPldType.comStIdType)) {
                // 必須選択

                // STプルダウン取得
                this.comSearchInfo.pldStationList
                    = mstDataService.getMstStationPld(
                        form.comPlantCode, form.comSeizouLnId, form.comProcessId, form.comLnId, false);

                // 未指定の場合、プルダウンの先頭を選択
                if (CM_CommonUtil.isNullOrBlank(form.comStId) && !this.comSearchInfo.pldStationList.isEmpty()) {
                    form.comStId = this.comSearchInfo.pldStationList.get(0)
                            .get(FW01_03_CreateSingleSelectTagUtil.FW01_03_KEY_OPT_VALUE);
                }

                // プルダウン結果から再設定
                form.comStId = checkPldData(this.comSearchInfo.pldStationList, form.comStId);

            } else if (CM_A04_Const.COM_SEARCH_PLD_TYPE.SELECTABLE.equals(searchPldType.comStIdType)) {
                // 選択可

                // STプルダウン取得
                this.comSearchInfo.pldStationList
                    = mstDataService.getMstStationPld(
                            form.comPlantCode, form.comSeizouLnId, form.comProcessId, form.comLnId, true);

                // プルダウン結果から再設定
                if ((CM_CommonUtil.isNotNullOrBlank(form.comProcessId))
                        && (CM_CommonUtil.isNotNullOrBlank(form.comLnId))) {
                    form.comStId = checkPldData(this.comSearchInfo.pldStationList, form.comStId);
                } else {
                    // 選択可の場合、上位（工程とライン）が未選択の場合は空にする。
                    form.comStId = "";
                    this.comSearchInfo.pldStationList.clear();
                }
            } else {
                // 選択不可

                this.comSearchInfo.pldStationList.clear();
            }

        } else {
            // グループプルダウン
            this.comSearchInfo.pldSeizouLineList.clear();
            // 工程プルダウン
            this.comSearchInfo.pldProcessList.clear();
            // ラインプルダウン
            this.comSearchInfo.pldLineList.clear();
            // STプルダウン
            this.comSearchInfo.pldStationList.clear();

        }

        /* **************************************/
        // 共通検索条件表示用のリストを作成
        /* **************************************/
        this.loadComDisplaySearchConditionList();

        /* **************************************/
        // 共通検索情報保存
        /* **************************************/
        this.comSearchInfo.saveComSearchCondRem(form);

        return null;
    }
    /**
     * 機種カテゴリ 検索用プルダウン作成.<br>
     * <br>
     * 概要:<br>
     * プルダウンの作成
     * <br>
     * @return 結果
     */
    public String getComSearchCategoryPld() {
        return null;
    }

    /**
     * プルダウンに値があるかどうかをチェック.
     *
     * @param _pld プルダウン
     * @param _val 値
     * @return プルダウンで選択される値
     */
    protected String checkPldData(final List<Map<String, String>> _pld, final String _val) {
        String res = null;

        if (!_pld.isEmpty()) {
            for (Map<String, String> pldData : _pld) {
                String value = pldData.get(FW01_03_CreateSingleSelectTagUtil.FW01_03_KEY_OPT_VALUE);
                if (StringUtil.equals(value, _val)) {
                    res = _val;
                    break;
                }
            }
            if (res == null) {
                res = _pld.get(0).get(FW01_03_CreateSingleSelectTagUtil.FW01_03_KEY_OPT_VALUE);
            }
        }

        return res;
    }

    /**
     *
     * 共通検索条件クリア処理.<br>
     *<br>
     * 概要:<br>
     *  初期検索条件を取得し、検索条件の初期化を行う
     *<br>
     * ※「記憶」処理は下記に実装<br>
     * {@link jp.ysk.mmcloud.visualization.common.service.CM_ListBaseService#getComRegisterParamNameList}
     */
    protected void clearComSearchCondition() {
        CM_BaseForm form = this.getActionForm();
        // グループ(製造ラインID)
        form.comSeizouLnId = null;
        // 工程コード
        form.comProcessId = null;
        // ライン番号
        form.comLnId = null;
        // ステーション番号
        form.comStId = null;
    }

    /**
     * 共通検索条件表示用のリストを作成.<br>
     *<br>
     * 概要:<br>
     *  共通検索情報から、現在検索条件 表示域に表示する共通リストを作成する。<br>
     *<br>
     */
    public void loadComDisplaySearchConditionList() {
        CM_BaseForm form = this.getActionForm();
        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
        CM_A09_ComSearchInfo comSearchInfoBuf = this.getComSearchInfo();

        this.comDisplaySearchConditionList.clear();

        // 工場名
        if (CM_CommonUtil.isNotNullOrBlank(form.comPlantCode)) {
            MaPlantEntity plant = mstDataService.getMaPlantEntity(form.comPlantCode);
            if (CM_CommonUtil.isNotNullOrBlank(plant)) {
                this.comDisplaySearchConditionList.add(plant.plantSNm);
            }
        }

        // グループ(製造ラインID)
        if (CM_CommonUtil.isNotNullOrBlank(form.comSeizouLnId)) {
            String groupNm = CM_CodeUtil.getTextOfMapList(comSearchInfoBuf.pldSeizouLineList, form.comSeizouLnId);
            if (CM_CommonUtil.isNotNullOrBlank(groupNm)) {
                this.comDisplaySearchConditionList.add(groupNm);
            }
        }

        // 工程コード
        if (CM_CommonUtil.isNotNullOrBlank(form.comProcessId)) {
            String processCodeNm = CM_CodeUtil.getTextOfMapList(comSearchInfoBuf.pldProcessList, form.comProcessId);
            if (CM_CommonUtil.isNotNullOrBlank(processCodeNm)) {
                this.comDisplaySearchConditionList.add(processCodeNm);
            }
        }

        // ライン番号
        if (CM_CommonUtil.isNotNullOrBlank(form.comLnId)) {
            String lineNoNm = CM_CodeUtil.getTextOfMapList(comSearchInfoBuf.pldLineList, form.comLnId);
            if (CM_CommonUtil.isNotNullOrBlank(lineNoNm)) {
                this.comDisplaySearchConditionList.add(lineNoNm);
            }
        }

        // ステーション番号
        if (CM_CommonUtil.isNotNullOrBlank(form.comStId)) {
            String stationNoNm = CM_CodeUtil.getTextOfMapList(comSearchInfoBuf.pldStationList, form.comStId);
            if (CM_CommonUtil.isNotNullOrBlank(stationNoNm)) {
                this.comDisplaySearchConditionList.add(stationNoNm);
            }
        }
    }

    /**
     * HOME検索条件表示用のリストを作成.<br>
     *<br>
     * 概要:<br>
     *  HOME検索情報から、現在検索条件 表示域に表示する共通リストを作成する。<br>
     *<br>
     */
    private void loadHomeDisplaySearchConditionList() {
        CM_BaseForm form = this.getActionForm();
        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
        CM_A12_HomeSearchInfo homeSearchInfoBuf = this.getHomeSearchInfo();

        this.homeDisplaySearchConditionList.clear();

        // 工場名
        if (CM_CommonUtil.isNotNullOrBlank(form.comPlantCode)) {
            MaPlantEntity plant = mstDataService.getMaPlantEntity(form.comPlantCode);
            if (CM_CommonUtil.isNotNullOrBlank(plant)) {
                this.homeDisplaySearchConditionList.add(plant.plantSNm);
            }
        }

        // グループ(製造ラインコード)
        if (CM_CommonUtil.isNotNullOrBlank(form.comSeizouLnId)) {
            String groupNm = CM_CodeUtil.getTextOfMapList(homeSearchInfoBuf.pldSeizouLineList, form.comSeizouLnId);
            if (CM_CommonUtil.isNotNullOrBlank(groupNm)) {
                this.homeDisplaySearchConditionList.add(groupNm);
            }
        }

        // 工程ID
        if (CM_CommonUtil.isNotNullOrBlank(form.comProcessId)) {
            String processCodeNm = CM_CodeUtil.getTextOfMapList(homeSearchInfoBuf.pldProcessList, form.comProcessId);
            if (CM_CommonUtil.isNotNullOrBlank(processCodeNm)) {
                this.homeDisplaySearchConditionList.add(processCodeNm);
            }
        }

        // ライン番号
        if (CM_CommonUtil.isNotNullOrBlank(form.comLnId)) {
            String lineNoNm = CM_CodeUtil.getTextOfMapList(homeSearchInfoBuf.pldLineList, form.comLnId);
            if (CM_CommonUtil.isNotNullOrBlank(lineNoNm)) {
                this.homeDisplaySearchConditionList.add(lineNoNm);
            }
        }
    }

    /**
     * 共通検索エリアを更新する.<br>
     *<br>
     * 概要:<br>
     *   プルダウン選択時に共通検索エリアを更新する。
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String changeComPld() {
        // プルダウン作成
        this.getComSearchPld();
        return "../common/com_searchArea.jsp";
    }
    /**
     * 共通検索エリアを更新する.<br>
     *<br>
     * 概要:<br>
     *   プルダウン選択時に共通検索エリアを更新する。
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String changeSettingComPld() {
        // プルダウン作成
        this.getComSearchPld();
        return "../common/com_settingSearchArea.jsp";
    }

    /**
     * 共通検索エリアと表示エリアを更新する.<br>
     *<br>
     * 概要:<br>
     *   プルダウン選択時に共通検索エリアと表示エリアを更新する。
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String changeSettingComPldSearch() {
        // プルダウン作成
        this.getComSearchPld();

        // 検索処理
        this.search();

        return this.getJspFileName();
    }


    /**
     * お気に入り情報取得.
     */
    public void loadFavoriteInfo() {
        // お気に入り登録可能判断
        this.checkFavoriteSaveAvail();

        List<BeanMap> favoriteList = this.getService().getFavoriteList();
        if (favoriteList != null && !favoriteList.isEmpty()) {
            Integer topFavoriteNo = (Integer) favoriteList.get(0).get(TrSearchConditionEntityNames.favoriteNo().toString());
            if (topFavoriteNo == 0) {
                // TOPページは分離
                this.favoriteTop = favoriteList.get(0);
                favoriteList.remove(0);
            }
            this.favoriteListMap.clear();
            for (BeanMap data : favoriteList) {
                Integer favoriteNo = (Integer) data.get(TrSearchConditionEntityNames.favoriteNo().toString());
                this.favoriteListMap.put(favoriteNo, data);
            }
        }

    }

    /**
     * お気に入り情報を取得.<br>
     * <br>
     * 概要:<br>
     *   ユーザーのお気に入り情報を取得
     *
     * @param _favoriteNo お気に入り番号
     * @return お気に入り情報
     */
    public Map<String, Object> loadFavoriteInfoDetails(final Integer _favoriteNo) {
        Map<String, Object> ret = new HashMap<String, Object>();

        ret.clear();

        // お気に入り情報取得
        List<BeanMap> favoriteList = this.getService().getFavoriteInfo(_favoriteNo);
        if (favoriteList != null && !favoriteList.isEmpty()) {
            for (BeanMap data : favoriteList) {
                // 名称
                String strName = (String) data.get(TrSearchConditionEntityNames.paramName().toString());
                // 値
                String strValue = (String) data.get(TrSearchConditionEntityNames.paramValue().toString());

                ret.put(strName, strValue);
            }
        }

        return ret;
    }

    /**
     * お気に入り登録可能かどうかを判断.
     */
    private void checkFavoriteSaveAvail() {
        // 画面URL定義が存在することを確認
        String pageUrlStr = this.getService().getPageUrlStr(this.getPageId());
        if (CM_CommonUtil.isNotNullOrBlank(pageUrlStr)) {
            this.favoriteSaveAvail = true;
        }
    }

    /**
     *
     * 検索条件保存処理.<br>
     *<br>
     * 概要:<br>
     *
     *<br>
     * @return jsp
     */
    @Execute(validator = false)
    public String registerFavorite() {
         // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        // 処理開始
        this.getService().init(this.cM_A03_SessionDto);

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        // 検索条件チェック処理
        try {
            this.getService().checkRegisterSearchCondition(formMap);
        } catch (FW00_12_BusinessException be) {
            this.alertErrorInfoForAjax(be.getMsgKey(), be.getFocusCtlId());
        }

        // 検索条件登録処理
        this.getService().registerSearchCondition(formMap, this.getPageId());

        // お気に入り情報取得
        this.loadFavoriteInfo();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, COM_FAVORITE_AREA_JSP);

        return COM_FAVORITE_AREA_JSP;
    }

    /**
     * お気に入り削除.<br>
     *<br>
     * 概要:<br>
     *   お気に入りを削除する。
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String deleteFavorite() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        // 処理開始
        this.getService().init(this.cM_A03_SessionDto);

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        // お気に入り削除処理
        this.getService().deleteFavorite(formMap);

        // お気に入り情報取得
        this.loadFavoriteInfo();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, COM_FAVORITE_AREA_JSP);

        return COM_FAVORITE_AREA_JSP;
    }

    /**
     * アンドン用データ取得
     */
    public String getAndongInfo() {
        this.initServiceIfNot();

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        // 工場コードを取得
        if (CM_CommonUtil.isNullOrBlank(formMap.get(CM_BaseForm.COM_PLANT_CODE))) {
            return null;
        }

        // comDataDateDispのチェック
        if (CM_CommonUtil.isNotNullOrBlank(formMap.get(CM_BaseForm.COM_DATA_DATE_DISP))) {
            String currentYearChar = CM_DisplayCharResourceUtil.getDisplayCharValue(
                    this.cM_A03_SessionDto.ssn_CustomerCD, this.cM_A03_SessionDto.ssn_UserLangCD, "CMMCDCCM00000_058");
            if (formMap.get(CM_BaseForm.COM_DATA_DATE_DISP).toString().equals(currentYearChar)) {
                formMap.put(CM_BaseForm.COM_DATA_DATE_DISP, CM_A04_Const.DISP_RECENT_FLG);
            }
        }

        // アンドン用データ取得
        this.andongInfoDto = this.getService().getAndongInfo(formMap);

        return null;
    }

    /**
     * ヘッダ警告メッセージ取得.
     * @return 警告メッセージ
     */
    public String getHeaderAlertMessage() {
        // フォーム情報保存
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);

        // 警告メッセージ取得
        return mstDataService.getAlertMessage(formMap);
    }

    /**
     * 共通検索用日時データ設定.<br>
     * <br>
     * 概要:<br>
     * 初期値を設定する
     * <br>
     * @return 結果
     */
    public String setInitDateInfo() {

        Timestamp startDatetime;
        CM_BaseForm form = this.getActionForm();

        CM_A11_SearchDateTypeInfo searchDateType = form.getComSearchDateType();
        if (searchDateType == null) {
            return "ERROR:CM_A11_SearchDateTypeInfo is not defined.";
        }

        if (CM_CommonUtil.isNullOrBlank(form.comDateTypeDisp)) {
            // 種別を設定
            form.comDateTypeDisp = searchDateType.comDateTypeInfo;
        }

        // 過去12ヶ月表示文言
        String currentYearChar = CM_DisplayCharResourceUtil.getDisplayCharValue(
                this.cM_A03_SessionDto.ssn_CustomerCD, this.cM_A03_SessionDto.ssn_UserLangCD, "CMMCDCCM00000_058");
        if (StringUtil.equals(currentYearChar, form.comDataDateDisp)) {
            if (searchDateType.dispRecentYear) {
                form.comDataDateDisp = CM_A04_Const.DISP_RECENT_FLG;
            } else {
                // 「過去12ヶ月」が選択された状態で「過去12ヶ月」非対応画面に遷移した場合は、
                // 日時情報を初期化する
                form.comDataDateDisp = "";
            }
        }
        // 選択可能な日付種別に再設定
        form.comDateTypeDisp = searchDateType.getDateTypeDisp(form.comDateTypeDisp);

        // 工場マスタ(見える化専用)の取得
        SimpleWhere where = new SimpleWhere();
        where.eq(MaPlantMierukaEntityNames.plantCd().toString(), form.comPlantCode);
        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
        MaPlantEntity plant = mstDataService.getMaPlantEntity(form.comPlantCode);

        // 開始年月日の取得
        if ((plant != null) && (plant.runningStartDatetime != null)) {
            startDatetime = plant.runningStartDatetime;
        } else {
            startDatetime = CM_CommonUtil.parseStringToTimestamp(CM_A04_Const.DEFAULT_RUNNING_START_DATETIME, CM_A04_Const.DATE_FORMAT_MILLI_HYPHEN);
        }

        // 現在日時の取得
        Calendar sysCal = Calendar.getInstance();

        // 日付種別の設定チェック
        if (CM_CommonUtil.isNotNullOrBlank(form.comDateTypeDisp)) {
            if (!checkComDataDateDisp()) {
                // 設定に従ってデフォルト日時を設定する
                if (form.comDateTypeDisp.equals(CM_A04_Const.DATE_TYPE_GETUJI)) {
                    // 月次の場合
                    if (searchDateType.dispRecentYear) {
                        // 過去12ヶ月表示
                        form.comDataDateDisp = CM_A04_Const.DISP_RECENT_FLG;
                    } else {
                        Calendar cal = Calendar.getInstance();
                        cal.setTimeInMillis(startDatetime.getTime());
                        cal.set(Calendar.YEAR, sysCal.get(Calendar.YEAR));
                        if (cal.compareTo(sysCal) > 0) {
                            cal.add(Calendar.YEAR, -1);
                        }
                        form.comDataDateDisp = String.format("%d", cal.get(Calendar.YEAR));
                    }
                } else if (form.comDateTypeDisp.equals(CM_A04_Const.DATE_TYPE_NITIJI)) {
                    // 日次の場合
                    Calendar cal = Calendar.getInstance();
                    cal.setTimeInMillis(startDatetime.getTime());
                    cal.set(Calendar.YEAR, sysCal.get(Calendar.YEAR));
                    cal.set(Calendar.MONTH, sysCal.get(Calendar.MONTH));
                    if (cal.compareTo(sysCal) > 0) {
                        cal.add(Calendar.MONTH, -1);
                    }
                    // 月度を求めるため、15日加算した後、日以下を切り捨てる
                    // （例えば3/21の場合は4月度(4/1)として扱いたいため）
                    cal.add(Calendar.DAY_OF_MONTH, 15);
                    form.comDataDateDisp = String.format("%d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
                } else {
                    // 時間別の場合（今日）
                    Calendar cal = Calendar.getInstance();
                    cal.setTimeInMillis(startDatetime.getTime());
                    cal.set(Calendar.YEAR, sysCal.get(Calendar.YEAR));
                    cal.set(Calendar.MONTH, sysCal.get(Calendar.MONTH));
                    cal.set(Calendar.DAY_OF_MONTH, sysCal.get(Calendar.DAY_OF_MONTH));
                    if (cal.compareTo(sysCal) > 0) {
                        cal.add(Calendar.DAY_OF_MONTH, -1);
                    }
                    form.comDataDateDisp = String.format("%d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
                }
            }
        } else {
            form.comDataDateDisp = "";
        }
        return null;
    }

    /**
     * 日付選択の再設定が必要かどうかを確認.
     * @return true:再設定不要
     */
    private boolean checkComDataDateDisp() {
        CM_BaseForm form = this.getActionForm();
        String comDataDateDisp = form.comDataDateDisp;
        if (CM_CommonUtil.isNullOrBlank(comDataDateDisp)) {
            return false;
        } else {
            String currentYearChar = CM_DisplayCharResourceUtil.getDisplayCharValue(
                    this.cM_A03_SessionDto.ssn_CustomerCD, this.cM_A03_SessionDto.ssn_UserLangCD, "CMMCDCCM00000_058");
            if (comDataDateDisp.equals(currentYearChar)) {
                comDataDateDisp = CM_A04_Const.DISP_RECENT_FLG;
            }
        }
        boolean res = false;

        CM_A11_SearchDateTypeInfo searchDateType = form.getComSearchDateType();
        if (!searchDateType.dispRecentYear && CM_A04_Const.DISP_RECENT_FLG.equals(comDataDateDisp)) {
            // 過去12ヶ月非表示で過去12ヶ月が選択されている場合
            return false;
        }

        int splitSize = comDataDateDisp.split("-").length;
        if (form.comDateTypeDisp.equals(CM_A04_Const.DATE_TYPE_GETUJI)) {
            // 月次の場合
            if (splitSize == 1) {
                res = true;
            }
        } else if (form.comDateTypeDisp.equals(CM_A04_Const.DATE_TYPE_NITIJI)) {
            // 日次の場合
            if (splitSize == 2) {
                res = true;
            }
        } else {
            // 時間別の場合（今日）
            if (splitSize == 3) {
                res = true;
            }
        }
        return res;
    }

    /**
     * 日時情報更新処理.<br>
     *<br>
     * 概要:<br>
     *  日時情報の更新＆設定<br>
     *<br>
     */
    public void setDisplayDateData(CM_BaseForm _form) {

        String strYear;
        String strMonth;
        String strDay;

        List<String> param = new ArrayList<String>(3);

        // 日付プルダウンの左／右ボタンの処理
        String strDateType = _form.comDateTypeDisp;
        if (CM_CommonUtil.isNotNullOrBlank(_form.hdnMoveDirection)) {
            if (_form.hdnMoveDirection.equals(CM_A04_Const.CLICK_RIGHT_BUTTON)) {
                // 右ボタンが押された
                if (strDateType.equals(CM_A04_Const.DATE_TYPE_GETUJI)) {
                    // 月次選択
                    _form.comDataDateDisp = this.getNextYear(_form.comDataDateDisp);
                } else if (strDateType.equals(CM_A04_Const.DATE_TYPE_NITIJI)) {
                    // 日次選択
                    strYear = strMonth = _form.comDataDateDisp;
                    strYear = strYear.substring(0, 4);
                    strMonth = strMonth.substring(5, 7);
                    param = this.getNextMonth(strYear, strMonth, "21");
                    strYear = param.get(0);
                    strMonth = param.get(1);
                    _form.comDataDateDisp = strYear + FW00_19_Const.HYPHEN_STR + strMonth;
                } else {
                    // 時間別選択
                    strYear = strMonth = strDay = _form.comDataDateDisp;
                    strYear = strYear.substring(0, 4);
                    strMonth = strMonth.substring(5, 7);
                    strDay = strDay.substring(8, 10);
                    param = this.getNextDay(strYear, strMonth, strDay);
                    _form.comDataDateDisp = param.get(0) + FW00_19_Const.HYPHEN_STR + param.get(1) + FW00_19_Const.HYPHEN_STR + param.get(2);
                }

            } else if (_form.hdnMoveDirection.equals(CM_A04_Const.CLICK_LEFT_BUTTON)) {
                // 左ボタンが押された
                if (strDateType.equals(CM_A04_Const.DATE_TYPE_GETUJI)) {
                    // 月次選択
                    _form.comDataDateDisp = this.getBeforeYear((String) _form.comDataDateDisp);
                } else if (strDateType.equals(CM_A04_Const.DATE_TYPE_NITIJI)) {
                    // 日次選択
                    strYear = strMonth = _form.comDataDateDisp;
                    strYear = strYear.substring(0, 4);
                    strMonth = strMonth.substring(5, 7);
                    param = this.getBeforeMonth(strYear, strMonth, "21");
                    _form.comDataDateDisp = param.get(0) + FW00_19_Const.HYPHEN_STR + param.get(1);
                } else {
                    // 時間別選択
                    strYear = strMonth = strDay = _form.comDataDateDisp;
                    strYear = strYear.substring(0, 4);
                    strMonth = strMonth.substring(5, 7);
                    strDay = strDay.substring(8, 10);
                    param = this.getBeforeDay(strYear, strMonth, strDay);
                    _form.comDataDateDisp = param.get(0) + FW00_19_Const.HYPHEN_STR + param.get(1) + FW00_19_Const.HYPHEN_STR + param.get(2);
                }

            } else {
                ;
            }

            // フラグをクリア
            _form.hdnMoveDirection = null;
        }

        // 日時情報設定
        this.setSearchDate(_form);
    }

    /**
     * 日時情報設定処理.<br>
     *<br>
     * 概要:<br>
     *  日時情報の設定<br>
     *<br>
     */
    public void setSearchDate(CM_BaseForm _form) {

        // 日時情報設定
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, _form).execute();
        this.setSearchDate(_form, formMap);

        // 現在の年度
        this.currentYear = this.getService().getCurrentYear(_form.comPlantCode);
    }

    /**
     * 日時情報設定処理.<br>
     *<br>
     * 概要:<br>
     *  日時情報の設定<br>
     *<br>
     */
    public void setSearchDate(CM_BaseForm _form, BeanMap _formMap) {
        // 過去12ヶ月表示文言
        String currentYearChar = CM_DisplayCharResourceUtil.getDisplayCharValue(
                this.cM_A03_SessionDto.ssn_CustomerCD, this.cM_A03_SessionDto.ssn_UserLangCD, "CMMCDCCM00000_058");

        // 日付検索条件
        String comDataDateDisp = (String) _formMap.get(CM_BaseForm.COM_DATA_DATE_DISP);
        if (CM_CommonUtil.isNotNullOrBlank(comDataDateDisp)) {
            if (comDataDateDisp.equals(currentYearChar)) {
                comDataDateDisp = CM_A04_Const.DISP_RECENT_FLG;
            }
        }

        // comDataDateDispのチェック
        if (CM_CommonUtil.isNotNullOrBlank(_formMap.get(CM_BaseForm.COM_DATA_DATE_DISP))) {
            if (_formMap.get(CM_BaseForm.COM_DATA_DATE_DISP).toString().equals(currentYearChar)) {
                comDataDateDisp = CM_A04_Const.DISP_RECENT_FLG;
            }
        }
        _formMap.put(DATE_SERCH_TYPE_KEY, comDataDateDisp);
        _formMap.put(CM_BaseForm.COM_DATA_DATE_DISP, comDataDateDisp);

        // 検索日時From/Toを作成
        this.getService().setDefaultSearchDate(_formMap);
        // 作成したパラメータを設定
        // comDateTypeDisp, comDataDateDispは初回時やパラメータ不整合により書きかえられる可能性があるため、再設定しておく
        _form.comDateType = _formMap.get(CM_BaseForm.COM_DATE_TYPE).toString();
        _form.comDataDateFrom = _formMap.get(CM_BaseForm.COM_DATA_DATE_FROM).toString();
        _form.comDataDateTo = _formMap.get(CM_BaseForm.COM_DATA_DATE_TO).toString();
        _form.comDateTypeDisp = _formMap.get(CM_BaseForm.COM_DATE_TYPE_DISP).toString();
        _form.comDataDateDisp = _formMap.get(CM_BaseForm.COM_DATA_DATE_DISP).toString();
        _form.comCurrentYearMonth = _formMap.get(CM_BaseForm.COM_CURRENT_YEAR_MONTH).toString();
        if (CM_A04_Const.DISP_RECENT_FLG.equals(_form.comDataDateDisp)) {
            // 検索条件表示用に設定
            _form.comDataDateDisp = currentYearChar;
        }
    }


    /**
     * うるう年の判定.<br>
     *<br>
     * 概要:<br>
     *   うるう年かどうか判定する
     *<br>
     * @param _year 判定したい年
     * @return boolean Yes/No
     */
    private boolean isLeapYear(final int _year) {
        if ((_year % 4 == 0) && (_year % 100 != 0) || (_year % 400 == 0)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 次日の取得.<br>
     *<br>
     * 概要:<br>
     *   指定した年月日の次日を取得する
     *<br>
     * @param _year 年
     * @param _month 月
     * @param _day 日
     * @return List<String> 年／月／日
     */
    private List<String> getNextDay(final String _year, final String _month, final String _day) {
        int intYear;
        int intMonth;
        int intDay;
        Integer oi;
        String strMonth;
        String strDay;

        List<String> retParam = new ArrayList<String>(3);

        intYear = Integer.parseInt(_year);
        intMonth = Integer.parseInt(_month);
        intDay = Integer.parseInt(_day) + 1;

        switch (intMonth) {
        case 1: case 3: case 5: case 7: case 8: case 10:
            if (intDay > 31) {
                intDay = 1;
                intMonth = intMonth + 1;
            }
            break;
        case 12:
            if (intDay > 31) {
                intDay = 1;
                intMonth = 1;
                intYear = intYear + 1;
            }
            break;
        case 4: case 6: case 9: case 11:
            if (intDay > 30) {
                intDay = 1;
                intMonth = intMonth + 1;
            }
            break;
        case 2:
            if (this.isLeapYear(intYear-1)) {
                if (intDay > 29) {
                    intDay = 1;
                    intMonth = intMonth + 1;
                } else {
                    if (intDay > 28) {
                        intDay = 1;
                        intMonth = intMonth + 1;
                    }
                }
            }
        }

        // 年のセット
        oi = new Integer(intYear);
        retParam.add(String.format("%s", oi.toString()));

        // 月の考慮
        if (intMonth > 12) {
            intMonth = 1;
        }

        // 月のセット
        oi = new Integer(intMonth);
        strMonth = oi.toString();
        if (strMonth.length() < 2)
            strMonth = "0" + strMonth;
        retParam.add(String.format("%s", strMonth));

        // 日のセット
        oi = new Integer(intDay);
        strDay = oi.toString();
        if (strDay.length() < 2) {
            strDay = "0" + strDay;
        }
        retParam.add(String.format("%s", strDay));

        return retParam;
    }

    /**
     * 前日の取得.<br>
     *<br>
     * 概要:<br>
     *   指定した年月日の前日を取得する
     *<br>
     * @param _year 年
     * @param _month 月
     * @param _day 日
     * @return List<String> 年／月／日
     */
    private List<String> getBeforeDay(final String _year, final String _month, final String _day) {
        int intYear;
        int intMonth;
        int intDay;

        String strYear;
        String strMonth;
        String strDay;

        Integer oi;

        List<String> retParam = new ArrayList<String>(3);

        intYear = Integer.parseInt(_year);
        intMonth = Integer.parseInt(_month);
        intDay = Integer.parseInt(_day) - 1;

        if (intDay < 1) {
            intMonth = intMonth - 1;
            if (intMonth < 1)
            {
                intMonth = 12;
                intYear = intYear - 1;
            }

            switch (intMonth) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                intDay = 31;
                break;
            case 4: case 6: case 9: case 11:
                intDay = 30;
                break;
            case 2:
                if (this.isLeapYear(intYear)) {
                    intDay = 29;
                } else {
                    intDay = 28;
                }
                break;
            }
        }

        // 年のセット
        oi = new Integer(intYear);
        retParam.add(String.format("%s", oi.toString()));

        // 月のセット
        oi = new Integer(intMonth);
        strMonth = oi.toString();
        if (strMonth.length() < 2)
            strMonth = "0" + strMonth;
        retParam.add(String.format("%s", strMonth));

        // 日のセット
        oi = new Integer(intDay);
        strDay = oi.toString();
        if (strDay.length() < 2) {
            strDay = "0" + strDay;
        }
        retParam.add(String.format("%s", strDay));

        return retParam;
    }

    /**
     * 前年の取得.<br>
     *<br>
     * 概要:<br>
     *   指定した年月日から前年を取得する
     *<br>
     * @param _year 年
     * @return _month 前月
     */
    private String getBeforeYear(final String _year) {
        int intYear;
        String strYear;
        Integer oi;

        intYear = Integer.parseInt(_year);
        intYear = intYear - 1;

        oi = new Integer(intYear);
        strYear = oi.toString();

        return strYear;
    }

    /**
     * 次年の取得.<br>
     *<br>
     * 概要:<br>
     *   指定した年月日から次年を取得する
     *<br>
     * @param _year 年
     * @param _month 月
     * @param _day 日
     * @return _month 前月
     */
    private String getNextYear(final String _year) {
        int intYear;
        String strYear;
        Integer oi;

        intYear = Integer.parseInt(_year);
        intYear = intYear + 1;

        oi = new Integer(intYear);
        strYear = oi.toString();

        return strYear;
    }

    /**
     * 次月の取得.<br>
     *<br>
     * 概要:<br>
     *   指定した年月日から次月を取得する
     *<br>
     * @param _year 年
     * @param _month 月
     * @param _day 日
     * @return _month 前月
     */
    private List<String> getNextMonth(final String _year, final String _month, final String _day) {
        int intYear;
        int intMonth;
        Integer oi;
        String strYear;
        String strMonth;

        List<String> retParam = new ArrayList<String>(3);

        intYear = Integer.parseInt(_year);
        intMonth = Integer.parseInt(_month);

        intMonth = intMonth + 1;
        if (intMonth == 13) {
            intMonth = 1;
            intYear = intYear + 1;
        }

        // 年のセット
        oi = new Integer(intYear);
        strYear = oi.toString();
        retParam.add(String.format("%s", strYear));

        // 月のセット
        oi = new Integer(intMonth);
        strMonth = oi.toString();
        if (strMonth.length() < 2) {
            strMonth = "0" + strMonth;
        }
        retParam.add(String.format("%s", strMonth));

        return retParam;
    }

    /**
     * 前月の取得.<br>
     *<br>
     * 概要:<br>
     *   指定した年月日から前月を取得する
     *<br>
     * @param _year 年
     * @param _month 月
     * @param _day 日
     * @return _month 前月
     */
    private List<String> getBeforeMonth(final String _year, final String _month, final String _day) {
        int intYear;
        int intMonth;
        Integer oi;
        String strYear;
        String strMonth;

        List<String> retParam = new ArrayList<String>(3);

        intYear = Integer.parseInt(_year);
        intMonth = Integer.parseInt(_month);

        intMonth = intMonth - 1;
        if (intMonth == 0) {
            intMonth = 12;
            intYear = intYear - 1;
        }

        // 年のセット
        oi = new Integer(intYear);
        strYear = oi.toString();
        retParam.add(String.format("%s", strYear));

        // 月のセット
        oi = new Integer(intMonth);
        strMonth = oi.toString();
        if (strMonth.length() < 2) {
            strMonth = "0" + strMonth;
        }
        retParam.add(String.format("%s", strMonth));

        return retParam;
    }

    /**
     * リダイレクト用パラメータマップ作成.
     * @return リダイレクト用パラメータマップ
     */
    protected Map<String, String> makeRedirectParam() {
        // 画面遷移パラメータ
        Map<String, String> transferMap = new HashMap<String, String>();
        // 画面遷移フラグ設定
        transferMap.put(CM_ListForm.CM_LISTFORM_HDN_TRANSFER_FLAG, CM_A04_Const.FLG.ON);
        // 工場コード
        transferMap.put(CM_BaseForm.COM_PLANT_CODE, this.getActionForm().comPlantCode);
        // リダイレクト用パラメータ
        Map<String, String> redirectParamMap = this.getActionForm().hdnRedirectParamMap;
        for (Map.Entry<String, String> redirectParamEnt : redirectParamMap.entrySet()) {
            transferMap.put(redirectParamEnt.getKey(), redirectParamEnt.getValue());
        }
        return transferMap;
    }

    /**
     *
     * 画面遷移処理.<br>
     *<br>
     * 概要:<br>
     *  各画面に遷移する。<br>
     *  各画面Actionで記述しているsetTransferMapを呼び出し、次画面へのパラメータを設定。
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String redirectPage() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        String pageUrl = this.getJspFileName();

        // フォーム情報保存
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        // サービス初期化
        this.getService().init(this.cM_A03_SessionDto);

        // パンくずリストに、戻りページ設定
        CM_HeaderUtil.setReturnInfo(this.cM_A03_SessionDto, this.getPageId(), this.getPageInfo().getReturnPageUrl(), formMap);

        // 画面遷移パラメータ
        Map<String, String> transferMap = this.makeRedirectParam();

        this.setTransferMap(transferMap);

        // 次画面ページ情報
        String nextPage = this.getRedirectPageUrl();

        if (CM_CommonUtil.isNotNullOrBlank(nextPage)) {
            pageUrl = this.redirectPage(nextPage, transferMap, this.getActionForm());
        }
        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, pageUrl);

        return pageUrl;
    }
    /**
     *
     * 次画面遷移パラメータを設定.<br>
     *<br>
     * 概要:<br>
     *  次画面遷移パラメータを設定<br>
     *  各画面のアクションでオーバーライドし、フォームクラスを設定する
     *<br>
     * @param _transferMap クエリパラメータ(KEY：次画面項目名、VALUE：遷移パラメータ)
     */
    protected abstract void setTransferMap(final Map<String, String> _transferMap);
    /**
     *
     * 遷移先URL取得.<br>
     *<br>
     * 概要:<br>
     *  遷移先のURLを取得
     *<br>
     * @return 遷移先URL
     */
    public String getRedirectPageUrl() {
        String redirectPageUrl = null;
        if (CM_CommonUtil.isNotNullOrBlank(this.getNextPageInfo())) {
            redirectPageUrl = this.getNextPageInfo().getIndexPageUrl();
        } else if (CM_CommonUtil.isNotNullOrBlank(this.getActionForm().hdnNextPageId)) {
            CM_A05_PageInfo pageInfo = CM_A05_PageInfo.getPageInfo(this.getActionForm().hdnNextPageId);
            if (pageInfo != null) {
                redirectPageUrl = pageInfo.getIndexPageUrl();
            }
        }
        return redirectPageUrl;
    };
    /**
     *
     * 次画面ページ情報取得.<br>
     *<br>
     * 概要:<br>
     * 次画面ページ情報を取得
     *<br>
     * @return 次画面ページ情報
     */
    protected CM_A05_PageInfo getNextPageInfo() {
        return null;
    };

    /**
     * リダイレクトパラメータ反映.
     */
    @SuppressWarnings("unchecked")
    protected void loadRedirectParam() {
        // 検索条件の設定
        CM_BaseForm form = this.getActionForm();

        Map<String, Object> redItemValMap = new HashMap<String, Object>();
        Map<String, String> mapParam = this.request.getParameterMap();
        for (String paramKey : mapParam.keySet()) {
            try {
                Field field = form.getClass().getField(paramKey);
                Object prop = field.get(form);
                redItemValMap.put(paramKey, prop);
            } catch (Exception e) {
            }
        }

        // セッションより共通検索情報を復元
        this.getComSearchInfo().restorComSearchCond(form);

        for (Map.Entry<String, Object> redItemValEnt : redItemValMap.entrySet()) {
            String paramKey = redItemValEnt.getKey();
            Object val = redItemValEnt.getValue();
            try {
                Field field = form.getClass().getField(paramKey);
                field.set(form, val);
            } catch (Exception e) {
            }
        }
    }

    /**
     * 変数の値をセッションから復元.
     * @param _fieldName 項目名
     */
    protected void restoreSessionParam(final String _fieldName) {
        this.comSearchInfo = this.getComSearchInfo();

        // 検索条件の設定
        CM_BaseForm form = this.getActionForm();
        if (this.hasReqParam(_fieldName)) {
            // リクエストパラーメータがある場合
            this.comSearchInfo.saveParam(form, _fieldName);
            return;
        }

        // 検索条件の設定
        this.comSearchInfo.restoreParam(form, _fieldName);
    }
    /**
     * 変数の値をセッションから復元(プルダウン用).
     * @param _fieldName 項目名
     * @param _pld プルダウンリストデータ
     */
    protected void restoreSessionParam(final String _fieldName, final List<Map<String, String>> _pld) {
        this.comSearchInfo = this.getComSearchInfo();

        // 検索条件の設定
        CM_BaseForm form = this.getActionForm();
        if (this.hasReqParam(_fieldName)) {
            // リクエストパラーメータがある場合
            this.comSearchInfo.saveParam(form, _fieldName);
            return;
        }

        // セッションから値を復元
        this.comSearchInfo.restoreParam(form, _fieldName);

        // プルダウンに存在する値で再設定
        String val = CM_A09_ComSearchInfo.getParam(form, _fieldName);
        val = this.checkPldData(_pld, val);
        CM_A09_ComSearchInfo.setParam(form, _fieldName, val);
    }
    /**
     * リクエストパラメータが存在するかどうかを確認.
     * @param _fieldName 項目名
     * @return	結果
     */
    private boolean hasReqParam(final String _fieldName) {
        boolean res = false;
        String mapParam = this.request.getParameter(_fieldName);
        if (CM_CommonUtil.isNotNullOrBlank(mapParam)) {
            res = true;
        }
        return res;
    }

    /**
     * リンク遷移のためのFormを編集.<br>
     *<br>
     * 概要:<br>
     *  リンク遷移のためのFormを編集<br>
     * @param _fieldName 項目名
     *<br>
     */
    public List<BeanMap> setFormForLink(CM_BaseForm _form) {
        List<BeanMap> processList;

        // 工程の取得
        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);

        // 工程プルダウン取得
        processList = mstDataService.getMstProcessId(_form.comPlantCode, _form.comSeizouLnId, _form.comLnId);
        return processList;
    }

    /**
     * 共通エリア情報取得.
     */
    private void loadComAreaInfo(final CM_BaseForm _formDto) {
        BeanMap beanMap = new BeanMap();

        // 検索エリアの開閉状態を設定
        if (CM_CommonUtil.isNullOrBlank(_formDto.hdnSearchAreaOpen)) {
            beanMap.put(CM_BaseForm.HDN_SEARCH_OPEN, "0");
        } else {
            beanMap.put(CM_BaseForm.HDN_SEARCH_OPEN, _formDto.hdnSearchAreaOpen);
        }
        // アンドンエリアの開閉状態を設定
        if (CM_CommonUtil.isNullOrBlank(_formDto.hdnAndonAreaOpen)) {
            beanMap.put(CM_BaseForm.HDN_ANDON_OPEN, "0");
        } else {
            beanMap.put(CM_BaseForm.HDN_ANDON_OPEN, _formDto.hdnAndonAreaOpen);
        }

        this.comAreaMap = beanMap;
    }

    /**
     *
     * ヘッダーメニューのリロード処理.<br>
     *<br>
     * 概要:<br>
     *   ヘッダーメニューの内容を再取得する<br>
     *<br>
     */
    protected void reloadTopHeader() {
        // 共通項目：工場コード取得
        this.loadComPlantCode();

        // ページ権限情報取得
        CM_MenuAuthInfoUtil.loadSessionPageAuthInfo(this.cM_A03_SessionDto, this.getActionForm().comPlantCode);

        // 共通ヘッダのデータセット
        CM_TopHeaderService s000050TopHeaderService = new CM_TopHeaderService();
        this.mapTopHeader = s000050TopHeaderService.getHeaderData(this.cM_A03_SessionDto, this.getActionForm());
    }

    /**
     * 共通項目：工場コード取得.
     */
    private void loadComPlantCode() {
        if (CM_CommonUtil.isNullOrBlank(this.getActionForm().comPlantCode)) {
            // セッションより工場コードを復元
            this.getComSearchInfo().restoreComParam(this.getActionForm(), CM_BaseForm.COM_PLANT_CODE);

            // それでも工場がない場合は、ログイン情報から工場コードを取得
            if (CM_CommonUtil.isNullOrBlank(this.getActionForm().comPlantCode)) {
                // サービスの初期化
                if (CM_CommonUtil.isNotNullOrBlank(this.getService())) {
                    this.getService().init(this.cM_A03_SessionDto);
                }
                // 工場コード設定
                this.setPlantCode();
            }
        }
    }

    /**
    *
    * お気に入り表示切替（閲覧⇒編集）処理.<br>
    *<br>
    * 概要:<br>
    *   お気に入り表示切替（閲覧⇒編集）
    *<br>
    * @return JSP名
    */
    @Execute(validator = false)
    public String editFavorite() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        // 処理開始
        this.getService().init(this.cM_A03_SessionDto);

        // モード変更
        this.modeChangeFavorite(CM_A04_Const.PAGE_EVENT_TYPE.EVENT_EDIT);

        // お気に入り情報取得
        this.loadFavoriteInfo();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, COM_FAVORITE_AREA_JSP);

        return COM_FAVORITE_AREA_JSP;
    }

   /**
   *
   * お気に入り表示切替（編集⇒キャンセル）処理.<br>
   *<br>
   * 概要:<br>
   *   お気に入り表示切替（閲覧⇒キャンセル）
   *<br>
   * @return JSP名
   */
   @Execute(validator = false)
   public String cancelFavorite() {
       // メソッド開始ログ出力
      CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

      // 処理開始
      this.getService().init(this.cM_A03_SessionDto);

      // モード変更
      this.modeChangeFavorite(CM_A04_Const.PAGE_EVENT_TYPE.EVENT_CANCEL);

      // お気に入り情報取得
      this.loadFavoriteInfo();

      // メソッド出力ログ出力
      CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, COM_FAVORITE_AREA_JSP);

      return COM_FAVORITE_AREA_JSP;
   }

   /**
   *
   * お気に入り編集保存処理.<br>
   *<br>
   * 概要:<br>
   *   お気に入り編集内容保存
   *<br>
   * @return JSP名
   */
    @Execute(validator = false)
    public String registFavoriteName() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        // 処理開始
        this.getService().init(this.cM_A03_SessionDto);

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        // モード変更
        this.modeChangeFavorite(CM_A04_Const.PAGE_EVENT_TYPE.EVENT_REGIST);

        // ページ名称をFormにセット
        List<BeanMap> favoriteList = this.getService().getFavoriteList();
        for (BeanMap data : favoriteList) {
            Integer favoriteNo = (Integer) data.get(TrSearchConditionEntityNames.favoriteNo().toString());
            switch (favoriteNo) {
                case 0:
                    break;
                case 1:
                    if (CM_CommonUtil.isNullOrBlank(formMap.get(CM_BaseForm.HDN_FAVORITE_NAME1))) {
                        formMap.put(CM_BaseForm.HDN_FAVORITE_NAME1, data.get(TrSearchConditionEntityNames.favoriteName()));
                    }
                    formMap.put(CM_BaseForm.HDN_FAVORITE_NO1, favoriteNo.toString());
                    break;
                case 2:
                    if (CM_CommonUtil.isNullOrBlank(formMap.get(CM_BaseForm.HDN_FAVORITE_NAME2))) {
                        formMap.put(CM_BaseForm.HDN_FAVORITE_NAME2, data.get(TrSearchConditionEntityNames.favoriteName()));
                    }
                    formMap.put(CM_BaseForm.HDN_FAVORITE_NO2, favoriteNo.toString());
                    break;
                case 3:
                    if (CM_CommonUtil.isNullOrBlank(formMap.get(CM_BaseForm.HDN_FAVORITE_NAME3))) {
                        formMap.put(CM_BaseForm.HDN_FAVORITE_NAME3, data.get(TrSearchConditionEntityNames.favoriteName()));
                    }
                    formMap.put(CM_BaseForm.HDN_FAVORITE_NO3, favoriteNo.toString());
                    break;
                case 4:
                    if (CM_CommonUtil.isNullOrBlank(formMap.get(CM_BaseForm.HDN_FAVORITE_NAME4))) {
                        formMap.put(CM_BaseForm.HDN_FAVORITE_NAME4, data.get(TrSearchConditionEntityNames.favoriteName()));
                    }
                    formMap.put(CM_BaseForm.HDN_FAVORITE_NO4, favoriteNo.toString());
                    break;
                case 5:
                    if (CM_CommonUtil.isNullOrBlank(formMap.get(CM_BaseForm.HDN_FAVORITE_NAME5))) {
                        formMap.put(CM_BaseForm.HDN_FAVORITE_NAME5, data.get(TrSearchConditionEntityNames.favoriteName()));
                    }
                    formMap.put(CM_BaseForm.HDN_FAVORITE_NO5, favoriteNo.toString());
                    break;
                case 6:
                    if (CM_CommonUtil.isNullOrBlank(formMap.get(CM_BaseForm.HDN_FAVORITE_NAME6))) {
                        formMap.put(CM_BaseForm.HDN_FAVORITE_NAME6, data.get(TrSearchConditionEntityNames.favoriteName()));
                    }
                    formMap.put(CM_BaseForm.HDN_FAVORITE_NO6, favoriteNo.toString());
                    break;
            }
        }

        // 検索条件登録処理
        this.getService().registerPageName(formMap, this.getPageId());

        // お気に入り情報取得
        this.loadFavoriteInfo();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, COM_FAVORITE_AREA_JSP);

        return COM_FAVORITE_AREA_JSP;
    }

    /**
    *
    * 検索処理.<br>
    *<br>
    * 概要:<br>
    *  検索処理を実行する
    *<br>
    * @return JSP名
    */
   @Execute(validator = false)
   public String search() {
       return this.getJspFileName();
   }

}
