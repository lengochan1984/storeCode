/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2005 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2015/01/06| 新規作成                           | 3.00.00| YSK)中田
 *  2015/06/23| <30003-034> 変更仕様No.1           | 3.01.00| YSK)千田
 *  2015/07/08| <30003-037> 変更仕様No.23          | 3.01.00| US)萩尾
 *  2016/07/20| <C1.01> 共通化対応取込             | C1.01  | US)萩尾
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.interceptor;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.dto.FW01_12_SessionDto;
import jp.ysk.fw.interceptor.FW01_11_AuthorityCheckInterceptor;
import jp.ysk.mmcloud.common.CM_A04_Const;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.dto.CM_A04_UserRoleDto;
import jp.ysk.mmcloud.visualization.common.util.CM_CommonUtil;

/**
 *
 * Actionクラス権限チェック処理.<br>
 *<br>
 * 概要:<br>
 *   Actionクラス権限チェック用のインターセプタークラスです
 *<br>
 */
public class CM_I00_BaseInterceptor extends FW01_11_AuthorityCheckInterceptor {

    /**
     * クラス名 機能CD終端位置.
     */
    private static final Integer FUNCCD_END_POS = 3;

    /**
     * クラス名 ページID終端位置.
     */
    private static final Integer PAGEID_END_POS = 7;

    /**
     * 権限チェック処理.<br>
     *<br>
     * 概要:<br>
     * セッション情報をもとに権限をチェックする。
     * プロジェクト特有の権限チェックを行う場合は、本クラスを
     *<br>
     * @param _className Actionクラス名
     * @param _sessionDto セッション情報
     * @return チェック結果(true：OK、false：権限なし）
     */
    @Override
    protected boolean authCheck(final String _className, final FW01_12_SessionDto _sessionDto) {

        CM_A03_SessionDto cM_A03_SessionDto = (CM_A03_SessionDto) _sessionDto;

        CM_A04_UserRoleDto roleDto = null;

        // クラス名からページIDを取得する
        String pageId = _className.substring(0, FUNCCD_END_POS) + FW00_19_Const.HYPHEN_STR + _className.substring(FUNCCD_END_POS, PAGEID_END_POS);

        if (pageId.equals(CM_A04_Const.HOME_PAGE_ID)) {
            // ホーム画面は権限に関係なく閲覧可
            return true;
        }

        // 権限情報取得
        for (CM_A04_UserRoleDto roleTmp : cM_A03_SessionDto.ssn_UserRoleSetting) {
            if (roleTmp.ssn_PageId.equals(pageId)) {
                roleDto = roleTmp;
                break;
            }
        }

        // ユーザ権限とグループ情報をもとに使用できるページのチェック
        if (!CM_CommonUtil.isEnableDisplayPage(pageId, cM_A03_SessionDto)) {
            return false;
        }

        // ユーザ情報画面以外について、権限を確認する。
        // ユーザ情報画面は、システム管理者以外の場合はユーザSIDによって
        // 閲覧可否が変わるため、インターセプタではチェックしない。
        if (!CM_A04_Const.USER_INFO_ID.equals(pageId)) {
            if (roleDto == null) {
                // 役割権限設定がないため閲覧不可
                return false;
            }

            if (roleDto.ssn_AuthSetting.equals(CM_A04_Const.ROLE_AUTH_KIND.NONE)) {
                // 役割権限がないため閲覧不可
                return false;
            }
        }

        return true;
    }
}
