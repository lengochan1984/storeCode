package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link TrTransferDatetimeEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class TrTransferDatetimeEntityNames {

    /**
     * connectionStringのプロパティ名を返します。
     * 
     * @return connectionStringのプロパティ名
     */
    public static PropertyName<String> connectionString() {
        return new PropertyName<String>("connectionString");
    }

    /**
     * userIdのプロパティ名を返します。
     * 
     * @return userIdのプロパティ名
     */
    public static PropertyName<String> userId() {
        return new PropertyName<String>("userId");
    }

    /**
     * tableNameのプロパティ名を返します。
     * 
     * @return tableNameのプロパティ名
     */
    public static PropertyName<String> tableName() {
        return new PropertyName<String>("tableName");
    }

    /**
     * updDatetimeのプロパティ名を返します。
     * 
     * @return updDatetimeのプロパティ名
     */
    public static PropertyName<Timestamp> updDatetime() {
        return new PropertyName<Timestamp>("updDatetime");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _TrTransferDatetimeNames extends PropertyName<TrTransferDatetimeEntity> {

        /**
         * インスタンスを構築します。
         */
        public _TrTransferDatetimeNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _TrTransferDatetimeNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _TrTransferDatetimeNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * connectionStringのプロパティ名を返します。
         *
         * @return connectionStringのプロパティ名
         */
        public PropertyName<String> connectionString() {
            return new PropertyName<String>(this, "connectionString");
        }

        /**
         * userIdのプロパティ名を返します。
         *
         * @return userIdのプロパティ名
         */
        public PropertyName<String> userId() {
            return new PropertyName<String>(this, "userId");
        }

        /**
         * tableNameのプロパティ名を返します。
         *
         * @return tableNameのプロパティ名
         */
        public PropertyName<String> tableName() {
            return new PropertyName<String>(this, "tableName");
        }

        /**
         * updDatetimeのプロパティ名を返します。
         *
         * @return updDatetimeのプロパティ名
         */
        public PropertyName<Timestamp> updDatetime() {
            return new PropertyName<Timestamp>(this, "updDatetime");
        }
    }
}
