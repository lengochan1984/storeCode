/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+======================================+========+==============
 *  DATE      | Comments                             | Rev    | SIGN
 * ===========+======================================+========+==============
 *  2014/01/27| 新規作成                             | 1.00.00| YSK)森山
 *  2014/06/21| <10000-004> ユーザ設定押下処理追加   | 1.00.00| YSK)鬼丸
 *  2014/06/21| <10000-008> 説明画面用処理追加       | 1.00.00| YSK)中田
 *  2014/06/23| <10000-023> 戻る処理の不具合修正     | 1.00.00| YSK)鬼丸
 *  2014/09/03| <10101-012> トレンドモニタ改造　  　 | 1.02.00| YSK)植山
 *  2014/10/03| <10101-029> リリース後不具合対応     | 1.02.00| YSK)大山
 *  2014/12/05| <20000-009> 変更仕様No.7             | 3.00.00| US)楢崎
 *  2014/01/06| <20000-006> 変更仕様No.18            | 3.00.00| YSK)中田
 *  2015/02/20| <20000-037>　仕様変更No.38           | 3.00.00| YSK)植山
 *  2015/12/01| <40000-025> Ver4.00.00 変更仕様No.25 | 4.00.00| US)高橋
 *  2016/01/11| <40000-013> Ver.4.00.00 変更仕様No.13| 4.00.00| US)甲斐
 *  2016/01/14| <40000-025> 変更仕様No.25            | 4.00.00| US)萩尾
 *  2016/01/18| <40000-027> Ver.4.00.00 変更仕様No.27| 4.00.00| US)甲斐
 *  2016/01/25| <40000-028> 変更仕様No.28            | 4.00.00| US)安永
 *  2016/01/26| <30101-002> 故障苦情No.30100-012 　  | 4.00.00| US)萩尾
 *  2016/04/18| <40000-043> PGレビュー指摘事項       | 4.01.00| US)萩尾
 *  2016/08/26|             見える化対応             | C1.01  | US)松本
 * -----------+--------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.action;

import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import jp.ysk.fw.FW00_12_AppException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.action.FW01_10_ListAction;
import jp.ysk.fw.csv.FW01_10_CSVFormat;
import jp.ysk.fw.csv.FW01_10_CSVWriter;
import jp.ysk.fw.form.FW01_14_ListForm;
import jp.ysk.fw.form.FW01_17_BaseForm;
import jp.ysk.fw.util.FW00_06_MessageResourceUtil;
import jp.ysk.fw.util.FW00_11_UrlEncodeUtil;
import jp.ysk.fw.util.FW01_03_CreateSingleSelectTagUtil;
import jp.ysk.mmcloud.common.action.CM_A03_InfoAction;
import jp.ysk.mmcloud.visualization.common.csv.CM_CsvUtil;
import jp.ysk.mmcloud.visualization.common.csv.CM_Csv_Const;
import jp.ysk.mmcloud.common.csv.CM_Csv_Upload_Result;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.dto.CM_A07_BreadCrumbDto;
import jp.ysk.mmcloud.common.dto.CM_A08_ComDetailSearchItemDto;
import jp.ysk.mmcloud.common.entity.customer.MstModelEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstNameEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstRoleEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstUserEntityNames;
import jp.ysk.mmcloud.common.entity.customer.RelModelIconEntity;
import jp.ysk.mmcloud.common.entity.customer.SysEnvEntityNames;
import jp.ysk.mmcloud.common.entity.customer.SysNameEntityNames;
import jp.ysk.mmcloud.common.service.CM_BaseService;
import jp.ysk.mmcloud.common.service.CM_GetMstDataService;
import jp.ysk.mmcloud.common.util.CM_ComDetailSearchUtil;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.common.util.CM_DisplayCharResourceUtil;
import jp.ysk.mmcloud.common.util.CM_HeaderUtil;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.common.util.CM_MessageResourceUtil;
import jp.ysk.mmcloud.common.util.CM_MessageUtil;
import jp.ysk.mmcloud.common.util.CM_MstNameDataUtil;
import jp.ysk.mmcloud.common.util.CM_SysEnvDataUtil;
import jp.ysk.mmcloud.common.util.CM_SysNameDataUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;

import org.apache.struts.upload.FormFile;
import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.util.ResourceUtil;
import org.seasar.struts.annotation.Execute;

/**
 *
 * 一覧用アクション基底クラス.<br>
 *<br>
 * 概要:<br>
 *   一覧用アクション用の共通基底クラス
 *<br>
 */
public class CM_A02_ListAction extends FW01_10_ListAction {
    /**
     * セッション情報.
     */
    @Resource
    public CM_A03_SessionDto cM_A03_SessionDto;

    /**
     * 共通ヘッダ情報.
     */
    public BeanMap mapTopHeader = null;

    /**
     * 全ページ数.
     */
    public String fw0110AllPageCnt;

    /**
     * 表示件数プルダウンリスト.
     */
    public List<Map<String, String>> fw0110DispCntList;

    /**
     * 1件もデータが存在しない場合.
     */
    public String fw0110NoneDataMsg;

    /**
     * .
     */
    public String fw0110AllSize;

    /**
     * 詳細検索条件項目リスト情報.
     */
    public List<BeanMap> itemList;

    /**
     * 詳細検索条件項目選択リスト情報.
     */
    public BeanMap itemSelectListInfoMap;

    /**
     * 詳細検索条件項目の復帰用情報.
     */
    public HashMap<String, Object> itemRestoreInfoMap;

    /**
     * 検索件数情報.
     */
    public  String searchCountInfo = FW00_19_Const.EMPTY_STR;


    /**
     * 一覧総データ数.
     */
    public static final String OFFSET_INFO_LIST_CNT = "intListCnt";

    /**
     * .
     */
    private static String envCodeListDispCount = "list_disp_count";

    /**
     * 検索条件項目選択リスト情報のコード.
     */
    public static final String ITEM_SELECT_LSIT_INFO_CODE = "code";

    /**
     * 検索条件項目選択リスト情報の名称.
     */
    public static final String ITEM_SELECT_LSIT_INFO_NAME = "name";

    /**
     * 詳細検索の検索項目セパレータ.
     */
    public static final String DETAIL_SEARCH_ITEM_SEP = "#condsp#";

    /**
     * 詳細検索の検索内容セパレータ.
     */
    public static final String DETAIL_SEARCH_COND_SEP = "#chsp#";

    /**
     * 詳細検索の検索条件IDヘッダ.
     */
    public static final String[] DETAIL_SEARCH_COND_HEADER_LIST = {"cond_", "_from", "_to", "_hour", "_minute"};

    /**
     * 情報ファイルリンク先.
     */
    public String infoFileLink = null;

    /**
     * ページID.
     */
    public String nowPageId = null;

    /**
     * CSV出力上限値チェック結果(true:上限エラー、false:上限内).
     */
    public String csvLimitError = "false";
    /**
     * CSV出力上限値.
     */
    public String csvLimitNum = "3";

    /**
     * 現在日時フォーマット.
     */
    public static final String DATE_FORMAT = "yyyyMMddHHmmss";

    /**
     * CSVデータ件数上限.
     */
    public static final long CSV_DATA_MAX = 10000;

    /**
     * SQLエラーメッセージCD.
     */
    private String strSqlErrorMsgCd = "MMCMCM00000_302";

    /**
     * 画像取得用メソッド名.<BR>
     * ※アラームアイコン取得用
     */
    public static final String ICON_IMAGE_DOWNLOAD_METHOD_NAME = "downloadMapIconImage";

    /**
     *アップロード結果.
     */
    public CM_Csv_Upload_Result csvUploadResult;

    /**
     * ページIDの設定.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param  _pageId ページID
     */
    protected void setPageId(final String _pageId) {
        this.nowPageId = _pageId;

        makeInfoFileLink(_pageId);
    }

    /**
     * 情報ページリンク先の生成.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param  _pageId ページID
     */
    private void makeInfoFileLink(final String _pageId) {
        this.infoFileLink = CM_A04_Const.INFO_PAGE_DIR + _pageId + ".html";
    }

    /**
     * 表示件数プルダウン情報の取得.
     */
    protected void selectDispCnt() {
        // 環境マスタより表示件数プルダウン情報の取得
        List<BeanMap> list = CM_SysEnvDataUtil.selectListSysEnv(this.cM_A03_SessionDto, envCodeListDispCount);

        FW01_03_CreateSingleSelectTagUtil util =
                new FW01_03_CreateSingleSelectTagUtil(
                        SysEnvEntityNames.itemCd().toString(),
                        SysEnvEntityNames.name().toString(),
                        SysEnvEntityNames.defaultFlag().toString(),
                        list,
                        -1);
        this.fw0110DispCntList = util.getItemList();
    }

    /**
     *
     * 頁計算処理.<br>
     *<br>
     * 概要:<br>
     *   表示件数から頁を計算する。
     *<br>
     * @param _form ActionForm
     * @param _intAllCnt 検索条件該当全件数
     */
    protected void calcPage(final FW01_14_ListForm _form, final long _intAllCnt) {

        long paramAllCnt = _intAllCnt;

        BeanMap envMap = CM_SysEnvDataUtil.selectSysEnv(this.cM_A03_SessionDto,
                CM_A04_Const.SYS_ENV_MST_ENV_CD.SEARCH_RESULT_MAX,
                CM_A04_Const.SEARCH_RESULT_ITEM_CD.SEARCH_RESULT_MAX_ITEM_CD);
        this.searchResultMax = new Long(envMap.get(SysEnvEntityNames.name()).toString());

        if (this.searchResultMax != null && _intAllCnt > this.searchResultMax.longValue()) {
            paramAllCnt = this.searchResultMax.longValue();
        }

        this.calcPage(_form, paramAllCnt, true);

        this.searchCountInfo = Long.toString(_intAllCnt);
    }

    /**
     *
     * メソッド名：一覧ページ計算処理.<br>
     *<br>
     * 概要:<br>
     *   一覧の表示情報の計算処理を行う
     *<br>
     * @param _form フォーム
     * @param _intAllCnt 一覧件数
     * @param _pageFlg ページ替え有無
     */
    protected void calcPage(final FW01_14_ListForm _form, final long _intAllCnt, final boolean _pageFlg) {
        // 該当件数をフィールドに設定
        this.fw0110AllSize = Long.toString(_intAllCnt);

        if (_intAllCnt == 0) {
            this.fw0110NoneDataMsg = FW00_06_MessageResourceUtil.getMessage("M025");
        }

        if (_form.fw0114PageNo == null || _form.fw0114PageNo.equals(FW00_19_Const.EMPTY_STR)) {
            _form.fw0114PageNo = "1";
        }
        if (_pageFlg) {
            if (this.fw0110DispCntList == null || this.fw0110DispCntList.isEmpty()) {

                this.selectDispCnt();
            }
            if (_form.fw0114ListSize == null || _form.fw0114ListSize.equals(FW00_19_Const.EMPTY_STR)) {
                for (Map<String, String> record : this.fw0110DispCntList) {
                    if (record.get(FW01_03_CreateSingleSelectTagUtil.FW01_03_KEY_OPT_SELECTED) != null
                            && record.get(FW01_03_CreateSingleSelectTagUtil.FW01_03_KEY_OPT_SELECTED).equals(FW01_03_CreateSingleSelectTagUtil.FLG_SELECTED)) {
                        _form.fw0114ListSize = record.get(FW01_03_CreateSingleSelectTagUtil.FW01_03_KEY_OPT_VALUE);
                        break;
                    }
                }
                if (_form.fw0114ListSize == null || _form.fw0114ListSize.equals(FW00_19_Const.EMPTY_STR)) {
                    _form.fw0114ListSize = this.fw0110DispCntList.get(this.fw0110DispCntList.size() - 1).get("value");
                }
            }
        } else {
            _form.fw0114ListSize = new Long(_intAllCnt).toString();
        }
        int intPageSize = Integer.parseInt(_form.fw0114ListSize);

        int intAllPageCnt = 0;

        if (intPageSize > 0) {
            intAllPageCnt = new Long(_intAllCnt).intValue() / intPageSize;

            if (new Long(_intAllCnt).intValue() % intPageSize > 0) {
                intAllPageCnt++;
            } else if (_intAllCnt == 0) {
                intAllPageCnt = 1;
            }
        }

        // 別ユーザによりデータ件数が替えられた為表示ページ位置がおかしくなった場合の対応
        if (intAllPageCnt < Integer.parseInt(_form.fw0114PageNo)) {
            _form.fw0114PageNo = Integer.toString(intAllPageCnt);
        }

        this.fw0110AllPageCnt = Integer.toString(intAllPageCnt);
    }


    /**
     *
     * 更新タイミングリスト情報を取得する.<br>
     *<br>
     * 概要:<br>
     *   更新タイミングリストに表示する項目を取得する。
     *<br>
     * @return getData 更新タイミングリスト
     */
    protected List<Map<String, String>> getUpdateTimingList() {

        List<BeanMap> map = null;
        FW01_03_CreateSingleSelectTagUtil fw0103Util = null;

        map = CM_SysNameDataUtil.getNameList(this.cM_A03_SessionDto,
                CM_A04_Const.SYS_ENV_MST_ENV_CD.UPDATETIME, this.cM_A03_SessionDto.ssn_UserLangCD);

        fw0103Util = new FW01_03_CreateSingleSelectTagUtil(
                SysNameEntityNames.itemCd().toString(),
                SysNameEntityNames.name1().toString(),
                SysNameEntityNames.defaultFlag().toString(),
                map,
                -1);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 共通詳細検索領域用の情報を取得し、共通情報にセットする.<br>
     *<br>
     * 概要:<br>
     *   共通詳細検索領域用の情報を取得し、共通情報にセットする。
     *<br>
     * @param _strPageId 画面ID
     */
    protected void initDetailSearchDisplayInfo(final String _strPageId) {

        // 検索条件選択リスト情報の初期化
        this.itemSelectListInfoMap = new BeanMap();

        // 対象画面の詳細検索設定情報を取得
        ArrayList<CM_A08_ComDetailSearchItemDto> dsItemInfoList = CM_ComDetailSearchUtil.getDSItemInfo(_strPageId);

        this.itemList = new ArrayList<BeanMap>();
        BeanMap dsItemInfoMap = null;
        List<BeanMap> listSelectListInfoFromDb = null;
        BeanMap mapSelectListFromDb = null;
        ArrayList<BeanMap> listSelectListInfoForDisp = null;
        BeanMap mapSelectListForDisp = null;
        String strMapKeyCd = FW00_19_Const.EMPTY_STR;
        String strMapKeyName = FW00_19_Const.EMPTY_STR;
        String strMapKeyName2 = FW00_19_Const.EMPTY_STR;

        // 詳細検索設定情報が存在する
        if (dsItemInfoList != null) {
            // 各検索項目情報を取得
            for (int i = 0; i < dsItemInfoList.size(); i++) {
                dsItemInfoMap = new BeanMap();
                dsItemInfoMap.put(CM_A08_ComDetailSearchItemDto.ITEM_ID, dsItemInfoList.get(i).itemId);
                dsItemInfoMap.put(CM_A08_ComDetailSearchItemDto.ITEM_RESOURCE_ID, dsItemInfoList.get(i).itemResourceId);
                dsItemInfoMap.put(CM_A08_ComDetailSearchItemDto.INPUT_TYPE, dsItemInfoList.get(i).inputType);
                dsItemInfoMap.put(CM_A08_ComDetailSearchItemDto.WHERE_COND_TYPE, dsItemInfoList.get(i).whereCondType);
                dsItemInfoMap.put(CM_A08_ComDetailSearchItemDto.WHERE_COLUMN_TYPE, dsItemInfoList.get(i).whereColumnType);

                // リスト指定されている場合、リスト情報を取得する
                if (dsItemInfoList.get(i).selectListType != null) {
                    listSelectListInfoForDisp = new ArrayList<BeanMap>();

                    // 必須でない場合、先頭にブランク選択肢を登録
                    if (!dsItemInfoList.get(i).selectListIsnes.equals(CM_A04_Const.FLG.ON)) {
                        // 表示用選択肢データ初期化
                        mapSelectListForDisp = new BeanMap();
                        // コード、名称をブランクで登録
                        mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, FW00_19_Const.EMPTY_STR);
                        mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME, FW00_19_Const.EMPTY_STR);
                        listSelectListInfoForDisp.add(mapSelectListForDisp);
                    }

                    // 名称マスタ（システム用）または名称マスタから取得する場合
                    if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.SYS_NAME)
                            || dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.MST_NAME)) {

                        // 名称コードを取得
                        if (!CM_CommonUtil.isNullOrBlank(dsItemInfoList.get(i).selectListCode)) {

                            // 名称マスタ（システム用）から取得
                            if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.SYS_NAME)) {
                                listSelectListInfoFromDb = CM_SysNameDataUtil.getNameList(this.cM_A03_SessionDto,
                                        dsItemInfoList.get(i).selectListCode, this.cM_A03_SessionDto.ssn_UserLangCD);
                                // 名称マスタから取得
                            } else {
                                listSelectListInfoFromDb = CM_MstNameDataUtil.getNameList(this.cM_A03_SessionDto,
                                        dsItemInfoList.get(i).selectListCode, this.cM_A03_SessionDto.ssn_UserLangCD);
                            }

                            if (listSelectListInfoFromDb != null) {
                                // 名称マスタ（システム用）から取得
                                if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.SYS_NAME)) {
                                    strMapKeyCd = SysNameEntityNames.itemCd().toString();
                                    strMapKeyName = SysNameEntityNames.name1().toString();
                                } else {
                                    strMapKeyCd = MstNameEntityNames.itemCd().toString();
                                    strMapKeyName = MstNameEntityNames.name().toString();
                                }

                                for (int j = 0; j < listSelectListInfoFromDb.size(); j++) {
                                    // DBから取得した選択肢データを取得
                                    mapSelectListFromDb = listSelectListInfoFromDb.get(j);
                                    // 表示用選択肢データ初期化
                                    mapSelectListForDisp = new BeanMap();
                                    // コードを登録
                                    mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, mapSelectListFromDb.get(strMapKeyCd));
                                    // 名称を登録
                                    mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME, mapSelectListFromDb.get(strMapKeyName));

                                    listSelectListInfoForDisp.add(mapSelectListForDisp);
                                }
                            }
                        }
                        // 環境マスタから取得する場合
                    } else if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.SYS_ENV)) {

                        // 名称コードを取得
                        if (!CM_CommonUtil.isNullOrBlank(dsItemInfoList.get(i).selectListCode)) {
                            listSelectListInfoFromDb = CM_SysEnvDataUtil.selectListSysEnv(this.cM_A03_SessionDto, dsItemInfoList.get(i).selectListCode);

                            if (listSelectListInfoFromDb != null) {

                                strMapKeyCd = SysEnvEntityNames.itemCd().toString();
                                strMapKeyName = SysEnvEntityNames.name().toString();

                                for (int j = 0; j < listSelectListInfoFromDb.size(); j++) {
                                    // DBから取得した選択肢データを取得
                                    mapSelectListFromDb = listSelectListInfoFromDb.get(j);
                                    // 表示用選択肢データ初期化
                                    mapSelectListForDisp = new BeanMap();
                                    // コードを登録
                                    mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, mapSelectListFromDb.get(strMapKeyCd));
                                    // 名称を登録
                                    mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME, mapSelectListFromDb.get(strMapKeyName));

                                    listSelectListInfoForDisp.add(mapSelectListForDisp);
                                }
                            }
                        }
                        // 役割マスタから取得する場合
                    } else if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.MST_ROLE)) {
                        // 役割マスタからデータ取得
                        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
                        List<BeanMap> mstRoleDataList = mstDataService.getMstRoleList(this.cM_A03_SessionDto.ssn_AuthorityCode);

                        if (mstRoleDataList != null) {

                            strMapKeyCd = MstRoleEntityNames.sid().toString();
                            strMapKeyName = MstRoleEntityNames.roleName().toString();

                            for (int j = 0; j < mstRoleDataList.size(); j++) {
                                // DBから取得した選択肢データを取得
                                mapSelectListFromDb = mstRoleDataList.get(j);
                                // 表示用選択肢データ初期化
                                mapSelectListForDisp = new BeanMap();
                                // コードを登録
                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, mapSelectListFromDb.get(strMapKeyCd));
                                // 名称を登録
                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME, mapSelectListFromDb.get(strMapKeyName));

                                listSelectListInfoForDisp.add(mapSelectListForDisp);
                            }
                        }
                        // ユーザマスタから取得する場合
                    } else if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.MST_USER)) {
                        // ユーザマスタからデータ取得
                        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
                        List<BeanMap> mstUserDataList = mstDataService.getMstUserList();

                        if (mstUserDataList != null) {

                            strMapKeyCd = MstUserEntityNames.sid().toString();
                            strMapKeyName = MstUserEntityNames.userLastname().toString();
                            strMapKeyName2 = MstUserEntityNames.userFirstname().toString();

                            for (int j = 0; j < mstUserDataList.size(); j++) {
                                // DBから取得した選択肢データを取得
                                mapSelectListFromDb = mstUserDataList.get(j);
                                // 表示用選択肢データ初期化
                                mapSelectListForDisp = new BeanMap();
                                // コードを登録
                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, mapSelectListFromDb.get(strMapKeyCd));
                                // 名称を登録
                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME,
                                        mapSelectListFromDb.get(strMapKeyName) + FW00_19_Const.SPACE + mapSelectListFromDb.get(strMapKeyName2));

                                listSelectListInfoForDisp.add(mapSelectListForDisp);
                            }
                        }
                        // 型番マスタから取得する場合
                    } else if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.MST_MODEL)) {
                        // 型番マスタからデータ取得
                        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
                        List<BeanMap> mstModelDataList = mstDataService.getMstModelList();

                        if (mstModelDataList != null) {

                            strMapKeyCd = MstModelEntityNames.sid().toString();
                            strMapKeyName = MstModelEntityNames.name().toString();

                            for (int j = 0; j < mstModelDataList.size(); j++) {
                                // DBから取得した選択肢データを取得
                                mapSelectListFromDb = mstModelDataList.get(j);
                                // 表示用選択肢データ初期化
                                mapSelectListForDisp = new BeanMap();
                                // コードを登録
                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, mapSelectListFromDb.get(strMapKeyCd));
                                // 名称を登録
                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME, mapSelectListFromDb.get(strMapKeyName));

                                listSelectListInfoForDisp.add(mapSelectListForDisp);
                            }
                        }
                        // 個別定義から取得する場合
                    } else if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.USER_LIST)) {
                        // 個別定義からデータ取得
                        String[] listCode = new String[0];
                        String[] listDispChar = new String[0];

                        // 個別定義のコードセットを分割
                        if (!CM_CommonUtil.isNullOrBlank(dsItemInfoList.get(i).selectListCodeSet)) {
                            listCode = dsItemInfoList.get(i).selectListCodeSet.split(FW00_19_Const.COMMA_STR);
                        }
                        // 個別定義の表示文言セットを分割
                        if (!CM_CommonUtil.isNullOrBlank(dsItemInfoList.get(i).selectListDispCharSet)) {
                            listDispChar = dsItemInfoList.get(i).selectListDispCharSet.split(FW00_19_Const.COMMA_STR);
                        }

                        if (listCode != null && listCode.length > 0) {
                            for (int j = 0; j < listCode.length; j++) {
                                // 表示用選択肢データ初期化
                                mapSelectListForDisp = new BeanMap();
                                // コードを登録
                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, listCode[j]);

                                // 名称を登録
                                if (listDispChar != null && listDispChar.length > j) {
                                    mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME,
                                            CM_DisplayCharResourceUtil.getDisplayCharValue(this.cM_A03_SessionDto.ssn_CustomerCD,
                                                    this.cM_A03_SessionDto.ssn_UserLangCD, listDispChar[j]));
                                }
                                listSelectListInfoForDisp.add(mapSelectListForDisp);
                            }
                        }
                    }

                    this.itemSelectListInfoMap.put(dsItemInfoList.get(i).itemId, listSelectListInfoForDisp);

                }
                this.itemList.add(dsItemInfoMap);
            }
        }
        return;
    }

    /**
     *
     * 共通詳細検索用の入力検索情報を検索処理用に分解加工する.<br>
     *<br>
     * 概要:<br>
     *   共通詳細検索用の入力検索情報を検索処理用に分解加工する。
     *<br>
     * @param _strPageId 画面ID
     * @param _actionForm 画面ActionFrom
     * @return 検索条件情報
     */
    protected Map<String, Object> getComDetailSearchInfo(final String _strPageId, final FW01_17_BaseForm _actionForm) {

        Map<String, Object> retMap = new HashMap<String, Object>();

        // 復帰用データを作成する
        this.itemRestoreInfoMap = new HashMap<String, Object>();

        // 対象画面の詳細検索設定情報を取得
        ArrayList<CM_A08_ComDetailSearchItemDto> dsItemInfoList = CM_ComDetailSearchUtil.getDSItemInfo(_strPageId);

        // 検索条件入力値がセットされている場合、検索条件情報を作成
        if (!CM_CommonUtil.isNullOrBlank(_actionForm.hdnComDetailSearchCond)) {

            // 検索条件文字列をセパレータで分割
            // 入力された検索条件の配列を作成
            String[] strSearchValueList = _actionForm.hdnComDetailSearchCond.split(DETAIL_SEARCH_ITEM_SEP);

            String[] strItemTempList = null;
            String strItemId = FW00_19_Const.EMPTY_STR;
            String strItemIdOrg = FW00_19_Const.EMPTY_STR;
            String strItemValue = FW00_19_Const.EMPTY_STR;

            // 入力された検索条件分ループ
            for (int i = 0; i < strSearchValueList.length; i++) {

                // 条件文字列を項目IDと条件内容に分割
                strItemTempList = strSearchValueList[i].split(FW00_19_Const.COLON_STR, 2);

                strItemId = FW00_19_Const.EMPTY_STR;
                strItemIdOrg = FW00_19_Const.EMPTY_STR;
                // 項目IDを取得
                if (!CM_CommonUtil.isNullOrBlank(strItemTempList[0])) {
                    strItemIdOrg = strItemTempList[0];
                    strItemId = strItemIdOrg;

                    // 検索項目名の不要ヘッダ文字列を削除
                    for (int j = 0; j < DETAIL_SEARCH_COND_HEADER_LIST.length; j++) {
                        strItemId = strItemId.replace(DETAIL_SEARCH_COND_HEADER_LIST[j], FW00_19_Const.EMPTY_STR);
                    }
                }

                strItemValue = FW00_19_Const.EMPTY_STR;
                // 条件内容を取得
                if (strItemTempList.length > 1 && !CM_CommonUtil.isNullOrBlank(strItemTempList[1])) {
                    strItemValue = strItemTempList[1];
                }

                // 項目ID、条件内容が取得できない場合は、条件対象外とする
                if (CM_CommonUtil.isNullOrBlank(strItemId) || CM_CommonUtil.isNullOrBlank(strItemValue)) {
                    continue;
                }

                // 項目IDに対応する条件設定情報を取得
                for (CM_A08_ComDetailSearchItemDto dsItemInfo : dsItemInfoList) {

                    // 項目IDが一致する条件情報で検索条件を作成
                    if (dsItemInfo.itemId.equals(strItemId)) {

                        // 対象の条件設定情報にて検索条件情報を作成
                        makeWhereInfo(retMap, dsItemInfo, strItemIdOrg, strItemValue);
                        makeItemRestoreInfo(this.itemRestoreInfoMap, dsItemInfo, strItemIdOrg, strItemValue);
                        break;
                    }
                }
            }

        }

        return retMap;
    }

    /**
     *
     * 共通詳細検索用の入力検索情報を検索処理用に分解加工する.<br>
     *<br>
     * 概要:<br>
     *   共通詳細検索用の入力検索情報を検索処理用に分解加工する。
     *<br>
     * @param _retMap 検索条件パラメータ情報
     * @param _dsItemInfo 条件設定情報
     * @param _strItemNameOrg 条件項目名
     * @param _strItemValue 条件内容
     */
    private void makeWhereInfo(final Map<String, Object> _retMap, final CM_A08_ComDetailSearchItemDto _dsItemInfo,
            final String _strItemNameOrg, final String _strItemValue) {

        // 項目の条件タイプにより条件内容を加工
        // IN句の場合
        if (_dsItemInfo.whereCondType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_TYPE.IN)) {
            // 複数条件をセパレータで分割
            String[] strTempList = _strItemValue.split(DETAIL_SEARCH_COND_SEP);

            // 数値型の場合、数値変換し条件パラメータに登録
            if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.INT)) {

                ArrayList<Integer> condList = new ArrayList<Integer>();
                // 条件分ループ
                for (String strVal : strTempList) {

                    try {
                        int numVal = Integer.parseInt(strVal);
                        condList.add(numVal);
                    } catch (NumberFormatException e) {
                        return;
                    }
                }
                _retMap.put(_strItemNameOrg, condList);

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.SHORT)) {

                ArrayList<Short> condList = new ArrayList<Short>();
                // 条件分ループ
                for (String strVal : strTempList) {

                    try {
                        short numVal = Short.parseShort(strVal);
                        condList.add(numVal);
                    } catch (NumberFormatException e) {
                        return;
                    }
                }
                _retMap.put(_strItemNameOrg, condList);

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.LONG)) {

                ArrayList<Long> condList = new ArrayList<Long>();
                // 条件分ループ
                for (String strVal : strTempList) {

                    try {
                        long numVal = Long.parseLong(strVal);
                        condList.add(numVal);
                    } catch (NumberFormatException e) {
                        return;
                    }
                }
                _retMap.put(_strItemNameOrg, condList);

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.FLOAT)) {

                ArrayList<Float> condList = new ArrayList<Float>();
                // 条件分ループ
                for (String strVal : strTempList) {

                    try {
                        float numVal = Float.parseFloat(strVal);
                        condList.add(numVal);
                    } catch (NumberFormatException e) {
                        return;
                    }
                }
                _retMap.put(_strItemNameOrg, condList);

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.DOUBLE)) {

                ArrayList<Double> condList = new ArrayList<Double>();
                // 条件分ループ
                for (String strVal : strTempList) {

                    try {
                        double numVal = Double.parseDouble(strVal);
                        condList.add(numVal);
                    } catch (NumberFormatException e) {
                        return;
                    }
                }
                _retMap.put(_strItemNameOrg, condList);

                // その他の型は文字配列をそのまま登録
            } else {
                _retMap.put(_strItemNameOrg, strTempList);
            }
            // Like句の場合
        } else if (_dsItemInfo.whereCondType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_TYPE.LIKE)) {
            // ワイルドカード文字をエスケープして登録
            String strTemp = CM_CommonUtil.escapeLikeString(_strItemValue);

            // LIKE検索用のワイルドカードを前後に追加
            strTemp = CM_CommonUtil.addWildcard(strTemp, true, true);

            _retMap.put(_strItemNameOrg, strTemp);

            // その他の場合はそのまま登録
        } else {
            // 数値型の場合、数値変換し条件パラメータに登録
            if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.INT)) {

                try {
                    int numVal = Integer.parseInt(_strItemValue);
                    _retMap.put(_strItemNameOrg, numVal);
                } catch (NumberFormatException e) {
                    return;
                }

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.SHORT)) {

                try {
                    short numVal = Short.parseShort(_strItemValue);
                    _retMap.put(_strItemNameOrg, numVal);
                } catch (NumberFormatException e) {
                    return;
                }

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.LONG)) {

                try {
                    long numVal = Long.parseLong(_strItemValue);
                    _retMap.put(_strItemNameOrg, numVal);
                } catch (NumberFormatException e) {
                    return;
                }

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.FLOAT)) {

                try {
                    float numVal = Float.parseFloat(_strItemValue);
                    _retMap.put(_strItemNameOrg, numVal);
                } catch (NumberFormatException e) {
                    return;
                }

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.DOUBLE)) {

                try {
                    double numVal = Double.parseDouble(_strItemValue);
                    _retMap.put(_strItemNameOrg, numVal);
                } catch (NumberFormatException e) {
                    return;
                }

                // その他の型は文字配列をそのまま登録
            } else {
                _retMap.put(_strItemNameOrg, _strItemValue);
            }

        }

        return;
    }

    /**
     *
     * 共通詳細検索用の入力検索情報を検索処理用に分解加工する.<br>
     *<br>
     * 概要:<br>
     *   共通詳細検索用の入力検索情報を検索処理用に分解加工する。
     *<br>
     * @param _restoreMap 詳細検索条件復帰情報
     * @param _dsItemInfo 条件設定情報
     * @param _strItemNameOrg 条件項目名
     * @param _strItemValue 条件内容
     */
    private void makeItemRestoreInfo(final HashMap<String, Object> _restoreMap, final CM_A08_ComDetailSearchItemDto _dsItemInfo,
            final String _strItemNameOrg, final String _strItemValue) {

        // 項目タイプにより条件内容を加工
        // Checkboxタイプの場合
        if (_dsItemInfo.inputType.equals(CM_A08_ComDetailSearchItemDto.VAL_INPUT_TYPE.CHECKBOX)) {

            // 複数条件をセパレータで分割
            String[] strTempList = _strItemValue.split(DETAIL_SEARCH_COND_SEP);

            ArrayList<String> condList = new ArrayList<String>();

            // 条件分ループ
            for (String strVal : strTempList) {
                condList.add(strVal);
            }

            _restoreMap.put(_strItemNameOrg, condList);

            // その他はそのまま復帰情報にセット
        } else {
            _restoreMap.put(_strItemNameOrg, _strItemValue);
        }

        return;
    }

    /**
     *
     * ヘッダーメニューのログアウト押下の処理.<br>
     *<br>
     * 概要:<br>
     *   ログイン画面へ遷移する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String logout_click() {

        FW01_17_BaseForm baseForm = new FW01_17_BaseForm();

        // セッション情報クリア
        this.cM_A03_SessionDto.initialize();

        return this.redirectPage("/a000010Login/index", new HashMap<String, String>(), baseForm);
    }

    /**
     *
     * ヘッダーメニューのユーザ設定押下の処理.<br>
     *<br>
     * 概要:<br>
     *   ユーザ情報画面へ遷移する
     *<br>
     * @return JSP名
     * @throws IllegalAccessException アクセス権限違反例外
     */
    @Execute(validator = false)
    public String menu_userSetting_click() throws IllegalAccessException {

        FW01_17_BaseForm baseForm = null;
        for (Field field : this.getClass().getFields()) {

            Object prop = field.get(this);

            // フォーム情報を検索
            if (prop instanceof FW01_17_BaseForm) {
                baseForm = (FW01_17_BaseForm) prop;
                break;
            }
        }

        String linkUrl = CM_A04_Const.USER_INFO_URL;

        // パンくずメニュークリア
        CM_HeaderUtil.removeAllBreadCrumbList(this.cM_A03_SessionDto);

        // パンくず先頭にホーム画面をセット
        CM_HeaderUtil.addBreadCrumbList(this.cM_A03_SessionDto, CM_A04_Const.HOME_PAGE_ID);
        CM_HeaderUtil.setReturnInfo(this.cM_A03_SessionDto, CM_A04_Const.HOME_PAGE_ID, CM_A04_Const.HOME_URL, null);

        // 遷移パラメータ作成
        HashMap<String, String> param = new HashMap<String, String>();
        param.put(CM_A04_Const.A500030FORM_HDN_USERSID, Integer.toString(this.cM_A03_SessionDto.ssn_UserSID));
        param.put(CM_A04_Const.A500030FORM_HDN_INFOMODE, CM_A03_InfoAction.MODE_DISP);


        return this.redirectPage(linkUrl, param, baseForm);
    }

    /**
     *
     * ヘッダーメニューのリンク押下の処理.<br>
     *<br>
     * 概要:<br>
     *   押下したメニューの画面へ遷移する
     *<br>
     * @return JSP名
     * @throws IllegalAccessException アクセス権限違反例外
     */
    @Execute(validator = false)
    public String menu_link_click() throws IllegalAccessException {

        FW01_17_BaseForm baseForm = null;
        for (Field field : this.getClass().getFields()) {

            Object prop = field.get(this);

            // フォーム情報を検索
            if (prop instanceof FW01_17_BaseForm) {
                baseForm = (FW01_17_BaseForm) prop;
                break;
            }
        }

        String linkUrl = CM_A04_Const.HOME_URL;
        if (baseForm != null && !CM_CommonUtil.isNullOrBlank(baseForm.hdnComHeaderMenuLink)) {
            linkUrl = baseForm.hdnComHeaderMenuLink;
        }

        // パンくずメニュークリア
        CM_HeaderUtil.removeAllBreadCrumbList(this.cM_A03_SessionDto);

        // ホーム画面遷移の以外場合は、パンくず先頭にホーム画面をセット
        if (!linkUrl.equals(CM_A04_Const.HOME_URL)) {
            CM_HeaderUtil.addBreadCrumbList(this.cM_A03_SessionDto, CM_A04_Const.HOME_PAGE_ID);
            CM_HeaderUtil.setReturnInfo(this.cM_A03_SessionDto, CM_A04_Const.HOME_PAGE_ID, CM_A04_Const.HOME_URL, null);
        }

        Map<String, String> param = new HashMap<String, String>();
        if (baseForm != null) {
            if (baseForm instanceof CM_BaseForm) {
                // お気に入り遷移フラグがある場合は付加
                String hdnFavoriteAccessFlg = ((CM_BaseForm) baseForm).hdnFavoriteAccessNo;
                if (CM_CommonUtil.isNotNullOrBlank(hdnFavoriteAccessFlg)) {
                    param.put(CM_BaseForm.HDN_FAVORITE_ACCESS_NO, hdnFavoriteAccessFlg);
                }
            }
        }

        return this.redirectPage(linkUrl, param, baseForm);
    }

    /**
     *
     * ヘッダーのパンくずリストリンク押下の処理.<br>
     *<br>
     * 概要:<br>
     *   押下したパンくずリストの画面へ遷移する
     *<br>
     * @return JSP名
     * @throws IllegalAccessException アクセス権限違反例外
     */
    @Execute(validator = false)
    public String bread_crumb_link_click() throws IllegalAccessException {

        // フォーム情報を取得
        FW01_17_BaseForm baseForm = null;
        for (Field field : this.getClass().getFields()) {

            Object prop = field.get(this);

            // フォーム情報を検索
            if (prop instanceof FW01_17_BaseForm) {
                baseForm = (FW01_17_BaseForm) prop;
                break;
            }
        }

        String linkUrl = CM_A04_Const.HOME_URL;
        // 遷移情報が取得できない場合はホーム画面に遷移
        if (baseForm == null || CM_CommonUtil.isNullOrBlank(baseForm.hdnComHeaderBreadCrumbIndex)) {
            // パンくずメニュークリア
            CM_HeaderUtil.removeAllBreadCrumbList(this.cM_A03_SessionDto);

            return this.redirectPage(linkUrl, new HashMap<String, String>(), new FW01_17_BaseForm());
        }

        // 押下されたパンくずリストのINDEX番号を取得
        String strBreadCrumbIndex = baseForm.hdnComHeaderBreadCrumbIndex;
        int intBreadCrumbIndex = Integer.parseInt(strBreadCrumbIndex);

        // 指定されたパンくずリストが存在しない場合はホーム画面に遷移
        int intListCount = this.cM_A03_SessionDto.ssn_BreadCrumbList.size();
        if (intListCount <= intBreadCrumbIndex) {
            return this.redirectPage(linkUrl, new HashMap<String, String>(), new FW01_17_BaseForm());
        }

        // 対象のパンくずリスト情報を取得
        CM_A07_BreadCrumbDto breadCrumbInfo = this.cM_A03_SessionDto.ssn_BreadCrumbList.get(intBreadCrumbIndex);

        // 遷移先情報作成
        linkUrl = breadCrumbInfo.ssn_ReturnMethod;
        HashMap<String, String> returnDispInfo = new HashMap<String, String>();

        // 遷移先画面以降のパンくずリスト削除
        for (int i = intListCount - 1; i > intBreadCrumbIndex; i--) {
            this.cM_A03_SessionDto.ssn_BreadCrumbList.remove(i);
        }

        // 遷移先画面のリンク情報をクリア
        breadCrumbInfo.ssn_ReturnMethod = FW00_19_Const.EMPTY_STR;

        return this.redirectPage(linkUrl, returnDispInfo, baseForm);
    }

    /**
     *
     * 検索処理時のフォーム内不要データクリア.<br>
     *<br>
     * 概要:<br>
     *   検索処理時に現在のページ番号、ソートキー、ソート順は不要なため、初期化する。
     *<br>
     * @param _actionForm 画面ActionFrom
     */
    protected void clearListFormForSearch(final FW01_14_ListForm _actionForm) {
        _actionForm.fw0114PageNo = "1";
        _actionForm.fw0114SortKey = null;
        _actionForm.fw0114SortOrder = null;
    }

    /**
     *
     * 遷移前データ復帰処理.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _actionForm 画面ActionFrom
     * @param _data 遷移前データ
     */
    protected void setReturnDispInfo(final FW01_14_ListForm _actionForm, final HashMap<String, Object> _data) {
        if (_data != null) {
            // ページング関連情報の復帰
            if (!CM_CommonUtil.isNullOrBlank(_data.get(FW01_14_ListForm.FW0114FORM_PAGENO))) {
                _actionForm.fw0114PageNo = _data.get(FW01_14_ListForm.FW0114FORM_PAGENO).toString();
            }
            if (!CM_CommonUtil.isNullOrBlank(_data.get(FW01_14_ListForm.FW0114FORM_SORTKEY))) {
                _actionForm.fw0114SortKey = _data.get(FW01_14_ListForm.FW0114FORM_SORTKEY).toString();
            }
            if (!CM_CommonUtil.isNullOrBlank(_data.get(FW01_14_ListForm.FW0114FORM_SORTORDER))) {
                _actionForm.fw0114SortOrder = _data.get(FW01_14_ListForm.FW0114FORM_SORTORDER).toString();
            }
            if (!CM_CommonUtil.isNullOrBlank(_data.get(FW01_14_ListForm.FW0114FORM_LISTSIZE))) {
                _actionForm.fw0114ListSize =  _data.get(FW01_14_ListForm.FW0114FORM_LISTSIZE).toString();
            }

            // 詳細検索条件の復帰
            if (!CM_CommonUtil.isNullOrBlank(_data.get(FW01_17_BaseForm.CM_HDN_COM_DETAIL_SEARCH_COND))) {
                _actionForm.hdnComDetailSearchCond = _data.get(FW01_17_BaseForm.CM_HDN_COM_DETAIL_SEARCH_COND).toString();
            }
            if (!CM_CommonUtil.isNullOrBlank(_data.get(FW01_17_BaseForm.CM_HDN_COM_DETAIL_SEARCH_COND_FOR_SORT))) {
                _actionForm.hdnComDetailSearchCondForSort = _data.get(FW01_17_BaseForm.CM_HDN_COM_DETAIL_SEARCH_COND_FOR_SORT).toString();
            }

        }
    }

    /**
     * CSVデータ数カウントチェック.
     * @param _count カウント数
     * @return カウントチェック結果(チェックOK：null, チェックNG：エラーページ情報)
     */
    protected String checkCsvCount(final long _count) {

        if (_count > CSV_DATA_MAX) {
            this.csvLimitError = "true";
            this.csvLimitNum = String.valueOf(CSV_DATA_MAX);
        }

        return "/FW01_20_WarningCsv.jsp";
    }

    /**
     * 部分データリスト取得.<br>
     *<br>
     * 概要:<br>
     *   出力可能なデータ数以上のデータを切り取ったデータリストを返す
     *<br>
     * @param _dataList 元データリスト
     * @return 上限内データリスト
     */
    protected List<List<String[]>> getLimitCutList(final List<List<String>> _dataList) {
        List<List<String[]>> dataStrList = new ArrayList<List<String[]>>();
        List<String[]> tmpDataList = new ArrayList<String[]>();
        for (int i = 0; i < _dataList.size(); i++) {
            if (i >= CM_A02_ListAction.CSV_DATA_MAX) {
                break;
            }
            List<String> csvDataList = _dataList.get(i);
            tmpDataList.add(csvDataList.toArray(new String[0]));
        }
        dataStrList.add(tmpDataList);
        return dataStrList;
    }

    /**
     * CSVダウンロード.
     * @param _csvFormat CSVフォーマットクラス
     * @return null値
     */
    protected String downloadCsv(final FW01_10_CSVFormat _csvFormat) {
        return this.downloadCsv(null, _csvFormat);
    }

    /**
     * CSVダウンロード(ファイル名指定).
     * @param _fileName ファイル名
     * @param _csvFormat CSVフォーマット
     * @return null値
     */
    protected String downloadCsv(final String _fileName, final FW01_10_CSVFormat _csvFormat) {

        List<String[]> headerStrList = new ArrayList<String[]>();
        List<List<String[]>> dataStrList = new ArrayList<List<String[]>>();

        for (String areaKey : _csvFormat.getAreaKeyList()) {

            List<String> headerList = new ArrayList<String>();
            for (String headerStr : _csvFormat.getHeaderInfo(areaKey)) {
                // ヘッダ用文字列をリソースから取得する
                headerList.add(CM_DisplayCharResourceUtil.getDisplayCharValue(
                        this.cM_A03_SessionDto.ssn_CustomerCD, this.cM_A03_SessionDto.ssn_UserLangCD, headerStr));
            }
            headerStrList.add((String[]) headerList.toArray(new String[0]));
            dataStrList.add(_csvFormat.getDataInfo(areaKey));
        }

        _csvFormat.clear();

        return this.downloadCsvCommon(_fileName, headerStrList, dataStrList);
    }

    /**
     * CSVダウンロード(ファイル名指定).
     * @param _fileName ファイル名
     * @param _dateStr ヘッダ用更新日時文字列
     * @param _csvFormat CSVフォーマット
     * @return null値
     */
    protected String downloadCsv(final String _fileName, final String _dateStr, final FW01_10_CSVFormat _csvFormat) {

        List<String[]> headerStrList = new ArrayList<String[]>();
        List<List<String[]>> dataStrList = new ArrayList<List<String[]>>();

        List<Map<String, String>> infoAreaDataList = new ArrayList<Map<String, String>>();
        Map<String, String> infoAreaMap = new HashMap<String, String>();
        infoAreaMap.put("name", _fileName);
        infoAreaMap.put("date", _dateStr);
        infoAreaMap.put("version", CM_HeaderUtil.getDisplaySystemVersion());
        infoAreaDataList.add(infoAreaMap);
        _csvFormat.putDataInfoList("infoArea", infoAreaDataList);

        for (String areaKey : _csvFormat.getAreaKeyList()) {

            List<String> headerList = new ArrayList<String>();
            for (String headerStr : _csvFormat.getHeaderInfo(areaKey)) {
                // ヘッダ用文字列をリソースから取得する
                headerList.add(CM_DisplayCharResourceUtil.getDisplayCharValue(
                        this.cM_A03_SessionDto.ssn_CustomerCD, this.cM_A03_SessionDto.ssn_UserLangCD, headerStr));
            }
            headerStrList.add((String[]) headerList.toArray(new String[0]));
            dataStrList.add(_csvFormat.getDataInfo(areaKey));
        }

        _csvFormat.clear();

        return this.downloadCsvCommon(_fileName, headerStrList, dataStrList);
    }

    /**
     * CSVダウンロード(ファイル名指定).
     * @param _fileName ファイル名
     * @param _dateStr ヘッダ用更新日時文字列
     * @param _headerList ヘッダーリスト
     * @param_dataList データリスト
     * @param _csvFormat CSVフォーマット
     * @return null値
     */
    protected String downloadCsv(final String _fileName,
            final String _dateStr,
            final List<String[]> _headerList,
            final List<List<String[]>> _dataList,
            final FW01_10_CSVFormat _csvFormat) {

        List<String[]> headerStrList = new ArrayList<String[]>();
        List<List<String[]>> dataStrList = new ArrayList<List<String[]>>();

        List<Map<String, String>> infoAreaDataList = new ArrayList<Map<String, String>>();
        Map<String, String> infoAreaMap = new HashMap<String, String>();
        infoAreaMap.put("name", _fileName);
        infoAreaMap.put("date", _dateStr);
        infoAreaMap.put("version", CM_HeaderUtil.getDisplaySystemVersion());
        infoAreaDataList.add(infoAreaMap);
        _csvFormat.putDataInfoList("infoArea", infoAreaDataList);

        String areaKey = "infoArea";

        List<String> headerList = new ArrayList<String>();
        for (String headerStr : _csvFormat.getHeaderInfo(areaKey)) {
            // ヘッダ用文字列をリソースから取得する
            headerList.add(CM_DisplayCharResourceUtil.getDisplayCharValue(
                    this.cM_A03_SessionDto.ssn_CustomerCD, this.cM_A03_SessionDto.ssn_UserLangCD, headerStr));
        }
        headerStrList.add((String[]) headerList.toArray(new String[0]));
        dataStrList.add(_csvFormat.getDataInfo(areaKey));

        _csvFormat.clear();

        for (int i = 0; i < _headerList.size(); i++) {
            headerStrList.add(_headerList.get(i));
            dataStrList.add(_dataList.get(i));
        }

        return this.downloadCsvCommon(_fileName, headerStrList, dataStrList);
    }

    /**
     * CSVダウンロード共通処理.
     * @param _fileName ファイル名
     * @param _headerList ヘッダリスト
     * @param _dataList データリスト
     * @return null値
     */
    protected String downloadCsvCommon(
            final String _fileName,
            final List<String[]> _headerList,
            final List<List<String[]>> _dataList) {

        if (_headerList.size() != _dataList.size()) {
            return null;
        }

        ServletOutputStream out = null;
        FW01_10_CSVWriter outCsv = null;

        try {
            if (_fileName != null && !_fileName.equals(FW00_19_Const.EMPTY_STR)) {
                String encordName = FW00_11_UrlEncodeUtil.getUrlEncode(_fileName);
                this.response.setContentType("application/octet-stream");
                this.response.setHeader("Content-Disposition", "attachment; filename=\"" + encordName + "\"");
            } else {
                this.response.setContentType("application/octet-stream");
                this.response.setHeader("Content-Disposition", "attachment");
            }
            this.response.setHeader("Cache-Control", "private");
            this.response.setHeader("Pragma", "private");

            out = this.response.getOutputStream();
            outCsv = new FW01_10_CSVWriter(out);

            for (int i = 0; i < _headerList.size(); i++) {
                outCsv.writeHeader(_headerList.get(i));
                outCsv.writeData(_dataList.get(i));
            }
        } catch (IOException e) {
            this.response.reset();
            this.response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            throw new FW00_12_AppException(e);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (outCsv != null) {
                try {
                    outCsv.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return null;
    }

    /**
     *
     * グループツリーデータ取得処理.<br>
     *<br>
     * 概要:<br>
     *   グループツリーデータを取得する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String searchGroupTree() {

        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
        this.groupTreeInfo = mstDataService.getGroupTreeInfoList(this.cM_A03_SessionDto.ssn_UserSID);

        return "../common/com_searchGroupTree.jsp";
    }

    /**
     *
     * ヘッダーメニューのHelpボタン押下の処理.<br>
     *<br>
     * 概要:<br>
     *   マニュアルダウンロードする
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String download_help_click() {

        // ファイルパス取得
        String fileDirectory = CM_A04_Const.MANUAL_DIR;
        // ファイル名取得
        String fileName = CM_A04_Const.MANUAL_FILENAME;

        return super.download(fileName, fileDirectory + fileName);
    }

    /**
     *
     * アップロードCSVファイル共通チェック処理.<br>
     *<br>
     * 概要:<br>
     *   アップロードCSVファイルの共通チェック処理
     *<br>
     * @return 返却JSPパス
     */
    @Execute(validator = false)
    public String checkImportCsv() {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, getActionForm());

        CM_BaseService service = this.getService();

        service.init(this.cM_A03_SessionDto);

        this.csvUploadResult = new CM_Csv_Upload_Result();

        FormFile uploadCsvFile = getActionForm().uploadCsvFile;

        // ファイルサイズをチェック
        String strErrorMsg = CM_CsvUtil.checkCsvFileLimit(uploadCsvFile, this.cM_A03_SessionDto);

        if (CM_CommonUtil.isNotNullOrBlank(strErrorMsg)) {
            // ファイルサイズエラー
            this.csvUploadResult.setErrorMessage(strErrorMsg);

            return CM_Csv_Const.UPLOAD_RESULT_PAGE;
        }

        try {
            String uploadCsvVersion = CM_CsvUtil.getCsvSystemVersion(getCsvFormat(),  uploadCsvFile.getInputStream(), this.cM_A03_SessionDto);

            //CSVのバージョンが現在のものと同一かどうかをチェック
            if (!CM_CommonUtil.isNullOrBlank(uploadCsvVersion) && !CM_CsvUtil.checkCsvNowSystemVersion(uploadCsvVersion)) {
                if (!CM_CsvUtil.checkCsvVersion(uploadCsvVersion, getCsvChangeVersionList(), this.cM_A03_SessionDto)) {
                    // コンバート可能な最大回数を超える場合、エラーメッセージを表示
                    String errorMsg = CM_MessageResourceUtil.getMessageValue(
                            this.cM_A03_SessionDto.ssn_CustomerCD, this.cM_A03_SessionDto.ssn_UserLangCD,
                            "MMCMCM00000_050");

                    this.csvUploadResult.setErrorMessage(errorMsg);
                } else {
                    // 古いバージョンのCSVでコンバート可能な最大回数を超えない場合、警告メッセージを表示
                    String warningMeg = CM_MessageResourceUtil.getMessageValue(
                            this.cM_A03_SessionDto.ssn_UserID, this.cM_A03_SessionDto.ssn_UserLangCD, "MMCMCM00000_046");
                    this.csvUploadResult.setWarningMessage(warningMeg);
                }
            }

            List<String[]> data = CM_CsvUtil.readCsvFile(uploadCsvFile.getInputStream());

            // 新規モードのデータが含まれている場合
            if (CM_CsvUtil.checkExistNewMode(data)) {

                // 空き容量チェック
                boolean check = CM_CommonUtil.checkDiskSpace(this.cM_A03_SessionDto, 0);
                if (!check) {
                    strErrorMsg = CM_MessageUtil.getOverDiskSpaceFileMessage(this.cM_A03_SessionDto);
                }

                if (CM_CommonUtil.isNotNullOrBlank(strErrorMsg)) {
                    // 空き容量エラー
                    this.csvUploadResult.setErrorMessage(strErrorMsg);

                    return CM_Csv_Const.UPLOAD_RESULT_PAGE;
                }
            }

        } catch (Exception e) {
            String strErrorMes = CM_MessageResourceUtil.getMessageValue(this.cM_A03_SessionDto.ssn_CustomerCD,
                    this.cM_A03_SessionDto.ssn_UserLangCD, "MMCMCM00000_024");
            this.csvUploadResult.setErrorMessage(strErrorMes);
            //ログ出力
            CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, strErrorMsg);
            return  CM_Csv_Const.UPLOAD_RESULT_PAGE;
        }

        // メソッド終了ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, CM_Csv_Const.UPLOAD_RESULT_PAGE);

        return CM_Csv_Const.UPLOAD_RESULT_PAGE;
    }

    /**
     * 各画面のCSVフォーマット情報クラス取得.<br>
     *<br>
     * 概要:<br>
     * 各画面のCSVフォーマット情報クラスを取得<br>
     * 各画面のアクションでオーバーライドし、CSVフォーマット情報クラスを設定する
     *
     * @return 画面のCSVフォーマット情報クラス
     */
    protected FW01_10_CSVFormat getCsvFormat() {
        return null;
    }

    /**
     * 各画面のCSVフォーマット変更バージョン一覧取得.<br>
     *<br>
     * 概要:<br>
     * 各画面のCSVフォーマット変更バージョン一覧を取得<br>
     * 各画面のアクションでオーバーライドし、CSVフォーマット変更バージョン一覧を設定する
     *
     * @return 画面のCSVフォーマット変更バージョン一覧
     */
    protected List<String> getCsvChangeVersionList() {
        return null;
    }

    /**
     *
     * 画像取得処理.<br/>
     *<br/>
     * 概要:<br/>
     *<br/>
     * @return NULL
     */
    @Execute(validator = false)
    public String downloadMapIconImage() {
        // フォーム情報
        FW01_14_ListForm form = this.getActionForm();

        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, form);

        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
        Integer modelSid = Integer.valueOf(form.fw0114ModelSid);
        String iconType = form.fw0114IconType;
        RelModelIconEntity iconEntity = mstDataService.getRelModelIconEntity(modelSid, iconType);

        String picpath = CM_CommonUtil.makeMapIconFilePath(this.cM_A03_SessionDto, modelSid, iconEntity.fileName);
        String ext = CM_CommonUtil.getExtention(picpath);

        boolean dlRet = CM_CommonUtil.downloadPicFileNoThrow(this.response, this.cM_A03_SessionDto, picpath, ext);

        if (!dlRet) {
            // 画像送信に失敗した場合、「no image」の画像ファイルを送る
            String defaultIconPath = CM_CommonUtil.getDefaultMapIconByIconType(iconType);
            URL url = ResourceUtil.getResource(CM_A04_Const.PARENT_DIRECTORY_PATH + defaultIconPath);
            picpath = ResourceUtil.getFileName(url);
            ext = CM_CommonUtil.getExtention(picpath);

            CM_CommonUtil.downloadPicFileNoThrow(this.response, this.cM_A03_SessionDto, picpath, ext);
        }


        // メソッド終了ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, FW00_19_Const.EMPTY_STR);

        return null;
    }


    /**
     * 画面のサービスを取得.<br>
     * <br>
     * 概要:<br>
     * 各画面のサービスを取得<br>
     * 各画面のアクションでオーバーライドし、サービスを設定する
     *
     * @return 画面のサービス
     */
    protected CM_BaseService getService() {
        return null;
    }
    /**
     * SQLエラーメッセージCD取得.
     *
     * @return strSqlErrorMsgCd
     */
    @Override
    public String getStrSqlErrorMsgCd() {
        return this.strSqlErrorMsgCd;
    }
    /**
     * SQLエラーメッセージCD設定.
     *
     * @param _strSqlErrorMsgCd SQLエラーメッセージCD
     */
    @Override
    public void setStrSqlErrorMsgCd(final String _strSqlErrorMsgCd) {
        this.strSqlErrorMsgCd = _strSqlErrorMsgCd;
    }

    /**
     *
     * 共通SQLエラーメッセージCD.<br>
     *<br>
     * 概要:<br>
     *   共通SQLエラーメッセージCD
     *<br>
     */
    protected void setBaseDefaultSqlErrorMsgCd() {
        this.setStrSqlErrorMsgCd("MMCMCM00000_303");
    }
}
