/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/05/14| 新規作成                           | 1.00.00| YSK)鬼丸
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.dao;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import jp.ysk.mmcloud.common.CM_A04_Const;
import jp.ysk.mmcloud.common.entity.customer.TblDispAccessCountDataEntity;
import jp.ysk.mmcloud.common.entity.customer.TblDispAccessCountDataEntityNames;


/**
 * 画面アクセス頻度ログ用Dao.<br>
 *<br>
 * 概要:<br>
 *   画面アクセス頻度ログ用DBアクセスを実行する
 *<br>
 */
public class CM_DispAccessLogDao extends CM_BaseDao {

    /**
     * コンストラクタ.
     */
    public CM_DispAccessLogDao() {
        super();
    }

    /**
     * コンストラクタ.
     *
     * @param _strConnectString 顧客DB接続情報
     * @param _strConnectUserId 顧客DBユーザID
     * @param _strConnectPasswd 顧客DBパスワード
     */
    public CM_DispAccessLogDao(final String _strConnectString, final String _strConnectUserId,
            final String _strConnectPasswd) {
        super(_strConnectString, _strConnectUserId, _strConnectPasswd);
    }

    /**
     *
     * 画面アクセス数のカウントアップ更新処理.<br>
     *<br>
     * 概要:<br>
     *   画面アクセス数のカウントアップ更新処理を実行する
     *<br>
     * @param _strDispId 画面ID
     * @return 更新件数
     */
    public int countUpAccessCount(final String _strDispId) {
        int retCnt = 0;
        Date dtNow = new Date();
        Timestamp tmNow = new Timestamp(dtNow.getTime());

        // アクセス時間帯の判定
        SimpleDateFormat sdf = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT_FOR_DISP_ACCESS_LOG);
        String strDatetime = sdf.format(dtNow);

        StringBuffer sbWhere = new StringBuffer();
        sbWhere.append(TblDispAccessCountDataEntityNames.accessDatetime());
        sbWhere.append(" = ? and ");
        sbWhere.append(TblDispAccessCountDataEntityNames.pageId());
        sbWhere.append(" = ?");

        // 対象カウントデータの存在チェック
        long ret = this.jdbcManager.from(TblDispAccessCountDataEntity.class).where(sbWhere.toString(), strDatetime, _strDispId).getCount();

        // 存在する場合はカウントアップ更新
        if (ret > 0) {
            // SQLパラメータ作成
            Map<String, Object> params = new HashMap<String, Object>();
            params.put(TblDispAccessCountDataEntityNames.accessDatetime().toString(), strDatetime);
            params.put(TblDispAccessCountDataEntityNames.pageId().toString(), _strDispId);
            params.put(TblDispAccessCountDataEntityNames.lastUpdProg().toString(), CM_A04_Const.CST_PROGRAM_CD);
            params.put(TblDispAccessCountDataEntityNames.lastUpdTim().toString(), tmNow);

            retCnt = this.jdbcManager.updateBySqlFile(SQL_PATH + "A000000/UpdateAccessCountData.sql", params).execute();

            // 存在しない場合は登録
        } else {
            TblDispAccessCountDataEntity entity = new TblDispAccessCountDataEntity();
            // SQLパラメータ作成
            entity.accessDatetime = strDatetime;
            entity.pageId = _strDispId;
            entity.countNum = 1;
            entity.lastUpdProg = CM_A04_Const.CST_PROGRAM_CD;
            entity.lastUpdTim = tmNow;

            retCnt = this.jdbcManager.insert(entity).execute();
        }

        return retCnt;
    }

}
