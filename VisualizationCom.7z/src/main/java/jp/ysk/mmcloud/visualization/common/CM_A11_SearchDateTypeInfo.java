/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/12/08| <C1.01>　新規作成                                                    | C1.01  | (US)甲斐
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common;

import jp.ysk.mmcloud.visualization.common.util.CM_CommonUtil;

/**
 * 共通検索機能 日時検索情報.
 */
public class CM_A11_SearchDateTypeInfo {
    /** 日時選択種別. */
    public String  comDateTypeInfo;

    /**
     * 「過去12ヶ月」表示フラグ.
     */
    public boolean dispRecentYear = false;

    // TODO JSP側で設定されているが、こちらで定義していないと初期表示時に設定処理（setInitDateInfo()）で使用できない
    /**
     * 日時選択(月次).
     */
    public CM_A04_Const.COM_SEARCH_DATE_TYPE comDateDisabledYear = null;
    /**
     * 日時選択(日次).
     */
    public CM_A04_Const.COM_SEARCH_DATE_TYPE comDateDisabledMonth = null;
    /**
     * 日時選択(時間別).
     */
    public CM_A04_Const.COM_SEARCH_DATE_TYPE comDateDisabledDay = null;
    /**
     * 日時選択(週次).
     */
    public CM_A04_Const.COM_SEARCH_DATE_TYPE comDateDisabledWeek = null;

    /**
     * 日付種別を取得.
     *
     * @param _nowDateTypeDisp 現在の日付種別
     * @return 日付種別
     */
    public String getDateTypeDisp(final String _nowDateTypeDisp) {
        String type = _nowDateTypeDisp;

        if (CM_CommonUtil.isNotNullOrBlank(this.comDateDisabledYear)
                && CM_CommonUtil.isNotNullOrBlank(this.comDateDisabledMonth)
                && CM_CommonUtil.isNotNullOrBlank(this.comDateDisabledDay)) {

            if (CM_CommonUtil.isNotNullOrBlank(_nowDateTypeDisp)) {
                // 現在の指定なしの場合
                type = getDefaultDateTypeDisp();

            } else {
                if (CM_A04_Const.DATE_TYPE_GETUJI.equals(_nowDateTypeDisp)) {
                    // 月次の場合
                    if (this.comDateDisabledYear.isDisabled()) {
                        // 月次選択不可の場合

                        type = getDefaultDateTypeDisp();
                    }

                } else if (CM_A04_Const.DATE_TYPE_NITIJI.equals(_nowDateTypeDisp)) {
                    // 日次の場合

                    if (this.comDateDisabledMonth.isDisabled()) {
                        // 日次選択不可の場合

                        type = getDefaultDateTypeDisp();
                    }
                } else {
                    // 時間別の場合

                    if (this.comDateDisabledDay.isDisabled()) {
                        // 日次選択不可の場合

                        type = getDefaultDateTypeDisp();
                    }
                }
            }
        } else if (CM_CommonUtil.isNotNullOrBlank(this.comDateDisabledWeek)
                && CM_CommonUtil.isNotNullOrBlank(this.comDateDisabledMonth)
                && CM_CommonUtil.isNotNullOrBlank(this.comDateDisabledDay)) {

            if (CM_CommonUtil.isNotNullOrBlank(_nowDateTypeDisp)) {
                // 現在の指定なしの場合
                type = getDefaultDateTypeReportDisp();

            } else {
                if (CM_A04_Const.DATE_TYPE_NITIJI.equals(_nowDateTypeDisp)) {
                    // 月次の場合
                    if (this.comDateDisabledWeek.isDisabled()) {
                        // 月次選択不可の場合

                        type = getDefaultDateTypeReportDisp();
                    }

                } else if (CM_A04_Const.DATE_TYPE_SHUJI.equals(_nowDateTypeDisp)) {
                    // 日次の場合

                    if (this.comDateDisabledMonth.isDisabled()) {
                        // 日次選択不可の場合

                        type = getDefaultDateTypeReportDisp();
                    }
                } else {
                    // 時間別の場合

                    if (this.comDateDisabledDay.isDisabled()) {
                        // 日次選択不可の場合

                        type = getDefaultDateTypeReportDisp();
                    }
                }
            }
        }

        return type;
    }
    /**
     * ディフォルトの選択取得.
     *
     * @return ディフォルトの選択
     */
    private String getDefaultDateTypeDisp() {
        String type = null;
        if (CM_A04_Const.COM_SEARCH_DATE_TYPE.DEFAULT.equals(this.comDateDisabledYear)) {
            // 月次
            type = CM_A04_Const.DATE_TYPE_GETUJI;
        } else if (CM_A04_Const.COM_SEARCH_DATE_TYPE.DEFAULT.equals(this.comDateDisabledMonth)) {
            // 日次
            type = CM_A04_Const.DATE_TYPE_NITIJI;
        } else if (CM_A04_Const.COM_SEARCH_DATE_TYPE.DEFAULT.equals(this.comDateDisabledDay)) {
            // 時間別
            type = CM_A04_Const.DATE_TYPE_NITIJI;
        } else {
            // ディフォルト設定がない場合
            type = null;
        }

        if (CM_CommonUtil.isNotNullOrBlank(type)) {
            // ディフォルト設定がない場合、可能なものを選択
            if (!this.comDateDisabledYear.isDisabled()) {
                // 月次
                type = CM_A04_Const.DATE_TYPE_GETUJI;
            } else if (!this.comDateDisabledMonth.isDisabled()) {
                // 日次
                type = CM_A04_Const.DATE_TYPE_NITIJI;
            } else if (!this.comDateDisabledDay.isDisabled()) {
                // 時間別
                type = CM_A04_Const.DATE_TYPE_NITIJI;
            }
        }

        return type;
    }


    /**
     *  帳票レポート用ディフォルトの選択取得.
     *
     * @return ディフォルトの選択
     */
    private String getDefaultDateTypeReportDisp() {
        String type = null;
        if (CM_A04_Const.COM_SEARCH_DATE_TYPE.DEFAULT.equals(this.comDateDisabledMonth)) {
            // 月次
            type = CM_A04_Const.DATE_TYPE_NITIJI;
        } else if (CM_A04_Const.COM_SEARCH_DATE_TYPE.DEFAULT.equals(this.comDateDisabledWeek)) {
            // 週次
            type = CM_A04_Const.DATE_TYPE_SHUJI;
        } else if (CM_A04_Const.COM_SEARCH_DATE_TYPE.DEFAULT.equals(this.comDateDisabledDay)) {
            // 日次
            type = CM_A04_Const.DATE_TYPE_JIKANBETU;
        } else {
            // ディフォルト設定がない場合
            type = null;
        }

        if (CM_CommonUtil.isNotNullOrBlank(type)) {
            // ディフォルト設定がない場合、可能なものを選択
            if (!this.comDateDisabledMonth.isDisabled()) {
                // 月次
                type = CM_A04_Const.DATE_TYPE_NITIJI;
            } else if (!this.comDateDisabledWeek.isDisabled()) {
                // 週次
                type = CM_A04_Const.DATE_TYPE_SHUJI;
            } else if (!this.comDateDisabledDay.isDisabled()) {
                // 日次
                type = CM_A04_Const.DATE_TYPE_JIKANBETU;
            }
        }

        return type;
    }
}
