/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/07/20| <C1.01>　新規作成（共通化対応取込）                                  | C1.01  | US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.service;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.TimeZone;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.form.FW01_17_BaseForm;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.dto.CM_A04_UserRoleDto;
import jp.ysk.mmcloud.common.dto.CM_A05_UserClockDispDto;
import jp.ysk.mmcloud.common.entity.customer.SysEnvEntityNames;
import jp.ysk.mmcloud.common.entity.customer.SysNameEntityNames;
import jp.ysk.mmcloud.common.service.CM_BaseService;
import jp.ysk.mmcloud.visualization.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.common.util.CM_ComparatorByDisplayOrder;
import jp.ysk.mmcloud.common.util.CM_HeaderUtil;
import jp.ysk.mmcloud.common.util.CM_SysEnvDataUtil;
import jp.ysk.mmcloud.common.util.CM_SysNameDataUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseDao;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;

import org.seasar.framework.beans.util.BeanMap;

/**
 *
 * 共通ヘッダサービス.<br>
 *<br>
 * 概要:<br>
 *   共通ヘッダのサービスクラス
 *<br>
 */
public class CM_TopHeaderService extends CM_BaseService  {

    /**
     * 共通ロゴのファイルパス.
     */
    private static final String COMMON_DEFAULT_LOGO_FILE = "/common/img/logo.png";
    /**
     * 共通ロゴのファイルパス.
     */
    private static final String COMMON_LOGO_FILEPATH = "/common/img/";
    /**
     * 共通ロゴのファイル名.
     */
    private static final String COMMON_LOGO_FILENAME = "/logo.png";

    /**
     * ブランクページのファイルパス.
     */
    private static final String COMMON_BLANK_PAGEPATH = "/Blank.html";

    /**
     * 処理中アイコンのファイルパス.
     */
    private static final String COMMON_PROCESSING_ICONPATH = "/gif/loading.gif";

    /**
     *
     * 共通ヘッダに必要な情報を取得し、Jspへの展開用BeanMapを作成.<br>
     *<br>
     * 概要:<br>
     *   共通セッションから共通ヘッダに必要な情報を取得し、Jspへの展開用BeanMapを作成する
     *<br>
     * @param _cM_A03_SessionDto 共通セッション情報
     * @param _formDto フォーム情報
     * @return 共通ヘッダJspへの展開用BeanMapデータ
     */
    public BeanMap getHeaderData(final CM_A03_SessionDto _cM_A03_SessionDto, final CM_BaseForm _formDto) {
        BeanMap beanMap = new BeanMap();

        // ヘッダーの開閉状態を設定
        if (CM_CommonUtil.isNullOrBlank(_formDto.hdnIsHeaderOpened)) {
            beanMap.put(FW01_17_BaseForm.CM_HDN_IS_HEADER_OPENED, "1");
        } else {
            beanMap.put(FW01_17_BaseForm.CM_HDN_IS_HEADER_OPENED, _formDto.hdnIsHeaderOpened);
        }

        // 処理中マスクのブランクページ、処理中アイコンファイルパス
        beanMap.put("strBlankPagePath", COMMON_BLANK_PAGEPATH);
        beanMap.put("strProcessingIconPath", COMMON_PROCESSING_ICONPATH);

        // 環境マスタデータより顧客ロゴファイルパスを取得
        List<BeanMap> envList = CM_SysEnvDataUtil.selectListSysEnv(_cM_A03_SessionDto,
                CM_A04_Const.SYS_ENV_MST_ENV_CD.LOGO_FILEPATH);
        String strCustomerLogoFilepath = FW00_19_Const.EMPTY_STR;
        // 顧客ロゴファイルパスが存在するかチェック
        if (envList != null && envList.size() > 0) {
            BeanMap envMap = envList.get(0);

            if (envMap != null && envMap.containsKey(SysEnvEntityNames.name())
                    && !CM_CommonUtil.isNullOrBlank(envMap.get(SysEnvEntityNames.name()))) {
                strCustomerLogoFilepath = envMap.get(SysEnvEntityNames.name()).toString();
            }
        }

        // ロゴファイルパス
        // 顧客用ロゴファイルパスが存在する場合は、顧客用ロゴをセット
        if (!CM_CommonUtil.isNullOrBlank(strCustomerLogoFilepath)) {
            beanMap.put("strIsCustomerLogo", "1");
            beanMap.put("strLogoFilepath", strCustomerLogoFilepath);
        } else {
            beanMap.put("strIsCustomerLogo", "0");

            // テーマカラーが設定されていない場合はデフォルトロゴを設定
            if (CM_CommonUtil.isNullOrBlank(_cM_A03_SessionDto.ssn_UserThemeColorCD)) {
                beanMap.put("strLogoFilepath", COMMON_DEFAULT_LOGO_FILE);
            } else {
                beanMap.put("strLogoFilepath", COMMON_LOGO_FILEPATH + _cM_A03_SessionDto.ssn_UserThemeColorCD + COMMON_LOGO_FILENAME);
            }
        }

        // 顧客名
        beanMap.put("strCustomerName", _cM_A03_SessionDto.ssn_CustomerName);
        // 所属名取得
        CM_BaseDao dao = new CM_BaseDao(_cM_A03_SessionDto.ssn_ConnectString,
                _cM_A03_SessionDto.ssn_ConnectUserID, _cM_A03_SessionDto.ssn_ConnectPassword);
        String plantCode = dao.getUserPlantCode(_cM_A03_SessionDto.ssn_UserID);
        String belongName = dao.getBelongName(_cM_A03_SessionDto.ssn_UserID, plantCode);
        if (CM_CommonUtil.isNotNullOrBlank(belongName)) {
            beanMap.put("strBelongName", belongName);
        } else {
            beanMap.put("strBelongName", _cM_A03_SessionDto.ssn_CustomerName);
        }
        beanMap.put("strUserName", CM_CommonUtil.getDispUserName(_cM_A03_SessionDto.ssn_UserNameLast,
                _cM_A03_SessionDto.ssn_UserNameFirst));

        // 時計表示モード
        beanMap.put("strClockDisp", _cM_A03_SessionDto.ssn_UserClockDispFlag);

        // 時計情報
        List<BeanMap> lstClockInfoList = new ArrayList<BeanMap>();
        BeanMap clockInfo = null;
        float flUserTimezoneDiffTime = 0;
        float flOtherTimezoneDiffTime = 0;
        String strDiffTemp = null;
        BeanMap sysEnvRet = null;
        Object objCountryFileName = FW00_19_Const.EMPTY_STR;
        float flTemp = 0;
        DecimalFormat df = new DecimalFormat("00");

        CM_A05_UserClockDispDto[] userClockDispDtoList = _cM_A03_SessionDto.ssn_UserClockDispSetting;
        for (int i = 0; i < userClockDispDtoList.length; i++) {
            clockInfo = new BeanMap();
            // 国名
            clockInfo.put("strCountry", userClockDispDtoList[i].ssn_CountryCd);
            // 都市名
            clockInfo.put("strCity", userClockDispDtoList[i].ssn_CityCd);

            // ユーザタイムゾーン用時計の場合
            if (i == 0) {
                flUserTimezoneDiffTime = 0;
                // ユーザタイムゾーンの時差を保持しておく
                Calendar tmpCal = Calendar.getInstance(TimeZone.getTimeZone(userClockDispDtoList[i].ssn_TimezoneCd));
                int zoneoffset = tmpCal.get(Calendar.ZONE_OFFSET);
                flUserTimezoneDiffTime = (float) zoneoffset / FW00_19_Const.MINUTE / FW00_19_Const.SECOND / FW00_19_Const.MILLI;

                // 時差
                clockInfo.put("strDiff", Float.toString(flUserTimezoneDiffTime));
                // 表示用時差 (一つ目の時計は不要)
                clockInfo.put("strDispDiff", FW00_19_Const.EMPTY_STR);

                // ユーザタイムゾーン用時計以外の場合
            } else {
                flOtherTimezoneDiffTime = 0;
                Calendar tmpCal = Calendar.getInstance(TimeZone.getTimeZone(userClockDispDtoList[i].ssn_TimezoneCd));
                int zoneoffset = tmpCal.get(Calendar.ZONE_OFFSET);
                flOtherTimezoneDiffTime = (float) zoneoffset / FW00_19_Const.MINUTE / FW00_19_Const.SECOND / FW00_19_Const.MILLI;

                // 時差
                clockInfo.put("strDiff", Float.toString(flOtherTimezoneDiffTime));

                // 表示用時差
                // 分表示用に負の値は正の値へ
                flTemp = flOtherTimezoneDiffTime - flUserTimezoneDiffTime;
                if (flTemp < 0) {
                    flTemp = flTemp * -1;
                }

                strDiffTemp = df.format(flOtherTimezoneDiffTime - flUserTimezoneDiffTime)
                        + FW00_19_Const.COLON_STR + df.format((flTemp * FW00_19_Const.MINUTE) % FW00_19_Const.MINUTE);
                clockInfo.put("strDispDiff", strDiffTemp);
            }

            // 国旗アイコンのファイルパス
            // 国コードからファイル名取得
            sysEnvRet = CM_SysEnvDataUtil.selectSysEnv(_cM_A03_SessionDto,
                    CM_A04_Const.SYS_ENV_MST_ENV_CD.COUNTRY_FLAG, userClockDispDtoList[i].ssn_CountryCd);
            objCountryFileName = null;
            if (sysEnvRet != null) {
                objCountryFileName = sysEnvRet.get(SysEnvEntityNames.name().toString());
            }

            // 国旗アイコンファイル名が取得できた場合、ファイルパス登録
            if (!CM_CommonUtil.isNullOrBlank(objCountryFileName)) {
                clockInfo.put("strFlagFilepath", CM_A04_Const.COUNTRY_FLAG_FILE_HEADER + objCountryFileName.toString());
            } else {
                clockInfo.put("strFlagFilepath", CM_A04_Const.COUNTRY_FLAG_FILE_HEADER + CM_A04_Const.COUNTRY_FLAG_BLANK_FILE_NAME);
            }

            lstClockInfoList.add(clockInfo);
        }

        // 時計情報
        beanMap.put("lstClockInfoList", lstClockInfoList);

        // メニュー情報
        // ホーム画面のURLセット
        beanMap.put("homeUrl", CM_A04_Const.HOME_URL);

        List<BeanMap> lstMenuInfoList = new ArrayList<BeanMap>();
        String strTargetFuncId = FW00_19_Const.EMPTY_STR;
        BeanMap menuInfo = new BeanMap();
        List<BeanMap> lstSubMenuInfoList = new ArrayList<BeanMap>();
        BeanMap subMenuInfo = null;
        BeanMap nameInfo = null;
        String strName = FW00_19_Const.EMPTY_STR;

        CM_A04_UserRoleDto[] userRoleDtoList = _cM_A03_SessionDto.ssn_UserRoleSetting;
        for (int i = 0; i < userRoleDtoList.length; i++) {

            strTargetFuncId = userRoleDtoList[i].ssn_FunctionCd;
            // 機能ID
            menuInfo.put("strFuncId", strTargetFuncId);
            // 名称マスタから機能名称情報を取得
            nameInfo = CM_SysNameDataUtil.getName(_cM_A03_SessionDto,
                    CM_A04_Const.SYS_NAME_MST_NAME_TYPE.FUNCTION_CD,
                    strTargetFuncId,
                    _cM_A03_SessionDto.ssn_UserLangCD);
            strName = FW00_19_Const.EMPTY_STR;
            if (nameInfo != null && !CM_CommonUtil.isNullOrBlank(nameInfo.get(SysNameEntityNames.name1()))) {
                strName = nameInfo.get(SysNameEntityNames.name1()).toString();
            }
            // 機能名称
            menuInfo.put("strFuncName", strName);

            // 表示順（ヘッダメニューの順番）
            String strDisplayOrder = FW00_19_Const.EMPTY_STR;
            if (nameInfo != null && !CM_CommonUtil.isNullOrBlank(nameInfo.get(SysNameEntityNames.displayOrder()))) {
                strDisplayOrder = nameInfo.get(SysNameEntityNames.displayOrder()).toString();
            }
            menuInfo.put("displayOrder", strDisplayOrder);

            // ログインユーザがユーザの場合、以下のメニューは表示しない
            // 役割一覧(A50-0040)・情報、トレンドビュー一覧・情報(A50-0200)、システム設定、グループ一覧・情報、お知らせ情報、一覧
            List<String> disablePageList = CM_CommonUtil.getDisableDisplayPageList(_cM_A03_SessionDto);
            if ((!CM_CommonUtil.isNullOrBlank(userRoleDtoList[i].ssn_PageId))
                    && (disablePageList.contains(userRoleDtoList[i].ssn_PageId))) {

                // 最後のデータまたは次のレコードの機能IDが変わっている場合は機能単位のリストに追加
                if (i == userRoleDtoList.length - 1 || !strTargetFuncId.equals(userRoleDtoList[i + 1].ssn_FunctionCd)) {

                    // 機能配下に追加された画面メニューが存在しない場合は、機能は追加対象外
                    if (lstSubMenuInfoList.size() > 0) {
                        // 表示順でソート
                        Collections.sort(lstSubMenuInfoList, new CM_ComparatorByDisplayOrder());
                        menuInfo.put("lstDispIdList", lstSubMenuInfoList);
                        lstMenuInfoList.add(menuInfo);
                    }

                    menuInfo = new BeanMap();
                    lstSubMenuInfoList = new ArrayList<BeanMap>();

                    continue;

                } else  {
                    continue;
                }
            }

            // 参照不可権限以下のメニューは表示対象外
            if (!CM_CommonUtil.isNullOrBlank(userRoleDtoList[i].ssn_AuthSetting)
                    && !userRoleDtoList[i].ssn_AuthSetting.equals(CM_A04_Const.ROLE_AUTH_KIND.NONE)) {
                // 画面メニュー情報を取得
                subMenuInfo = CM_HeaderUtil.getMenuInfo(_cM_A03_SessionDto, userRoleDtoList[i].ssn_PageId);

                if (subMenuInfo != null) {
                    subMenuInfo.put("strAuthSetting", userRoleDtoList[i].ssn_AuthSetting);

                    // 名称マスタから機能名称情報を取得
                    BeanMap pageInfo = CM_SysNameDataUtil.getName(_cM_A03_SessionDto,
                            CM_A04_Const.SYS_NAME_MST_NAME_TYPE.PAGE_ID,
                            userRoleDtoList[i].ssn_PageId,
                            _cM_A03_SessionDto.ssn_UserLangCD);

                    subMenuInfo.put("displayOrder", pageInfo.get(SysNameEntityNames.displayOrder()));

                    lstSubMenuInfoList.add(subMenuInfo);
                }
            }

            // 最後のデータまたは次のレコードの機能IDが変わっている場合は機能単位のリストに追加
            if (i == userRoleDtoList.length - 1 || !strTargetFuncId.equals(userRoleDtoList[i + 1].ssn_FunctionCd)) {

                // 機能配下に追加された画面メニューが存在しない場合は、機能は追加対象外
                if (lstSubMenuInfoList.size() > 0) {
                    // 表示順でソート
                    Collections.sort(lstSubMenuInfoList, new CM_ComparatorByDisplayOrder());
                    menuInfo.put("lstDispIdList", lstSubMenuInfoList);
                    lstMenuInfoList.add(menuInfo);
                }

                menuInfo = new BeanMap();
                lstSubMenuInfoList = new ArrayList<BeanMap>();
            }
        }

        if (lstMenuInfoList.size() > 0) {
            // 共通メニューの表示順でソート
            Collections.sort(lstMenuInfoList, new CM_ComparatorByDisplayOrder());
        }

        // メニュー情報
        beanMap.put("lstMenuInfoList", lstMenuInfoList);

        return beanMap;
    }

}
