package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ステーション間滞留情報
 * 
 */
@Entity
@Table(name = "tr_st_tm_info")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class TrStTmInfoEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 登録日時 */
    @Column(nullable = true, unique = false)
    public Timestamp createdOn;

    /** 登録者 */
    @Column(length = 32, nullable = true, unique = false)
    public String createdBy;

    /** 更新日時 */
    @Column(nullable = true, unique = false)
    public Timestamp modifiedOn;

    /** 更新者 */
    @Column(length = 32, nullable = true, unique = false)
    public String modifiedBy;

    /** 指図番号 */
    @Id
    @Column(length = 12, nullable = false, unique = false)
    public String sasizuNo;

    /** 指図追番 */
    @Id
    @Column(precision = 5, nullable = false, unique = false)
    public BigDecimal subNo;

    /** 作業順序 */
    @Id
    @Column(length = 6, nullable = false, unique = false)
    public String sagyoSeq;

    /** リペア処理回数 */
    @Id
    @Column(precision = 2, nullable = false, unique = false)
    public BigDecimal repairKaisu;

    /** ステーションID */
    @Id
    @Column(precision = 8, nullable = false, unique = false)
    public BigDecimal stId;

    /** プラントコード */
    @Column(length = 10, nullable = true, unique = false)
    public String plantCd;

    /** 製造ラインコード */
    @Column(length = 10, nullable = true, unique = false)
    public String seizouLnCd;

    /** 製造ライン名 */
    @Column(length = 64, nullable = true, unique = false)
    public String seizouLnNm;

    /** 工程コード */
    @Column(length = 5, nullable = true, unique = false)
    public String processCd;

    /** 工程名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String processNm;

    /** ラインNo */
    @Column(length = 32, nullable = true, unique = false)
    public String lnNo;

    /** ライン名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String lnNm;

    /** ステーションNo */
    @Column(length = 8, nullable = true, unique = false)
    public String stNo;

    /** ステーション名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String stNm;

    /** 作業区 */
    @Column(length = 8, nullable = true, unique = false)
    public String sagyoku;

    /** 作業終了日時 */
    @Id
    @Column(nullable = false, unique = false)
    public Timestamp endTime;

    /** 作業終了STEP番号 */
    @Column(length = 8, nullable = true, unique = false)
    public String endStepNo;

    /** 作業結果（合否判定） */
    @Column(precision = 2, nullable = true, unique = false)
    public BigDecimal hantei;

    /** 異常コード（不良モード） */
    @Column(length = 3, nullable = true, unique = false)
    public String alarmMode;

    /** 作業状態 */
    @Column(precision = 2, nullable = true, unique = false)
    public BigDecimal sagyoJyotai;

    /** ST作業結果 */
    @Column(precision = 2, nullable = true, unique = false)
    public BigDecimal sagyoKeka;

    /** 次作業開始日時 */
    @Column(nullable = true, unique = false)
    public Timestamp NStartTime;

    /** 次製造ラインコード */
    @Column(length = 10, nullable = true, unique = false)
    public String NSeizouLnCd;

    /** 次製造ライン名 */
    @Column(length = 64, nullable = true, unique = false)
    public String NSeizouLnNm;

    /** 次工程コード */
    @Column(length = 5, nullable = true, unique = false)
    public String NProcessCd;

    /** 次工程名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String NProcessNm;

    /** 次ラインNo */
    @Column(length = 32, nullable = true, unique = false)
    public String NLnNo;

    /** 次ライン名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String NLnNm;

    /** 次ステーションID */
    @Column(precision = 8, nullable = true, unique = false)
    public BigDecimal NStId;

    /** 次ステーションNo */
    @Column(length = 8, nullable = true, unique = false)
    public String NStNo;

    /** 次ステーション名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String NStNm;

    /** 次作業区 */
    @Column(length = 8, nullable = true, unique = false)
    public String NSagyoku;

    /** 滞留時間(msec） */
    @Column(precision = 11, nullable = true, unique = false)
    public BigDecimal stopTime;

    /** 停止時間を除く滞留時間(msec） */
    @Column(precision = 11, nullable = true, unique = false)
    public BigDecimal stopTime2;

    /** 次ライン作業順序 */
    @Column(length = 6, nullable = true, unique = false)
    public String NSagyoSeq;

    /** 送信フラグ */
    @Column(precision = 1, nullable = true, unique = false)
    public BigDecimal sousinFlag;

    /** 送信日時 */
    @Column(nullable = true, unique = false)
    public Timestamp sousinDate;

    /** 数字予備1 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum1;

    /** 数字予備2 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum2;

    /** 数字予備3 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum3;

    /** 文字予備1 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText1;

    /** 文字予備2 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText2;

    /** 文字予備3 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText3;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
