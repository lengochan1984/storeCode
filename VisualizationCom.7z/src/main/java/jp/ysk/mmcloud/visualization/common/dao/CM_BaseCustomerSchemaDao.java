/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/02/22| 新規作成                           | 1.00.00| YSK)植山
 *  2016/03/05| <40000-028> 変更仕様No.28          | 4.00.00| US)萩尾
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.dao;

import java.util.List;

import javax.transaction.TransactionManager;

import jp.ysk.fw.FW00_12_AppException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.dto.CM_CustomerDbAccessDto;
import jp.ysk.mmcloud.common.entity.customer.MstMailTemplateEntity;
import jp.ysk.mmcloud.common.entity.customer.MstMailTemplateEntityNames;
import jp.ysk.mmcloud.common.entity.customer.SysEnvEntity;
import jp.ysk.mmcloud.common.entity.customer.SysEnvEntityNames;
import jp.ysk.mmcloud.visualization.common.util.CM_CustomerDbAccessManager;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;

import org.seasar.extension.jdbc.JdbcManager;
import org.seasar.extension.jdbc.where.SimpleWhere;

/**
 * 顧客スキーマ用共通Dao.<br>
 *<br>
 * 概要:<br>
 *   顧客スキーマのDBにアクセスするための共通Daoクラス
 *<br>
 */
public abstract class CM_BaseCustomerSchemaDao {

    /**
     * JDBCマネージャー(顧客スキーマ).
     */
    protected JdbcManager jdbcManager;

    /**
     * トランザクション(顧客スキーマ).
     */
    protected TransactionManager transactionMng;

    /**
     * コンストラクタ.
     */
    public CM_BaseCustomerSchemaDao() {
    }

    /**
     * SQLファイルパス.
     */
    public static final String SQL_PATH = "jp/ysk/mmcloud/visualization/business/sql/";

    /**
     * SQLファイルパス(共通).
     */
    public static final String SQL_PATH_COMM = "jp/ysk/mmcloud/visualization/common/sql/";

    /**
     *
     * コンストラクタ.<br>
     *<br>
     * @param _strConnectString 顧客DB接続情報
     * @param _strConnectUserName 顧客DBユーザ名
     * @param _strConnectPasswd 顧客DBパスワード
     * @param _queryTimeout クエリタイムアウト値
     */
    public CM_BaseCustomerSchemaDao(
            final String _strConnectString,
            final String _strConnectUserName,
            final String _strConnectPasswd,
            final int _queryTimeout) {

        CM_CustomerDbAccessDto customerDbAccess = CM_CustomerDbAccessManager.getCutomerDbAccess(
                _strConnectString,
                _strConnectUserName,
                _strConnectPasswd,
                _queryTimeout);

        this.jdbcManager = customerDbAccess.jdbcManager;
        this.transactionMng = customerDbAccess.userTransactionMng;

    }

    /**
     *
     * 初期化.<br>
     *<br>
     * 概要:<br>
     *   初期化処理を実行する
     *<br>
     * @param _strConnectString 顧客DB接続情報
     * @param _strConnectUserId 顧客DBユーザID
     * @param _strConnectPasswd 顧客DBパスワード
     * @param _queryTimeout クエリタイムアウト値
     */
    public void setCustomerDbInfo(final String _strConnectString,
            final String _strConnectUserId,
            final String _strConnectPasswd,
            final int _queryTimeout) {

        CM_CustomerDbAccessDto customerDbAccess = CM_CustomerDbAccessManager.getCutomerDbAccess(
                _strConnectString,
                _strConnectUserId,
                _strConnectPasswd,
                _queryTimeout);

        this.jdbcManager = customerDbAccess.jdbcManager;
        this.transactionMng = customerDbAccess.userTransactionMng;

    }

    /**
     *
     * 顧客DBトランザクション開始処理.<br>
     *<br>
     * 概要:<br>
     *   顧客DBトランザクション開始処理を実行する
     *<br>
     */
    public void biginTransaction() {

        try {
            this.transactionMng.begin();

        } catch (Exception ex) {
            CM_LoggerUtil.outputErrorLog(null, ex);
            throw new FW00_12_AppException(FW00_19_Const.EMPTY_STR);
        }
    }

    /**
     *
     * 顧客DBトランザクションコミット処理.<br>
     *<br>
     * 概要:<br>
     *   顧客DBトランザクションコミット処理を実行する
     *<br>
     */
    public void commitTransaction() {

        try {
            this.transactionMng.commit();

        } catch (Exception ex) {
            CM_LoggerUtil.outputErrorLog(null, ex);
            throw new FW00_12_AppException(FW00_19_Const.EMPTY_STR);
        }
    }

    /**
     *
     * 顧客DBトランザクションロールバック処理.<br>
     *<br>
     * 概要:<br>
     *   顧客DBトランザクションロールバック処理を実行する
     *<br>
     */
    public void rollbackTransaction() {

        try {
            this.transactionMng.rollback();

        } catch (Exception ex) {
            CM_LoggerUtil.outputErrorLog(null, ex);
            throw new FW00_12_AppException(FW00_19_Const.EMPTY_STR);
        }
    }

    /**
     * 環境マスタ取得.
     *
     * @param _envCd 環境CD
     * @param _itemCd 項目CD
     * @return 環境マスタ
     */
    public SysEnvEntity getSysEnvEntity(final String _envCd, final String _itemCd) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_envCd", _envCd);
        CM_LoggerUtil.outputDaoInputParamLog("_itemCd", _itemCd);
        SysEnvEntity ret = this.jdbcManager.from(SysEnvEntity.class).where(new SimpleWhere().eq(SysEnvEntityNames.envCd(), _envCd)
                .eq(SysEnvEntityNames.itemCd(), _itemCd)).getSingleResult();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);
        return ret;
    }

    /**
     * 環境マスタ更新処理.
     *
     * @param _sysEnvEntity 環境マスタ
     */
    public void updateSysEnvEntity(final SysEnvEntity _sysEnvEntity) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_sysEnvEntity", _sysEnvEntity);
        long ret = this.jdbcManager.update(_sysEnvEntity).execute();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);
    }

    /**
     * メールテンプレートを取得.<br>
     * <br>
     * 概要:＜br＞ メールテンプレートを取得
     *
     * @param _alarmKind アラーム種別
     * @param _mailType メールタイプ
     * @return メールテンプレート
     */
    public List<MstMailTemplateEntity> getMailTemplateEntity(final String _alarmKind, final String _mailType) {
        List<MstMailTemplateEntity> ret = this.jdbcManager
                .from(MstMailTemplateEntity.class)
                .where(new SimpleWhere()
                        .eq(MstMailTemplateEntityNames.alarmKind(), _alarmKind)
                        .eq(MstMailTemplateEntityNames.type(), _mailType))
                .getResultList();

        return ret;
    }

}
