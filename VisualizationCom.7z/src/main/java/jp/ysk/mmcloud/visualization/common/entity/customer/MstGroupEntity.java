package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * グループマスタ
 * 
 */
@Entity
@Table(name = "mst_group")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class MstGroupEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** グループID : グループIDは4桁連番の0埋め文字列とする。 */
    @Id
    @Column(length = 4, nullable = false, unique = true)
    public String groupId;

    /** グループ名称 : グループの名称 */
    @Column(length = 256, nullable = false, unique = false)
    public String groupName;

    /** 名称項目CD : ★使用禁止（多言語対応時に利用予定）
グループ名称の名称コード
名称マスタの名称種別="group_name"とリンク。 */
    @Column(length = 64, nullable = true, unique = false)
    public String nameItemCd;

    /** treePathプロパティ */
    @Column(length = 2147483647, nullable = false, unique = false)
    public String treePath;

    /** 位置情報 : 機器や設置場所の位置。緯度経度で示されるもの。
保存形式：DEG形式を緯度、経度の順で半角スペース連結
小数点以下は６ケタまでで切り捨て
緯度は北半球が正の値、南半球が負の値
経度は東経が正の値、西経が負の値
例）41°25'01"N and 120°58'57"Wの場合、DBには"42.416944 -120.9875"で保存する。 */
    @Column(length = 32, nullable = true, unique = false)
    public String positionInfo;

    /** 住所 : グループの所在地住所 */
    @Column(length = 512, nullable = true, unique = false)
    public String address;

    /** タイムゾーンCD : タイムゾーンを保持。
環境マスタの環境CD="timezone"とリンク。 */
    @Column(length = 64, nullable = false, unique = false)
    public String timezoneCd;

    /** 表示順 : データポイントコードの表示順 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer displayOrder;

    /** 削除フラグ : true：有効、false：無効 */
    @Column(length = 1, nullable = false, unique = false)
    public Boolean deleteFlag;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
