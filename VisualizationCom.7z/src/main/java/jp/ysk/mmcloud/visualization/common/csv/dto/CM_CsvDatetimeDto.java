/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/03| <C1.01>　新規作成                                                    | C1.01  | (US)楢崎
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.csv.dto;

/**
 * CSV出力用日時データ.<br>
 *<br>
 * 概要:<br>
 *   CSV出力用日時データ
 *<br>
 */
public class CM_CsvDatetimeDto {

    /**
     * CSVファイル名用日時.
     */
    private String fileNameDateStr;

    /**
     * CSVヘッダ出力用日時.
     */
    private String headerDateStr;

    /**
     * @return fileNameDateStr
     */
    public String getFileNameDateStr() {
        return this.fileNameDateStr;
    }

    /**
     * @param _fileNameDateStr セットする fileNameDateStr
     */
    public void setFileNameDateStr(final String _fileNameDateStr) {
        this.fileNameDateStr = _fileNameDateStr;
    }

    /**
     * @return headerDateStr
     */
    public String getHeaderDateStr() {
        return this.headerDateStr;
    }

    /**
     * @param _headerDateStr セットする headerDateStr
     */
    public void setHeaderDateStr(final String _headerDateStr) {
        this.headerDateStr = _headerDateStr;
    }
}
