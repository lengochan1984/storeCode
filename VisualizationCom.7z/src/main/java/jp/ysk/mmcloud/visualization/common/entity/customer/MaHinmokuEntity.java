package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 品目マスタ
 * 
 */
@Entity
@Table(name = "ma_hinmoku")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class MaHinmokuEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 登録日時 */
    @Column(nullable = true, unique = false)
    public Timestamp createdOn;

    /** 登録者 */
    @Column(length = 32, nullable = true, unique = false)
    public String createdBy;

    /** 更新日時 */
    @Column(nullable = true, unique = false)
    public Timestamp modifiedOn;

    /** 更新者 */
    @Column(length = 32, nullable = true, unique = false)
    public String modifiedBy;

    /** 無効フラグ */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer invalidFlag;

    /** 品目コード */
    @Id
    @Column(length = 40, nullable = false, unique = false)
    public String matnr;

    /** 産業コード */
    @Column(length = 1, nullable = true, unique = false)
    public String mbrsh;

    /** 品目タイプ */
    @Column(length = 4, nullable = true, unique = false)
    public String mtart;

    /** プラントコード */
    @Id
    @Column(length = 10, nullable = false, unique = false)
    public String werks;

    /** 旧品目コード */
    @Column(length = 40, nullable = true, unique = false)
    public String bismt;

    /** 研究室設計室 */
    @Column(length = 3, nullable = true, unique = false)
    public String labor;

    /** 品目階層 */
    @Column(length = 18, nullable = true, unique = false)
    public String prdha;

    /** 共通品目ＳＴＡ */
    @Column(length = 2, nullable = true, unique = false)
    public String mstae;

    /** 有効開始日 */
    @Column(length = 8, nullable = true, unique = false)
    public String mstde;

    /** 一般明細カテゴリ */
    @Column(length = 4, nullable = true, unique = false)
    public String mtposMara;

    /** 製造検査メモ */
    @Column(length = 18, nullable = true, unique = false)
    public String ferth;

    /** 標準テキスト */
    @Column(length = 18, nullable = true, unique = false)
    public String normt;

    /** 文書 */
    @Column(length = 22, nullable = true, unique = false)
    public String zeinr;

    /** 文書タイプ */
    @Column(length = 3, nullable = true, unique = false)
    public String zeiar;

    /** 文書バージョン */
    @Column(length = 2, nullable = true, unique = false)
    public String zeivr;

    /** 文書変更番号 */
    @Column(length = 6, nullable = true, unique = false)
    public String aeszn;

    /** 文書枚数 */
    @Column(precision = 3, nullable = true, unique = false)
    public BigDecimal blanz;

    /** 基本数量単位 */
    @Column(length = 3, nullable = true, unique = false)
    public String meins;

    /** 品目グループ */
    @Column(length = 9, nullable = true, unique = false)
    public String matkl;

    /** 質量単位 */
    @Column(length = 3, nullable = true, unique = false)
    public String gewei;

    /** 輸送グループ */
    @Column(length = 4, nullable = true, unique = false)
    public String tragr;

    /** カタログプロファイル */
    @Column(length = 9, nullable = true, unique = false)
    public String rbnrm;

    /** 製品部門 */
    @Column(length = 2, nullable = true, unique = false)
    public String spart;

    /** 主構成物質 */
    @Column(length = 48, nullable = true, unique = false)
    public String wrkst;

    /** 出荷プラント */
    @Column(length = 4, nullable = true, unique = false)
    public String dwerk;

    /** 現金値引区分 */
    @Column(length = 1, nullable = true, unique = false)
    public String sktof;

    /** 品目統計グループ */
    @Column(length = 1, nullable = true, unique = false)
    public String versg;

    /** 品目価格設定グループ */
    @Column(length = 2, nullable = true, unique = false)
    public String kondm;

    /** 明細カテゴリグループ */
    @Column(length = 4, nullable = true, unique = false)
    public String mtpos;

    /** 販売品目階層 */
    @Column(length = 18, nullable = true, unique = false)
    public String prodh;

    /** 販売品目グループ１ */
    @Column(length = 3, nullable = true, unique = false)
    public String mvgr1;

    /** 販売品目グループ２ */
    @Column(length = 3, nullable = true, unique = false)
    public String mvgr2;

    /** 利用可能在庫確認グループ */
    @Column(length = 2, nullable = true, unique = false)
    public String mtvfp;

    /** 積載グループ */
    @Column(length = 4, nullable = true, unique = false)
    public String ladgr;

    /** 利益センタ */
    @Column(length = 10, nullable = true, unique = false)
    public String prctr;

    /** 特有品目ＳＴＡ */
    @Column(length = 2, nullable = true, unique = false)
    public String mmsta;

    /** ＭＲＰタイプ */
    @Column(length = 2, nullable = true, unique = false)
    public String dismm;

    /** ＭＲＰ管理者 */
    @Column(length = 3, nullable = true, unique = false)
    public String dispo;

    /** ロットサイズ */
    @Column(length = 2, nullable = true, unique = false)
    public String disls;

    /** 調達タイプ */
    @Column(length = 1, nullable = true, unique = false)
    public String beskz;

    /** 特殊調達タイプ */
    @Column(length = 2, nullable = true, unique = false)
    public String sobsl;

    /** 内製日数 */
    @Column(precision = 3, nullable = true, unique = false)
    public BigDecimal dzeit;

    /** 日程計画余裕キー */
    @Column(length = 3, nullable = true, unique = false)
    public String fhori;

    /** 安全在庫 */
    @Column(precision = 13, scale = 3, nullable = true, unique = false)
    public BigDecimal eisbe;

    /** 期間区分 */
    @Column(length = 1, nullable = true, unique = false)
    public String perkz;

    /** 計画方針グループ */
    @Column(length = 2, nullable = true, unique = false)
    public String strgr;

    /** 消費モード */
    @Column(length = 1, nullable = true, unique = false)
    public String vrmod;

    /** 逆消費期間 */
    @Column(precision = 3, nullable = true, unique = false)
    public BigDecimal vint1;

    /** 順消費期間 */
    @Column(precision = 3, nullable = true, unique = false)
    public BigDecimal vint2;

    /** 補充リードタイム合計 */
    @Column(precision = 3, nullable = true, unique = false)
    public BigDecimal wzeit;

    /** 個別一括所要量 */
    @Column(length = 1, nullable = true, unique = false)
    public String sbdkz;

    /** 製造計画担当 */
    @Column(length = 3, nullable = true, unique = false)
    public String fevor;

    /** 製造計画プロファイル */
    @Column(length = 6, nullable = true, unique = false)
    public String sfcpf;

    /** 原価計算ロットサイズ */
    @Column(precision = 13, scale = 3, nullable = true, unique = false)
    public BigDecimal losgr;

    /** 購買グループ */
    @Column(length = 3, nullable = true, unique = false)
    public String ekgrp;

    /** 自動購買発注 */
    @Column(length = 1, nullable = true, unique = false)
    public String kautb;

    /** 入庫処理日数 */
    @Column(precision = 3, nullable = true, unique = false)
    public BigDecimal webaz;

    /** 供給元一覧 */
    @Column(length = 1, nullable = true, unique = false)
    public String kordb;

    /** 供給量割当使用 */
    @Column(length = 1, nullable = true, unique = false)
    public String usequ;

    /** 輸出輸入グループ */
    @Column(length = 4, nullable = true, unique = false)
    public String mtver;

    /** ＭＲＰグループ */
    @Column(length = 4, nullable = true, unique = false)
    public String disgr;

    /** ＡＢＣ区分 */
    @Column(length = 1, nullable = true, unique = false)
    public String maabc;

    /** 発注点 */
    @Column(precision = 13, scale = 3, nullable = true, unique = false)
    public BigDecimal minbe;

    /** 計画周期 */
    @Column(length = 3, nullable = true, unique = false)
    public String lfrhy;

    /** 計画タイムフェンス */
    @Column(precision = 3, nullable = true, unique = false)
    public BigDecimal fxhor;

    /** 最小ロットサイズ */
    @Column(precision = 13, scale = 3, nullable = true, unique = false)
    public BigDecimal bstmi;

    /** 最大ロットサイズ */
    @Column(precision = 13, scale = 3, nullable = true, unique = false)
    public BigDecimal bstma;

    /** 固定ロットサイズ */
    @Column(precision = 13, scale = 3, nullable = true, unique = false)
    public BigDecimal bstfe;

    /** 丸めプロファイル */
    @Column(length = 4, nullable = true, unique = false)
    public String rdprf;

    /** 丸め数量 */
    @Column(precision = 13, scale = 3, nullable = true, unique = false)
    public BigDecimal bstrf;

    /** 納入予定日数 */
    @Column(precision = 3, nullable = true, unique = false)
    public BigDecimal plifz;

    /** ＪＩＴ納入日程 */
    @Column(length = 1, nullable = true, unique = false)
    public String fabkz;

    /** 出庫保管場所 */
    @Column(length = 4, nullable = true, unique = false)
    public String lgpro;

    /** 外部調達保管場所 */
    @Column(length = 4, nullable = true, unique = false)
    public String lgfsb;

    /** 在庫決定 */
    @Column(length = 4, nullable = true, unique = false)
    public String eprio;

    /** 二重ＭＲＰ区分 */
    @Column(length = 1, nullable = true, unique = false)
    public String miskz;

    /** 構成品不良 */
    @Column(precision = 5, scale = 2, nullable = true, unique = false)
    public BigDecimal kausf;

    /** 日程品目グループ */
    @Column(length = 20, nullable = true, unique = false)
    public String matgr;

    /** ＱＭ品目権限 */
    @Column(length = 6, nullable = true, unique = false)
    public String qmata;

    /** 品目税分類 */
    @Column(length = 1, nullable = true, unique = false)
    public String taxm1;

    /** 出荷国 */
    @Column(length = 3, nullable = true, unique = false)
    public String aland;

    /** 品目テキスト */
    @Column(length = 40, nullable = true, unique = false)
    public String maktx;

    /** 改訂レベル */
    @Column(length = 2, nullable = true, unique = false)
    public String revlv;

    /** 保管条件 */
    @Column(length = 2, nullable = true, unique = false)
    public String raube;

    /** 発注単位 */
    @Column(length = 3, nullable = true, unique = false)
    public String bstme;

    /** 過剰納入無制限 */
    @Column(length = 1, nullable = true, unique = false)
    public String ueetk;

    /** サービスレベル */
    @Column(precision = 3, scale = 1, nullable = true, unique = false)
    public BigDecimal lgrad;

    /** バルク区分 */
    @Column(length = 1, nullable = true, unique = false)
    public String schgt;

    /** ｸﾗｲｱﾝﾄﾚﾍﾞﾙの削除 */
    @Column(length = 1, nullable = true, unique = false)
    public String lvorm1;

    /** ﾌﾟﾗﾝﾄﾚﾍﾞﾙの削除 */
    @Column(length = 1, nullable = true, unique = false)
    public String lvorm2;

    /** 販売テキスト */
    @Column(length = 132, nullable = true, unique = false)
    public String tdline;

    /** 品目階層TEXT_その1 */
    @Column(length = 40, nullable = true, unique = false)
    public String vtextInfo1;

    /** 品目階層TEXT_その2 */
    @Column(length = 40, nullable = true, unique = false)
    public String vtextInfo2;

    /** EANコード */
    @Column(length = 18, nullable = true, unique = false)
    public String eanCode;

    /** 原産国 */
    @Column(length = 3, nullable = true, unique = false)
    public String gensankoku;

    /** 原産国名 */
    @Column(length = 50, nullable = true, unique = false)
    public String gensankokuNm;

    /** ERP変更日時 */
    @Column(nullable = true, unique = false)
    public Timestamp erpHenkoDate;

    /** 数字予備1 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum1;

    /** 数字予備2 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum2;

    /** 数字予備3 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum3;

    /** 文字予備1 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText1;

    /** 文字予備2 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText2;

    /** 文字予備3 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText3;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
