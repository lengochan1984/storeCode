package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * [サイネージ用]製品生産計画実績(月別)
 * 
 */
@Entity
@Table(name = "ds_product_mng_monthly")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class DsProductMngMonthlyEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** プラントコード */
    @Id
    @Column(length = 10, nullable = false, unique = false)
    public String plantCd;

    /** 品目コード */
    @Id
    @Column(length = 40, nullable = false, unique = false)
    public String buhinCd;

    /** データ日時 */
    @Id
    @Column(nullable = false, unique = false)
    public Timestamp dataDate;

    /** 品目階層TEXT_その1 */
    @Id
    @Column(length = 40, nullable = false, unique = false)
    public String vtextInfo1;

    /** 品目階層TEXT_その2 */
    @Id
    @Column(length = 40, nullable = false, unique = false)
    public String vtextInfo2;

    /** 更新日時 */
    @Column(nullable = true, unique = false)
    public Timestamp updDate;

    /** 計画台数 */
    @Column(precision = 19, nullable = true, unique = false)
    public Long planNum;

    /** 実績台数 */
    @Column(precision = 19, nullable = true, unique = false)
    public Long actualNum;

    /** 計画金額 */
    @Column(precision = 19, nullable = true, unique = false)
    public Long planValue;

    /** 実績金額 */
    @Column(precision = 19, nullable = true, unique = false)
    public Long actualValue;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
