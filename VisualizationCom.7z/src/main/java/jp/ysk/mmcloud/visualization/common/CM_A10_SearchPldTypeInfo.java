/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/12/08| <C1.01>　新規作成                                                    | C1.01  | (US)甲斐
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common;

/**
 * 共通検索機能 プルダウン種別情報.
 */
public class CM_A10_SearchPldTypeInfo {
    /** 工場プルダウン種別. */
    public CM_A04_Const.COM_SEARCH_PLD_TYPE comPlantCdType;
    /** 製造ラインプルダウン種別. */
    public CM_A04_Const.COM_SEARCH_PLD_TYPE comSeizouLnIdType;
    /** 工程プルダウン種別. */
    public CM_A04_Const.COM_SEARCH_PLD_TYPE comProcessIdType;
    /** ラインプルダウン種別. */
    public CM_A04_Const.COM_SEARCH_PLD_TYPE comLnIdType;
    /** STプルダウン種別. */
    public CM_A04_Const.COM_SEARCH_PLD_TYPE comStIdType;
}
