package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * [サイネージ用]品目別リードタイムデータ(日別)
 * 
 */
@Entity
@Table(name = "ds_lead_time_hinmoku_daily")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class DsLeadTimeHinmokuDailyEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** プラントコード */
    @Id
    @Column(length = 10, nullable = false, unique = false)
    public String plantCd;

    /** 指図番号 */
    @Id
    @Column(length = 12, nullable = false, unique = false)
    public String sasizuNo;

    /** 指図追番 */
    @Id
    @Column(precision = 5, nullable = false, unique = false)
    public BigDecimal subNo;

    /** 品目コード */
    @Id
    @Column(length = 40, nullable = false, unique = false)
    public String buhinCd;

    /** データ日時 */
    @Id
    @Column(nullable = false, unique = false)
    public Timestamp dataDate;

    /** リードタイム */
    @Column(precision = 19, nullable = true, unique = false)
    public Long leadTime;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
