/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2005 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+=============================================+========+==============
 *  DATE      | Comments                     　　　　　　   | Rev    | SIGN
 * ===========+=============================================+========+==============
 *  2015/04/22| 新規作成　<30003-006> 故障苦情No.30002-006  | 3.01.00| US)萩尾
 *  2015/06/25| <30003-035> 変更仕様No.13                   | 3.01.00| US)楢崎
 *  2015/07/08| <30003-037> 変更仕様No.23                   | 3.01.00| US)楢崎
 *  2015/07/16| <30003-042> 故障苦情No.30003-035            | 3.01.00| US)楢崎
 *  2015/08/07| <30003-057> Ver3.01.00 IT障害No.2-25        | 3.01.00| US)萩尾
 *  2015/08/18| <30003-061> 変更仕様No.34                   | 3.01.00| US)萩尾
 *  2015/08/27| <30003-066> 故障苦情No.30003-077            | 3.01.00| US)萩尾
 *  2015/12/22| <40000-025> 変更仕様No.25                   | 4.00.00| US)萩尾
 *  2015/01/04| <40000-021> Ver.4.00.00 変更仕様No.21       | 4.00.00| US)楢崎
 *  2016/01/18| <40000-028> Ver.4.00.00 変更仕様No.28       | 4.00.00| US)甲斐
 *  2016/01/28| <40000-028> 変更仕様No.28   　　　          | 4.00.00| US)安永
 *  2016/07/20| <C1.01> 共通化対応取込                      | C1.01  | US)萩尾
 *  2016/08/03| <C1.01> 指図一覧対応                        | C1.01  | US)楢崎
 *  2016/08/11| <C1.01> 不具合分析対応                      | C1.01  | US)楢崎
 *  2016/08/12| <C1.01> 不具合一覧対応                      | C1.01  | US)甲斐
 * -----------+---------------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.util.CM_DisplayCharResourceUtil;
import jp.ysk.mmcloud.common.util.CM_MessageResourceUtil;

/**
 * メッセージ関連ユーティリティ処理.<br>
 *<br>
 * 概要:<br>
 *  メッセージ関連のユーティリティクラス<br>
 *  CM_MessageResourceUtilとCM_DisplayCharResourceUtilを同じメソッド内で使用する共通メソッドや<br>
 *  固定のメッセージIDを取得する共通メソッドなどを実装する。
 *<br>
 */
public class CM_MessageUtil {

    /**
     *
     * コンストラクタ.
     *
     */
    protected CM_MessageUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     *
     * 禁則文字エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   禁則文字使用時のエラーメッセージを取得する
     *<br>
     * @param _sessionDto セッション情報
     * @param _param 置換メッセージID
     * @param _forbidChar 禁則文字
     * @return 禁則文字エラーメッセージ
     */
    public static String getForibidCharErrorMessage(final CM_A03_SessionDto _sessionDto, final String _param, final String _forbidChar) {
        List<String> paramList = CM_DisplayCharResourceUtil.getDisplayCharValue(_sessionDto, _param);
        paramList.add(_forbidChar);

        return getForibidCharErrorMessage(_sessionDto, paramList);
    }

    /**
     *
     * 禁則文字エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   禁則文字使用時のエラーメッセージを取得する
     *<br>
     * @param _sessionDto セッション情報
     * @param _paramList 置換文字列
     * @return 禁則文字エラーメッセージ
     */
    public static String getForibidCharErrorMessage(final CM_A03_SessionDto _sessionDto, final List<String> _paramList) {
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_081", _paramList);
    }

    /**
     *
     * 禁則文字エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   禁則文字使用時のエラーメッセージを取得する
     *<br>
     * @param _sessionDto セッション情報
     * @param _param 置換文字列
     * @param _forbidChar 禁則文字
     * @return 禁則文字エラーメッセージ
     */
    public static String getForibidCharErrorMessageByItemName(final CM_A03_SessionDto _sessionDto, final String _param, final String _forbidChar) {
        // 置換用の文字列リストを作成
        List<String> paramList = new ArrayList<String>();
        paramList.add(_param);
        paramList.add(_forbidChar);

        return getForibidCharErrorMessage(_sessionDto, paramList);
    }

    /**
     *
     * メッセージの取得処理（置換処理あり）.<br>
     *<br>
     * 概要:<br>
     *   指定したセッション情報、メッセージIDに対するメッセージを取得し指定した文言で置換する
     *<br>
     * @param _sessionDto セッション情報
     * @param _strMsgID メッセージID(MessageResourceeのメッセージIDのみ）
     * @param _param 置換メッセージID(DisplayCharResourceのメッセージIDのみ）
     * @return メッセージ文字列
     */
    public static String getMessageValueParam(final CM_A03_SessionDto _sessionDto, final String _strMsgID, final String... _param) {
        List<String> param = CM_DisplayCharResourceUtil.getDisplayCharValue(_sessionDto, _param);

        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, _strMsgID, param);
    }

    /**
     *
     * 必須エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   必須エラーメッセージを取得する
     *<br>
     * @param _sessionDto セッション情報
     * @param _param 置換メッセージID
     * @return 必須エラーメッセージ
     */
    public static String getEmptyErrorMessage(final CM_A03_SessionDto _sessionDto, final String _param) {
        List<String> param = CM_DisplayCharResourceUtil.getDisplayCharValue(_sessionDto, _param);

        return getEmptyErrorMessage(_sessionDto, param);
    }

    /**
     *
     * 必須エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   必須エラーメッセージを取得する
     *<br>
     * @param _sessionDto セッション情報
     * @param _param 置換文字列
     * @return 必須エラーメッセージ
     */
    public static String getEmptyErrorMessage(final CM_A03_SessionDto _sessionDto, final List<String> _param) {
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_051", _param);
    }

    /**
     *
     * 桁数上限エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   桁数上限エラーメッセージを取得する
     *<br>
     * @param _sessionDto セッション情報
     * @param _itemName 項目名
     * @param _maxLength 桁数上限値
     * @return 必須エラーメッセージ
     */
    public static String getLengthUpperErrorMessage(final CM_A03_SessionDto _sessionDto, final String _itemName, final int _maxLength) {
        // 置換用の文字列リストを作成
        List<String> param = new ArrayList<String>();
        param.add(_itemName);
        param.add(String.valueOf(_maxLength));

        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_062", param);
    }

    /**
     *
     * 削除フラグ不正エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   削除フラグ不正エラーメッセージを取得する
     *<br>
     * @param _sessionDto セッション情報
     * @return 削除フラグ不正エラーメッセージ
     */
    public static String getDeleteFlagErrorMessage(final CM_A03_SessionDto _sessionDto) {

        return getIncorrectValueMessage(_sessionDto, "MMCDCA000080_005");
    }

    /**
     *
     * 不正エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   不正エラーメッセージを取得する
     *<br>
     * @param _sessionDto セッション情報
     * @param _param 置換メッセージID(DisplayCharResourceのメッセージIDのみ）
     * @return 不正エラーメッセージ
     */
    public static String getIncorrectValueMessage(final CM_A03_SessionDto _sessionDto, final String _param) {

        return getMessageValueParam(_sessionDto, "MMCMCM00000_035", _param);
    }

    /**
     *
     * 「選択された{0}は使用できません。」メッセージ取得.<br>
     *<br>
     * 概要:<br>
     *  「選択された{0}は使用できません。」を取得する<br>
     *  _paramの値で{0}を置換する
     *
     *<br>
     * @param _sessionDto セッション情報
     * @param _param 置換メッセージID(DisplayCharResourceのメッセージIDのみ）
     * @return 選択された{0}は使用できません。
     */
    public static String getUnusableValueMessage(final CM_A03_SessionDto _sessionDto, final String _param) {
        List<String> param = new ArrayList<String>();
        param.add(_param);
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_082", param);
    }

    /**
     *
     * 選択されたグループが使用できないメッセージを取得.<br>
     *<br>
     * 概要:<br>
     *   選択されたグループが使用できないメッセージ(メッセージID：MMCMCM00000_083)を取得<br>
     *
     *<br>
     * @param _sessionDto セッション情報
     * @return 選択されたグループが使用できないメッセージ
     */
    public static String getUnusableGroupMessage(final CM_A03_SessionDto _sessionDto) {
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_083", new ArrayList<String>());
    }

    /**
     *
     * マスタにデータが存在しないかデータが削除されているエラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   マスタにデータが存在しないかデータが削除されているエラーメッセージ(メッセージID：MMCMCM00000_031）を取得
     *<br>
     * @param _sessionDto セッション情報
     * @param _param 置換メッセージID(DisplayCharResourceのメッセージIDのみ）
     * @return マスタにデータが存在しないかデータが削除されているエラーメッセージ
     */
    public static String getNotExistDataMessage(final CM_A03_SessionDto _sessionDto, final List<String> _param) {
        return getMessageValueParam(_sessionDto, "MMCMCM00000_031", _param.toArray(new String[_param.size()]));
    }

    /**
     *
     * データポイントがアラーム条件等に使用され、保存するから保存しないに変更しようとした場合のメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   データポイントがアラーム条件等に使用され、保存するから保存しないに変更しようとした場合のメッセージ取得
     *<br>
     * @param _sessionDto セッション情報
     * @param _param 使用されている場所のメッセージID(DisplayCharResourceのメッセージIDのみ）
     * @return  データポイントがアラーム条件等に使用され、保存するから保存しないに変更しようとした場合のメッセージ(メッセージID：MMCMCM00000_084)
     */
    public static String getUsableDataPointSaveKindErrorMassage(final CM_A03_SessionDto _sessionDto, final String _param) {

        return getMessageValueParam(_sessionDto, "MMCMCM00000_084", _param);
    }

    /**
     *
     * ユーザ情報を更新できないメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   ユーザ情報を更新できないメッセージ取得
     *<br>
     * @param _sessionDto セッション情報
     * @return ユーザ情報を更新できないメッセージ
     */
    public static String getEnableUpdateUserInfoMessage(final CM_A03_SessionDto _sessionDto) {
        return CM_MessageResourceUtil.getMessageValue(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, "MMCMCM00000_085");
    }

    /**
     *
     * ユーザ情報を削除できないメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   ユーザ情報を削除できないメッセージ取得
     *<br>
     * @param _sessionDto セッション情報
     * @return ユーザ情報を削除できないメッセージ(メッセージID：MMCMCM00000_086)
     */
    public static String getEnableDeleteUserInfoMessage(final CM_A03_SessionDto _sessionDto) {
        return CM_MessageResourceUtil.getMessageValue(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, "MMCMCM00000_086");
    }

    /**
     *
     * ユーザ権限が使用できないエラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   指定したユーザ権限が使用できないエラーメッセージを取得
     *<br>
     * @param _sessionDto セッション情報
     * @return ユーザ権限が使用できないエラーメッセージ(メッセージID：MMCMCM00000_087)
     */
    public static String getUnusableUserAuthorityErrorMessage(final CM_A03_SessionDto _sessionDto) {
        return CM_MessageResourceUtil.getMessageValue(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, "MMCMCM00000_087");
    }

    /**
     *
     * 削除済データか存在しないデータエラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   既に削除済データか存在しないデータのエラーメッセージ取得
     *<br>
     * @param _sessionDto セッション情報
     * @return 削除済データか存在しないデータエラーメッセージ(メッセージID：MMCMCM00000_073)
     */
    public static String getNotExistOrRemovedDataErrorMessage(final CM_A03_SessionDto _sessionDto) {
        return CM_MessageResourceUtil.getMessageValue(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, "MMCMCM00000_073");
    }

    /**
     *
     * CSVコンバート処理時のワーニングメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   CSVコンバート処理実施時に出力するワーニングメッセージ取得
     *<br>
     * @param _sessionDto セッション情報
     * @return CSVコンバート処理時のワーニングメッセージ(メッセージID：MMCMCM00000_045)
     */
    public static String getCsvConvertWarningMessage(final CM_A03_SessionDto _sessionDto) {
        return CM_MessageResourceUtil.getMessageValue(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, "MMCMCM00000_045");
    }

    /**
     *
     * 計測日時コードに未定義または削除済のデータポイントコード設定エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   計測日時コードに未定義または削除済のデータポイントコード設定エラーメッセージを取得
     *<br>
     * @param _sessionDto セッション情報
     * @return 計測日時コードに未定義または削除済のデータポイントコード設定エラーメッセージ(メッセージID：MMCMCM00000_088)
     */
    public static String getSetMeasurementDataPointErrorMessage(final CM_A03_SessionDto _sessionDto) {
        return CM_MessageResourceUtil.getMessageValue(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, "MMCMCM00000_088");
    }

    /**
     * 関連データ件数メッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   削除時、関連データ件数を取得件数メッセージを取得
     *<br>
     *
     * @param _sessionDto セッション情報
     * @param _relatedInfoNameMsgId 関連データメッセージID（DisplayCharResourceのメッセージIDのみ）
     * @param _dataCnt 件数
     * @return 関連データ件数を取得件数メッセージ(メッセージID：MMCMCM00000_090)
     */
    public static String getRelatedDataCntMessage(final CM_A03_SessionDto _sessionDto, final String _relatedInfoNameMsgId, final Long _dataCnt) {
        List<String> param = CM_DisplayCharResourceUtil.getDisplayCharValue(_sessionDto, _relatedInfoNameMsgId);
        param.add(_dataCnt.toString());
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_090", param) + FW00_19_Const.SPACE;
    }

    /**
     * 関連データ件数メッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   削除時、関連データ件数を取得件数メッセージを取得
     *<br>
     *
     * @param _sessionDto セッション情報
     * @param _relatedInfo 関連データ件数情報
     * @return 関連データ件数を取得件数メッセージ(メッセージID：MMCMCM00000_093)
     */
    public static String getDeleteConfirmMessage(final CM_A03_SessionDto _sessionDto, final String _relatedInfo) {
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_093", _relatedInfo);
    }

    /**
     * 関連付け削除エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   削除時、関連付けがあるため削除出来ないメッセージを取得
     *<br>
     *
     * @param _sessionDto セッション情報
     * @param _relatedInfoNameMsg 関連データメッセージ
     * @return 関連付け削除エラーメッセージ(メッセージID：MMCMCM00000_048)
     */
    public static String getDeleteRelatedErrorMessage(final CM_A03_SessionDto _sessionDto, final String _relatedInfoNameMsg) {
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_048", _relatedInfoNameMsg);
    }

    /**
     * 関連付け削除エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   削除時、他のテーブルと関連付けがあるため削除出来ないメッセージを取得
     *<br>
     *
     * @param _sessionDto セッション情報
     * @param _relatedInfoNameMsg 関連データメッセージ
     * @return 関連付け削除エラーメッセージ(メッセージID：MMCMCM00000_049)
     */
    public static String getCanNotDeleteMessage(final CM_A03_SessionDto _sessionDto, final String _relatedInfoNameMsg) {
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_049", _relatedInfoNameMsg);
    }

    /**
     * 関連付け削除警告メッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   削除時、関連付けがあるため削除するかを問うメッセージを取得
     *<br>
     *
     * @param _sessionDto セッション情報
     * @param _relatedTableName 関連テーブル
     * @return 関連付け削除エラーメッセージ(メッセージID：MMCMCM00000_047)
     */
    public static String getAskDeleteMessage(final CM_A03_SessionDto _sessionDto, final String _relatedTableName) {
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_047", _relatedTableName);
    }

    /**
     *
     * 不正な数値エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   不正な数値エラーメッセージを取得
     *<br>
     * @param _sessionDto セッション情報
     * @param _param 項目のメッセージID(DisplayCharResourceのメッセージIDのみ）
     * @return 不正な数値エラーメッセージ(メッセージID：MMCMCM00000_053)
     */
    public static String getInvalidNumericValueMessage(final CM_A03_SessionDto _sessionDto, final String _param) {

        return getMessageValueParam(_sessionDto, "MMCMCM00000_053", _param);
    }

    /**
     *
     * マスタに存在しないエラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   マスタに存在しないエラーメッセージを取得
     *<br>
     * @param _sessionDto セッション情報
     * @param _param 項目のメッセージID(DisplayCharResourceのメッセージIDのみ）
     * @return マスタに存在しないエラーメッセージ(メッセージID：MMCMCM00000_028)
     */
    public static String getMstNotExistMessage(final CM_A03_SessionDto _sessionDto, final String _param) {

        return getMessageValueParam(_sessionDto, "MMCMCM00000_028", _param);
    }

    /**
     *
     * 地図アクセス上限エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   地図アクセス上限エラーメッセージを取得
     *<br>
     * @param _sessionDto セッション情報
     * @return 地図アクセス上限エラーメッセージ(メッセージID：MMCMCM00000_301)
     */
    public static String getOverMapAccessMessage(final CM_A03_SessionDto _sessionDto) {
        // 置換用の文字列リストを作成
        List<String> param = new ArrayList<String>();
        param.add(String.valueOf(_sessionDto.ssn_PvCount));

        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_301", param);
    }

   /**
    *
    * ディスク容量上限エラーメッセージ取得.<br>
    *<br>
    * 概要:<br>
    *   登録時のDisk容量上限エラーメッセージを取得
    *<br>
    * @param _sessionDto セッション情報
    * @return Disk容量上限エラーメッセージ(メッセージID：MMCMCM00000_095)
    */
    public static String getOverDiskSpaceMessage(final CM_A03_SessionDto _sessionDto) {

        return CM_MessageResourceUtil.getMessageValue(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, "MMCMCM00000_095");
    }

    /**
    *
    * ディスク容量上限エラーメッセージ取得.<br>
    *<br>
    * 概要:<br>
    *   ファイルアップロード時のDisk容量上限エラーメッセージを取得
    *<br>
    * @param _sessionDto セッション情報
    * @return Disk容量上限エラーメッセージ(メッセージID：MMCMCM00000_096)
    */
    public static String getOverDiskSpaceFileMessage(final CM_A03_SessionDto _sessionDto) {

        return CM_MessageResourceUtil.getMessageValue(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, "MMCMCM00000_096");
    }

    /**
     *
     * 登録失敗エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     * 登録失敗エラーメッセージ取得
     *<br>
     * @param _sessionDto セッション情報
     * @return 登録失敗エラーメッセージ
     */
    public static String getInsertFailedErrorMessage(final CM_A03_SessionDto _sessionDto) {
        return CM_MessageResourceUtil.getMessageValue(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, "MMCMCM00000_007");
    }

    /**
     *
     * 更新失敗エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     * 更新失敗エラーメッセージ取得
     *<br>
     * @param _sessionDto セッション情報
     * @return 登録失敗エラーメッセージ
     */
    public static String getUpdateFailedErrorMessage(final CM_A03_SessionDto _sessionDto) {
        return CM_MessageResourceUtil.getMessageValue(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, "MMCMCM00000_008");
    }

    /**
     *
     * 削除失敗エラーメッセージ取得.<br>
     *<br>
     * 概要:<br>
     * 削除失敗エラーメッセージ取得
     *<br>
     * @param _sessionDto セッション情報
     * @return 登録失敗エラーメッセージ
     */
    public static String getDeleteFailedErrorMessage(final CM_A03_SessionDto _sessionDto) {
        return CM_MessageResourceUtil.getMessageValue(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, "MMCMCM00000_006");
    }

    /**
     *
     * 「○分」のフォーマットの文字列取得.<br>
     *<br>
     * 概要:<br>
     * 「○分」のフォーマットの文字列取得
     *<br>
     * @param _sessionDto セッション情報
     * @param _minute 変換する時間（分単位）
     * @return 「○分」のフォーマットの文字列
     */
    public static String getMinuteStr(final CM_A03_SessionDto _sessionDto, final long _minute) {
        String[] paramArray = new String[]{String.valueOf(_minute)};
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_038", Arrays.asList(paramArray));
    }

    /**
     *
     * 「○日」のフォーマットの文字列取得.<br>
     *<br>
     * 概要:<br>
     * 「○日」のフォーマットの文字列取得
     *<br>
     * @param _sessionDto セッション情報
     * @param _day 変換する時間（日単位）
     * @return 「○日」のフォーマットの文字列
     */
    public static String getDayStr(final CM_A03_SessionDto _sessionDto, final long _day) {
        String[] paramArray = new String[]{String.valueOf(_day)};
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "CMMCMCM00000_004", Arrays.asList(paramArray));
    }

    /**
     *
     * 「○ヶ月」のフォーマットの文字列取得.<br>
     *<br>
     * 概要:<br>
     * 「○ヶ月」のフォーマットの文字列取得
     *<br>
     * @param _sessionDto セッション情報
     * @param _month 変換する時間（月単位）
     * @return 「○ヶ月」のフォーマットの文字列
     */
    public static String getMonthStr(final CM_A03_SessionDto _sessionDto, final long _month) {
        String[] paramArray = new String[]{String.valueOf(_month)};
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "CMMCMCM00000_003", Arrays.asList(paramArray));
    }

    /**
     *
     * 「{0}に不正な日付が入力されています。」メッセージ取得.<br>
     *<br>
     * 概要:<br>
     *  「{0}に不正な日付が入力されています。」を取得する<br>
     *  _paramの値で{0}を置換する
     *
     *<br>
     * @param _sessionDto セッション情報
     * @param _param 置換メッセージID(DisplayCharResourceのメッセージIDのみ）
     * @return 選択された{0}は使用できません。
     */
    public static String getDatetimeFormatErrorMessage(final CM_A03_SessionDto _sessionDto, final String _param) {
        List<String> param = new ArrayList<String>();
        param.add(_param);
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_057", param);
    }

    /**
     *
     * 「{0}に大小関係が不正な日付が入力されています。」メッセージ取得.<br>
     *<br>
     * 概要:<br>
     *  「{0}に大小関係が不正な日付が入力されています。」を取得する<br>
     *  _paramの値で{0}を置換する
     *
     *<br>
     * @param _sessionDto セッション情報
     * @param _param 置換メッセージID(DisplayCharResourceのメッセージIDのみ）
     * @return 選択された{0}は使用できません。
     */
    public static String getDateMagnitudeErrorMessage(final CM_A03_SessionDto _sessionDto, final String _param) {
        List<String> param = new ArrayList<String>();
        param.add(_param);
        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "MMCMCM00000_071", param);
    }

    /**
     *
     * 「検索できる最大の期間（{0}）を超えています。」メッセージ取得.<br>
     *<br>
     * 概要:<br>
     *  「検索できる最大の期間（{0}）を超えています。」を取得する
     *<br>
     * @param _sessionDto セッション情報
     * @param _param 置換メッセージ
     * @return 検索できる最大の期間（{0}）を超えています。
     */
    public static String getDurationErrorMessage(final CM_A03_SessionDto _sessionDto, final String _param) {

        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "CMMCMCM00000_002", _param);
    }

    /**
    *
    * 「MESシステムとの連携異常」メッセージ取得.<br>
    *<br>
    * 概要:<br>
    *  「MESシステムとの連携異常」を取得する
    *<br>
    * @param _sessionDto セッション情報
    * @param _param 置換メッセージ
    * @return MESシステムとの連携異常
    */
    public static String getMESErrorMessage(final CM_A03_SessionDto _sessionDto, final String _param) {

        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "CMMCMCM00000_008", _param);
    }

    /**
    *
    * 「見える化DBとの接続異常」メッセージ取得.<br>
    *<br>
    * 概要:<br>
    *  「見える化DBとの接続異常」を取得する
    *<br>
    * @param _sessionDto セッション情報
    * @param _param 置換メッセージ
    * @return MESシステムとの連携異常
    */
    public static String getMESDBErrorMessage(final CM_A03_SessionDto _sessionDto, final String _param) {

        return CM_MessageResourceUtil.getMessageValueParam(_sessionDto, "CMMCMCM00000_009", _param);
    }

}
