package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link MaEquipAlmCdEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class MaEquipAlmCdEntityNames {

    /**
     * createdOnのプロパティ名を返します。
     * 
     * @return createdOnのプロパティ名
     */
    public static PropertyName<Timestamp> createdOn() {
        return new PropertyName<Timestamp>("createdOn");
    }

    /**
     * createdByのプロパティ名を返します。
     * 
     * @return createdByのプロパティ名
     */
    public static PropertyName<String> createdBy() {
        return new PropertyName<String>("createdBy");
    }

    /**
     * modifiedOnのプロパティ名を返します。
     * 
     * @return modifiedOnのプロパティ名
     */
    public static PropertyName<Timestamp> modifiedOn() {
        return new PropertyName<Timestamp>("modifiedOn");
    }

    /**
     * modifiedByのプロパティ名を返します。
     * 
     * @return modifiedByのプロパティ名
     */
    public static PropertyName<String> modifiedBy() {
        return new PropertyName<String>("modifiedBy");
    }

    /**
     * invalidFlagのプロパティ名を返します。
     * 
     * @return invalidFlagのプロパティ名
     */
    public static PropertyName<Integer> invalidFlag() {
        return new PropertyName<Integer>("invalidFlag");
    }

    /**
     * equipCdのプロパティ名を返します。
     * 
     * @return equipCdのプロパティ名
     */
    public static PropertyName<String> equipCd() {
        return new PropertyName<String>("equipCd");
    }

    /**
     * almCdのプロパティ名を返します。
     * 
     * @return almCdのプロパティ名
     */
    public static PropertyName<String> almCd() {
        return new PropertyName<String>("almCd");
    }

    /**
     * almLevelのプロパティ名を返します。
     * 
     * @return almLevelのプロパティ名
     */
    public static PropertyName<BigDecimal> almLevel() {
        return new PropertyName<BigDecimal>("almLevel");
    }

    /**
     * almMsgのプロパティ名を返します。
     * 
     * @return almMsgのプロパティ名
     */
    public static PropertyName<String> almMsg() {
        return new PropertyName<String>("almMsg");
    }

    /**
     * almDetailのプロパティ名を返します。
     * 
     * @return almDetailのプロパティ名
     */
    public static PropertyName<String> almDetail() {
        return new PropertyName<String>("almDetail");
    }

    /**
     * almGuideのプロパティ名を返します。
     * 
     * @return almGuideのプロパティ名
     */
    public static PropertyName<String> almGuide() {
        return new PropertyName<String>("almGuide");
    }

    /**
     * almClrFlgのプロパティ名を返します。
     * 
     * @return almClrFlgのプロパティ名
     */
    public static PropertyName<BigDecimal> almClrFlg() {
        return new PropertyName<BigDecimal>("almClrFlg");
    }

    /**
     * recoverFlgのプロパティ名を返します。
     * 
     * @return recoverFlgのプロパティ名
     */
    public static PropertyName<BigDecimal> recoverFlg() {
        return new PropertyName<BigDecimal>("recoverFlg");
    }

    /**
     * spareNum1のプロパティ名を返します。
     * 
     * @return spareNum1のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum1() {
        return new PropertyName<BigDecimal>("spareNum1");
    }

    /**
     * spareNum2のプロパティ名を返します。
     * 
     * @return spareNum2のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum2() {
        return new PropertyName<BigDecimal>("spareNum2");
    }

    /**
     * spareNum3のプロパティ名を返します。
     * 
     * @return spareNum3のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum3() {
        return new PropertyName<BigDecimal>("spareNum3");
    }

    /**
     * spareText1のプロパティ名を返します。
     * 
     * @return spareText1のプロパティ名
     */
    public static PropertyName<String> spareText1() {
        return new PropertyName<String>("spareText1");
    }

    /**
     * spareText2のプロパティ名を返します。
     * 
     * @return spareText2のプロパティ名
     */
    public static PropertyName<String> spareText2() {
        return new PropertyName<String>("spareText2");
    }

    /**
     * spareText3のプロパティ名を返します。
     * 
     * @return spareText3のプロパティ名
     */
    public static PropertyName<String> spareText3() {
        return new PropertyName<String>("spareText3");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _MaEquipAlmCdNames extends PropertyName<MaEquipAlmCdEntity> {

        /**
         * インスタンスを構築します。
         */
        public _MaEquipAlmCdNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _MaEquipAlmCdNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _MaEquipAlmCdNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * createdOnのプロパティ名を返します。
         *
         * @return createdOnのプロパティ名
         */
        public PropertyName<Timestamp> createdOn() {
            return new PropertyName<Timestamp>(this, "createdOn");
        }

        /**
         * createdByのプロパティ名を返します。
         *
         * @return createdByのプロパティ名
         */
        public PropertyName<String> createdBy() {
            return new PropertyName<String>(this, "createdBy");
        }

        /**
         * modifiedOnのプロパティ名を返します。
         *
         * @return modifiedOnのプロパティ名
         */
        public PropertyName<Timestamp> modifiedOn() {
            return new PropertyName<Timestamp>(this, "modifiedOn");
        }

        /**
         * modifiedByのプロパティ名を返します。
         *
         * @return modifiedByのプロパティ名
         */
        public PropertyName<String> modifiedBy() {
            return new PropertyName<String>(this, "modifiedBy");
        }

        /**
         * invalidFlagのプロパティ名を返します。
         *
         * @return invalidFlagのプロパティ名
         */
        public PropertyName<Integer> invalidFlag() {
            return new PropertyName<Integer>(this, "invalidFlag");
        }

        /**
         * equipCdのプロパティ名を返します。
         *
         * @return equipCdのプロパティ名
         */
        public PropertyName<String> equipCd() {
            return new PropertyName<String>(this, "equipCd");
        }

        /**
         * almCdのプロパティ名を返します。
         *
         * @return almCdのプロパティ名
         */
        public PropertyName<String> almCd() {
            return new PropertyName<String>(this, "almCd");
        }

        /**
         * almLevelのプロパティ名を返します。
         *
         * @return almLevelのプロパティ名
         */
        public PropertyName<BigDecimal> almLevel() {
            return new PropertyName<BigDecimal>(this, "almLevel");
        }

        /**
         * almMsgのプロパティ名を返します。
         *
         * @return almMsgのプロパティ名
         */
        public PropertyName<String> almMsg() {
            return new PropertyName<String>(this, "almMsg");
        }

        /**
         * almDetailのプロパティ名を返します。
         *
         * @return almDetailのプロパティ名
         */
        public PropertyName<String> almDetail() {
            return new PropertyName<String>(this, "almDetail");
        }

        /**
         * almGuideのプロパティ名を返します。
         *
         * @return almGuideのプロパティ名
         */
        public PropertyName<String> almGuide() {
            return new PropertyName<String>(this, "almGuide");
        }

        /**
         * almClrFlgのプロパティ名を返します。
         *
         * @return almClrFlgのプロパティ名
         */
        public PropertyName<BigDecimal> almClrFlg() {
            return new PropertyName<BigDecimal>(this, "almClrFlg");
        }

        /**
         * recoverFlgのプロパティ名を返します。
         *
         * @return recoverFlgのプロパティ名
         */
        public PropertyName<BigDecimal> recoverFlg() {
            return new PropertyName<BigDecimal>(this, "recoverFlg");
        }

        /**
         * spareNum1のプロパティ名を返します。
         *
         * @return spareNum1のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum1() {
            return new PropertyName<BigDecimal>(this, "spareNum1");
        }

        /**
         * spareNum2のプロパティ名を返します。
         *
         * @return spareNum2のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum2() {
            return new PropertyName<BigDecimal>(this, "spareNum2");
        }

        /**
         * spareNum3のプロパティ名を返します。
         *
         * @return spareNum3のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum3() {
            return new PropertyName<BigDecimal>(this, "spareNum3");
        }

        /**
         * spareText1のプロパティ名を返します。
         *
         * @return spareText1のプロパティ名
         */
        public PropertyName<String> spareText1() {
            return new PropertyName<String>(this, "spareText1");
        }

        /**
         * spareText2のプロパティ名を返します。
         *
         * @return spareText2のプロパティ名
         */
        public PropertyName<String> spareText2() {
            return new PropertyName<String>(this, "spareText2");
        }

        /**
         * spareText3のプロパティ名を返します。
         *
         * @return spareText3のプロパティ名
         */
        public PropertyName<String> spareText3() {
            return new PropertyName<String>(this, "spareText3");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
