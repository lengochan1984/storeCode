package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 製品生産計画実績(月別)
 * 
 */
@Entity
@Table(name = "ag_product_mng_monthly")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class AgProductMngMonthlyEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 製造ラインID */
    @Id
    @Column(precision = 8, nullable = false, unique = false)
    public BigDecimal seizouLnId;

    /** ラインID */
    @Id
    @Column(precision = 8, nullable = false, unique = false)
    public BigDecimal lnId;

    /** ステーションID */
    @Id
    @Column(precision = 8, nullable = false, unique = false)
    public BigDecimal stId;

    /** 品目コード */
    @Id
    @Column(length = 40, nullable = false, unique = false)
    public String buhinCd;

    /** データ日時 */
    @Id
    @Column(nullable = false, unique = false)
    public Timestamp dataDate;

    /** 品目階層TEXT_その1 */
    @Id
    @Column(length = 40, nullable = false, unique = false)
    public String vtextInfo1;

    /** 品目階層TEXT_その2 */
    @Column(length = 40, nullable = true, unique = false)
    public String vtextInfo2;

    /** プラントコード */
    @Column(length = 10, nullable = true, unique = false)
    public String plantCd;

    /** 製造ラインコード */
    @Column(length = 10, nullable = true, unique = false)
    public String seizouLnCd;

    /** 製造ライン名 */
    @Column(length = 64, nullable = true, unique = false)
    public String seizouLnNm;

    /** 工程コード */
    @Column(length = 5, nullable = true, unique = false)
    public String processCd;

    /** 工程名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String processNm;

    /** ラインNo */
    @Column(length = 32, nullable = true, unique = false)
    public String lnNo;

    /** ライン名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String lnNm;

    /** ステーションNo */
    @Column(length = 8, nullable = true, unique = false)
    public String stNo;

    /** ステーション名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String stNm;

    /** 更新日時 */
    @Column(nullable = true, unique = false)
    public Timestamp updDate;

    /** 計画(当日)台数 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer planTheDayNum;

    /** 計画(前日)台数 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer planBeforeTheDayNum;

    /** 計画(前々日)台数 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer planBeforeTwoDaysNum;

    /** 実績(当日)台数 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer actualTheDayNum;

    /** 計画(当日)金額 */
    @Column(precision = 19, nullable = false, unique = false)
    public Long planTheDayValue;

    /** 計画(前日)金額 */
    @Column(precision = 19, nullable = false, unique = false)
    public Long planBeforeTheDayValue;

    /** 計画(前々日)金額 */
    @Column(precision = 19, nullable = false, unique = false)
    public Long planBeforeTwoDaysValue;

    /** 実績(当日)金額 */
    @Column(precision = 19, nullable = false, unique = false)
    public Long actualTheDayValue;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
