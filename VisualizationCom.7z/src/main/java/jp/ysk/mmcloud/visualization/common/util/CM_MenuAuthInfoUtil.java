/*
 * ************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ************************************************************************************
 * ===========+================================================+========+==============
 *  DATE      | Comments                                       | Rev    | SIGN
 * ===========+================================================+========+==============
 *  2014/05/02| 新規作成                                       | 1.00.00| YSK)中田
 *  2014/12/19| <20000-025> 変更仕様一覧No.17                  | 3.00.00| YSK)森山
 *  2015/01/22| <20000-042> 役割用データ作成時の不要ループ回避 | 3.00.00| YSK)中田
 *  2015/06/23| <30003-034> 変更仕様No.1                       | 3.01.00| YSK)千田
 *  2015/07/08| <30003-037> 変更仕様No.23                      | 3.01.00| US)萩尾
 * -----------+------------------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.dto.CM_A04_UserRoleDto;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.common.util.CM_ComparatorByDisplayOrder;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.common.util.CM_SysNameDataUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.CM_A05_PageInfo;
import jp.ysk.mmcloud.visualization.common.dao.CM_GetMenuAuthInfoDao;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaMenuItemsEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaSettingMenuItemsEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.SysNameEntityNames;

import org.seasar.framework.beans.util.BeanMap;

/**
 * 役割・権限取得用ユーティリティ.<br>
 *<br>
 * 概要:<br>
 *<br>
 */
public class CM_MenuAuthInfoUtil {

//    /**
//     * [MAPキー]機能一覧.
//     */
//    public static final String MAPKEY_FUNCTION_ITEM_LIST = "functionItemList";
//
//    /**
//     * [MAPキー]機能CD名称.
//     */
//    public static final String MAPKEY_FUNCTION_CD_NAME = "functionCdName";
//
//    /**
//     * [MAPキー]ページID名称.
//     */
//    public static final String MAPKEY_PAGE_ID_NAME = "pageIdName";
//
//    /**
//     * [MAPキー]システム管理者のみ表示可能.
//     */
//    public static final String MAPKEY_ENABLE_ONLY_SYS_ADMIN = "enableOnlySysAdmin";
//
    /**
     * 機能CDの文字列位置.
     */
    public static final int FUNC_CD_POS = 3;


    /**
     *
     * コンストラクタ.
     *
     */
    protected CM_MenuAuthInfoUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     * 画面権限情報取得.<br>
     *<br>
     * 概要:<br>
     *   画面権限情報を取得しセッションに設定する
     *<br>
     * @param _sessionDto セッション
     * @param _plantCode 工場コード
     */
    public static void loadSessionPageAuthInfo(final CM_A03_SessionDto _sessionDto, final String _plantCode) {
        _sessionDto.ssn_UserRoleSetting
            = getSessionPageAuthInfo(_sessionDto, _sessionDto.ssn_AuthorityCode, _sessionDto.ssn_UserLangCD, _plantCode);
    }

    /**
     * 画面権限情報取得.<br>
     *<br>
     * 概要:<br>
     *   画面権限情報を取得する
     *<br>
     * @param _sessionDto セッション
     * @param _authorityCode 権限コード
     * @param _userLangCD 言語コード
     * @param _plantCode 工場コード
     * @return 画面権限情報
     */
    public static CM_A04_UserRoleDto[] getSessionPageAuthInfo(
            final CM_A03_SessionDto _sessionDto, final String _authorityCode, final String _userLangCD, final String _plantCode) {
        CM_A04_UserRoleDto[] resList = null;

        try {
            CM_GetMenuAuthInfoDao clsCM_GetMenuAuthInfoDao = new CM_GetMenuAuthInfoDao(_sessionDto.ssn_ConnectString,
                    _sessionDto.ssn_ConnectUserID,
                    _sessionDto.ssn_ConnectPassword);

            // ファンクションの並び順取得
            Map<String, Integer> fuctionDispOrderMap = new HashMap<String, Integer>();
            List<BeanMap> functionCdList = CM_SysNameDataUtil.getNameList(_sessionDto,
                    CM_A04_Const.SYS_NAME_MST_NAME_TYPE.FUNCTION_CD, _userLangCD);
            for (BeanMap functionCdDef : functionCdList) {
                String functionCd = (String) functionCdDef.get(SysNameEntityNames.itemCd().toString());
                Integer displayOrder = (Integer) functionCdDef.get(SysNameEntityNames.displayOrder().toString());
                fuctionDispOrderMap.put(functionCd, displayOrder);
            }

            // 指定された工場コードの権限リストを取得
            List<BeanMap> mapList = clsCM_GetMenuAuthInfoDao.selectMenuAuthInfo(_plantCode);
            if (CM_CommonUtil.isNullOrEmpty(mapList)) {
                // 取得できない場合、工場コードは指定せずに再取得
                mapList = clsCM_GetMenuAuthInfoDao.selectMenuAuthInfo(null);
            }

            // 指定された工場コードの設定権限リストを取得
            List<BeanMap> settingList = clsCM_GetMenuAuthInfoDao.selectSettingAuthInfo(_plantCode, _authorityCode);
            if (CM_CommonUtil.isNullOrEmpty(settingList)) {
                // 取得できない場合、工場コードは指定せずに再取得
                settingList = clsCM_GetMenuAuthInfoDao.selectSettingAuthInfo(null, _authorityCode);
            }

            // メニュー構成権限追加
            List<BeanMap> menuList = new ArrayList<BeanMap>();
            Map<String, BeanMap> menuMap = new HashMap<String, BeanMap>();
            String setteinFunctinCd = CM_A05_PageInfo.PAGE_ID_MENU_CONSTITUTION.getFunctionCd();
            String menuConstitutionPageId = CM_A05_PageInfo.PAGE_ID_MENU_CONSTITUTION.getPageId();
            int menuConstitutionIndex = 0;
            String functionCdBuf = FW00_19_Const.EMPTY_STR;
            for (BeanMap menuSetting : mapList) {
                String functionCd = (String) menuSetting.get(MaMenuItemsEntityNames.functionCd().toString());
                String pageId = (String) menuSetting.get(MaMenuItemsEntityNames.pageId().toString());
                // 並び順設定
                Integer displayOrder = fuctionDispOrderMap.get(functionCd);
                if (CM_CommonUtil.isNullOrBlank(displayOrder)) {
                    // 並び順が設定されていない場合
                    displayOrder = Integer.MAX_VALUE;
                }
                menuSetting.put(SysNameEntityNames.displayOrder().toString(), displayOrder);

                // メニューリストの作成
                menuList.add(menuSetting);
                menuMap.put(pageId, menuSetting);
            }

            for (BeanMap menuSetting : settingList) {
                String functionCd = (String) menuSetting.get(MaSettingMenuItemsEntityNames.functionCd().toString());
                String pageId = (String) menuSetting.get(MaSettingMenuItemsEntityNames.pageId().toString());
                Integer enableFlag = (Integer) menuSetting.get(MaSettingMenuItemsEntityNames.enableFlag().toString());
                // 並び順設定
                Integer displayOrder = fuctionDispOrderMap.get(functionCd);
                if (CM_CommonUtil.isNullOrBlank(displayOrder)) {
                    // 並び順が設定されていない場合
                    displayOrder = Integer.MAX_VALUE;
                }
                menuSetting.put(SysNameEntityNames.displayOrder().toString(), displayOrder);

                // メニューリストの作成
                BeanMap menuItemInfo = menuMap.get(pageId);
                if (menuItemInfo != null) {
                    // メニュー項目マスタにデータが有る場合
                    Integer enableDispFlag = (Integer) menuItemInfo.get(MaMenuItemsEntityNames.enableFlag().toString());
                    if (enableDispFlag > enableFlag) {
                        // 小さい権限を優先
                        menuList.add(menuSetting);
                        menuList.remove(menuItemInfo);
                    }
                } else {
                    menuList.add(menuSetting);
                }
            }

            // 表示順でソート
            Collections.sort(menuList, new CM_ComparatorByDisplayOrder());

            // 画面権限情報を共通セッションへ保存
            resList = new CM_A04_UserRoleDto[menuList.size()];
            CM_A04_UserRoleDto userRoleInfo = null;
           for (int index = 0; index < menuList.size(); ++index) {
                BeanMap roleSetting = menuList.get(index);

                userRoleInfo = new CM_A04_UserRoleDto();
                userRoleInfo.ssn_FunctionCd = (String) roleSetting.get(MaMenuItemsEntityNames.functionCd().toString());
                userRoleInfo.ssn_PageId = (String) roleSetting.get(MaMenuItemsEntityNames.pageId().toString());
//                userRoleInfo.ssn_AuthSetting = _authorityCode;
//              userRoleInfo.ssn_AuthSetting = (String) roleSetting.get(MaMenuItemsEntityNames.enableFlag().toString());;
                Integer intAuth = (Integer) roleSetting.get(MaMenuItemsEntityNames.enableFlag());
                userRoleInfo.ssn_AuthSetting = intAuth.toString();
                resList[index] = userRoleInfo;
            }

        } catch (Exception e) {
            // エラーログ出力
            CM_LoggerUtil.outputErrorLog(null, e);
        }

        return resList;
    }
}
