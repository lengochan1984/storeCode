package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link MaSettingMenuItemsEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class MaSettingMenuItemsEntityNames {

    /**
     * plantCdのプロパティ名を返します。
     * 
     * @return plantCdのプロパティ名
     */
    public static PropertyName<String> plantCd() {
        return new PropertyName<String>("plantCd");
    }

    /**
     * roleCdのプロパティ名を返します。
     * 
     * @return roleCdのプロパティ名
     */
    public static PropertyName<Integer> roleCd() {
        return new PropertyName<Integer>("roleCd");
    }

    /**
     * functionCdのプロパティ名を返します。
     * 
     * @return functionCdのプロパティ名
     */
    public static PropertyName<String> functionCd() {
        return new PropertyName<String>("functionCd");
    }

    /**
     * pageIdのプロパティ名を返します。
     * 
     * @return pageIdのプロパティ名
     */
    public static PropertyName<String> pageId() {
        return new PropertyName<String>("pageId");
    }

    /**
     * enableFlagのプロパティ名を返します。
     * 
     * @return enableFlagのプロパティ名
     */
    public static PropertyName<Integer> enableFlag() {
        return new PropertyName<Integer>("enableFlag");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _MaSettingMenuItemsNames extends PropertyName<MaSettingMenuItemsEntity> {

        /**
         * インスタンスを構築します。
         */
        public _MaSettingMenuItemsNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _MaSettingMenuItemsNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _MaSettingMenuItemsNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * plantCdのプロパティ名を返します。
         *
         * @return plantCdのプロパティ名
         */
        public PropertyName<String> plantCd() {
            return new PropertyName<String>(this, "plantCd");
        }

        /**
         * roleCdのプロパティ名を返します。
         *
         * @return roleCdのプロパティ名
         */
        public PropertyName<Integer> roleCd() {
            return new PropertyName<Integer>(this, "roleCd");
        }

        /**
         * functionCdのプロパティ名を返します。
         *
         * @return functionCdのプロパティ名
         */
        public PropertyName<String> functionCd() {
            return new PropertyName<String>(this, "functionCd");
        }

        /**
         * pageIdのプロパティ名を返します。
         *
         * @return pageIdのプロパティ名
         */
        public PropertyName<String> pageId() {
            return new PropertyName<String>(this, "pageId");
        }

        /**
         * enableFlagのプロパティ名を返します。
         *
         * @return enableFlagのプロパティ名
         */
        public PropertyName<Integer> enableFlag() {
            return new PropertyName<Integer>(this, "enableFlag");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
