/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/07/20| <C1.01>　新規作成（共通化対応取込）                                  | C1.01  | US)萩尾
 *  2017/05/23| <C1.01>　23H対応                                                     | C1.01  | YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.dao;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.dao.CM_BaseCustomerSchemaDao;
import jp.ysk.mmcloud.common.entity.customer.MstUserEntityNames;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.CM_A11_SearchDateTypeInfo;
import jp.ysk.mmcloud.visualization.common.action.CM_A01_BaseAction;
import jp.ysk.mmcloud.visualization.common.dto.AndongInfoDto;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantMierukaEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantMierukaEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaUserEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSearchConditionEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSearchConditionEntityNames;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;
import jp.ysk.mmcloud.visualization.common.util.CM_CommonUtil;

import org.seasar.extension.jdbc.OrderByItem;
import org.seasar.extension.jdbc.OrderByItem.OrderingSpec;
import org.seasar.extension.jdbc.where.SimpleWhere;
import org.seasar.framework.beans.util.BeanMap;

/**
 * 画面共通Dao.<br>
 *<br>
 * 概要:<br>
 *   顧客スキーマのDBにアクセスするための画面共通Daoクラス
 *<br>
 */
public class CM_BaseDao extends CM_BaseCustomerSchemaDao {

    /**
     * SQLファイルパス.
     */
    public static final String BASE_SQL_PATH = "jp/ysk/mmcloud/visualization/business/sql/";

    /**
     * SQLファイルパス.<br>
     * jp/ysk/mmcloud/visualization/common/sql/
     */
    public static final String BASE_SQL_PATH_COMM = "jp/ysk/mmcloud/visualization/common/sql/";

    /**
     * コンストラクタ.
     */
    public CM_BaseDao() {
        super();
    }

    /**
     *
     * コンストラクタ.<br>
     *<br>
     * @param _strConnectString 顧客DB接続情報
     * @param _strConnectUserName 顧客DBユーザ名
     * @param _strConnectPasswd 顧客DBパスワード
     */
    public CM_BaseDao(
            final String _strConnectString,
            final String _strConnectUserName,
            final String _strConnectPasswd) {

        super(_strConnectString, _strConnectUserName, _strConnectPasswd);
    }

    /**
     *
     * ユーザ工場コード取得.<br>
     *<br>
     * 概要:<br>
     *   作業者マスタからログインユーザのIDを元に工場コードを取得する
     *<br>
     * @param _userId ユーザID
     * @return 工場コード
     */
    public String getUserPlantCode(final String _userId) {

        CM_LoggerUtil.outputDaoInputParamLog("_userId", _userId);

        BeanMap param = new BeanMap();
        param.put(MstUserEntityNames.id().toString(), _userId);

        // TODO 暫定SQL実装
        String ret = this.jdbcManager.selectBySqlFile(String.class,
                BASE_SQL_PATH_COMM + "selectUserPlantCode.sql", param).getSingleResult();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * 所属名取得.<br>
     *<br>
     * 概要:<br>
     *   作業者マスタからログインユーザのIDを元に所属名を取得する
     *<br>
     * @param _userId ユーザID
     * @param _plantCode 工場コード
     * @return 所属名
     */
    public String getBelongName(final String _userId, final String _plantCode) {

        CM_LoggerUtil.outputDaoInputParamLog("_userId", _userId);
        CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);

        BeanMap param = new BeanMap();
        param.put(MstUserEntityNames.id().toString(), _userId);
        param.put(MaUserEntityNames.plantCd().toString(), _plantCode);

        String ret = this.jdbcManager.selectBySqlFile(String.class,
                BASE_SQL_PATH_COMM + "selectBelongName.sql", param).getSingleResult();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * 集計開始時刻を取得.<br>
     *<br>
     * 概要:<br>
     *  集計開始時刻を取得
     *<br>
     * @param _plantCode 工場コード
     * @return 集計開始時刻(単位：分）
     */
    public Integer getRunningStartTime(final String _plantCode) {
        CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);

        SimpleWhere where = new SimpleWhere();
        where.eq(MaPlantEntityNames.plantCd().toString(), _plantCode);

        MaPlantEntity plantEntity = this.jdbcManager.from(MaPlantEntity.class).where(where).getSingleResult();

        Calendar cal = Calendar.getInstance();
        if (plantEntity != null) {
            cal.setTimeInMillis(plantEntity.runningStartDatetime.getTime());
        } else {
            cal.setTime(CM_CommonUtil.fromString(CM_A04_Const.DEFAULT_RUNNING_START_DATETIME, CM_A04_Const.DATE_FORMAT_SEC_HYPHEN));
        }
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);

        int ret = hour * FW00_19_Const.MINUTE + minute;

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * 時差をずらすためのintervalの値を取得.<br>
     *<br>
     * 概要:<br>
     *   時差をずらすため
     *   サーバタイムゾーンとログインユーザのタイムゾーンの時差を算出し、
     *   intervalのフィールド値付与してを返却する
     *<br>
     * @param _userTimezone ユーザタイムゾーン
     * @return interval値
     */
    public String getIntervalZoneOffset(final String _userTimezone) {

        int offset = CM_CommonUtil.getZoneOffset(_userTimezone);
        String offsetStr = offset + CM_A04_Const.SQL_INTERVAL_FIELD.SECOND;
        return offsetStr;
    }

    /**
     *
     * 工場マスタ情報取得.<br>
     *<br>
     * 概要:<br>
     *   工場マスタ情報取得
     *<br>
     * @param _plantCode 工場コード
     * @return 工場マスタ情報
     */
    public MaPlantEntity getMstPlant(final String _plantCode) {
        CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);

        SimpleWhere where = new SimpleWhere();
        where.eq(MaPlantEntityNames.plantCd().toString(), _plantCode);

        MaPlantEntity ret = this.jdbcManager.from(MaPlantEntity.class).where(where).getSingleResult();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
    *
    * 工場マスタ(見える化専用)情報取得.<br>
    *<br>
    * 概要:<br>
    *   工場マスタ(見える化専用)情報取得
    *<br>
    * @param _plantCode 工場コード
    * @return 工場マスタ(見える化専用)情報
    */
    public MaPlantMierukaEntity getMstPlantMieruka(final String _plantCode) {
        CM_LoggerUtil.outputDaoInputParamLog("_plantCode", _plantCode);

        SimpleWhere where = new SimpleWhere();
        where.eq(MaPlantMierukaEntityNames.plantCd().toString(), _plantCode);

        MaPlantMierukaEntity ret = this.jdbcManager.from(MaPlantMierukaEntity.class).where(where).getSingleResult();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * BeanMap内の共通検索情報をMapに設定する.
     * @param _formInfo BeanMap
     * @param _param Map
     */
    protected void copyComSearchInfo(final BeanMap _formInfo, Map<String, Object> _param) {

        // 工場コード
        Object comPlantCode = _formInfo.get(CM_BaseForm.COM_PLANT_CODE);
        if (CM_CommonUtil.isNotNullOrBlank(comPlantCode)) {
            _param.put(CM_BaseForm.COM_PLANT_CODE, comPlantCode.toString());
        } else {
            _param.put(CM_BaseForm.COM_PLANT_CODE, null);
        }

        // 製造ラインID
        _param.put(CM_BaseForm.COM_SEIZOU_LN_ID, CM_CommonUtil.getLongVal(_formInfo.get(CM_BaseForm.COM_SEIZOU_LN_ID)));

        // 工程ID
        _param.put(CM_BaseForm.COM_PROCESS_ID, CM_CommonUtil.getLongVal(_formInfo.get(CM_BaseForm.COM_PROCESS_ID)));

        // ラインID
        _param.put(CM_BaseForm.COM_LN_ID, CM_CommonUtil.getLongVal(_formInfo.get(CM_BaseForm.COM_LN_ID)));

        // ステーションID
        _param.put(CM_BaseForm.COM_ST_ID, CM_CommonUtil.getLongVal(_formInfo.get(CM_BaseForm.COM_ST_ID)));

        // From/To作成
        this.exchangeSearchDate(_formInfo);

        // 日付種別
        Object comDateType = _formInfo.get(CM_BaseForm.COM_DATE_TYPE);
        if (CM_CommonUtil.isNotNullOrBlank(comDateType)) {
            _param.put(CM_BaseForm.COM_DATE_TYPE, comDateType.toString());
        } else {
            _param.put(CM_BaseForm.COM_DATE_TYPE, null);
        }

        // 日時検索（From）
        Object comDataDateFrom = _formInfo.get(CM_BaseForm.COM_DATA_DATE_FROM);
        if (CM_CommonUtil.isNotNullOrBlank(comDataDateFrom)) {
            int intHour;
            int intDay;
            String baseDateStart = _formInfo.get(CM_BaseForm.COM_DATA_DATE_FROM).toString();
            Date fromdate = CM_CommonUtil.getTimeTimezoneToGmt(baseDateStart, CM_BaseForm.HDN_TIME_ZONE, CM_A04_Const.DATE_FORMAT_SEC_HYPHEN);
            Calendar calFrom = Calendar.getInstance();
            calFrom.setTime(fromdate);
            // 日本時間に戻す
            intHour = calFrom.get(Calendar.HOUR_OF_DAY) - 9;
            intDay = calFrom.get(Calendar.DAY_OF_MONTH);
            if (intHour < 0) {
                intHour = intHour + 24;
                intDay = intDay - 1;
                if (intDay == 0) {
                }
            }
            calFrom.set(Calendar.HOUR_OF_DAY, intHour);
            _param.put(CM_BaseForm.COM_DATA_DATE_FROM, calFrom.getTime());
        } else {
            _param.put(CM_BaseForm.COM_DATA_DATE_FROM, null);
        }

        // 日時検索（To）
        Object comDataDateTo = _formInfo.get(CM_BaseForm.COM_DATA_DATE_TO);
        if (CM_CommonUtil.isNotNullOrBlank(comDataDateTo)) {
            int intHour;
            String baseDateEnd = _formInfo.get(CM_BaseForm.COM_DATA_DATE_TO).toString();
            Date todate = CM_CommonUtil.getTimeTimezoneToGmt(baseDateEnd, CM_BaseForm.HDN_TIME_ZONE, CM_A04_Const.DATE_FORMAT_MILLI_HYPHEN);
            Calendar calTo = Calendar.getInstance();
            calTo.setTime(todate);
            // 日本時間に戻す
            intHour = calTo.get(Calendar.HOUR_OF_DAY) - 9;
            if (intHour < 0) {
                intHour = intHour + 24;
            }
            calTo.set(Calendar.HOUR_OF_DAY, intHour);
            _param.put(CM_BaseForm.COM_DATA_DATE_TO, calTo.getTime());
        } else {
            _param.put(CM_BaseForm.COM_DATA_DATE_TO, null);
        }

        // 検索ワード
        Object comSerchWord = _formInfo.get(CM_BaseForm.COM_SEARCH_WORD);
        if (CM_CommonUtil.isNotNullOrBlank(comSerchWord)) {
            // ワイルドカード文字をエスケープして登録
            String strComSerchWord = CM_CommonUtil.escapeLikeString(comSerchWord.toString());
            // LIKE検索用のワイルドカードを前後に追加
            strComSerchWord = CM_CommonUtil.addWildcard(strComSerchWord, true, true);
            _param.put(CM_BaseForm.COM_SEARCH_WORD, strComSerchWord);
        } else {
            _param.put(CM_BaseForm.COM_SEARCH_WORD, null);
        }
    }

    /**
     * 検索条件のFrom/Toをセット.<br>
     *<br>
     * 概要:<br>
     *   検索条件のFrom/Toをセット
     *<br>
     * @param _formMap フォーム情報
     */
    public void exchangeSearchDate(BeanMap _formMap) {
        String fromDate = "";
        String toDate = "";
        String strDate;
        Timestamp startDatetime;

        // 工場マスタ(見える化専用)の取得
        SimpleWhere where = new SimpleWhere();
        where.eq(MaPlantEntityNames.plantCd().toString(), _formMap.get(CM_BaseForm.COM_PLANT_CODE));

        MaPlantEntity plant = this.jdbcManager.from(MaPlantEntity.class).where(where).getSingleResult();

        // 開始年月日の取得
        if ((plant != null) && (plant.runningStartDatetime != null)) {
            startDatetime = plant.runningStartDatetime;
        } else {
            startDatetime = CM_CommonUtil.parseStringToTimestamp(CM_A04_Const.DEFAULT_RUNNING_START_DATETIME, CM_A04_Const.DATE_FORMAT_MILLI_HYPHEN);
        }

        // 日時データが空の場合は、デフォルト値をセットする
        Calendar sysCal = Calendar.getInstance();

        // 15日足した結果の月として日より下を切り捨てる
        Calendar sysCalWk = Calendar.getInstance();
        sysCalWk.add(Calendar.DAY_OF_MONTH, 15);
        sysCalWk.set(Calendar.DAY_OF_MONTH, 1);
        sysCalWk.set(Calendar.HOUR_OF_DAY, 0);
        _formMap.put(CM_BaseForm.COM_CURRENT_YEAR_MONTH, CM_CommonUtil.getDatetimeStr(sysCalWk, CM_A04_Const.DATE_FORMAT_DATE));

        // 共通検索 日時定義
        CM_A11_SearchDateTypeInfo comSearchDateType = new CM_A11_SearchDateTypeInfo();
        if (_formMap.containsKey(CM_BaseForm.COM_SEARCH_DATE_TYPE)) {
            comSearchDateType = (CM_A11_SearchDateTypeInfo) _formMap.get(CM_BaseForm.COM_SEARCH_DATE_TYPE);
        }

        String dateSerchType;
        if (_formMap.containsKey(CM_A01_BaseAction.DATE_SERCH_TYPE_KEY)) {
            dateSerchType = (String) _formMap.get(CM_A01_BaseAction.DATE_SERCH_TYPE_KEY);
        } else {
            dateSerchType = (String) _formMap.get(CM_BaseForm.COM_DATA_DATE_DISP);
            _formMap.put(CM_A01_BaseAction.DATE_SERCH_TYPE_KEY, dateSerchType);
        }

        // 日付種別のチェック
        if (CM_CommonUtil.isNullOrBlank(_formMap.get(CM_BaseForm.COM_DATE_TYPE_DISP))) {
            // 今月度を設定
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(startDatetime.getTime());
            cal.set(Calendar.YEAR, sysCal.get(Calendar.YEAR));
            cal.set(Calendar.MONTH, sysCal.get(Calendar.MONTH));
            if (cal.compareTo(sysCal) > 0) {
                cal.add(Calendar.MONTH, -1);
            }
            // 月度を求めるため、15日加算した後、日以下を切り捨てる
            // （例えば3/21の場合は4月度(4/1)として扱いたいため）
            cal.add(Calendar.DAY_OF_MONTH, 15);

            _formMap.put(CM_BaseForm.COM_DATE_TYPE_DISP, CM_A04_Const.DATE_TYPE_NITIJI);
            _formMap.put(CM_BaseForm.COM_DATA_DATE_DISP, String.format("%d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1));
        }

        if (CM_CommonUtil.isNullOrBlank(_formMap.get(CM_BaseForm.COM_DATA_DATE_DISP))) {
            if (_formMap.get(CM_BaseForm.COM_DATE_TYPE_DISP).equals(CM_A04_Const.DATE_TYPE_GETUJI)) {
                // 月次の場合
                if (comSearchDateType.dispRecentYear) {
                    // 過去12ヶ月表示
                    _formMap.put(CM_BaseForm.COM_DATA_DATE_DISP, CM_A04_Const.DISP_RECENT_FLG);
                    _formMap.put(CM_A01_BaseAction.DATE_SERCH_TYPE_KEY, CM_A04_Const.DISP_RECENT_FLG);
                } else {
                    Calendar cal = Calendar.getInstance();
                    cal.setTimeInMillis(startDatetime.getTime());
                    cal.set(Calendar.YEAR, sysCal.get(Calendar.YEAR));
                    if (cal.compareTo(sysCal) > 0) {
                        cal.add(Calendar.YEAR, -1);
                    }
                    _formMap.put(CM_BaseForm.COM_DATA_DATE_DISP, String.format("%d", cal.get(Calendar.YEAR)));
                }
            } else if (_formMap.get(CM_BaseForm.COM_DATE_TYPE_DISP).equals(CM_A04_Const.DATE_TYPE_NITIJI)) {
                // 日次の場合
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(startDatetime.getTime());
                cal.set(Calendar.YEAR, sysCal.get(Calendar.YEAR));
                cal.set(Calendar.MONTH, sysCal.get(Calendar.MONTH));
                if (cal.compareTo(sysCal) > 0) {
                    cal.add(Calendar.MONTH, -1);
                }
                // 月度を求めるため、15日加算した後、日以下を切り捨てる
                // （例えば3/21の場合は4月度(4/1)として扱いたいため）
                cal.add(Calendar.DAY_OF_MONTH, 15);
                _formMap.put(CM_BaseForm.COM_DATA_DATE_DISP, String.format("%d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1));
            } else {
                // 時間別の場合
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(startDatetime.getTime());
                cal.set(Calendar.YEAR, sysCal.get(Calendar.YEAR));
                cal.set(Calendar.MONTH, sysCal.get(Calendar.MONTH));
                cal.set(Calendar.DAY_OF_MONTH, sysCal.get(Calendar.DAY_OF_MONTH));
                if (cal.compareTo(sysCal) > 0) {
                    cal.add(Calendar.DAY_OF_MONTH, -1);
                }
                _formMap.put(CM_BaseForm.COM_DATA_DATE_DISP, String.format("%d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)));
            }
        } else {
            // 種別に対して日付桁数の過不足がある場合は、今日、今月度、今年度をセットする
            strDate = _formMap.get(CM_BaseForm.COM_DATA_DATE_DISP).toString();

            // フォーマットチェック＆再設定
            if (!CM_A04_Const.DISP_RECENT_FLG.equals(dateSerchType)) {
                // 直近以外の場合
                strDate = CM_CommonUtil.dateFormatCheck(strDate);
            }
            _formMap.put(CM_BaseForm.COM_DATA_DATE_DISP, strDate);

            if (!CM_A04_Const.DISP_RECENT_FLG.equals(dateSerchType)) {
                // 直近以外の場合
                if (_formMap.get(CM_BaseForm.COM_DATE_TYPE_DISP).equals(CM_A04_Const.DATE_TYPE_JIKANBETU)
                        || _formMap.get(CM_BaseForm.COM_DATE_TYPE_DISP).equals(CM_A04_Const.DATE_TYPE_SHUJI)) {
                    if (strDate.length() != 10) {
                        // 今日を再設定
                        Calendar cal = Calendar.getInstance();
                        cal.setTimeInMillis(startDatetime.getTime());
                        cal.set(Calendar.YEAR, sysCal.get(Calendar.YEAR));
                        cal.set(Calendar.MONTH, sysCal.get(Calendar.MONTH));
                        cal.set(Calendar.DAY_OF_MONTH, sysCal.get(Calendar.DAY_OF_MONTH));
                        if (cal.compareTo(sysCal) > 0) {
                            cal.add(Calendar.DAY_OF_MONTH, -1);
                        }
                        _formMap.put(CM_BaseForm.COM_DATA_DATE_DISP, String.format("%d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)));
                    }
                } else if (_formMap.get(CM_BaseForm.COM_DATE_TYPE_DISP).equals(CM_A04_Const.DATE_TYPE_NITIJI)) {
                    if (strDate.length() != 7) {
                        // 今月度を再設定
                        Calendar cal = Calendar.getInstance();
                        cal.setTimeInMillis(startDatetime.getTime());
                        cal.set(Calendar.YEAR, sysCal.get(Calendar.YEAR));
                        cal.set(Calendar.MONTH, sysCal.get(Calendar.MONTH));
                        if (cal.compareTo(sysCal) > 0) {
                            cal.add(Calendar.MONTH, -1);
                        }
                        // 月度を求めるため、15日加算した後、日以下を切り捨てる
                        // （例えば3/21の場合は4月度(4/1)として扱いたいため）
                        cal.add(Calendar.DAY_OF_MONTH, 15);
                        _formMap.put(CM_BaseForm.COM_DATA_DATE_DISP, String.format("%d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1));
                    }
                } else {
                    if (strDate.length() != 4) {
                        // 今年度を再設定
                        Calendar cal = Calendar.getInstance();
                        cal.setTimeInMillis(startDatetime.getTime());
                        cal.set(Calendar.YEAR, sysCal.get(Calendar.YEAR));
                        if (cal.compareTo(sysCal) > 0) {
                            cal.add(Calendar.YEAR, -1);
                        }
                       _formMap.put(CM_BaseForm.COM_DATA_DATE_DISP, String.format("%d", cal.get(Calendar.YEAR)));
                    }
                }
            }
        }

        // ユーザタイムゾーンのセット（TODO:各国対応）
//        _formMap.put(CM_BaseForm.HDN_TIME_ZONE, this. this.sessionDto.ssn_UserTimezoneCD);
        _formMap.put(CM_BaseForm.HDN_TIME_ZONE, "Asia/Japan");

        // 検索日時(From/To)
        if (CM_CommonUtil.isNotNullOrBlank(_formMap.get(CM_BaseForm.HDN_PROCESS_EXEC_FLG)) &&
                _formMap.get(CM_BaseForm.HDN_PROCESS_EXEC_FLG).equals(CM_A04_Const.PROCESS_EXEC_CSV)) {
            fromDate = getDataDateFrom(_formMap, true);
            toDate = getDataDateTo(_formMap, true);
            _formMap.put(CM_BaseForm.COM_DATE_TYPE, _formMap.get(CM_BaseForm.COM_DATE_TYPE_CSV_DISP));
        } else {
            fromDate = getDataDateFrom(_formMap, false);
            toDate = getDataDateTo(_formMap, false);
            _formMap.put(CM_BaseForm.COM_DATE_TYPE, _formMap.get(CM_BaseForm.COM_DATE_TYPE_DISP));
        }

        if ((fromDate != "") && (toDate != "")) {
            // 作成したFrom/Toを格納
            _formMap.put(CM_BaseForm.COM_DATA_DATE_FROM, fromDate);
            _formMap.put(CM_BaseForm.COM_DATA_DATE_TO, toDate);
        }

        return;
    }

    /**
     * 現在の年度を取得.
     *
     * @param _comPlantCode 工場コード
     * @return 現在の年度(YYYY)
     */
    public String getCurrentYear(final String _comPlantCode) {
        Timestamp startDatetime;

        // 工場マスタ(見える化専用)の取得
        SimpleWhere where = new SimpleWhere();
        where.eq(MaPlantEntityNames.plantCd().toString(), _comPlantCode);

        MaPlantEntity plant = this.jdbcManager.from(MaPlantEntity.class).where(where).getSingleResult();

        // 開始年月日の取得
        if ((plant != null) && (plant.runningStartDatetime != null)) {
            startDatetime = plant.runningStartDatetime;
        } else {
            startDatetime = CM_CommonUtil.parseStringToTimestamp(CM_A04_Const.DEFAULT_RUNNING_START_DATETIME, CM_A04_Const.DATE_FORMAT_MILLI_HYPHEN);
        }

        // 現在日時の取得
        Calendar sysCal = Calendar.getInstance();

        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(startDatetime.getTime());
        cal.set(Calendar.YEAR, sysCal.get(Calendar.YEAR));
        if (cal.compareTo(sysCal) > 0) {
            cal.add(Calendar.YEAR, -1);
        }

        return String.format("%d", cal.get(Calendar.YEAR));
    }

    /**
     * うるう年の判定.<br>
     *<br>
     * 概要:<br>
     *   うるう年かどうか判定する
     *<br>
     * @param _year 判定したい年
     * @return boolean Yes/No
     */
    private boolean isLeapYear(final int _year) {
        if ( _year % 4 == 0 && _year % 100 != 0 || _year % 400 == 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 終了時間の取得.<br>
     *<br>
     * 概要:<br>
     *   指定した時間から終了時間を取得する
     *<br>
     * @param _startTime 開始時間
     * @return boolean Yes/No
     */
    private String getEndTime(final String _startTime) {
        int intHour;
        String strHour;
        Integer oi;

        intHour = Integer.parseInt(_startTime.substring(0, 2)) - 1;
        if (intHour < 0) {
            strHour = CM_A04_Const.END_HOUR_23;
        } else {
            oi = new Integer(intHour);
            strHour = oi.toString();
            if (strHour.length() < 2) {
                strHour = "0" + strHour;
            }
            strHour = String.format("%s", strHour);
        }
        return strHour + CM_A04_Const.DEFAULT_DATE_END_TIME;
    }

    /**
     * 終了年月日の取得.<br>
     *<br>
     * 概要:<br>
     *   指定した年月日から終了の年月日を取得する
     *<br>
     * @param _year 年
     * @param _month 月
     * @param _day 日
     * @return List<String> 年／月／日
     */
    private List<String> getEndDate(final String _year, final String _month, final String _day, final int _searchType) {
        int intYear;
        int intMonth;
        int intDay;
        Integer oi;
        String strMonth;
        String strDay;

        List<String> retParam = new ArrayList<String>(3);

        intYear = Integer.parseInt(_year) + 1;
        intMonth = Integer.parseInt(_month);
        if (_searchType == -1) {
            intDay = Integer.parseInt(_day) - 1;
        }
        else if (_searchType == 1) {
            intDay = Integer.parseInt(_day) + 1;
            switch (intMonth) {
            case 1: case 3: case 5: case 7: case 8: case 10:
                if (intDay > 31) {
                    intDay = 1;
                    intMonth = intMonth + 1;
                }
                break;
            case 12:
                if (intDay > 31) {
                    intDay = 1;
                    intMonth = 1;
                    intYear = intYear + 1;
                }
                break;
            case 4: case 6: case 9: case 11:
                if (intDay > 30) {
                    intDay = 1;
                    intMonth = intMonth + 1;
                }
                break;
            case 2:
                if (this.isLeapYear(intYear-1)) {
                    if (intDay > 29) {
                        intDay = 1;
                        intMonth = intMonth + 1;
                    } else {
                        if (intDay > 28) {
                            intDay = 1;
                            intMonth = intMonth + 1;
                        }
                    }
                }
                break;
            default:
                break;
            }
        }
        else {
            intDay = Integer.parseInt(_day);
        }

        // 年のセット
        oi = new Integer(intYear);
        retParam.add(String.format("%s", oi.toString()));

        // 月の考慮
        if (intDay == 0) {
            intMonth = intMonth -1;
            if (intMonth == 0) {
                intMonth = 12;
            }
        }
        // 月のセット
        oi = new Integer(intMonth);
        strMonth = oi.toString();
        if (strMonth.length() < 2)
            strMonth = "0" + strMonth;
        retParam.add(String.format("%s", strMonth));

        // 日の考慮
        if (intDay == 0) {
            switch (intMonth) {
            case 1:case 3:case 5:case 7:case 8:case 10:case 12:
                intDay = 31;
                break;
            case 2:
                if (isLeapYear(intYear)) {
                    intDay = CM_A04_Const.DEFAULT_MONTH_END_DAY_LEAPYEAR;
                } else {
                    intDay = CM_A04_Const.DEFAULT_MONTH_END_DAY;
                }
                break;
            case 4:case 6:case 9:case 11:
                intDay = 31;
                break;
            default:
                break;
            }
        }
        // 日のセット
        oi = new Integer(intDay);
        strDay = oi.toString();
        if (strDay.length() < 2) {
            strDay = "0" + strDay;
        }
        retParam.add(String.format("%s", strDay));

        return retParam;
    }

    /**
     * 前日の取得.<br>
     *<br>
     * 概要:<br>
     *   指定した年月日から前日を取得する
     *<br>
     * @param _year 年
     * @param _month 月
     * @param _day 日
     * @return _month 前月
     */
    private List<String> getBeforeDay(final String _year, final String _month, final String _day) {
        int intYear;
        int intMonth;
        int intDay;
        Integer oi;
        String strYear;
        String strMonth;
        String strDay;

        List<String> retParam = new ArrayList<String>(3);

        intYear = Integer.parseInt(_year);
        intMonth = Integer.parseInt(_month);
        intDay = Integer.parseInt(_day);

        // 前の日を取得
        intDay = intDay - 1;
        if (intDay < 1) {
            // 前の月
            intMonth = intMonth - 1;
            if (intMonth < 1) {
                // 前の年
                intMonth = 12;
                intYear = intYear - 1;
            }
            // 日の決定
            switch (intMonth) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                intDay = 31;
                break;
            case 4: case 6: case 9: case 11:
                intDay = 30;
                break;
            case 2:
                if (this.isLeapYear(intYear)) {
                    intDay = 29;
                } else {
                    intDay = 28;
                }
                break;
            }
        }

        // 年のセット
        oi = new Integer(intYear);
        retParam.add(String.format("%s", oi.toString()));

        // 月のセット
        oi = new Integer(intMonth);
        strMonth = oi.toString();
        if (strMonth.length() < 2) {
            strMonth = "0" + strMonth;
        }
        retParam.add(String.format("%s", strMonth));

        // 日のセット
        oi = new Integer(intDay);
        strDay = oi.toString();
        if (strDay.length() < 2) {
            strDay = "0" + strDay;
        }
        retParam.add(String.format("%s", strDay));

        return retParam;
}

    /**
     * 次日の取得.<br>
     *<br>
     * 概要:<br>
     *   指定した年月日から次日を取得する
     *<br>
     * @param _year 年
     * @param _month 月
     * @param _day 日
     * @return _month 前月
     */
    private List<String> getNextDay(final String _year, final String _month, final String _day) {
        int intYear;
        int intMonth;
        int intDay;
        Integer oi;
        String strYear;
        String strMonth;
        String strDay;

        List<String> retParam = new ArrayList<String>(3);

        intYear = Integer.parseInt(_year);
        intMonth = Integer.parseInt(_month);
        intDay = Integer.parseInt(_day);

        // 日を+1する
        intDay = intDay + 1;

        // 晦日の決定
        switch (intMonth) {
        case 1: case 3: case 5: case 7: case 8: case 10:
            if (intDay > 31) {
                intDay = 1;
                intMonth = intMonth + 1;
            }
            break;
        case 12:
            if (intDay > 31) {
                intDay = 1;
                intMonth = 1;
                intYear = intYear + 1;
            }
            break;
        case 4: case 6: case 9: case 11:
            if (intDay > 30) {
                intDay = 1;
                intMonth = intMonth + 1;
            }
            break;
        case 2:
            if (this.isLeapYear(intYear-1)) {
                if (intDay > 29) {
                    intDay = 1;
                    intMonth = intMonth + 1;
                } else {
                    if (intDay > 28) {
                        intDay = 1;
                        intMonth = intMonth + 1;
                    }
                }
            }
            break;
        default:
            break;
        }

        // 年のセット
        oi = new Integer(intYear);
        retParam.add(String.format("%s", oi.toString()));

        // 月のセット
        oi = new Integer(intMonth);
        strMonth = oi.toString();
        if (strMonth.length() < 2) {
            strMonth = "0" + strMonth;
        }
        retParam.add(String.format("%s", strMonth));

        // 日のセット
        oi = new Integer(intDay);
        strDay = oi.toString();
        if (strDay.length() < 2) {
            strDay = "0" + strDay;
        }
        retParam.add(String.format("%s", strDay));

        return retParam;
    }

    /**
     * 前月の取得.<br>
     *<br>
     * 概要:<br>
     *   指定した年月日から前月を取得する
     *<br>
     * @param _year 年
     * @param _month 月
     * @param _day 日
     * @return _month 前月
     */
    private String getBeforeMonth(final String _year, final String _month, final String _day) {
        int intYear;
        int intMonth;
        Integer oi;
        String strMonth;

        intYear = Integer.parseInt(_year);
        intMonth = Integer.parseInt(_month);

        intMonth = intMonth - 1;
        if (intMonth == 0) {
            intMonth = 12;
        }

        oi = new Integer(intMonth);
        strMonth = oi.toString();
        if (strMonth.length() < 2) {
            strMonth = "0" + strMonth;
        }

        return strMonth;
    }

    /**
     * 次月の取得.<br>
     *<br>
     * 概要:<br>
     *   指定した年月日から次月を取得する
     *<br>
     * @param _year 年
     * @param _month 月
     * @param _day 日
     * @return _month 前月
     */
    private List<String> getNextMonth(final String _year, final String _month, final String _day) {
        int intYear;
        int intMonth;
        Integer oi;
        String strYear;
        String strMonth;

        List<String> retParam = new ArrayList<String>(3);

        intYear = Integer.parseInt(_year);
        intMonth = Integer.parseInt(_month);

        intMonth = intMonth + 1;
        if (intMonth == 13) {
            intMonth = 1;
            intYear = intYear + 1;
        }

        // 年のセット
        oi = new Integer(intYear);
        strYear = oi.toString();
        retParam.add(String.format("%s", strYear));

        // 月のセット
        oi = new Integer(intMonth);
        strMonth = oi.toString();
        if (strMonth.length() < 2) {
            strMonth = "0" + strMonth;
        }
        retParam.add(String.format("%s", strMonth));

        return retParam;
    }

    /**
     * 今月度を取得.<br>
     *<br>
     * 概要:<br>
     *   今日が何月度か取得する
     *<br>
     * @param _formMap フォーム情報
     */
    public String GetCurrentMonth(final BeanMap _formMap) {

        Timestamp startDatetime;

        // 工場マスタ(見える化専用)の取得
        SimpleWhere where = new SimpleWhere();
        where.eq(MaPlantEntityNames.plantCd().toString(), _formMap.get(CM_BaseForm.COM_PLANT_CODE));

        MaPlantEntity plant = this.jdbcManager.from(MaPlantEntity.class).where(where).getSingleResult();

        // 開始年月日の取得
        if ((plant != null) && (plant.runningStartDatetime != null)) {
            startDatetime = plant.runningStartDatetime;
        } else {
            startDatetime = CM_CommonUtil.parseStringToTimestamp(CM_A04_Const.DEFAULT_RUNNING_START_DATETIME, CM_A04_Const.DATE_FORMAT_MILLI_HYPHEN);
        }

        // 現在日時の取得
        Calendar sysCal = Calendar.getInstance();

        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(startDatetime.getTime());
        cal.set(Calendar.YEAR, sysCal.get(Calendar.YEAR));
        cal.set(Calendar.MONTH, sysCal.get(Calendar.MONTH));
        if (cal.compareTo(sysCal) > 0) {
            cal.add(Calendar.MONTH, -1);
        }
        // 月度を求めるため、15日加算した後、日以下を切り捨てる
        // （例えば3/21の場合は4月度(4/1)として扱いたいため）
        cal.add(Calendar.DAY_OF_MONTH, 15);

        return String.format("%d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
    }

    /**
     * 工場稼働開始日時を取得.<br>
     *<br>
     * 概要:<br>
     *   工場稼働開始日時を取得する
     *<br>
     * @param _formMap フォーム情報
     */
    public String getPlantStartDate(final BeanMap _formMap) {
        // 工場マスタの取得
        SimpleWhere where = new SimpleWhere();
        where.eq(MaPlantEntityNames.plantCd().toString(), _formMap.get(CM_BaseForm.COM_PLANT_CODE));

        MaPlantEntity plant = this.jdbcManager.from(MaPlantEntity.class).where(where).getSingleResult();

        // 開始年月日と開始時間の取得
        String strRet;
        if (plant != null) {
            strRet = (new SimpleDateFormat(CM_A04_Const.DATE_FORMAT_SEC_HYPHEN).format(plant.runningStartDatetime));
        } else {
            strRet = CM_A04_Const.DEFAULT_RUNNING_START_DATETIME;
        }

        return strRet;
    }

    /**
    *
    * お気に入りページ取得.<br>
    *<br>
    * 概要:<br>
    *   検索条件記憶テーブルよりお気に入りページを取得
    *<br>
    * @param _userSid ユーザSID
    * @param _favoriteNo お気に入り番号（null可）
    * @return お気に入りページ一覧
    */
    public List<BeanMap> selectFavoritePage(final Integer _userSid, final Integer _favoriteNo) {
        CM_LoggerUtil.outputDaoInputParamLog("_userSid", _userSid);
        CM_LoggerUtil.outputDaoInputParamLog("_favoriteNo", _favoriteNo);

        BeanMap param = new BeanMap();
        param.put(TrSearchConditionEntityNames.userSid().toString(), _userSid);
        param.put(TrSearchConditionEntityNames.favoriteNo().toString(), _favoriteNo);

        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(BeanMap.class,
                BASE_SQL_PATH_COMM + "selectFavoritePage.sql", param).getResultList();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

   /**
    *
    * お気に入り情報取得.<br>
    *<br>
    * 概要:<br>
    *   検索条件記憶テーブルよりお気に入り情報を取得
    *<br>
    * @param _userSid ユーザSID
    * @param _favoriteNo お気に入り番号
    * @return お気に入り情報
    */
    public List<BeanMap> selectFavoriteInfo(final Integer _userSid, final Integer _favoriteNo) {
        CM_LoggerUtil.outputDaoInputParamLog("_userSid", _userSid);
        CM_LoggerUtil.outputDaoInputParamLog("_favoriteNo", _favoriteNo);

        BeanMap param = new BeanMap();
        param.put(TrSearchConditionEntityNames.userSid().toString(), _userSid);
        param.put(TrSearchConditionEntityNames.favoriteNo().toString(), _favoriteNo);

        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(BeanMap.class,
                BASE_SQL_PATH_COMM + "selectFavoriteInfo.sql", param).getResultList();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

   /**
    *
    *　検索条件記憶テーブル取得.<br>
    *<br>
    * 概要:<br>
    *   検索条件記憶テーブルの取得処理
    *<br>
    * @param _userSid ユーザSID
    * @param _pageId 画面ID
    * @return 検索条件記録テーブル一覧
    */
   public List<TrSearchConditionEntity> selectTblSearchCondition(
           final Integer _userSid, final String _pageId, final String _favoriteNo) {
       CM_LoggerUtil.outputDaoInputParamLog("_userSid", _userSid);
       CM_LoggerUtil.outputDaoInputParamLog("_pageId", _pageId);
       CM_LoggerUtil.outputDaoInputParamLog("_favoriteNo", _favoriteNo);

       SimpleWhere where = new SimpleWhere();
       where.eq(TrSearchConditionEntityNames.userSid(), _userSid);
       where.eq(TrSearchConditionEntityNames.pageId(), _pageId);
       where.eq(TrSearchConditionEntityNames.favoriteNo(), _favoriteNo);

       OrderByItem orderItem = new OrderByItem(TrSearchConditionEntityNames.conditionNum(), OrderingSpec.ASC);

       List<TrSearchConditionEntity> ret = this.jdbcManager.from(TrSearchConditionEntity.class)
               .where(where).orderBy(orderItem).getResultList();

       CM_LoggerUtil.outputDaoOutputParamLog(ret);

       return ret;
   }

   /**
    *
    * 検索条件登録.<br>
    *<br>
    * 概要:<br>
    *  検索条件登録処理
    *<br>
    * @param _entity 検索条件登録Entity
    * @return 登録件数
    */
   public int insertTblSearchCondition(final TrSearchConditionEntity _entity) {
       CM_LoggerUtil.outputDaoInputParamLog();

       int ret = this.jdbcManager.insert(_entity).execute();

       CM_LoggerUtil.outputDaoOutputParamLog(ret);

       return ret;

   }

   /**
    *
    * お気に入り削除.<br>
    *<br>
    * 概要:<br>
    *   ユーザSID、お気に入り番号を元に検索条件記憶テーブルを削除する
    *<br>
    * @param _userSid ユーザSID
    * @param _favoriteNo お気に入り番号
    * @return 削除件数
    */
   public int deleteFavorite(final Integer _userSid, final Integer _favoriteNo) {
       CM_LoggerUtil.outputDaoInputParamLog("_userSid", _userSid);
       CM_LoggerUtil.outputDaoInputParamLog("_favoriteNo", _favoriteNo);

       BeanMap param = new BeanMap();
       param.put(TrSearchConditionEntityNames.userSid().toString(), _userSid);
       param.put(TrSearchConditionEntityNames.favoriteNo().toString(), _favoriteNo);

       int ret = this.jdbcManager.updateBySqlFile(BASE_SQL_PATH_COMM + "deleteTblSearchCondition.sql", param).execute();

       CM_LoggerUtil.outputDaoOutputParamLog(ret);

       return ret;
   }

   /**
   *
   * お気に入り名称更新.<br>
   *<br>
   * 概要:<br>
   *  お気に入り名称更新処理
   *<br>
   * @param _entity お気に入り登録Entity
   * @return 登録件数
   */
    public int updateFavoriteName(final TrSearchConditionEntity _entity) {
        CM_LoggerUtil.outputDaoInputParamLog("_userSid", _entity.userSid);
        CM_LoggerUtil.outputDaoInputParamLog("_favoriteNo", _entity.favoriteNo);
        CM_LoggerUtil.outputDaoInputParamLog("_favoriteName", _entity.favoriteName);
        CM_LoggerUtil.outputDaoInputParamLog("_updProg", _entity.updProg);
        CM_LoggerUtil.outputDaoInputParamLog("_updTim", _entity.updTim);
        CM_LoggerUtil.outputDaoInputParamLog("_updUserSid", _entity.updUserSid);

        BeanMap param = new BeanMap();
        param.put(TrSearchConditionEntityNames.userSid().toString(), _entity.userSid);
        param.put(TrSearchConditionEntityNames.favoriteNo().toString(), _entity.favoriteNo);
        param.put(TrSearchConditionEntityNames.favoriteName().toString(), _entity.favoriteName);
        param.put(TrSearchConditionEntityNames.updProg().toString(), _entity.updProg);
        param.put(TrSearchConditionEntityNames.updTim().toString(), _entity.updTim);
        param.put(TrSearchConditionEntityNames.updUserSid().toString(), _entity.updUserSid);

        int ret = this.jdbcManager.updateBySqlFile(BASE_SQL_PATH_COMM + "updateTblSearchCondition.sql", param).execute();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

   /**
    * アンドン情報取得.
    * @param _formInfo BeanMap
    * @return AndongInfoDto
    */
   public AndongInfoDto getAndongInfoDto(final BeanMap _formInfo) {

       CM_LoggerUtil.outputDaoInputParamLog("_formInfo", _formInfo);

       Map<String, Object> param = new HashMap<String, Object>();

       // 検索条件の取得
       this.copyComSearchInfo(_formInfo, param);

       // ユーザ情報検索
       List<AndongInfoDto> retList = this.jdbcManager.selectBySqlFile(AndongInfoDto.class,
               BASE_SQL_PATH_COMM + "selectLineWorkCurrent.sql",
               param).getResultList();

       AndongInfoDto ret = retList.get(0);

       CM_LoggerUtil.outputDaoOutputParamLog(ret);
       return ret;
   }

    /**
     * MES連携情報取得.
     * @param _formInfo BeanMap
     * @return connectTime
     */
    public long getMesConnectInfoDto(final BeanMap _formInfo) {
        CM_LoggerUtil.outputDaoInputParamLog("_formInfo", _formInfo);

        Long retTime = 0L;
        long ret = 0;

        // 工場コードの取得
        if (CM_CommonUtil.isNullOrBlank(_formInfo.get(CM_BaseForm.COM_PLANT_CODE))) {
            return (-1);
        }

        BeanMap param = new BeanMap();
        param.putAll(_formInfo);

        // ユーザ情報検索
        retTime = this.jdbcManager.selectBySqlFile(long.class,
                BASE_SQL_PATH_COMM + "selectMesConnectTime.sql", param).getSingleResult();
        if (retTime != null)
        {
            ret = retTime.longValue();
        }

        CM_LoggerUtil.outputDaoOutputParamLog(ret);
        return ret;
    }

    /**
     * 検索日時(From)取得.
     * @param _formInfo BeanMap
     * @param _isCsv boolean
     * @return From文字列
     */
    public String getDataDateFrom(final BeanMap _formInfo, final boolean _isCsv) {

        String strYear;
        String strMonth;
        String strDay;

        Integer oi;
        int intYear;

        String strDateType;
        String strFrom;

        List<String> paramShuji = new ArrayList<String>(3);
        String dateSerchType = (String) _formInfo.get(CM_A01_BaseAction.DATE_SERCH_TYPE_KEY);

        if (_isCsv) {
            if (CM_CommonUtil.isNullOrBlank(_formInfo.get(CM_BaseForm.COM_DATE_TYPE_CSV_DISP)) ||
                    CM_CommonUtil.isNullOrBlank(_formInfo.get(CM_BaseForm.COM_DATA_DATE_FROM_CSV_DISP))) {
                return FW00_19_Const.EMPTY_STR;
            }

            strDateType = (String)_formInfo.get(CM_BaseForm.COM_DATE_TYPE_CSV_DISP);
            strFrom = (String)_formInfo.get(CM_BaseForm.COM_DATA_DATE_FROM_CSV_DISP);
        } else {
            if (CM_CommonUtil.isNullOrBlank(_formInfo.get(CM_BaseForm.COM_DATE_TYPE_DISP)) ||
                    CM_CommonUtil.isNullOrBlank(_formInfo.get(CM_BaseForm.COM_DATA_DATE_DISP))) {
                return FW00_19_Const.EMPTY_STR;
            }

            strDateType = (String)_formInfo.get(CM_BaseForm.COM_DATE_TYPE_DISP);
            strFrom = (String)_formInfo.get(CM_BaseForm.COM_DATA_DATE_DISP);
        }

        // 開始年月日と開始時間の取得
        String strStartDate = getPlantStartDate(_formInfo);
        String strStartTime = strStartDate.substring(11,19);

        if (strDateType.equals(CM_A04_Const.DATE_TYPE_JIKANBETU)) {
            strFrom = strFrom + " " + strStartTime + ".000";
        } else if (strDateType.equals(CM_A04_Const.DATE_TYPE_SHUJI)) {
            // 今月度は前月
            strYear = strFrom.substring(0, 4);
            strMonth = strFrom.substring(5, 7);
            strDay = strFrom.substring(8, 10);

            // 今月度は前月
            // 始まりが00:00:00の場合は、終わりは前の日
            paramShuji = this.getBeforeWeek(strYear, strMonth, strDay);
            strYear = paramShuji.get(0);
            strMonth = paramShuji.get(1);
            strDay = paramShuji.get(2);

            if (Integer.parseInt(strMonth) == 12) {
                intYear = Integer.parseInt(strYear) - 1;
                oi = new Integer(intYear);
                strYear = oi.toString();
            }
            strFrom = strYear + "-" + strMonth + "-" + strDay + " "
                    + strStartTime + ".000";
        } else if (strDateType.equals(CM_A04_Const.DATE_TYPE_NITIJI)) {
            if (Integer.parseInt(strStartDate.substring(8, 10)) == 1) {
                // 1日始まりはその月度
                strFrom = strFrom + "-" + strStartDate.substring(8, 10) + " " + strStartTime + ".000";
            } else {
                // 今月度は前月
                strYear = strFrom.substring(0,  4);
                strMonth = strFrom.substring(5, 7);
                strDay = strStartDate.substring(8, 10);
                strMonth = getBeforeMonth(strYear, strMonth, strDay);
                if (Integer.parseInt(strMonth) == 12) {
                    intYear = Integer.parseInt(strYear) - 1;
                    oi = new Integer(intYear);
                    strYear = oi.toString();
                }
                strFrom = strYear + "-" + strMonth + "-" + strDay + " " + strStartTime + ".000";
            }
        } else {
            if (!_isCsv && CM_A04_Const.DISP_RECENT_FLG.equals(dateSerchType)) {
                // 直近12ヶ月の場合
                Calendar sysCal = Calendar.getInstance();
                sysCal.add(Calendar.YEAR, -1);
                strFrom = this.getDateForSearch(sysCal, strStartDate) + " " + strStartTime + ".000";
            } else {
                strFrom = strFrom + "-" + strStartDate.substring(5, 10) + " " + strStartTime + ".000";
            }
        }

        return strFrom;
    }

    /**
     * 前週の取得.<br>
     * <br>
     * 概要:<br>
     * 指定した年月日から前週を取得する <br>
     *
     * @param _year
     *            年
     * @param _month
     *            月
     * @param _day
     *            日
     * @return _month 前月
     */
    private List<String> getBeforeWeek(final String _year, final String _month,
            final String _day) {
        int intYear;
        int intMonth;
        int intDay;
        Integer oi;
        String strMonth;
        String strDay;

        List<String> retParam = new ArrayList<String>(3);

        intYear = Integer.parseInt(_year);
        intMonth = Integer.parseInt(_month);
        intDay = Integer.parseInt(_day);

        // 前の週を取得
        intDay = intDay - 6;
        if (intDay < 1) {
            // 前の月
            intMonth = intMonth - 1;
            if (intMonth < 1) {
                // 前の年
                intMonth = 12;
                intYear = intYear - 1;
            }
            // 日の決定
            switch (intMonth) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                intDay = 31 + intDay + 1;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                intDay = 30 + intDay + 1;
                break;
            case 2:
                if (this.isLeapYear(intYear)) {
                    intDay = 29 + intDay + 1;
                } else {
                    intDay = 28 + intDay + 1;
                }
                break;
            }
        }

        // 年のセット
        oi = new Integer(intYear);
        retParam.add(String.format("%s", oi.toString()));

        // 月のセット
        oi = new Integer(intMonth);
        strMonth = oi.toString();
        if (strMonth.length() < 2) {
            strMonth = "0" + strMonth;
        }
        retParam.add(String.format("%s", strMonth));

        // 日のセット
        oi = new Integer(intDay);
        strDay = oi.toString();
        if (strDay.length() < 2) {
            strDay = "0" + strDay;
        }
        retParam.add(String.format("%s", strDay));

        return retParam;
    }

    /**
     * 検索条件用の年月日（文字列）を生成する.
     *
     * @param _cal Calendar
     * @param _strStartDate 期首（文字列）
     * @return 検索条件用の年月日（文字列）
     */
    private String getDateForSearch(final Calendar _cal, final String _strStartDate) {

        String ret = FW00_19_Const.EMPTY_STR;

        int intYear = _cal.get(Calendar.YEAR);
        int intMonth = _cal.get(Calendar.MONTH) + 1;
        int intDate = _cal.get(Calendar.DATE);

        int startMonth = Integer.valueOf(_strStartDate.substring(5, 7));
        int startDate = Integer.valueOf(_strStartDate.substring(8, 10));

        if (startDate > 1 && intDate >= startDate) {
            intMonth++;
        }

        ret += CM_CommonUtil.paddingZero(intYear, 4);
        ret += FW00_19_Const.HYPHEN_STR;
        ret += CM_CommonUtil.paddingZero(intMonth, 2);
        ret += FW00_19_Const.HYPHEN_STR;
        ret += CM_CommonUtil.paddingZero(startDate, 2);

        return ret;
    }

    /**
     * 検索日時(To)取得.
     * @param _formInfo BeanMap
     * @param fromDate 検索期間From
     * @param _isCsv boolean
     * @return To文字列
     */
    public String getDataDateTo(final BeanMap _formInfo, final boolean _isCsv) {

        String strYear;
        String strMonth;
        String strDay;

        String strDateType;
        String strTo;

        SimpleDateFormat sdf = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT_MILLI_HYPHEN);

        String dateSerchType = (String) _formInfo.get(CM_A01_BaseAction.DATE_SERCH_TYPE_KEY);

        if (_isCsv) {
            if (CM_CommonUtil.isNullOrBlank(_formInfo.get(CM_BaseForm.COM_DATE_TYPE_CSV_DISP)) ||
                    CM_CommonUtil.isNullOrBlank(_formInfo.get(CM_BaseForm.COM_DATA_DATE_TO_CSV_DISP))) {
                return FW00_19_Const.EMPTY_STR;
            }

            strDateType = (String) _formInfo.get(CM_BaseForm.COM_DATE_TYPE_CSV_DISP);
            strTo = (String) _formInfo.get(CM_BaseForm.COM_DATA_DATE_TO_CSV_DISP);
        } else {
            if (CM_CommonUtil.isNullOrBlank(_formInfo.get(CM_BaseForm.COM_DATE_TYPE_DISP)) ||
                    CM_CommonUtil.isNullOrBlank(_formInfo.get(CM_BaseForm.COM_DATA_DATE_DISP))) {
                return FW00_19_Const.EMPTY_STR;
            }

            strDateType = (String) _formInfo.get(CM_BaseForm.COM_DATE_TYPE_DISP);
            strTo = (String) _formInfo.get(CM_BaseForm.COM_DATA_DATE_DISP);
        }

        List<String> param = new ArrayList<String>(3);

        // 開始年月日と開始時間の取得
        String strStartDate = this.getPlantStartDate(_formInfo);
        String strStartTime = strStartDate.substring(11,19);
        if (strDateType.equals(CM_A04_Const.DATE_TYPE_JIKANBETU)
                || strDateType.equals(CM_A04_Const.DATE_TYPE_SHUJI)) {
            strYear = strTo.substring(0, 4);
            strMonth = strTo.substring(5,7);
            strDay = strTo.substring(8,10);
            param = this.getNextDay(strYear, strMonth, strDay);

            strYear = param.get(0);
            strMonth = param.get(1);
            strDay = param.get(2);

            if (strStartTime.equals("00:00:00")) {
                // 始まりが00:00:00の場合は、終わりは前の日
                param = this.getBeforeDay(strYear, strMonth, strDay);
                strYear = param.get(0);
                strMonth = param.get(1);
                strDay = param.get(2);
            }

            strTo = strYear
                    + FW00_19_Const.HYPHEN_STR
                    + strMonth
                    + FW00_19_Const.HYPHEN_STR
                    + strDay
                    + FW00_19_Const.SPACE
                    + this.getEndTime(strStartTime)
                    + ".999";

        } else if (strDateType.equals(CM_A04_Const.DATE_TYPE_NITIJI)) {
            strYear = strTo.substring(0, 4);
            strMonth = strTo.substring(5, 7);
            strDay = strStartDate.substring(8, 10);

            if (strStartDate.substring(8,10).equals("01")) {
                param = this.getNextMonth(strYear, strMonth, strDay);
                strYear = param.get(0);
                strMonth = param.get(1);
                strTo = strYear
                        + FW00_19_Const.HYPHEN_STR
                        + strMonth
                        + FW00_19_Const.HYPHEN_STR
                        + strStartDate.substring(8,10)
                        + FW00_19_Const.SPACE
                        + this.getEndTime(strStartTime)
                        + ".999";
            } else {
                if (strStartTime.equals("00:00:00")) {
                    // 始まりが00:00:00の場合は、終わりは前の日
                    param = this.getBeforeDay(strYear, strMonth, strDay);
                    strYear = param.get(0);
                    strMonth = param.get(1);
                    strDay = param.get(2);
                }
                strTo = strYear
                        + FW00_19_Const.HYPHEN_STR
                        + strMonth
                        + FW00_19_Const.HYPHEN_STR
                        + strDay
                        + FW00_19_Const.SPACE
                        + this.getEndTime(strStartTime)
                        + ".999";
            }


            if (strStartTime.equals("00:00:00")) {
                // 始まりが00:00:00の場合は、終わりは前の日
                param = this.getBeforeDay(strYear, strMonth, strDay);
                strYear = param.get(0);
                strMonth = param.get(1);
                strDay = param.get(2);
            }

            strTo = strYear
                    + FW00_19_Const.HYPHEN_STR
                    + strMonth
                    + FW00_19_Const.HYPHEN_STR
                    + strDay
                    + FW00_19_Const.SPACE
                    + this.getEndTime(strStartTime)
                    + ".999";
        } else {
            if (!_isCsv && CM_A04_Const.DISP_RECENT_FLG.equals(dateSerchType)) {
                // 直近12ヶ月の場合
                Calendar sysCal = Calendar.getInstance();
                int tmpYear = sysCal.get(Calendar.YEAR);
                int tmpMonth = sysCal.get(Calendar.MONTH) + 1;
                int tmpDate = sysCal.get(Calendar.DAY_OF_MONTH);
                int tmpHour = sysCal.get(Calendar.HOUR_OF_DAY);
                int tmpMin = sysCal.get(Calendar.MINUTE);
                if (Integer.valueOf(strStartDate.substring(8, 10)) < tmpDate) {
                    tmpMonth++;
                } else if (Integer.valueOf(strStartDate.substring(8, 10)) == tmpDate) {
                    // 開始日と同じ日の場合は、開始時間以上だったら次月
                    if (Integer.valueOf(strStartDate.substring(11, 13)) < tmpHour) {
                        tmpMonth++;
                    } else if (Integer.valueOf(strStartDate.substring(11, 13)) == tmpHour) {
                        if (Integer.valueOf(strStartDate.substring(14, 16)) <= tmpMin) {
                            tmpMonth++;
                        }
                    }
                } else {
                    // 開始日に再設定する
                    tmpDate = Integer.valueOf(strStartDate.substring(8, 10));
                }
                if (tmpMonth > 12) {
                    tmpYear++;
                    tmpMonth = 1;
                }
                strYear = CM_CommonUtil.paddingZero(tmpYear, 4);
                strMonth = CM_CommonUtil.paddingZero(tmpMonth, 2);
                strDay = CM_CommonUtil.paddingZero(tmpDate, 2);

                strTo = strYear
                        + FW00_19_Const.HYPHEN_STR
                        + strMonth
                        + FW00_19_Const.HYPHEN_STR
                        + strDay
                        + FW00_19_Const.SPACE
                        + this.getEndTime(strStartTime)
                        + ".999";

            } else {
                strYear = strTo.substring(0, 4);
                strMonth = strStartDate.substring(5, 7);
                strDay = strStartDate.substring(8,10);

                param = this.getEndDate(strYear, strMonth, strDay, - 1);
                strYear = param.get(0);

                if (strStartTime.equals("00:00:00")) {
                    // 始まりが00:00:00の場合は、終わりは前の日
                    param = this.getBeforeDay(strYear, strMonth, strDay);
                    strYear = param.get(0);
                    strMonth = param.get(1);
                    strDay = param.get(2);
                }

                strTo = strYear
                        + FW00_19_Const.HYPHEN_STR
                        + strMonth
                        + FW00_19_Const.HYPHEN_STR
                        + strDay
                        + FW00_19_Const.SPACE
                        + this.getEndTime(strStartTime)
                        + ".999";
            }
        }

        return strTo;
    }

    /**
     * 計画状態を取得する.
    * @param _formInfo
    *            Form情報
    * @return 計画状態（0～2:作業計画中、3～8:負荷計画中、9:計画完了、-1～-5:計画中止、-99:該当データなし）
     */
    public int getPlanStatus(final BeanMap _formInfo) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_formInfo", _formInfo);

        int ret = -99;

//        // 検索条件のセット
//        Map<String, Object> param = new HashMap<String, Object>();
//
//       // 工場コード
//        Object comPlantCode = _formInfo.get(CM_BaseForm.COM_PLANT_CODE);
//        if (CM_CommonUtil.isNotNullOrBlank(comPlantCode)) {
//            param.put(CM_BaseForm.COM_PLANT_CODE, comPlantCode.toString());
//        } else {
//            param.put(CM_BaseForm.COM_PLANT_CODE, null);
//        }
//
//        // 製造ラインコード
//        Object comSeizouLnId = _formInfo.get(CM_BaseForm.COM_SEIZOU_LN_ID);
//        if (CM_CommonUtil.isNotNullOrBlank(comSeizouLnId)) {
//            param.put(CM_BaseForm.COM_SEIZOU_LN_ID, comSeizouLnId.toString());
//        } else {
//            param.put(CM_BaseForm.COM_SEIZOU_LN_ID, null);
//        }
//
//        Integer retStatus = this.jdbcManager.selectBySqlFile(int.class,
//                BASE_SQL_PATH_COMM + "selectPlanStatus.sql", param).getSingleResult();
//        if (null != retStatus) {
//            ret = retStatus.intValue();
//        }

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return  ret;
    }
}
