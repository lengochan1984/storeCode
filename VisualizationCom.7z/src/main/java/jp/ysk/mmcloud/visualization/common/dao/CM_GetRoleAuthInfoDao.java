/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/05/02| 新規作成                           | 1.00.00| YSK)中田
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.dao;

import java.util.ArrayList;
import java.util.List;

import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.entity.customer.MstRoleSettingEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MstRoleSettingEntityNames;

import org.seasar.extension.jdbc.where.SimpleWhere;
import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.beans.util.Beans;

/**
 * {??クラス名??}.<br>
 *<br>
 * 概要:<br>
 *   {??クラス説明??}
 *<br>
 */
public class CM_GetRoleAuthInfoDao extends CM_BaseCustomerSchemaDao {

    /**
     * クエリタイムアウト(秒).
     * s2jdbc.diconのqueryTimeoutと設定をあわせること
     */
    private static final int QUERY_TIMEOUT = 55;

    /**
     * コンストラクタ.
     */
    public CM_GetRoleAuthInfoDao() {
        super();
    }

    /**
     * コンストラクタ.
     *
     * @param _strConnectString 顧客DB接続情報
     * @param _strConnectUserId 顧客DBユーザID
     * @param _strConnectPasswd 顧客DBパスワード
     */
    public CM_GetRoleAuthInfoDao(final String _strConnectString, final String _strConnectUserId,
            final String _strConnectPasswd) {
        super(_strConnectString, _strConnectUserId, _strConnectPasswd, QUERY_TIMEOUT);
    }

    /**
     *
     * 役割権限取得処理.<br>
     *<br>
     * 概要:<br>
     *   役割に設定された権限情報を取得する
     *<br>
     * @param _plantCode 工場コード
     * @return 役割権限情報
     */
    public List<BeanMap> selectRoleAuthInfo(final String _plantCode) {

        List<MstRoleSettingEntity> listEntity = this.selectRoleAuthInfoList(_plantCode);

        List<BeanMap> result = new ArrayList<BeanMap>();
        for (MstRoleSettingEntity entity : listEntity) {
            BeanMap bm = Beans.createAndCopy(BeanMap.class, entity).execute();
            result.add(bm);
        }
        return result;
    }

    /**
     *
     * 役割権限取得処理.<br>
     * <br>
     * 概要:<br>
     *   役割に設定された権限情報を取得する
     *<br>
     * @param _plantCode 工場コード
     * @return 役割権限情報
     */
    public List<MstRoleSettingEntity> selectRoleAuthInfoList(final String _plantCode) {

        List<MstRoleSettingEntity> listEntity = new ArrayList<MstRoleSettingEntity>();

//        SimpleWhere whereCond = new SimpleWhere();
//        String plantCd = CM_A04_Const.ALL_PLANT_CODE;
//        if (CM_CommonUtil.isNotNullOrBlank(_plantCode)) {
//            plantCd = _plantCode;
//        }
//        whereCond.eq(MstRoleSettingEntityNames.plantCode(), plantCd);
//        whereCond.eq(MstRoleSettingEntityNames.deleteFlag(), false);
//
//        List<MstRoleSettingEntity> listEntity = this.jdbcManager
//                .from(MstRoleSettingEntity.class)
//                .where(whereCond)
//                .orderBy("function_cd,page_id")
//                .getResultList();
        return listEntity;
    }
}
