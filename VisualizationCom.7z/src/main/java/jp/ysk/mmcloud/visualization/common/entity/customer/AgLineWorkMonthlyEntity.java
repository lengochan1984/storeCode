package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ライン計画/実績(月別)
 * 
 */
@Entity
@Table(name = "ag_line_work_monthly")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:31")
public class AgLineWorkMonthlyEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 製造ラインID */
    @Id
    @Column(precision = 8, nullable = false, unique = false)
    public BigDecimal seizouLnId;

    /** ラインID */
    @Id
    @Column(precision = 8, nullable = false, unique = false)
    public BigDecimal lnId;

    /** データ日時 */
    @Id
    @Column(nullable = false, unique = false)
    public Timestamp dataDate;

    /** プラントコード */
    @Column(length = 10, nullable = true, unique = false)
    public String plantCd;

    /** 製造ラインコード */
    @Column(length = 10, nullable = true, unique = false)
    public String seizouLnCd;

    /** 製造ライン名 */
    @Column(length = 64, nullable = true, unique = false)
    public String seizouLnNm;

    /** 工程コード */
    @Column(length = 5, nullable = true, unique = false)
    public String processCd;

    /** 工程名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String processNm;

    /** ラインNo */
    @Column(length = 32, nullable = true, unique = false)
    public String lnNo;

    /** ライン名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String lnNm;

    /** 更新日時 */
    @Column(nullable = true, unique = false)
    public Timestamp updDate;

    /** 計画数 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer planNum;

    /** 実績数 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer actualNum;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
