/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/05/02| 新規作成                           | 1.00.00| YSK)中田
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.dao;

import java.util.ArrayList;
import java.util.List;

import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaMenuItemsEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaMenuItemsEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaSettingMenuItemsEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaSettingMenuItemsEntityNames;

import org.seasar.extension.jdbc.where.SimpleWhere;
import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.beans.util.Beans;

/**
 * {??クラス名??}.<br>
 *<br>
 * 概要:<br>
 *   {??クラス説明??}
 *<br>
 */
public class CM_GetMenuAuthInfoDao extends CM_BaseCustomerSchemaDao {

    /**
     * クエリタイムアウト(秒).
     * s2jdbc.diconのqueryTimeoutと設定をあわせること
     */
    private static final int QUERY_TIMEOUT = 55;

    /**
     * コンストラクタ.
     */
    public CM_GetMenuAuthInfoDao() {
        super();
    }

    /**
     * コンストラクタ.
     *
     * @param _strConnectString 顧客DB接続情報
     * @param _strConnectUserId 顧客DBユーザID
     * @param _strConnectPasswd 顧客DBパスワード
     */
    public CM_GetMenuAuthInfoDao(final String _strConnectString, final String _strConnectUserId,
            final String _strConnectPasswd) {
        super(_strConnectString, _strConnectUserId, _strConnectPasswd, QUERY_TIMEOUT);
    }

    /**
     *
     * 役割権限取得処理.<br>
     *<br>
     * 概要:<br>
     *   役割に設定された権限情報を取得する
     *<br>
     * @param _plantCode 工場コード
     * @return 役割権限情報
     */
    public List<BeanMap> selectMenuAuthInfo(final String _plantCode) {

        List<MaMenuItemsEntity> listEntity = this.selectMenuAuthInfoList(_plantCode);

        List<BeanMap> result = new ArrayList<BeanMap>();
        for (MaMenuItemsEntity entity : listEntity) {
            BeanMap bm = Beans.createAndCopy(BeanMap.class, entity).execute();
            result.add(bm);
        }
        return result;
    }

    /**
     *
     * 役割権限取得処理.<br>
     * <br>
     * 概要:<br>
     *   役割に設定された権限情報を取得する
     *<br>
     * @param _plantCode 工場コード
     * @return 役割権限情報
     */
    public List<MaMenuItemsEntity> selectMenuAuthInfoList(final String _plantCode) {

        SimpleWhere whereCond = new SimpleWhere();
        String plantCd = CM_A04_Const.ALL_PLANT_CODE;
        if (CM_CommonUtil.isNotNullOrBlank(_plantCode)) {
            plantCd = _plantCode;
        }
        whereCond.eq(MaMenuItemsEntityNames.plantCd(), plantCd);

        List<MaMenuItemsEntity> listEntity = this.jdbcManager
                .from(MaMenuItemsEntity.class)
                .where(whereCond)
                .orderBy("function_cd,page_id")
                .getResultList();
        return listEntity;
    }

    /**
     *
     * 役割権限取得処理.<br>
     *<br>
     * 概要:<br>
     *   役割に設定された権限情報を取得する
     *<br>
     * @param _plantCode 工場コード
     * @param _workerAuth ユーザ権限
     * @return 設定権限情報
     */
    public List<BeanMap> selectSettingAuthInfo(final String _plantCode, final String _workerAuth) {

        List<MaSettingMenuItemsEntity> listEntity = this.selectSettingAuthInfoList(_plantCode, _workerAuth);

        List<BeanMap> result = new ArrayList<BeanMap>();
        for (MaSettingMenuItemsEntity entity : listEntity) {
            BeanMap bm = Beans.createAndCopy(BeanMap.class, entity).execute();
            result.add(bm);
        }
        return result;
    }

    /**
     *
     * 役割権限取得処理.<br>
     * <br>
     * 概要:<br>
     *   役割に設定された権限情報を取得する
     *<br>
     * @param _plantCode 工場コード
     * @param _workerAuth ユーザ権限
     * @return 設定権限情報
     */
    public List<MaSettingMenuItemsEntity> selectSettingAuthInfoList(final String _plantCode, final String _workerAuth) {

        SimpleWhere whereCond = new SimpleWhere();
        String plantCd = CM_A04_Const.ALL_PLANT_CODE;
        String workerAuth = _workerAuth;
        if (CM_CommonUtil.isNotNullOrBlank(_plantCode)) {
            plantCd = _plantCode;
        }
        whereCond.eq(MaSettingMenuItemsEntityNames.plantCd(), plantCd);
        whereCond.eq(MaSettingMenuItemsEntityNames.roleCd(), workerAuth);
//      whereCond.eq(MaSettingMenuItemsEntityNames.enableFlag(), "1");

        List<MaSettingMenuItemsEntity> listEntity = this.jdbcManager
                .from(MaSettingMenuItemsEntity.class)
                .where(whereCond)
                .orderBy("function_cd,page_id")
                .getResultList();
        return listEntity;
    }
}
