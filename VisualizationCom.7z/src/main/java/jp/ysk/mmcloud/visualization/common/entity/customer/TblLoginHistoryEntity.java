package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ログイン履歴データ
 * 
 */
@Entity
@Table(name = "tbl_login_history")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class TblLoginHistoryEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** ログイン日時 : ログインボタンを押下した日時 */
    @Id
    @Column(nullable = false, unique = false)
    public Timestamp loginDatetime;

    /** ユーザID : 入力されたユーザID */
    @Id
    @Column(length = 32, nullable = false, unique = false)
    public String inputUserId;

    /** 入力パスワード : 入力されたパスワード（暗号化後） */
    @Column(length = 256, nullable = true, unique = false)
    public String inputPasswd;

    /** ログイン成否 : true：ログイン成功
false：ログイン失敗 */
    @Column(length = 1, nullable = false, unique = false)
    public Boolean isSuccess;

    /** アクセスIPアドレス */
    @Column(length = 40, nullable = true, unique = false)
    public String accessIpAderess;

    /** ブラウザ種別 : ブラウザの種別判定文字列 */
    @Column(length = 256, nullable = true, unique = false)
    public String browserKind;

    /** 最終更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String lastUpdProg;

    /** 最終更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp lastUpdTim;
}
