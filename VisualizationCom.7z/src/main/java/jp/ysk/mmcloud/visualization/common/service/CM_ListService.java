/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/01/14| <40000-025> 変更仕様No.25 新規作成                                   | 4.00.00| US)萩尾
 *  2016/07/20| <C1.01>共通化対応取込                                                | C1.01  | US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.service;

import java.util.List;
import java.util.Map;

import jp.ysk.mmcloud.visualization.common.dao.CM_ListDao;

import org.seasar.framework.beans.util.BeanMap;

/**
 * 一覧画面共通サービス.<br>
 *<br>
 * 概要:<br>
 *   一覧画面共通処理のサービスクラス
 *<br>
 */
public abstract class CM_ListService extends CM_ListBaseService {

    /**
     *
     * データ件数取得.<br>
     *<br>
     * 概要:<br>
     *   一覧のデータ件数を取得する<br>
     *   dao.selectListCountを呼び出す
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return 件数
     */
    public long getDataCount(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        return this.getCustomerDao().selectListCount(_formInfo, _mapSearchCondInfo);
    };

    /**
     *
     * 一覧データ取得.<br>
     *<br>
     * 概要:<br>
     *   一覧のデータ件数を取得する<br>
     *   dao.selectListを呼び出す
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @param _offsetInfo オフセット情報
     * @return 抽出データ
     */
    public List<?> getDataList(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo, final Map<String, Integer> _offsetInfo) {
        List<?> listData = this.getCustomerDao().selectList(_formInfo, _mapSearchCondInfo, _offsetInfo);
        List<?> ret = this.createDspData(listData);
        return ret;
    };

    /**
     * ソートキー取得処理.<br>
     *<br>
     * 概要:<br>
     *   一覧用のソートキーを生成して渡します。
     *<br>
     * @return ソートキーマップ
     */
    public abstract BeanMap getSortKeyNames();

    /**
     * 画面データアクセスDaoを取得.<br>
     * <br>
     * 概要:<br>
     *   画面データアクセスDaoを取得
     *
     *
     * @return 画面データアクセスDao
     */
    @Override
    protected abstract CM_ListDao getCustomerDao();

    @Override
    protected List<?> getExportExcelData(final BeanMap _formInfo) {
        return null;
    };

    /**
     *
     * 取得データの加工処理.<br>
     *<br>
     * 概要:<br>
     *   取得データの加工処理
     *<br>
     * @param _listData 取得データ
     * @return 表示用データ
     */
    protected List<?> createDspData(final List<?> _listData) {
        return _listData;
    }

    /**
     *
     * 入力チェック処理.<br/>
     * <br/>
     * 概要:<br/>
     *  入力チェック処理を行う。<br/>
     *  エラーがある場合、例外をThrowする。<br/>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     */
    public void validate(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        return;
    }

    /**
     *
     * CSV入力チェック処理.<br/>
     * <br/>
     * 概要:<br/>
     *  CSV入力チェック処理を行う。<br/>
     *  エラーがある場合、例外をThrowする。<br/>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     */
    public void csvValidate(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        return;
    }
}
