package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link SysEnvEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class SysEnvEntityNames {

    /**
     * envCdのプロパティ名を返します。
     * 
     * @return envCdのプロパティ名
     */
    public static PropertyName<String> envCd() {
        return new PropertyName<String>("envCd");
    }

    /**
     * itemCdのプロパティ名を返します。
     * 
     * @return itemCdのプロパティ名
     */
    public static PropertyName<String> itemCd() {
        return new PropertyName<String>("itemCd");
    }

    /**
     * nameのプロパティ名を返します。
     * 
     * @return nameのプロパティ名
     */
    public static PropertyName<String> name() {
        return new PropertyName<String>("name");
    }

    /**
     * abbNameのプロパティ名を返します。
     * 
     * @return abbNameのプロパティ名
     */
    public static PropertyName<String> abbName() {
        return new PropertyName<String>("abbName");
    }

    /**
     * nameItemCdのプロパティ名を返します。
     * 
     * @return nameItemCdのプロパティ名
     */
    public static PropertyName<String> nameItemCd() {
        return new PropertyName<String>("nameItemCd");
    }

    /**
     * defaultFlagのプロパティ名を返します。
     * 
     * @return defaultFlagのプロパティ名
     */
    public static PropertyName<String> defaultFlag() {
        return new PropertyName<String>("defaultFlag");
    }

    /**
     * displayOrderのプロパティ名を返します。
     * 
     * @return displayOrderのプロパティ名
     */
    public static PropertyName<Integer> displayOrder() {
        return new PropertyName<Integer>("displayOrder");
    }

    /**
     * remarkのプロパティ名を返します。
     * 
     * @return remarkのプロパティ名
     */
    public static PropertyName<String> remark() {
        return new PropertyName<String>("remark");
    }

    /**
     * deleteFlagのプロパティ名を返します。
     * 
     * @return deleteFlagのプロパティ名
     */
    public static PropertyName<Boolean> deleteFlag() {
        return new PropertyName<Boolean>("deleteFlag");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _SysEnvNames extends PropertyName<SysEnvEntity> {

        /**
         * インスタンスを構築します。
         */
        public _SysEnvNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _SysEnvNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _SysEnvNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * envCdのプロパティ名を返します。
         *
         * @return envCdのプロパティ名
         */
        public PropertyName<String> envCd() {
            return new PropertyName<String>(this, "envCd");
        }

        /**
         * itemCdのプロパティ名を返します。
         *
         * @return itemCdのプロパティ名
         */
        public PropertyName<String> itemCd() {
            return new PropertyName<String>(this, "itemCd");
        }

        /**
         * nameのプロパティ名を返します。
         *
         * @return nameのプロパティ名
         */
        public PropertyName<String> name() {
            return new PropertyName<String>(this, "name");
        }

        /**
         * abbNameのプロパティ名を返します。
         *
         * @return abbNameのプロパティ名
         */
        public PropertyName<String> abbName() {
            return new PropertyName<String>(this, "abbName");
        }

        /**
         * nameItemCdのプロパティ名を返します。
         *
         * @return nameItemCdのプロパティ名
         */
        public PropertyName<String> nameItemCd() {
            return new PropertyName<String>(this, "nameItemCd");
        }

        /**
         * defaultFlagのプロパティ名を返します。
         *
         * @return defaultFlagのプロパティ名
         */
        public PropertyName<String> defaultFlag() {
            return new PropertyName<String>(this, "defaultFlag");
        }

        /**
         * displayOrderのプロパティ名を返します。
         *
         * @return displayOrderのプロパティ名
         */
        public PropertyName<Integer> displayOrder() {
            return new PropertyName<Integer>(this, "displayOrder");
        }

        /**
         * remarkのプロパティ名を返します。
         *
         * @return remarkのプロパティ名
         */
        public PropertyName<String> remark() {
            return new PropertyName<String>(this, "remark");
        }

        /**
         * deleteFlagのプロパティ名を返します。
         *
         * @return deleteFlagのプロパティ名
         */
        public PropertyName<Boolean> deleteFlag() {
            return new PropertyName<Boolean>(this, "deleteFlag");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
