/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/12/08| <C1.01>　新規作成                                                    | C1.01  | (US)甲斐
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;

import org.seasar.framework.util.StringUtil;

/**
 * HOME検索機能 セッション保持情報.
 */
public class CM_A12_HomeSearchInfo implements Serializable {

    /** シリアルバージョンUID. */
    private static final long serialVersionUID = 1L;

    /**
     * 共通セッション保存対象パラメータ定義(変更時プルダウン再作成対象).
     */
    private static final String[] COM_SAVE_PARAM_DEF = {
            // グループ(製造ラインID)
            CM_BaseForm.COM_SEIZOU_LN_ID
            // 工程ID
            , CM_BaseForm.COM_PROCESS_ID
            // ラインID
            , CM_BaseForm.COM_LN_ID
    };

    /* **************************************/
    // プルダウン
    /* **************************************/
    /**
     * 工場プルダウン.
     */
    public  List<Map<String, String>> pldPlantList = new ArrayList<Map<String, String>>();

    /**
     * グループ(製造ライン)プルダウン.
     */
    public List<Map<String, String>> pldSeizouLineList = new ArrayList<Map<String, String>>();

    /**
     * ラインプルダウン.
     */
    public List<Map<String, String>> pldLineList = new ArrayList<Map<String, String>>();

    /**
     * 工程プルダウン.
     */
    public List<Map<String, String>> pldProcessList = new ArrayList<Map<String, String>>();

    /**
     * プルダウンにデータが存在するかを確認.
     * @return true:データ存在
     */
    public boolean hasPldData() {
        boolean res = false;
        if (!this.pldPlantList.isEmpty()
                || !this.pldSeizouLineList.isEmpty()
                || !this.pldLineList.isEmpty()
                || !this.pldProcessList.isEmpty()) {
            res = true;
        }
        return res;
    }

    /* **************************************/
    // 検索情報
    /* **************************************/
    /**
     * HOME検索情報保持マップ.
     */
    private Map<String, String> homeSearchCondRemMap = new HashMap<String, String>();
    /**
     * 画面別検索情報保持マップ.
     */
    private Map<String, String> pageSearchCondRemMap = new HashMap<String, String>();
    /**
     * HOME検索情報保持マップ.
     */
    private CM_A10_SearchPldTypeInfo searchPldType = null;

    /**
     * 検索済情報取得.
     * @param _key 項目キー
     * @return 検索済情報
     */
    public String getHomeSearchCondRem(final String _key) {
        return this.homeSearchCondRemMap.get(_key);
    }

    /**
     * HOME検索情報保存.
     * @param _form 画面Form
     */
    public void saveHomeSearchCondRem(final CM_BaseForm _form) {
        this.homeSearchCondRemMap = this.makeHomeSearchCondRemMap(_form);
        this.searchPldType = _form.getComSearchPldType();
    }

    /**
     * 保持している検索情報とFormの検索情報が同じかどうかを比較.
     * @param _form 画面Form
     * @return 比較結果
     */
    public boolean isSameHomeSearchCondRem(final CM_BaseForm _form) {
        if (this.homeSearchCondRemMap.isEmpty()) {
            return false;
        }
        boolean same = true;
        Map<String, String> searchMap = this.makeHomeSearchCondRemMap(_form);
        for (Map.Entry<String, String> homeRemInfo : this.homeSearchCondRemMap.entrySet()) {
            String remKey = homeRemInfo.getKey();
            String remVal = homeRemInfo.getValue();
            String val = searchMap.get(remKey);
            if (!StringUtil.equals(remVal, val)) {
                same = false;
                break;
            }
            searchMap.remove(remKey);
        }
        if (!searchMap.isEmpty()) {
            same = false;
        }
//        // プルダウン状態も確認
//        if (same) {
//            if (!_form.isSameSearchPldTypeInfo(this.searchPldType)) {
//                same = false;
//            }
//        }
        return same;
    }

    /**
     * 記憶した情報をFormに復元する.
     * @param _form 画面Form
     */
    public void restorHomeSearchCond(final CM_BaseForm _form) {
        // 変数の値をセッションから復元(変更時リスト再作成対象).
        for (String fieldName : COM_SAVE_PARAM_DEF) {
            this.restoreHomeParam(_form, fieldName);
        }
    }

    /**
     * HOME検索情報マップ作成(変更時プルダウン再作成対象).
     * @param _form 画面Form
     * @return 共通検索情報マップ
     */
    private Map<String, String> makeHomeSearchCondRemMap(final CM_BaseForm _form) {
        Map<String, String> remMap = new HashMap<String, String>();
        String val;
        String valSaved;

        // HOME検索情報保存
        for (String fieldName : COM_SAVE_PARAM_DEF) {
            val = getParam(_form, fieldName);
            remMap.put(fieldName, val);
        }

        // 画面別検索情報保存
        for (String fieldName : this.homeSearchCondRemMap.keySet()) {
            if ((fieldName.equals(COM_SAVE_PARAM_DEF[0]))
                    || (fieldName.equals(COM_SAVE_PARAM_DEF[1]))
                    || (fieldName.equals(COM_SAVE_PARAM_DEF[2]))
                    || (fieldName.equals(COM_SAVE_PARAM_DEF[3]))) {
                continue;
            }

            val = getParam(_form, fieldName);
            valSaved = this.homeSearchCondRemMap.get(fieldName);
            if (CM_CommonUtil.isNotNullOrBlank(val)) {
                remMap.put(fieldName, val);
            } else {
                remMap.put(fieldName, valSaved);
            }
        }

        return remMap;
    }

    /**
     * 変数の値をセッションに保存.
     * @param _form FORMオブジェクト
     * @param _fieldName 項目名
     */
    public void saveParam(final CM_BaseForm _form, final String _fieldName) {
        this.pageSearchCondRemMap.put(_fieldName, CM_A12_HomeSearchInfo.getParam(_form, _fieldName));
    }
    /**
     * 変数の値をセッションから復元.
     * @param _form FORMオブジェクト
     * @param _fieldName 項目名
     */
    public void restoreParam(final CM_BaseForm _form, final String _fieldName) {
        if (!this.checkHasField(_form, _fieldName)) {
            return;
        }
        if (this.pageSearchCondRemMap.containsKey(_fieldName)) {
            CM_A12_HomeSearchInfo.setParam(_form, _fieldName, this.homeSearchCondRemMap.get(_fieldName));
        } else {
            this.saveParam(_form, _fieldName);
        }
    }

    /**
     * 変数の値をセッションに保存.
     * @param _form FORMオブジェクト
     * @param _fieldName 項目名
     */
    private void saveHomeParam(final CM_BaseForm _form, final String _fieldName) {
        this.homeSearchCondRemMap.put(_fieldName, CM_A12_HomeSearchInfo.getParam(_form, _fieldName));
    }
    /**
     * 変数の値をセッションから復元(変更時リスト再作成対象).
     * @param _form FORMオブジェクト
     * @param _fieldName 項目名
     */
    private void restoreHomeParam(final CM_BaseForm _form, final String _fieldName) {
        if (!this.checkHasField(_form, _fieldName)) {
            return;
        }
        if (this.homeSearchCondRemMap.containsKey(_fieldName)) {
            CM_A12_HomeSearchInfo.setParam(_form, _fieldName, this.homeSearchCondRemMap.get(_fieldName));
        } else {
            this.saveParam(_form, _fieldName);
        }
    }

    /**
     * FORMに変数が定義されているかどうかを確認.
     * @param _form FORMオブジェクト
     * @param _fieldName 項目名
     * @return 結果
     */
    private boolean checkHasField(final Object _form, final String _fieldName) {
        boolean res = false;
        try {
            Field field = _form.getClass().getField(_fieldName);
            String name = field.getName();
            if (CM_CommonUtil.isNotNullOrBlank(name)) {
                res = true;
            }
        } catch (Exception e) {
        }
        return res;
    }

    /**
     * FORMから値を取得.
     * @param _form FORMオブジェクト
     * @param _fieldName 項目名
     * @return 	値
     */
    public static String getParam(final Object _form, final String _fieldName) {
        String val = null;
        try {
            Field field = _form.getClass().getField(_fieldName);
            Object valObj = field.get(_form);
            if (valObj != null) {
                val = valObj.toString();
            }
        } catch (Exception e) {
        }
        return val;
    }
    /**
     * FORMに値を設定.
     * @param _form FORMオブジェクト
     * @param _fieldName 項目名
     * @param _value 値
     */
    public static void setParam(final Object _form, final String _fieldName, final Object _value) {
        try {
            Field field = _form.getClass().getField(_fieldName);
            field.set(_form, _value);
        } catch (Exception e) {
        }
    }
}
