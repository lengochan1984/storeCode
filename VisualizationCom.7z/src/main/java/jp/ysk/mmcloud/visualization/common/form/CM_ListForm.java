/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/07/20| <C1.01>　新規作成（共通化対応取込）                                  | C1.01  | US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.form;

import org.apache.struts.upload.FormFile;

/**
*
* 一覧画面基底ActionForm.<br>
*<br>
* 概要:<br>
*  Listフォームクラスの最上位の親クラスで、フレームワークの共通処理を実装します
*<br>
*/
public class CM_ListForm extends CM_BaseForm {

    //*********************************************
    //プロパティ名Const
    //*********************************************

    /**
     * 型番SID：modelSid.<BR>
     * ※アラームアイコン取得用
     */
    public static final String FW0114FORM_MODELSID = "fw0114ModelSid";

    /**
     * アイコンタイプ：iconType.<BR>
     * ※アラームアイコン取得用
     */
    public static final String FW0114FORM_ICONTYPE = "fw0114IconType";

    /**
     *  更新タイミング：txtUpdateTiming.
     */
    public static final String CM_LISTFORM_TXTUPDATETIMING = "txtUpdateTiming";

    /**
     * Excel出力種別.
     */
    public static final String CM_LISTFORM_HDN_EXPORT_EXCEL_TYPE = "hdnExportExcelType";


    //*********************************************
    //プロパティ名宣言
    //*********************************************
    /**
     * アップロードファイル.
     */
    public FormFile uploadCsvFile;

    /**
     * 更新タイミング.
     */
    public String txtUpdateTiming;

    /**
     * Excel出力種別.
     */
    public String hdnExportExcelType;


}
