package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ライン稼働状況レイアウト
 * 
 */
@Entity
@Table(name = "tr_line_layout")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class TrLineLayoutEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** ラインID */
    @Id
    @Column(precision = 8, nullable = false, unique = true)
    public BigDecimal lnId;

    /** 縦ページ位置 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer vertPagePos;

    /** 横ページ位置 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer horiPagePos;

    /** 縦フレーム位置 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer vertFramePos;

    /** 横フレーム位置 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer horiFramePos;

    /** レイアウトID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer layoutId;

    /** 矢印1表示有効/無効 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer dispAllow1Enable;

    /** 矢印2表示有効/無効 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer dispAllow2Enable;

    /** 矢印3表示有効/無効 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer dispAllow3Enable;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
