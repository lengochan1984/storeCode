/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/17| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common;

/**
 *
 * ExcelのCell書式タイプ.<br>
 *<br>
 * 概要:<br>
 *  Excelの書式タイプ定義<br>
 *  数値、文字列、計算式、空白セル、真偽値、エラーの定義は
 *  org.apache.poi.ss.usermodel.CellのCellTypeの定義と同値を定義している為、変更不可
 *<br>
 */
public abstract class CM_A07_ExcelCellType {

    /**
     * 数値型.
     */
    public static final int CELL_TYPE_NUMERIC = 0;

    /**
     * 文字列型.
     */
    public static final int CELL_TYPE_STRING = 1;

    /**
     * 計算式.
     */
    public static final int CELL_TYPE_FORMULA = 2;

    /**
     * 空白セル.
     */
    public static final int CELL_TYPE_BLANK = 3;

    /**
     * 真偽値.
     */
    public static final int CELL_TYPE_BOOLEAN = 4;

    /**
     * エラー.
     */
    public static final int CELL_TYPE_ERROR = 5;

    /**
     * 日付型.
     */
    public static final int CELL_TYPE_DATE = 6;

}
