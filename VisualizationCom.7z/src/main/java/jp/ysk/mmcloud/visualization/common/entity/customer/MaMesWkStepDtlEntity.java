package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * MES作業STEP詳細
 * 
 */
@Entity
@Table(name = "ma_mes_wk_step_dtl")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class MaMesWkStepDtlEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 登録日時 */
    @Column(nullable = true, unique = false)
    public Timestamp createdOn;

    /** 登録者 */
    @Column(length = 32, nullable = true, unique = false)
    public String createdBy;

    /** 更新日時 */
    @Column(nullable = true, unique = false)
    public Timestamp modifiedOn;

    /** 更新者 */
    @Column(length = 32, nullable = true, unique = false)
    public String modifiedBy;

    /** 無効フラグ */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer invalidFlag;

    /** 作業パターンID */
    @Id
    @Column(precision = 8, nullable = false, unique = false)
    public BigDecimal jobPtnId;

    /** 通し番号 */
    @Column(precision = 5, nullable = false, unique = false)
    public BigDecimal jobNo;

    /** 作業順序 */
    @Column(length = 6, nullable = true, unique = false)
    public String sagyoSeq;

    /** 作業活動番号 */
    @Column(length = 4, nullable = true, unique = false)
    public String sagyoNo;

    /** 作業STEP */
    @Id
    @Column(length = 8, nullable = false, unique = false)
    public String stepNo;

    /** ステーションID */
    @Column(precision = 8, nullable = true, unique = false)
    public BigDecimal stId;

    /** 設備STEP */
    @Column(length = 8, nullable = true, unique = false)
    public String machineStep;

    /** 設備プログラム番号 */
    @Column(length = 32, nullable = true, unique = false)
    public String pgmNo;

    /** 標準工数(高) */
    @Column(precision = 8, nullable = true, unique = false)
    public BigDecimal stdHourHigh;

    /** 標準工数(中) */
    @Column(precision = 8, nullable = true, unique = false)
    public BigDecimal stdHourMiddle;

    /** 標準工数(低) */
    @Column(precision = 8, nullable = true, unique = false)
    public BigDecimal stdHourLow;

    /** シーケンス番号 */
    @Column(precision = 5, nullable = true, unique = false)
    public BigDecimal seqNo;

    /** 任意作業STEP */
    @Column(length = 1, nullable = true, unique = false)
    public String optionStep;

    /** 数字予備1 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum1;

    /** 数字予備2 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum2;

    /** 数字予備3 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum3;

    /** 文字予備1 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText1;

    /** 文字予備2 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText2;

    /** 文字予備3 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText3;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
