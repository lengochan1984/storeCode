package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link TrStWorkDetailEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class TrStWorkDetailEntityNames {

    /**
     * createdOnのプロパティ名を返します。
     * 
     * @return createdOnのプロパティ名
     */
    public static PropertyName<Timestamp> createdOn() {
        return new PropertyName<Timestamp>("createdOn");
    }

    /**
     * createdByのプロパティ名を返します。
     * 
     * @return createdByのプロパティ名
     */
    public static PropertyName<String> createdBy() {
        return new PropertyName<String>("createdBy");
    }

    /**
     * modifiedOnのプロパティ名を返します。
     * 
     * @return modifiedOnのプロパティ名
     */
    public static PropertyName<Timestamp> modifiedOn() {
        return new PropertyName<Timestamp>("modifiedOn");
    }

    /**
     * modifiedByのプロパティ名を返します。
     * 
     * @return modifiedByのプロパティ名
     */
    public static PropertyName<String> modifiedBy() {
        return new PropertyName<String>("modifiedBy");
    }

    /**
     * sasizuNoのプロパティ名を返します。
     * 
     * @return sasizuNoのプロパティ名
     */
    public static PropertyName<String> sasizuNo() {
        return new PropertyName<String>("sasizuNo");
    }

    /**
     * subNoのプロパティ名を返します。
     * 
     * @return subNoのプロパティ名
     */
    public static PropertyName<BigDecimal> subNo() {
        return new PropertyName<BigDecimal>("subNo");
    }

    /**
     * stIdのプロパティ名を返します。
     * 
     * @return stIdのプロパティ名
     */
    public static PropertyName<BigDecimal> stId() {
        return new PropertyName<BigDecimal>("stId");
    }

    /**
     * jobPtnIdのプロパティ名を返します。
     * 
     * @return jobPtnIdのプロパティ名
     */
    public static PropertyName<BigDecimal> jobPtnId() {
        return new PropertyName<BigDecimal>("jobPtnId");
    }

    /**
     * sagyoNoのプロパティ名を返します。
     * 
     * @return sagyoNoのプロパティ名
     */
    public static PropertyName<String> sagyoNo() {
        return new PropertyName<String>("sagyoNo");
    }

    /**
     * stepNoのプロパティ名を返します。
     * 
     * @return stepNoのプロパティ名
     */
    public static PropertyName<String> stepNo() {
        return new PropertyName<String>("stepNo");
    }

    /**
     * optionStepのプロパティ名を返します。
     * 
     * @return optionStepのプロパティ名
     */
    public static PropertyName<String> optionStep() {
        return new PropertyName<String>("optionStep");
    }

    /**
     * productEndのプロパティ名を返します。
     * 
     * @return productEndのプロパティ名
     */
    public static PropertyName<Short> productEnd() {
        return new PropertyName<Short>("productEnd");
    }

    /**
     * processEndのプロパティ名を返します。
     * 
     * @return processEndのプロパティ名
     */
    public static PropertyName<Short> processEnd() {
        return new PropertyName<Short>("processEnd");
    }

    /**
     * sagyokuEndのプロパティ名を返します。
     * 
     * @return sagyokuEndのプロパティ名
     */
    public static PropertyName<Short> sagyokuEnd() {
        return new PropertyName<Short>("sagyokuEnd");
    }

    /**
     * lineEndのプロパティ名を返します。
     * 
     * @return lineEndのプロパティ名
     */
    public static PropertyName<Short> lineEnd() {
        return new PropertyName<Short>("lineEnd");
    }

    /**
     * stationStatusのプロパティ名を返します。
     * 
     * @return stationStatusのプロパティ名
     */
    public static PropertyName<Short> stationStatus() {
        return new PropertyName<Short>("stationStatus");
    }

    /**
     * lineOutInのプロパティ名を返します。
     * 
     * @return lineOutInのプロパティ名
     */
    public static PropertyName<Short> lineOutIn() {
        return new PropertyName<Short>("lineOutIn");
    }

    /**
     * jogaiのプロパティ名を返します。
     * 
     * @return jogaiのプロパティ名
     */
    public static PropertyName<Short> jogai() {
        return new PropertyName<Short>("jogai");
    }

    /**
     * buildoutのプロパティ名を返します。
     * 
     * @return buildoutのプロパティ名
     */
    public static PropertyName<Short> buildout() {
        return new PropertyName<Short>("buildout");
    }

    /**
     * qtyのプロパティ名を返します。
     * 
     * @return qtyのプロパティ名
     */
    public static PropertyName<Integer> qty() {
        return new PropertyName<Integer>("qty");
    }

    /**
     * spareNum1のプロパティ名を返します。
     * 
     * @return spareNum1のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum1() {
        return new PropertyName<BigDecimal>("spareNum1");
    }

    /**
     * spareNum2のプロパティ名を返します。
     * 
     * @return spareNum2のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum2() {
        return new PropertyName<BigDecimal>("spareNum2");
    }

    /**
     * spareNum3のプロパティ名を返します。
     * 
     * @return spareNum3のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum3() {
        return new PropertyName<BigDecimal>("spareNum3");
    }

    /**
     * spareText1のプロパティ名を返します。
     * 
     * @return spareText1のプロパティ名
     */
    public static PropertyName<String> spareText1() {
        return new PropertyName<String>("spareText1");
    }

    /**
     * spareText2のプロパティ名を返します。
     * 
     * @return spareText2のプロパティ名
     */
    public static PropertyName<String> spareText2() {
        return new PropertyName<String>("spareText2");
    }

    /**
     * spareText3のプロパティ名を返します。
     * 
     * @return spareText3のプロパティ名
     */
    public static PropertyName<String> spareText3() {
        return new PropertyName<String>("spareText3");
    }

    /**
     * lnStsFrameのプロパティ名を返します。
     * 
     * @return lnStsFrameのプロパティ名
     */
    public static PropertyName<Integer> lnStsFrame() {
        return new PropertyName<Integer>("lnStsFrame");
    }

    /**
     * lnStsIconのプロパティ名を返します。
     * 
     * @return lnStsIconのプロパティ名
     */
    public static PropertyName<Integer> lnStsIcon() {
        return new PropertyName<Integer>("lnStsIcon");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _TrStWorkDetailNames extends PropertyName<TrStWorkDetailEntity> {

        /**
         * インスタンスを構築します。
         */
        public _TrStWorkDetailNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _TrStWorkDetailNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _TrStWorkDetailNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * createdOnのプロパティ名を返します。
         *
         * @return createdOnのプロパティ名
         */
        public PropertyName<Timestamp> createdOn() {
            return new PropertyName<Timestamp>(this, "createdOn");
        }

        /**
         * createdByのプロパティ名を返します。
         *
         * @return createdByのプロパティ名
         */
        public PropertyName<String> createdBy() {
            return new PropertyName<String>(this, "createdBy");
        }

        /**
         * modifiedOnのプロパティ名を返します。
         *
         * @return modifiedOnのプロパティ名
         */
        public PropertyName<Timestamp> modifiedOn() {
            return new PropertyName<Timestamp>(this, "modifiedOn");
        }

        /**
         * modifiedByのプロパティ名を返します。
         *
         * @return modifiedByのプロパティ名
         */
        public PropertyName<String> modifiedBy() {
            return new PropertyName<String>(this, "modifiedBy");
        }

        /**
         * sasizuNoのプロパティ名を返します。
         *
         * @return sasizuNoのプロパティ名
         */
        public PropertyName<String> sasizuNo() {
            return new PropertyName<String>(this, "sasizuNo");
        }

        /**
         * subNoのプロパティ名を返します。
         *
         * @return subNoのプロパティ名
         */
        public PropertyName<BigDecimal> subNo() {
            return new PropertyName<BigDecimal>(this, "subNo");
        }

        /**
         * stIdのプロパティ名を返します。
         *
         * @return stIdのプロパティ名
         */
        public PropertyName<BigDecimal> stId() {
            return new PropertyName<BigDecimal>(this, "stId");
        }

        /**
         * jobPtnIdのプロパティ名を返します。
         *
         * @return jobPtnIdのプロパティ名
         */
        public PropertyName<BigDecimal> jobPtnId() {
            return new PropertyName<BigDecimal>(this, "jobPtnId");
        }

        /**
         * sagyoNoのプロパティ名を返します。
         *
         * @return sagyoNoのプロパティ名
         */
        public PropertyName<String> sagyoNo() {
            return new PropertyName<String>(this, "sagyoNo");
        }

        /**
         * stepNoのプロパティ名を返します。
         *
         * @return stepNoのプロパティ名
         */
        public PropertyName<String> stepNo() {
            return new PropertyName<String>(this, "stepNo");
        }

        /**
         * optionStepのプロパティ名を返します。
         *
         * @return optionStepのプロパティ名
         */
        public PropertyName<String> optionStep() {
            return new PropertyName<String>(this, "optionStep");
        }

        /**
         * productEndのプロパティ名を返します。
         *
         * @return productEndのプロパティ名
         */
        public PropertyName<Short> productEnd() {
            return new PropertyName<Short>(this, "productEnd");
        }

        /**
         * processEndのプロパティ名を返します。
         *
         * @return processEndのプロパティ名
         */
        public PropertyName<Short> processEnd() {
            return new PropertyName<Short>(this, "processEnd");
        }

        /**
         * sagyokuEndのプロパティ名を返します。
         *
         * @return sagyokuEndのプロパティ名
         */
        public PropertyName<Short> sagyokuEnd() {
            return new PropertyName<Short>(this, "sagyokuEnd");
        }

        /**
         * lineEndのプロパティ名を返します。
         *
         * @return lineEndのプロパティ名
         */
        public PropertyName<Short> lineEnd() {
            return new PropertyName<Short>(this, "lineEnd");
        }

        /**
         * stationStatusのプロパティ名を返します。
         *
         * @return stationStatusのプロパティ名
         */
        public PropertyName<Short> stationStatus() {
            return new PropertyName<Short>(this, "stationStatus");
        }

        /**
         * lineOutInのプロパティ名を返します。
         *
         * @return lineOutInのプロパティ名
         */
        public PropertyName<Short> lineOutIn() {
            return new PropertyName<Short>(this, "lineOutIn");
        }

        /**
         * jogaiのプロパティ名を返します。
         *
         * @return jogaiのプロパティ名
         */
        public PropertyName<Short> jogai() {
            return new PropertyName<Short>(this, "jogai");
        }

        /**
         * buildoutのプロパティ名を返します。
         *
         * @return buildoutのプロパティ名
         */
        public PropertyName<Short> buildout() {
            return new PropertyName<Short>(this, "buildout");
        }

        /**
         * qtyのプロパティ名を返します。
         *
         * @return qtyのプロパティ名
         */
        public PropertyName<Integer> qty() {
            return new PropertyName<Integer>(this, "qty");
        }

        /**
         * spareNum1のプロパティ名を返します。
         *
         * @return spareNum1のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum1() {
            return new PropertyName<BigDecimal>(this, "spareNum1");
        }

        /**
         * spareNum2のプロパティ名を返します。
         *
         * @return spareNum2のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum2() {
            return new PropertyName<BigDecimal>(this, "spareNum2");
        }

        /**
         * spareNum3のプロパティ名を返します。
         *
         * @return spareNum3のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum3() {
            return new PropertyName<BigDecimal>(this, "spareNum3");
        }

        /**
         * spareText1のプロパティ名を返します。
         *
         * @return spareText1のプロパティ名
         */
        public PropertyName<String> spareText1() {
            return new PropertyName<String>(this, "spareText1");
        }

        /**
         * spareText2のプロパティ名を返します。
         *
         * @return spareText2のプロパティ名
         */
        public PropertyName<String> spareText2() {
            return new PropertyName<String>(this, "spareText2");
        }

        /**
         * spareText3のプロパティ名を返します。
         *
         * @return spareText3のプロパティ名
         */
        public PropertyName<String> spareText3() {
            return new PropertyName<String>(this, "spareText3");
        }

        /**
         * lnStsFrameのプロパティ名を返します。
         *
         * @return lnStsFrameのプロパティ名
         */
        public PropertyName<Integer> lnStsFrame() {
            return new PropertyName<Integer>(this, "lnStsFrame");
        }

        /**
         * lnStsIconのプロパティ名を返します。
         *
         * @return lnStsIconのプロパティ名
         */
        public PropertyName<Integer> lnStsIcon() {
            return new PropertyName<Integer>(this, "lnStsIcon");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
