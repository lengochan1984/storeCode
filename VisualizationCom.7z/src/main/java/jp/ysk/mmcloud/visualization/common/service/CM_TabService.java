/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/07/27| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 *  2017/06/09| <C1.02>　CSV出力にてSQL検索時にLIMITをつける対応                     | C1.02  | YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.service;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.common.util.CM_DisplayCharResourceUtil;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.CM_A06_TabInfo;
import jp.ysk.mmcloud.visualization.common.dao.CM_TabDao;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;

import org.seasar.framework.beans.util.BeanMap;

/**
 *
 * タブがある画面共通サービス.<br>
 *<br>
 * 概要:<br>
 *  タブがある画面共通サービスクラス
 *<br>
 */
public abstract class CM_TabService extends CM_ListBaseService {

    /**
     * 一覧系の一覧件数取得の共通メソッド名.
     */
    protected static final String COMMON_PRE_SELECT_METHOD_NAME = "PreSelect";

    /**
     * 一覧系の一覧件数取得の共通メソッド名.
     */
    protected static final String COMMON_SELECT_COUNT_METHOD_NAME = "SelectListCount";

    /**
     * 一覧系の一覧取得の共通メソッド名.
     */
    protected static final String COMMON_SELECT_LIST_METHOD_NAME = "SelectList";

    /**
     * 一覧系のデータ加工処理の共通メソッド名.
     */
    protected static final String COMMON_CREATE_DSP_DATA_METHOD_NAME = "CreateDspData";

    /**
     * 一覧系の一覧取得の共通メソッド名.
     */
    protected static final String COMMON_GET_CSV_SEARCH_CONDITION_METHOD_NAME = "GetCsvSearchCondition";

    /**
     * タブ情報.
     */
    private CM_A06_TabInfo tabInfo;

    /**
     *
     * 一覧検索の前処理.<br>
     *<br>
     * 概要:<br>
     *   一覧の検索時に実行する前処理
     *   ServiceのtabId + 「PreSelect」のメソッドを呼び出す<br>
     *   例：タブIDがoperationListの場合、ServiceのoperationListPreSelectのメソッドを呼び出す
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     */
    @Override
    public void preGetData(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {

        try {
            // tabId + 「PreSelect」のメソッドを呼び出し処理
            Method method = this.getClass().getMethod(this.getTabInfo().getTabId() + COMMON_PRE_SELECT_METHOD_NAME,
                    new Class[]{BeanMap.class, Map.class});

            method.invoke(this, new Object[]{_formInfo, _mapSearchCondInfo});

        } catch (NoSuchMethodException nsm) {
            // メソッドが無い場合は処理なし
        } catch (InvocationTargetException | IllegalAccessException e) {
            CM_LoggerUtil.outputErrorLog(this.sessionDto, e, FW00_19_Const.EMPTY_STR);
        }

    };

    /**
     *
     * データ件数取得.<br>
     *<br>
     * 概要:<br>
     *   一覧のデータ件数を取得する<br>
     *   daoのtabId + 「SelectListCount」のメソッドを呼び出す<br>
     *   例：タブIDがoperationListの場合、daoのoperationListSelectListCountのメソッドを呼び出す
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return 件数
     */
    public long getDataCount(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        long ret = 0;
        try {
            // tabId + 「SelectListCount」のメソッドを呼び出し処理
            Method method = this.getCustomerDao().getClass().getMethod(this.getTabInfo().getTabId() + COMMON_SELECT_COUNT_METHOD_NAME,
                    new Class[]{BeanMap.class, Map.class});
            Object count = method.invoke(this.getCustomerDao(), new Object[]{_formInfo, _mapSearchCondInfo});

            ret = Long.parseLong(count.toString());
        }  catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            CM_LoggerUtil.outputErrorLog(this.sessionDto, e, FW00_19_Const.EMPTY_STR);
        }

        return ret;
    };


    /**
     *
     * 一覧データ取得.<br>
     *<br>
     * 概要:<br>
     *   一覧のデータ件数を取得する<br>
     *   daoのtabId + 「SelectList」のメソッドを呼び出す<br>
     *   例：タブIDがoperationListの場合、daoのoperationListSelectListのメソッドを呼び出す
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @param _offsetInfo オフセット情報
     * @return 抽出データ
     */
    public List<?> getDataList(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo, final Map<String, Integer> _offsetInfo) {
        List<?> ret = null;

        try {
            // tabId + 「SelectList」のメソッドを呼び出し処理
            Method method = this.getCustomerDao().getClass().getMethod(this.getTabInfo().getTabId() + COMMON_SELECT_LIST_METHOD_NAME,
                    new Class[]{BeanMap.class, Map.class, Map.class});
            Object list = method.invoke(this.getCustomerDao(), new Object[]{_formInfo, _mapSearchCondInfo, _offsetInfo});

            ret = (List<?>) list;

        }  catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            CM_LoggerUtil.outputErrorLog(this.sessionDto, e, FW00_19_Const.EMPTY_STR);
        }

        // 取得データの加工処理
        try {
            // tabId + 「CreateDspData」のメソッドを呼び出し処理
            Method method = this.getClass().getMethod(this.getTabInfo().getTabId() + COMMON_CREATE_DSP_DATA_METHOD_NAME,
                    new Class[]{List.class});
            Object list = method.invoke(this, new Object[]{ret});

            ret = (List<?>) list;

        } catch (NoSuchMethodException nsm) {
            // メソッドが無い場合は処理なし
        } catch (InvocationTargetException | IllegalAccessException e) {
            CM_LoggerUtil.outputErrorLog(this.sessionDto, e, FW00_19_Const.EMPTY_STR);
        }

        return ret;
    };

    /**
    *
    * 一覧データ取得.<br>
    *<br>
    * 概要:<br>
    *   一覧のデータ件数を取得する<br>
    *   daoのtabId + 「SelectList」のメソッドを呼び出す<br>
    *   例：タブIDがoperationListの場合、daoのoperationListSelectListのメソッドを呼び出す
    *<br>
    * @param _formInfo フォーム情報
    * @param _mapSearchCondInfo 詳細検索条件情報
    * @param _offsetInfo オフセット情報
    * @param _csvMaxSize CSV出力最大行数
    * @return 抽出データ
    */
    public List<?> getDataList(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo, final Map<String, Integer> _offsetInfo, final long _csvMaxSize) {
        List<?> ret = null;

        try {
            // tabId + 「SelectList」のメソッドを呼び出し処理
            Method method = this.getCustomerDao().getClass().getMethod(this.getTabInfo().getTabId() + COMMON_SELECT_LIST_METHOD_NAME,
                    new Class[]{BeanMap.class, Map.class, Map.class, long.class});
            Object list = method.invoke(this.getCustomerDao(), new Object[]{_formInfo, _mapSearchCondInfo, _offsetInfo, _csvMaxSize});

            ret = (List<?>) list;

        }  catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            CM_LoggerUtil.outputErrorLog(this.sessionDto, e, FW00_19_Const.EMPTY_STR);
        }

        // 取得データの加工処理
        try {
            // tabId + 「CreateDspData」のメソッドを呼び出し処理
            Method method = this.getClass().getMethod(this.getTabInfo().getTabId() + COMMON_CREATE_DSP_DATA_METHOD_NAME,
                    new Class[]{List.class});
            Object list = method.invoke(this, new Object[]{ret});

            ret = (List<?>) list;

        } catch (NoSuchMethodException nsm) {
            // メソッドが無い場合は処理なし
        } catch (InvocationTargetException | IllegalAccessException e) {
            CM_LoggerUtil.outputErrorLog(this.sessionDto, e, FW00_19_Const.EMPTY_STR);
        }

        return ret;
    };

    /**
     *
     * 入力チェック処理.<br/>
     * <br/>
     * 概要:<br/>
     *  入力チェック処理を行う。<br/>
     *  エラーがある場合、例外をThrowする。<br/>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     */
    public void validate(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        return;
    }

    /**
     *
     * CSV入力チェック処理.<br/>
     * <br/>
     * 概要:<br/>
     *  CSV入力チェック処理を行う。<br/>
     *  エラーがある場合、例外をThrowする。<br/>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     */
    public void csvValidate(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        return;
    }

    /**
     * タブ情報を取得.
     *
     * @return tabInfo
     */
    public CM_A06_TabInfo getTabInfo() {
        return this.tabInfo;
    }

    /**
     * タブ情報を設定する.
     *
     * @param _tabInfo タブ情報
     */
    public void setTabInfo(final CM_A06_TabInfo _tabInfo) {
        this.tabInfo = _tabInfo;
    }

    /**
     * ソートキー取得処理.<br>
     *<br>
     * 概要:<br>
     *   一覧用のソートキーを生成して渡します。
     *<br>
     * @return ソートキーマップ
     */
    public BeanMap getSortKeyNames() {
        return null;
    }

    /**
     * 画面データアクセスDaoを取得.<br>
     * <br>
     * 概要:<br>
     *   画面データアクセスDaoを取得
     *
     *
     * @return 画面データアクセスDao
     */
    @Override
    protected abstract CM_TabDao getCustomerDao();

    @Override
    protected List<?> getExportExcelData(final BeanMap _formInfo) {
        return null;
    };

    @SuppressWarnings("unchecked")
    @Override
    public Map<String, String> getCsvSearchConditionData(final BeanMap _formMap) {

        Map<String, String> ret = null;

        try {
            // tabId + 「GetCsvSearchCondition」のメソッドを呼び出し処理
            Method method = this.getClass().getMethod(this.getTabInfo().getTabId() + COMMON_GET_CSV_SEARCH_CONDITION_METHOD_NAME,
                    new Class[]{BeanMap.class});
            Object searchCondition = method.invoke(this, new Object[]{_formMap});

            ret = (Map<String, String>) searchCondition;

        }  catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            CM_LoggerUtil.outputErrorLog(this.sessionDto, e, FW00_19_Const.EMPTY_STR);
        }

        return ret;
    }

    /**
     * 検索期間を設定.
     *
     * @param _formInfo
     *            フォーム情報.
     */
    public void fixSearchDate(final BeanMap _formInfo) {
        SimpleDateFormat sdf = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT_MILLI_HYPHEN);

        // comDataDateDispのチェック
        if (CM_CommonUtil.isNotNullOrBlank(_formInfo.get(CM_BaseForm.COM_DATA_DATE_DISP))) {
            String currentYearChar = CM_DisplayCharResourceUtil.getDisplayCharValue(
                    this.sessionDto.ssn_CustomerCD, this.sessionDto.ssn_UserLangCD, "CMMCDCCM00000_058");
            if (_formInfo.get(CM_BaseForm.COM_DATA_DATE_DISP).toString().equals(currentYearChar)) {
                _formInfo.put(CM_BaseForm.COM_DATA_DATE_DISP, CM_A04_Const.DISP_RECENT_FLG);
            }
        }

        // 日付種別
        Calendar fromCal = Calendar.getInstance();
        Calendar toCal = Calendar.getInstance();
        String p;
        try {
            // 検索開始日時
            p = (String) _formInfo.get(CM_BaseForm.COM_DATA_DATE_FROM);
            fromCal.setTime(sdf.parse(p));
            fromCal.add(Calendar.DAY_OF_MONTH, 15);
//            if (fromCal.get(Calendar.DAY_OF_MONTH) > 1) {
//                fromCal.add(Calendar.MONTH, 1);
//            }
            fromCal.set(Calendar.DAY_OF_MONTH, 1);
            fromCal.add(Calendar.MINUTE, 0);
            fromCal.set(Calendar.HOUR_OF_DAY, 0);
            fromCal.set(Calendar.MINUTE, 0);
            fromCal.set(Calendar.SECOND, 0);
            fromCal.set(Calendar.MILLISECOND, 0);
            _formInfo.put(CM_BaseForm.COM_DATA_DATE_FROM, sdf.format(fromCal.getTime()));

            // 検索終了日時
            p = (String) _formInfo.get(CM_BaseForm.COM_DATA_DATE_TO);
            toCal.setTime(sdf.parse(p));
            toCal.add(Calendar.DAY_OF_MONTH, -15);
            toCal.set(Calendar.DAY_OF_MONTH, 1);
            toCal.add(Calendar.MINUTE, 0);
            toCal.set(Calendar.HOUR_OF_DAY, 0);
            toCal.set(Calendar.MINUTE, 0);
            toCal.set(Calendar.SECOND, 0);
            toCal.set(Calendar.MILLISECOND, 0);
            _formInfo.put(CM_BaseForm.COM_DATA_DATE_TO, sdf.format(toCal.getTime()));

        } catch (ParseException e) {
            CM_LoggerUtil.outputErrorLog(this.sessionDto, e);
        }
    }


}
