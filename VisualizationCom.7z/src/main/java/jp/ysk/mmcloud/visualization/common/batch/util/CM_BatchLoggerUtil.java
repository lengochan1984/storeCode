/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/23| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.batch.util;

import jp.ysk.fw.util.FW00_23_LoggerUtil;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.common.util.CM_MessageResourceUtil;

/**
 * バッチログ出力ユーティリティクラス.
 *<br>
 * 概要:<br>
 *   バッチログ出力のユーティリティクラス
 *<br>
 */
public class CM_BatchLoggerUtil extends FW00_23_LoggerUtil {
    /**
     *
     * コンストラクタ.
     *
     */
    protected CM_BatchLoggerUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     *
     * エラーログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   エラーログを出力する
     *<br>
     * @param _companyId 顧客ID
     * @param _processName プロセス名
     * @param _strMsg メッセージ
     * @param _ex 例外情報
     */
    public static void outputErrorLog(
            final String _companyId, final String _processName, final String _strMsg, final Exception _ex) {
        StringBuffer sbMsg = new StringBuffer();

        // 顧客ID、をセット
        if (_companyId != null && _processName != null) {
            sbMsg.append("CompanyId:");
            sbMsg.append(_companyId);
            sbMsg.append(" ProcessName:");
            sbMsg.append(_processName);
        }

        // メッセージがあれば、メッセージをセット
        if (!CM_CommonUtil.isNullOrBlank(_strMsg)) {
            sbMsg.append(" Message:");
            sbMsg.append(_strMsg);
        }

        errorLog.error(sbMsg.toString(), _ex);
    }

    /**
     *
     * エラーログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   エラーログを出力する
     *<br>
     * @param _companyId 顧客ID
     * @param _processName プロセス名
     * @param _strMsg メッセージ
     */
    public static void outputErrorLog(final String _companyId, final String _processName, final String _strMsg) {
        outputErrorLog(_companyId, _processName, _strMsg, null);
    }

    /**
     *
     * エラーログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   エラーログを出力する
     *<br>
     * @param _companyId 顧客ID
     * @param _processName プロセス名
     * @param _ex 例外情報
     */
    public static void outputErrorLog(final String _companyId, final String _processName, final Exception _ex) {
        outputErrorLog(_companyId, _processName, null, _ex);
    }

    /**
     *
     * エラーログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   エラーログを出力する
     *<br>
     * @param _companyId 顧客ID
     * @param _processName プロセス名
     * @param _ex 例外情報
     * @param _strMsgID メッセージID
     */
    public static void outputErrorLog(
            final String _companyId, final String _processName, final Exception _ex, final String _strMsgID) {

        String strMsg = CM_MessageResourceUtil.getMessageValue(null, CM_A03_SessionDto.SSN_USER_LANG_CD, _strMsgID);

        outputErrorLog(_companyId, _processName, strMsg, _ex);
    }

    /**
     *
     * デバックログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   デバックログを出力する
     *<br>
     * @param _companyId 顧客ID
     * @param _processName プロセス名
     * @param _strMsg メッセージ
     */
    public static void outputDebugLog(final String _companyId, final String _processName, final String _strMsg) {
        StringBuffer sbMsg = new StringBuffer();

        // 顧客ID、機器IDをセット
        if (_companyId != null && _processName != null) {
            sbMsg.append("CompanyId:");
            sbMsg.append(_companyId);
            sbMsg.append(" ProcessName:");
            sbMsg.append(_processName);
        }

        // メッセージがあれば、メッセージをセット
        if (!CM_CommonUtil.isNullOrBlank(_strMsg)) {
            sbMsg.append(" Message:");
            sbMsg.append(_strMsg);
        }

        debugLog.debug(sbMsg.toString());
    }

    /**
     *
     * ログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   ログを出力する
     *<br>
     * @param _companyId 顧客ID
     * @param _processName プロセス名
     * @param _strMsg メッセージ
     */
    public static void outputLog(final String _companyId, final String _processName, final String _strMsg) {
        StringBuffer sbMsg = new StringBuffer();

        // 顧客ID、機器IDをセット
        if (_companyId != null && _processName != null) {
            sbMsg.append("CompanyId:");
            sbMsg.append(_companyId);
            sbMsg.append(" ProcessName:");
            sbMsg.append(_processName);
        }

        // メッセージがあれば、メッセージをセット
        if (!CM_CommonUtil.isNullOrBlank(_strMsg)) {
            sbMsg.append(" Message:");
            sbMsg.append(_strMsg);
        }

        accessLog.info(sbMsg.toString());
    }

}
