/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/01/14| <40000-025> 変更仕様No.25 新規作成                                   | 4.00.00| US)萩尾
 *  2016/07/20| <C1.01>共通化対応取込                                                | C1.01  | US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.service;

import java.util.List;
import java.util.Map;

import jp.ysk.mmcloud.visualization.common.dao.CM_GraphDao;

import org.seasar.framework.beans.util.BeanMap;

/**
 * 一覧画面共通サービス.<br>
 *<br>
 * 概要:<br>
 *   一覧画面共通処理のサービスクラス
 *<br>
 */
public abstract class CM_GraphService extends CM_ListBaseService {


    /**
     *
     * グラフデータ取得.<br>
     *<br>
     * 概要:<br>
     *  グラフデータ取得
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索
     * @return グラフデータ
     */
    public Object getGraphData(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        // グラフデータ取得
        List<?> listData = this.getCustomerDao().selectList(_formInfo, _mapSearchCondInfo);
        // 表示用データ生成
        Object ret = this.createDspData(_formInfo, listData);

        return ret;
    }

    /**
     * 画面データアクセスDaoを取得.<br>
     * <br>
     * 概要:<br>
     *   画面データアクセスDaoを取得
     *
     *
     * @return 画面データアクセスDao
     */
    @Override
    protected abstract CM_GraphDao getCustomerDao();

    /*
     * (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.common.service.CM_ListBaseService#getExportExcelData(org.seasar.framework.beans.util.BeanMap)
     */
    @Override
    protected List<?> getExportExcelData(final BeanMap _formInfo) {
        return null;
    };

    /**
     *
     * 取得データの加工処理.<br>
     *<br>
     * 概要:<br>
     *   取得データの加工処理
     *<br>
     * @param _formInfo フォーム情報
     * @param _listData 取得データ
     * @return 表示用データ
     */
    protected Object createDspData(final BeanMap _formInfo, final List<?> _listData) {
        return _listData;
    }

    /**
     *
     * 入力チェック処理.<br/>
     * <br/>
     * 概要:<br/>
     *  入力チェック処理を行う。<br/>
     *  エラーがある場合、例外をThrowする。<br/>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     */
    public void validate(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        return;
    }

    /*
     * (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.common.service.CM_ListBaseService#getDataCount(org.seasar.framework.beans.util.BeanMap, java.util.Map)
     */
    @Override
    public long getDataCount(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        return this.getCustomerDao().selectListCount(_formInfo, _mapSearchCondInfo);
    };

    /**
     *
     * CSV入力チェック処理.<br/>
     * <br/>
     * 概要:<br/>
     *  CSV入力チェック処理を行う。<br/>
     *  エラーがある場合、例外をThrowする。<br/>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     */
    public void csvValidate(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        // 一覧と同じ
        this.validate(_formInfo, _mapSearchCondInfo);
        return;
    }

    /**
     *
     * CSV出力用データ取得.<br>
     *<br>
     * 概要:<br>
     * CSV出力用データ取得
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return CSV出力用データ
     */
    public List<Map<String, String>> getCsvData(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {

        // 一覧データ取得
        List<?> listData = this.getCsvListData(_formInfo, _mapSearchCondInfo);

        // 表示用データ生成
        List<Map<String, String>> ret = this.createCsvData(_formInfo, listData);

        return ret;
    }

    /**
     *
     * CSVデータ一覧取得.<br>
     *<br>
     * 概要:<br>
     *  CSVデータ一覧取得
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return CSV出力データ
     */
    protected List<?> getCsvListData(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        // データ取得
        List<?> listData = this.getCustomerDao().selectList(_formInfo, _mapSearchCondInfo);
        return listData;
    }

    /**
     *
     * CSV出力用データ生成.<br>
     *<br>
     * 概要:<br>
     * CSV出力用データ生成
     *<br>
     * @param _formInfo フォーム情報
     * @param _listData 取得データ
     * @return CSV出力データ
     */
    protected List<Map<String, String>> createCsvData(final BeanMap _formInfo, final List<?> _listData) {
        return null;
    }

}
