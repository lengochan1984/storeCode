/*
 * ************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ************************************************************************************
 * ===========+================================================+========+==============
 *  DATE      | Comments                                       | Rev    | SIGN
 * ===========+================================================+========+==============
 *  2014/05/02| 新規作成                                       | 1.00.00| YSK)中田
 *  2014/12/19| <20000-025> 変更仕様一覧No.17                  | 3.00.00| YSK)森山
 *  2015/01/22| <20000-042> 役割用データ作成時の不要ループ回避 | 3.00.00| YSK)中田
 *  2015/06/23| <30003-034> 変更仕様No.1                       | 3.01.00| YSK)千田
 *  2015/07/08| <30003-037> 変更仕様No.23                      | 3.01.00| US)萩尾
 * -----------+------------------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.dto.CM_A04_UserRoleDto;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.common.util.CM_ComparatorByDisplayOrder;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.common.util.CM_SysNameDataUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.CM_A05_PageInfo;
import jp.ysk.mmcloud.common.dao.CM_GetRoleAuthInfoDao;
import jp.ysk.mmcloud.visualization.common.entity.customer.MstRoleSettingEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.SysNameEntityNames;

import org.seasar.framework.beans.util.BeanMap;

/**
 * 役割・権限取得用ユーティリティ.<br>
 *<br>
 * 概要:<br>
 *<br>
 */
public class CM_RoleAuthInfoUtil {

//    /**
//     * [MAPキー]機能一覧.
//     */
//    public static final String MAPKEY_FUNCTION_ITEM_LIST = "functionItemList";
//
//    /**
//     * [MAPキー]機能CD名称.
//     */
//    public static final String MAPKEY_FUNCTION_CD_NAME = "functionCdName";
//
//    /**
//     * [MAPキー]ページID名称.
//     */
//    public static final String MAPKEY_PAGE_ID_NAME = "pageIdName";
//
//    /**
//     * [MAPキー]システム管理者のみ表示可能.
//     */
//    public static final String MAPKEY_ENABLE_ONLY_SYS_ADMIN = "enableOnlySysAdmin";
//
    /**
     * 機能CDの文字列位置.
     */
    public static final int FUNC_CD_POS = 3;


    /**
     *
     * コンストラクタ.
     *
     */
    protected CM_RoleAuthInfoUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     * 画面権限情報取得.<br>
     *<br>
     * 概要:<br>
     *   画面権限情報を取得しセッションに設定する
     *<br>
     * @param _sessionDto セッション
     * @param _plantCode 工場コード
     */
    public static void loadSessionPageAuthInfo(final CM_A03_SessionDto _sessionDto, final String _plantCode) {
        _sessionDto.ssn_UserRoleSetting
            = getSessionPageAuthInfo(_sessionDto, _sessionDto.ssn_AuthorityCode, _sessionDto.ssn_UserLangCD, _plantCode);
    }

    /**
     * 画面権限情報取得.<br>
     *<br>
     * 概要:<br>
     *   画面権限情報を取得する
     *<br>
     * @param _sessionDto セッション
     * @param _authorityCode 権限コード
     * @param _userLangCD 言語コード
     * @param _plantCode 工場コード
     * @return 画面権限情報
     */
    public static CM_A04_UserRoleDto[] getSessionPageAuthInfo(
            final CM_A03_SessionDto _sessionDto, final String _authorityCode, final String _userLangCD, final String _plantCode) {
        CM_A04_UserRoleDto[] resList = null;

//        try {
//            CM_GetRoleAuthInfoDao clsCM_GetRoleAuthInfoDao = new CM_GetRoleAuthInfoDao(_sessionDto.ssn_ConnectString,
//                    _sessionDto.ssn_ConnectUserID,
//                    _sessionDto.ssn_ConnectPassword);
//
//            // ファンクションの並び順取得
//            Map<String, Integer> fuctionDispOrderMap = new HashMap<String, Integer>();
//            List<BeanMap> functionCdList = CM_SysNameDataUtil.getNameList(_sessionDto,
//                    CM_A04_Const.SYS_NAME_MST_NAME_TYPE.FUNCTION_CD, _userLangCD);
//            for (BeanMap functionCdDef : functionCdList) {
//                String functionCd = (String) functionCdDef.get(SysNameEntityNames.itemCd().toString());
//                Integer displayOrder = (Integer) functionCdDef.get(SysNameEntityNames.displayOrder().toString());
//                fuctionDispOrderMap.put(functionCd, displayOrder);
//            }
//
//            // 指定された工場コードの権限リストを取得
//            List<BeanMap> mapList = clsCM_GetRoleAuthInfoDao.selectRoleAuthInfo(_plantCode);
//            if (CM_CommonUtil.isNullOrEmpty(mapList)) {
//                // 取得できない場合、工場コードは指定せずに再取得
//                mapList = clsCM_GetRoleAuthInfoDao.selectRoleAuthInfo(null);
//            }
//
//            // メニュー構成権限追加
//            String setteinFunctinCd = CM_A05_PageInfo.PAGE_ID_MENU_CONSTITUTION.getFunctionCd();
//            String menuConstitutionPageId = CM_A05_PageInfo.PAGE_ID_MENU_CONSTITUTION.getPageId();
//            int menuConstitutionIndex = 0;
//            String functionCdBuf = FW00_19_Const.EMPTY_STR;
//            for (BeanMap roleSetting : mapList) {
//                String functionCd = (String) roleSetting.get(MstMenuItemsEntityNames.functionCd().toString());
//                String pageId = (String) roleSetting.get(MstMenuItemsEntityNames.pageId().toString());
//                // 並び順設定
//                Integer displayOrder = fuctionDispOrderMap.get(functionCd);
//                if (CM_CommonUtil.isNullOrBlank(displayOrder)) {
//                    // 並び順が設定されていない場合
//                    displayOrder = Integer.MAX_VALUE;
//                }
//                roleSetting.put(SysNameEntityNames.displayOrder().toString(), displayOrder);
//
//                if (menuConstitutionPageId.equals(pageId)) {
//                    // メニュー構成画面の場合
//                    if (CM_A04_Const.USER_AUTH_CD.equals(_authorityCode)) {
//                        // ユーザーの場合、権限なしに設定
//                        roleSetting.put(MstMenuItemsEntityNames.enableFlag().toString(), CM_A04_Const.ROLE_AUTH_KIND.NONE);
//                    }
//                    menuConstitutionIndex = -1;
//                    break;
//                }
//
//                if (!functionCd.equals(functionCdBuf) && setteinFunctinCd.equals(functionCd)) {
//                    // 設定項目最後の場合
//                    break;
//                }
//                ++menuConstitutionIndex;
//                functionCdBuf = functionCd;
//            }
//            if (menuConstitutionIndex >= 0) {
//                if (CM_A04_Const.SYS_ADMIN_AUTH_CD.equals(_authorityCode)) {
//                    // 管理者権限の場合、メニュー構成画面を表示可能とする
//                    BeanMap menuConstitutionAuth = new BeanMap();
//                    // 並び順
//                    Integer displayOrder = fuctionDispOrderMap.get(setteinFunctinCd);
//                    if (CM_CommonUtil.isNullOrBlank(displayOrder)) {
//                        // 並び順が設定されていない場合
//                        displayOrder = Integer.MAX_VALUE;
//                    }
//                    menuConstitutionAuth.put(SysNameEntityNames.displayOrder().toString(), displayOrder);
//                    // ファンクションコード
//                    menuConstitutionAuth.put(MstMenuItemsEntityNames.functionCd().toString(), setteinFunctinCd);
//                    // 画面ID
//                    menuConstitutionAuth.put(MstMEntityNames.pageId().toString(),
//                            CM_A05_PageInfo.PAGE_ID_MENU_CONSTITUTION.getPageId());
//                    // 権限区分
//                    menuConstitutionAuth.put(MstRoleSettingEntityNames.authSetting().toString(),
//                            CM_A04_Const.ROLE_AUTH_KIND.UPDATE_ENABLE);
//                    mapList.add(menuConstitutionIndex, menuConstitutionAuth);
//                }
//            }
//
//            // 表示順でソート
//            Collections.sort(mapList, new CM_ComparatorByDisplayOrder());
//
//            // 画面権限情報を共通セッションへ保存
//            resList = new CM_A04_UserRoleDto[mapList.size()];
//            CM_A04_UserRoleDto userRoleInfo = null;
//            for (int index = 0; index < mapList.size(); ++index) {
//                BeanMap roleSetting = mapList.get(index);
//
//                userRoleInfo = new CM_A04_UserRoleDto();
//                userRoleInfo.ssn_FunctionCd = (String) roleSetting.get(MstRoleSettingEntityNames.functionCd().toString());
//                userRoleInfo.ssn_PageId = (String) roleSetting.get(MstRoleSettingEntityNames.pageId().toString());
//                userRoleInfo.ssn_AuthSetting = (String) roleSetting.get(MstRoleSettingEntityNames.authSetting().toString());
//                resList[index] = userRoleInfo;
//            }
//
//        } catch (Exception e) {
//            // エラーログ出力
//            CM_LoggerUtil.outputErrorLog(null, e);
//        }

        return resList;
    }
}
