/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+===================================================================================+========+==============
 *  DATE      | Comments                                                                          | Rev    | SIGN
 * ===========+===================================================================================+========+==============
 *  2016/08/01| 新規作成                                                                          | 1.00.00| US)入江
 */

package jp.ysk.mmcloud.visualization.common.util;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.seasar.framework.util.StringUtil;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;

/**
 * コード変換Util.<br>
 *<br>
 * 概要:<br>
 *
 *<br>
 */
public final class CM_CodeUtil {

    /**
     * ライングループコード連結文字.
     */
    private static final String SPLIT_CHAR_OF_LINEGROUP_NO_PLD = "_";

    /**
     * インデント文字列.
     */
    private static final String PULLDOWN_LIST_INDENT_STR = "-";

    /**
     * コンストラクタ.
     */
    private CM_CodeUtil() {

    }

    /**
     * ラインプルダウンリストのコードからライングループ№を取得する.
     * <br>
     *
     * @param _code プルダウンコード
     * @return ライングループ№
     */
    public static String getLineGroupNoOutofLinePld(final String _code) {

        return getSplitedString(_code, SPLIT_CHAR_OF_LINEGROUP_NO_PLD, 1);
    }

    /**
     * プルダウンリストの名称から不要な文字列を除去して返す.<br>
     * 概要：<br>
     * プルダウンリストに表示される名称に付与される階層表現文字(-)を除去する.
     *
     * @param _name プルダウンリスト名称
     * @return クリア後名称
     */
    public static String getCleanedNameOfPld(final String _name) {

        Pattern p = Pattern.compile("^" + PULLDOWN_LIST_INDENT_STR + "+");

        return p.matcher(_name).replaceFirst("");

    }

    /***
     * Mapリストからの名称取得.<br>
     * 概要:<br>
     * Map<String, String>リストからValueキーが一致するtext値を取得する.<br>
     * プルダウンリスト用Mapリストからの抽出が目的.
     * @param _list Mapリスト
     * @param _code コード(value)
     * @return 名称(txt)
     */
    public static String getTextOfMapList(final List<Map<String, String>> _list, final String _code) {

        for (Map<String, String> m : _list) {

            try {
            	if (StringUtil.equals(_code.trim(), m.get("value").trim())) {
                    return getCleanedNameOfPld(m.get("text"));
                }
			} catch (Exception e) {
				// TODO: handle exception
				//Null value cannot trim
			}
        }
        return FW00_19_Const.EMPTY_STR;
    }

    /**
     * 文字列を指定された区切り文字で分割し、指定位置の文字列を返す.
     * <br>
     * 概要：<br>
     *
     * @param _s 分割対象文字列
     * @param _split 分割文字
     * @param _no 分割後の取得位置(0～)
     * @return 分割後の指定位置文字列
     */
    private static String getSplitedString(final String _s, final String _split, final int _no) {

        if (CM_CommonUtil.isNullOrBlank(_s)) {
            return _s;
        }

        String[] sd = _s.split(_split, -1);

        if (_no < sd.length) {
            return sd[_no];
        } else {
            return sd[sd.length - 1];
        }
    }

}
