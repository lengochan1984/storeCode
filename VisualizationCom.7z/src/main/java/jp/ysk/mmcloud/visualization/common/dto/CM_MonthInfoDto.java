/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/10/05| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.dto;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import jp.ysk.mmcloud.visualization.common.CM_A04_Const;

/**
 *
 * 月の情報DTO.<br>
 *<br>
 * 概要:<br>
 *  月の情報DTO
 *<br>
 */
public class CM_MonthInfoDto {

    /**
     * コンストラクタ.
     */
    public CM_MonthInfoDto() {
        this.dateFormat = CM_A04_Const.DATE_FORMAT_DATE;
        this.monthlyFormat = CM_A04_Const.DATE_FORMAT_MONTH_HYPHEN;
    }

    /**
     * コンストラクタ.
     * @param _dateFormat 日付フォーマット
     * @param _monthlyFormat 月度フォーマット
     */
    public CM_MonthInfoDto(final String _dateFormat, final String _monthlyFormat) {
        this.dateFormat = _dateFormat;
        this.monthlyFormat = _monthlyFormat;
    }

    /**
     * 月初日.
     */
    private String firstDate;

    /**
     * 月末日.
     */
    private String endDate;

    /**
     * 月度.
     */
    private String monthly;

    /**
     * 日付フォーマット.
     * デフォルト：yyyy/MM/dd
     */
    private String dateFormat;

    /**
     * 月初フォーマット.
     */
    private String monthlyFormat;

    /**
     * 工場マスタの基準日時.
     */
    private Calendar plantCalendar;

    /**
     * 月初日を取得.
     *
     * @return 月初日
     */
    public String getFirstDate() {
        return this.firstDate;
    }

    /**
     * 月初日を設定する.
     *
     * @param _firstDate 月初日
     */
    public void setFirstDate(final String _firstDate) {
        this.firstDate = _firstDate;
    }

    /**
     * 月末日を取得.
     *
     * @return 月末日
     */
    public String getEndDate() {
        return this.endDate;
    }

    /**
     * 月末日を設定する.
     *
     * @param _endDate 月末日
     */
    public void setEndDate(final String _endDate) {
        this.endDate = _endDate;
    }

    /**
     * 月度を取得.
     *
     * @return 月度
     */
    public String getMonthly() {
        return this.monthly;
    }

    /**
     * 月度を設定する.
     *
     * @param _monthly 月度
     */
    public void setMonthly(final String _monthly) {
        this.monthly = _monthly;
    }

    /**
     *
     * 月初日を取得.
     *
     *<br>
     * @return 月初日
     */
    public Date getFirstDatetime() {
        SimpleDateFormat sdf = new SimpleDateFormat(this.dateFormat);
        Date ret = null;
        try {
            ret = sdf.parse(this.firstDate);
        } catch (ParseException e) {
            // 処理なし
        }
        return ret;
    }

    /**
     *
     * 月末日を取得.
     *
     *<br>
     * @return 月末日
     */
    public Date getEndDatetime() {
        SimpleDateFormat sdf = new SimpleDateFormat(this.dateFormat);
        Date ret = null;
        try {
            ret = sdf.parse(this.endDate);
        } catch (ParseException e) {
            // 処理なし
        }
        return ret;
    }

    /**
     *
     * 月度を取得.
     *
     *<br>
     * @return 月度
     */
    public Date getMonthlyDatetime() {
        SimpleDateFormat sdf = new SimpleDateFormat(this.monthlyFormat);
        Date ret = null;
        try {
            ret = sdf.parse(this.monthly);
        } catch (ParseException e) {
            // 処理なし
        }
        return ret;
    }

    /**
     * 基準日時を取得する.
     * @return plantCalendar 基準日時
     */
    public Calendar getPlantCalendar() {
        return this.plantCalendar;
    }

    /**
     * 基準日時を取得する.
     * @param _plantCalendar セットする _plantCalendar
     */
    public void setPlantCalendar(final Calendar _plantCalendar) {
        this.plantCalendar = _plantCalendar;
    }
}
