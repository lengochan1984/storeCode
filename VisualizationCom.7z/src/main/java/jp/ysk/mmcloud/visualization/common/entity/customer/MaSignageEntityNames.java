package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link MaSignageEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class MaSignageEntityNames {

    /**
     * signageIdのプロパティ名を返します。
     * 
     * @return signageIdのプロパティ名
     */
    public static PropertyName<String> signageId() {
        return new PropertyName<String>("signageId");
    }

    /**
     * facilitySummaryKindのプロパティ名を返します。
     * 
     * @return facilitySummaryKindのプロパティ名
     */
    public static PropertyName<String> facilitySummaryKind() {
        return new PropertyName<String>("facilitySummaryKind");
    }

    /**
     * groupSummaryKindのプロパティ名を返します。
     * 
     * @return groupSummaryKindのプロパティ名
     */
    public static PropertyName<String> groupSummaryKind() {
        return new PropertyName<String>("groupSummaryKind");
    }

    /**
     * leadtimePeriodUnitのプロパティ名を返します。
     * 
     * @return leadtimePeriodUnitのプロパティ名
     */
    public static PropertyName<String> leadtimePeriodUnit() {
        return new PropertyName<String>("leadtimePeriodUnit");
    }

    /**
     * leadtimePeriodのプロパティ名を返します。
     * 
     * @return leadtimePeriodのプロパティ名
     */
    public static PropertyName<Integer> leadtimePeriod() {
        return new PropertyName<Integer>("leadtimePeriod");
    }

    /**
     * leadtimeHistUnitのプロパティ名を返します。
     * 
     * @return leadtimeHistUnitのプロパティ名
     */
    public static PropertyName<String> leadtimeHistUnit() {
        return new PropertyName<String>("leadtimeHistUnit");
    }

    /**
     * leadtimeHistMaxNumのプロパティ名を返します。
     * 
     * @return leadtimeHistMaxNumのプロパティ名
     */
    public static PropertyName<Integer> leadtimeHistMaxNum() {
        return new PropertyName<Integer>("leadtimeHistMaxNum");
    }

    /**
     * leadtimeHistMinNumのプロパティ名を返します。
     * 
     * @return leadtimeHistMinNumのプロパティ名
     */
    public static PropertyName<Integer> leadtimeHistMinNum() {
        return new PropertyName<Integer>("leadtimeHistMinNum");
    }

    /**
     * dailyOpeTimePeriodのプロパティ名を返します。
     * 
     * @return dailyOpeTimePeriodのプロパティ名
     */
    public static PropertyName<Integer> dailyOpeTimePeriod() {
        return new PropertyName<Integer>("dailyOpeTimePeriod");
    }

    /**
     * yearlyProductNumPeriodのプロパティ名を返します。
     * 
     * @return yearlyProductNumPeriodのプロパティ名
     */
    public static PropertyName<Integer> yearlyProductNumPeriod() {
        return new PropertyName<Integer>("yearlyProductNumPeriod");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _MaSignageNames extends PropertyName<MaSignageEntity> {

        /**
         * インスタンスを構築します。
         */
        public _MaSignageNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _MaSignageNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _MaSignageNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * signageIdのプロパティ名を返します。
         *
         * @return signageIdのプロパティ名
         */
        public PropertyName<String> signageId() {
            return new PropertyName<String>(this, "signageId");
        }

        /**
         * facilitySummaryKindのプロパティ名を返します。
         *
         * @return facilitySummaryKindのプロパティ名
         */
        public PropertyName<String> facilitySummaryKind() {
            return new PropertyName<String>(this, "facilitySummaryKind");
        }

        /**
         * groupSummaryKindのプロパティ名を返します。
         *
         * @return groupSummaryKindのプロパティ名
         */
        public PropertyName<String> groupSummaryKind() {
            return new PropertyName<String>(this, "groupSummaryKind");
        }

        /**
         * leadtimePeriodUnitのプロパティ名を返します。
         *
         * @return leadtimePeriodUnitのプロパティ名
         */
        public PropertyName<String> leadtimePeriodUnit() {
            return new PropertyName<String>(this, "leadtimePeriodUnit");
        }

        /**
         * leadtimePeriodのプロパティ名を返します。
         *
         * @return leadtimePeriodのプロパティ名
         */
        public PropertyName<Integer> leadtimePeriod() {
            return new PropertyName<Integer>(this, "leadtimePeriod");
        }

        /**
         * leadtimeHistUnitのプロパティ名を返します。
         *
         * @return leadtimeHistUnitのプロパティ名
         */
        public PropertyName<String> leadtimeHistUnit() {
            return new PropertyName<String>(this, "leadtimeHistUnit");
        }

        /**
         * leadtimeHistMaxNumのプロパティ名を返します。
         *
         * @return leadtimeHistMaxNumのプロパティ名
         */
        public PropertyName<Integer> leadtimeHistMaxNum() {
            return new PropertyName<Integer>(this, "leadtimeHistMaxNum");
        }

        /**
         * leadtimeHistMinNumのプロパティ名を返します。
         *
         * @return leadtimeHistMinNumのプロパティ名
         */
        public PropertyName<Integer> leadtimeHistMinNum() {
            return new PropertyName<Integer>(this, "leadtimeHistMinNum");
        }

        /**
         * dailyOpeTimePeriodのプロパティ名を返します。
         *
         * @return dailyOpeTimePeriodのプロパティ名
         */
        public PropertyName<Integer> dailyOpeTimePeriod() {
            return new PropertyName<Integer>(this, "dailyOpeTimePeriod");
        }

        /**
         * yearlyProductNumPeriodのプロパティ名を返します。
         *
         * @return yearlyProductNumPeriodのプロパティ名
         */
        public PropertyName<Integer> yearlyProductNumPeriod() {
            return new PropertyName<Integer>(this, "yearlyProductNumPeriod");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
