package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * MES-DB連携結果
 * 
 */
@Entity
@Table(name = "tr_transfer_datetime")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class TrTransferDatetimeEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 接続文字列 */
    @Id
    @Column(length = 256, nullable = false, unique = false)
    public String connectionString;

    /** ユーザID */
    @Id
    @Column(length = 64, nullable = false, unique = false)
    public String userId;

    /** テーブル名 */
    @Id
    @Column(length = 64, nullable = false, unique = false)
    public String tableName;

    /** テーブル更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updDatetime;
}
