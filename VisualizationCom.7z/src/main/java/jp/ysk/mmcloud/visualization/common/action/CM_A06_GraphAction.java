/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/10/03| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.action;

import java.text.ParseException;
import java.util.Map;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.form.FW01_17_BaseForm;
import jp.ysk.mmcloud.visualization.common.csv.CM_Csv_Const;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.csv.CM_CsvUtil;
import jp.ysk.mmcloud.visualization.common.csv.dto.CM_CsvDatetimeDto;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;
import jp.ysk.mmcloud.visualization.common.service.CM_GraphService;

import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.beans.util.Beans;
import org.seasar.struts.annotation.Execute;

/**
 *
 * グラフ用アクション基底クラス.<br>
 *<br>
 * 概要:<br>
 *   グラフ用アクション用の共通基底クラス
 *<br>
 */
public abstract class CM_A06_GraphAction extends CM_A04_ListBaseAction {

    /**
     * グラフ表示データ.
     */
    public Object graphData;

    /**
     *
     * 表示データ作成処理.<br>
     *<br>
     * 概要:<br>
     *  表示データ作成処理を実行する<br>
     *  service.getDataCountで件数を取得後、
     *  service.getDataListで一覧を取得する
     *<br>
     * @return 画面のJSP
     */
    @Override
    protected String display() {

        // 日時情報更新処理
        this.setDisplayDateData(this.getActionForm());

        // 詳細検索条件情報を取得
        Map<String, Object> mapSearchCondInfo = this.getComDetailSearchInfo(getPageId(), (FW01_17_BaseForm) this.getActionForm());

        CM_GraphService service = this.getService();

        // 検索前処理
        this.preDisplay();

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();
        // フォーム情報にユーザの言語コードを設定
        formMap.put(CM_A04_Const.SQL_PARAM.LOGIN_USER_LANG_CD, this.cM_A03_SessionDto.ssn_UserLangCD);

        // 検索前処理
        service.preGetData(formMap, mapSearchCondInfo);

        // グラフ表示のデータ抽出を行う
        this.graphData = service.getGraphData(formMap, mapSearchCondInfo);

        // 検索後処理
        this.afterDisplay(formMap);

        return getJspFileName();
    }

    /**
     * 画面のサービスを取得.<br>
     * <br>
     * 概要:<br>
     * 各画面のサービスを取得<br>
     * 各画面のアクションで実装し、サービスを設定する
     *
     * @return 画面のサービス
     */
    @Override
    protected abstract CM_GraphService getService();

    /**
     *
     * CSV出力処理.<br>
     *<br>
     * 概要:<br>
     *  CSV出力を行う。
     *<br>
     * @return JSP名
     * @throws ParseException エクセプション
     */
    @Execute(validator = false)
    public String downloadCSV() throws ParseException {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        // CSV出力処理開始
        this.getActionForm().hdnProcessExecFlg = CM_A04_Const.PROCESS_EXEC_CSV;

        // 日時情報更新処理
        this.setDisplayDateData(this.getActionForm());

        // 詳細検索条件情報を取得
        Map<String, Object> mapSearchCondInfo = this.getComDetailSearchInfo(getPageId(), this.getActionForm());

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        CM_GraphService service = this.getService();
        // 処理開始
        service.init(this.cM_A03_SessionDto);

        // CSV出力用の現在日時を取得
        CM_CsvDatetimeDto csvDatetimeDto = CM_CsvUtil.getCsvDatetimeData(this.cM_A03_SessionDto.ssn_UserTimezoneCD);

        // ファイル名取得
        String fileName = this.getCsvFileName() + csvDatetimeDto.getFileNameDateStr() + ".csv";

        // 出力前処理
        this.preDownloadCsv(formMap, mapSearchCondInfo);

        // 出力データ取得処理
        this.getCsvFormat().putDataInfoList(CM_Csv_Const.AREA_KEY, service.getCsvData(formMap, mapSearchCondInfo));

        // CSVダウンロード処理
        String ret = this.downloadCsv(fileName, csvDatetimeDto.getHeaderDateStr(), this.getCsvFormat());

        // CSV出力処理完了
        this.getActionForm().hdnProcessExecFlg = CM_A04_Const.PROCESS_EXEC_NONE;

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, ret);

        // JSPを返す
        return ret;
    }

    /**
     *
     * CSVファイル名を取得.<br>
     *<br>
     * 概要:<br>
     *   CSVファイル名を取得
     *<br>
     * @return CSVファイル名
     */
    protected String getCsvFileName() {
        return FW00_19_Const.EMPTY_STR;
    }

    /**
     *
     * CSVダウンロードチェック前処理.<br/>
     *<br/>
     * 概要:<br/>
     *  CSVダウンロードチェックの前処理を行う。<br/>
     *<br/>
     * @param _formMap Form情報
     * @param _mapSearchCondInfo 詳細検索情報
     */
    @Override
    protected void beforeCheckCSVDownload(final BeanMap _formMap, final Map<String, Object> _mapSearchCondInfo) {
        this.preDownloadCsv(_formMap, _mapSearchCondInfo);
    }
    /**
     *
     * CSVダウンロード前処理.<br>
     *<br>
     * 概要:<br>
     *  CSVダウンロード前処理
     *<br>
     * @param _formMap フォーム情報
     * @param _mapSearchCondInfo 詳細検索情報
     */
    protected void preDownloadCsv(final BeanMap _formMap, final Map<String, Object> _mapSearchCondInfo) {
        // デフォルトは、グラフデータ取得時の検索前処理と同じ
        this.getService().preGetData(_formMap, _mapSearchCondInfo);
    }
}
