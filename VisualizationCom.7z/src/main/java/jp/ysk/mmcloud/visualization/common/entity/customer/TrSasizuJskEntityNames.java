package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link TrSasizuJskEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class TrSasizuJskEntityNames {

    /**
     * createdOnのプロパティ名を返します。
     * 
     * @return createdOnのプロパティ名
     */
    public static PropertyName<Timestamp> createdOn() {
        return new PropertyName<Timestamp>("createdOn");
    }

    /**
     * createdByのプロパティ名を返します。
     * 
     * @return createdByのプロパティ名
     */
    public static PropertyName<String> createdBy() {
        return new PropertyName<String>("createdBy");
    }

    /**
     * modifiedOnのプロパティ名を返します。
     * 
     * @return modifiedOnのプロパティ名
     */
    public static PropertyName<Timestamp> modifiedOn() {
        return new PropertyName<Timestamp>("modifiedOn");
    }

    /**
     * modifiedByのプロパティ名を返します。
     * 
     * @return modifiedByのプロパティ名
     */
    public static PropertyName<String> modifiedBy() {
        return new PropertyName<String>("modifiedBy");
    }

    /**
     * sasizuNoのプロパティ名を返します。
     * 
     * @return sasizuNoのプロパティ名
     */
    public static PropertyName<String> sasizuNo() {
        return new PropertyName<String>("sasizuNo");
    }

    /**
     * sikanBiのプロパティ名を返します。
     * 
     * @return sikanBiのプロパティ名
     */
    public static PropertyName<String> sikanBi() {
        return new PropertyName<String>("sikanBi");
    }

    /**
     * sikanSuのプロパティ名を返します。
     * 
     * @return sikanSuのプロパティ名
     */
    public static PropertyName<BigDecimal> sikanSu() {
        return new PropertyName<BigDecimal>("sikanSu");
    }

    /**
     * sikanKbnのプロパティ名を返します。
     * 
     * @return sikanKbnのプロパティ名
     */
    public static PropertyName<String> sikanKbn() {
        return new PropertyName<String>("sikanKbn");
    }

    /**
     * startDateのプロパティ名を返します。
     * 
     * @return startDateのプロパティ名
     */
    public static PropertyName<Timestamp> startDate() {
        return new PropertyName<Timestamp>("startDate");
    }

    /**
     * endDateのプロパティ名を返します。
     * 
     * @return endDateのプロパティ名
     */
    public static PropertyName<Timestamp> endDate() {
        return new PropertyName<Timestamp>("endDate");
    }

    /**
     * seisanJyotaiのプロパティ名を返します。
     * 
     * @return seisanJyotaiのプロパティ名
     */
    public static PropertyName<Integer> seisanJyotai() {
        return new PropertyName<Integer>("seisanJyotai");
    }

    /**
     * jyotaiHenkoDateのプロパティ名を返します。
     * 
     * @return jyotaiHenkoDateのプロパティ名
     */
    public static PropertyName<Timestamp> jyotaiHenkoDate() {
        return new PropertyName<Timestamp>("jyotaiHenkoDate");
    }

    /**
     * sekininsyaIdのプロパティ名を返します。
     * 
     * @return sekininsyaIdのプロパティ名
     */
    public static PropertyName<String> sekininsyaId() {
        return new PropertyName<String>("sekininsyaId");
    }

    /**
     * repairSuのプロパティ名を返します。
     * 
     * @return repairSuのプロパティ名
     */
    public static PropertyName<BigDecimal> repairSu() {
        return new PropertyName<BigDecimal>("repairSu");
    }

    /**
     * lineChgFlgのプロパティ名を返します。
     * 
     * @return lineChgFlgのプロパティ名
     */
    public static PropertyName<String> lineChgFlg() {
        return new PropertyName<String>("lineChgFlg");
    }

    /**
     * tonyuSuのプロパティ名を返します。
     * 
     * @return tonyuSuのプロパティ名
     */
    public static PropertyName<BigDecimal> tonyuSu() {
        return new PropertyName<BigDecimal>("tonyuSu");
    }

    /**
     * spareNum1のプロパティ名を返します。
     * 
     * @return spareNum1のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum1() {
        return new PropertyName<BigDecimal>("spareNum1");
    }

    /**
     * spareNum2のプロパティ名を返します。
     * 
     * @return spareNum2のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum2() {
        return new PropertyName<BigDecimal>("spareNum2");
    }

    /**
     * spareNum3のプロパティ名を返します。
     * 
     * @return spareNum3のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum3() {
        return new PropertyName<BigDecimal>("spareNum3");
    }

    /**
     * spareText1のプロパティ名を返します。
     * 
     * @return spareText1のプロパティ名
     */
    public static PropertyName<String> spareText1() {
        return new PropertyName<String>("spareText1");
    }

    /**
     * spareText2のプロパティ名を返します。
     * 
     * @return spareText2のプロパティ名
     */
    public static PropertyName<String> spareText2() {
        return new PropertyName<String>("spareText2");
    }

    /**
     * spareText3のプロパティ名を返します。
     * 
     * @return spareText3のプロパティ名
     */
    public static PropertyName<String> spareText3() {
        return new PropertyName<String>("spareText3");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _TrSasizuJskNames extends PropertyName<TrSasizuJskEntity> {

        /**
         * インスタンスを構築します。
         */
        public _TrSasizuJskNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _TrSasizuJskNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _TrSasizuJskNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * createdOnのプロパティ名を返します。
         *
         * @return createdOnのプロパティ名
         */
        public PropertyName<Timestamp> createdOn() {
            return new PropertyName<Timestamp>(this, "createdOn");
        }

        /**
         * createdByのプロパティ名を返します。
         *
         * @return createdByのプロパティ名
         */
        public PropertyName<String> createdBy() {
            return new PropertyName<String>(this, "createdBy");
        }

        /**
         * modifiedOnのプロパティ名を返します。
         *
         * @return modifiedOnのプロパティ名
         */
        public PropertyName<Timestamp> modifiedOn() {
            return new PropertyName<Timestamp>(this, "modifiedOn");
        }

        /**
         * modifiedByのプロパティ名を返します。
         *
         * @return modifiedByのプロパティ名
         */
        public PropertyName<String> modifiedBy() {
            return new PropertyName<String>(this, "modifiedBy");
        }

        /**
         * sasizuNoのプロパティ名を返します。
         *
         * @return sasizuNoのプロパティ名
         */
        public PropertyName<String> sasizuNo() {
            return new PropertyName<String>(this, "sasizuNo");
        }

        /**
         * sikanBiのプロパティ名を返します。
         *
         * @return sikanBiのプロパティ名
         */
        public PropertyName<String> sikanBi() {
            return new PropertyName<String>(this, "sikanBi");
        }

        /**
         * sikanSuのプロパティ名を返します。
         *
         * @return sikanSuのプロパティ名
         */
        public PropertyName<BigDecimal> sikanSu() {
            return new PropertyName<BigDecimal>(this, "sikanSu");
        }

        /**
         * sikanKbnのプロパティ名を返します。
         *
         * @return sikanKbnのプロパティ名
         */
        public PropertyName<String> sikanKbn() {
            return new PropertyName<String>(this, "sikanKbn");
        }

        /**
         * startDateのプロパティ名を返します。
         *
         * @return startDateのプロパティ名
         */
        public PropertyName<Timestamp> startDate() {
            return new PropertyName<Timestamp>(this, "startDate");
        }

        /**
         * endDateのプロパティ名を返します。
         *
         * @return endDateのプロパティ名
         */
        public PropertyName<Timestamp> endDate() {
            return new PropertyName<Timestamp>(this, "endDate");
        }

        /**
         * seisanJyotaiのプロパティ名を返します。
         *
         * @return seisanJyotaiのプロパティ名
         */
        public PropertyName<Integer> seisanJyotai() {
            return new PropertyName<Integer>(this, "seisanJyotai");
        }

        /**
         * jyotaiHenkoDateのプロパティ名を返します。
         *
         * @return jyotaiHenkoDateのプロパティ名
         */
        public PropertyName<Timestamp> jyotaiHenkoDate() {
            return new PropertyName<Timestamp>(this, "jyotaiHenkoDate");
        }

        /**
         * sekininsyaIdのプロパティ名を返します。
         *
         * @return sekininsyaIdのプロパティ名
         */
        public PropertyName<String> sekininsyaId() {
            return new PropertyName<String>(this, "sekininsyaId");
        }

        /**
         * repairSuのプロパティ名を返します。
         *
         * @return repairSuのプロパティ名
         */
        public PropertyName<BigDecimal> repairSu() {
            return new PropertyName<BigDecimal>(this, "repairSu");
        }

        /**
         * lineChgFlgのプロパティ名を返します。
         *
         * @return lineChgFlgのプロパティ名
         */
        public PropertyName<String> lineChgFlg() {
            return new PropertyName<String>(this, "lineChgFlg");
        }

        /**
         * tonyuSuのプロパティ名を返します。
         *
         * @return tonyuSuのプロパティ名
         */
        public PropertyName<BigDecimal> tonyuSu() {
            return new PropertyName<BigDecimal>(this, "tonyuSu");
        }

        /**
         * spareNum1のプロパティ名を返します。
         *
         * @return spareNum1のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum1() {
            return new PropertyName<BigDecimal>(this, "spareNum1");
        }

        /**
         * spareNum2のプロパティ名を返します。
         *
         * @return spareNum2のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum2() {
            return new PropertyName<BigDecimal>(this, "spareNum2");
        }

        /**
         * spareNum3のプロパティ名を返します。
         *
         * @return spareNum3のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum3() {
            return new PropertyName<BigDecimal>(this, "spareNum3");
        }

        /**
         * spareText1のプロパティ名を返します。
         *
         * @return spareText1のプロパティ名
         */
        public PropertyName<String> spareText1() {
            return new PropertyName<String>(this, "spareText1");
        }

        /**
         * spareText2のプロパティ名を返します。
         *
         * @return spareText2のプロパティ名
         */
        public PropertyName<String> spareText2() {
            return new PropertyName<String>(this, "spareText2");
        }

        /**
         * spareText3のプロパティ名を返します。
         *
         * @return spareText3のプロパティ名
         */
        public PropertyName<String> spareText3() {
            return new PropertyName<String>(this, "spareText3");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
