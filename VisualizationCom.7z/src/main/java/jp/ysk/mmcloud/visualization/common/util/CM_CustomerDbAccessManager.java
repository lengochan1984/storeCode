/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/02/21| 新規作成                           | 1.00.00| YSK)鬼丸
 *  2014/07/11| <10000-123> ST不具合対応           | 1.01.00| YSK)植山
 *  2016/01/26| <30101-002> 故障苦情No.30100-012   | 4.00.00| US)萩尾
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.util;

import java.util.HashMap;

import jp.ysk.mmcloud.common.dto.CM_CustomerDbAccessDto;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;

import org.seasar.extension.datasource.impl.DataSourceFactoryImpl;
import org.seasar.extension.dbcp.impl.ConnectionPoolImpl;
import org.seasar.extension.dbcp.impl.DataSourceImpl;
import org.seasar.extension.dbcp.impl.XADataSourceImpl;
import org.seasar.extension.jdbc.dialect.Postgre81Dialect;
import org.seasar.extension.jdbc.manager.JdbcManagerImpl;
import org.seasar.extension.jdbc.meta.ColumnMetaFactoryImpl;
import org.seasar.extension.jdbc.meta.EntityMetaFactoryImpl;
import org.seasar.extension.jdbc.meta.PropertyMetaFactoryImpl;
import org.seasar.extension.jdbc.meta.TableMetaFactoryImpl;
import org.seasar.extension.jta.TransactionManagerImpl;
import org.seasar.extension.jta.TransactionSynchronizationRegistryImpl;
import org.seasar.framework.convention.PersistenceConvention;
import org.seasar.framework.convention.impl.PersistenceConventionImpl;

/**
 *
 * 顧客用DBへの接続管理処理.<br>
 *<br>
 * 概要:<br>
 *   顧客用DBへの接続管理クラス
 *<br>
 */
public class CM_CustomerDbAccessManager {

    /**
     *
     * コンストラクタ.
     *
     */
    protected CM_CustomerDbAccessManager() {
        throw new UnsupportedOperationException();
    }

    /**
     * コネクションプール格納Map（顧客毎の管理）.
     */
    private static HashMap<String, CM_CustomerDbAccessDto> mapCustomerDbAccessDto = null;

    /**
     * コネクションプールのタイムアウト時間.
     */
    private static final int CONNECTION_POOL_TIMEOUT = 600;

    /**
     * コネクションプールの最大プールサイズ.
     */
    private static final int CONNECTION_POOL_MAX_SIZE = 10;

    /**
     *
     * 顧客DB接続の取得処理.<br>
     *<br>
     * 概要:<br>
     *   指定された顧客DBへの接続確立を行う
     *<br>
     * @param _strDataSource 顧客コード
     * @param _strUser 顧客コード
     * @param _strPassword 顧客コード
     * @param _queryTimeout クエリタイムアウト値
     * @return 顧客DB接続用JdbcManager
     */
    public static CM_CustomerDbAccessDto getCutomerDbAccess(final String _strDataSource,
            final String _strUser,
            final String _strPassword,
            final int _queryTimeout) {

        CM_CustomerDbAccessDto customerDbAccessDto = null;

        try {

            if (mapCustomerDbAccessDto == null) {
                mapCustomerDbAccessDto = new HashMap<String, CM_CustomerDbAccessDto>();
            }

            customerDbAccessDto = mapCustomerDbAccessDto.get(_strUser);
            if (customerDbAccessDto == null) {
                // トランザクションマネージャの初期化
                TransactionManagerImpl transactionManager = new TransactionManagerImpl();
                XADataSourceImpl xaDataSource = new XADataSourceImpl();
                xaDataSource.setDriverClassName("org.postgresql.Driver");
                xaDataSource.setURL("jdbc:postgresql:" + _strDataSource);
                xaDataSource.setUser(_strUser);
                xaDataSource.setPassword(_strPassword);

                ConnectionPoolImpl connectionPool = new ConnectionPoolImpl();
                connectionPool.setXADataSource(xaDataSource);
                connectionPool.setTransactionManager(transactionManager);
                connectionPool.setTimeout(CONNECTION_POOL_TIMEOUT);
                connectionPool.setMaxPoolSize(CONNECTION_POOL_MAX_SIZE);
                connectionPool.setAllowLocalTx(true);

                TransactionSynchronizationRegistryImpl syncRegistry = new TransactionSynchronizationRegistryImpl();
                syncRegistry.setTransactionManager(transactionManager);

                // データソースの初期化
                DataSourceImpl dataSource = new DataSourceImpl(connectionPool);

                // エンティティメタファクトリの初期化
                EntityMetaFactoryImpl entityMetaFactory = new EntityMetaFactoryImpl();
                PersistenceConvention persistenceConvention = new PersistenceConventionImpl();
                entityMetaFactory.setPersistenceConvention(persistenceConvention);
                PropertyMetaFactoryImpl propertyMetaFactory = new PropertyMetaFactoryImpl();
                ColumnMetaFactoryImpl columnMetaFactory = new ColumnMetaFactoryImpl();
                columnMetaFactory.setPersistenceConvention(persistenceConvention);
                propertyMetaFactory.setColumnMetaFactory(columnMetaFactory);
                propertyMetaFactory.setPersistenceConvention(persistenceConvention);
                entityMetaFactory.setPropertyMetaFactory(propertyMetaFactory);
                TableMetaFactoryImpl tableMetaFactory = new TableMetaFactoryImpl();
                tableMetaFactory.setPersistenceConvention(persistenceConvention);
                entityMetaFactory.setTableMetaFactory(tableMetaFactory);

                // ダイアレクトの初期化
                Postgre81Dialect postgre81Dialect = new Postgre81Dialect();

                // データソースの初期化
                DataSourceFactoryImpl dataSourceFactory = new DataSourceFactoryImpl();

                // JdbcManagerの初期化
                JdbcManagerImpl jdbcManager = new JdbcManagerImpl();
                jdbcManager.setSyncRegistry(syncRegistry);
                jdbcManager.setPersistenceConvention(persistenceConvention);
                jdbcManager.setEntityMetaFactory(entityMetaFactory);
                jdbcManager.setDataSource(dataSource);
                jdbcManager.setDataSourceFactory(dataSourceFactory);
                jdbcManager.setDialect(postgre81Dialect);
                jdbcManager.setQueryTimeout(_queryTimeout);

                customerDbAccessDto = new CM_CustomerDbAccessDto();
                customerDbAccessDto.jdbcManager = jdbcManager;
                customerDbAccessDto.userTransactionMng = transactionManager;

                mapCustomerDbAccessDto.put(_strUser, customerDbAccessDto);
            }

        } catch (Exception e) {
            // エラーログ出力
            CM_LoggerUtil.outputErrorLog(null, e);
        }

        return customerDbAccessDto;
    }
}
