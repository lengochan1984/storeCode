/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/07/20| <C1.01>　新規作成（共通化対応取込）                                  | C1.01  | US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.util.CM_DisplayCharResourceUtil;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.common.util.CM_MessageResourceUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_DispAccessLogDao;
import jp.ysk.mmcloud.visualization.common.dto.AndongInfoDto;
import jp.ysk.mmcloud.visualization.common.dto.CM_MonthInfoDto;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSearchConditionEntity;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;
import jp.ysk.mmcloud.visualization.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.visualization.common.util.CM_MessageUtil;

import org.seasar.framework.beans.util.BeanMap;


/**
 * 画面共通サービス.<br>
 *<br>
 * 概要:<br>
 *   画面共通処理のサービスクラスの
 *<br>
 */
public abstract class CM_VisualizationBaseService extends CM_BaseService {

    /**
     * コンストラクタ.
     *<br>
     * 概要:<br>
     *   DB接続を行わないサービス処理用コンストラクタ
     */
    public CM_VisualizationBaseService() {
    }

    /**
     *
     * セッション情報設定処理.<br>
     *<br>
     * 概要:<br>
     *   セッション情報設定の処理を実行する
     *<br>
     * @param _sessionDto 共通セッション情報
     */
    public void setSessionDto(final CM_A03_SessionDto _sessionDto) {
        // セッション情報をメンバ変数に保存
        this.sessionDto = _sessionDto;
    }

    /**
     *
     * 画面アクセス数のカウントアップ更新処理.<br>
     *<br>
     * 概要:<br>
     *   画面アクセス数のカウントアップ更新処理を実行する
     *<br>
     * @param _strDispId 画面ID
     */
    public void countUpAccessCount(final String _strDispId) {

        CM_DispAccessLogDao baseDao = null;

        try {
            // Dao生成
            baseDao = new CM_DispAccessLogDao();
            this.initCustomerDbDao(baseDao);

            // トランザクション開始
            baseDao.biginTransaction();

            // アクセスカウント更新
            baseDao.countUpAccessCount(_strDispId);

            // トランザクションコミット
            baseDao.commitTransaction();

        } catch (Exception ex) {
            if (baseDao != null) {
                baseDao.rollbackTransaction();
            }
            // エラー発生時はログ出力を行い、業務側へはエラーを発生させない
            CM_LoggerUtil.outputErrorLog(null, ex);
        }
    }

    /**
     *
     * ユーザ工場CD取得.<br>
     *<br>
     * 概要:<br>
     *  ユーザ工場CD取得処理<br>
     *  作業者マスタからログインユーザのIDを元に工場コードを取得する
     *<br>
     * @return ユーザ工場CD
     */
    public String getUserPlantCode() {
        return this.getCustomerDao().getUserPlantCode(this.sessionDto.ssn_UserID);
    }

    /**
     * 画面データアクセスDaoを取得.<br>
     * <br>
     * 概要:<br>
     *   画面データアクセスDaoを取得
     *
     *
     * @return 画面データアクセスDao
     */
    @Override
    protected abstract CM_BaseDao getCustomerDao();


    /**
     *
     * 禁則文字チェック.<br>
     * <br>
     * 概要:<br>
     *   禁則文字が含まれていないかチェックし、含まれている場合は例外を発生させる
     *
     * @param _strValue チェック対象の文字列
     * @param _arrForbidStr 禁則文字
     * @param _ctlKey フォーカスID
     * @param _resourceKey リソースキー
     */
    protected void checkForbidChar(final String _strValue, final String[] _arrForbidStr, final String _ctlKey, final String _resourceKey) {
        if (CM_CommonUtil.isNullOrBlank(_strValue)) {
            return;
        }

        // 禁則文字の存在チェック
        String forbidChar = CM_CommonUtil.checkForbidCharExists(_strValue, _arrForbidStr);

        // 禁則文字を含む場合、エラーメッセージを取得
        if (CM_CommonUtil.isNotNullOrBlank(forbidChar)) {
            String strErrorMes = CM_MessageUtil.getForibidCharErrorMessage(this.sessionDto, _resourceKey, forbidChar);
            strErrorMes = CM_CommonUtil.escapeJavascript(strErrorMes);
            throw new FW00_12_BusinessException(strErrorMes, _ctlKey);
        }
    }

    /**
     * テキスト必須チェック.<br>
     *<br>
     * 概要:<br>
     *   テキスト入力の必須チェック
     *<br>
     * @param _formMap フォーム情報
     * @param _ctlKey コントロールキー
     * @param _resourceKey リソースキー
     * @return 入力値
     */
    protected String checkTextNessesary(final BeanMap _formMap, final String _ctlKey, final String _resourceKey) {
        return checkNessesary("MMCMCM00000_051", _formMap, _ctlKey, _resourceKey);
    }

    /**
     * プルダウン必須チェック.<br>
     *<br>
     * 概要:<br>
     *   プルダウン選択の必須チェック
     *<br>
     * @param _formMap フォーム情報
     * @param _ctlKey コントロールキー
     * @param _resourceKey リソースキー
     * @return 入力値
     */
    protected String checkPldNessesary(final BeanMap _formMap, final String _ctlKey, final String _resourceKey) {
        return checkNessesary("MMCMCM00000_052", _formMap, _ctlKey, _resourceKey);
    }

    /**
     * テキスト必須チェック.<br>
     *<br>
     * 概要:<br>
     *   テキスト入力の必須チェック
     *<br>
     * @param _msgKey メッセージキー(メッセージ)
     * @param _formMap フォーム情報
     * @param _ctlKey コントロールキー
     * @param _resourceKey リソースキー(項目名)
     * @return 入力値
     */
    private String checkNessesary(final String _msgKey, final BeanMap _formMap, final String _ctlKey, final String _resourceKey) {
        if (!_formMap.containsKey(_ctlKey)) {
            // 必須のためエラー
            List<String> strParam = new ArrayList<String>();
            strParam.add(CM_DisplayCharResourceUtil.getDisplayCharValue(this.sessionDto.ssn_CustomerCD, this.sessionDto.ssn_UserLangCD, _resourceKey));

            String errorMsg = CM_MessageResourceUtil.getMessageValueParam(
                    this.sessionDto.ssn_CustomerCD,
                    this.sessionDto.ssn_UserLangCD,
                    _msgKey, (String[]) strParam.toArray(new String[strParam.size()]));

            throw new FW00_12_BusinessException(errorMsg, _ctlKey);
        }

        Object param = _formMap.get(_ctlKey);

        if (CM_CommonUtil.isNullOrBlank(param)) {
            // 必須のためエラー
            List<String> strParam = new ArrayList<String>();
            strParam.add(CM_DisplayCharResourceUtil.getDisplayCharValue(this.sessionDto.ssn_CustomerCD, this.sessionDto.ssn_UserLangCD, _resourceKey));

            String errorMsg = CM_MessageResourceUtil.getMessageValueParam(
                    this.sessionDto.ssn_CustomerCD,
                    this.sessionDto.ssn_UserLangCD,
                    _msgKey, (String[]) strParam.toArray(new String[strParam.size()]));

            throw new FW00_12_BusinessException(errorMsg, _ctlKey);
        }

        return param.toString();
    }

    /**
     * 日時妥当性チェック.<br>
     *<br>
     * 概要:<br>
     *   日時妥当性の必須チェック
     *<br>
     * @param _formMap フォーム情報
     * @param _ctlKey コントロールキー
     * @param _resourceKey リソースキー(項目名)
     * @param _format 日付フォーマット
     * @return 入力値
     */
    protected Date chekDatetime(final BeanMap _formMap, final String _ctlKey, final String _resourceKey, final String _format) {
        String param = (String) _formMap.get(_ctlKey);
        Date datetime = CM_CommonUtil.parseString(param, _format);
        if (CM_CommonUtil.isNullOrBlank(datetime)) {
            String strErrorMes = CM_MessageUtil.getDatetimeFormatErrorMessage(this.sessionDto, _resourceKey);
            throw new FW00_12_BusinessException(strErrorMes, _ctlKey);
        }
        return datetime;
    }

    /**
     * 日時大小関係チェック.<br>
     *<br>
     * 概要:<br>
     *   日時の大小関係チェック
     *<br>
     * @param _from 日時From
     * @param _to 日時To
     * @param _ctlKey コントロールキー
     * @param _resourceKey リソースキー(項目名)
     */
    protected void chekDatetimeMagnitude(final Date _from, final Date _to, final String _ctlKey, final String _resourceKey) {
        if (_from.compareTo(_to) > 0) {
            String strErrorMes = CM_MessageUtil.getDateMagnitudeErrorMessage(this.sessionDto, _resourceKey);
            throw new FW00_12_BusinessException(strErrorMes, _ctlKey);
        }
    }

    /**
     *
     * 月の情報取得.<br>
     *<br>
     * 概要:<br>
     * 月の情報取得
     *<br>
     * @param _plantCode 工場コード
     * @param _dateFormat 日付フォーマット
     * @param _monthlyFormat 月度フォーマット
     * @return 月情報
     */
    public CM_MonthInfoDto getMonthInfo(final String _plantCode, final String _dateFormat, final String _monthlyFormat) {
        // 現在日取得
        Date now = CM_CommonUtil.getNowGmtDatetime();
        // GMT⇒ログインユーザのタイムゾーンに変換
        String sNow = CM_CommonUtil.getTimeGmtToTimezone(new Timestamp(now.getTime()),
                this.sessionDto.ssn_UserTimezoneCD, CM_A04_Const.DATE_FORMAT_DATE);
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT_DATE);
            now = sdf.parse(sNow);
        } catch (ParseException e) {
            CM_LoggerUtil.outputErrorLog(this.sessionDto, e);
        }
        return this.getMonthInfo(_plantCode, now, _dateFormat, _monthlyFormat);
    }

    /**
     *
     * 月の情報取得.<br>
     *<br>
     * 概要:<br>
     *  月の情報取得
     *<br>
     * @param _plantCode 工場コード
     * @param _date 日時
     * @param _dateFormat 日付フォーマット
     * @param _monthlyFormat 月度フォーマット
     * @return 月情報
     */
    public CM_MonthInfoDto getMonthInfo(final String _plantCode, final Date _date,
            final String _dateFormat, final String _monthlyFormat) {
        CM_MonthInfoDto ret = new CM_MonthInfoDto(_dateFormat, _monthlyFormat);

        // 工場マスタ(見える化専用)情報取得
        MaPlantEntity plantInfo = this.getCustomerDao().getMstPlant(_plantCode);
        Calendar plantCal = Calendar.getInstance();
        if (plantInfo != null) {
            plantCal.setTime(new Date(plantInfo.runningStartDatetime.getTime()));
        } else {
            plantCal.setTime(CM_CommonUtil.fromString(CM_A04_Const.DEFAULT_RUNNING_START_DATETIME, CM_A04_Const.DATE_FORMAT_SEC_HYPHEN));
        }
        ret.setPlantCalendar(plantCal);

        // 月初めの日にちを取得
        int startDate = plantCal.get(Calendar.DATE);

        Calendar targetCal = Calendar.getInstance();
        targetCal.setTime(_date);

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(_dateFormat);
        SimpleDateFormat sdf2 = new SimpleDateFormat(_monthlyFormat);
        if (targetCal.get(Calendar.DATE) >= startDate) {
            // 月初日
            cal.set(targetCal.get(Calendar.YEAR), targetCal.get(Calendar.MONTH), startDate);
            String tmpStartDate = sdf.format(cal.getTime());
            ret.setFirstDate(tmpStartDate);
        } else {
            // 月初日
            cal.set(targetCal.get(Calendar.YEAR), targetCal.get(Calendar.MONTH) - 1, startDate);
            String tmpStartDate = sdf.format(cal.getTime());
            ret.setFirstDate(tmpStartDate);
        }
        // 月末日
        cal.add(Calendar.MONTH, 1);
        cal.add(Calendar.DATE, -1);
        String tmpEndDate = sdf.format(cal.getTime());
        ret.setEndDate(tmpEndDate);
        // 月度
        String tmpMontly = sdf2.format(cal.getTime());
        ret.setMonthly(tmpMontly);

        return ret;
    }

    /**
    *
    * 登録検索条件を取得.<br>
    *<br>
    * 概要:<br>
    *  登録検索条件一覧取得処理
    *<br>
    * @param _pageId 画面ID
    * @param _favoriteNo お気に入り番号
    * @return 登録検索条件一覧
    */
    public List<TrSearchConditionEntity> getRegisterSearchCondition(final String _pageId, final String _favoriteNo) {
        List<TrSearchConditionEntity> ret = this.getCustomerDao().selectTblSearchCondition(this.sessionDto.ssn_UserSID, _pageId, _favoriteNo);
        return ret;
    }

   /**
    *
    * 登録検索条件チェック処理.<br>
    *<br>
    * 概要:<br>
    * 登録する検索条件のチェックを行う
    *<br>
    * @param _formMap フォーム情報
    */
   public abstract void checkRegisterSearchCondition(final BeanMap _formMap);

   /**
    *
    * 検索条件登録処理.<br>
    *<br>
    * 概要:<br>
    *  検索条件の登録処理
    *<br>
    * @param _formMap フォーム情報
    * @param _pageId 画面ID
    */
    public void registerSearchCondition(final BeanMap _formMap, final String _pageId) {
        // お気に入り番号
        String favoriteNoStr = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO);
        Integer favoriteNo = Integer.valueOf(favoriteNoStr);

        // 登録するパラメータ名を取得
        List<String> registerParamList = this.getRegisterParamNameList();

        // 共通登録対象検索条件パラメータ名取得
        registerParamList = this.getComRegisterParamNameList(registerParamList);

        // トランザクション開始
        this.getCustomerDao().biginTransaction();

        // 検索条件削除
        this.getCustomerDao().deleteFavorite(this.sessionDto.ssn_UserSID, favoriteNo);

        try {
            int index = 0;
            for (String registerParamName : registerParamList) {
                List<String> paramValueList = new ArrayList<String>();

                Object objParamValue = _formMap.get(registerParamName);
                if (CM_CommonUtil.isNotNullOrBlank(objParamValue)) {
                    if (objParamValue instanceof List) {
                        // リストの場合
                        @SuppressWarnings("unchecked")
                        List<String> tmpParamValue = (List<String>) objParamValue;
                        paramValueList = tmpParamValue;
                    } else if (objParamValue instanceof String[]) {
                        // 配列の場合
                        String[] tmpParamValue = (String[]) objParamValue;
                        paramValueList = Arrays.asList(tmpParamValue);
                    } else {
                        paramValueList.add(objParamValue.toString());
                    }
                } else {
                    paramValueList.add(FW00_19_Const.EMPTY_STR);
                }

                String favoriteName = "";
                for (String paramValue : paramValueList) {
                    TrSearchConditionEntity registData = new TrSearchConditionEntity();
                    registData.userSid = this.sessionDto.ssn_UserSID;
                    registData.favoriteNo = favoriteNo;
                    registData.pageId = _pageId;
                    registData.insProg = _pageId;
                    registData.updProg = _pageId;
                    registData.conditionNum = index;
                    registData.paramName = registerParamName;
                    registData.paramValue = paramValue;
                    Timestamp now = new Timestamp(System.currentTimeMillis());
                    registData.insTim = new Timestamp(now.getTime());
                    registData.updTim = new Timestamp(now.getTime());
                    registData.insUserSid = this.sessionDto.ssn_UserSID;
                    registData.updUserSid = this.sessionDto.ssn_UserSID;
                    switch  (favoriteNo) {
                        case 1:
                            if (CM_CommonUtil.isNullOrBlank((String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME1))) {
                                favoriteName = "";
                            } else {
                                favoriteName = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME1);
                            }
                            break;
                        case 2:
                            if (CM_CommonUtil.isNullOrBlank((String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME2))) {
                                favoriteName = "";
                            } else {
                                favoriteName = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME2);
                            }
                            break;
                        case 3:
                            if (CM_CommonUtil.isNullOrBlank((String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME3))) {
                                favoriteName = "";
                            } else {
                                favoriteName = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME3);
                            }
                            break;
                        case 4:
                            if (CM_CommonUtil.isNullOrBlank((String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME4))) {
                                favoriteName = "";
                            } else {
                                favoriteName = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME4);
                            }
                            break;
                        case 5:
                            if (CM_CommonUtil.isNullOrBlank((String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME5))) {
                                favoriteName = "";
                            } else {
                                favoriteName = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME5);
                            }
                            break;
                        case 6:
                            if (CM_CommonUtil.isNullOrBlank((String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME6))) {
                                favoriteName = "";
                            } else {
                                favoriteName = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME6);
                            }
                            break;
                        default:
                            break;
                    }
                    registData.favoriteName = favoriteName;

                    this.getCustomerDao().insertTblSearchCondition(registData);
                    index++;
                }
            }
            // コミット
            this.getCustomerDao().commitTransaction();
        } catch (Exception e) {
            CM_LoggerUtil.outputErrorLog(this.sessionDto, e);
            // ロールバック
            this.getCustomerDao().rollbackTransaction();
        }

    }

    /**
    *
    * お気に入り名称登録処理.<br>
    *<br>
    * 概要:<br>
    *  お気に入り名称の登録処理
    *<br>
    * @param _formMap フォーム情報
    * @param _pageId 画面ID
    */
    public void registerPageName(final BeanMap _formMap, final String _pageId) {

        // トランザクション開始
        this.getCustomerDao().biginTransaction();

        try {
            String favoriteNo = null;
            String favoriteName = null;
            for (int index = 1; index < 7; index++) {
                TrSearchConditionEntity registData = new TrSearchConditionEntity();
                registData.userSid = this.sessionDto.ssn_UserSID;
                switch  (index) {
                    case 1:
                        if (CM_CommonUtil.isNullOrBlank((String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO1))) {
                            continue;
                        }
                        favoriteNo = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO1);
                        favoriteName = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME1);
                        break;
                    case 2:
                        if (CM_CommonUtil.isNullOrBlank((String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO2))) {
                            continue;
                        }
                        favoriteNo = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO2);
                        favoriteName = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME2);
                        break;
                    case 3:
                        if (CM_CommonUtil.isNullOrBlank((String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO3))) {
                            continue;
                        }
                        favoriteNo = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO3);
                        favoriteName = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME3);
                        break;
                    case 4:
                        if (CM_CommonUtil.isNullOrBlank((String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO4))) {
                            continue;
                        }
                        favoriteNo = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO4);
                        favoriteName = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME4);
                        break;
                    case 5:
                        if (CM_CommonUtil.isNullOrBlank((String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO5))) {
                            continue;
                        }
                        favoriteNo = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO5);
                        favoriteName = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME5);
                        break;
                    case 6:
                        if (CM_CommonUtil.isNullOrBlank((String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO6))) {
                            continue;
                        }
                        favoriteNo = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO6);
                        favoriteName = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NAME6);
                        break;
                    default:
                        break;
                }
                registData.favoriteNo = Integer.parseInt(favoriteNo);
                registData.favoriteName = favoriteName;
                registData.updProg = _pageId;
                Timestamp now = new Timestamp(System.currentTimeMillis());
                registData.updTim = new Timestamp(now.getTime());
                registData.updUserSid = this.sessionDto.ssn_UserSID;

                // お気に入り条件登録
                this.getCustomerDao().updateFavoriteName(registData);
            }
            // コミット
            this.getCustomerDao().commitTransaction();
        } catch (Exception e) {
            CM_LoggerUtil.outputErrorLog(this.sessionDto, e);
            // ロールバック
            this.getCustomerDao().rollbackTransaction();
        }

    }

   /**
    * 共通登録対象検索条件パラメータ名取得処理.<br>
    *<br>
    * 概要:<br>
    *   登録の対象にする共通検索条件のパラメータ名を設定する
    *<br>
    * @return 登録対象検索条件パラメータ名一覧
    */
    private List<String> getComRegisterParamNameList(List<String> ret) {
        if (ret == null) {
            ret = new ArrayList<String>();
        }
        // 工場
        ret.add(CM_BaseForm.COM_PLANT_CODE);
        // 製造ライン
        ret.add(CM_BaseForm.COM_SEIZOU_LN_ID);
        // 工程ID
        ret.add(CM_BaseForm.COM_PROCESS_ID);
        // ラインID
        ret.add(CM_BaseForm.COM_LN_ID);
        // ステーションID
        ret.add(CM_BaseForm.COM_ST_ID);
        return ret;
    }

   /**
    *
    * 登録対象検索条件パラメータ名取得処理.<br>
    *<br>
    * 概要:<br>
    *   登録の対象にする検索条件のパラメータ名を設定する
    *<br>
    * @return 登録対象検索条件パラメータ名一覧
    */
   protected abstract List<String> getRegisterParamNameList();

   /**
    *
    * お気に入り削除処理.<br>
    *<br>
    * 概要:<br>
    *  お気に入り削除処理
    *<br>
    * @param _formMap フォーム情報
    * @param _favoriteNo お気に入り番号
    */
   public void deleteFavorite(final BeanMap _formMap) {
       // お気に入り番号
       String favoriteNoStr = (String) _formMap.get(CM_BaseForm.HDN_FAVORITE_NO);
       Integer favoriteNo = Integer.valueOf(favoriteNoStr);
       // お気に入り削除
       this.getCustomerDao().deleteFavorite(this.sessionDto.ssn_UserSID, favoriteNo);
   }

   /**
    * アンドン用データ取得<br>
    * 概要：<br>
    * アンドン用のデータを取得します.<br>
    *<br>
    * @param _formMap フォーム
    * @return アンドン表示データ
    */
   public AndongInfoDto getAndongInfo(final BeanMap _formMap) {
       return this.getCustomerDao().getAndongInfoDto(_formMap);
   }

}
