package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 画面アクセスカウントデータ
 * 
 */
@Entity
@Table(name = "tbl_disp_access_count_data")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class TblDispAccessCountDataEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** アクセス日時 : yyyymmdd hhで登録（年、月、日、時間はゼロ埋め） */
    @Id
    @Column(length = 11, nullable = false, unique = false)
    public String accessDatetime;

    /** ページID : ページマスタと他テーブルとのリンクキー
環境マスタの環境CD="page_id"とリンク。 */
    @Id
    @Column(length = 64, nullable = false, unique = false)
    public String pageId;

    /** カウント数 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer countNum;

    /** 最終更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String lastUpdProg;

    /** 最終更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp lastUpdTim;
}
