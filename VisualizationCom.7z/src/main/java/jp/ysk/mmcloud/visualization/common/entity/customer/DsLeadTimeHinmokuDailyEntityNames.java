package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link DsLeadTimeHinmokuDailyEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class DsLeadTimeHinmokuDailyEntityNames {

    /**
     * plantCdのプロパティ名を返します。
     * 
     * @return plantCdのプロパティ名
     */
    public static PropertyName<String> plantCd() {
        return new PropertyName<String>("plantCd");
    }

    /**
     * sasizuNoのプロパティ名を返します。
     * 
     * @return sasizuNoのプロパティ名
     */
    public static PropertyName<String> sasizuNo() {
        return new PropertyName<String>("sasizuNo");
    }

    /**
     * subNoのプロパティ名を返します。
     * 
     * @return subNoのプロパティ名
     */
    public static PropertyName<BigDecimal> subNo() {
        return new PropertyName<BigDecimal>("subNo");
    }

    /**
     * buhinCdのプロパティ名を返します。
     * 
     * @return buhinCdのプロパティ名
     */
    public static PropertyName<String> buhinCd() {
        return new PropertyName<String>("buhinCd");
    }

    /**
     * dataDateのプロパティ名を返します。
     * 
     * @return dataDateのプロパティ名
     */
    public static PropertyName<Timestamp> dataDate() {
        return new PropertyName<Timestamp>("dataDate");
    }

    /**
     * leadTimeのプロパティ名を返します。
     * 
     * @return leadTimeのプロパティ名
     */
    public static PropertyName<Long> leadTime() {
        return new PropertyName<Long>("leadTime");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _DsLeadTimeHinmokuDailyNames extends PropertyName<DsLeadTimeHinmokuDailyEntity> {

        /**
         * インスタンスを構築します。
         */
        public _DsLeadTimeHinmokuDailyNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _DsLeadTimeHinmokuDailyNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _DsLeadTimeHinmokuDailyNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * plantCdのプロパティ名を返します。
         *
         * @return plantCdのプロパティ名
         */
        public PropertyName<String> plantCd() {
            return new PropertyName<String>(this, "plantCd");
        }

        /**
         * sasizuNoのプロパティ名を返します。
         *
         * @return sasizuNoのプロパティ名
         */
        public PropertyName<String> sasizuNo() {
            return new PropertyName<String>(this, "sasizuNo");
        }

        /**
         * subNoのプロパティ名を返します。
         *
         * @return subNoのプロパティ名
         */
        public PropertyName<BigDecimal> subNo() {
            return new PropertyName<BigDecimal>(this, "subNo");
        }

        /**
         * buhinCdのプロパティ名を返します。
         *
         * @return buhinCdのプロパティ名
         */
        public PropertyName<String> buhinCd() {
            return new PropertyName<String>(this, "buhinCd");
        }

        /**
         * dataDateのプロパティ名を返します。
         *
         * @return dataDateのプロパティ名
         */
        public PropertyName<Timestamp> dataDate() {
            return new PropertyName<Timestamp>(this, "dataDate");
        }

        /**
         * leadTimeのプロパティ名を返します。
         *
         * @return leadTimeのプロパティ名
         */
        public PropertyName<Long> leadTime() {
            return new PropertyName<Long>(this, "leadTime");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
