/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/07/20| <C1.01>　新規作成（共通化対応取込）                                  | C1.01  | US)萩尾
 *  2017/05/15| <C1.02>　トレーサビリティ、レポート出力追加                          | C1.02  | YSK)元満
 *  2017/05/29| <C1.00>　トレーサビリティ                                           | C1.00  | YSK)ThanhDM
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common;

import java.util.ArrayList;
import java.util.List;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.visualization.common.util.CM_MenuAuthInfoUtil;

/**
 *
 * 画面ID情報.<br>
 *<br>
 * 概要:<br>
 * 全画面の画面ID等の情報
 *<br>
 */
public enum CM_A05_PageInfo {

    /**
     * 画面ID：ホーム.
     */
    PAGE_ID_HOME("A00-0020", "a000020Home", true, true, true),

    /**
     * 画面ID：機器稼働状況一覧.
     */
    PAGE_ID_OPERATION_STATUS_LIST("A01-0010", "a010010OperationStatusList", true, true, true),

    /**
     * 画面ID：機器トレンドモニタ.
     */
    PAGE_ID_TREND_MONITOR("A01-0020", "a010020TrendMonitor", true, true, true),

    /**
     * 画面ID：機器詳細.
     */
    PAGE_ID_DEVICE_DESC("A01-0030", "a010030DeviceDesc", true, true, true),

    /**
     * 画面ID：点検保守状況.
     */
    PAGE_ID_MAINTE_STATUS("A01-0040", "a010040MainteStatus", true, true, true),

    /**
     * 画面ID：報告書.
     */
    PAGE_ID_RAPORT_CREATE("A01-0050", "a010050ReportCreate", true, true, true),

    /**
     * 画面ID：アラーム履歴.
     */
    PAGE_ID_ALARM_HISTORY ("A01-0070", "a010070AlarmHistory", true, true, true),

    /**
     * 画面ID：通信状況一覧.
     */
    PAGE_ID_TELECOM_STATUS_LIST("A01-0080", "a010080TelecomStatusList", true, true, true),

    /**
     * 画面ID：機器稼働時間一覧.
     */
    PAGE_ID_OPERATION_TIME_LIST("A01-0090", "a010090OperationTimeList", true, true, true),

    /**
     * 画面ID：配信状況一覧.
     */
    PAGE_ID_DISTRIBUTION_STATUS_LIST("A01-0100", "a010100DistributionStatusList", true, true, true),

    /**
     * 画面ID：通信ログ一覧.
     */
    PAGE_ID_TELECOM_LOG_LIST("A01-0110", "a010110TelecomLogList", true, true, true),

    /**
     * 画面ID：コマンド実行.
     */
    PAGE_ID_SEND_COMMAND_LIST("A01-0120", "a010120SendCommandList", true, true, true),

    /**
     * 画面ID：稼働状況分析.
     */
    PAGE_ID_OPERATION_STATUS_ANALYSIS("A02-0010", "a020010OperationStatusAnalysis", true, true, true),

    /**
     * 画面ID：アラーム状況分析.
     */
    PAGE_ID_ALARM_STATUS_ANALYSIS("A02-0020", "a020020AlarmStatusAnalysis", true, true, true),

    /**
     * 画面ID：資料一覧.
     */
    PAGE_ID_DOCUMENT_LIST("A03-0010", "a030010DocumentList", true, true, true),

    /**
     * 画面ID：資料情報.
     */
    PAGE_ID_DOCUMENT_INFO("A03-0020", "a030020DocumentInfo", true, true, true),

    /**
     * 画面ID:システム設定.
     */
    PAGE_ID_SYSTEMSETTING("A50-0010", "a500010SystemSettings", true, false, false),

    /**
     * 画面ID：ユーザ一覧.
     */
    PAGE_ID_USER_LIST("A50-0020", "a500020UserList", true, true, true),

    /**
     * 画面ID：ユーザ一覧.
     */
    PAGE_ID_USER_LIST_V("C18-0020", "c180020UserList", true, true, true),

    /**
     * 画面ID：ユーザ情報.
     */
//    PAGE_ID_USER_INFO("A50-0030", "a500030UserInfo", true, true, true),

    /**
     * 画面ID：役割一覧.
     */
    PAGE_ID_ROLELIST("A50-0040", "a500040RoleList", true, false, false),

    /**
     * 画面ID:役割情報.
     */
    PAGE_ID_ROLEINFO("A50-0050", "a500050RoleInfo", true, false, false),

    /**
     * 画面ID：型番一覧.
     */
    PAGE_ID_MODEL_LIST("A50-0060", "a500060ModelList", true, true, true),

    /**
     * 画面ID：型番情報.
     */
    PAGE_ID_MODEL_INFO("A50-0070", "a500070ModelInfo", true, true, true),

    /**
     * 画面ID：アラーム条件一覧.
     */
    PAGE_ID_ALARM_TRIGGER_LIST("A50-0080", "a500080AlarmTriggerList", true, true, true),

    /**
     * 画面ID：アラーム条件情報.
     */
    PAGE_ID_ALARM_TRIGGER_INFO("A50-0090", "a500090AlarmTriggerInfo", true, true, true),

    /**
     * 画面ID：通信プロファイル一覧.
     */
    PAGE_ID_COMMAND_PROFILE_LIST("A50-0100", "a500100CommandProfileList", true, true, true),

    /**
     * 画面ID：通信プロファイル情報.
     */
    PAGE_ID_COMMAND_PROFILE_INFO("A50-0110", "a500110CommandProfileInfo", true, true, true),

    /**
     * 画面ID：機器一覧.
     */
    PAGE_ID_DEVICE_LIST("A50-0120", "a500120DeviceList", true, true, true),

    /**
     * 画面ID：機器情報.
     */
    PAGE_ID_DEVICE_INFO("A50-0130", "a500130DeviceInfo", true, true, true),

    /**
     * 画面ID:グループ一覧.
     */
    PAGE_ID_GROUPLIST("A50-0160", "a500160GroupList", true, true, false),

    /**
     * 画面ID:グループ情報.
     */
    PAGE_ID_GROUPINFO("A50-0170", "a500170GroupInfo", true, true, false),

    /**
     * 画面ID:トレンドビュー一覧.
     */
    PAGE_ID_TRENDVIEW("A50-0200", "a500200TrendViewList", true, true, false),

    /**
     * 画面ID:トレンドビュー情報.
     */
    PAGE_ID_TRENDINFO("A50-0210", "a500210TrendViewInfo", true, true, false),

    /**
     * 画面ID:稼働状態定義情報.
     */
    PAGE_ID_OPERATION_STATUS_INFO("A50-0230", "a500230OperationStatusSetInfo", true, true, true),

    /**
     * 画面ID：配信データ一覧.
     */
    PAGE_ID_DISTRIBUTION_DATA_LIST("A50-0240", "a500240DistributionDataList", true, true, true),

    /**
     * 画面ID：配信データ情報.
     */
    PAGE_ID_DISTRIBUTION_DATA_INFO("A50-0250", "a500250DistributionDataInfo", true, true, true),

    /**
     * 画面ID：イベント変換一覧.
     */
    PAGE_ID_EVENT_CHANGE_LIST("A50-0260", "a500260EventChangeList", true, true, true),

    /**
     * 画面ID：イベント変換情報.
     */
    PAGE_ID_EVENT_CHANGE_INFO("A50-0270", "a500270EventChangeInfo", true, true, true),

    /**
     * 画面ID:お知らせ情報.
     */
    PAGE_ID_NEWSINFO("A50-0900", "a500900NewsInfo", true, true, false),

    /**
     * 画面ID:お知らせ一覧.
     */
    PAGE_ID_NEWSLIST("A50-0910", "a500910NewsList", true, true, false),

    /**
     * 画面ID：モニタHOME.
     */
    PAGE_ID_MONITOR_HOME("C10-0010", "c100010MonitorHome", true, true, true, true),

    /**
     * 画面ID：作業区状況モニタ.
     */
    PAGE_ID_WORK_AREA_STATUS_MONITOR("C01-0010", "c010010WorkAreaStatusMonitor", true, true, true, true),

    /**
     * 画面ID：ライン状況モニタ.
     */
    PAGE_ID_LINE_STATUS_MONITOR("C01-0020", "c010020LineStatusMonitor", true, true, true),

    /**
     * 画面ID：計画数設定.
     */
    PAGE_ID_PLANNING_QUANTITY_SETTING("C01-0030", "c010030PlanningQuantitySetting", true, true, true),

    /**
     * 画面ID：滞留分析.
     */
    PAGE_ID_RETENTION_ANALYSIS("C02-0010", "c020010RetentionAnalysis", true, true, true),

    /**
     * 画面ID：製品別分析.
     */
    PAGE_ID_PRODUCT_ANALYSIS("C02-0020", "c020020ProductAnalysis", true, true, true),

    /**
     * 画面ID：不具合分析.
     */
    PAGE_ID_FAILURE_ANALYSIS("C02-0030", "c020030FailureAnalysis", true, true, true),

    /**
     * 画面ID：設備一覧.
     */
    PAGE_ID_EQUIPMENT_LIST("C02-0040", "c020040EquipmentList", true, true, true),

    /**
     * 画面ID：作業別工数.
     */
    PAGE_ID_MAN_HOUR_ANALYSIS("C02-0050", "c020050ManHourAnalysis", true, true, true),

    /**
     * 画面ID：サイネージ　グローバル画面情報取得.
     */
    PAGE_ID_SIGNAGE_FACILITY_LIST("C08-0010", "c080010SignageFacilityList", true, true, true),

    /**
     * 画面ID：サイネージ　製品グループ画面情報取得.
     */
    PAGE_ID_SIGNAGE_MODEL_GROUP_LIST("C08-0020", "c080020SignageModelGroupList", true, true, true),

    /**
     * 画面ID：サイネージ　製造進捗画面情報取得.
     */
    PAGE_ID_SIGNAGE_LINE_LIST("C08-0030", "c080030SignageLineList", true, true, true),

    /**
     * 画面ID：ライン稼動状況.
     */
    PAGE_ID_LINE_OPERATION_STATUS("C11-0010", "c110010LineOperationStatus", true, true, true, true),

    /**
     * 画面ID：ライン稼動一覧.
     */
    PAGE_ID_LINE_OPERATION_LIST("C11-0020", "c110020LineOperationList", true, true, true, true),

    /**
     * 画面ID：ステーション稼動状況.
     */
    PAGE_ID_STATION_OPERATION_STATUS("C11-0030", "c110030StationOperationStatus", true, true, true, true),

    /**
     * 画面ID：ステーション稼動一覧.
     */
    PAGE_ID_STATION_OPERATION_LIST("C11-0040", "c110040StationOperationList", true, true, true, true),

    /**
     * 画面ID：指図一覧.
     */
    PAGE_ID_INSTRACTION_LIST("C12-0010", "c120010InstructionList", true, true, true, true),

    /**
     * 画面ID：指図進捗.
     */
    PAGE_ID_INSTRACTION_PROGRESS("C12-0020", "c120020InstructionProgress", true, true, true, true),

    /**
     * 画面ID：ステーションログ.
     */
    PAGE_ID_STATION_LOG("C12-0030", "c120030StationLog", true, true, true, true),

    /**
     * 画面ID：不具合一覧.
     */
    PAGE_ID_SYSTEM_ERROR_LIST("C13-0010", "c130010FailureList", true, true, true, true),

    /**
     * 画面ID：不具合分析.
     */
    PAGE_ID_SYSTEM_ERROR_ANALYSIS("C13-0020", "c130020FailureAnalysis", true, true, true, true),

    /**
     * 画面ID：製品別生産数.
     */
    PAGE_ID_PRODUCTION_NUMBER_MONITOR("C14-0010", "c140010ProductionNumberMonitor", true, true, true, true),

    /**
     * 画面ID：生産進捗.
     */
    PAGE_ID_PRODUCTION_PROGRESS("C14-0020", "c140020ProductionProgress", true, true, true, true),

    /**
     * 画面ID：前詰負荷平準.
     */
    PAGE_ID_PRELOAD_LEVEL_DAILY_MONITOR("C14-0030", "c140030PreloadLevelDaily", true, true, true, true),

    /**
     * 画面ID：納期遵守率.
     */
    PAGE_ID_ERP_DUE_DATE_RATING_MONTHLY("C14-0040", "c140040ErpDueDateRatingMonthly", true, true, true, true),

    /**
     * 画面ID：納期遅れ額.
     */
    PAGE_ID_NOKI_OKU_LE("C14-0050", "c140050NokiOkuLeGaku", true, true, true, true),

    /**
     * 画面ID：欠品額.
     */
    PAGE_ID_STOCKOUT_AMOUNT("C14-0060", "c140060StockoutAmount", true, true, true, true),

    /**
     * 画面ID：材完率.
     */
    PAGE_ID_MATERIAL_SUPPLY_RATE("C14-0070", "c140070MaterialSupplyRate", true, true, true, true),

    /**
     * 画面ID：材完率詳細.
     */
    PAGE_ID_MATERIAL_SUPPLY_RATE_DETAIL("C14-0080", "c140080MaterialSupplyRateDetail", true, true, true, true),

    /**
     * 画面ID：欠品品目数.
     */
    PAGE_ID_STOCKOUT_NUMBER("C14-0090", "c140090StockoutNumber", true, true, true, true),

    /**
     * 画面ID：トレーサビリティ.
     */
    PAGE_ID_TRACEABILITY_LIST("C14-0100", "c140100TraceabilityList", true, true, true, true),


    /**
     * 画面ID：リードタイム.
     */
    PAGE_ID_LEADTIME_MONITOR("C15-0010", "c150010LeadTimeMonitor", true, true, true, true),

    /**
     * 画面ID：滞留分析.
     */
    PAGE_ID_RETENTION_ANALYSIS_MONITOR("C15-0020", "c150020RetentionAnalysisMonitor", true, true, true, true),

    /**
     * 画面ID：作業別工数.
     */
    PAGE_ID_MANHOUR_ANALYSIS_MONITOR("C15-0030", "c150030ManHourAnalysis", true, true, true, true),

    /**
     * 画面ID：製造工数解析モニタ.
     */
    PAGE_ID_MANUFACTURING_MANHOUR_ANALYSIS_MONITOR("C15-0040", "c150040ManufacturingManhoursAnalysis", true, true, true, true),

    /**
     * 画面ID：定期保全モニタ.
     */
    PAGE_ID_REGULAR_MAINTENANCE_MONITOR("C15-0050", "c150050RegularMaintenanceMonitor", true, true, true, true),

    /**
     * 画面ID：品質不良発生モニタ.
     */
    PAGE_ID_QUALITY_FAILURE_MONITOR("C15-0060", "c150060QualityFailureMonitor", true, true, true, true),

    /**
     * 画面ID：リードタイムヒストグラム.
     */
    PAGE_ID_LEADTIME_HISTOGRAM("C15-0070", "c150070LeadTimeHistogram", true, true, true, true),

    /**
     * 画面ID：レポート出力.
     */
    PAGE_ID_OUTPUT_REPORT("C15-0080", "c150080OutputReport", true, true, true, true),

    /**
     * 画面ID：メニュー構成.
     */
    PAGE_ID_MENU_CONSTITUTION("C18-0010", "c180010MenuConstitution", true, true, true, true),

    /**
     * 画面ID：拠点設定.
     */
    PAGE_ID_PRODUCTION_BASE_SETTING("C18-0030", "c180030ProductionBaseSetting", true, true, true, true),

    /**
     * 画面ID：製造ライン設定.
     */
    PAGE_ID_MANUFACTURING_LINE_SETTING("C18-0040", "c180040ManufacturingLineSetting", true, true, true, true),

    /**
     * 画面ID：計画数設定.
     */
    PAGE_ID_PLAN_NUMBER_SETTING("C18-0050", "c180050PlanNumberSetting", true, true, true, true),

    /**
     * 画面ID：ユーザ情報.
     */
    PAGE_ID_USER_INFO("C18-0060", "c180060UserInfo", true, true, true),

    /**
     * 画面ID：ラインレイアウト設定.
     */
    PAGE_ID_LINE_LAYOUT_SETTING("C18-0070", "c180070LineLayoutSetting", true, true, true, true);

    /**
     * 画面ID.
     */
    public String pageId;

    /**
     * 画面名.
     */
    public String pageName;

    /**
     * システム管理者（グループ:SYS0)での表示可能フラグ.
     */
    public boolean enableSysAdim;

    /**
     * システム管理者（グループ：SYS0以外)での表示可能フラグ.
     */
    public boolean enableSysGroupAdmin;

    /**
     * ユーザでの表示可能フラグ.
     */
    public boolean enableUser;

    /**
     * ホーム画面フラグ.
     */
    public boolean homePage;

    /**
     *
     * コンストラクタ.
     *
     * @param _pageId 画面ID
     * @param _pageName 画面名
     * @param _enableSysAdim システム管理者（グループ:SYS0)での表示可能フラグ
     * @param _enableSysGroupAdmin システム管理者（グループ:SYS0以外)での表示可能フラグ
     * @param _enableUser ユーザでの表示可能フラグ
     */
    private CM_A05_PageInfo(final String _pageId, final String _pageName, final boolean _enableSysAdim,
            final boolean _enableSysGroupAdmin, final boolean _enableUser) {
        this.pageId = _pageId;
        this.pageName = _pageName;
        this.enableSysAdim = _enableSysAdim;
        this.enableSysGroupAdmin = _enableSysGroupAdmin;
        this.enableUser = _enableUser;
        this.homePage = false;
    }

    /**
     *
     * コンストラクタ.
     *
     * @param _pageId 画面ID
     * @param _pageName 画面名
     * @param _enableSysAdim システム管理者（グループ:SYS0)での表示可能フラグ
     * @param _enableSysGroupAdmin システム管理者（グループ:SYS0以外)での表示可能フラグ
     * @param _enableUser ユーザでの表示可能フラグ
     * @param _homePage ホーム画面フラグ
     */
    private CM_A05_PageInfo(final String _pageId, final String _pageName, final boolean _enableSysAdim,
            final boolean _enableSysGroupAdmin, final boolean _enableUser, final boolean _homePage) {
        this.pageId = _pageId;
        this.pageName = _pageName;
        this.enableSysAdim = _enableSysAdim;
        this.enableSysGroupAdmin = _enableSysGroupAdmin;
        this.enableUser = _enableUser;
        this.homePage = _homePage;
    }

    /**
     * 画面ID取得.
     *
     * @return pageId 画面ID
     */
    public String getPageId() {
        return this.pageId;
    }

    /**
     *
     * 画面名取得.<br>
     *
     *<br>
     *@return 画面名
     */
    public String getPageName() {
        return this.pageName;
    }

    /**
     * システム管理者（グループ:SYS0)での表示可能かどうかを取得.
     *
     * @return enableSysAdim システム管理者（グループ:SYS0)での表示可能かどうか
     */
    public boolean isEnableSysAdim() {
        return this.enableSysAdim;
    }

    /**
     * システム管理者（グループ:SYS0以外)での表示可能かどうかを取得.
     *
     * @return enableSysGroupAdmin システム管理者（グループ:SYS0)での表示可能かどうか
     */
    public boolean isEnableSysGroupAdmin() {
        return this.enableSysGroupAdmin;
    }

    /**
     * ユーザでの表示可能かどうかを取得.
     *
     * @return enableUser ユーザでの表示可能かどうか
     */
    public boolean isEnableUser() {
        return this.enableUser;
    }

    /**
     * ホーム画面かどうかを取得.
     *
     * @return homePage ホーム画面かどうか
     */
    public boolean isHomePage() {
        return this.homePage;
    }

    /**
     *
     * 初期表示URL取得.<br>
     *<br>
     * 概要:<br>
     *   初期表示URL取得
     *<br>
     * @return 初期表示URL
     */
    public String getIndexPageUrl() {
        return FW00_19_Const.SLASH_STR + this.pageName + FW00_19_Const.SLASH_STR + "index";
    }

    /**
     *
     * 戻りページURL取得.<br>
     *<br>
     * 概要:<br>
     * 戻りページURLを取得
     *<br>
     * @return 戻りページURL
     */
    public String getReturnPageUrl() {
        return FW00_19_Const.SLASH_STR + this.pageName + FW00_19_Const.SLASH_STR + "returnPage";
    }

    /**
     * ファンクションコードを取得.<br>
     *<br>
     * 概要:<br>
     *  画面IDからファンクションコードを取得
     *<br>
     * @return ファンクションコード
     */
    public String getFunctionCd() {
        // 画面IDから機能CDを取得
        return pageId.substring(0, CM_MenuAuthInfoUtil.FUNC_CD_POS);
    }

    /**
     *
     * 画面IDをを元に画面情報取得.<br>
     *<br>
     * 概要:<br>
     *   画面IDをを元に画面情報取得処理
     *<br>
     * @param _pageId 画面ID
     * @return 画面情報
     */
    public static CM_A05_PageInfo getPageInfo(final String _pageId) {
        CM_A05_PageInfo ret = null;

        for (CM_A05_PageInfo pageInfo : CM_A05_PageInfo.values()) {
            if (pageInfo.getPageId().equals(_pageId)) {
                return pageInfo;
            }
        }

        return ret;
    }

    /**
     *
     * ユーザ権限がユーザの場合に表示できない画面一覧を取得.<br>
     *<br>
     * 概要:<br>
     *   ユーザ権限がユーザの場合に表示できない画面一覧を取得
     *<br>
     * @return ユーザ権限がユーザの場合に表示できない画面ID一覧
     */
    public static List<String> getDisableUserList() {
        List<String> ret = new ArrayList<String>();

        for (CM_A05_PageInfo pageInfo : CM_A05_PageInfo.values()) {
            if (!pageInfo.isEnableUser()) {
                ret.add(pageInfo.pageId);
            }
        }
        return ret;
    }

    /**
     *
     * ユーザ権限がユーザの場合に表示できない画面一覧を取得.<br>
     *<br>
     * 概要:<br>
     *   ユーザ権限がユーザの場合に表示できない画面一覧を取得
     *<br>
     * @return ユーザ権限がユーザの場合に表示できない画面ID一覧
     */
    public static List<String> getDisableSysGroupAdminList() {
        List<String> ret = new ArrayList<String>();

        for (CM_A05_PageInfo pageInfo : CM_A05_PageInfo.values()) {
            if (!pageInfo.isEnableSysGroupAdmin()) {
                ret.add(pageInfo.pageId);
            }
        }
        return ret;
    }

    /**
     *
     * ユーザ権限がユーザの場合に表示できない画面一覧を取得.<br>
     *<br>
     * 概要:<br>
     *   ユーザ権限がユーザの場合に表示できない画面一覧を取得
     *<br>
     * @return ユーザ権限がユーザの場合に表示できない画面ID一覧
     */
    public static List<String> getDisableSysAdminList() {
        List<String> ret = new ArrayList<String>();

        for (CM_A05_PageInfo pageInfo : CM_A05_PageInfo.values()) {
            if (!pageInfo.isEnableSysAdim()) {
                ret.add(pageInfo.pageId);
            }
        }
        return ret;
    }

    /**
     * ホーム画面を取得.<br>
     *<br>
     * 概要:<br>
     *  ホーム画面フラグがtrueが設定されているページ情報を取得
     *<br>
     * @return ホーム画面情報
     */
    public static CM_A05_PageInfo getHomePageInfo() {
        CM_A05_PageInfo ret = null;

        for (CM_A05_PageInfo pageInfo : CM_A05_PageInfo.values()) {
            if (pageInfo.isHomePage()) {
                return pageInfo;
            }
        }

        return ret;
    }
}
