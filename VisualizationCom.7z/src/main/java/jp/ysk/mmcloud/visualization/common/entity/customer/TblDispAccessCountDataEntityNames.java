package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link TblDispAccessCountDataEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class TblDispAccessCountDataEntityNames {

    /**
     * accessDatetimeのプロパティ名を返します。
     * 
     * @return accessDatetimeのプロパティ名
     */
    public static PropertyName<String> accessDatetime() {
        return new PropertyName<String>("accessDatetime");
    }

    /**
     * pageIdのプロパティ名を返します。
     * 
     * @return pageIdのプロパティ名
     */
    public static PropertyName<String> pageId() {
        return new PropertyName<String>("pageId");
    }

    /**
     * countNumのプロパティ名を返します。
     * 
     * @return countNumのプロパティ名
     */
    public static PropertyName<Integer> countNum() {
        return new PropertyName<Integer>("countNum");
    }

    /**
     * lastUpdProgのプロパティ名を返します。
     * 
     * @return lastUpdProgのプロパティ名
     */
    public static PropertyName<String> lastUpdProg() {
        return new PropertyName<String>("lastUpdProg");
    }

    /**
     * lastUpdTimのプロパティ名を返します。
     * 
     * @return lastUpdTimのプロパティ名
     */
    public static PropertyName<Timestamp> lastUpdTim() {
        return new PropertyName<Timestamp>("lastUpdTim");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _TblDispAccessCountDataNames extends PropertyName<TblDispAccessCountDataEntity> {

        /**
         * インスタンスを構築します。
         */
        public _TblDispAccessCountDataNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _TblDispAccessCountDataNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _TblDispAccessCountDataNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * accessDatetimeのプロパティ名を返します。
         *
         * @return accessDatetimeのプロパティ名
         */
        public PropertyName<String> accessDatetime() {
            return new PropertyName<String>(this, "accessDatetime");
        }

        /**
         * pageIdのプロパティ名を返します。
         *
         * @return pageIdのプロパティ名
         */
        public PropertyName<String> pageId() {
            return new PropertyName<String>(this, "pageId");
        }

        /**
         * countNumのプロパティ名を返します。
         *
         * @return countNumのプロパティ名
         */
        public PropertyName<Integer> countNum() {
            return new PropertyName<Integer>(this, "countNum");
        }

        /**
         * lastUpdProgのプロパティ名を返します。
         *
         * @return lastUpdProgのプロパティ名
         */
        public PropertyName<String> lastUpdProg() {
            return new PropertyName<String>(this, "lastUpdProg");
        }

        /**
         * lastUpdTimのプロパティ名を返します。
         *
         * @return lastUpdTimのプロパティ名
         */
        public PropertyName<Timestamp> lastUpdTim() {
            return new PropertyName<Timestamp>(this, "lastUpdTim");
        }
    }
}
