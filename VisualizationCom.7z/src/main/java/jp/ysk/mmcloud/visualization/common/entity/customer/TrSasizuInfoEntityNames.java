package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link TrSasizuInfoEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class TrSasizuInfoEntityNames {

    /**
     * createdOnのプロパティ名を返します。
     * 
     * @return createdOnのプロパティ名
     */
    public static PropertyName<Timestamp> createdOn() {
        return new PropertyName<Timestamp>("createdOn");
    }

    /**
     * createdByのプロパティ名を返します。
     * 
     * @return createdByのプロパティ名
     */
    public static PropertyName<String> createdBy() {
        return new PropertyName<String>("createdBy");
    }

    /**
     * modifiedOnのプロパティ名を返します。
     * 
     * @return modifiedOnのプロパティ名
     */
    public static PropertyName<Timestamp> modifiedOn() {
        return new PropertyName<Timestamp>("modifiedOn");
    }

    /**
     * modifiedByのプロパティ名を返します。
     * 
     * @return modifiedByのプロパティ名
     */
    public static PropertyName<String> modifiedBy() {
        return new PropertyName<String>("modifiedBy");
    }

    /**
     * syoriKbnのプロパティ名を返します。
     * 
     * @return syoriKbnのプロパティ名
     */
    public static PropertyName<String> syoriKbn() {
        return new PropertyName<String>("syoriKbn");
    }

    /**
     * invalidFlagのプロパティ名を返します。
     * 
     * @return invalidFlagのプロパティ名
     */
    public static PropertyName<Integer> invalidFlag() {
        return new PropertyName<Integer>("invalidFlag");
    }

    /**
     * sasizuNoのプロパティ名を返します。
     * 
     * @return sasizuNoのプロパティ名
     */
    public static PropertyName<String> sasizuNo() {
        return new PropertyName<String>("sasizuNo");
    }

    /**
     * sasizuTypeのプロパティ名を返します。
     * 
     * @return sasizuTypeのプロパティ名
     */
    public static PropertyName<String> sasizuType() {
        return new PropertyName<String>("sasizuType");
    }

    /**
     * werksのプロパティ名を返します。
     * 
     * @return werksのプロパティ名
     */
    public static PropertyName<String> werks() {
        return new PropertyName<String>("werks");
    }

    /**
     * orderNoのプロパティ名を返します。
     * 
     * @return orderNoのプロパティ名
     */
    public static PropertyName<String> orderNo() {
        return new PropertyName<String>("orderNo");
    }

    /**
     * koNoのプロパティ名を返します。
     * 
     * @return koNoのプロパティ名
     */
    public static PropertyName<String> koNo() {
        return new PropertyName<String>("koNo");
    }

    /**
     * tyumonnusiのプロパティ名を返します。
     * 
     * @return tyumonnusiのプロパティ名
     */
    public static PropertyName<String> tyumonnusi() {
        return new PropertyName<String>("tyumonnusi");
    }

    /**
     * buhinCdのプロパティ名を返します。
     * 
     * @return buhinCdのプロパティ名
     */
    public static PropertyName<String> buhinCd() {
        return new PropertyName<String>("buhinCd");
    }

    /**
     * katasikiのプロパティ名を返します。
     * 
     * @return katasikiのプロパティ名
     */
    public static PropertyName<String> katasiki() {
        return new PropertyName<String>("katasiki");
    }

    /**
     * sireiSuのプロパティ名を返します。
     * 
     * @return sireiSuのプロパティ名
     */
    public static PropertyName<BigDecimal> sireiSu() {
        return new PropertyName<BigDecimal>("sireiSu");
    }

    /**
     * PSasizuNoのプロパティ名を返します。
     * 
     * @return PSasizuNoのプロパティ名
     */
    public static PropertyName<String> PSasizuNo() {
        return new PropertyName<String>("PSasizuNo");
    }

    /**
     * wbsのプロパティ名を返します。
     * 
     * @return wbsのプロパティ名
     */
    public static PropertyName<String> wbs() {
        return new PropertyName<String>("wbs");
    }

    /**
     * wbsProjectTypeのプロパティ名を返します。
     * 
     * @return wbsProjectTypeのプロパティ名
     */
    public static PropertyName<String> wbsProjectType() {
        return new PropertyName<String>("wbsProjectType");
    }

    /**
     * hyojyunGenkaのプロパティ名を返します。
     * 
     * @return hyojyunGenkaのプロパティ名
     */
    public static PropertyName<BigDecimal> hyojyunGenka() {
        return new PropertyName<BigDecimal>("hyojyunGenka");
    }

    /**
     * sagyoStaBiのプロパティ名を返します。
     * 
     * @return sagyoStaBiのプロパティ名
     */
    public static PropertyName<String> sagyoStaBi() {
        return new PropertyName<String>("sagyoStaBi");
    }

    /**
     * kanYoteiBiのプロパティ名を返します。
     * 
     * @return kanYoteiBiのプロパティ名
     */
    public static PropertyName<String> kanYoteiBi() {
        return new PropertyName<String>("kanYoteiBi");
    }

    /**
     * yokyuNokiのプロパティ名を返します。
     * 
     * @return yokyuNokiのプロパティ名
     */
    public static PropertyName<String> yokyuNoki() {
        return new PropertyName<String>("yokyuNoki");
    }

    /**
     * sagyokuのプロパティ名を返します。
     * 
     * @return sagyokuのプロパティ名
     */
    public static PropertyName<String> sagyoku() {
        return new PropertyName<String>("sagyoku");
    }

    /**
     * hasseiDateのプロパティ名を返します。
     * 
     * @return hasseiDateのプロパティ名
     */
    public static PropertyName<Timestamp> hasseiDate() {
        return new PropertyName<Timestamp>("hasseiDate");
    }

    /**
     * henkoDateのプロパティ名を返します。
     * 
     * @return henkoDateのプロパティ名
     */
    public static PropertyName<Timestamp> henkoDate() {
        return new PropertyName<Timestamp>("henkoDate");
    }

    /**
     * torikesiDateのプロパティ名を返します。
     * 
     * @return torikesiDateのプロパティ名
     */
    public static PropertyName<Timestamp> torikesiDate() {
        return new PropertyName<Timestamp>("torikesiDate");
    }

    /**
     * sireiSuOrgのプロパティ名を返します。
     * 
     * @return sireiSuOrgのプロパティ名
     */
    public static PropertyName<BigDecimal> sireiSuOrg() {
        return new PropertyName<BigDecimal>("sireiSuOrg");
    }

    /**
     * sasizuHenkoDateのプロパティ名を返します。
     * 
     * @return sasizuHenkoDateのプロパティ名
     */
    public static PropertyName<Timestamp> sasizuHenkoDate() {
        return new PropertyName<Timestamp>("sasizuHenkoDate");
    }

    /**
     * startSubNoのプロパティ名を返します。
     * 
     * @return startSubNoのプロパティ名
     */
    public static PropertyName<BigDecimal> startSubNo() {
        return new PropertyName<BigDecimal>("startSubNo");
    }

    /**
     * PVersionのプロパティ名を返します。
     * 
     * @return PVersionのプロパティ名
     */
    public static PropertyName<String> PVersion() {
        return new PropertyName<String>("PVersion");
    }

    /**
     * orderDateのプロパティ名を返します。
     * 
     * @return orderDateのプロパティ名
     */
    public static PropertyName<String> orderDate() {
        return new PropertyName<String>("orderDate");
    }

    /**
     * deliveryDateのプロパティ名を返します。
     * 
     * @return deliveryDateのプロパティ名
     */
    public static PropertyName<String> deliveryDate() {
        return new PropertyName<String>("deliveryDate");
    }

    /**
     * purchaseDateのプロパティ名を返します。
     * 
     * @return purchaseDateのプロパティ名
     */
    public static PropertyName<String> purchaseDate() {
        return new PropertyName<String>("purchaseDate");
    }

    /**
     * LDeliveryDateのプロパティ名を返します。
     * 
     * @return LDeliveryDateのプロパティ名
     */
    public static PropertyName<String> LDeliveryDate() {
        return new PropertyName<String>("LDeliveryDate");
    }

    /**
     * factoryDateのプロパティ名を返します。
     * 
     * @return factoryDateのプロパティ名
     */
    public static PropertyName<String> factoryDate() {
        return new PropertyName<String>("factoryDate");
    }

    /**
     * snKihonのプロパティ名を返します。
     * 
     * @return snKihonのプロパティ名
     */
    public static PropertyName<String> snKihon() {
        return new PropertyName<String>("snKihon");
    }

    /**
     * lotKihonのプロパティ名を返します。
     * 
     * @return lotKihonのプロパティ名
     */
    public static PropertyName<String> lotKihon() {
        return new PropertyName<String>("lotKihon");
    }

    /**
     * groupCntのプロパティ名を返します。
     * 
     * @return groupCntのプロパティ名
     */
    public static PropertyName<BigDecimal> groupCnt() {
        return new PropertyName<BigDecimal>("groupCnt");
    }

    /**
     * erpHenkoDateのプロパティ名を返します。
     * 
     * @return erpHenkoDateのプロパティ名
     */
    public static PropertyName<Timestamp> erpHenkoDate() {
        return new PropertyName<Timestamp>("erpHenkoDate");
    }

    /**
     * erpSakujyoFlgのプロパティ名を返します。
     * 
     * @return erpSakujyoFlgのプロパティ名
     */
    public static PropertyName<String> erpSakujyoFlg() {
        return new PropertyName<String>("erpSakujyoFlg");
    }

    /**
     * spareNum1のプロパティ名を返します。
     * 
     * @return spareNum1のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum1() {
        return new PropertyName<BigDecimal>("spareNum1");
    }

    /**
     * spareNum2のプロパティ名を返します。
     * 
     * @return spareNum2のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum2() {
        return new PropertyName<BigDecimal>("spareNum2");
    }

    /**
     * spareNum3のプロパティ名を返します。
     * 
     * @return spareNum3のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum3() {
        return new PropertyName<BigDecimal>("spareNum3");
    }

    /**
     * spareText1のプロパティ名を返します。
     * 
     * @return spareText1のプロパティ名
     */
    public static PropertyName<String> spareText1() {
        return new PropertyName<String>("spareText1");
    }

    /**
     * spareText2のプロパティ名を返します。
     * 
     * @return spareText2のプロパティ名
     */
    public static PropertyName<String> spareText2() {
        return new PropertyName<String>("spareText2");
    }

    /**
     * spareText3のプロパティ名を返します。
     * 
     * @return spareText3のプロパティ名
     */
    public static PropertyName<String> spareText3() {
        return new PropertyName<String>("spareText3");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _TrSasizuInfoNames extends PropertyName<TrSasizuInfoEntity> {

        /**
         * インスタンスを構築します。
         */
        public _TrSasizuInfoNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _TrSasizuInfoNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _TrSasizuInfoNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * createdOnのプロパティ名を返します。
         *
         * @return createdOnのプロパティ名
         */
        public PropertyName<Timestamp> createdOn() {
            return new PropertyName<Timestamp>(this, "createdOn");
        }

        /**
         * createdByのプロパティ名を返します。
         *
         * @return createdByのプロパティ名
         */
        public PropertyName<String> createdBy() {
            return new PropertyName<String>(this, "createdBy");
        }

        /**
         * modifiedOnのプロパティ名を返します。
         *
         * @return modifiedOnのプロパティ名
         */
        public PropertyName<Timestamp> modifiedOn() {
            return new PropertyName<Timestamp>(this, "modifiedOn");
        }

        /**
         * modifiedByのプロパティ名を返します。
         *
         * @return modifiedByのプロパティ名
         */
        public PropertyName<String> modifiedBy() {
            return new PropertyName<String>(this, "modifiedBy");
        }

        /**
         * syoriKbnのプロパティ名を返します。
         *
         * @return syoriKbnのプロパティ名
         */
        public PropertyName<String> syoriKbn() {
            return new PropertyName<String>(this, "syoriKbn");
        }

        /**
         * invalidFlagのプロパティ名を返します。
         *
         * @return invalidFlagのプロパティ名
         */
        public PropertyName<Integer> invalidFlag() {
            return new PropertyName<Integer>(this, "invalidFlag");
        }

        /**
         * sasizuNoのプロパティ名を返します。
         *
         * @return sasizuNoのプロパティ名
         */
        public PropertyName<String> sasizuNo() {
            return new PropertyName<String>(this, "sasizuNo");
        }

        /**
         * sasizuTypeのプロパティ名を返します。
         *
         * @return sasizuTypeのプロパティ名
         */
        public PropertyName<String> sasizuType() {
            return new PropertyName<String>(this, "sasizuType");
        }

        /**
         * werksのプロパティ名を返します。
         *
         * @return werksのプロパティ名
         */
        public PropertyName<String> werks() {
            return new PropertyName<String>(this, "werks");
        }

        /**
         * orderNoのプロパティ名を返します。
         *
         * @return orderNoのプロパティ名
         */
        public PropertyName<String> orderNo() {
            return new PropertyName<String>(this, "orderNo");
        }

        /**
         * koNoのプロパティ名を返します。
         *
         * @return koNoのプロパティ名
         */
        public PropertyName<String> koNo() {
            return new PropertyName<String>(this, "koNo");
        }

        /**
         * tyumonnusiのプロパティ名を返します。
         *
         * @return tyumonnusiのプロパティ名
         */
        public PropertyName<String> tyumonnusi() {
            return new PropertyName<String>(this, "tyumonnusi");
        }

        /**
         * buhinCdのプロパティ名を返します。
         *
         * @return buhinCdのプロパティ名
         */
        public PropertyName<String> buhinCd() {
            return new PropertyName<String>(this, "buhinCd");
        }

        /**
         * katasikiのプロパティ名を返します。
         *
         * @return katasikiのプロパティ名
         */
        public PropertyName<String> katasiki() {
            return new PropertyName<String>(this, "katasiki");
        }

        /**
         * sireiSuのプロパティ名を返します。
         *
         * @return sireiSuのプロパティ名
         */
        public PropertyName<BigDecimal> sireiSu() {
            return new PropertyName<BigDecimal>(this, "sireiSu");
        }

        /**
         * PSasizuNoのプロパティ名を返します。
         *
         * @return PSasizuNoのプロパティ名
         */
        public PropertyName<String> PSasizuNo() {
            return new PropertyName<String>(this, "PSasizuNo");
        }

        /**
         * wbsのプロパティ名を返します。
         *
         * @return wbsのプロパティ名
         */
        public PropertyName<String> wbs() {
            return new PropertyName<String>(this, "wbs");
        }

        /**
         * wbsProjectTypeのプロパティ名を返します。
         *
         * @return wbsProjectTypeのプロパティ名
         */
        public PropertyName<String> wbsProjectType() {
            return new PropertyName<String>(this, "wbsProjectType");
        }

        /**
         * hyojyunGenkaのプロパティ名を返します。
         *
         * @return hyojyunGenkaのプロパティ名
         */
        public PropertyName<BigDecimal> hyojyunGenka() {
            return new PropertyName<BigDecimal>(this, "hyojyunGenka");
        }

        /**
         * sagyoStaBiのプロパティ名を返します。
         *
         * @return sagyoStaBiのプロパティ名
         */
        public PropertyName<String> sagyoStaBi() {
            return new PropertyName<String>(this, "sagyoStaBi");
        }

        /**
         * kanYoteiBiのプロパティ名を返します。
         *
         * @return kanYoteiBiのプロパティ名
         */
        public PropertyName<String> kanYoteiBi() {
            return new PropertyName<String>(this, "kanYoteiBi");
        }

        /**
         * yokyuNokiのプロパティ名を返します。
         *
         * @return yokyuNokiのプロパティ名
         */
        public PropertyName<String> yokyuNoki() {
            return new PropertyName<String>(this, "yokyuNoki");
        }

        /**
         * sagyokuのプロパティ名を返します。
         *
         * @return sagyokuのプロパティ名
         */
        public PropertyName<String> sagyoku() {
            return new PropertyName<String>(this, "sagyoku");
        }

        /**
         * hasseiDateのプロパティ名を返します。
         *
         * @return hasseiDateのプロパティ名
         */
        public PropertyName<Timestamp> hasseiDate() {
            return new PropertyName<Timestamp>(this, "hasseiDate");
        }

        /**
         * henkoDateのプロパティ名を返します。
         *
         * @return henkoDateのプロパティ名
         */
        public PropertyName<Timestamp> henkoDate() {
            return new PropertyName<Timestamp>(this, "henkoDate");
        }

        /**
         * torikesiDateのプロパティ名を返します。
         *
         * @return torikesiDateのプロパティ名
         */
        public PropertyName<Timestamp> torikesiDate() {
            return new PropertyName<Timestamp>(this, "torikesiDate");
        }

        /**
         * sireiSuOrgのプロパティ名を返します。
         *
         * @return sireiSuOrgのプロパティ名
         */
        public PropertyName<BigDecimal> sireiSuOrg() {
            return new PropertyName<BigDecimal>(this, "sireiSuOrg");
        }

        /**
         * sasizuHenkoDateのプロパティ名を返します。
         *
         * @return sasizuHenkoDateのプロパティ名
         */
        public PropertyName<Timestamp> sasizuHenkoDate() {
            return new PropertyName<Timestamp>(this, "sasizuHenkoDate");
        }

        /**
         * startSubNoのプロパティ名を返します。
         *
         * @return startSubNoのプロパティ名
         */
        public PropertyName<BigDecimal> startSubNo() {
            return new PropertyName<BigDecimal>(this, "startSubNo");
        }

        /**
         * PVersionのプロパティ名を返します。
         *
         * @return PVersionのプロパティ名
         */
        public PropertyName<String> PVersion() {
            return new PropertyName<String>(this, "PVersion");
        }

        /**
         * orderDateのプロパティ名を返します。
         *
         * @return orderDateのプロパティ名
         */
        public PropertyName<String> orderDate() {
            return new PropertyName<String>(this, "orderDate");
        }

        /**
         * deliveryDateのプロパティ名を返します。
         *
         * @return deliveryDateのプロパティ名
         */
        public PropertyName<String> deliveryDate() {
            return new PropertyName<String>(this, "deliveryDate");
        }

        /**
         * purchaseDateのプロパティ名を返します。
         *
         * @return purchaseDateのプロパティ名
         */
        public PropertyName<String> purchaseDate() {
            return new PropertyName<String>(this, "purchaseDate");
        }

        /**
         * LDeliveryDateのプロパティ名を返します。
         *
         * @return LDeliveryDateのプロパティ名
         */
        public PropertyName<String> LDeliveryDate() {
            return new PropertyName<String>(this, "LDeliveryDate");
        }

        /**
         * factoryDateのプロパティ名を返します。
         *
         * @return factoryDateのプロパティ名
         */
        public PropertyName<String> factoryDate() {
            return new PropertyName<String>(this, "factoryDate");
        }

        /**
         * snKihonのプロパティ名を返します。
         *
         * @return snKihonのプロパティ名
         */
        public PropertyName<String> snKihon() {
            return new PropertyName<String>(this, "snKihon");
        }

        /**
         * lotKihonのプロパティ名を返します。
         *
         * @return lotKihonのプロパティ名
         */
        public PropertyName<String> lotKihon() {
            return new PropertyName<String>(this, "lotKihon");
        }

        /**
         * groupCntのプロパティ名を返します。
         *
         * @return groupCntのプロパティ名
         */
        public PropertyName<BigDecimal> groupCnt() {
            return new PropertyName<BigDecimal>(this, "groupCnt");
        }

        /**
         * erpHenkoDateのプロパティ名を返します。
         *
         * @return erpHenkoDateのプロパティ名
         */
        public PropertyName<Timestamp> erpHenkoDate() {
            return new PropertyName<Timestamp>(this, "erpHenkoDate");
        }

        /**
         * erpSakujyoFlgのプロパティ名を返します。
         *
         * @return erpSakujyoFlgのプロパティ名
         */
        public PropertyName<String> erpSakujyoFlg() {
            return new PropertyName<String>(this, "erpSakujyoFlg");
        }

        /**
         * spareNum1のプロパティ名を返します。
         *
         * @return spareNum1のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum1() {
            return new PropertyName<BigDecimal>(this, "spareNum1");
        }

        /**
         * spareNum2のプロパティ名を返します。
         *
         * @return spareNum2のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum2() {
            return new PropertyName<BigDecimal>(this, "spareNum2");
        }

        /**
         * spareNum3のプロパティ名を返します。
         *
         * @return spareNum3のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum3() {
            return new PropertyName<BigDecimal>(this, "spareNum3");
        }

        /**
         * spareText1のプロパティ名を返します。
         *
         * @return spareText1のプロパティ名
         */
        public PropertyName<String> spareText1() {
            return new PropertyName<String>(this, "spareText1");
        }

        /**
         * spareText2のプロパティ名を返します。
         *
         * @return spareText2のプロパティ名
         */
        public PropertyName<String> spareText2() {
            return new PropertyName<String>(this, "spareText2");
        }

        /**
         * spareText3のプロパティ名を返します。
         *
         * @return spareText3のプロパティ名
         */
        public PropertyName<String> spareText3() {
            return new PropertyName<String>(this, "spareText3");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
