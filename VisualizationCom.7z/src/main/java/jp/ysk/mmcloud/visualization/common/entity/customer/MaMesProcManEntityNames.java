package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link MaMesProcManEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class MaMesProcManEntityNames {

    /**
     * createdOnのプロパティ名を返します。
     * 
     * @return createdOnのプロパティ名
     */
    public static PropertyName<Timestamp> createdOn() {
        return new PropertyName<Timestamp>("createdOn");
    }

    /**
     * createdByのプロパティ名を返します。
     * 
     * @return createdByのプロパティ名
     */
    public static PropertyName<String> createdBy() {
        return new PropertyName<String>("createdBy");
    }

    /**
     * modifiedOnのプロパティ名を返します。
     * 
     * @return modifiedOnのプロパティ名
     */
    public static PropertyName<Timestamp> modifiedOn() {
        return new PropertyName<Timestamp>("modifiedOn");
    }

    /**
     * modifiedByのプロパティ名を返します。
     * 
     * @return modifiedByのプロパティ名
     */
    public static PropertyName<String> modifiedBy() {
        return new PropertyName<String>("modifiedBy");
    }

    /**
     * invalidFlagのプロパティ名を返します。
     * 
     * @return invalidFlagのプロパティ名
     */
    public static PropertyName<Integer> invalidFlag() {
        return new PropertyName<Integer>("invalidFlag");
    }

    /**
     * procManIdのプロパティ名を返します。
     * 
     * @return procManIdのプロパティ名
     */
    public static PropertyName<BigDecimal> procManId() {
        return new PropertyName<BigDecimal>("procManId");
    }

    /**
     * createDateのプロパティ名を返します。
     * 
     * @return createDateのプロパティ名
     */
    public static PropertyName<Timestamp> createDate() {
        return new PropertyName<Timestamp>("createDate");
    }

    /**
     * buhinCdのプロパティ名を返します。
     * 
     * @return buhinCdのプロパティ名
     */
    public static PropertyName<String> buhinCd() {
        return new PropertyName<String>("buhinCd");
    }

    /**
     * plantCdのプロパティ名を返します。
     * 
     * @return plantCdのプロパティ名
     */
    public static PropertyName<String> plantCd() {
        return new PropertyName<String>("plantCd");
    }

    /**
     * groupCntのプロパティ名を返します。
     * 
     * @return groupCntのプロパティ名
     */
    public static PropertyName<BigDecimal> groupCnt() {
        return new PropertyName<BigDecimal>("groupCnt");
    }

    /**
     * katasikiのプロパティ名を返します。
     * 
     * @return katasikiのプロパティ名
     */
    public static PropertyName<String> katasiki() {
        return new PropertyName<String>("katasiki");
    }

    /**
     * procManCatのプロパティ名を返します。
     * 
     * @return procManCatのプロパティ名
     */
    public static PropertyName<String> procManCat() {
        return new PropertyName<String>("procManCat");
    }

    /**
     * manGroupのプロパティ名を返します。
     * 
     * @return manGroupのプロパティ名
     */
    public static PropertyName<String> manGroup() {
        return new PropertyName<String>("manGroup");
    }

    /**
     * procManNameのプロパティ名を返します。
     * 
     * @return procManNameのプロパティ名
     */
    public static PropertyName<String> procManName() {
        return new PropertyName<String>("procManName");
    }

    /**
     * approvalKbnのプロパティ名を返します。
     * 
     * @return approvalKbnのプロパティ名
     */
    public static PropertyName<BigDecimal> approvalKbn() {
        return new PropertyName<BigDecimal>("approvalKbn");
    }

    /**
     * spareNum1のプロパティ名を返します。
     * 
     * @return spareNum1のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum1() {
        return new PropertyName<BigDecimal>("spareNum1");
    }

    /**
     * spareNum2のプロパティ名を返します。
     * 
     * @return spareNum2のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum2() {
        return new PropertyName<BigDecimal>("spareNum2");
    }

    /**
     * spareNum3のプロパティ名を返します。
     * 
     * @return spareNum3のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum3() {
        return new PropertyName<BigDecimal>("spareNum3");
    }

    /**
     * spareText1のプロパティ名を返します。
     * 
     * @return spareText1のプロパティ名
     */
    public static PropertyName<String> spareText1() {
        return new PropertyName<String>("spareText1");
    }

    /**
     * spareText2のプロパティ名を返します。
     * 
     * @return spareText2のプロパティ名
     */
    public static PropertyName<String> spareText2() {
        return new PropertyName<String>("spareText2");
    }

    /**
     * spareText3のプロパティ名を返します。
     * 
     * @return spareText3のプロパティ名
     */
    public static PropertyName<String> spareText3() {
        return new PropertyName<String>("spareText3");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _MaMesProcManNames extends PropertyName<MaMesProcManEntity> {

        /**
         * インスタンスを構築します。
         */
        public _MaMesProcManNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _MaMesProcManNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _MaMesProcManNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * createdOnのプロパティ名を返します。
         *
         * @return createdOnのプロパティ名
         */
        public PropertyName<Timestamp> createdOn() {
            return new PropertyName<Timestamp>(this, "createdOn");
        }

        /**
         * createdByのプロパティ名を返します。
         *
         * @return createdByのプロパティ名
         */
        public PropertyName<String> createdBy() {
            return new PropertyName<String>(this, "createdBy");
        }

        /**
         * modifiedOnのプロパティ名を返します。
         *
         * @return modifiedOnのプロパティ名
         */
        public PropertyName<Timestamp> modifiedOn() {
            return new PropertyName<Timestamp>(this, "modifiedOn");
        }

        /**
         * modifiedByのプロパティ名を返します。
         *
         * @return modifiedByのプロパティ名
         */
        public PropertyName<String> modifiedBy() {
            return new PropertyName<String>(this, "modifiedBy");
        }

        /**
         * invalidFlagのプロパティ名を返します。
         *
         * @return invalidFlagのプロパティ名
         */
        public PropertyName<Integer> invalidFlag() {
            return new PropertyName<Integer>(this, "invalidFlag");
        }

        /**
         * procManIdのプロパティ名を返します。
         *
         * @return procManIdのプロパティ名
         */
        public PropertyName<BigDecimal> procManId() {
            return new PropertyName<BigDecimal>(this, "procManId");
        }

        /**
         * createDateのプロパティ名を返します。
         *
         * @return createDateのプロパティ名
         */
        public PropertyName<Timestamp> createDate() {
            return new PropertyName<Timestamp>(this, "createDate");
        }

        /**
         * buhinCdのプロパティ名を返します。
         *
         * @return buhinCdのプロパティ名
         */
        public PropertyName<String> buhinCd() {
            return new PropertyName<String>(this, "buhinCd");
        }

        /**
         * plantCdのプロパティ名を返します。
         *
         * @return plantCdのプロパティ名
         */
        public PropertyName<String> plantCd() {
            return new PropertyName<String>(this, "plantCd");
        }

        /**
         * groupCntのプロパティ名を返します。
         *
         * @return groupCntのプロパティ名
         */
        public PropertyName<BigDecimal> groupCnt() {
            return new PropertyName<BigDecimal>(this, "groupCnt");
        }

        /**
         * katasikiのプロパティ名を返します。
         *
         * @return katasikiのプロパティ名
         */
        public PropertyName<String> katasiki() {
            return new PropertyName<String>(this, "katasiki");
        }

        /**
         * procManCatのプロパティ名を返します。
         *
         * @return procManCatのプロパティ名
         */
        public PropertyName<String> procManCat() {
            return new PropertyName<String>(this, "procManCat");
        }

        /**
         * manGroupのプロパティ名を返します。
         *
         * @return manGroupのプロパティ名
         */
        public PropertyName<String> manGroup() {
            return new PropertyName<String>(this, "manGroup");
        }

        /**
         * procManNameのプロパティ名を返します。
         *
         * @return procManNameのプロパティ名
         */
        public PropertyName<String> procManName() {
            return new PropertyName<String>(this, "procManName");
        }

        /**
         * approvalKbnのプロパティ名を返します。
         *
         * @return approvalKbnのプロパティ名
         */
        public PropertyName<BigDecimal> approvalKbn() {
            return new PropertyName<BigDecimal>(this, "approvalKbn");
        }

        /**
         * spareNum1のプロパティ名を返します。
         *
         * @return spareNum1のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum1() {
            return new PropertyName<BigDecimal>(this, "spareNum1");
        }

        /**
         * spareNum2のプロパティ名を返します。
         *
         * @return spareNum2のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum2() {
            return new PropertyName<BigDecimal>(this, "spareNum2");
        }

        /**
         * spareNum3のプロパティ名を返します。
         *
         * @return spareNum3のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum3() {
            return new PropertyName<BigDecimal>(this, "spareNum3");
        }

        /**
         * spareText1のプロパティ名を返します。
         *
         * @return spareText1のプロパティ名
         */
        public PropertyName<String> spareText1() {
            return new PropertyName<String>(this, "spareText1");
        }

        /**
         * spareText2のプロパティ名を返します。
         *
         * @return spareText2のプロパティ名
         */
        public PropertyName<String> spareText2() {
            return new PropertyName<String>(this, "spareText2");
        }

        /**
         * spareText3のプロパティ名を返します。
         *
         * @return spareText3のプロパティ名
         */
        public PropertyName<String> spareText3() {
            return new PropertyName<String>(this, "spareText3");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
