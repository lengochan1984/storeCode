/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/07/28| <C1.01>　新規作成                                                    | C1.01  | (US)入江
 *  2017/05/16| <C1.02>　otherColorリストを画面毎に保持するように変更  | C1.02  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.util;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.entity.customer.SysEnvEntityNames;
import jp.ysk.mmcloud.common.util.CM_SysEnvDataUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;

import org.seasar.framework.beans.util.BeanMap;

/**
 * グラフ描画時の色設定ユーティリティ.
 *
 */
public final class CM_GraphUtil {

    /**
     * Colorリスト.
     */
    private static Map<Integer, String> colorList = new LinkedHashMap<Integer, String>();

    /**
     * otherColorリスト.
     */
    private static Map<String, Map<Integer, String>> otherColorList = new LinkedHashMap<String, Map<Integer, String>>();

    /**
     * 初期処理判断.
     */
    private static boolean isInit = true;

    /**
     * コンストラクタ.
     */
    private CM_GraphUtil() {

    }

    /**
     * カラー文字列取得.<br>
     * 概要:<br>
     * カラーリスト内の取得連番で指定されたカラー文字列を返す.<br>
     * 取得連番がリストない件数を上回る場合、リスト内でLoopさせた位置のカラー文字列を返す.<br>
     * 備考:<br>
     * 取得連番は1からの連番とすること.<br>
     *
     * @param _count 取得連番(1 ～)
     * @return カラーコードString(#ffffff etc)
     */
    public static String getElementColor(final Integer _count) {

        if (isInit) {
            return "#000000";
        }

        int cIdx  = _count;
        int max = colorList.size();

        if (cIdx > max) {

            if (cIdx % max == 0) {
                cIdx = 1;
            } else {
                int lc = (int) (cIdx / max);
                cIdx -= lc * max;
            }
        }

        return colorList.get(cIdx);
    }

    /**
     * Colorリスト編集.
     * @param _session セッションDTO
     */
    public static void initColorList(final CM_A03_SessionDto _session) {

        if (!isInit) {
            return;
        }

        List<BeanMap> map = CM_SysEnvDataUtil.selectListSysEnv(_session, CM_A04_Const.SYS_ENV_MST_ENV_CD.GRAPH_ELEMENT_COLOR);

        int i = 1;
        for (BeanMap m : map) {

            colorList.put(i++, m.get(SysEnvEntityNames.name().toString()).toString());
        }

        isInit = false;

    }


    /**
     * カラー文字列取得.<br>
     * 概要:<br>
     * カラーリスト内の取得連番で指定されたカラー文字列を返す.<br>
     * 取得連番がリストない件数を上回る場合、リスト内でLoopさせた位置のカラー文字列を返す.<br>
     * 備考:<br>
     * 取得連番は1からの連番とすること.<br>
     *
     * @param _count 取得連番(1 ～)
     * @param _colorCode グラフ色コード
     * @return カラーコードString(#ffffff etc)
     */
    public static String getElementOtherColor(final Integer _count, final String _colorCode) {
        if (null == otherColorList.get(_colorCode)) {
            return "#000000";
        }
        int max = otherColorList.get(_colorCode).size();
        if (max == 0) {
            return "#000000";
        }
        int cIdx  = _count;
        if (cIdx > max) {
            if (cIdx % max == 0) {
                cIdx = 1;
            } else {
                int lc = (int) (cIdx / max);
                cIdx -= lc * max;
            }
        }
        return otherColorList.get(_colorCode).get(cIdx);
    }

    /**
     * Colorリスト編集.
     * @param _session セッションDTO
     * @param _colorCode グラフ色コード
     */
    public static void initOtherColorList(final CM_A03_SessionDto _session, final String _colorCode) {

        List<BeanMap> map = CM_SysEnvDataUtil.selectListSysEnv(_session, _colorCode);
        // 初期化する
        if (null == otherColorList.get(_colorCode)) {
            otherColorList.put(_colorCode, new LinkedHashMap<Integer, String>());
        }
        int i = 1;
        for (BeanMap m : map) {
            otherColorList.get(_colorCode).put(i++, m.get(SysEnvEntityNames.name().toString()).toString());
        }
    }

}
