/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+=======================================+========+==============
 *  DATE      | Comments                              | Rev    | SIGN
 * ===========+=======================================+========+==============
 *  2014/12/17| 新規作成                              | 3.00.00| YSK)中田
 *  2015/12/17| <40000-025> Ver.4.00.00 変更仕様No.25 | 4.00.00| US)甲斐
 * -----------+---------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.dao;

import java.util.List;
import java.util.Map;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.form.FW01_14_ListForm;
import jp.ysk.fw.util.FW00_22_DataListOffSetUtil;
import jp.ysk.mmcloud.common.entity.customer.MstDocumentEntity;
import jp.ysk.mmcloud.common.entity.customer.MstDocumentEntityNames;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.util.CM_CommonUtil;

import org.seasar.extension.jdbc.operation.Operations;
import org.seasar.extension.jdbc.where.SimpleWhere;
import org.seasar.framework.beans.util.BeanMap;


/**
 * 資料一覧用Daoクラス.<br>
 *<br>
 * 概要:<br>
 *<br>
 */
public class CM_MstDocumentDao extends CM_BaseDao {

    //*********************************
    // 検索条件
    //*********************************
    /**
     * 型番名称-SIDプルダウンリスト.
     */
    public static final String SEARCH_TXT_MODEL_SID = "txtModelId";

    /**
     * 機器名称-SIDプルダウンリスト.
     */
    public static final String SEARCH_TXT_DEVICE_SID = "txtDeviceId";

    /**
     * 種別名称プルダウンリスト.
     */
    public static final String SEARCH_TXT_FILE_KIND = "txtFileKind";

    /**
     * 資料名称テキスト.
     */
    public static final String SEARCH_TXT_DOC_NAME = "txtDocName";

    //*********************************
    // マップキー用定義
    //*********************************
    /**
     * 型番名称.
     */
    public static final String MODELNAME = "modelName";

    /**
     * 機器名称.
     */
    public static final String DEVICENAME = "deviceName";

    /**
     * ファイル種別.
     */
    public static final String FILEKINDNAME = "fileKindName";

    /**
     * 管理者フラグ.
     */
    public static final String IS_ADMIN = "isAdmin";

    /**
     * コンストラクタ.
     */
    public CM_MstDocumentDao() {
        super();
    }

    /**
     * コンストラクタ.
     *
     * @param _strConnectString 顧客DB接続情報
     * @param _strConnectUserId 顧客DBユーザID
     * @param _strConnectPasswd 顧客DBパスワード
     */
    public CM_MstDocumentDao(final String _strConnectString, final String _strConnectUserId,
            final String _strConnectPasswd) {
        super(_strConnectString, _strConnectUserId, _strConnectPasswd);
    }

    /**
     *
     * 一覧データ数取得.<br>
     * <br>
     * 概要:<br>
     * 一覧のデータ数を取得する <br>
     *
     * @param _formInfo
     *            フォーム情報
     * @param _mapSearchCondInfo
     *            検索条件情報Map
     * @param _loginUserSid
     *            ユーザSID
     * @param _txtDocType
     *            文書区分
     * @param _deleteFlg
     *            削除フラグ (nullの場合指定なし)
     * @param _isAdmin
     *            管理者フラグ
     * @return データ数
     */
    public long selectDocumentListCount(final BeanMap _formInfo,
            final Map<String, Object> _mapSearchCondInfo, final int _loginUserSid,
            final String _txtDocType,
            final Boolean _deleteFlg, final boolean _isAdmin) {
        long ret = 0;

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_formInfo", _formInfo);
        CM_LoggerUtil.outputDaoInputParamLog("_mapSearchCondInfo", _mapSearchCondInfo);
        CM_LoggerUtil.outputDaoInputParamLog("_loginUserSid", _loginUserSid);
        CM_LoggerUtil.outputDaoInputParamLog("_txtDocType", _txtDocType);
        CM_LoggerUtil.outputDaoInputParamLog("_deleteFlg", _deleteFlg);
        CM_LoggerUtil.outputDaoInputParamLog("_isAdmin", _isAdmin);

        // 検索条件のセット
        BeanMap param = this.setParam(_formInfo, _mapSearchCondInfo);
        param.put(CM_A04_Const.SQL_PARAM.LOGIN_USER_SID, _loginUserSid);
        if (!CM_CommonUtil.isNullOrBlank(_txtDocType)) {
            param.put(MstDocumentEntityNames.docType().toString(), _txtDocType);
        }
        // 削除フラグ
        param.put(MstDocumentEntityNames.deleteFlag().toString(), _deleteFlg);
        // 管理者フラグ
        param.put(IS_ADMIN, _isAdmin);

        String path = SQL_PATH_COMM + "SelectDocumentListCount.sql";

        // データ件数の取得
        Long cnt = this.jdbcManager.selectBySqlFile(Long.class, path, param)
                .getSingleResult();
        if (cnt != null) {
            ret = cnt.longValue();
        }

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(cnt);

        return ret;
    }

    /**
     *
     * 一覧データ取得.<br>
     * <br>
     * 概要:<br>
     * 一覧データを取得する <br>
     *
     * @param _formInfo
     *            フォーム情報
     * @param _mapSearchCondInfo
     *            検索条件情報Map
     * @param _offsetInfo
     *            オフセット情報
     * @param _loginUserSid
     *            ログインユーザSID
     * @param _txtDocType
     *            文書区分
     * @param _isAdmin
     *            管理者フラグ
     * @return 一覧データリスト
     */
    public List<BeanMap> selectDocumentList(final BeanMap _formInfo,
            final Map<String, Object> _mapSearchCondInfo,
            final Map<String, Integer> _offsetInfo, final int _loginUserSid,
            final String _txtDocType, final boolean _isAdmin) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_formInfo", _formInfo);
        CM_LoggerUtil.outputDaoInputParamLog("_mapSearchCondInfo",
                _mapSearchCondInfo);
        CM_LoggerUtil.outputDaoInputParamLog("_offsetInfo", _offsetInfo);
        CM_LoggerUtil.outputDaoInputParamLog("_loginUserSid", _loginUserSid);
        CM_LoggerUtil.outputDaoInputParamLog("_txtDocType", _txtDocType);
        CM_LoggerUtil.outputDaoInputParamLog("_isAdmin", _isAdmin);

        // 検索条件のセット
        BeanMap param = this.setParam(_formInfo, _mapSearchCondInfo);
        param.put(CM_A04_Const.SQL_PARAM.LOGIN_USER_SID, _loginUserSid);
        if (!CM_CommonUtil.isNullOrBlank(_txtDocType)) {
            param.put(MstDocumentEntityNames.docType().toString(), _txtDocType);
        }
        param.put(IS_ADMIN, _isAdmin);

        String path = SQL_PATH_COMM + "SelectDocumentList.sql";

        // ページング用クラス
        FW00_22_DataListOffSetUtil<BeanMap> offsetUtil = new FW00_22_DataListOffSetUtil<BeanMap>();

        // データ件数の取得
        List<BeanMap> ret = offsetUtil.offsetDataListBySqlFile(
                this.jdbcManager.selectBySqlFile(BeanMap.class, path, param),
                _offsetInfo).getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * 一覧データ取得.<br>
     * <br>
     * 概要:<br>
     * 一覧データを取得する <br>
     *
     * @param _formInfo
     *            フォーム情報
     * @param _mapSearchCondInfo
     *            検索条件情報Map
     * @param _loginUserSid
     *            ユーザSID
     * @param _txtDocType
     *            文書区分
     * @param _isAdmin
     *            管理者フラグ
     * @return 一覧データリスト
     */
    public List<BeanMap> selectDocumentListCSV(final BeanMap _formInfo,
            final Map<String, Object> _mapSearchCondInfo,
            final int _loginUserSid, final String _txtDocType, final boolean _isAdmin) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_formInfo", _formInfo);
        CM_LoggerUtil.outputDaoInputParamLog("_mapSearchCondInfo", _mapSearchCondInfo);
        CM_LoggerUtil.outputDaoInputParamLog("_loginUserSid", _loginUserSid);
        CM_LoggerUtil.outputDaoInputParamLog("_txtDocType", _txtDocType);

        // 検索条件のセット
        BeanMap param = this.setParam(_formInfo, _mapSearchCondInfo);
        param.put(CM_A04_Const.SQL_PARAM.LOGIN_USER_SID, _loginUserSid);
        if (!CM_CommonUtil.isNullOrBlank(_txtDocType)) {
            param.put(MstDocumentEntityNames.docType().toString(), _txtDocType);
        }
        param.put(FW01_14_ListForm.FW0114FORM_SORTKEY, null);
        // 削除フラグ
        param.put(MstDocumentEntityNames.deleteFlag().toString(), false);
        // 管理者フラグ
        param.put(IS_ADMIN, _isAdmin);

        String path = SQL_PATH_COMM + "SelectDocumentListCSV.sql";

        // データ件数の取得
        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(BeanMap.class, path, param).getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * パラメータ設定処理.<br>
     * <br>
     * 概要:<br>
     * SQL文のパラメータをセットする <br>
     *
     * @param _formInfo
     *            form情報
     * @param _mapSearchCondInfo
     *            詳細検索条件情報
     * @return _param SQLパラメータ
     */
    private BeanMap setParam(final BeanMap _formInfo,
            final Map<String, Object> _mapSearchCondInfo) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_formInfo", _formInfo);
        CM_LoggerUtil.outputDaoInputParamLog("_mapSearchCondInfo", _mapSearchCondInfo);

        BeanMap ret = new BeanMap();

        // ソートキー
        this.setParamFromForm(_formInfo,
                FW01_14_ListForm.FW0114FORM_SORTKEY, ret, null);
        // ソート順
        this.setParamFromForm(_formInfo,
                FW01_14_ListForm.FW0114FORM_SORTORDER, ret, null);

        // 固定検索条件情報を追加
        this.setParamFromForm(_formInfo, SEARCH_TXT_DOC_NAME, ret, FW00_19_Const.PERCENT_STR);
        this.setParamFromForm(_formInfo, SEARCH_TXT_FILE_KIND, ret, null);


        // 型番と機器はSIDのため、数値型に変換する。
        if (CM_CommonUtil.isNullOrBlank(_formInfo.get(SEARCH_TXT_MODEL_SID))) {
            ret.put(SEARCH_TXT_MODEL_SID, null);
        } else {
            String tmp = _formInfo.get(SEARCH_TXT_MODEL_SID).toString();
            ret.put(SEARCH_TXT_MODEL_SID, Integer.valueOf(tmp));
        }

        if (CM_CommonUtil.isNullOrBlank(_formInfo.get(SEARCH_TXT_DEVICE_SID))) {
            ret.put(SEARCH_TXT_DEVICE_SID, null);
        } else {
            String tmp = _formInfo.get(SEARCH_TXT_DEVICE_SID).toString();
            ret.put(SEARCH_TXT_DEVICE_SID, Integer.valueOf(tmp));
        }

        // 詳細検索条件情報を追加
        ret.putAll(_mapSearchCondInfo);

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);
        return ret;
    }

    /**
     *
     * 検索条件設定.<br>
     * <br>
     * 概要:<br>
     * フォームから取得したパラメータをチェックし、検索条件Mapに追加する <br>
     *
     * @param _formInfo
     *            フォーム情報
     * @param _key
     *            キー
     * @param _param
     *            検索条件Map
     * @param _option
     *            検索条件編集オプション
     */
    private void setParamFromForm(final BeanMap _formInfo, final String _key,
            final BeanMap _param, final String _option) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_formInfo", _formInfo);
        CM_LoggerUtil.outputDaoInputParamLog("_key", _key);
        CM_LoggerUtil.outputDaoInputParamLog("_param", _param);
        CM_LoggerUtil.outputDaoInputParamLog("_option", _option);

        Object parameter = _formInfo.get(_key);

        if (CM_CommonUtil.isNullOrBlank(parameter)) {
            _param.put(_key, null);
        } else {
            if (_option != null) {
                // あいまい検索用
                _param.put(_key, _option + parameter + _option);
            } else {
                _param.put(_key, parameter);
            }
        }
        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(null);
    }

    /**
     * 画像リスト取得処理.<br>
     *<br>
     * 概要:<br>
     *   資料マスタから指定されたkeyCdの画像リストを取得する
     *<br>
     * @param _docType 資料種別
     * @param _keyCd キーコード
     * @return 画像リスト
     */
    public List<MstDocumentEntity> getPicList(final String _docType, final String _keyCd) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_docType", _docType);
        CM_LoggerUtil.outputDaoInputParamLog("_keyCd", _keyCd);

        List<MstDocumentEntity> listEntity = this.jdbcManager
                .from(MstDocumentEntity.class)
                .where("doc_type = ? AND key_cd = ? AND file_kind = '6' AND delete_flag = false", _docType, _keyCd)
                .orderBy(Operations.desc(MstDocumentEntityNames.lastUpdTim().toString()))
                .getResultList();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(listEntity);

        return listEntity;
    }

    /**
     *
     * 資料情報取得.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _sid 資料SID
     * @return 資料情報
     */
    public MstDocumentEntity getDocInfo(final int _sid) {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_sid", _sid);

        MstDocumentEntity entity = this.jdbcManager
                .from(MstDocumentEntity.class)
                .where("sid = ? AND delete_flag = false", _sid)
                .getSingleResult();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(entity);

        return entity;
    }

    /**
     * ドキュメント情報取得.<br/>
     * <br/>
     * 概要:<br/>
     * 型番に紐付くドキュメント情報を取得する。 <br/>
     *
     * @param _modelSid
     *            型番SID
     * @return ドキュメントリスト
     */
    public List<MstDocumentEntity> getDocumentList(final Integer _modelSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_modelSid", _modelSid);

        // 検索実行
        List<MstDocumentEntity> ret = this.jdbcManager
                .from(MstDocumentEntity.class)
                .where(new SimpleWhere().eq(MstDocumentEntityNames.docType(),
                        CM_A04_Const.DOCTYPE.MODEL).eq(
                        MstDocumentEntityNames.keyCd(), _modelSid))
                .getResultList();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     * 型番に紐付く資料情報の数を取得.
     *
     * @param _modelSid
     *            型番SID
     * @return 型番に紐付く資料情報数
     */
    public long getRelModelDocumentCnt(final Integer _modelSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_modelSid", _modelSid);

        // 検索実行
        long ret = this.jdbcManager
                .from(MstDocumentEntity.class)
                .where(new SimpleWhere().eq(MstDocumentEntityNames.docType(),
                        CM_A04_Const.DOCTYPE.MODEL).eq(
                        MstDocumentEntityNames.keyCd(), _modelSid)).getCount();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;

    }

    /**
     * 機器に紐付く資料情報の数を取得.
     *
     * @param _deviceSid
     *            機器SID
     * @return 機器に紐付く資料情報数
     */
    public long getRelDeviceDocumentCnt(final Integer _deviceSid) {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputDaoInputParamLog("_deviceSid", _deviceSid);

        // 検索実行
        long ret = this.jdbcManager
                .from(MstDocumentEntity.class)
                .where(new SimpleWhere().eq(MstDocumentEntityNames.docType(),
                        CM_A04_Const.DOCTYPE.DEVICE).eq(
                        MstDocumentEntityNames.keyCd(), _deviceSid)).getCount();

        // メソッド終了ログ出力
        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;

    }
}
