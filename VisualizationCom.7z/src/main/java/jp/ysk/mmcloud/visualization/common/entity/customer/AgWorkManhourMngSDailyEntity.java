package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 作業工数実績(シリーズ別)(日別)
 * 
 */
@Entity
@Table(name = "ag_work_manhour_mng_s_daily")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class AgWorkManhourMngSDailyEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 品目階層TEXT_その2 */
    @Id
    @Column(length = 40, nullable = false, unique = false)
    public String vtextInfo2;

    /** 作業パターンID */
    @Id
    @Column(precision = 8, nullable = false, unique = false)
    public BigDecimal jobPtnId;

    /** 作業STEP */
    @Id
    @Column(length = 8, nullable = false, unique = false)
    public String stepNo;

    /** データ日時 */
    @Id
    @Column(nullable = false, unique = false)
    public Timestamp dataDate;

    /** 製造ラインコード */
    @Column(length = 10, nullable = true, unique = false)
    public String seizouLnCd;

    /** 製造ライン名 */
    @Column(length = 64, nullable = true, unique = false)
    public String seizouLnNm;

    /** 工程コード */
    @Column(length = 5, nullable = true, unique = false)
    public String processCd;

    /** 工程名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String processNm;

    /** ラインNo */
    @Column(length = 32, nullable = true, unique = false)
    public String lnNo;

    /** ライン名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String lnNm;

    /** 作業パターン名 */
    @Column(length = 64, nullable = true, unique = false)
    public String jobPtnName;

    /** 標準工数 */
    @Column(precision = 10, nullable = true, unique = false)
    public Integer standardManhour;

    /** 実績平均 */
    @Column(precision = 15, scale = 4, nullable = true, unique = false)
    public BigDecimal workManhourAverage;

    /** 標準偏差 */
    @Column(precision = 15, scale = 4, nullable = true, unique = false)
    public BigDecimal standardDeviation;

    /** 母数 */
    @Column(precision = 10, nullable = true, unique = false)
    public Integer parameter;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
