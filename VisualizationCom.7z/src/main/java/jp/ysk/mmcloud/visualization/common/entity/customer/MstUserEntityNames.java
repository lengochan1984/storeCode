package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link MstUserEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class MstUserEntityNames {

    /**
     * sidのプロパティ名を返します。
     * 
     * @return sidのプロパティ名
     */
    public static PropertyName<Integer> sid() {
        return new PropertyName<Integer>("sid");
    }

    /**
     * idのプロパティ名を返します。
     * 
     * @return idのプロパティ名
     */
    public static PropertyName<String> id() {
        return new PropertyName<String>("id");
    }

    /**
     * userLastnameのプロパティ名を返します。
     * 
     * @return userLastnameのプロパティ名
     */
    public static PropertyName<String> userLastname() {
        return new PropertyName<String>("userLastname");
    }

    /**
     * userFirstnameのプロパティ名を返します。
     * 
     * @return userFirstnameのプロパティ名
     */
    public static PropertyName<String> userFirstname() {
        return new PropertyName<String>("userFirstname");
    }

    /**
     * userLastnameKanaのプロパティ名を返します。
     * 
     * @return userLastnameKanaのプロパティ名
     */
    public static PropertyName<String> userLastnameKana() {
        return new PropertyName<String>("userLastnameKana");
    }

    /**
     * userFirstnameKanaのプロパティ名を返します。
     * 
     * @return userFirstnameKanaのプロパティ名
     */
    public static PropertyName<String> userFirstnameKana() {
        return new PropertyName<String>("userFirstnameKana");
    }

    /**
     * userAuthCdのプロパティ名を返します。
     * 
     * @return userAuthCdのプロパティ名
     */
    public static PropertyName<String> userAuthCd() {
        return new PropertyName<String>("userAuthCd");
    }

    /**
     * passwdのプロパティ名を返します。
     * 
     * @return passwdのプロパティ名
     */
    public static PropertyName<String> passwd() {
        return new PropertyName<String>("passwd");
    }

    /**
     * timezoneCdのプロパティ名を返します。
     * 
     * @return timezoneCdのプロパティ名
     */
    public static PropertyName<String> timezoneCd() {
        return new PropertyName<String>("timezoneCd");
    }

    /**
     * langCdのプロパティ名を返します。
     * 
     * @return langCdのプロパティ名
     */
    public static PropertyName<String> langCd() {
        return new PropertyName<String>("langCd");
    }

    /**
     * themeColorCdのプロパティ名を返します。
     * 
     * @return themeColorCdのプロパティ名
     */
    public static PropertyName<String> themeColorCd() {
        return new PropertyName<String>("themeColorCd");
    }

    /**
     * clockDispFlagのプロパティ名を返します。
     * 
     * @return clockDispFlagのプロパティ名
     */
    public static PropertyName<String> clockDispFlag() {
        return new PropertyName<String>("clockDispFlag");
    }

    /**
     * charSizeのプロパティ名を返します。
     * 
     * @return charSizeのプロパティ名
     */
    public static PropertyName<String> charSize() {
        return new PropertyName<String>("charSize");
    }

    /**
     * invalidFlagのプロパティ名を返します。
     * 
     * @return invalidFlagのプロパティ名
     */
    public static PropertyName<String> invalidFlag() {
        return new PropertyName<String>("invalidFlag");
    }

    /**
     * expTimのプロパティ名を返します。
     * 
     * @return expTimのプロパティ名
     */
    public static PropertyName<Timestamp> expTim() {
        return new PropertyName<Timestamp>("expTim");
    }

    /**
     * deleteFlagのプロパティ名を返します。
     * 
     * @return deleteFlagのプロパティ名
     */
    public static PropertyName<Boolean> deleteFlag() {
        return new PropertyName<Boolean>("deleteFlag");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _MstUserNames extends PropertyName<MstUserEntity> {

        /**
         * インスタンスを構築します。
         */
        public _MstUserNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _MstUserNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _MstUserNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * sidのプロパティ名を返します。
         *
         * @return sidのプロパティ名
         */
        public PropertyName<Integer> sid() {
            return new PropertyName<Integer>(this, "sid");
        }

        /**
         * idのプロパティ名を返します。
         *
         * @return idのプロパティ名
         */
        public PropertyName<String> id() {
            return new PropertyName<String>(this, "id");
        }

        /**
         * userLastnameのプロパティ名を返します。
         *
         * @return userLastnameのプロパティ名
         */
        public PropertyName<String> userLastname() {
            return new PropertyName<String>(this, "userLastname");
        }

        /**
         * userFirstnameのプロパティ名を返します。
         *
         * @return userFirstnameのプロパティ名
         */
        public PropertyName<String> userFirstname() {
            return new PropertyName<String>(this, "userFirstname");
        }

        /**
         * userLastnameKanaのプロパティ名を返します。
         *
         * @return userLastnameKanaのプロパティ名
         */
        public PropertyName<String> userLastnameKana() {
            return new PropertyName<String>(this, "userLastnameKana");
        }

        /**
         * userFirstnameKanaのプロパティ名を返します。
         *
         * @return userFirstnameKanaのプロパティ名
         */
        public PropertyName<String> userFirstnameKana() {
            return new PropertyName<String>(this, "userFirstnameKana");
        }

        /**
         * userAuthCdのプロパティ名を返します。
         *
         * @return userAuthCdのプロパティ名
         */
        public PropertyName<String> userAuthCd() {
            return new PropertyName<String>(this, "userAuthCd");
        }

        /**
         * passwdのプロパティ名を返します。
         *
         * @return passwdのプロパティ名
         */
        public PropertyName<String> passwd() {
            return new PropertyName<String>(this, "passwd");
        }

        /**
         * timezoneCdのプロパティ名を返します。
         *
         * @return timezoneCdのプロパティ名
         */
        public PropertyName<String> timezoneCd() {
            return new PropertyName<String>(this, "timezoneCd");
        }

        /**
         * langCdのプロパティ名を返します。
         *
         * @return langCdのプロパティ名
         */
        public PropertyName<String> langCd() {
            return new PropertyName<String>(this, "langCd");
        }

        /**
         * themeColorCdのプロパティ名を返します。
         *
         * @return themeColorCdのプロパティ名
         */
        public PropertyName<String> themeColorCd() {
            return new PropertyName<String>(this, "themeColorCd");
        }

        /**
         * clockDispFlagのプロパティ名を返します。
         *
         * @return clockDispFlagのプロパティ名
         */
        public PropertyName<String> clockDispFlag() {
            return new PropertyName<String>(this, "clockDispFlag");
        }

        /**
         * charSizeのプロパティ名を返します。
         *
         * @return charSizeのプロパティ名
         */
        public PropertyName<String> charSize() {
            return new PropertyName<String>(this, "charSize");
        }

        /**
         * invalidFlagのプロパティ名を返します。
         *
         * @return invalidFlagのプロパティ名
         */
        public PropertyName<String> invalidFlag() {
            return new PropertyName<String>(this, "invalidFlag");
        }

        /**
         * expTimのプロパティ名を返します。
         *
         * @return expTimのプロパティ名
         */
        public PropertyName<Timestamp> expTim() {
            return new PropertyName<Timestamp>(this, "expTim");
        }

        /**
         * deleteFlagのプロパティ名を返します。
         *
         * @return deleteFlagのプロパティ名
         */
        public PropertyName<Boolean> deleteFlag() {
            return new PropertyName<Boolean>(this, "deleteFlag");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
