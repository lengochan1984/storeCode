/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/04/07| <C1.01>　新規作成                                                    | C1.01  | (YSK)三村
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.dto;

import jp.ysk.mmcloud.visualization.common.entity.customer.MstRoleSettingEntity;

/**
 * CM_PageAuthInfoDtoクラス.
 *
 */
public class CM_PageAuthInfoDto extends MstRoleSettingEntity {

    /**
     * 機能CD名称.
     */
    public String functionCdName;

    /**
     * ページID名称.
     */
    public String pageIdName;

    /**
     * システム管理者のみ表示可能.
     */
    public boolean enableOnlySysAdmin;
}
