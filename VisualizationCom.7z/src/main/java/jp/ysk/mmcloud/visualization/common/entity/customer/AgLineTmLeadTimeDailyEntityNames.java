package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link AgLineTmLeadTimeDailyEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:40")
public class AgLineTmLeadTimeDailyEntityNames {

    /**
     * lnIdのプロパティ名を返します。
     * 
     * @return lnIdのプロパティ名
     */
    public static PropertyName<BigDecimal> lnId() {
        return new PropertyName<BigDecimal>("lnId");
    }

    /**
     * NLnIdのプロパティ名を返します。
     * 
     * @return NLnIdのプロパティ名
     */
    public static PropertyName<BigDecimal> NLnId() {
        return new PropertyName<BigDecimal>("NLnId");
    }

    /**
     * sasizuNoのプロパティ名を返します。
     * 
     * @return sasizuNoのプロパティ名
     */
    public static PropertyName<String> sasizuNo() {
        return new PropertyName<String>("sasizuNo");
    }

    /**
     * subNoのプロパティ名を返します。
     * 
     * @return subNoのプロパティ名
     */
    public static PropertyName<BigDecimal> subNo() {
        return new PropertyName<BigDecimal>("subNo");
    }

    /**
     * dataDateのプロパティ名を返します。
     * 
     * @return dataDateのプロパティ名
     */
    public static PropertyName<Timestamp> dataDate() {
        return new PropertyName<Timestamp>("dataDate");
    }

    /**
     * plantCdのプロパティ名を返します。
     * 
     * @return plantCdのプロパティ名
     */
    public static PropertyName<String> plantCd() {
        return new PropertyName<String>("plantCd");
    }

    /**
     * seizouLnCdのプロパティ名を返します。
     * 
     * @return seizouLnCdのプロパティ名
     */
    public static PropertyName<String> seizouLnCd() {
        return new PropertyName<String>("seizouLnCd");
    }

    /**
     * seizouLnNmのプロパティ名を返します。
     * 
     * @return seizouLnNmのプロパティ名
     */
    public static PropertyName<String> seizouLnNm() {
        return new PropertyName<String>("seizouLnNm");
    }

    /**
     * processCdのプロパティ名を返します。
     * 
     * @return processCdのプロパティ名
     */
    public static PropertyName<String> processCd() {
        return new PropertyName<String>("processCd");
    }

    /**
     * processNmのプロパティ名を返します。
     * 
     * @return processNmのプロパティ名
     */
    public static PropertyName<String> processNm() {
        return new PropertyName<String>("processNm");
    }

    /**
     * lnNoのプロパティ名を返します。
     * 
     * @return lnNoのプロパティ名
     */
    public static PropertyName<String> lnNo() {
        return new PropertyName<String>("lnNo");
    }

    /**
     * lnNmのプロパティ名を返します。
     * 
     * @return lnNmのプロパティ名
     */
    public static PropertyName<String> lnNm() {
        return new PropertyName<String>("lnNm");
    }

    /**
     * NProcessCdのプロパティ名を返します。
     * 
     * @return NProcessCdのプロパティ名
     */
    public static PropertyName<String> NProcessCd() {
        return new PropertyName<String>("NProcessCd");
    }

    /**
     * NProcessNmのプロパティ名を返します。
     * 
     * @return NProcessNmのプロパティ名
     */
    public static PropertyName<String> NProcessNm() {
        return new PropertyName<String>("NProcessNm");
    }

    /**
     * NLnNoのプロパティ名を返します。
     * 
     * @return NLnNoのプロパティ名
     */
    public static PropertyName<String> NLnNo() {
        return new PropertyName<String>("NLnNo");
    }

    /**
     * NLnNmのプロパティ名を返します。
     * 
     * @return NLnNmのプロパティ名
     */
    public static PropertyName<String> NLnNm() {
        return new PropertyName<String>("NLnNm");
    }

    /**
     * leadTimeのプロパティ名を返します。
     * 
     * @return leadTimeのプロパティ名
     */
    public static PropertyName<Long> leadTime() {
        return new PropertyName<Long>("leadTime");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _AgLineTmLeadTimeDailyNames extends PropertyName<AgLineTmLeadTimeDailyEntity> {

        /**
         * インスタンスを構築します。
         */
        public _AgLineTmLeadTimeDailyNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _AgLineTmLeadTimeDailyNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _AgLineTmLeadTimeDailyNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * lnIdのプロパティ名を返します。
         *
         * @return lnIdのプロパティ名
         */
        public PropertyName<BigDecimal> lnId() {
            return new PropertyName<BigDecimal>(this, "lnId");
        }

        /**
         * NLnIdのプロパティ名を返します。
         *
         * @return NLnIdのプロパティ名
         */
        public PropertyName<BigDecimal> NLnId() {
            return new PropertyName<BigDecimal>(this, "NLnId");
        }

        /**
         * sasizuNoのプロパティ名を返します。
         *
         * @return sasizuNoのプロパティ名
         */
        public PropertyName<String> sasizuNo() {
            return new PropertyName<String>(this, "sasizuNo");
        }

        /**
         * subNoのプロパティ名を返します。
         *
         * @return subNoのプロパティ名
         */
        public PropertyName<BigDecimal> subNo() {
            return new PropertyName<BigDecimal>(this, "subNo");
        }

        /**
         * dataDateのプロパティ名を返します。
         *
         * @return dataDateのプロパティ名
         */
        public PropertyName<Timestamp> dataDate() {
            return new PropertyName<Timestamp>(this, "dataDate");
        }

        /**
         * plantCdのプロパティ名を返します。
         *
         * @return plantCdのプロパティ名
         */
        public PropertyName<String> plantCd() {
            return new PropertyName<String>(this, "plantCd");
        }

        /**
         * seizouLnCdのプロパティ名を返します。
         *
         * @return seizouLnCdのプロパティ名
         */
        public PropertyName<String> seizouLnCd() {
            return new PropertyName<String>(this, "seizouLnCd");
        }

        /**
         * seizouLnNmのプロパティ名を返します。
         *
         * @return seizouLnNmのプロパティ名
         */
        public PropertyName<String> seizouLnNm() {
            return new PropertyName<String>(this, "seizouLnNm");
        }

        /**
         * processCdのプロパティ名を返します。
         *
         * @return processCdのプロパティ名
         */
        public PropertyName<String> processCd() {
            return new PropertyName<String>(this, "processCd");
        }

        /**
         * processNmのプロパティ名を返します。
         *
         * @return processNmのプロパティ名
         */
        public PropertyName<String> processNm() {
            return new PropertyName<String>(this, "processNm");
        }

        /**
         * lnNoのプロパティ名を返します。
         *
         * @return lnNoのプロパティ名
         */
        public PropertyName<String> lnNo() {
            return new PropertyName<String>(this, "lnNo");
        }

        /**
         * lnNmのプロパティ名を返します。
         *
         * @return lnNmのプロパティ名
         */
        public PropertyName<String> lnNm() {
            return new PropertyName<String>(this, "lnNm");
        }

        /**
         * NProcessCdのプロパティ名を返します。
         *
         * @return NProcessCdのプロパティ名
         */
        public PropertyName<String> NProcessCd() {
            return new PropertyName<String>(this, "NProcessCd");
        }

        /**
         * NProcessNmのプロパティ名を返します。
         *
         * @return NProcessNmのプロパティ名
         */
        public PropertyName<String> NProcessNm() {
            return new PropertyName<String>(this, "NProcessNm");
        }

        /**
         * NLnNoのプロパティ名を返します。
         *
         * @return NLnNoのプロパティ名
         */
        public PropertyName<String> NLnNo() {
            return new PropertyName<String>(this, "NLnNo");
        }

        /**
         * NLnNmのプロパティ名を返します。
         *
         * @return NLnNmのプロパティ名
         */
        public PropertyName<String> NLnNm() {
            return new PropertyName<String>(this, "NLnNm");
        }

        /**
         * leadTimeのプロパティ名を返します。
         *
         * @return leadTimeのプロパティ名
         */
        public PropertyName<Long> leadTime() {
            return new PropertyName<Long>(this, "leadTime");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
