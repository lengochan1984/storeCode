/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/07/28| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.dto.CM_CheckDeleteResult;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.dao.CM_InfoDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_ListBaseDao;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSearchConditionEntity;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;
import jp.ysk.mmcloud.visualization.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.visualization.common.util.CM_MessageUtil;

import org.seasar.framework.beans.util.BeanMap;

import java.util.Date;

/**
 *
 * 一覧がある基底クラスの共通Service.<br>
 *<br>
 * 概要:<br>
 *  一覧がある基底クラスの共通Serviceクラス
 *<br>
 */
public abstract class CM_InfoListBaseService extends CM_VisualizationBaseService {

    /**
     * 検索条件(FROM).
     */
    protected static final String SEARCH_DATE_FROM_NAME = "txtSearchDateTimeFrom";

    /**
     * 検索条件(TO).
     */
    protected static final String SEARCH_DATE_TO_NAME = "txtSearchDateTimeTo";

    /**
     * 計算用（１時間）.
     */
    protected static final int ONE_HOUR = 60;

    /**
     *
     * 一覧検索の前処理.<br>
     *<br>
     * 概要:<br>
     *   一覧の検索時に実行する前処理
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     */
    public void preGetData(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        return;
    }

    /**
     *
     * データ件数取得.<br>
     *<br>
     * 概要:<br>
     *   一覧のデータ件数を取得する
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return 件数
     */
    public long getDataCount(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        return 0;
    };

    /**
     *
     * 一覧データ取得.<br>
     *<br>
     * 概要:<br>
     *   一覧のデータ件数を取得する
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @param _offsetInfo オフセット情報
     * @return 抽出データ
     */
    public List<?> getDataList(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo, final Map<String, Integer> _offsetInfo) {
        return null;
    };

    /**
     * 画面データアクセスDaoを取得.<br>
     * <br>
     * 概要:<br>
     *   画面データアクセスDaoを取得
     *
     *
     * @return 画面データアクセスDao
     */
    @Override
    protected abstract CM_ListBaseDao getCustomerDao();

    /**
     *
     * Excel出力データ取得.<br>
     *<br>
     * 概要:<br>
     * Excel出力データ取得
     *<br>
     * @param _formInfo フォーム情報
     * @return Excel出力データ
     */
    protected abstract List<?> getExportExcelData(final BeanMap _formInfo);


    /**
     * 検索条件初期値取得処理.
     * @param _formMap フォーム情報
     */
    public void getDefaultSearchDate(final BeanMap _formMap) {

        //開始時刻（分）を取得
        Integer start = this.getCustomerDao().getRunningStartTime((String) _formMap.get(CM_BaseForm.COM_PLANT_CODE));
        // 現在時刻取得
        Calendar cal = Calendar.getInstance();
        Integer currentMin = cal.get(Calendar.HOUR_OF_DAY) * ONE_HOUR;
        currentMin += cal.get(Calendar.MINUTE);
        if (start.compareTo(currentMin) > 0) {
            //現在時刻＜開始時刻
            cal.add(Calendar.DAY_OF_MONTH, -1);
        }
        Calendar startCal = Calendar.getInstance();
        startCal.set(Calendar.YEAR , cal.get(Calendar.YEAR));
        startCal.set(Calendar.MONTH , cal.get(Calendar.MONTH));
        startCal.set(Calendar.DATE , cal.get(Calendar.DATE));
        startCal.set(Calendar.HOUR_OF_DAY , 0);
        startCal.set(Calendar.MINUTE , 0);
        startCal.set(Calendar.SECOND , 0);
        startCal.add(Calendar.MINUTE , start);

        SimpleDateFormat sdf;
        sdf = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT_MIN_HYPHEN);
        Calendar endCal = Calendar.getInstance();

        _formMap.put(CM_BaseForm.COM_DATA_DATE_FROM, sdf.format(startCal.getTime()));
        _formMap.put(CM_BaseForm.COM_DATA_DATE_TO, sdf.format(endCal.getTime()));
        _formMap.put(CM_BaseForm.COM_DATE_TYPE, CM_A04_Const.DATE_TYPE_NITIJI);

        sdf = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT_FOR_DISP);
        _formMap.put(CM_BaseForm.COM_DATA_DATE_DISP, sdf.format(startCal.getTime()));
        int len = _formMap.get(CM_BaseForm.COM_DATA_DATE_DISP).toString().length();
        if (len == 10) {
            _formMap.put(CM_BaseForm.COM_DATE_TYPE, CM_A04_Const.DATE_TYPE_JIKANBETU);
        } else if (len ==6) {
            _formMap.put(CM_BaseForm.COM_DATE_TYPE, CM_A04_Const.DATE_TYPE_NITIJI);
        } else {
            _formMap.put(CM_BaseForm.COM_DATE_TYPE, CM_A04_Const.DATE_TYPE_GETUJI);
        }
    }

    /**
     *
     * CSV出力検索条件値取得.<br>
     *<br>
     * 概要:<br>
     *   CSVに出力する検索条件の値を取得
     *<br>
     * @param _formMap フォーム情報
     * @return CSV出力検索条件値
     */
    public Map<String, String> getCsvSearchConditionData(final BeanMap _formMap) {
        return null;
    }

    /**
     * 検索条件初期値取得処理.
     * @param _formMap フォーム情報
     */
    public void setDefaultSearchDate(BeanMap _formMap) {
        this.getCustomerDao().exchangeSearchDate(_formMap);
    }

    /**
     * 今月度取得処理.
     * @param _formMap フォーム情報
     */
    public String getCurrentMonth(BeanMap _formMap) {
          return this.getCurrentMonth(_formMap);
    }

    /**
    *
    * 情報挿入処理.<br>
    *<br>
    * 概要:<br>
    *<br>
    * @param _formInfo form情報
    * @return 新しいSID
    */
   public Integer insertInfo(final BeanMap _formInfo) {

       Object obj = this.checkInsertInfo(_formInfo);

       return this.insertData(_formInfo, obj);
   }

   /**
    *
    * 情報更新処理.<br>
    *<br>
    * 概要:<br>
    *<br>
    * @param _formInfo form情報
    */
   public void updateInfo(final BeanMap _formInfo) {
       Object obj = this.checkUpdateInfo(_formInfo);

       this.updateData(_formInfo, obj);
   }

   /**
    *
    * 情報削除処理.<br>
    *<br>
    * 概要:<br>
    *<br>
    * @param _formInfo form情報
    */
   public void deleteInfo(final BeanMap _formInfo) {

       Object obj = this.checkDeleteInfo(_formInfo);

       this.deleteData(_formInfo, obj);
   }

   /**
    *
    * 新規登録入力項目チェック処理.<br>
    *<br>
    * 概要:<br>
    *   新規登録入力項目チェック処理
    *<br>
    * @param _formInfo フォーム
    * @return 登録データ
    */
   protected Object checkInsertInfo(final BeanMap _formInfo) {
       return null;
   }

   /**
    *
    * 新規登録実行処理.<br>
    *<br>
    * 概要:<br>
    *  新規登録実行処理
    *<br>
    * @param _formInfo フォーム
    * @param _chkDataObj 登録データ
    * @return 新規SID
    */
   protected Integer insertData(final BeanMap _formInfo, final Object _chkDataObj) {

       Object preDataObj = this.beforeUpdate(_formInfo, _chkDataObj);

       Integer ret = null;

       try {

           this.getCustomerDao().biginTransaction();

           ret = this.insert(_formInfo, _chkDataObj, preDataObj);

           this.getCustomerDao().commitTransaction();

       } catch (FW00_12_BusinessException be) {
           this.getCustomerDao().rollbackTransaction();
           throw be;
       } catch (Exception e) {
           this.getCustomerDao().rollbackTransaction();
           CM_LoggerUtil.outputErrorLog(this.sessionDto, e);
           throw new FW00_12_BusinessException(CM_MessageUtil.getInsertFailedErrorMessage(this.sessionDto), FW00_19_Const.EMPTY_STR);
       }

       this.afterInsert(_formInfo, _chkDataObj, preDataObj);

       return ret;
   }

   /**
    *
    * 新規登録DBアクセス前処理.<br>
    *<br>
    * 概要:<br>
    *   新規登録アクセス前処理
    *<br>
    * @param _formInfo フォーム
    * @param _chkDataObj チェックデータ
    * @return 前処理データ
    */
   protected Object beforeInsert(final BeanMap _formInfo, final Object _chkDataObj) {
       return null;
   }

   /**
    *
    * 新規登録DBアクセス処理.<br>
    *<br>
    * 概要:<br>
    *   新規登録DBアクセス処理
    *<br>
    * @param _formInfo フォーム
    * @param _chkDataObj チェックデータ
    * @param _preDataObj DBアクセス前処理データ
    * @return 新規SID
    */
   protected Integer insert(final BeanMap _formInfo, final Object _chkDataObj, final Object _preDataObj) {
       return null;
   }

   /**
    *
    * 新規登録DBアクセス後処理.<br>
    *<br>
    * 概要:<br>
    *   新規登録アクセス後処理
    *<br>
    * @param _formInfo フォーム
    * @param _chkDataObj チェックデータ
    * @param _preDataObj DBアクセス前処理データ
    */
   protected void afterInsert(final BeanMap _formInfo, final Object _chkDataObj, final Object _preDataObj) {
       return;
   }

   /**
    *
    * 更新入力項目チェック処理.<br>
    *<br>
    * 概要:<br>
    *   更新入力項目チェック処理
    *<br>
    * @param _formInfo フォーム
    * @return チェックデータ
    */
   protected Object checkUpdateInfo(final BeanMap _formInfo) {
       return null;
   }

   /**
    *
    * 更新実行処理.<br>
    *<br>
    * 概要:<br>
    *  更新実行処理
    *<br>
    * @param _formInfo フォーム
    * @param _chkDataObj チェックデータ
    */
   protected void updateData(final BeanMap _formInfo, final Object _chkDataObj) {

       Object preDataObj = this.beforeUpdate(_formInfo, _chkDataObj);

       try {

           this.getCustomerDao().biginTransaction();

           this.update(_formInfo, _chkDataObj, preDataObj);

           this.getCustomerDao().commitTransaction();

       } catch (FW00_12_BusinessException be) {
           this.getCustomerDao().rollbackTransaction();
           throw be;
       } catch (Exception e) {
           this.getCustomerDao().rollbackTransaction();
           CM_LoggerUtil.outputErrorLog(this.sessionDto, e);
           throw new FW00_12_BusinessException(CM_MessageUtil.getUpdateFailedErrorMessage(this.sessionDto), FW00_19_Const.EMPTY_STR);
       }

       this.afterUpdate(_formInfo, _chkDataObj, preDataObj);
   }

   /**
    *
    * 更新DBアクセス前処理.<br>
    *<br>
    * 概要:<br>
    *   更新DBアクセス前処理
    *<br>
    * @param _formInfo フォーム
    * @param _chkDataObj チェックデータ
    * @return 前処理データ
    */
   protected Object beforeUpdate(final BeanMap _formInfo, final Object _chkDataObj) {
       return null;
   }

   /**
    *
    * 更新DBアクセス処理.<br>
    *<br>
    * 概要:<br>
    *   更新DBアクセス処理
    *<br>
    * @param _formInfo フォーム
    * @param _chkDataObj チェックデータ
    * @param _preDataObj DBアクセス前処理データ
    */
   protected void update(final BeanMap _formInfo, final Object _chkDataObj, final Object _preDataObj) {
       return;
   }

   /**
    *
    * 更新DBアクセス後処理.<br>
    *<br>
    * 概要:<br>
    *   更新アクセス後処理
    *<br>
    * @param _formInfo フォーム
    * @param _chkDataObj チェックデータ
    * @param _preDataObj DBアクセス前処理データ
    */
   protected void afterUpdate(final BeanMap _formInfo, final Object _chkDataObj, final Object _preDataObj) {
       return;
   }

   /**
    *
    * 削除時チェック処理.<br>
    *<br>
    * 概要:<br>
    *   削除時チェック処理.
    *<br>
    * @param _formInfo フォーム
    * @return 削除データ
    */
   protected Object checkDeleteInfo(final BeanMap _formInfo) {
       return null;
   }

   /**
    *
    * 削除実行処理.<br>
    *<br>
    * 概要:<br>
    *  削除実行処理
    *<br>
    * @param _formInfo フォーム
    * @param _chkDataObj チェックデータ
    */
   protected void deleteData(final BeanMap _formInfo, final Object _chkDataObj) {

       Object preDataObj = this.beforeUpdate(_formInfo, _chkDataObj);

       try {

           this.getCustomerDao().biginTransaction();

           this.delete(_formInfo, _chkDataObj, preDataObj);

           this.getCustomerDao().commitTransaction();

       } catch (FW00_12_BusinessException be) {
           this.getCustomerDao().rollbackTransaction();
           throw be;
       } catch (Exception e) {
           this.getCustomerDao().rollbackTransaction();
           CM_LoggerUtil.outputErrorLog(this.sessionDto, e);
           throw new FW00_12_BusinessException(CM_MessageUtil.getDeleteFailedErrorMessage(this.sessionDto), FW00_19_Const.EMPTY_STR);
       }

       this.afterDelete(_formInfo, _chkDataObj, preDataObj);

   }

   /**
    *
    * 削除DBアクセス前処理.<br>
    *<br>
    * 概要:<br>
    *   削除DBアクセス前処理
    *<br>
    * @param _formInfo フォーム
    * @param _chkDataObj チェックデータ
    * @return DBアクセス前処理データ
    */
   protected Object beforeDelete(final BeanMap _formInfo, final Object _chkDataObj) {
       return null;
   }

   /**
    *
    * 削除DBアクセス処理.<br>
    *<br>
    * 概要:<br>
    *   削除DBアクセス処理
    *<br>
    * @param _formInfo フォーム
    * @param _chkDataObj チェックデータ
    * @param _preDataObj DBアクセス前処理データ
    */
   protected void delete(final BeanMap _formInfo, final Object _chkDataObj, final Object _preDataObj) {
       return;
   }

   /**
    *
    * 削除DBアクセス後処理.<br>
    *<br>
    * 概要:<br>
    *   削除アクセス後処理
    *<br>
    * @param _formInfo フォーム
    * @param _chkDataObj チェックデータ
    * @param _preDataObj DBアクセス前処理データ
    */
   protected void afterDelete(final BeanMap _formInfo, final Object _chkDataObj, final Object _preDataObj) {
       return;
   }
   /**
    * 情報削除チェック処理.<br>
    *<br>
    * 概要:<br>
    *<br>
    * @param _formInfo form情報
    * @param _checkResult 削除時チェック結果
    */
   public void checkDeleteInfo(final BeanMap _formInfo, final CM_CheckDeleteResult _checkResult) {
       // 処理無し
   }

}
