package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link AgLineWorkHourlyEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class AgLineWorkHourlyEntityNames {

    /**
     * seizouLnIdのプロパティ名を返します。
     * 
     * @return seizouLnIdのプロパティ名
     */
    public static PropertyName<BigDecimal> seizouLnId() {
        return new PropertyName<BigDecimal>("seizouLnId");
    }

    /**
     * lnIdのプロパティ名を返します。
     * 
     * @return lnIdのプロパティ名
     */
    public static PropertyName<BigDecimal> lnId() {
        return new PropertyName<BigDecimal>("lnId");
    }

    /**
     * dataDateのプロパティ名を返します。
     * 
     * @return dataDateのプロパティ名
     */
    public static PropertyName<Timestamp> dataDate() {
        return new PropertyName<Timestamp>("dataDate");
    }

    /**
     * plantCdのプロパティ名を返します。
     * 
     * @return plantCdのプロパティ名
     */
    public static PropertyName<String> plantCd() {
        return new PropertyName<String>("plantCd");
    }

    /**
     * seizouLnCdのプロパティ名を返します。
     * 
     * @return seizouLnCdのプロパティ名
     */
    public static PropertyName<String> seizouLnCd() {
        return new PropertyName<String>("seizouLnCd");
    }

    /**
     * seizouLnNmのプロパティ名を返します。
     * 
     * @return seizouLnNmのプロパティ名
     */
    public static PropertyName<String> seizouLnNm() {
        return new PropertyName<String>("seizouLnNm");
    }

    /**
     * processCdのプロパティ名を返します。
     * 
     * @return processCdのプロパティ名
     */
    public static PropertyName<String> processCd() {
        return new PropertyName<String>("processCd");
    }

    /**
     * processNmのプロパティ名を返します。
     * 
     * @return processNmのプロパティ名
     */
    public static PropertyName<String> processNm() {
        return new PropertyName<String>("processNm");
    }

    /**
     * lnNoのプロパティ名を返します。
     * 
     * @return lnNoのプロパティ名
     */
    public static PropertyName<String> lnNo() {
        return new PropertyName<String>("lnNo");
    }

    /**
     * lnNmのプロパティ名を返します。
     * 
     * @return lnNmのプロパティ名
     */
    public static PropertyName<String> lnNm() {
        return new PropertyName<String>("lnNm");
    }

    /**
     * updDateのプロパティ名を返します。
     * 
     * @return updDateのプロパティ名
     */
    public static PropertyName<Timestamp> updDate() {
        return new PropertyName<Timestamp>("updDate");
    }

    /**
     * planNumのプロパティ名を返します。
     * 
     * @return planNumのプロパティ名
     */
    public static PropertyName<Integer> planNum() {
        return new PropertyName<Integer>("planNum");
    }

    /**
     * actualNumのプロパティ名を返します。
     * 
     * @return actualNumのプロパティ名
     */
    public static PropertyName<Integer> actualNum() {
        return new PropertyName<Integer>("actualNum");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _AgLineWorkHourlyNames extends PropertyName<AgLineWorkHourlyEntity> {

        /**
         * インスタンスを構築します。
         */
        public _AgLineWorkHourlyNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _AgLineWorkHourlyNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _AgLineWorkHourlyNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * seizouLnIdのプロパティ名を返します。
         *
         * @return seizouLnIdのプロパティ名
         */
        public PropertyName<BigDecimal> seizouLnId() {
            return new PropertyName<BigDecimal>(this, "seizouLnId");
        }

        /**
         * lnIdのプロパティ名を返します。
         *
         * @return lnIdのプロパティ名
         */
        public PropertyName<BigDecimal> lnId() {
            return new PropertyName<BigDecimal>(this, "lnId");
        }

        /**
         * dataDateのプロパティ名を返します。
         *
         * @return dataDateのプロパティ名
         */
        public PropertyName<Timestamp> dataDate() {
            return new PropertyName<Timestamp>(this, "dataDate");
        }

        /**
         * plantCdのプロパティ名を返します。
         *
         * @return plantCdのプロパティ名
         */
        public PropertyName<String> plantCd() {
            return new PropertyName<String>(this, "plantCd");
        }

        /**
         * seizouLnCdのプロパティ名を返します。
         *
         * @return seizouLnCdのプロパティ名
         */
        public PropertyName<String> seizouLnCd() {
            return new PropertyName<String>(this, "seizouLnCd");
        }

        /**
         * seizouLnNmのプロパティ名を返します。
         *
         * @return seizouLnNmのプロパティ名
         */
        public PropertyName<String> seizouLnNm() {
            return new PropertyName<String>(this, "seizouLnNm");
        }

        /**
         * processCdのプロパティ名を返します。
         *
         * @return processCdのプロパティ名
         */
        public PropertyName<String> processCd() {
            return new PropertyName<String>(this, "processCd");
        }

        /**
         * processNmのプロパティ名を返します。
         *
         * @return processNmのプロパティ名
         */
        public PropertyName<String> processNm() {
            return new PropertyName<String>(this, "processNm");
        }

        /**
         * lnNoのプロパティ名を返します。
         *
         * @return lnNoのプロパティ名
         */
        public PropertyName<String> lnNo() {
            return new PropertyName<String>(this, "lnNo");
        }

        /**
         * lnNmのプロパティ名を返します。
         *
         * @return lnNmのプロパティ名
         */
        public PropertyName<String> lnNm() {
            return new PropertyName<String>(this, "lnNm");
        }

        /**
         * updDateのプロパティ名を返します。
         *
         * @return updDateのプロパティ名
         */
        public PropertyName<Timestamp> updDate() {
            return new PropertyName<Timestamp>(this, "updDate");
        }

        /**
         * planNumのプロパティ名を返します。
         *
         * @return planNumのプロパティ名
         */
        public PropertyName<Integer> planNum() {
            return new PropertyName<Integer>(this, "planNum");
        }

        /**
         * actualNumのプロパティ名を返します。
         *
         * @return actualNumのプロパティ名
         */
        public PropertyName<Integer> actualNum() {
            return new PropertyName<Integer>(this, "actualNum");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
