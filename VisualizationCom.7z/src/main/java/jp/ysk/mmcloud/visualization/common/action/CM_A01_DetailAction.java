/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 *  2014/06/21| <10000-004> ユーザ設定押下処理追加 | 1.00.00| YSK)鬼丸
 *  2014/06/21| <10000-008> 説明画面用処理追加     | 1.00.00| YSK)中田
 *  2015/01/06| <20000-033> 変更仕様一覧No.26      | 3.00.00| YSK)中田
 *  2016/01/14| <40000-025> 変更仕様No.25          | 4.00.00| US)萩尾
 *  2016/08/26|             見える化対応           | C1.01  | US)松本
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.action;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.action.FW01_15_BaseAction;
import jp.ysk.fw.form.FW01_17_BaseForm;
import jp.ysk.mmcloud.common.action.CM_A03_InfoAction;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.dto.CM_A07_BreadCrumbDto;
import jp.ysk.mmcloud.common.dto.CM_CheckDeleteResult;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.common.util.CM_HeaderUtil;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.common.util.CM_MessageResourceUtil;
import jp.ysk.mmcloud.common.util.CM_SysEnvDataUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.CM_A05_PageInfo;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSearchConditionEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSearchConditionEntityNames;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;
import jp.ysk.mmcloud.visualization.common.service.CM_GetMstDataService;
import jp.ysk.mmcloud.visualization.common.service.CM_InfoService;
import jp.ysk.mmcloud.visualization.common.service.CM_VisualizationBaseService;

import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.beans.util.Beans;
import org.seasar.struts.annotation.Execute;

/**
 *
 * 単票用アクション基底クラス.<br>
 *<br>
 * 概要:<br>
 *   単票用アクション用の共通基底クラス
 *<br>
 */
public abstract class CM_A01_DetailAction extends FW01_15_BaseAction {
    /**
     * セッション情報.
     */
    @Resource
    public CM_A03_SessionDto cM_A03_SessionDto;

    /**
     * 共通ヘッダ情報.
     */
    public BeanMap mapTopHeader = null;

    /**
     * 情報ファイルリンク先.
     */
    public String infoFileLink = null;

    /**
     * ページID.
     */
    public String nowPageId = null;

    /**
     * 削除時チェック結果.
     */
    public CM_CheckDeleteResult checkDeleteResult;

    /**
     * JSPファイル名（削除警告JSP）.
     */
    public static final String JSP_FILE_NAME_DELETE_CONFIRM = "../common/com_deleteConfirm.jsp";

    /**
     * ヘッダ異常メッセージ.
     */
    public String haeaderAlertMessage = null;

    /**
     * お気に入りTOP.
     */
    public BeanMap favoriteTop = null;

    /** お気に入り登録可能フラグ. */
    public boolean favoriteSaveAvail = false;

    /**
     * お気に入りリストマップ.
     */
    public Map<Integer, BeanMap> favoriteListMap = new LinkedHashMap<Integer, BeanMap>();

    /** お気に入りJSP. */
    public static final String COM_FAVORITE_AREA_JSP = "../common/com_favoriteArea.jsp";

    /**
     * ページIDの設定.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param  _pageId ページID
     */
    protected void setPageId(final String _pageId) {
        this.nowPageId = _pageId;

        makeInfoFileLink(_pageId);
    }

    /**
     * 情報ページリンク先の生成.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param  _pageId ページID
     */
    private void makeInfoFileLink(final String _pageId) {
        this.infoFileLink = CM_A04_Const.INFO_PAGE_DIR + _pageId + ".html";
    }

    /**
     *
     * ヘッダーメニューのログアウト押下の処理.<br>
     *<br>
     * 概要:<br>
     *   ログイン画面へ遷移する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String logout_click() {

        FW01_17_BaseForm baseForm = new FW01_17_BaseForm();

        // セッション情報クリア
        this.cM_A03_SessionDto.initialize();

        return this.redirectPage("/a000010Login/index", new HashMap<String, String>(), baseForm);
    }

    /**
     *
     * ヘッダーメニューのリンク押下の処理.<br>
     *<br>
     * 概要:<br>
     *   押下したメニューの画面へ遷移する
     *<br>
     * @return JSP名
     * @throws IllegalAccessException アクセス権限違反例外
     */
    @Execute(validator = false)
    public String menu_link_click() throws IllegalAccessException {

        FW01_17_BaseForm baseForm = null;
        for (Field field : this.getClass().getFields()) {

            Object prop = field.get(this);

            // フォーム情報を検索
            if (prop instanceof FW01_17_BaseForm) {
                baseForm = (FW01_17_BaseForm) prop;
                break;
            }
        }

        String linkUrl = CM_A04_Const.HOME_URL;
        if (baseForm != null && !CM_CommonUtil.isNullOrBlank(baseForm.hdnComHeaderMenuLink)) {
            linkUrl = baseForm.hdnComHeaderMenuLink;
        }

        // パンくずメニュークリア
        CM_HeaderUtil.removeAllBreadCrumbList(this.cM_A03_SessionDto);

        // ホーム画面遷移の以外場合は、パンくず先頭にホーム画面をセット
        if (!linkUrl.equals(CM_A04_Const.HOME_URL)) {
            CM_HeaderUtil.addBreadCrumbList(this.cM_A03_SessionDto, CM_A04_Const.HOME_PAGE_ID);
            CM_HeaderUtil.setReturnInfo(this.cM_A03_SessionDto, CM_A04_Const.HOME_PAGE_ID, CM_A04_Const.HOME_URL, null);
        }

        Map<String, String> param = new HashMap<String, String>();
        if (baseForm != null) {
            if (baseForm instanceof CM_BaseForm) {
                // お気に入り遷移フラグがある場合は付加
                String hdnFavoriteAccessFlg = ((CM_BaseForm) baseForm).hdnFavoriteAccessNo;
                if (CM_CommonUtil.isNotNullOrBlank(hdnFavoriteAccessFlg)) {
                    param.put(CM_BaseForm.HDN_FAVORITE_ACCESS_NO, hdnFavoriteAccessFlg);
                }
                // 検索エリア、アンドンエリア表示情報
                String hdnSearchAreaOpen = ((CM_BaseForm) baseForm).hdnSearchAreaOpen;
                String hdnAndonAreaOpen = ((CM_BaseForm) baseForm).hdnAndonAreaOpen;
                param.put(CM_BaseForm.HDN_SEARCH_OPEN, hdnSearchAreaOpen);
                param.put(CM_BaseForm.HDN_ANDON_OPEN, hdnAndonAreaOpen);
            }
        }

        return this.redirectPage(linkUrl, param, baseForm);
    }

    /**
     *
     * ヘッダーメニューのユーザ設定押下の処理.<br>
     *<br>
     * 概要:<br>
     *   ユーザ情報画面へ遷移する
     *<br>
     * @return JSP名
     * @throws IllegalAccessException アクセス権限違反例外
     */
    @Execute(validator = false)
    public String menu_userSetting_click() throws IllegalAccessException {

        FW01_17_BaseForm baseForm = null;
        for (Field field : this.getClass().getFields()) {

            Object prop = field.get(this);

            // フォーム情報を検索
            if (prop instanceof FW01_17_BaseForm) {
                baseForm = (FW01_17_BaseForm) prop;
                break;
            }
        }

        String linkUrl = CM_A04_Const.USER_INFO_URL;

        // パンくずメニュークリア
        CM_HeaderUtil.removeAllBreadCrumbList(this.cM_A03_SessionDto);

        // パンくず先頭にホーム画面をセット
        CM_HeaderUtil.addBreadCrumbList(this.cM_A03_SessionDto, CM_A04_Const.HOME_PAGE_ID);
        CM_HeaderUtil.setReturnInfo(this.cM_A03_SessionDto, CM_A04_Const.HOME_PAGE_ID, CM_A04_Const.HOME_URL, null);

        // 遷移パラメータ作成
        HashMap<String, String> param = new HashMap<String, String>();
        param.put(CM_A04_Const.A500030FORM_HDN_USERSID, Integer.toString(this.cM_A03_SessionDto.ssn_UserSID));
        param.put(CM_A04_Const.A500030FORM_HDN_INFOMODE, CM_A03_InfoAction.MODE_DISP);


        return this.redirectPage(linkUrl, param, baseForm);
    }

    /**
     *
     * ヘッダーのパンくずリストリンク押下の処理.<br>
     *<br>
     * 概要:<br>
     *   押下したパンくずリストの画面へ遷移する
     *<br>
     * @return JSP名
     * @throws IllegalAccessException アクセス権限違反例外
     */
    @Execute(validator = false)
    public String bread_crumb_link_click() throws IllegalAccessException {

        // フォーム情報を取得
        FW01_17_BaseForm baseForm = null;
        for (Field field : this.getClass().getFields()) {

            Object prop = field.get(this);

            // フォーム情報を検索
            if (prop instanceof FW01_17_BaseForm) {
                baseForm = (FW01_17_BaseForm) prop;
                break;
            }
        }

        String linkUrl = CM_A04_Const.HOME_URL;
        // 遷移情報が取得できない場合はホーム画面に遷移
        if (baseForm == null || CM_CommonUtil.isNullOrBlank(baseForm.hdnComHeaderBreadCrumbIndex)) {
            // パンくずメニュークリア
            CM_HeaderUtil.removeAllBreadCrumbList(this.cM_A03_SessionDto);

            return this.redirectPage(linkUrl, new HashMap<String, String>(), new FW01_17_BaseForm());
        }

        // 押下されたパンくずリストのINDEX番号を取得
        String strBreadCrumbIndex = baseForm.hdnComHeaderBreadCrumbIndex;
        int intBreadCrumbIndex = Integer.parseInt(strBreadCrumbIndex);

        // 指定されたパンくずリストが存在しない場合はホーム画面に遷移
        int intListCount = this.cM_A03_SessionDto.ssn_BreadCrumbList.size();
        if (intListCount <= intBreadCrumbIndex) {
            return this.redirectPage(linkUrl, new HashMap<String, String>(), new FW01_17_BaseForm());
        }

        // 対象のパンくずリスト情報を取得
        CM_A07_BreadCrumbDto breadCrumbInfo = this.cM_A03_SessionDto.ssn_BreadCrumbList.get(intBreadCrumbIndex);

        // 遷移先情報作成
        linkUrl = breadCrumbInfo.ssn_ReturnMethod;
        HashMap<String, String> returnDispInfo = new HashMap<String, String>();

        // 遷移先画面以降のパンくずリスト削除
        for (int i = intListCount - 1; i > intBreadCrumbIndex; i--) {
            this.cM_A03_SessionDto.ssn_BreadCrumbList.remove(i);
        }

        // 遷移先画面のリンク情報をクリア
        breadCrumbInfo.ssn_ReturnMethod = FW00_19_Const.EMPTY_STR;

        return this.redirectPage(linkUrl, returnDispInfo, baseForm);
    }

    /**
     *
     * グループツリーデータ取得処理.<br>
     *<br>
     * 概要:<br>
     *   グループツリーデータを取得する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String searchGroupTree() {

        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
        this.groupTreeInfo = mstDataService.getGroupTreeInfoList(this.cM_A03_SessionDto.ssn_UserSID);

        return "../common/com_searchGroupTree.jsp";
    }

    /**
     *
     * ヘッダーメニューのHelpボタン押下の処理.<br>
     *<br>
     * 概要:<br>
     *   マニュアルダウンロードする
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String download_help_click() {

        // ファイルパス取得
        String fileDirectory = CM_A04_Const.MANUAL_DIR;
        // ファイル名取得
        String fileName = CM_A04_Const.MANUAL_FILENAME;

        return super.download(fileName, fileDirectory + fileName);
    }


    /**
     *
     * Action関数権限確認処理.<br>
     *<br>
     * 概要:<br>
     *  Actionクラスの各関数に対する権限を確認する
     *<br>
     * @param _needAuth 対象Actionに必要な権限（1:閲覧権限、2：更新権限）
     * @return チェック結果
     */
    public boolean checkActionAuth(final String _needAuth) {

        String auth = this.cM_A03_SessionDto.getPageAuth(this.nowPageId);

        if (auth.equals(CM_A04_Const.ROLE_AUTH_KIND.DISP_ENABLE) && _needAuth.equals(CM_A04_Const.ROLE_AUTH_KIND.UPDATE_ENABLE)) {
            // 閲覧権限しかないのに、更新権限が必要となるActionが呼ばれた場合
            return false;
        }
        return true;
    }

    /**
     * 削除前チェック処理.
     *
     * @return jsp
     */
    @Execute(validator = false)
    public String checkDelete() {

        // 開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        try {
            // フォーム情報をMapに格納
            BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

            CM_InfoService service = getInfoService();

            this.checkDeleteResult = new CM_CheckDeleteResult();
            service.checkDeleteInfo(formMap, this.checkDeleteResult);

        } catch (FW00_12_BusinessException be) {
            // 例外発生時はエラーメッセージ表示
            return this.alertErrorInfoForAjax(be.getMsgKey(), be.getFocusCtlId());
        } catch (Exception e) {
            // 例外発生時はエラーメッセージ表示
            String strErrorMes = CM_MessageResourceUtil.getMessageValue(this.cM_A03_SessionDto.ssn_CustomerCD,
                    this.cM_A03_SessionDto.ssn_UserLangCD, "MMCMCM00000_006");

            // 例外情報はログ出力
            CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, e);

            return this.alertErrorInfoForAjax(strErrorMes, null);
        }

        // 終了ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, JSP_FILE_NAME_DELETE_CONFIRM);

        return JSP_FILE_NAME_DELETE_CONFIRM;
    }


    /**
     * 各画面のサービスクラス取得.<br>
     *<br>
     * 概要:<br>
     * 各画面のサービスクラスを取得<br>
     *
     * @return 画面のサービスクラス
     */
    protected CM_InfoService getInfoService() {
        return null;
    }

    /**
     * 各画面のフォームクラス取得.<br>
     *<br>
     * 概要:<br>
     * 各画面のフォームクラスを取得<br>
     *
     * @return 画面のフォームクラス
     */
    protected FW01_17_BaseForm getActionForm() {
        return null;
    };


    /**
     *
     * 初期表示.<br>
     *<br>
     * 概要:<br>
     *   初期表示処理を実行する
     *<br>
     * @return JSP名
     */
    protected void init() {
        // 検索条件の設定
        CM_BaseForm form = (CM_BaseForm) this.getActionForm();
        CM_VisualizationBaseService service = this.getInfoService();

        if (CM_CommonUtil.isNotNullOrBlank(form.hdnFavoriteAccessNo)) {
            // お気に入りからの遷移の場合
            // 検索条件取得
            List<TrSearchConditionEntity> searchConditionList = service.getRegisterSearchCondition(this.getPageId(), form.hdnFavoriteAccessNo);

            if (CM_CommonUtil.isNotNullOrEmpty(searchConditionList)) {
                // 検索条件が登録されている場合
                this.setParamRegisterSearchCondition(searchConditionList);
            }
        }
    }

    /**
     *
     * 登録検索条件の設定処理.<br>
     *<br>
     * 概要:<br>
     *   登録検索条件の設定処理
     *<br>
     * @param _searchConditionList 登録検索条件一覧
     */
    private void setParamRegisterSearchCondition(final List<TrSearchConditionEntity> _searchConditionList) {
        for (TrSearchConditionEntity entity : _searchConditionList) {
            try {
                Field field = this.getActionForm().getClass().getField(entity.paramName);
                field.setAccessible(true);
                // フィールドの型を判定
                if (field.getGenericType() instanceof ParameterizedType) {
                    // リスト形式の場合
                    @SuppressWarnings("unchecked")
                    List<String> object = (List<String>) field.get(this.getActionForm());
                    if (CM_CommonUtil.isNullOrEmpty(object)) {
                        object = new ArrayList<String>();
                    }
                    object.add(entity.paramValue);
                    field.set(this.getActionForm(), object);
                } else if (field.getType().isArray()) {
                    // 配列型の場合
                    String[] object = (String[]) field.get(this.getActionForm());
                    if (CM_CommonUtil.isNullOrBlank(object)) {
                        object = new String[]{};
                    }
                    List<String> tmp = new ArrayList<String>(Arrays.asList(object));
                    tmp.add(entity.paramValue);
                    field.set(this.getActionForm(), tmp.toArray(new String[tmp.size()]));
                } else {
                    field.set(this.getActionForm(), entity.paramValue);
                }


            } catch (NoSuchFieldException | IllegalAccessException e) {
                // ログ出力のみ
                CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, e);
            }

        }
    }

    /**
     * お気に入り情報取得.
     */
    private void loadFavoriteInfo() {
        // お気に入り登録可能判断
        this.checkFavoriteSaveAvail();

        List<BeanMap> favoriteList = this.getInfoService().getFavoriteList();
        if (favoriteList != null && !favoriteList.isEmpty()) {
            Integer topFavoriteNo = (Integer) favoriteList.get(0).get(TrSearchConditionEntityNames.favoriteNo().toString());
            if (topFavoriteNo == 0) {
                // TOPページは分離
                this.favoriteTop = favoriteList.get(0);
                favoriteList.remove(0);
            }
            this.favoriteListMap.clear();
            for (BeanMap data : favoriteList) {
                Integer favoriteNo = (Integer) data.get(TrSearchConditionEntityNames.favoriteNo().toString());
                this.favoriteListMap.put(favoriteNo, data);
            }
        }
    }

    /**
     * お気に入り登録可能かどうかを判断.
     */
    private void checkFavoriteSaveAvail() {
        CM_VisualizationBaseService service = this.getInfoService();
        // 画面URL定義が存在することを確認
        String pageUrlStr = service.getPageUrlStr(this.getPageId());
        if (CM_CommonUtil.isNotNullOrBlank(pageUrlStr)) {
            this.favoriteSaveAvail = true;
        }
    }

    /**
     *
     * 検索条件保存処理.<br>
     *<br>
     * 概要:<br>
     *
     *<br>
     * @return jsp
     */
    @Execute(validator = false)
    public String registerFavorite() {
         // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        CM_VisualizationBaseService service = this.getInfoService();

        // 処理開始
        service.init(this.cM_A03_SessionDto);

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        // 検索条件チェック処理
        try {
            this.getInfoService().checkRegisterSearchCondition(formMap);
        } catch (FW00_12_BusinessException be) {
            this.alertErrorInfoForAjax(be.getMsgKey(), be.getFocusCtlId());
        }

        // 検索条件登録処理
        service.registerSearchCondition(formMap, this.getPageId());

        // お気に入り情報取得
        this.loadFavoriteInfo();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, COM_FAVORITE_AREA_JSP);

        return COM_FAVORITE_AREA_JSP;
    }

    /**
     * お気に入り削除.<br>
     *<br>
     * 概要:<br>
     *   お気に入りを削除する。
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String deleteFavorite() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        CM_VisualizationBaseService service = this.getInfoService();

        // 処理開始
        service.init(this.cM_A03_SessionDto);

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        // お気に入り削除処理
        service.deleteFavorite(formMap);

        // お気に入り情報取得
        this.loadFavoriteInfo();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, COM_FAVORITE_AREA_JSP);

        return COM_FAVORITE_AREA_JSP;
    }

    /**
     * 画面のページ情報を取得.<br>
     * <br>
     * 概要:<br>
     * 各画面のページ情報を取得<br>
     * 各画面のアクションで実装し、ページ情報を設定する
     *
     * @return 画面のページID
     */
    protected CM_A05_PageInfo getPageInfo() {
        return null;
    }

    /**
     * 画面のページIDを取得.<br>
     * <br>
     * 概要:<br>
     * 各画面のページIDを取得<br>
     * 各画面のアクションで実装し、ページIDを設定する
     *
     * @return 画面のページID
     */
    protected String getPageId() {
        return this.getPageInfo().getPageId();
    };

    /**
    *
    * 共通設定.<br>
    *<br>
    * 概要:<br>
    *   共通設定処理を行う
    *<br>
    */
    protected void commonSetting() {

        // お気に入り情報取得
        if (this.favoriteListMap == null || this.favoriteListMap.isEmpty()) {
            this.loadFavoriteInfo();
        }
    }

   /**
    * ヘッダ警告メッセージ取得.
    * @return 警告メッセージ
    */
    public String getHeaderAlertMessage() {
       // フォーム情報保存
       BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);

        // 警告メッセージ取得
        return mstDataService.getAlertMessage(formMap);
    }
}
