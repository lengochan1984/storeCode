/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/01| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.excel;

import jp.ysk.mmcloud.visualization.common.CM_A07_ExcelCellType;

/**
 *
 * Cellデータフォーマット情報.<br>
 *<br>
 * 概要:<br>
 *   Cellデータのフォーマット情報
 *<br>
 */
public class CM_ExcelDataInfoDto implements Cloneable {

    /**
     * データ取得キー.
     */
    private String key;

    /**
     * 凡例名.
     * 凡例名のdispCharのメッセージCDを設定.
     */
    private String legendName;

    /**
     * Cellのデータ形式.
     * デフォルト:数値
     */
    private int cellType = CM_A07_ExcelCellType.CELL_TYPE_NUMERIC;

    /**
     * データ取得キーを取得.
     *
     * @return データ取得キー
     */
    public String getKey() {
        return this.key;
    }

    /**
     * データ取得キーを設定する.
     *
     * @param _key データ取得キー
     */
    public void setKey(final String _key) {
        this.key = _key;
    }

    /**
     * 凡例名を取得.
     *
     * @return 凡例名
     */
    public String getLegendName() {
        return this.legendName;
    }

    /**
     * 凡例名を設定する.
     *
     * @param _legendName 凡例名
     */
    public void setLegendName(final String _legendName) {
        this.legendName = _legendName;
    }

    /**
     * Cellのデータ形式を取得.
     *
     * @return Cellのデータ形式
     */
    public int getCellType() {
        return this.cellType;
    }

    /**
     * Cellのデータ形式を設定する.
     *
     * @param _cellType Cellのデータ形式
     */
    public void setCellType(final int _cellType) {
        this.cellType = _cellType;
    }

    @Override
    public CM_ExcelDataInfoDto clone() {
        try {
            return (CM_ExcelDataInfoDto) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new InternalError(e.toString());
        }
    }
}
