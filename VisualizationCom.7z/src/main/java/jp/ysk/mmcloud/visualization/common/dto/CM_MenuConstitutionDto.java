/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/04/07| <C1.01>　新規作成                                                    | C1.01  | (YSK)三村
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * CM_MenuConstitutionDtoクラス.
 *
 */
public class CM_MenuConstitutionDto {

    /**
     * 構成名称.
     */
    public String functionName;

    /**
     * メニュー構成データリスト.
     */
    public List<CM_PageAuthInfoDto> menuItemList = new ArrayList<CM_PageAuthInfoDto>();
}
