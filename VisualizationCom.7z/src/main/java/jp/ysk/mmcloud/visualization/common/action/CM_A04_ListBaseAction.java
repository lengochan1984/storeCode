/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/07/28| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 *  2017/06/22| <C1.02>　[課題管理表No.2]CSV10万件出力、総件数表示対応   | C1.02  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.action;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import jp.ysk.fw.FW00_12_AppException;
import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.csv.FW01_10_CSVFormat;
import jp.ysk.fw.csv.FW01_10_CSVWriter;
import jp.ysk.fw.form.FW01_14_ListForm;
import jp.ysk.fw.form.FW01_17_BaseForm;
import jp.ysk.fw.util.FW00_06_MessageResourceUtil;
import jp.ysk.fw.util.FW00_11_UrlEncodeUtil;
import jp.ysk.fw.util.FW01_03_CreateSingleSelectTagUtil;
import jp.ysk.mmcloud.common.csv.CM_Csv_Upload_Result;
import jp.ysk.mmcloud.common.dto.CM_A08_ComDetailSearchItemDto;
import jp.ysk.mmcloud.common.entity.customer.MstModelEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstNameEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstRoleEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstUserEntityNames;
import jp.ysk.mmcloud.common.entity.customer.SysEnvEntityNames;
import jp.ysk.mmcloud.common.entity.customer.SysNameEntityNames;
import jp.ysk.mmcloud.common.util.CM_ComDetailSearchUtil;
import jp.ysk.mmcloud.common.util.CM_DisplayCharResourceUtil;
import jp.ysk.mmcloud.common.util.CM_HeaderUtil;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.common.util.CM_MessageResourceUtil;
import jp.ysk.mmcloud.common.util.CM_MstNameDataUtil;
import jp.ysk.mmcloud.common.util.CM_SysEnvDataUtil;
import jp.ysk.mmcloud.common.util.CM_SysNameDataUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.CM_A07_ExcelCellType;
import jp.ysk.mmcloud.visualization.common.csv.CM_CsvUtil;
import jp.ysk.mmcloud.visualization.common.csv.CM_Csv_Const;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantMierukaEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSearchConditionEntity;
import jp.ysk.mmcloud.visualization.common.excel.CM_ExcelDataInfoDto;
import jp.ysk.mmcloud.visualization.common.excel.CM_ExcelFormat;
import jp.ysk.mmcloud.visualization.common.excel.CM_ExcelSheetInfoDto;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;
import jp.ysk.mmcloud.visualization.common.form.CM_ListForm;
import jp.ysk.mmcloud.visualization.common.service.CM_GetMstDataService;
import jp.ysk.mmcloud.visualization.common.service.CM_ListBaseService;
import jp.ysk.mmcloud.visualization.common.service.CM_TopHeaderService;
import jp.ysk.mmcloud.visualization.common.service.CM_VisualizationBaseService;
import jp.ysk.mmcloud.visualization.common.util.CM_CodeUtil;
import jp.ysk.mmcloud.visualization.common.util.CM_CommonUtil;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.struts.upload.FormFile;
import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.beans.util.Beans;
import org.seasar.framework.exception.SQLRuntimeException;
import org.seasar.struts.annotation.Execute;

/**
 *
 * 一覧がある基底クラスの共通Action.<br>
 *<br>
 * 概要:<br>
 *  一覧がある基底クラスの共通Actionクラス
 *
 *<br>
 */
public abstract class CM_A04_ListBaseAction extends CM_A01_BaseAction {

    /**
     * 遷移先画面情報.<br>
     * value:ページID
     */
    protected Map<String, String> nextPageInfoMap = new HashMap<String, String>();

    /**
     * 遷移先権限情報.<br>
     */
    public Map<String, Boolean> nextAuthInfo = new HashMap<String, Boolean>();

    /**
     * CSV出力上限値チェック結果(true:上限エラー、false:上限内).
     */
    public String csvLimitError = "false";
    /**
     * CSV出力上限値.
     */
    public String csvLimitNum = "3";

    /**
     * CSV出力上限値オーバーメッセージパラメータ.
     */
    public String csvLimitErrorMsgParam = "";

//    /**
//     * CSVデータ件数上限.
//     */
//    public static final long CSV_DATA_MAX = 100000;

    /**
     * SQLエラーメッセージCD.
     */
    private String strSqlErrorMsgCd = "MMCMCM00000_302";

    /**
     * 画像取得用メソッド名.<BR>
     * ※アラームアイコン取得用
     */
    public static final String ICON_IMAGE_DOWNLOAD_METHOD_NAME = "downloadMapIconImage";

    /**
     *アップロード結果.
     */
    public CM_Csv_Upload_Result csvUploadResult;

    /**
     * 一覧データソートキー名マップ.
     */
    public BeanMap sortKeyNameMap = null;

    /**
     * 一覧表示データリスト　表示用(JSP表示情報).
     */
    public List<?> listData = null;

    /**
     * ページ数.
     */
    public static final String OFFSET_INFO_DISP_PAGE = "intDispPage";

    /**
     * 指定ページに表示するデータ数.
     */
    public static final String OFFSET_INFO_LIMIT_CNT = "intLimitCnt";

    /**
     * 一覧ヘッダ.
     */
    public List<Map<String, String>> fw0110ListHeader;

    /**
     * 検索結果表示上限.
     */
    public Long searchResultMax = null;

    /**
     * 詳細検索条件項目の復帰用情報.
     */
    public HashMap<String, Object> itemRestoreInfoMap;

    /**
     * 詳細検索の検索項目セパレータ.
     */
    public static final String DETAIL_SEARCH_ITEM_SEP = "#condsp#";

    /**
     * 詳細検索の検索内容セパレータ.
     */
    public static final String DETAIL_SEARCH_COND_SEP = "#chsp#";

    /**
     * 詳細検索の検索条件IDヘッダ.
     */
    public static final String[] DETAIL_SEARCH_COND_HEADER_LIST = {"cond_", "_from", "_to", "_hour", "_minute"};

    /**
     * 検索条件項目選択リスト情報のコード.
     */
    public static final String ITEM_SELECT_LSIT_INFO_CODE = "code";

    /**
     * 検索条件項目選択リスト情報の名称.
     */
    public static final String ITEM_SELECT_LSIT_INFO_NAME = "name";

    /**
     * 検索件数情報.
     */
    public  String searchCountInfo = FW00_19_Const.EMPTY_STR;

    /**
     * 1件もデータが存在しない場合.
     */
    public String fw0110NoneDataMsg;

    /**
     * .
     */
    public String fw0110AllSize;

    /**
     * 表示件数プルダウンリスト.
     */
    public List<Map<String, String>> fw0110DispCntList;

    /**
     * .
     */
    private static String envCodeListDispCount = "list_disp_count";

    /**
     * 一覧総データ数.
     */
    public static final String OFFSET_INFO_LIST_CNT = "intListCnt";

    /**
     * 全ページ数.
     */
    public String fw0110AllPageCnt;

    /**
     * 詳細検索条件項目選択リスト情報.
     */
    public BeanMap itemSelectListInfoMap;

    /**
     * 詳細検索条件項目リスト情報.
     */
    public List<BeanMap> itemList;

    /**
     * 更新タイミングプルダウン 表示用(JSP表示情報).
     */
    public  List<Map<String, String>> pldUpdateTimingList = null;

    /**
     * Ecel出力チェック処理返却JSP.
     */
    protected static final String CHECK_EXPORT_EXCEL_RESULT = "../common/com_checkExportExcelResult.jsp";

    /**
     * 検索条件登録結果返却JSP.
     */
    protected static final String REGISTER_SEARCH_CONDITION_RESULT = "../common/com_registerSearchConditionResult.jsp";

    /**
     * Excel出力用検索条件のラベル名Mapキー.<br>
     */
    protected static final String MAP_KEY_EXPORT_EXCEL_SEARCH_CONDITION_NAME = "searchConditionName";

    /**
     * Excel出力用検索条件の検索値Mapキー.<br>
     */
    protected static final String MAP_KEY_EXPORT_EXCEL_SEARCH_CONDITION_VALUE = "searchConditionValue";

    /**
     *
     * 初期表示.<br>
     *<br>
     * 概要:<br>
     *   初期表示処理を実行する
     *<br>
     * @return JSP名
     */
    @Override
    protected String init() {
        // 次画面に対する権限取得
        this.getNextPageAuth();

        // 検索条件の設定
        CM_ListForm form = this.getActionForm();

        if (CM_A04_Const.FLG.ON.equals(form.hdnTransferFlag)) {
            // 画面遷移フラグが設定されている場合、フォームの値をそのまま使用

            // リダイレクトパラメータロード
            this.initComSearchInfo(true);

        } else {
            // 検索条件取得
            List<TrSearchConditionEntity> searchConditionList = null;
            if (CM_CommonUtil.isNotNullOrBlank(form.hdnFavoriteAccessNo)) {
                // お気に入りからの遷移の場合
                searchConditionList
                    = this.getService().getRegisterSearchCondition(this.getPageId(), form.hdnFavoriteAccessNo);
            }

            if (CM_CommonUtil.isNotNullOrEmpty(searchConditionList)) {
                // 検索条件が登録されている場合
                this.setParamRegisterSearchCondition(searchConditionList);
            } else {
                // 検索条件が登録されていない場合、ユーザの工場コードを設定
                this.initComSearchInfo(false);
            }
        }

        // 工場マスタ(見える化専用)の取得
        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
        MaPlantEntity plant = mstDataService.getMaPlantEntity(form.comPlantCode);

        // 開始年月日と開始時間をセット
        if (plant != null) {
            form.plantStartDate = (new SimpleDateFormat(CM_A04_Const.DATE_FORMAT_SEC_HYPHEN).format(plant.runningStartDatetime));
        } else {
            form.plantStartDate = CM_A04_Const.DEFAULT_RUNNING_START_DATETIME;
        }

        // 検索領域の情報をセット
        this.initDetailSearchDisplayInfo(this.getPageId());

        return this.getJspFileName();
    }

    /**
     *
     * 次画面権限取得処理.<br>
     *<br>
     * 概要:<br>
     *  次画面に対する変更権限の有無を取得する
     *<br>
     * @return
     */
    protected void getNextPageAuth() {

        String nextPageId = this.getNextPageId();
        // 情報画面参照権限確認
        this.enableInfoDisp = this.checkHasDispPageAuth(nextPageId);
        // 情報画面更新権限確認
        this.enableInfoChange = this.checkHasUpdatePageAuth(nextPageId);

        // 情報画面以外の遷移先パラメータ設定
        this.setNextPageInfo();
        for (Entry<String, String> nextPageInfo : this.nextPageInfoMap.entrySet()) {
            this.nextAuthInfo.put(nextPageInfo.getKey(), this.checkHasDispPageAuth(nextPageInfo.getValue()));
        }

        // 次画面権限設定後処理
        this.afterCheckPageAuth();
    }

    /**
     *
     * 次画面ページID取得.<br>
     *<br>
     * 概要:<br>
     * 次画面ページIDを取得
     *<br>
     * @return 次画面ページID
     */
    protected String getNextPageId() {
        String nextPageId = null;
        if (CM_CommonUtil.isNotNullOrBlank(this.getNextPageInfo())) {
            nextPageId = this.getNextPageInfo().getPageId();
        }
        return nextPageId;
    }

//    /**
//     *
//     * 次画面ページ情報取得.<br>
//     *<br>
//     * 概要:<br>
//     * 次画面ページ情報を取得
//     *<br>
//     * @return 次画面ページ情報
//     */
//    protected CM_A05_PageInfo getNextPageInfo() {
//        return null;
//    };

    /**
     *
     * ページの参照権限チェック.<br>
     *<br>
     * 概要:<br>
     *   ページに参照権限があるかのチェック
     *<br>
     * @param _pageId ページID
     * @return 参照権限有無
     */
    protected boolean checkHasDispPageAuth(final String _pageId) {

        boolean ret = false;
        if (CM_CommonUtil.isNotNullOrBlank(_pageId)) {
            String auth = this.cM_A03_SessionDto.getPageAuth(_pageId);

            switch (auth) {
                case CM_A04_Const.ROLE_AUTH_KIND.UPDATE_ENABLE:
                case CM_A04_Const.ROLE_AUTH_KIND.DISP_ENABLE:
                    // 更新可能または閲覧可能の場合
                    ret = true;
                    break;

                case CM_A04_Const.ROLE_AUTH_KIND.NONE:
                default:
                    // 権限なしの場合

                    ret = false;
                    break;
            }
        }
        return ret;
    }

    /**
     *
     * ページの更新権限チェック.<br>
     *<br>
     * 概要:<br>
     *   ページに更新権限があるかのチェック
     *<br>
     * @param _pageId ページID
     * @return 更新権限有無
     */
    protected boolean checkHasUpdatePageAuth(final String _pageId) {

        boolean ret = false;
        if (CM_CommonUtil.isNotNullOrBlank(_pageId)) {
            String auth = this.cM_A03_SessionDto.getPageAuth(_pageId);

            switch (auth) {
                case CM_A04_Const.ROLE_AUTH_KIND.UPDATE_ENABLE:
                    // 更新可能の場合
                    ret = true;
                    break;

                case CM_A04_Const.ROLE_AUTH_KIND.NONE:
                case CM_A04_Const.ROLE_AUTH_KIND.DISP_ENABLE:
                default:
                    // 権限なしの場合

                    ret = false;
                    break;
            }
        }
        return ret;
    }

    /**
     *
     * 次画面情報設定処理.<br>
     *<br>
     * 概要:<br>
     *  遷移先の情報を設定
     *<br>
     */
    protected void setNextPageInfo() {
        return;
    };

    /**
     *
     * 次画面権限設定後処理.<br>
     *<br>
     * 概要:<br>
     *   次画面権限設定後処理
     *<br>
     */
    protected void afterCheckPageAuth() {
        return;
    }

    /**
     *
     * 更新タイミングリスト情報を取得する.<br>
     *<br>
     * 概要:<br>
     *   更新タイミングリストに表示する項目を取得する。
     *<br>
     * @return getData 更新タイミングリスト
     */
    protected List<Map<String, String>> getUpdateTimingList() {

        List<BeanMap> map = null;
        FW01_03_CreateSingleSelectTagUtil fw0103Util = null;

        map = CM_SysNameDataUtil.getNameList(this.cM_A03_SessionDto,
                CM_A04_Const.SYS_ENV_MST_ENV_CD.UPDATETIMEM, this.cM_A03_SessionDto.ssn_UserLangCD);

        fw0103Util = new FW01_03_CreateSingleSelectTagUtil(
                SysNameEntityNames.itemCd().toString(),
                SysNameEntityNames.name1().toString(),
                SysNameEntityNames.defaultFlag().toString(),
                map,
                -1);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 一覧画面復帰処理.<br>
     *<br>
     * 概要:<br>
     *  一覧画面に復帰する。
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String returnPage() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        CM_ListForm form = this.getActionForm();

        // 検索領域の情報をセット
        this.initDetailSearchDisplayInfo(this.getPageId());

        // 共通ヘッダのデータセット
        CM_TopHeaderService s000050TopHeaderService = new CM_TopHeaderService();
        this.mapTopHeader = s000050TopHeaderService.getHeaderData(this.cM_A03_SessionDto, form);

        // 画面サービス初期化
        this.getService().init(this.cM_A03_SessionDto);

        // 画面情報の復帰処理
        HashMap<String, Object> returnDispInfo = CM_HeaderUtil.getReturnInfo(cM_A03_SessionDto, this.getPageId());
        if (returnDispInfo == null) {
            returnDispInfo = new HashMap<String, Object>();
        }

        // 次画面に対する権限取得
        this.getNextPageAuth();

        if (returnDispInfo != null) {
            // 画面個別のデータ復帰処理
            this.returnPageResult(returnDispInfo);
            // 画面共通のデータ復帰処理
            this.setReturnDispInfo(returnDispInfo);
        }

        // 共通ヘッダパンくずリストの再登録（復帰用データ削除のため）
        CM_HeaderUtil.addBreadCrumbList(this.cM_A03_SessionDto, this.getPageId());

        // 表示処理
        String ret = this.display();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, ret);

        return ret;
    }
    /**
     *
     * 遷移前データ復帰処理.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _data 遷移前データ
     */
    protected void setReturnDispInfo(final HashMap<String, Object> _data) {
        CM_ListForm actionForm = this.getActionForm();
        // ページング関連情報の復帰
        if (!CM_CommonUtil.isNullOrBlank(_data.get(CM_ListForm.FW0114FORM_PAGENO))) {
            actionForm.fw0114PageNo = _data.get(CM_ListForm.FW0114FORM_PAGENO).toString();
        }
        if (!CM_CommonUtil.isNullOrBlank(_data.get(CM_ListForm.FW0114FORM_SORTKEY))) {
            actionForm.fw0114SortKey = _data.get(CM_ListForm.FW0114FORM_SORTKEY).toString();
        }
        if (!CM_CommonUtil.isNullOrBlank(_data.get(CM_ListForm.FW0114FORM_SORTORDER))) {
            actionForm.fw0114SortOrder = _data.get(CM_ListForm.FW0114FORM_SORTORDER).toString();
        }
        if (!CM_CommonUtil.isNullOrBlank(_data.get(CM_ListForm.FW0114FORM_LISTSIZE))) {
            actionForm.fw0114ListSize =  _data.get(CM_ListForm.FW0114FORM_LISTSIZE).toString();
        }

        // 詳細検索条件の復帰
        if (!CM_CommonUtil.isNullOrBlank(_data.get(FW01_17_BaseForm.CM_HDN_COM_DETAIL_SEARCH_COND))) {
            actionForm.hdnComDetailSearchCond = _data.get(FW01_17_BaseForm.CM_HDN_COM_DETAIL_SEARCH_COND).toString();
        }
        if (!CM_CommonUtil.isNullOrBlank(_data.get(FW01_17_BaseForm.CM_HDN_COM_DETAIL_SEARCH_COND_FOR_SORT))) {
            actionForm.hdnComDetailSearchCondForSort = _data.get(FW01_17_BaseForm.CM_HDN_COM_DETAIL_SEARCH_COND_FOR_SORT).toString();
        }
    }

    /**
     * CSVデータ数カウントチェック.
     * @param _count カウント数
     * @return カウントチェック結果(チェックOK：null, チェックNG：エラーページ情報)
     */
    protected String checkCsvCount(final long _count) {
        // CSV上限件数
    	long csvMaxLimit = CM_CsvUtil.getCsvMaxExportCnt(this.cM_A03_SessionDto);

        if (_count > csvMaxLimit) {
            this.csvLimitError = "true";
            this.csvLimitNum = String.valueOf(csvMaxLimit);
            this.csvLimitErrorMsgParam = String.valueOf(csvMaxLimit) + "," + String.valueOf(_count);
        }

        return "/FW01_20_WarningCsv.jsp";
    }

    /**
     * 部分データリスト取得.<br>
     *<br>
     * 概要:<br>
     *   出力可能なデータ数以上のデータを切り取ったデータリストを返す
     *<br>
     * @param _dataList 元データリスト
     * @return 上限内データリスト
     */
    protected List<List<String[]>> getLimitCutList(final List<List<String>> _dataList) {
        // CSV上限件数
    	long csvMaxLimit = CM_CsvUtil.getCsvMaxExportCnt(this.cM_A03_SessionDto);

        List<List<String[]>> dataStrList = new ArrayList<List<String[]>>();
        List<String[]> tmpDataList = new ArrayList<String[]>();
        for (int i = 0; i < _dataList.size(); i++) {
            if (i >= csvMaxLimit) {
                break;
            }
            List<String> csvDataList = _dataList.get(i);
            tmpDataList.add(csvDataList.toArray(new String[0]));
        }
        dataStrList.add(tmpDataList);
        return dataStrList;
    }

    /**
     * CSVダウンロード.
     * @param _csvFormat CSVフォーマットクラス
     * @return null値
     */
    protected String downloadCsv(final FW01_10_CSVFormat _csvFormat) {
        return this.downloadCsv(null, _csvFormat);
    }

    /**
     * CSVダウンロード(ファイル名指定).
     * @param _fileName ファイル名
     * @param _csvFormat CSVフォーマット
     * @return null値
     */
    protected String downloadCsv(final String _fileName, final FW01_10_CSVFormat _csvFormat) {

        List<String[]> headerStrList = new ArrayList<String[]>();
        List<List<String[]>> dataStrList = new ArrayList<List<String[]>>();

        for (String areaKey : _csvFormat.getAreaKeyList()) {

            List<String> headerList = new ArrayList<String>();
            for (String headerStr : _csvFormat.getHeaderInfo(areaKey)) {
                // ヘッダ用文字列をリソースから取得する
                headerList.add(CM_DisplayCharResourceUtil.getDisplayCharValue(
                        this.cM_A03_SessionDto.ssn_CustomerCD, this.cM_A03_SessionDto.ssn_UserLangCD, headerStr));
            }
            headerStrList.add((String[]) headerList.toArray(new String[0]));
            dataStrList.add(_csvFormat.getDataInfo(areaKey));
        }

        _csvFormat.clear();

        return this.downloadCsvCommon(_fileName, headerStrList, dataStrList);
    }

    /**
     * CSVダウンロード(ファイル名指定).
     * @param _fileName ファイル名
     * @param _dateStr ヘッダ用更新日時文字列
     * @param _csvFormat CSVフォーマット
     * @return null値
     */
    protected String downloadCsv(final String _fileName, final String _dateStr, final FW01_10_CSVFormat _csvFormat) {

        List<String[]> headerStrList = new ArrayList<String[]>();
        List<List<String[]>> dataStrList = new ArrayList<List<String[]>>();

        // infoArea
        List<Map<String, String>> infoAreaDataList = new ArrayList<Map<String, String>>();
        Map<String, String> infoAreaMap = new HashMap<String, String>();

        // ファイル名
        infoAreaMap.put("name", _fileName);
        // 出力日時
        infoAreaMap.put("date", _dateStr);
        // バージョン
        infoAreaMap.put("version", CM_HeaderUtil.getDisplaySystemVersion());

        infoAreaDataList.add(infoAreaMap);
        _csvFormat.putDataInfoList(CM_Csv_Const.AREA_KEY_INFO_AREA, infoAreaDataList);

        // 検索条件の設定
        this.setCsvSearchAreaData(_csvFormat);

        String legendName = "";
        for (String areaKey : _csvFormat.getAreaKeyList()) {

            List<String> headerList = new ArrayList<String>();
            for (String headerStr : _csvFormat.getHeaderInfo(areaKey)) {

                // ヘッダ用文字列をリソースから取得する
                legendName = CM_DisplayCharResourceUtil.getDisplayCharValue(
                            this.cM_A03_SessionDto.ssn_CustomerCD, this.cM_A03_SessionDto.ssn_UserLangCD, headerStr);
                if (CM_CommonUtil.isNullOrBlank(legendName)) {
                    legendName = headerStr;
                }
                headerList.add(legendName);
            }
            headerStrList.add((String[]) headerList.toArray(new String[0]));
            dataStrList.add(_csvFormat.getDataInfo(areaKey));
        }

        _csvFormat.clear();

        return this.downloadCsvCommon(_fileName, headerStrList, dataStrList);
    }

    /**
     * CSVダウンロード(ファイル名指定).
     * @param _fileName ファイル名
     * @param _dateStr ヘッダ用更新日時文字列
     * @param _headerList ヘッダーリスト
     * @param_dataList データリスト
     * @param _csvFormat CSVフォーマット
     * @return null値
     */
    protected String downloadCsv(final String _fileName,
            final String _dateStr,
            final List<String[]> _headerList,
            final List<List<String[]>> _dataList,
            final FW01_10_CSVFormat _csvFormat) {

        List<String[]> headerStrList = new ArrayList<String[]>();
        List<List<String[]>> dataStrList = new ArrayList<List<String[]>>();

        List<Map<String, String>> infoAreaDataList = new ArrayList<Map<String, String>>();
        Map<String, String> infoAreaMap = new HashMap<String, String>();
        infoAreaMap.put("name", _fileName);
        infoAreaMap.put("date", _dateStr);
        infoAreaMap.put("version", CM_HeaderUtil.getDisplaySystemVersion());
        infoAreaDataList.add(infoAreaMap);
        _csvFormat.putDataInfoList("infoArea", infoAreaDataList);

        String areaKey = "infoArea";

        List<String> headerList = new ArrayList<String>();
        for (String headerStr : _csvFormat.getHeaderInfo(areaKey)) {
            // ヘッダ用文字列をリソースから取得する
            headerList.add(CM_DisplayCharResourceUtil.getDisplayCharValue(
                    this.cM_A03_SessionDto.ssn_CustomerCD, this.cM_A03_SessionDto.ssn_UserLangCD, headerStr));
        }
        headerStrList.add((String[]) headerList.toArray(new String[0]));
        dataStrList.add(_csvFormat.getDataInfo(areaKey));

        _csvFormat.clear();

        for (int i = 0; i < _headerList.size(); i++) {
            headerStrList.add(_headerList.get(i));
            dataStrList.add(_dataList.get(i));
        }

        return this.downloadCsvCommon(_fileName, headerStrList, dataStrList);
    }

    /**
     * CSVダウンロード共通処理.
     * @param _fileName ファイル名
     * @param _headerList ヘッダリスト
     * @param _dataList データリスト
     * @return null値
     */
    protected String downloadCsvCommon(
            final String _fileName,
            final List<String[]> _headerList,
            final List<List<String[]>> _dataList) {

        if (_headerList.size() != _dataList.size()) {
            return null;
        }

        ServletOutputStream out = null;
        FW01_10_CSVWriter outCsv = null;

        try {
            if (_fileName != null && !_fileName.equals(FW00_19_Const.EMPTY_STR)) {
                String encordName = FW00_11_UrlEncodeUtil.getUrlEncode(_fileName);
                this.response.setContentType("application/octet-stream");
                this.response.setHeader("Content-Disposition", "attachment; filename=\"" + encordName + "\"");
            } else {
                this.response.setContentType("application/octet-stream");
                this.response.setHeader("Content-Disposition", "attachment");
            }
            this.response.setHeader("Cache-Control", "private");
            this.response.setHeader("Pragma", "private");

            out = this.response.getOutputStream();
            outCsv = new FW01_10_CSVWriter(out);

            for (int i = 0; i < _headerList.size(); i++) {
                outCsv.writeHeader(_headerList.get(i));
                outCsv.writeData(_dataList.get(i));
            }
        } catch (IOException e) {
            this.response.reset();
            this.response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            throw new FW00_12_AppException(e);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (outCsv != null) {
                try {
                    outCsv.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return null;
    }

    /**
     *
     * CSV検索条件データ設定処理.<br>
     *<br>
     * 概要:<br>
     * CSVで出力する検索条件の値をCSVフォーマット情報クラスに設定する
     *<br>
     * @param _csvFormat CSVフォーマット情報クラス
     */
    protected void setCsvSearchAreaData(final FW01_10_CSVFormat _csvFormat) {

        if (CM_CommonUtil.isNotNullOrBlank(_csvFormat.getHeader(CM_Csv_Const.AREA_KEY_COM_SEARCH_AREA))) {
            // フォーマットに共通検索条件の項目がある場合に設定
            List<Map<String, String>> comSearchAreaDataList = new ArrayList<Map<String, String>>();

            // 検索条件エリア共通項目
            CM_GetMstDataService mds = new CM_GetMstDataService(this.cM_A03_SessionDto);
            Map<String, String> comSearchAreaMap = new HashMap<String, String>();
            CM_BaseForm form = this.getActionForm();

            // 工場
            String strPlant = CM_CodeUtil.getTextOfMapList(mds.getPhysicalPlantPld(), form.comPlantCode);
            if (CM_CommonUtil.isNullOrBlank(strPlant)) {
                strPlant = "";
            }
            comSearchAreaMap.put("comPlant", strPlant.trim());

            // 製造ライン
            String strSeizouLine = CM_CodeUtil.getTextOfMapList(mds.getMstSeizouLinePld(form.comPlantCode, true), form.comSeizouLnId);
            if (CM_CommonUtil.isNullOrBlank(strSeizouLine)) {
                strSeizouLine = "";
            }
            comSearchAreaMap.put("comSeizouLine", strSeizouLine.trim());

            // 工程
            String strProcess = CM_CodeUtil.getTextOfMapList(mds.getMstProcessPld(form.comPlantCode, form.comSeizouLnId, true), form.comProcessId);
            if (CM_CommonUtil.isNullOrBlank(strProcess)) {
                strProcess = "";
            }
            comSearchAreaMap.put("comProcess", strProcess.trim());

            // ライン
            String strLine = CM_CodeUtil.getTextOfMapList(mds.getLinePld(form.comPlantCode, form.comSeizouLnId, form.comProcessId, true), form.comLnId);
            if (CM_CommonUtil.isNullOrBlank(strLine)) {
                strLine = "";
            }
            comSearchAreaMap.put("comLine", strLine.trim());

            // ステーション
            String strSt = CM_CodeUtil.getTextOfMapList(mds.getMstStationPld(form.comPlantCode, form.comSeizouLnId, form.comProcessId, form.comLnId, true), form.comStId);
            if (CM_CommonUtil.isNullOrBlank(strSt)) {
                strSt = "";
            }
            comSearchAreaMap.put("comSt", strSt.trim());

            // 検索日時
            if (CM_CommonUtil.isNotNullOrBlank(form.comDataDateDisp)) {
                comSearchAreaMap.put("comDataDate", form.comDataDateDisp);
            }
            else {
                // 今日を取得
                Calendar cal = Calendar.getInstance();
                SimpleDateFormat sdf = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT_FOR_DISP);
                comSearchAreaMap.put("comDataDate", sdf.format(cal.getTime()));
            }

            // 検索日時(From)
            if (CM_CommonUtil.isNotNullOrBlank(form.comDataDateFromCsvDisp)) {
                comSearchAreaMap.put("comDataDateFrom", form.comDataDateFromCsvDisp);
            }

            // 検索日時(To)
            if (CM_CommonUtil.isNotNullOrBlank(form.comDataDateToCsvDisp)) {
                comSearchAreaMap.put("comDataDateTo", form.comDataDateToCsvDisp);
            }

            // 検索ワード
            String strSearchWord = form.comSearchWord;
            if (CM_CommonUtil.isNullOrBlank(strSearchWord)) {
                strSearchWord = "";
            }
            comSearchAreaMap.put("comSarchWord", strSearchWord);

            // シリアルワード
            String strSerialNumberCSV = form.serialNumberCSV;
            if (CM_CommonUtil.isNullOrBlank(strSerialNumberCSV)) {
                strSerialNumberCSV = "";
            }
            comSearchAreaMap.put("serialNumberCSV", strSerialNumberCSV);

            comSearchAreaDataList.add(comSearchAreaMap);
            _csvFormat.putDataInfoList(CM_Csv_Const.AREA_KEY_COM_SEARCH_AREA, comSearchAreaDataList);
        }

        if (CM_CommonUtil.isNotNullOrBlank(_csvFormat.getHeader(CM_Csv_Const.AREA_KEY_SEARCH_AREA))) {
            // フォーマットに個別検索条件の項目がある場合に設定
            List<Map<String, String>> searchAreaDataList = new ArrayList<Map<String, String>>();

            // 検索条件エリア個別項目
            BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();
            Map<String, String> searchAreaMap = this.getCsvSearchConditionData(formMap);

            searchAreaDataList.add(searchAreaMap);
            _csvFormat.putDataInfoList(CM_Csv_Const.AREA_KEY_SEARCH_AREA, searchAreaDataList);
        }
    }

    /**
     *
     * CSV出力検索条件値取得.<br>
     *<br>
     * 概要:<br>
     *   CSVに出力する検索条件の値を取得
     *<br>
     * @param _formMap フォーム情報
     * @return CSV出力検索条件値
     */
    protected Map<String, String> getCsvSearchConditionData(final BeanMap _formMap) {
        Map<String, String> ret = this.getService().getCsvSearchConditionData(_formMap);
        return ret;
    }

    /**
     *
     * アップロードCSVファイル共通チェック処理.<br>
     *<br>
     * 概要:<br>
     *   アップロードCSVファイルの共通チェック処理
     *<br>
     * @return 返却JSPパス
     */
    @Execute(validator = false)
    public String checkImportCsv() {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, getActionForm());

        CM_VisualizationBaseService service = this.getService();

        service.init(this.cM_A03_SessionDto);

        this.csvUploadResult = new CM_Csv_Upload_Result();

        FormFile uploadCsvFile = getActionForm().uploadCsvFile;

        // ファイルサイズをチェック
        String strErrorMsg = CM_CsvUtil.checkCsvFileLimit(uploadCsvFile, this.cM_A03_SessionDto);

        if (CM_CommonUtil.isNotNullOrBlank(strErrorMsg)) {
            // ファイルサイズエラー
            this.csvUploadResult.setErrorMessage(strErrorMsg);

            return CM_Csv_Const.UPLOAD_RESULT_PAGE;
        }

        try {
            String uploadCsvVersion = CM_CsvUtil.getCsvSystemVersion(getCsvFormat(),  uploadCsvFile.getInputStream(), this.cM_A03_SessionDto);

            //CSVのバージョンが現在のものと同一かどうかをチェック
            if (!CM_CommonUtil.isNullOrBlank(uploadCsvVersion) && !CM_CsvUtil.checkCsvNowSystemVersion(uploadCsvVersion)) {
                if (!CM_CsvUtil.checkCsvVersion(uploadCsvVersion, getCsvChangeVersionList(), this.cM_A03_SessionDto)) {
                    // コンバート可能な最大回数を超える場合、エラーメッセージを表示
                    String errorMsg = CM_MessageResourceUtil.getMessageValue(
                            this.cM_A03_SessionDto.ssn_CustomerCD, this.cM_A03_SessionDto.ssn_UserLangCD,
                            "MMCMCM00000_050");

                    this.csvUploadResult.setErrorMessage(errorMsg);
                } else {
                    // 古いバージョンのCSVでコンバート可能な最大回数を超えない場合、警告メッセージを表示
                    String warningMeg = CM_MessageResourceUtil.getMessageValue(
                            this.cM_A03_SessionDto.ssn_UserID, this.cM_A03_SessionDto.ssn_UserLangCD, "MMCMCM00000_046");
                    this.csvUploadResult.setWarningMessage(warningMeg);
                }
            }

            List<String[]> data = CM_CsvUtil.readCsvFile(uploadCsvFile.getInputStream());

            // 新規モードのデータが含まれている場合
            if (CM_CsvUtil.checkExistNewMode(data)) {

            }

        } catch (Exception e) {
            String strErrorMes = CM_MessageResourceUtil.getMessageValue(this.cM_A03_SessionDto.ssn_CustomerCD,
                    this.cM_A03_SessionDto.ssn_UserLangCD, "MMCMCM00000_024");
            this.csvUploadResult.setErrorMessage(strErrorMes);
            //ログ出力
            CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, strErrorMsg);
            return  CM_Csv_Const.UPLOAD_RESULT_PAGE;
        }

        // メソッド終了ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, CM_Csv_Const.UPLOAD_RESULT_PAGE);

        return CM_Csv_Const.UPLOAD_RESULT_PAGE;
    }

    /**
     * 各画面のCSVフォーマット情報クラス取得.<br>
     *<br>
     * 概要:<br>
     * 各画面のCSVフォーマット情報クラスを取得<br>
     * 各画面のアクションでオーバーライドし、CSVフォーマット情報クラスを設定する
     *
     * @return 画面のCSVフォーマット情報クラス
     */
    protected FW01_10_CSVFormat getCsvFormat() {
        return null;
    }

    /**
     * 各画面のCSVフォーマット変更バージョン一覧取得.<br>
     *<br>
     * 概要:<br>
     * 各画面のCSVフォーマット変更バージョン一覧を取得<br>
     * 各画面のアクションでオーバーライドし、CSVフォーマット変更バージョン一覧を設定する
     *
     * @return 画面のCSVフォーマット変更バージョン一覧
     */
    protected List<String> getCsvChangeVersionList() {
        return null;
    }

    /**
     * SQLエラーメッセージCD取得.
     *
     * @return strSqlErrorMsgCd
     */
    @Override
    public String getStrSqlErrorMsgCd() {
        return this.strSqlErrorMsgCd;
    }

    /**
     * SQLエラーメッセージCD設定.
     *
     * @param _strSqlErrorMsgCd SQLエラーメッセージCD
     */
    @Override
    public void setStrSqlErrorMsgCd(final String _strSqlErrorMsgCd) {
        this.strSqlErrorMsgCd = _strSqlErrorMsgCd;
    }

    /**
     *
     * 共通SQLエラーメッセージCD.<br>
     *<br>
     * 概要:<br>
     *   共通SQLエラーメッセージCD
     *<br>
     */
    protected void setBaseDefaultSqlErrorMsgCd() {
        this.setStrSqlErrorMsgCd("MMCMCM00000_303");
    }

    /**
     *
     * ヘッダー情報格納.<br>
     *<br>
     * 概要:<br>
     *   ヘッダ情報を格納する
     *<br>
     * @param _iName 項目名
     * @param _dName 表示名
     * @param _width 列幅
     * @param _sort ソート有無
     * @param _vertical 表示/非表示
     */
    public void putHdInf(final String _iName, final String _dName, final String _width,
            final boolean _sort, final String _vertical) {
        if (this.fw0110ListHeader == null) {
            this.fw0110ListHeader = new ArrayList<Map<String, String>>();
        }
        Map<String, String> headerInfo = new HashMap<String, String>();
        headerInfo.put("ItemCode", _iName);
        headerInfo.put("DispName", _dName);
        headerInfo.put("width", _width);
        headerInfo.put("sort", Boolean.toString(_sort));
        headerInfo.put("sortmd", _vertical);
        this.fw0110ListHeader.add(headerInfo);
    }

    /**
     *
     * 初期表示 初期処理.<br>
     *<br>
     * 概要:<br>
     *   初期表示 初期処理を実行する<br>
     *   各画面でオーバーライドして実装する
     *<br>
     */
    @Override
    protected void preIndex() {
    }

    /**
     *
     * 初期表示 初期処理.<br>
     *<br>
     * 概要:<br>
     *   初期表示 初期処理を実行する<br>
     *   各画面でオーバーライドして実装する
     *<br>
     */
    @Override
    protected void afterIndex() {

        // 共通ヘッダパンくずリストの登録
        CM_HeaderUtil.addBreadCrumbList(this.cM_A03_SessionDto, this.getPageId());
    }

    /**
     *
     * 検索処理.<br>
     *<br>
     * 概要:<br>
     *  検索処理を実行する
     *<br>
     * @return JSP名
     */
    @Override
    @Execute(validator = false)
    public String search() {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        // 不要データクリア
        this.clearListFormForSearch(this.getActionForm());

        // 検索領域の情報をセット
        this.initDetailSearchDisplayInfo(this.getPageId());

        // 共通設定
        commonSetting();

        // 検索処理
        String ret = this.searchResult();
        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, ret);

        return ret;
    }

    /**
     *
     * 自動更新処理.<br>
     *<br>
     * 概要:<br>
     *  自動更新処理を実行する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String searchAuto() {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        // 不要データクリア
        this.clearListFormForSearch(this.getActionForm());

        // 検索領域の情報をセット
        this.initDetailSearchDisplayInfo(this.getPageId());

        commonSetting();

        // 検索処理
        String ret = this.autoSearchResult();

        // 警告メッセージ取得
        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();
        mstDataService.getAlertMessage(formMap);

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, ret);

        return ret;
    }

    /**
     *
     * ソート処理.<br>
     *<br>
     * 概要:<br>
     *  ソート処理を実行する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String sort() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        CM_ListForm form = this.getActionForm();

        // 検索領域の情報をセット
        this.initDetailSearchDisplayInfo(this.getPageId());

        // 検索時の条件保持用隠し項目の値で検索条件を上書き
        form.hdnComDetailSearchCond = form.hdnComDetailSearchCondForSort;

        // ソート処理実行
        String ret = this.sortResult();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, ret);

        return ret;
    }

    /**
     *
     * ページング処理.<br>
     *<br>
     * 概要:<br>
     *  ページング処理を実行する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String paging() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        CM_ListForm form = this.getActionForm();

        // 検索領域の情報をセット
        this.initDetailSearchDisplayInfo(this.getPageId());

        // 検索時の条件保持用隠し項目の値で検索条件を上書き
        form.hdnComDetailSearchCond = form.hdnComDetailSearchCondForSort;

        // AJAX用JSPを返す
        String ret = this.pagingResult();

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, ret);

        return ret;
    }

//    /**
//     *
//     * 画面遷移処理.<br>
//     *<br>
//     * 概要:<br>
//     *  各画面に遷移する。<br>
//     *  各画面Actionで記述しているsetTransferMapを呼び出し、次画面へのパラメータを設定。
//     *<br>
//     * @return JSP名
//     */
//    @Execute(validator = false)
//    public String redirectPage() {
//        // メソッド開始ログ出力
//        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());
//
//        String pageUrl = this.getJspFileName();
//
//        // フォーム情報保存
//        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();
//
//        // サービス初期化
//        this.getService().init(this.cM_A03_SessionDto);
//
//        // パンくずリストに、戻りページ設定
//        CM_HeaderUtil.setReturnInfo(this.cM_A03_SessionDto, this.getPageId(), this.getPageInfo().getReturnPageUrl(), formMap);
//
//        // 画面遷移パラメータ
//        Map<String, String> transferMap = new HashMap<String, String>();
//        // 画面遷移フラグ設定
//        transferMap.put(CM_ListForm.CM_LISTFORM_HDN_TRANSFER_FLAG, CM_A04_Const.FLG.ON);
//
//        this.setTransferMap(transferMap);
//
//        // 次画面ページ情報
//        String nextPage = this.getRedirectPageUrl();
//
//        if (CM_CommonUtil.isNotNullOrBlank(nextPage)) {
//            pageUrl = this.redirectPage(nextPage, transferMap, this.getActionForm());
//        }
//        // メソッド出力ログ出力
//        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, pageUrl);
//
//        return pageUrl;
//    }

    /**
     *
     * 検索件数取得.<br>
     *<br>
     * 概要:<br>
     *  検索件数取得処理を実行する
     *<br>
     * @return 検索件数返却用ページ
     */
    @Execute(validator = false)
    public String searchDetailCount() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        CM_ListForm form = this.getActionForm();

        // 検索領域の情報をセット
        this.initDetailSearchDisplayInfo(this.getPageId());

        // 詳細検索条件情報を取得
        Map<String, Object> mapSearchCondInfo = this.getComDetailSearchInfo(this.getPageId(), (FW01_17_BaseForm) form);

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, form).execute();

        // サービス初期化
        this.getService().init(this.cM_A03_SessionDto);

        // 条件に該当する全件数を取得
        long listCnt = this.getSearchCount(formMap, mapSearchCondInfo);

        this.searchCountInfo = Long.toString(listCnt);

        String ret = "../common/com_searchCount.jsp";

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, ret);

        return ret;
    }

    /**
     * 検索処理.<br>
     *<br>
     * 概要:<br>
     * 各画面の検索処理を実行<br>
     * 各画面のアクションでオーバーライドし、実装する
     *
     * @return JSP名
     */
    public String searchResult() {

        // 次画面に対する権限取得
        this.getNextPageAuth();

        // サービス初期化
        this.getService().init(this.cM_A03_SessionDto);

        // 表示処理
        this.display();

        // 検索時は全画面更新
        return this.getJspFileName();
    };

    /**
     * ページング処理.<br>
     *<br>
     * 概要:<br>
     * 各画面のページング処理を実行<br>
     * 各画面のアクションでオーバーライドし、実装する
     *
     * @return JSP名
     */
    public String autoSearchResult() {
        // 次画面に対する権限取得
        this.getNextPageAuth();

        // サービス初期化
        this.getService().init(this.cM_A03_SessionDto);

        // 表示処理
        this.display();

        // AJAX用JSPを返す
        return this.getJspFileNameAjax();
    };

    /**
     * 件数取得処理.<br>
     *<br>
     * 概要:<br>
     * 各画面の検索件数取得処理を実行<br>
     * 各画面のアクションでオーバーライドし、実装する
     *
     * @param _formInfo Form情報
     * @param _mapSearchCondInfo 詳細検索情報
     * @return 件数
     */
    public long getSearchCount(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {
        return this.getService().getDataCount(_formInfo, _mapSearchCondInfo);
    };

    /**
     * ソート処理.<br>
     *<br>
     * 概要:<br>
     * 各画面のソート処理を実行<br>
     * 各画面のアクションでオーバーライドし、実装する
     *
     * @return JSP名
     */
    public String sortResult() {
        // 次画面に対する権限取得
        this.getNextPageAuth();

        // サービス初期化
        this.getService().init(this.cM_A03_SessionDto);

        // 表示処理
        this.display();

        // AJAX用JSPを返す
        return this.getJspFileNameAjax();
    };

    /**
     * ページング処理.<br>
     *<br>
     * 概要:<br>
     * 各画面のページング処理を実行<br>
     * 各画面のアクションでオーバーライドし、実装する
     *
     * @return JSP名
     */
    public String pagingResult() {
        // 次画面に対する権限取得
        this.getNextPageAuth();

        // サービス初期化
        this.getService().init(this.cM_A03_SessionDto);

        // 表示処理
        this.display();

        // AJAX用JSPを返す
        return this.getJspFileNameAjax();
    };

//    /**
//     *
//     * 遷移先URL取得.<br>
//     *<br>
//     * 概要:<br>
//     *  遷移先のURLを取得
//     *<br>
//     * @return 遷移先URL
//     */
//    public String getRedirectPageUrl() {
//
//        String redirectPageUrl = null;
//        if (CM_CommonUtil.isNotNullOrBlank(this.getNextPageInfo())) {
//            redirectPageUrl = this.getNextPageInfo().getIndexPageUrl();
//        } else if (CM_CommonUtil.isNotNullOrBlank(this.getActionForm().hdnNextPageId)) {
//            CM_A05_PageInfo pageInfo = CM_A05_PageInfo.getPageInfo(this.getActionForm().hdnNextPageId);
//            if (pageInfo != null) {
//                redirectPageUrl = pageInfo.getIndexPageUrl();
//            }
//        }
//        return redirectPageUrl;
//    };

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.common.action.CM_A01_BaseAction#getService()
     */
    @Override
    protected abstract CM_ListBaseService getService();

    /**
     * 復帰処理.<br>
     *<br>
     * 概要:<br>
     * 各画面の復帰処理を実行<br>
     * 各画面のアクションでオーバーライドし、実装する<br>
     * ※実装内容：Form に _returnDispInfo の値を設定
     *
     * @param _returnDispInfo 画面復帰用情報
     */
    public abstract void returnPageResult(final HashMap<String, Object> _returnDispInfo);

    /**
     * 各画面のフォームクラス取得.<br>
     *<br>
     * 概要:<br>
     * 各画面のフォームクラスを取得<br>
     * 各画面のアクションでオーバーライドし、フォームクラスを設定する
     *
     * @return 画面のフォームクラス
     */
    @Override
    protected abstract CM_ListForm getActionForm();

//    /**
//     *
//     * 次画面遷移パラメータを設定.<br>
//     *<br>
//     * 概要:<br>
//     *  次画面遷移パラメータを設定<br>
//     *  各画面のアクションでオーバーライドし、フォームクラスを設定する
//     *<br>
//     * @param _transferMap クエリパラメータ(KEY：次画面項目名、VALUE：遷移パラメータ)
//     */
//    protected abstract void setTransferMap(final Map<String, String> _transferMap);

    /**
     *
     * 検索処理時のフォーム内不要データクリア.<br>
     *<br>
     * 概要:<br>
     *   検索処理時に現在のページ番号、ソートキー、ソート順は不要なため、初期化する。
     *<br>
     * @param _actionForm 画面ActionFrom
     */
    protected void clearListFormForSearch(final CM_BaseForm _actionForm) {
        _actionForm.fw0114PageNo = "1";
        _actionForm.fw0114SortKey = null;
        _actionForm.fw0114SortOrder = null;
    }

    /**
     *
     * 共通詳細検索領域用の情報を取得し、共通情報にセットする.<br>
     *<br>
     * 概要:<br>
     *   共通詳細検索領域用の情報を取得し、共通情報にセットする。
     *<br>
     * @param _strPageId 画面ID
     */
    protected void initDetailSearchDisplayInfo(final String _strPageId) {

        // 検索条件選択リスト情報の初期化
        this.itemSelectListInfoMap = new BeanMap();

        // 対象画面の詳細検索設定情報を取得
        ArrayList<CM_A08_ComDetailSearchItemDto> dsItemInfoList = CM_ComDetailSearchUtil.getDSItemInfo(_strPageId);

        this.itemList = new ArrayList<BeanMap>();
        BeanMap dsItemInfoMap = null;
        List<BeanMap> listSelectListInfoFromDb = null;
        BeanMap mapSelectListFromDb = null;
        ArrayList<BeanMap> listSelectListInfoForDisp = null;
        BeanMap mapSelectListForDisp = null;
        String strMapKeyCd = FW00_19_Const.EMPTY_STR;
        String strMapKeyName = FW00_19_Const.EMPTY_STR;
        String strMapKeyName2 = FW00_19_Const.EMPTY_STR;

        // 詳細検索設定情報が存在する
        if (dsItemInfoList != null) {
            // 各検索項目情報を取得
            for (int i = 0; i < dsItemInfoList.size(); i++) {
                dsItemInfoMap = new BeanMap();
                dsItemInfoMap.put(CM_A08_ComDetailSearchItemDto.ITEM_ID, dsItemInfoList.get(i).itemId);
                dsItemInfoMap.put(CM_A08_ComDetailSearchItemDto.ITEM_RESOURCE_ID, dsItemInfoList.get(i).itemResourceId);
                dsItemInfoMap.put(CM_A08_ComDetailSearchItemDto.INPUT_TYPE, dsItemInfoList.get(i).inputType);
                dsItemInfoMap.put(CM_A08_ComDetailSearchItemDto.WHERE_COND_TYPE, dsItemInfoList.get(i).whereCondType);
                dsItemInfoMap.put(CM_A08_ComDetailSearchItemDto.WHERE_COLUMN_TYPE, dsItemInfoList.get(i).whereColumnType);

                // リスト指定されている場合、リスト情報を取得する
                if (dsItemInfoList.get(i).selectListType != null) {
                    listSelectListInfoForDisp = new ArrayList<BeanMap>();

                    // 必須でない場合、先頭にブランク選択肢を登録
                    if (!dsItemInfoList.get(i).selectListIsnes.equals(CM_A04_Const.FLG.ON)) {
                        // 表示用選択肢データ初期化
                        mapSelectListForDisp = new BeanMap();
                        // コード、名称をブランクで登録
                        mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, FW00_19_Const.EMPTY_STR);
                        mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME, FW00_19_Const.EMPTY_STR);
                        listSelectListInfoForDisp.add(mapSelectListForDisp);
                    }

                    // 名称マスタ（システム用）または名称マスタから取得する場合
                    if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.SYS_NAME)
                            || dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.MST_NAME)) {

                        // 名称コードを取得
                        if (!CM_CommonUtil.isNullOrBlank(dsItemInfoList.get(i).selectListCode)) {

                            // 名称マスタ（システム用）から取得
                            if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.SYS_NAME)) {
                                listSelectListInfoFromDb = CM_SysNameDataUtil.getNameList(this.cM_A03_SessionDto,
                                        dsItemInfoList.get(i).selectListCode, this.cM_A03_SessionDto.ssn_UserLangCD);
                                // 名称マスタから取得
                            } else {
                                listSelectListInfoFromDb = CM_MstNameDataUtil.getNameList(this.cM_A03_SessionDto,
                                        dsItemInfoList.get(i).selectListCode, this.cM_A03_SessionDto.ssn_UserLangCD);
                            }

                            if (listSelectListInfoFromDb != null) {
                                // 名称マスタ（システム用）から取得
                                if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.SYS_NAME)) {
                                    strMapKeyCd = SysNameEntityNames.itemCd().toString();
                                    strMapKeyName = SysNameEntityNames.name1().toString();
                                } else {
                                    strMapKeyCd = MstNameEntityNames.itemCd().toString();
                                    strMapKeyName = MstNameEntityNames.name().toString();
                                }

                                for (int j = 0; j < listSelectListInfoFromDb.size(); j++) {
                                    // DBから取得した選択肢データを取得
                                    mapSelectListFromDb = listSelectListInfoFromDb.get(j);
                                    // 表示用選択肢データ初期化
                                    mapSelectListForDisp = new BeanMap();
                                    // コードを登録
                                    mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, mapSelectListFromDb.get(strMapKeyCd));
                                    // 名称を登録
                                    mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME, mapSelectListFromDb.get(strMapKeyName));

                                    listSelectListInfoForDisp.add(mapSelectListForDisp);
                                }
                            }
                        }
                        // 環境マスタから取得する場合
                    } else if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.SYS_ENV)) {

                        // 名称コードを取得
                        if (!CM_CommonUtil.isNullOrBlank(dsItemInfoList.get(i).selectListCode)) {
                            listSelectListInfoFromDb = CM_SysEnvDataUtil.selectListSysEnv(this.cM_A03_SessionDto, dsItemInfoList.get(i).selectListCode);

                            if (listSelectListInfoFromDb != null) {

                                strMapKeyCd = SysEnvEntityNames.itemCd().toString();
                                strMapKeyName = SysEnvEntityNames.name().toString();

                                for (int j = 0; j < listSelectListInfoFromDb.size(); j++) {
                                    // DBから取得した選択肢データを取得
                                    mapSelectListFromDb = listSelectListInfoFromDb.get(j);
                                    // 表示用選択肢データ初期化
                                    mapSelectListForDisp = new BeanMap();
                                    // コードを登録
                                    mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, mapSelectListFromDb.get(strMapKeyCd));
                                    // 名称を登録
                                    mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME, mapSelectListFromDb.get(strMapKeyName));

                                    listSelectListInfoForDisp.add(mapSelectListForDisp);
                                }
                            }
                        }
//                        // 役割マスタから取得する場合
//                    } else if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.MST_ROLE)) {
//                        // 役割マスタからデータ取得
//                        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
//                        List<BeanMap> mstRoleDataList = mstDataService.getMstRoleList(this.cM_A03_SessionDto.ssn_AuthorityCode);
//
//                        if (mstRoleDataList != null) {
//
//                            strMapKeyCd = MstRoleEntityNames.sid().toString();
//                            strMapKeyName = MstRoleEntityNames.roleName().toString();
//
//                            for (int j = 0; j < mstRoleDataList.size(); j++) {
//                                // DBから取得した選択肢データを取得
//                                mapSelectListFromDb = mstRoleDataList.get(j);
//                                // 表示用選択肢データ初期化
//                                mapSelectListForDisp = new BeanMap();
//                                // コードを登録
//                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, mapSelectListFromDb.get(strMapKeyCd));
//                                // 名称を登録
//                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME, mapSelectListFromDb.get(strMapKeyName));
//
//                                listSelectListInfoForDisp.add(mapSelectListForDisp);
//                            }
//                        }
                        // ユーザマスタから取得する場合
                    } else if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.MST_USER)) {
                        // ユーザマスタからデータ取得
                        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
                        List<BeanMap> mstUserDataList = mstDataService.getMstUserList();

                        if (mstUserDataList != null) {

                            strMapKeyCd = MstUserEntityNames.sid().toString();
                            strMapKeyName = MstUserEntityNames.userLastname().toString();
                            strMapKeyName2 = MstUserEntityNames.userFirstname().toString();

                            for (int j = 0; j < mstUserDataList.size(); j++) {
                                // DBから取得した選択肢データを取得
                                mapSelectListFromDb = mstUserDataList.get(j);
                                // 表示用選択肢データ初期化
                                mapSelectListForDisp = new BeanMap();
                                // コードを登録
                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, mapSelectListFromDb.get(strMapKeyCd));
                                // 名称を登録
                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME,
                                        mapSelectListFromDb.get(strMapKeyName) + FW00_19_Const.SPACE + mapSelectListFromDb.get(strMapKeyName2));

                                listSelectListInfoForDisp.add(mapSelectListForDisp);
                            }
                        }
                        // 型番マスタから取得する場合
                    } else if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.MST_MODEL)) {
                        // 型番マスタからデータ取得
                        CM_GetMstDataService mstDataService = new CM_GetMstDataService(this.cM_A03_SessionDto);
                        List<BeanMap> mstModelDataList = mstDataService.getMstModelList();

                        if (mstModelDataList != null) {

                            strMapKeyCd = MstModelEntityNames.sid().toString();
                            strMapKeyName = MstModelEntityNames.name().toString();

                            for (int j = 0; j < mstModelDataList.size(); j++) {
                                // DBから取得した選択肢データを取得
                                mapSelectListFromDb = mstModelDataList.get(j);
                                // 表示用選択肢データ初期化
                                mapSelectListForDisp = new BeanMap();
                                // コードを登録
                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, mapSelectListFromDb.get(strMapKeyCd));
                                // 名称を登録
                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME, mapSelectListFromDb.get(strMapKeyName));

                                listSelectListInfoForDisp.add(mapSelectListForDisp);
                            }
                        }
                        // 個別定義から取得する場合
                    } else if (dsItemInfoList.get(i).selectListType.equals(CM_A08_ComDetailSearchItemDto.VAL_SELECT_LIST_TYPE.USER_LIST)) {
                        // 個別定義からデータ取得
                        String[] listCode = new String[0];
                        String[] listDispChar = new String[0];

                        // 個別定義のコードセットを分割
                        if (!CM_CommonUtil.isNullOrBlank(dsItemInfoList.get(i).selectListCodeSet)) {
                            listCode = dsItemInfoList.get(i).selectListCodeSet.split(FW00_19_Const.COMMA_STR);
                        }
                        // 個別定義の表示文言セットを分割
                        if (!CM_CommonUtil.isNullOrBlank(dsItemInfoList.get(i).selectListDispCharSet)) {
                            listDispChar = dsItemInfoList.get(i).selectListDispCharSet.split(FW00_19_Const.COMMA_STR);
                        }

                        if (listCode != null && listCode.length > 0) {
                            for (int j = 0; j < listCode.length; j++) {
                                // 表示用選択肢データ初期化
                                mapSelectListForDisp = new BeanMap();
                                // コードを登録
                                mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_CODE, listCode[j]);

                                // 名称を登録
                                if (listDispChar != null && listDispChar.length > j) {
                                    mapSelectListForDisp.put(ITEM_SELECT_LSIT_INFO_NAME,
                                            CM_DisplayCharResourceUtil.getDisplayCharValue(this.cM_A03_SessionDto.ssn_CustomerCD,
                                                    this.cM_A03_SessionDto.ssn_UserLangCD, listDispChar[j]));
                                }
                                listSelectListInfoForDisp.add(mapSelectListForDisp);
                            }
                        }
                    }

                    this.itemSelectListInfoMap.put(dsItemInfoList.get(i).itemId, listSelectListInfoForDisp);

                }
                this.itemList.add(dsItemInfoMap);
            }
        }
        return;
    }

    /**
     *
     * 共通詳細検索用の入力検索情報を検索処理用に分解加工する.<br>
     *<br>
     * 概要:<br>
     *   共通詳細検索用の入力検索情報を検索処理用に分解加工する。
     *<br>
     * @param _strPageId 画面ID
     * @param _actionForm 画面ActionFrom
     * @return 検索条件情報
     */
    protected Map<String, Object> getComDetailSearchInfo(final String _strPageId, final FW01_17_BaseForm _actionForm) {

        Map<String, Object> retMap = new HashMap<String, Object>();

        // 復帰用データを作成する
        this.itemRestoreInfoMap = new HashMap<String, Object>();

        // 対象画面の詳細検索設定情報を取得
        ArrayList<CM_A08_ComDetailSearchItemDto> dsItemInfoList = CM_ComDetailSearchUtil.getDSItemInfo(_strPageId);

        // 検索条件入力値がセットされている場合、検索条件情報を作成
        if (!CM_CommonUtil.isNullOrBlank(_actionForm.hdnComDetailSearchCond)) {

            // 検索条件文字列をセパレータで分割
            // 入力された検索条件の配列を作成
            String[] strSearchValueList = _actionForm.hdnComDetailSearchCond.split(DETAIL_SEARCH_ITEM_SEP);

            String[] strItemTempList = null;
            String strItemId = FW00_19_Const.EMPTY_STR;
            String strItemIdOrg = FW00_19_Const.EMPTY_STR;
            String strItemValue = FW00_19_Const.EMPTY_STR;

            // 入力された検索条件分ループ
            for (int i = 0; i < strSearchValueList.length; i++) {

                // 条件文字列を項目IDと条件内容に分割
                strItemTempList = strSearchValueList[i].split(FW00_19_Const.COLON_STR, 2);

                strItemId = FW00_19_Const.EMPTY_STR;
                strItemIdOrg = FW00_19_Const.EMPTY_STR;
                // 項目IDを取得
                if (!CM_CommonUtil.isNullOrBlank(strItemTempList[0])) {
                    strItemIdOrg = strItemTempList[0];
                    strItemId = strItemIdOrg;

                    // 検索項目名の不要ヘッダ文字列を削除
                    for (int j = 0; j < DETAIL_SEARCH_COND_HEADER_LIST.length; j++) {
                        strItemId = strItemId.replace(DETAIL_SEARCH_COND_HEADER_LIST[j], FW00_19_Const.EMPTY_STR);
                    }
                }

                strItemValue = FW00_19_Const.EMPTY_STR;
                // 条件内容を取得
                if (strItemTempList.length > 1 && !CM_CommonUtil.isNullOrBlank(strItemTempList[1])) {
                    strItemValue = strItemTempList[1];
                }

                // 項目ID、条件内容が取得できない場合は、条件対象外とする
                if (CM_CommonUtil.isNullOrBlank(strItemId) || CM_CommonUtil.isNullOrBlank(strItemValue)) {
                    continue;
                }

                // 項目IDに対応する条件設定情報を取得
                for (CM_A08_ComDetailSearchItemDto dsItemInfo : dsItemInfoList) {

                    // 項目IDが一致する条件情報で検索条件を作成
                    if (dsItemInfo.itemId.equals(strItemId)) {

                        // 対象の条件設定情報にて検索条件情報を作成
                        this.makeWhereInfo(retMap, dsItemInfo, strItemIdOrg, strItemValue);
                        makeItemRestoreInfo(this.itemRestoreInfoMap, dsItemInfo, strItemIdOrg, strItemValue);
                        break;
                    }
                }
            }

        }

        return retMap;
    }

    /**
     *
     * 共通詳細検索用の入力検索情報を検索処理用に分解加工する.<br>
     *<br>
     * 概要:<br>
     *   共通詳細検索用の入力検索情報を検索処理用に分解加工する。
     *<br>
     * @param _retMap 検索条件パラメータ情報
     * @param _dsItemInfo 条件設定情報
     * @param _strItemNameOrg 条件項目名
     * @param _strItemValue 条件内容
     */
    private void makeWhereInfo(final Map<String, Object> _retMap, final CM_A08_ComDetailSearchItemDto _dsItemInfo,
            final String _strItemNameOrg, final String _strItemValue) {

        // 項目の条件タイプにより条件内容を加工
        // IN句の場合
        if (_dsItemInfo.whereCondType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_TYPE.IN)) {
            // 複数条件をセパレータで分割
            String[] strTempList = _strItemValue.split(DETAIL_SEARCH_COND_SEP);

            // 数値型の場合、数値変換し条件パラメータに登録
            if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.INT)) {

                ArrayList<Integer> condList = new ArrayList<Integer>();
                // 条件分ループ
                for (String strVal : strTempList) {

                    try {
                        int numVal = Integer.parseInt(strVal);
                        condList.add(numVal);
                    } catch (NumberFormatException e) {
                        return;
                    }
                }
                _retMap.put(_strItemNameOrg, condList);

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.SHORT)) {

                ArrayList<Short> condList = new ArrayList<Short>();
                // 条件分ループ
                for (String strVal : strTempList) {

                    try {
                        short numVal = Short.parseShort(strVal);
                        condList.add(numVal);
                    } catch (NumberFormatException e) {
                        return;
                    }
                }
                _retMap.put(_strItemNameOrg, condList);

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.LONG)) {

                ArrayList<Long> condList = new ArrayList<Long>();
                // 条件分ループ
                for (String strVal : strTempList) {

                    try {
                        long numVal = Long.parseLong(strVal);
                        condList.add(numVal);
                    } catch (NumberFormatException e) {
                        return;
                    }
                }
                _retMap.put(_strItemNameOrg, condList);

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.FLOAT)) {

                ArrayList<Float> condList = new ArrayList<Float>();
                // 条件分ループ
                for (String strVal : strTempList) {

                    try {
                        float numVal = Float.parseFloat(strVal);
                        condList.add(numVal);
                    } catch (NumberFormatException e) {
                        return;
                    }
                }
                _retMap.put(_strItemNameOrg, condList);

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.DOUBLE)) {

                ArrayList<Double> condList = new ArrayList<Double>();
                // 条件分ループ
                for (String strVal : strTempList) {

                    try {
                        double numVal = Double.parseDouble(strVal);
                        condList.add(numVal);
                    } catch (NumberFormatException e) {
                        return;
                    }
                }
                _retMap.put(_strItemNameOrg, condList);

                // その他の型は文字配列をそのまま登録
            } else {
                _retMap.put(_strItemNameOrg, strTempList);
            }
            // Like句の場合
        } else if (_dsItemInfo.whereCondType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_TYPE.LIKE)) {
            // ワイルドカード文字をエスケープして登録
            String strTemp = CM_CommonUtil.escapeLikeString(_strItemValue);

            // LIKE検索用のワイルドカードを前後に追加
            strTemp = CM_CommonUtil.addWildcard(strTemp, true, true);

            _retMap.put(_strItemNameOrg, strTemp);

            // その他の場合はそのまま登録
        } else {
            // 数値型の場合、数値変換し条件パラメータに登録
            if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.INT)) {

                try {
                    int numVal = Integer.parseInt(_strItemValue);
                    _retMap.put(_strItemNameOrg, numVal);
                } catch (NumberFormatException e) {
                    return;
                }

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.SHORT)) {

                try {
                    short numVal = Short.parseShort(_strItemValue);
                    _retMap.put(_strItemNameOrg, numVal);
                } catch (NumberFormatException e) {
                    return;
                }

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.LONG)) {

                try {
                    long numVal = Long.parseLong(_strItemValue);
                    _retMap.put(_strItemNameOrg, numVal);
                } catch (NumberFormatException e) {
                    return;
                }

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.FLOAT)) {

                try {
                    float numVal = Float.parseFloat(_strItemValue);
                    _retMap.put(_strItemNameOrg, numVal);
                } catch (NumberFormatException e) {
                    return;
                }

            } else if (_dsItemInfo.whereColumnType.equals(CM_A08_ComDetailSearchItemDto.VAL_COND_ITEM_TYPE.DOUBLE)) {

                try {
                    double numVal = Double.parseDouble(_strItemValue);
                    _retMap.put(_strItemNameOrg, numVal);
                } catch (NumberFormatException e) {
                    return;
                }

                // その他の型は文字配列をそのまま登録
            } else {
                _retMap.put(_strItemNameOrg, _strItemValue);
            }

        }

        return;
    }

    /**
     *
     * 共通詳細検索用の入力検索情報を検索処理用に分解加工する.<br>
     *<br>
     * 概要:<br>
     *   共通詳細検索用の入力検索情報を検索処理用に分解加工する。
     *<br>
     * @param _restoreMap 詳細検索条件復帰情報
     * @param _dsItemInfo 条件設定情報
     * @param _strItemNameOrg 条件項目名
     * @param _strItemValue 条件内容
     */
    private void makeItemRestoreInfo(final HashMap<String, Object> _restoreMap, final CM_A08_ComDetailSearchItemDto _dsItemInfo,
            final String _strItemNameOrg, final String _strItemValue) {

        // 項目タイプにより条件内容を加工
        // Checkboxタイプの場合
        if (_dsItemInfo.inputType.equals(CM_A08_ComDetailSearchItemDto.VAL_INPUT_TYPE.CHECKBOX)) {

            // 複数条件をセパレータで分割
            String[] strTempList = _strItemValue.split(DETAIL_SEARCH_COND_SEP);

            ArrayList<String> condList = new ArrayList<String>();

            // 条件分ループ
            for (String strVal : strTempList) {
                condList.add(strVal);
            }

            _restoreMap.put(_strItemNameOrg, condList);

            // その他はそのまま復帰情報にセット
        } else {
            _restoreMap.put(_strItemNameOrg, _strItemValue);
        }

        return;
    }

    /**
     *
     * 頁計算処理.<br>
     *<br>
     * 概要:<br>
     *   表示件数から頁を計算する。
     *<br>
     * @param _form ActionForm
     * @param _intAllCnt 検索条件該当全件数
     */
    protected void calcPage(final CM_BaseForm _form, final long _intAllCnt) {

        long paramAllCnt = _intAllCnt;

        BeanMap envMap = CM_SysEnvDataUtil.selectSysEnv(this.cM_A03_SessionDto,
                CM_A04_Const.SYS_ENV_MST_ENV_CD.SEARCH_RESULT_MAX,
                CM_A04_Const.SEARCH_RESULT_ITEM_CD.SEARCH_RESULT_MAX_ITEM_CD);
        this.searchResultMax = new Long(envMap.get(SysEnvEntityNames.name()).toString());

        if (this.searchResultMax != null && _intAllCnt > this.searchResultMax.longValue()) {
            paramAllCnt = this.searchResultMax.longValue();
        }

        this.calcPage(_form, paramAllCnt, true);

        this.searchCountInfo = Long.toString(_intAllCnt);
    }

    /**
     *
     * メソッド名：一覧ページ計算処理.<br>
     *<br>
     * 概要:<br>
     *   一覧の表示情報の計算処理を行う
     *<br>
     * @param _form フォーム
     * @param _intAllCnt 一覧件数
     * @param _pageFlg ページ替え有無
     */
    protected void calcPage(final CM_BaseForm _form, final long _intAllCnt, final boolean _pageFlg) {
        // 該当件数をフィールドに設定
        this.fw0110AllSize = Long.toString(_intAllCnt);

        if (_intAllCnt == 0) {
            this.fw0110NoneDataMsg = FW00_06_MessageResourceUtil.getMessage("M025");
        }

        if (_form.fw0114PageNo == null || _form.fw0114PageNo.equals(FW00_19_Const.EMPTY_STR)) {
            _form.fw0114PageNo = "1";
        }
        if (_pageFlg) {
            if (this.fw0110DispCntList == null || this.fw0110DispCntList.isEmpty()) {

                this.selectDispCnt();
            }
            if (_form.fw0114ListSize == null || _form.fw0114ListSize.equals(FW00_19_Const.EMPTY_STR)) {
                for (Map<String, String> record : this.fw0110DispCntList) {
                    if (record.get(FW01_03_CreateSingleSelectTagUtil.FW01_03_KEY_OPT_SELECTED) != null
                            && record.get(FW01_03_CreateSingleSelectTagUtil.FW01_03_KEY_OPT_SELECTED).equals(FW01_03_CreateSingleSelectTagUtil.FLG_SELECTED)) {
                        _form.fw0114ListSize = record.get(FW01_03_CreateSingleSelectTagUtil.FW01_03_KEY_OPT_VALUE);
                        break;
                    }
                }
                if (_form.fw0114ListSize == null || _form.fw0114ListSize.equals(FW00_19_Const.EMPTY_STR)) {
                    _form.fw0114ListSize = this.fw0110DispCntList.get(this.fw0110DispCntList.size() - 1).get("value");
                }
            }
        } else {
            _form.fw0114ListSize = new Long(_intAllCnt).toString();
        }
        int intPageSize = Integer.parseInt(_form.fw0114ListSize);

        int intAllPageCnt = 0;

        if (intPageSize > 0) {
            intAllPageCnt = new Long(_intAllCnt).intValue() / intPageSize;

            if (new Long(_intAllCnt).intValue() % intPageSize > 0) {
                intAllPageCnt++;
            } else if (_intAllCnt == 0) {
                intAllPageCnt = 1;
            }
        }

        // 別ユーザによりデータ件数が替えられた為表示ページ位置がおかしくなった場合の対応
        if (intAllPageCnt < Integer.parseInt(_form.fw0114PageNo)) {
            _form.fw0114PageNo = Integer.toString(intAllPageCnt);
        }

        this.fw0110AllPageCnt = Integer.toString(intAllPageCnt);
    }

    /**
     * 表示件数プルダウン情報の取得.
     */
    protected void selectDispCnt() {
        // 環境マスタより表示件数プルダウン情報の取得
        List<BeanMap> list = CM_SysEnvDataUtil.selectListSysEnv(this.cM_A03_SessionDto, envCodeListDispCount);

        FW01_03_CreateSingleSelectTagUtil util =
                new FW01_03_CreateSingleSelectTagUtil(
                        SysEnvEntityNames.itemCd().toString(),
                        SysEnvEntityNames.name().toString(),
                        SysEnvEntityNames.defaultFlag().toString(),
                        list,
                        -1);
        this.fw0110DispCntList = util.getItemList();
    }

    /**
     *
     * オフセット情報取得.<br>
     *<br>
     * 概要:<br>
     *   {??メソッド説明??}
     *<br>
     * @param _form フォーム
     * @return オフセット情報
     */
    public Map<String, Integer> getOffsetInfo(final CM_BaseForm _form) {
        Map<String, Integer> offsetInfo = new HashMap<String, Integer>();

        int intDispPage = Integer.parseInt(_form.fw0114PageNo);
        int intListSize = Integer.parseInt(_form.fw0114ListSize);

        offsetInfo.put(OFFSET_INFO_DISP_PAGE, new Integer(intDispPage));
        offsetInfo.put(OFFSET_INFO_LIST_CNT, new Integer(intListSize));

        // 表示可能な最大件数を超える場合、limitを設定する
        if (this.searchResultMax != null && intDispPage * intListSize > this.searchResultMax.longValue()) {
            // 表示件数 = 最大件数 - 前頁までの合計件数
            int intLimitCnt = (int) (this.searchResultMax.longValue() - (intDispPage - 1) * intListSize);
            offsetInfo.put(OFFSET_INFO_LIMIT_CNT, new Integer(intLimitCnt));
        }

        return offsetInfo;
    }

    /**
     *
     * Excel出力チェック.<br>
     *<br>
     * 概要:<br>
     * Excel出力時のチェック処理
     *<br>
     * @return jsp
     */
    @Execute(validator = false)
    public String checkExportExcel() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        try {
            // フォーム情報をMapに格納
            BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();
            formMap.put(CM_A04_Const.SQL_PARAM.LOGIN_USER_LANG_CD, this.cM_A03_SessionDto.ssn_UserLangCD);
            formMap.put(CM_A04_Const.SQL_PARAM.PARAM_USER_TIMEZONE, this.cM_A03_SessionDto.ssn_UserTimezoneCD);
            // 詳細検索条件情報を取得
            Map<String, Object> mapSearchCondInfo = this.getComDetailSearchInfo(this.getPageId(), this.getActionForm());

            // 入力チェック
            this.getService().excelValidate(formMap, mapSearchCondInfo);

        } catch (FW00_12_BusinessException be) {
            // 例外発生時はエラーメッセージ表示
            return this.alertErrorInfoForAjax(be.getMsgKey(), be.getFocusCtlId());

        } catch (SQLRuntimeException re) {
            // SQLエラー時はエラーをスローする
            throw re;
        } catch (Exception e) {
            // 例外発生時はエラーメッセージ表示
            String strErrorMes = CM_MessageResourceUtil.getMessageValue(this.cM_A03_SessionDto.ssn_CustomerCD,
                    this.cM_A03_SessionDto.ssn_UserLangCD, "CMMCMCM00000_011");

            // 例外情報はログ出力
            CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, e);

            return this.alertErrorInfoForAjax(strErrorMes, null);
        }

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, CHECK_EXPORT_EXCEL_RESULT);

        return CHECK_EXPORT_EXCEL_RESULT;
    }

    /**
     *
     * Excel出力.<br>
     *<br>
     * 概要:<br>
     * Excelを出力する処理
     *<br>
     * @return jsp
     */
    @Execute(validator = false)
    public String exportExcel() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        CM_VisualizationBaseService service = this.getService();

        // サービス初期化
        service.init(this.cM_A03_SessionDto);

        // 日時情報更新処理
        this.setDisplayDateData(this.getActionForm());

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();
        // フォーム情報にユーザの言語コードを設定
        formMap.put(CM_A04_Const.SQL_PARAM.LOGIN_USER_LANG_CD, this.cM_A03_SessionDto.ssn_UserLangCD);

        service.init(this.cM_A03_SessionDto);

        String excelType = formMap.get(CM_ListForm.CM_LISTFORM_HDN_EXPORT_EXCEL_TYPE).toString();

        // 環境マスタからテンプレート配置先取得
        BeanMap tmplateInfo = CM_SysEnvDataUtil.selectSysEnv(this.cM_A03_SessionDto, CM_A04_Const.SYS_ENV_MST_ENV_CD.EXPORT_EXCEL_INFO,
                CM_A04_Const.SYS_ENV_MST_ITEM_CD.TEMPLATE_PATH);
        // 環境マスタからExcel情報を取得
        BeanMap excelInfo = CM_SysEnvDataUtil.selectSysEnv(this.cM_A03_SessionDto, CM_A04_Const.SYS_ENV_MST_ENV_CD.EXCEL_TYPE, excelType);

        // テンプレートパス
        String tmpleateFilePath = tmplateInfo.get(SysEnvEntityNames.name()).toString()
                + FW00_19_Const.SLASH_STR + excelInfo.get(SysEnvEntityNames.name()).toString();

        // 出力ファイル名生成
        String outFile = createExportFilePath(excelInfo);

        // 表示用検索条件取得
        List<BeanMap> exportSearchConditionList = this.getExportExcelSearchConditionList();
        String exportSearchConditionStr = this.convertExportExcelSearchCondition(exportSearchConditionList);

        // Excelフォーマット取得
        CM_ExcelFormat excelFormat = this.getExcelFormat();

        try {
             // テンプレートファイル読み込み
            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(tmpleateFilePath));

            for (CM_ExcelSheetInfoDto sheetFormatInfo : excelFormat.getSheetInfoList()) {

                // データ取得
                List<?> data = this.getExportData(sheetFormatInfo, formMap);

                // シート読み込み
                XSSFSheet sheet = wb.getSheet(sheetFormatInfo.getSheetName());

                // 凡例部書き込み
                this.setLegend(sheet, sheetFormatInfo);

                // 検索条件出力
                this.setExportSearchCondition(sheet, sheetFormatInfo, exportSearchConditionStr);

                // データ部書き込み
                this.setExportData(data, wb, sheet, sheetFormatInfo);

            }
            // 再計算
            wb.getSheet("View").setForceFormulaRecalculation(true);

            // Excel出力
            ServletOutputStream out = null;
            if (outFile != null && !outFile.equals(FW00_19_Const.EMPTY_STR)) {
                String encordName = FW00_11_UrlEncodeUtil.getUrlEncode(outFile);
                this.response.setContentType("application/octet-stream");
                this.response.setHeader("Content-Disposition", "attachment; filename=\"" + encordName + "\"");
            } else {
                this.response.setContentType("application/octet-stream");
                this.response.setHeader("Content-Disposition", "attachment");
            }
            this.response.setHeader("Cache-Control", "private");
            this.response.setHeader("Pragma", "private");

            out = this.response.getOutputStream();
            wb.write(out);

            out.close();
        } catch (FW00_12_BusinessException be) {
            // 例外発生時はエラーメッセージ表示
            throw new FW00_12_BusinessException(be.getMessage());

        } catch (Exception e) {
            // 例外発生時はエラーメッセージ表示
            String strErrorMes = e.getMessage();

            // 例外情報はログ出力
            CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, e);

            throw new FW00_12_BusinessException(strErrorMes);
        }

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, null);

        return null;
    }

    /**
     *
     * 出力ファイルパス生成.<br>
     *<br>
     * 概要:<br>
     * 出力ファイルパス生成処理<br>
     * 環境マスタから取得した出力するExcel種別の環境マスタ情報から出力するファイル名を生成する<br>
     * 生成するファイル名は<br>
     * 環境マスタ.略称 + _ + 出力日時(yyyyMMddHHmmssSSS) + _ + 環境マスタ.備考
     *
     *<br>
     * @param _sysEnv 環境マスタ（環境CD：excel_type　項目CD：Excelの出力種別）
     * @return 出力ファイルパス
     */
    private String createExportFilePath(final BeanMap _sysEnv) {
        // システム日時を取得する(日本時間)
        Date now = new Date();
        String jpnDatetime = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT).format(now);

        // 日本時間から標準時に変換する
        Date gmtDatetime = CM_CommonUtil.getTimeTimezoneToGmt(jpnDatetime, FW00_19_Const.TZ_JPN, CM_A04_Const.DATE_FORMAT);

        // ログインユーザのタイムゾーンに変換
        String userTimezone = this.cM_A03_SessionDto.ssn_UserTimezoneCD;
        String userTimezoneStr = CM_CommonUtil.getTimeGmtToTimezone(new Timestamp(gmtDatetime.getTime()), userTimezone, CM_A04_Const.DATE_FORMAT_JUSTIFIED);

        String fileName = _sysEnv.get(SysEnvEntityNames.abbName()).toString() + FW00_19_Const.UNDER_BAR_STR + userTimezoneStr
                + _sysEnv.get(SysEnvEntityNames.remark()).toString();

        return fileName;
    }

    /**
     * Excel出力用検索条件取得.<br>
     *<br>
     * 概要:<br>
     * Excel出力に使用した検索条件の項目名とパラメータ値を取得する処理<br>
     * BeanMapに検索項目のメッセージID（dispCharResource）と検索条件値を設定して
     * リストで返す。
     * 検索条件の値には、String型またはList<String>を設定可能<br>
     * メッセージIDは共通処理で展開する<br>
     *
     * ※各画面にOverrideして実装する
     *<br>
     * @return Excel出力用検索条件
     */
    protected List<BeanMap> getExportExcelSearchConditionList() {
        return null;
    }

    /**
     *
     * Excel出力用検索条件変換処理.<br>
     *<br>
     * 概要:<br>
     *   検索条件を文字列連結し、Excel出力用に変換する<br>
     *   [検索項目名:検索条件値]...<br>
     *   の形式に変換<br>
     *   検索条件がListの場合、,区切りで文字列連結する
     *<br>
     * @param _searchConditionList 検索条件
     * @return 検索条件文字列
     */
    private String convertExportExcelSearchCondition(final List<BeanMap> _searchConditionList) {
        StringBuffer ret = new StringBuffer();

        for (BeanMap searchCondition : _searchConditionList) {
            ret.append(FW00_19_Const.BRACKET_START_STR);
            // 表示名
            String labelMsgCd = searchCondition.get(MAP_KEY_EXPORT_EXCEL_SEARCH_CONDITION_NAME).toString();
            String labelName = CM_DisplayCharResourceUtil.getDisplayCharValue(this.cM_A03_SessionDto.ssn_CustomerCD,
                    this.cM_A03_SessionDto.ssn_UserLangCD, labelMsgCd);
            ret.append(labelName);

            ret.append(FW00_19_Const.COLON_STR);

            // データ
            Object objectValue = searchCondition.get(MAP_KEY_EXPORT_EXCEL_SEARCH_CONDITION_VALUE);
            String delimiter = FW00_19_Const.EMPTY_STR;
            if (objectValue instanceof List) {
                @SuppressWarnings("unchecked")
                List<String> valueList = (List<String>) objectValue;
                for (String value : valueList) {
                    ret.append(delimiter);
                    ret.append(value);
                    delimiter = FW00_19_Const.COMMA_STR;
                }
            } else {
                ret.append(objectValue.toString().trim());
            }
            ret.append(FW00_19_Const.BRACKET_END_STR);
        }

        return ret.toString();
    }

    /**
     *
     * Excelフォーマット取得.<br>
     *<br>
     * 概要:<br>
     * 出力するExcelのフォーマットを取得する<br>
     * ※各画面でフォーマットを設定する
     *<br>
     * @return Excelフォーマット
     */
    protected CM_ExcelFormat getExcelFormat() {
        return null;
    }

    /**
     *
     * 出力データ取得.<br>
     *<br>
     * 概要:<br>
     *   Excelに出力するデータ取得処理<br>
     *   各シートのフォーマット情報で指定されているデータを取得するメソッドをサービスから呼び出し、データを取得する
     *
     *<br>
     * @param _sheetFormatInfo シートフォーマット情報
     * @param _formMap フォーム情報
     * @return 出力データ
     */
    protected List<?> getExportData(final CM_ExcelSheetInfoDto _sheetFormatInfo, final BeanMap _formMap) {
        List<?> ret = null;

        try {
            Method method = this.getService().getClass().getMethod(_sheetFormatInfo.getGetDataMethodName(), new Class[]{BeanMap.class});
            ret = (List<?>) method.invoke(this.getService(), new Object[]{_formMap});
        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, FW00_19_Const.EMPTY_STR);
        }

        return ret;
    }

    /**
     *
     * 凡例データ設定.<br>
     *<br>
     * 概要:<br>
     *  Excelに出力する凡例のデータを設定する<br>
     *  各データのフォーマット情報で取得したメッセージCDを取得し、
     *  ログインユーザの言語にして設定する<br>
     *  凡例を動的にする場合は、このメソッドをOverrideして実装する
     *<br>
     * @param _sheetInfo 出力シート情報
     * @param _sheetFormatInfo シートフォーマット情報
     */
    protected void setLegend(final XSSFSheet _sheetInfo, final CM_ExcelSheetInfoDto _sheetFormatInfo) {
        int startRow = _sheetFormatInfo.getLegendStartRaw();
        int startCell = _sheetFormatInfo.getLegendStartCell();

        XSSFRow row =  null;
        XSSFCell cell = null;
        for (CM_ExcelDataInfoDto legedInfo : _sheetFormatInfo.getDataInfoList()) {
            row = _sheetInfo.getRow(startRow);
            if (CM_CommonUtil.isNullOrBlank(row)) {
                row = _sheetInfo.createRow(startRow);
            }
            cell = row.getCell(startCell);
            if (CM_CommonUtil.isNullOrBlank(cell)) {
                cell = row.createCell(startCell);
            }
            // 言語処理 displayCharに定義がなければ、そのまま設定する
            String legedName = CM_DisplayCharResourceUtil.getDisplayCharValue(this.cM_A03_SessionDto.ssn_CustomerCD,
                    this.cM_A03_SessionDto.ssn_UserLangCD, legedInfo.getLegendName());
            if (CM_CommonUtil.isNullOrBlank(legedName)) {
                legedName = legedInfo.getLegendName();
            }
            cell.setCellValue(legedName);
            cell.setCellType(XSSFCell.CELL_TYPE_STRING);
            startCell++;
        }
    }

    /**
     *
     * 検索条件データ設定.<br>
     *<br>
     * 概要:<br>
     *  Excelに出力する検索条件のデータを設定する<br>
     *<br>
     * @param _sheetInfo 出力シート情報
     * @param _sheetFormatInfo シートフォーマット情報
     * @param _searchCondition 検索条件文字列
     */
    protected void setExportSearchCondition(final XSSFSheet _sheetInfo, final CM_ExcelSheetInfoDto _sheetFormatInfo, final String _searchCondition) {
        int startRow = _sheetFormatInfo.getConditionStartRaw();
        int startCell = _sheetFormatInfo.getConditionStartCell();

        XSSFRow row =  null;
        XSSFCell cell = null;
        row = _sheetInfo.getRow(startRow);
        if (CM_CommonUtil.isNullOrBlank(row)) {
            row = _sheetInfo.createRow(startRow);
        }
        cell = row.getCell(startCell);
        if (CM_CommonUtil.isNullOrBlank(cell)) {
            cell = row.createCell(startCell);
        }

        cell.setCellValue(_searchCondition);
        cell.setCellType(XSSFCell.CELL_TYPE_STRING);
    }

    /**
     *
     * 出力データ設定.<br>
     *<br>
     * 概要:<br>
     *   Excelに出力するデータを設定する<br>
     *   取得したデータのObjectからデータフォーマット情報に設定したキーのフィールド名の値を取得し、
     *   シートに設定する
     *<br>
     * @param _exportDataList 出力データ
     * @param _wb 出力Book情報
     * @param _sheetInfo 出力シート情報
     * @param _sheetFormatInfo シートフォーマット情報
     * @throws ParseException フォーマットエラー
     */
    protected void setExportData(final List<?> _exportDataList, final XSSFWorkbook _wb, final XSSFSheet _sheetInfo,
            final CM_ExcelSheetInfoDto _sheetFormatInfo) throws ParseException {

        if (_exportDataList != null) {
            // 出力開始行設定
            int startRow = _sheetFormatInfo.getDataStartRaw();

            XSSFRow row =  null;
            XSSFCell cell = null;

            for (int i = 0; i < _exportDataList.size(); i++) {
                Object data = _exportDataList.get(i);
                // objectをBeanMapにし、データをキーで取得できるようにする
                BeanMap formMap = Beans.createAndCopy(BeanMap.class, data).execute();

                row = _sheetInfo.getRow(startRow);
                if (CM_CommonUtil.isNullOrBlank(row)) {
                    row = _sheetInfo.createRow(startRow);
                }

                // 出力開始列設定
                int startCell = _sheetFormatInfo.getDataStartCell();

                for (CM_ExcelDataInfoDto legedInfo : _sheetFormatInfo.getDataInfoList()) {
                    cell = row.getCell(startCell);
                    if (CM_CommonUtil.isNullOrBlank(cell)) {
                        cell = row.createCell(startCell);
                    }
                    int cellType = legedInfo.getCellType();
                    if (CM_CommonUtil.isNotNullOrBlank(formMap.get(legedInfo.getKey()))) {
                        switch (cellType) {
                            case CM_A07_ExcelCellType.CELL_TYPE_NUMERIC:
                                cell.setCellValue(Double.parseDouble(formMap.get(legedInfo.getKey()).toString()));
                                cell.setCellType(cellType);
                                break;
                            case CM_A07_ExcelCellType.CELL_TYPE_DATE:
                                if (formMap.get(legedInfo.getKey()) instanceof Timestamp) {
                                    Timestamp tmpData = (Timestamp) formMap.get(legedInfo.getKey());
                                    cell.setCellValue(new Date(tmpData.getTime()));
                                } else if (formMap.get(legedInfo.getKey()) instanceof Date) {
                                    cell.setCellValue((Date) formMap.get(legedInfo.getKey()));
                                } else {
                                    String tmpDate = formMap.get(legedInfo.getKey()).toString();
                                    SimpleDateFormat sdf = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT);
                                    cell.setCellValue(sdf.parse(tmpDate));
                                }
                                CreationHelper createHelper = _wb.getCreationHelper();
                                CellStyle cellStyle = _wb.createCellStyle();
                                short style = createHelper.createDataFormat().getFormat(CM_A04_Const.DATE_FORMAT);
                                cellStyle.setDataFormat(style);
                                cell.setCellStyle(cellStyle);
                                break;
                            default:
                                cell.setCellValue(formMap.get(legedInfo.getKey()).toString());
                                cell.setCellType(cellType);
                                break;
                        }

                    }
                    startCell++;
                }
                startRow++;
            }
        }

    }

    /**
     *
     * 検索条件クリア処理.<br>
     *<br>
     * 概要:<br>
     *  初期検索条件を取得し、検索条件の初期化を行う
     *<br>
     * @return jsp
     */
    @Execute(validator = false)
    public String clearSearchCondition() {
        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        // サービス初期化
        CM_ListBaseService service = this.getService();
        service.init(this.cM_A03_SessionDto);

        // 共通検索情報クリア
        this.clearComSearchCondition();

        // 各画面初期検索条件取得処理
        String ret = this.getInitSearchCondition(formMap);

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, null);

        return ret;
    }

    /**
     *
     * 初期検索条件取得処理.<br>
     *<br>
     * 概要:<br>
     *  初期検索条件取得処理
     *<br>
     * @param _formMap フォーム情報
     * @return jsp
     */
    protected String getInitSearchCondition(final BeanMap _formMap) {
        return null;
    }

    /**
     *
     * CSVダウンロードチェック処理.<br/>
     *<br/>
     * 概要:<br/>
     *  CSVダウンロード可否のチェックを行う。<br/>
     *<br/>
     * @return JSP名
     */
    @Execute(validator = false)
    public String checkCSVDownload() {

        // メソッド開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        // CSV出力処理開始
        this.getActionForm().hdnProcessExecFlg = CM_A04_Const.PROCESS_EXEC_CSV;

        // 処理開始
        this.getService().init(this.cM_A03_SessionDto);

        // フォーム情報をMapに格納
        BeanMap formMap = getCsvFormInfo();

        // 詳細検索条件情報を取得
        Map<String, Object> mapSearchCondInfo = this.getComDetailSearchInfo(this.getPageId(), this.getActionForm());

        // 日時情報更新処理
        this.setDisplayDateData(this.getActionForm());

        // CSVダウンロードチェック前処理
        this.beforeCheckCSVDownload(formMap, mapSearchCondInfo);

        // CSV入力チェック
        String validation = this.csvValidation(formMap, mapSearchCondInfo);
        if (CM_CommonUtil.isNotNullOrBlank(validation)) {
            // CSV出力処理完了
            this.getActionForm().hdnProcessExecFlg = CM_A04_Const.PROCESS_EXEC_NONE;
            return validation;
        }

        // CSVデータカウント数をチェック
        // 条件に該当する全件数取得を行う
        long csvCnt = this.getSearchCount(formMap, mapSearchCondInfo);

        String ret = this.checkCsvCount(csvCnt);

        // CSV出力処理完了
        this.getActionForm().hdnProcessExecFlg = CM_A04_Const.PROCESS_EXEC_NONE;

        // メソッド出力ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, ret);

        // JSPを返す
        return ret;
    }

    /**
     *
     * CSVダウンロード用入力チェック処理.<br/>
     *<br/>
     * 概要:<br/>
     *  CSVダウンロード用入力チェック処理を行う。<br/>
     *<br/>
     * @param _formMap Form情報
     * @param _mapSearchCondInfo 詳細検索情報
     * @return エラーAjaxJSPファイル
     */
    protected String csvValidation(final BeanMap _formMap, final Map<String, Object> _mapSearchCondInfo) {
        return null;
    }

    /**
     *
     * CSVダウンロード用Form情報取得処理.<br/>
     *<br/>
     * 概要:<br/>
     *  CSVダウンロード用のForm情報取得処理を行う。<br/>
     *<br/>
     * @return Form情報
     */
    protected BeanMap getCsvFormInfo() {
        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        // ソートキークリア
        formMap.put(FW01_14_ListForm.FW0114FORM_SORTKEY, null);

        return formMap;
    }

    /**
     *
     * CSVダウンロードチェック前処理.<br/>
     *<br/>
     * 概要:<br/>
     *  CSVダウンロードチェックの前処理を行う。<br/>
     *<br/>
     * @param _formMap Form情報
     * @param _mapSearchCondInfo 詳細検索情報
     */
    protected void beforeCheckCSVDownload(final BeanMap _formMap, final Map<String, Object> _mapSearchCondInfo) {
        return;
    }


}
