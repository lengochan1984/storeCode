package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link TblLoginHistoryEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class TblLoginHistoryEntityNames {

    /**
     * loginDatetimeのプロパティ名を返します。
     * 
     * @return loginDatetimeのプロパティ名
     */
    public static PropertyName<Timestamp> loginDatetime() {
        return new PropertyName<Timestamp>("loginDatetime");
    }

    /**
     * inputUserIdのプロパティ名を返します。
     * 
     * @return inputUserIdのプロパティ名
     */
    public static PropertyName<String> inputUserId() {
        return new PropertyName<String>("inputUserId");
    }

    /**
     * inputPasswdのプロパティ名を返します。
     * 
     * @return inputPasswdのプロパティ名
     */
    public static PropertyName<String> inputPasswd() {
        return new PropertyName<String>("inputPasswd");
    }

    /**
     * isSuccessのプロパティ名を返します。
     * 
     * @return isSuccessのプロパティ名
     */
    public static PropertyName<Boolean> isSuccess() {
        return new PropertyName<Boolean>("isSuccess");
    }

    /**
     * accessIpAderessのプロパティ名を返します。
     * 
     * @return accessIpAderessのプロパティ名
     */
    public static PropertyName<String> accessIpAderess() {
        return new PropertyName<String>("accessIpAderess");
    }

    /**
     * browserKindのプロパティ名を返します。
     * 
     * @return browserKindのプロパティ名
     */
    public static PropertyName<String> browserKind() {
        return new PropertyName<String>("browserKind");
    }

    /**
     * lastUpdProgのプロパティ名を返します。
     * 
     * @return lastUpdProgのプロパティ名
     */
    public static PropertyName<String> lastUpdProg() {
        return new PropertyName<String>("lastUpdProg");
    }

    /**
     * lastUpdTimのプロパティ名を返します。
     * 
     * @return lastUpdTimのプロパティ名
     */
    public static PropertyName<Timestamp> lastUpdTim() {
        return new PropertyName<Timestamp>("lastUpdTim");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _TblLoginHistoryNames extends PropertyName<TblLoginHistoryEntity> {

        /**
         * インスタンスを構築します。
         */
        public _TblLoginHistoryNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _TblLoginHistoryNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _TblLoginHistoryNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * loginDatetimeのプロパティ名を返します。
         *
         * @return loginDatetimeのプロパティ名
         */
        public PropertyName<Timestamp> loginDatetime() {
            return new PropertyName<Timestamp>(this, "loginDatetime");
        }

        /**
         * inputUserIdのプロパティ名を返します。
         *
         * @return inputUserIdのプロパティ名
         */
        public PropertyName<String> inputUserId() {
            return new PropertyName<String>(this, "inputUserId");
        }

        /**
         * inputPasswdのプロパティ名を返します。
         *
         * @return inputPasswdのプロパティ名
         */
        public PropertyName<String> inputPasswd() {
            return new PropertyName<String>(this, "inputPasswd");
        }

        /**
         * isSuccessのプロパティ名を返します。
         *
         * @return isSuccessのプロパティ名
         */
        public PropertyName<Boolean> isSuccess() {
            return new PropertyName<Boolean>(this, "isSuccess");
        }

        /**
         * accessIpAderessのプロパティ名を返します。
         *
         * @return accessIpAderessのプロパティ名
         */
        public PropertyName<String> accessIpAderess() {
            return new PropertyName<String>(this, "accessIpAderess");
        }

        /**
         * browserKindのプロパティ名を返します。
         *
         * @return browserKindのプロパティ名
         */
        public PropertyName<String> browserKind() {
            return new PropertyName<String>(this, "browserKind");
        }

        /**
         * lastUpdProgのプロパティ名を返します。
         *
         * @return lastUpdProgのプロパティ名
         */
        public PropertyName<String> lastUpdProg() {
            return new PropertyName<String>(this, "lastUpdProg");
        }

        /**
         * lastUpdTimのプロパティ名を返します。
         *
         * @return lastUpdTimのプロパティ名
         */
        public PropertyName<Timestamp> lastUpdTim() {
            return new PropertyName<Timestamp>(this, "lastUpdTim");
        }
    }
}
