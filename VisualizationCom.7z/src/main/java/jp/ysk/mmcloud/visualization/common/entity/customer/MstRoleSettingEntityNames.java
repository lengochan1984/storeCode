package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link MstRoleSettingEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/08/10 11:22:28")
public class MstRoleSettingEntityNames {

    /**
     * roleSidのプロパティ名を返します。
     * 
     * @return roleSidのプロパティ名
     */
    public static PropertyName<Integer> roleSid() {
        return new PropertyName<Integer>("roleSid");
    }

    /**
     * functionCdのプロパティ名を返します。
     * 
     * @return functionCdのプロパティ名
     */
    public static PropertyName<String> functionCd() {
        return new PropertyName<String>("functionCd");
    }

    /**
     * pageIdのプロパティ名を返します。
     * 
     * @return pageIdのプロパティ名
     */
    public static PropertyName<String> pageId() {
        return new PropertyName<String>("pageId");
    }

    /**
     * authSettingのプロパティ名を返します。
     * 
     * @return authSettingのプロパティ名
     */
    public static PropertyName<String> authSetting() {
        return new PropertyName<String>("authSetting");
    }

    /**
     * deleteFlagのプロパティ名を返します。
     * 
     * @return deleteFlagのプロパティ名
     */
    public static PropertyName<Boolean> deleteFlag() {
        return new PropertyName<Boolean>("deleteFlag");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _MstRoleSettingNames extends PropertyName<MstRoleSettingEntity> {

        /**
         * インスタンスを構築します。
         */
        public _MstRoleSettingNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _MstRoleSettingNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _MstRoleSettingNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * roleSidのプロパティ名を返します。
         *
         * @return roleSidのプロパティ名
         */
        public PropertyName<Integer> roleSid() {
            return new PropertyName<Integer>(this, "roleSid");
        }

        /**
         * functionCdのプロパティ名を返します。
         *
         * @return functionCdのプロパティ名
         */
        public PropertyName<String> functionCd() {
            return new PropertyName<String>(this, "functionCd");
        }

        /**
         * pageIdのプロパティ名を返します。
         *
         * @return pageIdのプロパティ名
         */
        public PropertyName<String> pageId() {
            return new PropertyName<String>(this, "pageId");
        }

        /**
         * authSettingのプロパティ名を返します。
         *
         * @return authSettingのプロパティ名
         */
        public PropertyName<String> authSetting() {
            return new PropertyName<String>(this, "authSetting");
        }

        /**
         * deleteFlagのプロパティ名を返します。
         *
         * @return deleteFlagのプロパティ名
         */
        public PropertyName<Boolean> deleteFlag() {
            return new PropertyName<Boolean>(this, "deleteFlag");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
