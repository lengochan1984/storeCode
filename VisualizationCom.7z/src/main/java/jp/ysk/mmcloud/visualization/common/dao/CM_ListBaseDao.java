/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/07/28| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.dao;

import java.util.List;
import java.util.Map;

import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSearchConditionEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSearchConditionEntityNames;
import jp.ysk.mmcloud.visualization.common.form.CM_ListForm;

import org.seasar.extension.jdbc.OrderByItem;
import org.seasar.extension.jdbc.OrderByItem.OrderingSpec;
import org.seasar.extension.jdbc.where.SimpleWhere;
import org.seasar.framework.beans.util.BeanMap;

/**
 *
 * 一覧がある基底クラスの共通Dao.<br>
 *<br>
 * 概要:<br>
 *  一覧がある基底クラスの共通Daoクラス
 *<br>
 */
public abstract class CM_ListBaseDao extends CM_BaseDao {

    /**
     *
     * パラメータ設定処理.<br>
     *<br>
     * 概要:<br>
     *  SQL文のパラメータをセットする
     *<br>
     * @param _formInfo form情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return パラメータ情報
     */
    protected BeanMap setCommonParam(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {

        BeanMap param = _formInfo;

        String sortKey = null;
        String sortOrder = null;
        if (CM_CommonUtil.isNotNullOrBlank(_formInfo)) {
            // ソートキー
            sortKey = (String) _formInfo.get(CM_ListForm.FW0114FORM_SORTKEY);
            // ソート順
            sortOrder = (String) _formInfo.get(CM_ListForm.FW0114FORM_SORTORDER);
        }

        // ソートキー
        if (CM_CommonUtil.isNullOrBlank(sortKey)) {
            param.put(CM_ListForm.FW0114FORM_SORTKEY, null);
        } else {
            param.put(CM_ListForm.FW0114FORM_SORTKEY, sortKey);
        }

        // ソート順
        if (CM_CommonUtil.isNullOrBlank(sortOrder)) {
            param.put(CM_ListForm.FW0114FORM_SORTORDER, null);
        } else {
            param.put(CM_ListForm.FW0114FORM_SORTORDER, sortOrder);
        }

        // 詳細検索条件情報を追加
        if (CM_CommonUtil.isNotNullOrBlank(_mapSearchCondInfo)) {
            param.putAll(_mapSearchCondInfo);
        }

        return param;
    }

    /**
     *
     * 検索条件記憶削除.<br>
     *<br>
     * 概要:<br>
     *   ユーザSID、画面IDを元に検索条件記憶テーブルを削除する
     *<br>
     * @param _userSid ユーザSID
     * @param _pageId 画面ID
     * @return 削除件数
     */
    public int deleteSearchCondition(final Integer _userSid, final String _pageId) {
        CM_LoggerUtil.outputDaoInputParamLog("_userSid", _userSid);
        CM_LoggerUtil.outputDaoInputParamLog("_pageId", _pageId);

        BeanMap param = new BeanMap();
        param.put(TrSearchConditionEntityNames.userSid().toString(), _userSid);
        param.put(TrSearchConditionEntityNames.pageId().toString(), _pageId);

        int ret = this.jdbcManager.updateBySqlFile(BASE_SQL_PATH_COMM + "deleteTblSearchCondition.sql", param).execute();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

    /**
     *
     * 検索条件登録.<br>
     *<br>
     * 概要:<br>
     *  検索条件登録処理
     *<br>
     * @param _entity 検索条件登録Entity
     * @return 登録件数
     */
    public int insertTblSearchCondition(final TrSearchConditionEntity _entity) {
        CM_LoggerUtil.outputDaoInputParamLog();

        int ret = this.jdbcManager.insert(_entity).execute();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;

    }

    /**
     *
     *　検索条件記憶テーブル取得.<br>
     *<br>
     * 概要:<br>
     *   検索条件記憶テーブルの取得処理
     *<br>
     * @param _userSid ユーザSID
     * @param _pageId 画面ID
     * @return 検索条件記録テーブル一覧
     */
    public List<TrSearchConditionEntity> selectTblSearchCondition(final Integer _userSid, final String _pageId) {
        CM_LoggerUtil.outputDaoInputParamLog("_userSid", _userSid);
        CM_LoggerUtil.outputDaoInputParamLog("_pageId", _pageId);

        SimpleWhere where = new SimpleWhere();
        where.eq(TrSearchConditionEntityNames.userSid(), _userSid);
        where.eq(TrSearchConditionEntityNames.pageId(), _pageId);

        OrderByItem orderItem = new OrderByItem(TrSearchConditionEntityNames.conditionNum(), OrderingSpec.ASC);

        List<TrSearchConditionEntity> ret = this.jdbcManager.from(TrSearchConditionEntity.class)
                .where(where).orderBy(orderItem).getResultList();

        CM_LoggerUtil.outputDaoOutputParamLog(ret);

        return ret;
    }

}
