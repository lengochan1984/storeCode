package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 環境マスタ
 * 
 */
@Entity
@Table(name = "sys_env")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class SysEnvEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 環境CD */
    @Id
    @Column(length = 20, nullable = false, unique = false)
    public String envCd;

    /** 項目CD */
    @Id
    @Column(length = 64, nullable = false, unique = false)
    public String itemCd;

    /** 名称 */
    @Column(length = 128, nullable = true, unique = false)
    public String name;

    /** 略称 */
    @Column(length = 64, nullable = true, unique = false)
    public String abbName;

    /** 名称項目CD : ★使用禁止（多言語対応時に利用予定）
役割名称の名称コード
名称マスタの名称種別="role_name"とリンク。 */
    @Column(length = 64, nullable = true, unique = false)
    public String nameItemCd;

    /** デフォルトフラグ : 1:デフォルト
0:デフォルトでない
※1以外はデフォルトでないとみなす。 */
    @Column(length = 1, nullable = false, unique = false)
    public String defaultFlag;

    /** 表示順 : データポイントコードの表示順 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer displayOrder;

    /** 備考 */
    @Column(length = 300, nullable = true, unique = false)
    public String remark;

    /** 削除フラグ : true：有効、false：無効 */
    @Column(length = 1, nullable = false, unique = false)
    public Boolean deleteFlag;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
