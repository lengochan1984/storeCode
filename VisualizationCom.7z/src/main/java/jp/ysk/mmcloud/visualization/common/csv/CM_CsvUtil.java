/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2005 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+=======================================+========+==============
 *  DATE      | Comments                              | Rev    | SIGN
 * ===========+=======================================+========+==============
 *  2014/12/16| <20000-020> 変更仕様No.8              | 3.00.00| US)萩尾
 *  2015/02/20| <20000-037>　仕様変更No.38            | 3.00.00| YSK)植山
 *  2015/06/25| <30003-035> 変更仕様No.13             | 3.01.00| US)楢崎
 *  2015/07/08| <30003-037> 変更仕様No.23             | 3.01.00| US)楢崎
 *  2015/07/16| <30003-042> 故障苦情No.30003-035      | 3.01.00| US)楢崎
 *  2015/08/18| <30003-061> 変更仕様No.34             | 3.01.00| US)萩尾
 *  2015/12/03| <40000-019> Ver.4.00.00 変更仕様No.19 | 4.00.00| US)楢崎
 *  2016/01/25| <40000-028> 変更仕様No.28             | 4.00.00| US)安永
 *  2016/04/18| <40000-043> PGレビュー指摘事項        | 4.01.00| US)萩尾
 *  2016/08/03| <C1.01> 指図一覧対応                  | C1.01  | US)楢崎
 * -----------+---------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.csv;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.csv.FW01_10_CSVFormat;
import jp.ysk.fw.util.FW01_02_CommonCheckUtil;
import jp.ysk.mmcloud.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.csv.CM_Csv_Const;
import jp.ysk.mmcloud.common.csv.CM_Csv_Error_Message;
import jp.ysk.mmcloud.common.csv.CM_Csv_Upload_Result;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.entity.customer.SysEnvEntityNames;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.common.util.CM_DisplayCharResourceUtil;
import jp.ysk.mmcloud.common.util.CM_HeaderUtil;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.common.util.CM_MessageResourceUtil;
import jp.ysk.mmcloud.common.util.CM_MessageUtil;
import jp.ysk.mmcloud.common.util.CM_SysEnvDataUtil;
import jp.ysk.mmcloud.visualization.common.csv.dto.CM_CsvDatetimeDto;

import org.apache.struts.upload.FormFile;
import org.seasar.framework.beans.util.BeanMap;

import au.com.bytecode.opencsv.CSVParser;
import au.com.bytecode.opencsv.CSVReader;

/**
 * CSVユーティリティ処理.<br>
 *<br>
 * 概要:<br>
 *   CSVユーティリティクラス
 *<br>
 */
public class CM_CsvUtil {

    /**
     * 項目コード.
     */
    private static final String ERROR_COUNT_ITEM_CD = "100";

    /**
     * 文字コード.
     */
    private static final String CHAR_SET = FW00_19_Const.FWCST_CD_CSV;


    /**
     * プラス行数.
     */
    public static final int LINE_NUM = 4;

    /**
     * CSVコンバート最大回数（CSVのフォーマットを何世代前まで取込可能かを指定する）.
     */
    private static final int CSV_CONVERT_MAX = 1;

    /**
     *
     * コンストラクタ.
     *
     */
    protected CM_CsvUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     * CSVインポートファイルの制限チェック.
     *
     * @param _formFile    インポートファイル
     * @param _sessitonDao セッション情報
     * @return エラーメッセージ
     */
    public static String checkCsvFileLimit(final FormFile _formFile, final CM_A03_SessionDto _sessitonDao) {

        String strErrorMsg = FW00_19_Const.EMPTY_STR;

        // ファイルサイズ
        if (_formFile == null || _formFile.getFileSize() > CM_Csv_Const.UPLOAD_CSV_FILE_MAX_SIZE) {
            strErrorMsg = CM_MessageResourceUtil.getMessageValueParam(_sessitonDao.ssn_CustomerCD, _sessitonDao.ssn_UserLangCD, "MMCMCM00000_021", null);
        }

        return strErrorMsg;
    }

    /**
     * CSVインポートファイルを読み込み.
     *
     * @param _input
     *            インポートCSVファイル
     * @return CSVファイル
     */
    public static List<String[]> readCsvFile(final InputStream _input) {

        List<String[]> allLines = new ArrayList<String[]>();
        final int hederLineNum = 3;

        try {

            InputStreamReader ireader = new InputStreamReader(_input, CHAR_SET);
            CSVReader reader = new CSVReader(ireader,
                    CSVParser.DEFAULT_SEPARATOR,
                    CSVParser.DEFAULT_QUOTE_CHARACTER, hederLineNum);

            allLines = reader.readAll();

            reader.close();

        } catch (Exception e) {
            throw new FW00_12_BusinessException("");
        }

        return allLines;
    }

    /**
     * CSVインポートにてエラー発生後に処理する件数を取得.
     *
     * @param _sessionDto
     *            セッション情報
     * @return エラー処理件数
     */
    public static Integer getErrorCount(final CM_A03_SessionDto _sessionDto) {
        Integer errorCount = 0;

        BeanMap beanMap = CM_SysEnvDataUtil.selectSysEnv(_sessionDto,
                CM_A04_Const.SYS_ENV_MST_ENV_CD.CSV_ERROR_COUNT, ERROR_COUNT_ITEM_CD);

        String strErrorCount = beanMap.get(SysEnvEntityNames.name().toString()).toString();

        errorCount = Integer.valueOf(strErrorCount);

        return errorCount;
    }

    /**
     * CSV1レコードの配列をBeanMapに展開.
     *
     * @param _line
     *            CSV1レコード情報
     * @param _headerList
     *            CSVインポートヘッダ情報
     * @return 展開用BeanMapデータ
     */
    public static BeanMap convertBeanMap(final String[] _line, final List<String> _headerList) {

        BeanMap beanMap = new BeanMap();
        for (int i = 0; i < _headerList.size(); i++) {
            beanMap.put(_headerList.get(i), _line[i]);
        }

        return beanMap;
    }

    /**
     *
     * CSVエラーメッセージ取得.<br>
     * <br>
     * 概要:<br>
     * CSVエラーメッセージ取得<br>
     *
     * @param _index 順番
     * @param _msgID メッセージID
     * @param _param メッセージパラメータ
     * @param _sessionDto セッション情報
     * @return メッセージ
     */
    public static CM_Csv_Error_Message getCsvErrorMessage(final int _index, final String _msgID,
            final String[] _param, final CM_A03_SessionDto _sessionDto) {
        return new CM_Csv_Error_Message(String.valueOf(_index),
                CM_MessageResourceUtil.getMessageValueParam(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, _msgID, _param));
    }

    /**
     *
     * CSVエラーメッセージ取得.<br>
     * <br>
     * 概要:<br>
     * CSVエラーメッセージ取得<br>
     *
     * @param _index 順番
     * @param _msg メッセージ
     * @return メッセージ
     */
    public static CM_Csv_Error_Message getCsvErrorMessage(final int _index, final String _msg) {
        return new CM_Csv_Error_Message(String.valueOf(_index), _msg);
    }

    /**
     *
     * エラーメッセージ設定.<br>
     * <br>
     * 概要:<br>
     * エラーメッセージ設定 <br>
     *
     * @param _idx 順番
     * @param _msgId メッセージID
     * @param _param メッセージパラメータ
     * @param _csvUploadResult CM_Csv_Upload_Result
     * @param _sessionDto セッション情報
     */
    public static void setErrorMsg(final int _idx, final String _msgId, final String[] _param,
            final CM_Csv_Upload_Result _csvUploadResult, final CM_A03_SessionDto _sessionDto) {
        // 最大エラー処理数を取得
        int maxErrorCount = CM_CsvUtil.getErrorCount(_sessionDto);
        if (maxErrorCount > _csvUploadResult.getErrorMessageList().size()) {
            _csvUploadResult.getErrorMessageList().add(getCsvErrorMessage(_idx + LINE_NUM, _msgId, _param, _sessionDto));
        }
        _csvUploadResult.setIntResult(CM_A04_Const.CSV_RESULT.FAILED);
    }

    /**
     *
     * エラーメッセージ設定.<br>
     * <br>
     * 概要:<br>
     * エラーメッセージ設定 <br>
     *
     * @param _idx 順番
     * @param _msg メッセージ
     * @param _csvUploadResult CM_Csv_Upload_Result
     * @param _sessionDto セッション情報
     */
    public static void setErrorMsg(final int _idx, final String _msg,
            final CM_Csv_Upload_Result _csvUploadResult, final CM_A03_SessionDto _sessionDto) {
        // 最大エラー処理数を取得
        int maxErrorCount = CM_CsvUtil.getErrorCount(_sessionDto);
        if (maxErrorCount > _csvUploadResult.getErrorMessageList().size()) {
            _csvUploadResult.getErrorMessageList().add(getCsvErrorMessage(_idx + LINE_NUM, _msg));
        }
        _csvUploadResult.setIntResult(CM_A04_Const.CSV_RESULT.FAILED);
    }

    /**
     *
     * 必須エラーメッセージ設定.<br>
     * <br>
     * 概要:<br>
     * 必須エラーメッセージ設定 <br>
     *
     * @param _idx 順番
     * @param _resourceKey リソースキー
     * @param _csvUploadResult CM_Csv_Upload_Result
     * @param _sessionDto セッション情報
     */
    public static void setEmptyErrorMsg(final int _idx, final String _resourceKey,
            final CM_Csv_Upload_Result _csvUploadResult, final CM_A03_SessionDto _sessionDto) {
        // 必須エラーメッセージを取得
        String strErrorMes = CM_MessageUtil.getEmptyErrorMessage(_sessionDto, _resourceKey);

        // 取得したメッセージをセット
        setErrorMsg(_idx, strErrorMes, _csvUploadResult, _sessionDto);
    }

    /**
     *
     * 必須エラーメッセージ設定.<br>
     * <br>
     * 概要:<br>
     * 必須エラーメッセージ設定 <br>
     *
     * @param _idx 順番
     * @param _itemName 項目名
     * @param _csvUploadResult CM_Csv_Upload_Result
     * @param _sessionDto セッション情報
     */
    public static void setEmptyErrorMsgByItemName(final int _idx, final String _itemName,
            final CM_Csv_Upload_Result _csvUploadResult, final CM_A03_SessionDto _sessionDto) {
        // 置換用の文字列リストを作成
        List<String> param = new ArrayList<String>();
        param.add(_itemName);

        // 取得したメッセージをセット
        String strErrorMes = CM_MessageUtil.getEmptyErrorMessage(_sessionDto, param);
        setErrorMsg(_idx, strErrorMes, _csvUploadResult, _sessionDto);
    }

    /**
     *
     * 桁数上限エラーメッセージ設定.<br>
     * <br>
     * 概要:<br>
     * 桁数上限エラーメッセージ設定 <br>
     *
     * @param _idx 順番
     * @param _maxLength
     * @param _maxLength 桁数上限値
     * @param _itemName 項目名
     * @param _csvUploadResult CM_Csv_Upload_Result
     * @param _sessionDto セッション情報
     */
    public static void setLengthUpperErrorMsgByItemName(final int _idx, final int _maxLength, final String _itemName,
            final CM_Csv_Upload_Result _csvUploadResult, final CM_A03_SessionDto _sessionDto) {
        // 取得したメッセージをセット
        String strErrorMes = CM_MessageUtil.getLengthUpperErrorMessage(_sessionDto, _itemName, _maxLength);
        setErrorMsg(_idx, strErrorMes, _csvUploadResult, _sessionDto);
    }

    /**
     *
     * 禁則文字チェック.<br>
     * <br>
     * 概要:<br>
     * 禁則文字チェック <br>
     *
     * @param _idx インディクス
     * @param _strValue チェック対象の文字列
     * @param _arrForbidStr 禁則文字
     * @param _resourceKey リソースキー(DisplayCharResourceのメッセージIDのみ）
     * @param _csvUploadResult 処理結果
     * @param _sessionDto セッション情報
     * @return チェック結果(禁則文字を含む場合はfalse)
     */
    public static boolean checkForbidChar(final int _idx, final String _strValue, final String[] _arrForbidStr,
            final String _resourceKey, final CM_Csv_Upload_Result _csvUploadResult, final CM_A03_SessionDto _sessionDto) {

        boolean ret = true;

        // 禁則文字の存在チェック
        String forbidChar = CM_CommonUtil.checkForbidCharExists(_strValue, _arrForbidStr);

        // 禁則文字を含む場合、エラーメッセージを取得
        if (CM_CommonUtil.isNotNullOrBlank(forbidChar)) {
            String strErrorMes = CM_MessageUtil.getForibidCharErrorMessage(_sessionDto, _resourceKey, forbidChar);
            setErrorMsg(_idx, strErrorMes, _csvUploadResult, _sessionDto);

            ret = false;
        }

        return ret;
    }

    /**
     *
     * 禁則文字チェック.<br>
     * <br>
     * 概要:<br>
     * 禁則文字チェック <br>
     *
     * @param _idx インディクス
     * @param _strValue チェック対象の文字列
     * @param _itemName 項目名(メッセージIDを元と言語を元に変換済みを指定)
     * @param _arrForbidStr 禁則文字
     * @param _csvUploadResult 処理結果
     * @param _sessionDto セッション情報
     * @return チェック結果(禁則文字を含む場合はfalse)
     */
    public static boolean checkForbidChar(final int _idx, final String _strValue, final String _itemName, final String[] _arrForbidStr,
            final CM_Csv_Upload_Result _csvUploadResult, final CM_A03_SessionDto _sessionDto) {

        boolean ret = true;

        // 禁則文字の存在チェック
        String forbidChar = CM_CommonUtil.checkForbidCharExists(_strValue, _arrForbidStr);

        // 禁則文字を含む場合、エラーメッセージを取得
        if (CM_CommonUtil.isNotNullOrBlank(forbidChar)) {
            String strErrorMes = CM_MessageUtil.getForibidCharErrorMessageByItemName(_sessionDto, _itemName, forbidChar);
            setErrorMsg(_idx, strErrorMes, _csvUploadResult, _sessionDto);

            ret = false;
        }

        return ret;
    }

    /**
     * CSV全レコードの配列をBeanMapに展開.
     *
     * @param _allCsvLines CSV全レコード情報
     * @param _headerInfo CSVインポートヘッダ情報
     * @return 展開用BeanMapデータリスト
     */
    public static List<BeanMap> convertCsvData(final List<String[]> _allCsvLines, final List<String> _headerInfo) {
        List<BeanMap> result = new ArrayList<BeanMap>();

        for (String[] line : _allCsvLines) {
            BeanMap tmpBeanMap = CM_CsvUtil.convertBeanMap(line, _headerInfo);
            result.add(tmpBeanMap);
        }

        return result;
    }


    /**
     * CSVヘッダ情報取得.<br>
     * <br>
     * 概要:<br>
     *  CSVヘッダ情報のキーと項目名をMapで取得
     * <br>
     *
     * @param _format CSVフォーマット
     * @param _session セッション情報
     * @return ヘッダ情報
     */
    public static Map<String, String> getCsvHeaderResourceInfo(
            final FW01_10_CSVFormat _format, final CM_A03_SessionDto _session) {
        Map<String, String> headerInfoMap = new HashMap<String, String>();

        List<String[]> headerInfo = _format.getHeader(CM_Csv_Const.AREA_KEY);

        for (String[] itemInfo : headerInfo) {
            String itemName = CM_DisplayCharResourceUtil.getDisplayCharValue(
                    _session.ssn_CustomerCD, _session.ssn_UserLangCD, itemInfo[1]);
            headerInfoMap.put(itemInfo[0], itemName);
        }

        return headerInfoMap;
    }

    /**
     *
     * リスト内容重複チェック.<br>
     *<br>
     * 概要:<br>
     *   リスト内容重複チェック.
     *<br>
     * @param _param チェック対象
     * @return 重複フラグ
     */
    public static boolean checkCcontains(final List<String> _param) {
        HashSet<String> hs = new HashSet<String>();
        for (String item : _param) {

            if (hs.contains(item)) {
                return true;
            } else {
                hs.add(item);
            }
        }

        return false;
    }



    /**
     *
     * {操作フラグが全部空であるかどうかチェック}.<br>
     *<br>
     * 概要:<br>
     *   {操作フラグが全部空であるかどうかチェック}
     *<br>
     * @param _data CSVデータ
     * @param _csvUploadResult 取込結果
     * @param _sessionDto セッション情報
     * @return 処理結果
     */
    public static boolean checkOperation(final List<String[]> _data, final CM_Csv_Upload_Result _csvUploadResult, final CM_A03_SessionDto _sessionDto) {
        if (_data == null || _data.isEmpty()) {
            _csvUploadResult.setIntResult(CM_A04_Const.CSV_RESULT.OPERATION_EMPTY);
            _csvUploadResult.setErrorMessage(CM_MessageResourceUtil.getMessageValue(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, "MMCMCM00000_042"));
            return false;
        }
        boolean exists = true;
        for (String[] line : _data) {

            if (exists && !CM_CommonUtil.isNullOrBlank(line[0])) {
                exists = false;
            }
            if (line[0] != null) {
                line[0] = line[0].toUpperCase();
            } else {
                line[0] = FW00_19_Const.EMPTY_STR;
            }

        }

        // 操作フラグが全部空の場合
        if (exists) {
            _csvUploadResult.setIntResult(CM_A04_Const.CSV_RESULT.OPERATION_EMPTY);
            _csvUploadResult.setErrorMessage(CM_MessageResourceUtil.getMessageValue(_sessionDto.ssn_CustomerCD, _sessionDto.ssn_UserLangCD, "MMCMCM00000_041"));
        }
        return exists;
    }

    /**
     * テキスト必須チェック.<br>
     * <br>
     * 概要:<br>
     * テキスト入力の必須チェック <br>
     *
     * @param _lineIndex CSV行番号
     * @param _strValue チェック対象の文字列
     * @param _resourceKey リソースキー
     * @param _result アップロード結果
     * @param _sessionDto セッション情報
     * @return チェック結果
     */
    public static boolean checkNecessary(final int _lineIndex, final String _strValue,
            final String _resourceKey, final CM_Csv_Upload_Result _result, final CM_A03_SessionDto _sessionDto) {

        if (CM_CommonUtil.isNullOrBlank(_strValue)) {
            // 必須のためエラー
            setEmptyErrorMsg(_lineIndex, _resourceKey, _result, _sessionDto);
            return false;
        }
        return true;
    }

    /**
     * テキスト必須チェック.<br>
     * <br>
     * 概要:<br>
     * テキスト入力の必須チェック <br>
     *
     * @param _lineIndex CSV行番号
     * @param _beanMap チェック対象情報
     * @param _checkKey チェック対象キー
     * @param _resourceKey リソースキー
     * @param _result アップロード結果
     * @param _sessionDto セッション情報
     * @return チェック結果
     */
    public static boolean checkNecessary(final int _lineIndex, final BeanMap _beanMap,
            final String _checkKey, final String _resourceKey, final CM_Csv_Upload_Result _result, final CM_A03_SessionDto _sessionDto) {
        if (!_beanMap.containsKey(_checkKey)) {
            // 必須のためエラー
            setEmptyErrorMsg(_lineIndex, _resourceKey, _result, _sessionDto);
            return false;
        }

        String param = (String) _beanMap.get(_checkKey);

        if (CM_CommonUtil.isNullOrBlank(param)) {
            // 必須のためエラー
            setEmptyErrorMsg(_lineIndex, _resourceKey, _result, _sessionDto);
            return false;
        }
        return true;
    }

    /**
     * テキスト必須チェック.<br>
     * <br>
     * 概要:<br>
     * テキスト入力の必須チェック <br>
     *
     * @param _lineIndex CSV行番号
     * @param _strValue チェック対象の文字列
     * @param _itemName 項目名
     * @param _result アップロード結果
     * @param _sessionDto セッション情報
     * @return チェック結果
     */
    public static boolean checkNecessaryByItemName(final int _lineIndex, final String _strValue,
            final String _itemName, final CM_Csv_Upload_Result _result, final CM_A03_SessionDto _sessionDto) {

        if (CM_CommonUtil.isNullOrBlank(_strValue)) {
            // 必須のためエラー
            setEmptyErrorMsgByItemName(_lineIndex, _itemName, _result, _sessionDto);
            return false;
        }
        return true;
    }

    /**
     *
     * 桁数チェック（上限）.<br>
     *<br>
     * 概要:<br>
     *   桁数チェック（上限）
     *<br>
     * @param _lineIndex CSV行番号
     * @param _strValue チェック文字列
     * @param _itemName 項目名
     * @param _maxLength 桁数上限値
     * @param _result アップロード結果
     * @param _sessionDto セッション情報
     * @return チェック結果
     */
    public static boolean checkLengthUpperByItemName(final int _lineIndex, final String _strValue, final int _maxLength,
            final String _itemName, final CM_Csv_Upload_Result _result, final CM_A03_SessionDto _sessionDto) {

        if (!FW01_02_CommonCheckUtil.checkLengthUpper(_strValue, _maxLength)) {
            // 桁数上限オーバーのためエラー
            setLengthUpperErrorMsgByItemName(_lineIndex, _maxLength, _itemName, _result, _sessionDto);
            return false;
        }
        return true;
    }

    /**
     *
     * 削除フラグチェック.<br>
     *<br>
     * 概要:<br>
     *   削除フラグチェック
     *<br>
     * @param _lineIndex CSV行番号
     * @param _strValue チェック文字列
     * @param _result アップロード結果
     * @param _sessionDto セッション情報
     * @return チェック結果
     */
    public static boolean checkDeleteFlag(final int _lineIndex, final String _strValue,
            final CM_Csv_Upload_Result _result, final CM_A03_SessionDto _sessionDto) {

        boolean ret = true;
        // 必須チェック
        if (!checkNecessary(_lineIndex, _strValue, "MMCDCA000080_005", _result, _sessionDto)) {
            return false;
        }

        if (!checkDeleteFlagLabel(_strValue)) {
            // true, false以外はエラー
            String strErrorMes = CM_MessageUtil.getDeleteFlagErrorMessage(_sessionDto);
            setErrorMsg(_lineIndex, strErrorMes, _result, _sessionDto);
            return false;
        }

        return ret;
    }

    /**
     *
     * 削除フラグチェック.<br>
     *<br>
     * 概要:<br>
     *   削除フラグチェック
     *<br>
     * @param _lineIndex CSV行番号
     * @param _strValue チェック文字列
     * @param _resourceKey リソースキー
     * @param _result アップロード結果
     * @param _sessionDto セッション情報
     * @return チェック結果
     */
    public static boolean checkDeleteFlag(final int _lineIndex, final String _strValue,
            final String _resourceKey, final CM_Csv_Upload_Result _result, final CM_A03_SessionDto _sessionDto) {

        boolean ret = true;

        // 必須チェック
        if (!checkNecessary(_lineIndex, _strValue, _resourceKey, _result, _sessionDto)) {
            return false;
        }

        if (!checkDeleteFlagLabel(_strValue)) {
            // true, false以外はエラー
            String strErrorMes = CM_MessageUtil.getIncorrectValueMessage(_sessionDto, _resourceKey);
            setErrorMsg(_lineIndex, strErrorMes, _result, _sessionDto);
            return false;
        }

        return ret;
    }

    /**
     *
     * 削除フラグ整合性チェック.<br>
     *<br>
     * 概要:<br>
     *   削除フラグ整合性チェック
     *<br>
     * @param _strValue チェック文字列
     * @return チェック結果
     */
    private static boolean checkDeleteFlagLabel(final String _strValue) {

        boolean ret = false;

        switch (_strValue.toUpperCase()) {
            // 入力値が "TRUE" または "FALSE" のとき、trueを返す
            case CM_A04_Const.BOOLEAN_FLG.TRUE:
            case CM_A04_Const.BOOLEAN_FLG.FALSE:
                ret = true;
                break;
            default:
                break;
        }

        return ret;
    }

    /**
     *
     * CSVファイル情報の行を読み込み.<br>
     *<br>
     * 概要:<br>
     *   CSVファイル情報（ファイル名・出力日時・バージョン等）の行を読み込む処理
     *<br>
     * @param _input インポートCSVファイル
     * @param _sessionDto セッション情報
     * @return CSVファイル情報
     */
    public static String[] readFileInfo(final InputStream _input, final CM_A03_SessionDto _sessionDto) {
        final int hederLineNum = 1;

        String[] csvData = new String[]{};

        // CSVヘッダ情報読込
        try {

            InputStreamReader ireader = new InputStreamReader(_input, CHAR_SET);
            CSVReader reader = new CSVReader(ireader,
                    CSVParser.DEFAULT_SEPARATOR,
                    CSVParser.DEFAULT_QUOTE_CHARACTER, hederLineNum);

            // 1行のみ読込
            csvData = reader.readNext();

            reader.close();
        } catch (Exception e) {
            CM_LoggerUtil.outputErrorLog(_sessionDto, e);
            throw new FW00_12_BusinessException("");
        }

        return csvData;
    }

    /**
     *
     * CSVのシステムバージョンを取得.<br>
     *<br>
     * 概要:<br>
     *   アップロードされたCSVのシステムバージョンをCSVファイル内の項目から取得する
     *<br>
     * @param _csvLineData CSV行データ
     * @param _csvFormat CSVフォーマット
     * @return システムバージョン
     */
    public static String getCsvSystemVersion(final String[] _csvLineData, final FW01_10_CSVFormat _csvFormat) {
        List<String[]> fileInfo = _csvFormat.getHeader(CM_Csv_Const.AREA_KEY_INFO_AREA);
        int versionIndex = 0;
        for (int i = 0; i < fileInfo.size(); i++) {
            if (CM_Csv_Const.VERSION.equals(fileInfo.get(i)[0])) {
                versionIndex = i;
                break;
            }
        }

        String version =  FW00_19_Const.EMPTY_STR;
        if (_csvLineData.length > versionIndex) {
            version = _csvLineData[versionIndex];
        }

        return version;
    }

    /**
     *
     * CSVファイル情報の行からシステムバージョンを取得.<br>
     *<br>
     * 概要:<br>
     *   CSVファイル情報（ファイル名・出力日時・バージョン等）の行を読み込み、システムバージョンを取得する
     *<br>
     * @param _csvFormat CSVフォーマット
     * @param _input インポートCSVファイル
     * @param _sessionDto セッション情報
     * @return システムバージョン
     */
    public static String getCsvSystemVersion(final FW01_10_CSVFormat _csvFormat, final InputStream _input, final CM_A03_SessionDto _sessionDto) {


        String[] csvData = readFileInfo(_input, _sessionDto);

        String version = getCsvSystemVersion(csvData, _csvFormat);

        return version;
    }

    /**
     *
     * 現在のシステムバージョンと一致しているかチェック.<br>
     *<br>
     * 概要:<br>
     *   現在のシステムバージョンと一致しているかをチェックする処理
     *<br>
     * @param _csvSystemVersion CSVシステムバージョン
     * @return true:現システムバージョンと一致 false:現システムバージョンと不一致
     */
    public static boolean checkCsvNowSystemVersion(final String _csvSystemVersion) {

        return CM_HeaderUtil.getDisplaySystemVersion().equals(_csvSystemVersion);
    }

    /**
     *
     * バージョンを数値に変換.<br>
     *<br>
     * 概要:<br>
     *   バージョンを.を除去し数値に変換
     *<br>
     * @param _version バージョン
     * @param _sessionDto セッション情報
     * @return バージョンの数値
     */
    public static Long parseLongVersion(final String _version, final CM_A03_SessionDto _sessionDto) {
        Long ret = null;

        // バージョンから.を除去
        String tmpVersion = _version.replace(FW00_19_Const.DOT_STR, FW00_19_Const.EMPTY_STR);

        try {
            // 数値に置き換え
            ret = Long.parseLong(tmpVersion);
        } catch (Exception e) {
            CM_LoggerUtil.outputErrorLog(_sessionDto, e);
        }

        if (CM_CommonUtil.isNullOrBlank(ret)) {
            ret = Long.parseLong(CM_HeaderUtil.getDisplaySystemVersion().replace(FW00_19_Const.DOT_STR, FW00_19_Const.EMPTY_STR));
        }

        return ret;
    }

    /**
     *
     * フォーマットの変更が発生したバージョンを取得する.<br>
     *<br>
     * 概要:<br>
     *    アップロードしたCSVのバージョンを元にフォーマットの変更が発生したバージョンを取得する
     *<br>
     * @param _convertVersionList コンバート対象となる変更バージョン一覧
     * @return フォーマットの変更が発生したバージョン
     */
    public static String getConvertCsvVersion(final List<String> _convertVersionList) {

        String convertCsvVersion = FW00_19_Const.EMPTY_STR;

        if (_convertVersionList != null && _convertVersionList.size() > 0) {
            // コンバート対象が取得できた場合、最初の1件を設定
            convertCsvVersion = _convertVersionList.get(0);
        } else {
            // コンバート対象が取得できない場合、現在のシステムバージョンを設定
            convertCsvVersion = CM_HeaderUtil.getDisplaySystemVersion();
        }

        return convertCsvVersion;
    }
    /**
     *
     * コンバート対象となる変更バージョンのリスト取得.<br>
     *<br>
     * 概要:<br>
     *   コンバート対象となる変更バージョンのリストを取得
     *<br>
     * @param _csvSystemVersion CSVシステムバージョン
     * @param _changeVersionList 変更バージョン一覧
     * @param _sessionDto セッション情報
     * @return コンバート対象となる変更バージョンのリスト
     */
    public static List<String> getConvertVersionList(final String _csvSystemVersion, final List<String> _changeVersionList,
            final CM_A03_SessionDto _sessionDto) {
        List<String> convertVersionList = new ArrayList<String>();

        if (checkCsvNowSystemVersion(_csvSystemVersion)) {
            // 現在のシステムバージョンと一致している場合
            return convertVersionList;
        }

        Long longCsvSystemVersion = parseLongVersion(_csvSystemVersion, _sessionDto);

        if (longCsvSystemVersion > parseLongVersion(CM_HeaderUtil.getDisplaySystemVersion(), _sessionDto)) {
            // 指定バージョンが現バージョン以上の場合
            return convertVersionList;
        }

        for (String changeVersion : _changeVersionList) {
            Long longChangeVersion = parseLongVersion(changeVersion, _sessionDto);

            if (longChangeVersion > longCsvSystemVersion) {
                // CSVのシステムバージョンが変更バージョンより古いバージョンの場合にリストに追加
                convertVersionList.add(changeVersion);
            }
        }

        return convertVersionList;
    }
    /**
     *
     * CSV取り込み可否の判定.<br>
     *<br>
     * 概要:<br>
     *   CSVのバージョンが取り込み可能なものか否かを判定する
     *<br>
     * @param _csvSystemVersion CSVシステムバージョン
     * @param _changeVersionList 変更バージョン一覧
     * @param _sessionDto セッション情報
     * @return チェック結果
     */
    public static boolean checkCsvVersion(final String _csvSystemVersion, final List<String> _changeVersionList,
            final CM_A03_SessionDto _sessionDto) {
        // 判定結果
        boolean result = false;

        // コンバート対象となる変更バージョンのリストを取得
        List<String> csvConvertVersionList = getConvertVersionList(_csvSystemVersion, _changeVersionList, _sessionDto);

        if (csvConvertVersionList.size() <= CSV_CONVERT_MAX) {
            // 最大コンバート回数を超えていなければ取り込み可能
            result = true;
        }

        return result;
    }

    /**
     *
     * 使用しているCSVフォーマット情報取得.<br>
     *<br>
     * 概要:<br>
     *   アップロードしたCSVファイルが使用しているCSVフォーマット情報を取得する
     *<br>
     * @param _isConvert コンバート処理をするかフラグ
     * @param _nowCsvFormat 現在のCSVフォーマット
     * @param _changetVersion 変更バージョン
     * @param _oldCsvFormatInfo 過去のCSVフォーマット情報
     * @return CSVファイルが使用しているCSVフォーマット情報
     */
    public static FW01_10_CSVFormat getUseCsvFormat(final boolean _isConvert, final FW01_10_CSVFormat _nowCsvFormat,
            final String _changetVersion, final Map<String, FW01_10_CSVFormat> _oldCsvFormatInfo) {

        FW01_10_CSVFormat csvFormtat = null;
        if (_isConvert) {
            if (_oldCsvFormatInfo.containsKey(_changetVersion)) {
                csvFormtat = _oldCsvFormatInfo.get(_changetVersion);
            }
        } else {
            csvFormtat = _nowCsvFormat;
        }

        // 取得できなかった場合、現在のCSVフォーマットバージョンを設定
        if (CM_CommonUtil.isNullOrBlank(csvFormtat)) {
            csvFormtat = _nowCsvFormat;
        }

        return csvFormtat;
    }

    /**
     *
     * {新規モード存在チェック}.<br>
     *<br>
     * 概要:<br>
     *   {操作フラグ「新規」のデータが存在するかどうかのチェック}
     *<br>
     * @param _data CSVデータ
     * @return 処理結果
     */
    public static boolean checkExistNewMode(final List<String[]> _data) {

        // CSVデータが空の場合、チェックしない
        if (_data == null || _data.isEmpty()) {
            return true;
        }

        for (String[] line : _data) {
            // 操作フラグ「新規」のデータが見つかるまでループする

            if (CM_Csv_Const.OperationType.INSERT.equals(line[0].toUpperCase())) {
                // 操作フラグが新規モードの場合
                return true;
            }
        }
        return false;
    }

    /**
     * CSV用日時データを生成する.
     *
     * @param _userTimezone ログインユーザのタイムゾーン
     * @return CSV用日時データ
     */
    public static CM_CsvDatetimeDto getCsvDatetimeData(final String _userTimezone) {
        // 返却用インスタンスの初期化
        CM_CsvDatetimeDto ret = new CM_CsvDatetimeDto();

        Date date = new Date();
        String jpnDatetime = new SimpleDateFormat(CM_A04_Const.DATETIME_FORMAT).format(date);
        Date gmtDatetime = CM_CommonUtil.getTimeTimezoneToGmt(jpnDatetime, FW00_19_Const.TZ_JPN, CM_A04_Const.DATETIME_FORMAT);

        // CSVファイル名用
        ret.setFileNameDateStr(CM_CommonUtil.getTimeGmtToTimezone(new Timestamp(gmtDatetime.getTime()), _userTimezone, CM_A04_Const.DATETIME_FORMAT));

        // CSVヘッダ用
        ret.setHeaderDateStr(CM_CommonUtil.getTimeGmtToTimezone(new Timestamp(gmtDatetime.getTime()), _userTimezone, CM_A04_Const.DATE_FORMAT_SEC_HYPHEN));

        return ret;
    }

    /**
     * CSVダウンロード上限件数を取得.
     * @param _sessionDto セッションDto
     * @return CSVダウンロード上限件数
     */
    public static final long getCsvMaxExportCnt(final CM_A03_SessionDto _sessionDto) {
        String strMaxSize = CM_SysEnvDataUtil.selectSysEnvName(_sessionDto,
                CM_A04_Const.SYS_ENV_MST_ENV_CD.CSV_MAX_EXPORT_CNT, CM_A04_Const.SYS_ENV_MST_ITEM_CD.MAX);
        return CM_CommonUtil.getLongVal(strMaxSize);
    }
}
