/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 *  2014/06/21| <10000-004> ユーザ設定押下処理追加 | 1.00.00| YSK)鬼丸
 *  2014/06/21| <10000-008> 説明画面用処理追加     | 1.00.00| YSK)中田
 *  2015/01/06| <20000-033> 変更仕様一覧No.26      | 3.00.00| YSK)中田
 *  2016/01/14| <40000-025> 変更仕様No.25          | 4.00.00| US)萩尾
 *  2016/07/20| <C1.01> 共通化対応取込             | C1.01  | US)萩尾
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.mmcloud.common.dto.CM_CheckDeleteResult;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.common.util.CM_HeaderUtil;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.common.util.CM_MessageResourceUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSearchConditionEntity;
import jp.ysk.mmcloud.visualization.common.form.CM_BaseForm;
import jp.ysk.mmcloud.visualization.common.form.CM_ListForm;
import jp.ysk.mmcloud.visualization.common.service.CM_InfoService;
import jp.ysk.mmcloud.visualization.common.util.CM_MessageUtil;

import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.beans.util.Beans;
import org.seasar.framework.exception.SQLRuntimeException;
import org.seasar.struts.annotation.Execute;

/**
 *
 * 単票用アクション基底クラス.<br>
 *<br>
 * 概要:<br>
 *   単票用アクション用の共通基底クラス
 *<br>
 */
public abstract class CM_A02_VisualizationDetailAction extends CM_A01_BaseAction {

    /**
     * 初期表示処理.<br>
     * <br>
     * 概要:<br>
     * 初期表示処理を実行<br>
     *
     * @return 画面のJSP
     */
    @Override
    protected String init() {
        // 実行可否確認
        if (!this.checkAction()) {
            return CM_A04_Const.ERROR_PAGE.ERROR_PAGE_404;
        }

        // 検索条件の設定
        CM_BaseForm form = this.getActionForm();

        // 検索条件取得
        List<TrSearchConditionEntity> searchConditionList = null;
        if (CM_CommonUtil.isNotNullOrBlank(form.hdnFavoriteAccessNo)) {
            // お気に入りからの遷移の場合
            searchConditionList
                = this.getService().getRegisterSearchCondition(this.getPageId(), form.hdnFavoriteAccessNo);
        }
        if (CM_CommonUtil.isNotNullOrEmpty(searchConditionList)) {
            // 検索条件が登録されている場合
            this.setParamRegisterSearchCondition(searchConditionList);
        }

        return this.getJspFileName();
    }

    /*
     * (非 Javadoc)
     * @see jp.ysk.specialization.common.action.CM_A01_BaseAction#display()
     */
    @Override
    protected String display() {

        // 日時情報更新処理
        this.setDisplayDateData(this.getActionForm());

        // フォーム情報をMapに格納
        BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

        this.beforeDisplay(formMap);

        // モード別の処理
        if (CM_CommonUtil.isNullOrBlank(this.getActionForm().hdnPageDispMode)
                || CM_A04_Const.PAGE_DISP_MODE.MODE_NEW.equals(this.getActionForm().hdnPageDispMode)) {
            this.dspNewData(formMap);
        } else {
            this.dspExistData(formMap);
        }

        this.afterDisplay(formMap);

        return this.getJspFileName();
    }

    /**
     *
     * 初期表示 前処理.<br>
     *<br>
     * 概要:<br>
     *   初期表示 前処理を実行する
     *<br>
     * @param _formInfo フォーム情報
     */
    protected void beforeDisplay(final BeanMap _formInfo) {
        return;
    }

    /**
     *
     * 初期表示 後処理.<br>
     *<br>
     * 概要:<br>
     *   初期表示 後処理を実行する
     *<br>
     * @param _formInfo フォーム情報
     */
    protected void afterDisplay(final BeanMap _formInfo) {
        return;
    }

    /**
     *
     * 新規登録画面表示処理.<br>
     *<br>
     * 概要:<br>
     *   新規データ登録の画面表示処理
     *<br>
     * @param _formInfo フォーム情報
     */
    protected void dspNewData(final BeanMap _formInfo) {
        return;
    }

    /**
     *
     * 登録済みデータ表示処理.<br>
     *<br>
     * 概要:<br>
     *   登録済みデータ表示処理
     *<br>
     * @param _formInfo フォーム情報
     */
    protected void dspExistData(final BeanMap _formInfo) {
        return;
    }

    /**
     *
     * 登録処理.<br>
     *<br>
     * 概要:<br>
     *   登録処理を実行する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String regist() {
        String strRet = null;

        try {
            // 共通設定
            this.commonSetting();

            // フォーム情報をMapに格納
            BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

            if (CM_A04_Const.PAGE_DISP_MODE.MODE_NEW.equals(this.getActionForm().hdnPageDispMode)) {
                // 登録処理
                int newSid = this.getService().insertInfo(formMap);
                this.setNewSid(newSid);

                // 登録完了後、SIDが生成されるため、そのSIDをJSONでクライアントに渡す。
                strRet = this.getJspFileNameAjax();

            } else {
                // 編集処理
                this.getService().updateInfo(formMap);

            }

        } catch (FW00_12_BusinessException be) {
            // 例外発生時はエラーメッセージ表示
            return this.alertErrorInfoForAjax(be.getMsgKey(), be.getFocusCtlId());

        } catch (SQLRuntimeException re) {
            // SQLエラー時はエラーをスローする
            throw re;
        } catch (Exception e) {
            // 例外発生時はエラーメッセージ表示
            String strErrorMes = CM_MessageUtil.getInsertFailedErrorMessage(this.cM_A03_SessionDto);

            // 例外情報はログ出力
            CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, e);

            return this.alertErrorInfoForAjax(strErrorMes, null);
        }

        return strRet;
    }

    /**
     *
     * 登録時に生成されたSIDをFormにSIDを設定.<br>
     *<br>
     * 概要:<br>
     *   登録完了後、SIDが生成されるため、そのSIDをJSONでクライアントに渡すためにFormにSIDを設定。
     *<br>
     * @param _sid 登録完了後生成されたSID
     */
    protected void setNewSid(final int _sid) {
        return;
    }

    /**
     *
     * 表示切替（閲覧⇒編集）処理.<br>
     *<br>
     * 概要:<br>
     *   表示切替（閲覧⇒編集）
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String edit() {

        // 共通設定
        this.commonSetting();

        // モード変更
        this.modeChange(CM_A04_Const.PAGE_EVENT_TYPE.EVENT_EDIT);

        // 実行可否確認
        if (!this.checkAction()) {
            return CM_A04_Const.ERROR_PAGE.ERROR_PAGE_404;
        }

        // 表示データ作成
        this.display();

        return this.getJspFileName();
    }

    /**
     *
     * キャンセル処理.<br>
     *<br>
     * 概要:<br>
     *   キャンセル処理を実行する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String cancel() {

        if (CM_A04_Const.PAGE_DISP_MODE.MODE_NEW.equals(this.getActionForm().hdnPageDispMode)) {
            // 画面遷移パラメータはなし
            Map<String, String> transferMap = new HashMap<String, String>();

            // 一覧画面の遷移先関数を取得
            String returnMethod = CM_HeaderUtil.getReturnMethod(this.cM_A03_SessionDto);

            // パンくず最終データを削除
            CM_HeaderUtil.removeLastBreadCrumbList(this.cM_A03_SessionDto);

            // 一覧画面へリダイレクト
            return this.redirectPage(returnMethod, transferMap, this.getActionForm());

        } else {

            // 共通設定
            this.commonSetting();

            // モード変更
            this.modeChange(CM_A04_Const.PAGE_EVENT_TYPE.EVENT_CANCEL);

            // 表示データ作成
            this.display();

            return getJspFileName();

        }

    }

    /**
     *
     * 登録完了時処理.<br>
     *<br>
     * 概要:<br>
     *   登録完了後の処理を実行する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String updateDataComplete() {
        if (CM_A04_Const.PAGE_DISP_MODE.MODE_NEW.equals(this.getActionForm().hdnPageDispMode)) {
            // 画面遷移パラメータはなし
            Map<String, String> transferMap = new HashMap<String, String>();

            // 一覧画面の遷移先関数を取得
            String returnMethod = CM_HeaderUtil.getReturnMethod(this.cM_A03_SessionDto);

            // パンくず最終データを削除
            CM_HeaderUtil.removeLastBreadCrumbList(this.cM_A03_SessionDto);

            // 一覧画面へリダイレクト
            return this.redirectPage(returnMethod, transferMap, this.getActionForm());

        } else {

            // 共通設定
            this.commonSetting();

            // モード変更
            this.modeChange(CM_A04_Const.PAGE_EVENT_TYPE.EVENT_REGIST);

            // 実行可否確認
            if (!this.checkAction()) {
                return CM_A04_Const.ERROR_PAGE.ERROR_PAGE_404;
            }

            // 表示データ作成
            this.display();

            return this.getJspFileName();
        }
    }

    /**
     *
     * 表示切替（閲覧⇒コピー）処理.<br>
     *<br>
     * 概要:<br>
     *   コピー処理を実行する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String copy() {

        // 共通設定
        this.commonSetting();

        // 表示データ作成（現在表示しているデータを使いたいため、モード変更より先に作成）
        this.display();

        // モード変更
        this.modeChange(CM_A04_Const.PAGE_EVENT_TYPE.EVENT_COPY);

        // 実行可否確認
        if (!this.checkAction()) {
            return CM_A04_Const.ERROR_PAGE.ERROR_PAGE_404;
        }

        // 入力項目のクリア処理
        this.clearCopyData();

        return this.getJspFileName();
    }

    /**
     *
     * 入力項目のクリア処理.<br>
     *<br>
     * 概要:<br>
     *   コピーにクリアが必要な入力項目の値をクリアする
     *<br>
     */
    protected void clearCopyData() {
        return;
    }

    /**
     *
     * 削除処理.<br>
     *<br>
     * 概要:<br>
     *   削除処理を実行する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String delete() {
        try {

            // 共通設定
            this.commonSetting();

            // フォーム情報をMapに格納
            BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

            // 削除処理
            this.getService().deleteInfo(formMap);

        } catch (FW00_12_BusinessException be) {
            // 例外発生時はエラーメッセージ表示
            return this.alertErrorInfoForAjax(be.getMsgKey(), be.getFocusCtlId());

        } catch (SQLRuntimeException re) {
            // SQLエラー時はエラーをスローする
            throw re;
        } catch (Exception e) {
            // 例外発生時はエラーメッセージ表示
            String strErrorMes = CM_MessageUtil.getDeleteFailedErrorMessage(this.cM_A03_SessionDto);

            // 例外情報はログ出力
            CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, e);

            return this.alertErrorInfoForAjax(strErrorMes, null);
        }

        return null;
    }

    /**
     *
     * 削除完了処理.<br>
     *<br>
     * 概要:<br>
     *   削除完了処理を実行する
     *<br>
     * @return JSP名
     */
    @Execute(validator = false)
    public String deleteDataComplete() {
        // 画面遷移パラメータはなし
        Map<String, String> transferMap = new HashMap<String, String>();

        String returnMethod = CM_HeaderUtil.getReturnMethod(this.cM_A03_SessionDto);

        // パンくず最終データを削除
        CM_HeaderUtil.removeLastBreadCrumbList(this.cM_A03_SessionDto);

        // 一覧画面へリダイレクト
        return this.redirectPage(returnMethod, transferMap, this.getActionForm());
    }

    /**
     * 削除時チェック結果.
     */
    public CM_CheckDeleteResult checkDeleteResult;

    /**
     * JSPファイル名（削除警告JSP）.
     */
    public static final String JSP_FILE_NAME_DELETE_CONFIRM = "../common/com_deleteConfirm.jsp";

    /**
     * 削除前チェック処理.
     *
     * @return jsp
     */
    @Execute(validator = false)
    public String checkDelete() {

        // 開始ログ出力
        CM_LoggerUtil.outputActionInputParamLog(this.cM_A03_SessionDto, this.getActionForm());

        try {
            // フォーム情報をMapに格納
            BeanMap formMap = Beans.createAndCopy(BeanMap.class, this.getActionForm()).execute();

            CM_InfoService service = getService();

            this.checkDeleteResult = new CM_CheckDeleteResult();
            service.checkDeleteInfo(formMap, this.checkDeleteResult);

        } catch (FW00_12_BusinessException be) {
            // 例外発生時はエラーメッセージ表示
            return this.alertErrorInfoForAjax(be.getMsgKey(), be.getFocusCtlId());
        } catch (Exception e) {
            // 例外発生時はエラーメッセージ表示
            String strErrorMes = CM_MessageResourceUtil.getMessageValue(this.cM_A03_SessionDto.ssn_CustomerCD,
                    this.cM_A03_SessionDto.ssn_UserLangCD, "MMCMCM00000_006");

            // 例外情報はログ出力
            CM_LoggerUtil.outputErrorLog(this.cM_A03_SessionDto, e);

            return this.alertErrorInfoForAjax(strErrorMes, null);
        }

        // 終了ログ出力
        CM_LoggerUtil.outputActionOutputParamLog(this.cM_A03_SessionDto, JSP_FILE_NAME_DELETE_CONFIRM);

        return JSP_FILE_NAME_DELETE_CONFIRM;
    }

    /**
     *
     * 初期表示 初期処理.<br>
     *<br>
     * 概要:<br>
     *   初期表示 初期処理を実行する
     *<br>
     */
    @Override
    protected void afterIndex() {
        // 共通設定
        this.commonSetting();
    }

    /**
     *
     * 共通設定.<br>
     *<br>
     * 概要:<br>
     *   共通設定処理を行う
     *<br>
     */
    @Override
    protected void commonSetting() {
        super.commonSetting();

        // サービス初期化
        this.getService().init(this.cM_A03_SessionDto);

        // 権限設定取得
        this.getAuth();

        // 共通ヘッダパンくずリストの登録
        CM_HeaderUtil.addBreadCrumbList(this.cM_A03_SessionDto, this.getPageId());
    }

    /**
     * 各画面のサービスクラス取得.<br>
     *<br>
     * 概要:<br>
     * 各画面のサービスクラスを取得<br>
     *
     * @return 画面のサービスクラス
     */
    @Override
    protected abstract CM_InfoService getService();

    /**
     * 各画面のフォームクラス取得.<br>
     *<br>
     * 概要:<br>
     * 各画面のフォームクラスを取得<br>
     *
     * @return 画面のフォームクラス
     */
    protected abstract CM_BaseForm getActionForm();

}
