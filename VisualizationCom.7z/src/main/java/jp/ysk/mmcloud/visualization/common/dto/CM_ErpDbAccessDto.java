/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2017/03/09| 新規作成                           | C1.01  | H.Nakamura
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.mmcloud.visualization.common.dto;

import javax.transaction.TransactionManager;

import org.seasar.extension.jdbc.manager.JdbcManagerImpl;

/**
 * ERP-DBアクセス用Dtoクラス.<br>
 *<br>
 * 概要:<br>
 *   ERP-DBへアクセスするためのJDBCManagerおよびそのトランザクションデータのDtoクラス
 *<br>
 */
public class CM_ErpDbAccessDto {

    /**
     * ERP-DBアクセス用のJDBCManager.
     */
    public JdbcManagerImpl jdbcManager;

    /**
     * データ型(データポイントマスタのデータ型).
     */
    public TransactionManager userTransactionMng;

    /**
     * エラーメッセージ.
     */
    public String errMsg;

    /**
     * コンストラクタ.
     *
     */
    public CM_ErpDbAccessDto() {
        this.jdbcManager = null;
        this.userTransactionMng = null;
    }

}
