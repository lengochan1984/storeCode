package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ライン予定/実績/計画(現状)
 * 
 */
@Entity
@Table(name = "ag_line_work_current")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:31")
public class AgLineWorkCurrentEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** ラインID */
    @Id
    @Column(precision = 8, nullable = false, unique = true)
    public BigDecimal lnId;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updDate;

    /** 予定数 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer scheduleNum;

    /** 実績数 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer actualNum;

    /** 計画数 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer planNum;

    /** 完了時刻(予測) */
    @Column(nullable = true, unique = false)
    public Timestamp predictionCompletionTime;

    /** 完了時刻(計画) */
    @Column(nullable = true, unique = false)
    public Timestamp planCompletionTime;

    /** ライン前の滞留数 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer preRetentionNum;

    /** ライン内の滞留数 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer retentionNum;

    /** ライン後の滞留数 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer afterRetentionNum;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
