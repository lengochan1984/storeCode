package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link MaEquipEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class MaEquipEntityNames {

    /**
     * createdOnのプロパティ名を返します。
     * 
     * @return createdOnのプロパティ名
     */
    public static PropertyName<Timestamp> createdOn() {
        return new PropertyName<Timestamp>("createdOn");
    }

    /**
     * createdByのプロパティ名を返します。
     * 
     * @return createdByのプロパティ名
     */
    public static PropertyName<String> createdBy() {
        return new PropertyName<String>("createdBy");
    }

    /**
     * modifiedOnのプロパティ名を返します。
     * 
     * @return modifiedOnのプロパティ名
     */
    public static PropertyName<Timestamp> modifiedOn() {
        return new PropertyName<Timestamp>("modifiedOn");
    }

    /**
     * modifiedByのプロパティ名を返します。
     * 
     * @return modifiedByのプロパティ名
     */
    public static PropertyName<String> modifiedBy() {
        return new PropertyName<String>("modifiedBy");
    }

    /**
     * invalidFlagのプロパティ名を返します。
     * 
     * @return invalidFlagのプロパティ名
     */
    public static PropertyName<Integer> invalidFlag() {
        return new PropertyName<Integer>("invalidFlag");
    }

    /**
     * mainResNoのプロパティ名を返します。
     * 
     * @return mainResNoのプロパティ名
     */
    public static PropertyName<String> mainResNo() {
        return new PropertyName<String>("mainResNo");
    }

    /**
     * plantCdのプロパティ名を返します。
     * 
     * @return plantCdのプロパティ名
     */
    public static PropertyName<String> plantCd() {
        return new PropertyName<String>("plantCd");
    }

    /**
     * mainResNmのプロパティ名を返します。
     * 
     * @return mainResNmのプロパティ名
     */
    public static PropertyName<String> mainResNm() {
        return new PropertyName<String>("mainResNm");
    }

    /**
     * equipCdのプロパティ名を返します。
     * 
     * @return equipCdのプロパティ名
     */
    public static PropertyName<String> equipCd() {
        return new PropertyName<String>("equipCd");
    }

    /**
     * fixedAssetNoのプロパティ名を返します。
     * 
     * @return fixedAssetNoのプロパティ名
     */
    public static PropertyName<String> fixedAssetNo() {
        return new PropertyName<String>("fixedAssetNo");
    }

    /**
     * inventoryNoのプロパティ名を返します。
     * 
     * @return inventoryNoのプロパティ名
     */
    public static PropertyName<String> inventoryNo() {
        return new PropertyName<String>("inventoryNo");
    }

    /**
     * equipLevelのプロパティ名を返します。
     * 
     * @return equipLevelのプロパティ名
     */
    public static PropertyName<BigDecimal> equipLevel() {
        return new PropertyName<BigDecimal>("equipLevel");
    }

    /**
     * stIdのプロパティ名を返します。
     * 
     * @return stIdのプロパティ名
     */
    public static PropertyName<BigDecimal> stId() {
        return new PropertyName<BigDecimal>("stId");
    }

    /**
     * spareNum1のプロパティ名を返します。
     * 
     * @return spareNum1のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum1() {
        return new PropertyName<BigDecimal>("spareNum1");
    }

    /**
     * spareNum2のプロパティ名を返します。
     * 
     * @return spareNum2のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum2() {
        return new PropertyName<BigDecimal>("spareNum2");
    }

    /**
     * spareNum3のプロパティ名を返します。
     * 
     * @return spareNum3のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum3() {
        return new PropertyName<BigDecimal>("spareNum3");
    }

    /**
     * spareText1のプロパティ名を返します。
     * 
     * @return spareText1のプロパティ名
     */
    public static PropertyName<String> spareText1() {
        return new PropertyName<String>("spareText1");
    }

    /**
     * spareText2のプロパティ名を返します。
     * 
     * @return spareText2のプロパティ名
     */
    public static PropertyName<String> spareText2() {
        return new PropertyName<String>("spareText2");
    }

    /**
     * spareText3のプロパティ名を返します。
     * 
     * @return spareText3のプロパティ名
     */
    public static PropertyName<String> spareText3() {
        return new PropertyName<String>("spareText3");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _MaEquipNames extends PropertyName<MaEquipEntity> {

        /**
         * インスタンスを構築します。
         */
        public _MaEquipNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _MaEquipNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _MaEquipNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * createdOnのプロパティ名を返します。
         *
         * @return createdOnのプロパティ名
         */
        public PropertyName<Timestamp> createdOn() {
            return new PropertyName<Timestamp>(this, "createdOn");
        }

        /**
         * createdByのプロパティ名を返します。
         *
         * @return createdByのプロパティ名
         */
        public PropertyName<String> createdBy() {
            return new PropertyName<String>(this, "createdBy");
        }

        /**
         * modifiedOnのプロパティ名を返します。
         *
         * @return modifiedOnのプロパティ名
         */
        public PropertyName<Timestamp> modifiedOn() {
            return new PropertyName<Timestamp>(this, "modifiedOn");
        }

        /**
         * modifiedByのプロパティ名を返します。
         *
         * @return modifiedByのプロパティ名
         */
        public PropertyName<String> modifiedBy() {
            return new PropertyName<String>(this, "modifiedBy");
        }

        /**
         * invalidFlagのプロパティ名を返します。
         *
         * @return invalidFlagのプロパティ名
         */
        public PropertyName<Integer> invalidFlag() {
            return new PropertyName<Integer>(this, "invalidFlag");
        }

        /**
         * mainResNoのプロパティ名を返します。
         *
         * @return mainResNoのプロパティ名
         */
        public PropertyName<String> mainResNo() {
            return new PropertyName<String>(this, "mainResNo");
        }

        /**
         * plantCdのプロパティ名を返します。
         *
         * @return plantCdのプロパティ名
         */
        public PropertyName<String> plantCd() {
            return new PropertyName<String>(this, "plantCd");
        }

        /**
         * mainResNmのプロパティ名を返します。
         *
         * @return mainResNmのプロパティ名
         */
        public PropertyName<String> mainResNm() {
            return new PropertyName<String>(this, "mainResNm");
        }

        /**
         * equipCdのプロパティ名を返します。
         *
         * @return equipCdのプロパティ名
         */
        public PropertyName<String> equipCd() {
            return new PropertyName<String>(this, "equipCd");
        }

        /**
         * fixedAssetNoのプロパティ名を返します。
         *
         * @return fixedAssetNoのプロパティ名
         */
        public PropertyName<String> fixedAssetNo() {
            return new PropertyName<String>(this, "fixedAssetNo");
        }

        /**
         * inventoryNoのプロパティ名を返します。
         *
         * @return inventoryNoのプロパティ名
         */
        public PropertyName<String> inventoryNo() {
            return new PropertyName<String>(this, "inventoryNo");
        }

        /**
         * equipLevelのプロパティ名を返します。
         *
         * @return equipLevelのプロパティ名
         */
        public PropertyName<BigDecimal> equipLevel() {
            return new PropertyName<BigDecimal>(this, "equipLevel");
        }

        /**
         * stIdのプロパティ名を返します。
         *
         * @return stIdのプロパティ名
         */
        public PropertyName<BigDecimal> stId() {
            return new PropertyName<BigDecimal>(this, "stId");
        }

        /**
         * spareNum1のプロパティ名を返します。
         *
         * @return spareNum1のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum1() {
            return new PropertyName<BigDecimal>(this, "spareNum1");
        }

        /**
         * spareNum2のプロパティ名を返します。
         *
         * @return spareNum2のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum2() {
            return new PropertyName<BigDecimal>(this, "spareNum2");
        }

        /**
         * spareNum3のプロパティ名を返します。
         *
         * @return spareNum3のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum3() {
            return new PropertyName<BigDecimal>(this, "spareNum3");
        }

        /**
         * spareText1のプロパティ名を返します。
         *
         * @return spareText1のプロパティ名
         */
        public PropertyName<String> spareText1() {
            return new PropertyName<String>(this, "spareText1");
        }

        /**
         * spareText2のプロパティ名を返します。
         *
         * @return spareText2のプロパティ名
         */
        public PropertyName<String> spareText2() {
            return new PropertyName<String>(this, "spareText2");
        }

        /**
         * spareText3のプロパティ名を返します。
         *
         * @return spareText3のプロパティ名
         */
        public PropertyName<String> spareText3() {
            return new PropertyName<String>(this, "spareText3");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
