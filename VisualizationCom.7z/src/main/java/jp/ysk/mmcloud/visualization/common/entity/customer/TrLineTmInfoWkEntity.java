package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ライン間滞留情報(作業用)
 * 
 */
@Entity
@Table(name = "tr_line_tm_info_wk")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class TrLineTmInfoWkEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 登録日時 */
    @Column(nullable = true, unique = false)
    public Timestamp createdOn;

    /** 登録者 */
    @Column(length = 32, nullable = true, unique = false)
    public String createdBy;

    /** 更新日時 */
    @Column(nullable = true, unique = false)
    public Timestamp modifiedOn;

    /** 更新者 */
    @Column(length = 32, nullable = true, unique = false)
    public String modifiedBy;

    /** 指図番号 */
    @Id
    @Column(length = 12, nullable = false, unique = false)
    public String sasizuNo;

    /** 指図追番 */
    @Id
    @Column(precision = 5, nullable = false, unique = false)
    public BigDecimal subNo;

    /** 作業順序 */
    @Id
    @Column(length = 6, nullable = false, unique = false)
    public String sagyoSeq;

    /** リペア処理回数 */
    @Id
    @Column(precision = 2, nullable = false, unique = false)
    public BigDecimal repairKaisu;

    /** ラインID */
    @Id
    @Column(precision = 8, nullable = false, unique = false)
    public BigDecimal lnId;

    /** プラントコード */
    @Column(length = 10, nullable = true, unique = false)
    public String plantCd;

    /** 製造ラインコード */
    @Column(length = 10, nullable = true, unique = false)
    public String seizouLnCd;

    /** 製造ライン名 */
    @Column(length = 64, nullable = true, unique = false)
    public String seizouLnNm;

    /** 工程コード */
    @Column(length = 5, nullable = true, unique = false)
    public String processCd;

    /** 工程名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String processNm;

    /** ラインNo */
    @Column(length = 32, nullable = true, unique = false)
    public String lnNo;

    /** ライン名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String lnNm;

    /** 作業終了ステーションID */
    @Column(precision = 8, nullable = true, unique = false)
    public BigDecimal endStId;

    /** 作業終了ステーションNo */
    @Column(length = 8, nullable = true, unique = false)
    public String endStNo;

    /** 作業終了ステーション名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String endStNm;

    /** 作業終了作業区 */
    @Column(length = 8, nullable = true, unique = false)
    public String endSagyoku;

    /** 終了作業STEP */
    @Column(length = 8, nullable = true, unique = false)
    public String endStepNo;

    /** 終了日時 */
    @Column(nullable = true, unique = false)
    public Timestamp endTime;

    /** 作業結果（合否判定） */
    @Column(precision = 2, nullable = true, unique = false)
    public BigDecimal hantei;

    /** アラームコード */
    @Column(length = 10, nullable = true, unique = false)
    public String almCd;

    /** 作業状態 */
    @Column(precision = 2, nullable = true, unique = false)
    public BigDecimal sagyoJyotai;

    /** ライン作業結果 */
    @Column(precision = 2, nullable = true, unique = false)
    public BigDecimal sagyoKeka;

    /** 開始ステーションID */
    @Column(precision = 8, nullable = true, unique = false)
    public BigDecimal startStId;

    /** 作業開始ステーションNo */
    @Column(length = 8, nullable = true, unique = false)
    public String startStNo;

    /** 作業開始ステーション名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String startStNm;

    /** 作業開始作業区 */
    @Column(length = 8, nullable = true, unique = false)
    public String startSagyoku;

    /** 開始作業STEP */
    @Column(length = 8, nullable = true, unique = false)
    public String startStepNo;

    /** 開始日時 */
    @Column(nullable = true, unique = false)
    public Timestamp startTime;

    /** 滞留時間(msec） */
    @Column(precision = 11, nullable = true, unique = false)
    public BigDecimal stopTime;

    /** 停止時間を除く滞留時間(msec） */
    @Column(precision = 11, nullable = true, unique = false)
    public BigDecimal stopTime2;

    /** 次ラインID */
    @Column(precision = 8, nullable = true, unique = false)
    public BigDecimal NLnId;

    /** 次製造ラインコード */
    @Column(length = 10, nullable = true, unique = false)
    public String NSeizouLnCd;

    /** 次製造ライン名 */
    @Column(length = 64, nullable = true, unique = false)
    public String NSeizouLnNm;

    /** 次工程コード */
    @Column(length = 5, nullable = true, unique = false)
    public String NProcessCd;

    /** 次工程名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String NProcessNm;

    /** 次ラインNo */
    @Column(length = 32, nullable = true, unique = false)
    public String NLnNo;

    /** 次ライン名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String NLnNm;

    /** 次ライン作業順序 */
    @Column(length = 6, nullable = true, unique = false)
    public String NSagyoSeq;

    /** 数字予備1 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum1;

    /** 数字予備2 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum2;

    /** 数字予備3 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum3;

    /** 文字予備1 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText1;

    /** 文字予備2 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText2;

    /** 文字予備3 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText3;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
