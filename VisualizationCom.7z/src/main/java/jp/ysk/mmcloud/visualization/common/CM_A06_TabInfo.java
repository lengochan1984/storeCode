/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/07/27| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common;

/**
 *
 * タブ情報.<br>
 *<br>
 * 概要:<br>
 *  タブID等の情報
 *<br>
 */
public enum CM_A06_TabInfo {

    /**
     * HOME画面.
     */
    MONITOR_HOME("monitorHome", false),

    /**
     * 稼動状況.
     */
    OPERATION_STATUS("operationStatus", false),

    /**
     * 製品別分析-リードタイムタブ.
     */
    LEAD_TIME_TAB("leadTime", false),

    /**
     * 製品別分析-作業別工数タブ.
     */
    WORK_TAB("work", false),

    /**
     * 製品別分析-生産数タブ.
     */
    PRODUCTION_TAB("production", false),

    /**
     * 前詰負荷平準タブ.
     */
    PRELOAD_LEVEL_DAILY_TAB("preloadLevelDaily", false),

    /**
     * 納期遵守率タブ.
     */
    ERP_DUE_DATE_RATING_MONTHLY_TAB("erpDueDateRatingMonthly", false),

    /**
     * 納期遅れ額タブ.
     */
    NOKI_OKU_LE_TAB("nokiOkuLeGaku", false),

    /**
     * 欠品額タブ.
     */
    STOCKOUT_AMOUNT_TAB("stockoutAmount", false),

    /**
     * 材完率タブ.
     */
    MATERIAL_SUPPLY_RATE_TAB("materialSupplyRate", false),

    /**
     * 材完率詳細タブ.
     */
    MATERIAL_SUPPLY_RATE_DETAIL_TAB("materialSupplyRateDetail", false),

    /**
     * 欠品品目数タブ.
     */
    STOCKOUT_NUMBER_TAB("stockoutNumber", false),

    /**
     * 稼動一覧.
     */
    OPERATIION_LIST("operationList", true),

    /**
     * トレーサビリティ一覧.
     */
    TRACEABILITY_LIST("traceabilityList", true),

    /**
     * 滞留分析.
     */
    RETENTION_ANALYSIS("retentionAnalysis", false),

    /**
     * ライン状況モニタ-生産進捗タブ.
     */
    PRODUCTION_PROGRESS_TAB("productionProgress", false),

    /**
     * ライン状況モニタ-指図一覧タブ.
     */
    ORDER_LIST_TAB("orderList", true),

    /**
     * ライン状況モニタ-不具合一覧タブ.
     */
    FAILURE_LIST_TAB("failureList", true),

    /**
     * ライン状況モニタ-設備状況タブ.
     */
    FACILITY_STATUS_TAB("facilityStatus", false),

    /**
     * 指図進捗モニタ.
     */
    INSTRUCTION_PROGRESS_TAB("instructionProgress", false),

    /**
     * 品質不良発生モニタ.
     */
    QUALITY_FAILURE_TAB("qualityFailure", true),

    /**
     * ユーザ一覧タブ.
     */
    USER_LIST_TAB("userList", true);

    /**
     * タブID.
     */
    private String tabId;

    /**
     * 一覧表示フラグ.
     */
    private boolean listFlag;

    /**
     * コンストラクタ.
     *
     * @param _tabId タブID
     * @param _listFlag 一覧表示フラグ
     */
    private CM_A06_TabInfo(final String _tabId, final boolean _listFlag) {
        this.tabId = _tabId;
        this.listFlag = _listFlag;
    }

    /**
     * タブIDを取得.
     *
     * @return タブId
     */
    public String getTabId() {
        return this.tabId;
    }

    /**
     * 一覧表示フラグを取得.
     *
     * @return 一覧表示かどうか
     */
    public boolean isListFlag() {
        return this.listFlag;
    }

    /**
     *
     * タブ情報取得.<br>
     *<br>
     * 概要:<br>
     *  タブ情報取得
     *<br>
     * @param _tabId タブID
     * @return タブ情報
     */
    public static CM_A06_TabInfo getTabInfo(final String _tabId) {
        for (CM_A06_TabInfo tabInfo : CM_A06_TabInfo.values()) {
            if (tabInfo.getTabId().equals(_tabId)) {
                return tabInfo;
            }
        }
        return null;
    }
}
