/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2016/08/28| 新規作成                           | C1.01  | US)萩尾
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.dao;

import java.util.List;

import javax.transaction.TransactionManager;

import jp.ysk.fw.FW00_12_AppException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.visualization.common.dto.CM_MesDbAccessDto;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrTransferDatetimeEntityNames;
import jp.ysk.mmcloud.visualization.common.util.CM_MesDbAccessManager;

import org.seasar.extension.jdbc.JdbcManager;
import org.seasar.framework.beans.util.BeanMap;

/**
 * mesスキーマ用共通Dao.<br>
 *<br>
 * 概要:<br>
 *   mesスキーマのDBにアクセスするための共通Daoクラス
 *<br>
 */
public abstract class CM_BaseMesSchemaDao {

    /**
     * JDBCマネージャー(mesスキーマ).
     */
    protected JdbcManager jdbcManager;

    /**
     * トランザクション(mesスキーマ).
     */
    protected TransactionManager transactionMng;

    /**
     * SQLファイルパス(共通).
     */
    public static final String SQL_PATH_COMM = "jp/ysk/mmcloud/visualization/batch/sql/";

    /**
     * コンストラクタ.
     */
    public CM_BaseMesSchemaDao() {
    }

    /**
     *
     * コンストラクタ.<br>
     *<br>
     * @param _strConnectString mesDB接続情報
     * @param _strConnectUserName mesDBユーザ名
     * @param _strConnectPasswd mesDBパスワード
     */
    public CM_BaseMesSchemaDao(
            final String _strConnectString,
            final String _strConnectUserName,
            final String _strConnectPasswd) {

        CM_MesDbAccessDto mesDbAccess = CM_MesDbAccessManager.getMesDbAccess(
                _strConnectString,
                _strConnectUserName,
                _strConnectPasswd);

        this.jdbcManager = mesDbAccess.jdbcManager;
        this.transactionMng = mesDbAccess.userTransactionMng;

    }

    /**
     *
     * 初期化.<br>
     *<br>
     * 概要:<br>
     *   初期化処理を実行する
     *<br>
     * @param _strConnectString mesDB接続情報
     * @param _strConnectUserId mesDBユーザID
     * @param _strConnectPasswd mesDBパスワード
     */
    public void setMesDbInfo(final String _strConnectString,
            final String _strConnectUserId,
            final String _strConnectPasswd) {

        CM_MesDbAccessDto customerDbAccess = CM_MesDbAccessManager.getMesDbAccess(
                _strConnectString,
                _strConnectUserId,
                _strConnectPasswd);

        this.jdbcManager = customerDbAccess.jdbcManager;
        this.transactionMng = customerDbAccess.userTransactionMng;

    }

    /**
     *
     * mesDBトランザクション開始処理.<br>
     *<br>
     * 概要:<br>
     *   mesDBトランザクション開始処理を実行する
     *<br>
     */
    public void biginTransaction() {

        try {
            this.transactionMng.begin();

        } catch (Exception ex) {
            CM_LoggerUtil.outputErrorLog(null, ex);
            throw new FW00_12_AppException(FW00_19_Const.EMPTY_STR);
        }
    }

    /**
     *
     * mesDBトランザクションコミット処理.<br>
     *<br>
     * 概要:<br>
     *   mesDBトランザクションコミット処理を実行する
     *<br>
     */
    public void commitTransaction() {

        try {
            this.transactionMng.commit();

        } catch (Exception ex) {
            CM_LoggerUtil.outputErrorLog(null, ex);
            throw new FW00_12_AppException(FW00_19_Const.EMPTY_STR);
        }
    }

    /**
     *
     * mesDBトランザクションロールバック処理.<br>
     *<br>
     * 概要:<br>
     *   mesDBトランザクションロールバック処理を実行する
     *<br>
     */
    public void rollbackTransaction() {

        try {
            this.transactionMng.rollback();

        } catch (Exception ex) {
            CM_LoggerUtil.outputErrorLog(null, ex);
            throw new FW00_12_AppException(FW00_19_Const.EMPTY_STR);
        }
    }

    /**
     *
     * Mesデータ取得.<br>
     *<br>
     * 概要:<br>
     * 登録するMesデータを取得する
     *<br>
     * @param _sqlFileName SQLファイル名
     * @param _param パラメータ
     * @return 登録するMesデータ
     */
    public List<BeanMap> selectMesData(final String _sqlFileName, final BeanMap _param) {

        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(BeanMap.class, SQL_PATH_COMM + _sqlFileName, _param).getResultList();

        return ret;
    }

    /**
     *
     * MESデータ件数取得.<br>
     *<br>
     * 概要:<br>
     * 登録対象のMESデータ件数を取得する
     *<br>
     * @param _sqlFileName SQLファイル名
     * @param _param パラメータ
     * @return 登録対象のMESデータ件数
     */
    public long checkMesData(final String _sqlFileName, final BeanMap _param) {

        long ret = this.jdbcManager.getCountBySqlFile(SQL_PATH_COMM + _sqlFileName, _param);

        return ret;
    }

    /**
     *
     * ステーションログ取得.<br>
     *<br>
     * 概要:<br>
     *  ステーションログを取得
     *<br>
     * @param _selectParam 取得パラメータ
     * @return ステーションログ
     */
    public BeanMap selectStationLog(final BeanMap _selectParam) {
        BeanMap ret = this.jdbcManager.selectBySqlFile(BeanMap.class, SQL_PATH_COMM + "selectStationInf.sql", _selectParam).getSingleResult();

        return ret;
    }

    /**
     *
     * ステーション間ログ取得.<br>
     *<br>
     * 概要:<br>
     *  ステーション間ログを取得
     *<br>
     * @param _selectParam 取得パラメータ
     * @return ステーション間ログ
     */
    public BeanMap selectStationTmLog(final BeanMap _selectParam) {
        _selectParam.put(TrTransferDatetimeEntityNames.updDatetime().toString(), null);
        List<BeanMap> retList = this.jdbcManager.selectBySqlFile(BeanMap.class, SQL_PATH_COMM + "selectStaTmLog.sql", _selectParam).getResultList();
        BeanMap ret = null;

        if (CM_CommonUtil.isNotNullOrEmpty(retList)) {
            ret = retList.get(0);
        }

        return ret;
    }

}
