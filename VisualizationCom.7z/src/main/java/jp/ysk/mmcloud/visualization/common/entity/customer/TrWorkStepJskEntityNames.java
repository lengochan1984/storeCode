package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link TrWorkStepJskEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class TrWorkStepJskEntityNames {

    /**
     * createdOnのプロパティ名を返します。
     * 
     * @return createdOnのプロパティ名
     */
    public static PropertyName<Timestamp> createdOn() {
        return new PropertyName<Timestamp>("createdOn");
    }

    /**
     * createdByのプロパティ名を返します。
     * 
     * @return createdByのプロパティ名
     */
    public static PropertyName<String> createdBy() {
        return new PropertyName<String>("createdBy");
    }

    /**
     * modifiedOnのプロパティ名を返します。
     * 
     * @return modifiedOnのプロパティ名
     */
    public static PropertyName<Timestamp> modifiedOn() {
        return new PropertyName<Timestamp>("modifiedOn");
    }

    /**
     * modifiedByのプロパティ名を返します。
     * 
     * @return modifiedByのプロパティ名
     */
    public static PropertyName<String> modifiedBy() {
        return new PropertyName<String>("modifiedBy");
    }

    /**
     * sasizuNoのプロパティ名を返します。
     * 
     * @return sasizuNoのプロパティ名
     */
    public static PropertyName<String> sasizuNo() {
        return new PropertyName<String>("sasizuNo");
    }

    /**
     * subNoのプロパティ名を返します。
     * 
     * @return subNoのプロパティ名
     */
    public static PropertyName<BigDecimal> subNo() {
        return new PropertyName<BigDecimal>("subNo");
    }

    /**
     * sagyoSeqのプロパティ名を返します。
     * 
     * @return sagyoSeqのプロパティ名
     */
    public static PropertyName<String> sagyoSeq() {
        return new PropertyName<String>("sagyoSeq");
    }

    /**
     * stIdのプロパティ名を返します。
     * 
     * @return stIdのプロパティ名
     */
    public static PropertyName<BigDecimal> stId() {
        return new PropertyName<BigDecimal>("stId");
    }

    /**
     * stepNoのプロパティ名を返します。
     * 
     * @return stepNoのプロパティ名
     */
    public static PropertyName<String> stepNo() {
        return new PropertyName<String>("stepNo");
    }

    /**
     * startTimeのプロパティ名を返します。
     * 
     * @return startTimeのプロパティ名
     */
    public static PropertyName<Timestamp> startTime() {
        return new PropertyName<Timestamp>("startTime");
    }

    /**
     * endTimeのプロパティ名を返します。
     * 
     * @return endTimeのプロパティ名
     */
    public static PropertyName<Timestamp> endTime() {
        return new PropertyName<Timestamp>("endTime");
    }

    /**
     * workTimeのプロパティ名を返します。
     * 
     * @return workTimeのプロパティ名
     */
    public static PropertyName<BigDecimal> workTime() {
        return new PropertyName<BigDecimal>("workTime");
    }

    /**
     * plantCdのプロパティ名を返します。
     * 
     * @return plantCdのプロパティ名
     */
    public static PropertyName<String> plantCd() {
        return new PropertyName<String>("plantCd");
    }

    /**
     * seizouLnCdのプロパティ名を返します。
     * 
     * @return seizouLnCdのプロパティ名
     */
    public static PropertyName<String> seizouLnCd() {
        return new PropertyName<String>("seizouLnCd");
    }

    /**
     * seizouLnNmのプロパティ名を返します。
     * 
     * @return seizouLnNmのプロパティ名
     */
    public static PropertyName<String> seizouLnNm() {
        return new PropertyName<String>("seizouLnNm");
    }

    /**
     * processCdのプロパティ名を返します。
     * 
     * @return processCdのプロパティ名
     */
    public static PropertyName<String> processCd() {
        return new PropertyName<String>("processCd");
    }

    /**
     * processNmのプロパティ名を返します。
     * 
     * @return processNmのプロパティ名
     */
    public static PropertyName<String> processNm() {
        return new PropertyName<String>("processNm");
    }

    /**
     * lnNoのプロパティ名を返します。
     * 
     * @return lnNoのプロパティ名
     */
    public static PropertyName<String> lnNo() {
        return new PropertyName<String>("lnNo");
    }

    /**
     * lnNmのプロパティ名を返します。
     * 
     * @return lnNmのプロパティ名
     */
    public static PropertyName<String> lnNm() {
        return new PropertyName<String>("lnNm");
    }

    /**
     * stNoのプロパティ名を返します。
     * 
     * @return stNoのプロパティ名
     */
    public static PropertyName<String> stNo() {
        return new PropertyName<String>("stNo");
    }

    /**
     * stNmのプロパティ名を返します。
     * 
     * @return stNmのプロパティ名
     */
    public static PropertyName<String> stNm() {
        return new PropertyName<String>("stNm");
    }

    /**
     * sagyokuのプロパティ名を返します。
     * 
     * @return sagyokuのプロパティ名
     */
    public static PropertyName<String> sagyoku() {
        return new PropertyName<String>("sagyoku");
    }

    /**
     * pgmNoのプロパティ名を返します。
     * 
     * @return pgmNoのプロパティ名
     */
    public static PropertyName<String> pgmNo() {
        return new PropertyName<String>("pgmNo");
    }

    /**
     * userIdのプロパティ名を返します。
     * 
     * @return userIdのプロパティ名
     */
    public static PropertyName<String> userId() {
        return new PropertyName<String>("userId");
    }

    /**
     * kiguFugouのプロパティ名を返します。
     * 
     * @return kiguFugouのプロパティ名
     */
    public static PropertyName<String> kiguFugou() {
        return new PropertyName<String>("kiguFugou");
    }

    /**
     * partsMaterialのプロパティ名を返します。
     * 
     * @return partsMaterialのプロパティ名
     */
    public static PropertyName<String> partsMaterial() {
        return new PropertyName<String>("partsMaterial");
    }

    /**
     * partsCodeのプロパティ名を返します。
     * 
     * @return partsCodeのプロパティ名
     */
    public static PropertyName<String> partsCode() {
        return new PropertyName<String>("partsCode");
    }

    /**
     * partSnのプロパティ名を返します。
     * 
     * @return partSnのプロパティ名
     */
    public static PropertyName<String> partSn() {
        return new PropertyName<String>("partSn");
    }

    /**
     * torqueIdのプロパティ名を返します。
     * 
     * @return torqueIdのプロパティ名
     */
    public static PropertyName<String> torqueId() {
        return new PropertyName<String>("torqueId");
    }

    /**
     * torqueCountのプロパティ名を返します。
     * 
     * @return torqueCountのプロパティ名
     */
    public static PropertyName<BigDecimal> torqueCount() {
        return new PropertyName<BigDecimal>("torqueCount");
    }

    /**
     * torqueNeedCountのプロパティ名を返します。
     * 
     * @return torqueNeedCountのプロパティ名
     */
    public static PropertyName<BigDecimal> torqueNeedCount() {
        return new PropertyName<BigDecimal>("torqueNeedCount");
    }

    /**
     * testDeviceのプロパティ名を返します。
     * 
     * @return testDeviceのプロパティ名
     */
    public static PropertyName<String> testDevice() {
        return new PropertyName<String>("testDevice");
    }

    /**
     * testDeviceRstのプロパティ名を返します。
     * 
     * @return testDeviceRstのプロパティ名
     */
    public static PropertyName<String> testDeviceRst() {
        return new PropertyName<String>("testDeviceRst");
    }

    /**
     * checkBoxのプロパティ名を返します。
     * 
     * @return checkBoxのプロパティ名
     */
    public static PropertyName<String> checkBox() {
        return new PropertyName<String>("checkBox");
    }

    /**
     * senserNowのプロパティ名を返します。
     * 
     * @return senserNowのプロパティ名
     */
    public static PropertyName<String> senserNow() {
        return new PropertyName<String>("senserNow");
    }

    /**
     * senserNextのプロパティ名を返します。
     * 
     * @return senserNextのプロパティ名
     */
    public static PropertyName<String> senserNext() {
        return new PropertyName<String>("senserNext");
    }

    /**
     * logTypeIdのプロパティ名を返します。
     * 
     * @return logTypeIdのプロパティ名
     */
    public static PropertyName<String> logTypeId() {
        return new PropertyName<String>("logTypeId");
    }

    /**
     * logDataのプロパティ名を返します。
     * 
     * @return logDataのプロパティ名
     */
    public static PropertyName<String> logData() {
        return new PropertyName<String>("logData");
    }

    /**
     * sagyoModeのプロパティ名を返します。
     * 
     * @return sagyoModeのプロパティ名
     */
    public static PropertyName<BigDecimal> sagyoMode() {
        return new PropertyName<BigDecimal>("sagyoMode");
    }

    /**
     * spareNum1のプロパティ名を返します。
     * 
     * @return spareNum1のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum1() {
        return new PropertyName<BigDecimal>("spareNum1");
    }

    /**
     * spareNum2のプロパティ名を返します。
     * 
     * @return spareNum2のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum2() {
        return new PropertyName<BigDecimal>("spareNum2");
    }

    /**
     * spareNum3のプロパティ名を返します。
     * 
     * @return spareNum3のプロパティ名
     */
    public static PropertyName<BigDecimal> spareNum3() {
        return new PropertyName<BigDecimal>("spareNum3");
    }

    /**
     * spareText1のプロパティ名を返します。
     * 
     * @return spareText1のプロパティ名
     */
    public static PropertyName<String> spareText1() {
        return new PropertyName<String>("spareText1");
    }

    /**
     * spareText2のプロパティ名を返します。
     * 
     * @return spareText2のプロパティ名
     */
    public static PropertyName<String> spareText2() {
        return new PropertyName<String>("spareText2");
    }

    /**
     * spareText3のプロパティ名を返します。
     * 
     * @return spareText3のプロパティ名
     */
    public static PropertyName<String> spareText3() {
        return new PropertyName<String>("spareText3");
    }

    /**
     * insProgのプロパティ名を返します。
     * 
     * @return insProgのプロパティ名
     */
    public static PropertyName<String> insProg() {
        return new PropertyName<String>("insProg");
    }

    /**
     * insTimのプロパティ名を返します。
     * 
     * @return insTimのプロパティ名
     */
    public static PropertyName<Timestamp> insTim() {
        return new PropertyName<Timestamp>("insTim");
    }

    /**
     * insUserSidのプロパティ名を返します。
     * 
     * @return insUserSidのプロパティ名
     */
    public static PropertyName<Integer> insUserSid() {
        return new PropertyName<Integer>("insUserSid");
    }

    /**
     * updProgのプロパティ名を返します。
     * 
     * @return updProgのプロパティ名
     */
    public static PropertyName<String> updProg() {
        return new PropertyName<String>("updProg");
    }

    /**
     * updTimのプロパティ名を返します。
     * 
     * @return updTimのプロパティ名
     */
    public static PropertyName<Timestamp> updTim() {
        return new PropertyName<Timestamp>("updTim");
    }

    /**
     * updUserSidのプロパティ名を返します。
     * 
     * @return updUserSidのプロパティ名
     */
    public static PropertyName<Integer> updUserSid() {
        return new PropertyName<Integer>("updUserSid");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _TrWorkStepJskNames extends PropertyName<TrWorkStepJskEntity> {

        /**
         * インスタンスを構築します。
         */
        public _TrWorkStepJskNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _TrWorkStepJskNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _TrWorkStepJskNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * createdOnのプロパティ名を返します。
         *
         * @return createdOnのプロパティ名
         */
        public PropertyName<Timestamp> createdOn() {
            return new PropertyName<Timestamp>(this, "createdOn");
        }

        /**
         * createdByのプロパティ名を返します。
         *
         * @return createdByのプロパティ名
         */
        public PropertyName<String> createdBy() {
            return new PropertyName<String>(this, "createdBy");
        }

        /**
         * modifiedOnのプロパティ名を返します。
         *
         * @return modifiedOnのプロパティ名
         */
        public PropertyName<Timestamp> modifiedOn() {
            return new PropertyName<Timestamp>(this, "modifiedOn");
        }

        /**
         * modifiedByのプロパティ名を返します。
         *
         * @return modifiedByのプロパティ名
         */
        public PropertyName<String> modifiedBy() {
            return new PropertyName<String>(this, "modifiedBy");
        }

        /**
         * sasizuNoのプロパティ名を返します。
         *
         * @return sasizuNoのプロパティ名
         */
        public PropertyName<String> sasizuNo() {
            return new PropertyName<String>(this, "sasizuNo");
        }

        /**
         * subNoのプロパティ名を返します。
         *
         * @return subNoのプロパティ名
         */
        public PropertyName<BigDecimal> subNo() {
            return new PropertyName<BigDecimal>(this, "subNo");
        }

        /**
         * sagyoSeqのプロパティ名を返します。
         *
         * @return sagyoSeqのプロパティ名
         */
        public PropertyName<String> sagyoSeq() {
            return new PropertyName<String>(this, "sagyoSeq");
        }

        /**
         * stIdのプロパティ名を返します。
         *
         * @return stIdのプロパティ名
         */
        public PropertyName<BigDecimal> stId() {
            return new PropertyName<BigDecimal>(this, "stId");
        }

        /**
         * stepNoのプロパティ名を返します。
         *
         * @return stepNoのプロパティ名
         */
        public PropertyName<String> stepNo() {
            return new PropertyName<String>(this, "stepNo");
        }

        /**
         * startTimeのプロパティ名を返します。
         *
         * @return startTimeのプロパティ名
         */
        public PropertyName<Timestamp> startTime() {
            return new PropertyName<Timestamp>(this, "startTime");
        }

        /**
         * endTimeのプロパティ名を返します。
         *
         * @return endTimeのプロパティ名
         */
        public PropertyName<Timestamp> endTime() {
            return new PropertyName<Timestamp>(this, "endTime");
        }

        /**
         * workTimeのプロパティ名を返します。
         *
         * @return workTimeのプロパティ名
         */
        public PropertyName<BigDecimal> workTime() {
            return new PropertyName<BigDecimal>(this, "workTime");
        }

        /**
         * plantCdのプロパティ名を返します。
         *
         * @return plantCdのプロパティ名
         */
        public PropertyName<String> plantCd() {
            return new PropertyName<String>(this, "plantCd");
        }

        /**
         * seizouLnCdのプロパティ名を返します。
         *
         * @return seizouLnCdのプロパティ名
         */
        public PropertyName<String> seizouLnCd() {
            return new PropertyName<String>(this, "seizouLnCd");
        }

        /**
         * seizouLnNmのプロパティ名を返します。
         *
         * @return seizouLnNmのプロパティ名
         */
        public PropertyName<String> seizouLnNm() {
            return new PropertyName<String>(this, "seizouLnNm");
        }

        /**
         * processCdのプロパティ名を返します。
         *
         * @return processCdのプロパティ名
         */
        public PropertyName<String> processCd() {
            return new PropertyName<String>(this, "processCd");
        }

        /**
         * processNmのプロパティ名を返します。
         *
         * @return processNmのプロパティ名
         */
        public PropertyName<String> processNm() {
            return new PropertyName<String>(this, "processNm");
        }

        /**
         * lnNoのプロパティ名を返します。
         *
         * @return lnNoのプロパティ名
         */
        public PropertyName<String> lnNo() {
            return new PropertyName<String>(this, "lnNo");
        }

        /**
         * lnNmのプロパティ名を返します。
         *
         * @return lnNmのプロパティ名
         */
        public PropertyName<String> lnNm() {
            return new PropertyName<String>(this, "lnNm");
        }

        /**
         * stNoのプロパティ名を返します。
         *
         * @return stNoのプロパティ名
         */
        public PropertyName<String> stNo() {
            return new PropertyName<String>(this, "stNo");
        }

        /**
         * stNmのプロパティ名を返します。
         *
         * @return stNmのプロパティ名
         */
        public PropertyName<String> stNm() {
            return new PropertyName<String>(this, "stNm");
        }

        /**
         * sagyokuのプロパティ名を返します。
         *
         * @return sagyokuのプロパティ名
         */
        public PropertyName<String> sagyoku() {
            return new PropertyName<String>(this, "sagyoku");
        }

        /**
         * pgmNoのプロパティ名を返します。
         *
         * @return pgmNoのプロパティ名
         */
        public PropertyName<String> pgmNo() {
            return new PropertyName<String>(this, "pgmNo");
        }

        /**
         * userIdのプロパティ名を返します。
         *
         * @return userIdのプロパティ名
         */
        public PropertyName<String> userId() {
            return new PropertyName<String>(this, "userId");
        }

        /**
         * kiguFugouのプロパティ名を返します。
         *
         * @return kiguFugouのプロパティ名
         */
        public PropertyName<String> kiguFugou() {
            return new PropertyName<String>(this, "kiguFugou");
        }

        /**
         * partsMaterialのプロパティ名を返します。
         *
         * @return partsMaterialのプロパティ名
         */
        public PropertyName<String> partsMaterial() {
            return new PropertyName<String>(this, "partsMaterial");
        }

        /**
         * partsCodeのプロパティ名を返します。
         *
         * @return partsCodeのプロパティ名
         */
        public PropertyName<String> partsCode() {
            return new PropertyName<String>(this, "partsCode");
        }

        /**
         * partSnのプロパティ名を返します。
         *
         * @return partSnのプロパティ名
         */
        public PropertyName<String> partSn() {
            return new PropertyName<String>(this, "partSn");
        }

        /**
         * torqueIdのプロパティ名を返します。
         *
         * @return torqueIdのプロパティ名
         */
        public PropertyName<String> torqueId() {
            return new PropertyName<String>(this, "torqueId");
        }

        /**
         * torqueCountのプロパティ名を返します。
         *
         * @return torqueCountのプロパティ名
         */
        public PropertyName<BigDecimal> torqueCount() {
            return new PropertyName<BigDecimal>(this, "torqueCount");
        }

        /**
         * torqueNeedCountのプロパティ名を返します。
         *
         * @return torqueNeedCountのプロパティ名
         */
        public PropertyName<BigDecimal> torqueNeedCount() {
            return new PropertyName<BigDecimal>(this, "torqueNeedCount");
        }

        /**
         * testDeviceのプロパティ名を返します。
         *
         * @return testDeviceのプロパティ名
         */
        public PropertyName<String> testDevice() {
            return new PropertyName<String>(this, "testDevice");
        }

        /**
         * testDeviceRstのプロパティ名を返します。
         *
         * @return testDeviceRstのプロパティ名
         */
        public PropertyName<String> testDeviceRst() {
            return new PropertyName<String>(this, "testDeviceRst");
        }

        /**
         * checkBoxのプロパティ名を返します。
         *
         * @return checkBoxのプロパティ名
         */
        public PropertyName<String> checkBox() {
            return new PropertyName<String>(this, "checkBox");
        }

        /**
         * senserNowのプロパティ名を返します。
         *
         * @return senserNowのプロパティ名
         */
        public PropertyName<String> senserNow() {
            return new PropertyName<String>(this, "senserNow");
        }

        /**
         * senserNextのプロパティ名を返します。
         *
         * @return senserNextのプロパティ名
         */
        public PropertyName<String> senserNext() {
            return new PropertyName<String>(this, "senserNext");
        }

        /**
         * logTypeIdのプロパティ名を返します。
         *
         * @return logTypeIdのプロパティ名
         */
        public PropertyName<String> logTypeId() {
            return new PropertyName<String>(this, "logTypeId");
        }

        /**
         * logDataのプロパティ名を返します。
         *
         * @return logDataのプロパティ名
         */
        public PropertyName<String> logData() {
            return new PropertyName<String>(this, "logData");
        }

        /**
         * sagyoModeのプロパティ名を返します。
         *
         * @return sagyoModeのプロパティ名
         */
        public PropertyName<BigDecimal> sagyoMode() {
            return new PropertyName<BigDecimal>(this, "sagyoMode");
        }

        /**
         * spareNum1のプロパティ名を返します。
         *
         * @return spareNum1のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum1() {
            return new PropertyName<BigDecimal>(this, "spareNum1");
        }

        /**
         * spareNum2のプロパティ名を返します。
         *
         * @return spareNum2のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum2() {
            return new PropertyName<BigDecimal>(this, "spareNum2");
        }

        /**
         * spareNum3のプロパティ名を返します。
         *
         * @return spareNum3のプロパティ名
         */
        public PropertyName<BigDecimal> spareNum3() {
            return new PropertyName<BigDecimal>(this, "spareNum3");
        }

        /**
         * spareText1のプロパティ名を返します。
         *
         * @return spareText1のプロパティ名
         */
        public PropertyName<String> spareText1() {
            return new PropertyName<String>(this, "spareText1");
        }

        /**
         * spareText2のプロパティ名を返します。
         *
         * @return spareText2のプロパティ名
         */
        public PropertyName<String> spareText2() {
            return new PropertyName<String>(this, "spareText2");
        }

        /**
         * spareText3のプロパティ名を返します。
         *
         * @return spareText3のプロパティ名
         */
        public PropertyName<String> spareText3() {
            return new PropertyName<String>(this, "spareText3");
        }

        /**
         * insProgのプロパティ名を返します。
         *
         * @return insProgのプロパティ名
         */
        public PropertyName<String> insProg() {
            return new PropertyName<String>(this, "insProg");
        }

        /**
         * insTimのプロパティ名を返します。
         *
         * @return insTimのプロパティ名
         */
        public PropertyName<Timestamp> insTim() {
            return new PropertyName<Timestamp>(this, "insTim");
        }

        /**
         * insUserSidのプロパティ名を返します。
         *
         * @return insUserSidのプロパティ名
         */
        public PropertyName<Integer> insUserSid() {
            return new PropertyName<Integer>(this, "insUserSid");
        }

        /**
         * updProgのプロパティ名を返します。
         *
         * @return updProgのプロパティ名
         */
        public PropertyName<String> updProg() {
            return new PropertyName<String>(this, "updProg");
        }

        /**
         * updTimのプロパティ名を返します。
         *
         * @return updTimのプロパティ名
         */
        public PropertyName<Timestamp> updTim() {
            return new PropertyName<Timestamp>(this, "updTim");
        }

        /**
         * updUserSidのプロパティ名を返します。
         *
         * @return updUserSidのプロパティ名
         */
        public PropertyName<Integer> updUserSid() {
            return new PropertyName<Integer>(this, "updUserSid");
        }
    }
}
