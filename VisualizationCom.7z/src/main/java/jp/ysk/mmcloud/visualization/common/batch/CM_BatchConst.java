/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/23| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.batch;

/**
 *
 * バッチ処理共通定数.<br>
 *<br>
 * 概要:<br>
 *  バッチ処理共通の定数クラス
 *<br>
 */
public abstract class CM_BatchConst {

    /**
     * 実行ロックファイルパス.
     */
    public static final String PATH_LOCK = "/var/lock/mmcloud/batch/";

    /**
     * 実行ロックファイルパス(ERP用).
     */
    public static final String PATH_LOCK_ERP = "/var/lock/mmcloud/batch_erp/";

    /**
     * 実行ロックファイル名.
     */
    public static final String FILE_LOCK_TAIL = "-lock.txt";

    /**
     * 登録ユーザSID.
     */
    public static final Integer DEFAULT_USER_SID = -1;

    /**
     *
     * ログ種別.<br>
     *<br>
     * 概要:<br>
     *  ログ種別の定数定義
     *<br>
     */
    public abstract class LogType {

        /**
         * デフォルト.
         */
        public static final int DEFAULT = 2;
    }

    /**
     *
     * 処理結果コード.<br>
     *<br>
     * 概要:<br>
     *  処理結果コードの定数定義
     *<br>
     */
    public abstract class ResultCode {

        /**
         * 正常終了(0).
         */
        public static final int RET_OK = 0;

        /**
         * 異常終了コード(-1).
         */
        public static final int RET_NG = -1;
    }

    /**
     *
     * SQL共通パラメータ.<br>
     *<br>
     * 概要:<br>
     * SQL共通パラメータ定義
     *<br>
     */
    public abstract class COMMON_SQL_PARAM {

        /**
         * ラインID.
         */
        public static final String LINE_ID = "lineId";

        /**
         * 開始日時.
         */
        public static final String START_TIME = "startTime";

        /**
         * 終了日時.
         */
        public static final String END_TIME = "endTime";

        /**
         * 開始日時.
         */
        public static final String START_DATE = "startDate";

        /**
         * 終了日時.
         */
        public static final String END_DATE = "endDate";

        /**
         * ユーザ名.
         */
        public static final String USER_NAME = "userName";

        /**
         * 次ライン番号.
         */
        public static final String N_LINE_ID = "NLineId";

        /**
         * 次ステーション番号.
         */
        public static final String N_STATION_NO = "NStationNo";

    }

    /**
     *
     * ライン作業結果.<br>
     *<br>
     * 概要:<br>
     *  ライン作業結果
     *<br>
     */
    public abstract class WORK_STATUS {

        /**
         * 作業完了.
         */
        public static final int END = 90;

    }

    /**
     *
     * ライン作業結果.<br>
     *<br>
     * 概要:<br>
     *  ライン作業結果
     *<br>
     */
    public abstract class WORK_RESULT {

        /**
         * 生産開始.
         */
        public static final int WORK_START = 1;

        /**
         * 生産完了.
         */
        public static final int SUCCESS = 90;

        /**
         * NG完了.
         */
        public static final int ERROR = 97;
    }
}
