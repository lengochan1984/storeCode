package jp.ysk.mmcloud.visualization.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CM_A09_SearchPldInfo {

    /**
     * 工場プルダウン.
     */
    public  List<Map<String, String>> pldPlantList = new ArrayList<Map<String, String>>();

    /**
     * グループプルダウン.
     */
    public List<Map<String, String>> pldSeizouLineList = new ArrayList<Map<String, String>>();

    /**
     * ラインプルダウン.
     */
    public List<Map<String, String>> pldLineList = new ArrayList<Map<String, String>>();

    /**
     * 工程プルダウン.
     */
    public List<Map<String, String>> pldProcessList = new ArrayList<Map<String, String>>();

    /**
     * ステーションプルダウン.
     */
    public List<Map<String, String>> pldStationList = new ArrayList<Map<String, String>>();

//    /**
//     * 製品プルダウン.
//     */
//    public List<Map<String, String>> pldProductList = new ArrayList<Map<String, String>>();

}
