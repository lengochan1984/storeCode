package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * MstRoleSettingエンティティクラス
 * 
 */
@Entity
@Table(name = "mst_role_setting")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/08/10 11:22:19")
public class MstRoleSettingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 役割SID : 役割マスタとリンク */
    @Id
    @Column(precision = 10, nullable = false, unique = false)
    public Integer roleSid;

    /** 機能CD : 機能ID
環境マスタの環境CD="function_cd"とリンク。 */
    @Id
    @Column(length = 64, nullable = false, unique = false)
    public String functionCd;

    /** ページID : ページマスタと他テーブルとのリンクキー
環境マスタの環境CD="page_id"とリンク。 */
    @Id
    @Column(length = 64, nullable = false, unique = false)
    public String pageId;

    /** 権限設定 : 各画面への権限。
0：利用不可
1：利用可能（閲覧可能）
2：利用可能（更新可能）
上記以外：利用不可
名称マスタ（システム用）の名称種別="auth_setting"とリンク。 */
    @Column(length = 1, nullable = false, unique = false)
    public String authSetting;

    /** 削除フラグ : true：有効、false：無効 */
    @Column(length = 1, nullable = false, unique = false)
    public Boolean deleteFlag;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
