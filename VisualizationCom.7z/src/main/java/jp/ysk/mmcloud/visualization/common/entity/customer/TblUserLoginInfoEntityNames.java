package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.sql.Timestamp;
import javax.annotation.Generated;
import org.seasar.extension.jdbc.name.PropertyName;

/**
 * {@link TblUserLoginInfoEntity}のプロパティ名の集合です。
 * 
 */
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.NamesModelFactoryImpl"}, date = "2017/09/08 13:51:41")
public class TblUserLoginInfoEntityNames {

    /**
     * userSidのプロパティ名を返します。
     * 
     * @return userSidのプロパティ名
     */
    public static PropertyName<Integer> userSid() {
        return new PropertyName<Integer>("userSid");
    }

    /**
     * passwdMissCountのプロパティ名を返します。
     * 
     * @return passwdMissCountのプロパティ名
     */
    public static PropertyName<Integer> passwdMissCount() {
        return new PropertyName<Integer>("passwdMissCount");
    }

    /**
     * lastLoginDatetimeのプロパティ名を返します。
     * 
     * @return lastLoginDatetimeのプロパティ名
     */
    public static PropertyName<Timestamp> lastLoginDatetime() {
        return new PropertyName<Timestamp>("lastLoginDatetime");
    }

    /**
     * lastUpdProgのプロパティ名を返します。
     * 
     * @return lastUpdProgのプロパティ名
     */
    public static PropertyName<String> lastUpdProg() {
        return new PropertyName<String>("lastUpdProg");
    }

    /**
     * lastUpdTimのプロパティ名を返します。
     * 
     * @return lastUpdTimのプロパティ名
     */
    public static PropertyName<Timestamp> lastUpdTim() {
        return new PropertyName<Timestamp>("lastUpdTim");
    }

    /**
     * @author S2JDBC-Gen
     */
    public static class _TblUserLoginInfoNames extends PropertyName<TblUserLoginInfoEntity> {

        /**
         * インスタンスを構築します。
         */
        public _TblUserLoginInfoNames() {
        }

        /**
         * インスタンスを構築します。
         * 
         * @param name
         *            名前
         */
        public _TblUserLoginInfoNames(final String name) {
            super(name);
        }

        /**
         * インスタンスを構築します。
         * 
         * @param parent
         *            親
         * @param name
         *            名前
         */
        public _TblUserLoginInfoNames(final PropertyName<?> parent, final String name) {
            super(parent, name);
        }

        /**
         * userSidのプロパティ名を返します。
         *
         * @return userSidのプロパティ名
         */
        public PropertyName<Integer> userSid() {
            return new PropertyName<Integer>(this, "userSid");
        }

        /**
         * passwdMissCountのプロパティ名を返します。
         *
         * @return passwdMissCountのプロパティ名
         */
        public PropertyName<Integer> passwdMissCount() {
            return new PropertyName<Integer>(this, "passwdMissCount");
        }

        /**
         * lastLoginDatetimeのプロパティ名を返します。
         *
         * @return lastLoginDatetimeのプロパティ名
         */
        public PropertyName<Timestamp> lastLoginDatetime() {
            return new PropertyName<Timestamp>(this, "lastLoginDatetime");
        }

        /**
         * lastUpdProgのプロパティ名を返します。
         *
         * @return lastUpdProgのプロパティ名
         */
        public PropertyName<String> lastUpdProg() {
            return new PropertyName<String>(this, "lastUpdProg");
        }

        /**
         * lastUpdTimのプロパティ名を返します。
         *
         * @return lastUpdTimのプロパティ名
         */
        public PropertyName<Timestamp> lastUpdTim() {
            return new PropertyName<Timestamp>(this, "lastUpdTim");
        }
    }
}
