/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+=======================================+========+==============
 *  DATE      | Comments                              | Rev    | SIGN
 * ===========+=======================================+========+==============
 *  2014/04/19| 新規作成                              | 1.00.00| YSK)鬼丸
 *  2014/09/22| <10101-015> 点検保守状況画面追加      | 1.02.00| YSK)中田
 *  2014/12/01| <20000-005> 仕様変更No.11             | 3.00.00| US)楢崎
 *  2014/12/11| <20000-006> 変更仕様一覧No.18         | 3.00.00| YSK)中田
 *  2014/12/15| <20000-019> 変更仕様No.13             | 3.00.00| YSK)中田
 *  2014/12/17| <20000-024> 共通関数名修正            | 3.00.00| YSK)中田
 *  2014/12/17| <20000-005> 変更仕様No.11             | 3.00.00| YSK)中田
 *  2014/12/21| <20000-026> 仕様変更No.9              | 3.00.00| YSK)中田
 *  2015/01/06| <20000-028> 仕様変更No.32             | 3.00.00| YSK)鬼丸
 *  2014/01/09| <20000-028> 仕様変更No.32             | 3.00.00| US)苗
 *  2015/05/13| <30003-019> 変更仕様No.7              | 3.01.00| US)楢崎
 *  2015/06/25| <30003-033> 変更仕様No.12             | 3.01.00| US)萩尾
 *  2015/07/08| <30003-037> 変更仕様No.23             | 3.01.00| US)楢崎
 *  2015/12/15| <40000-025> Ver.4.00.00 変更仕様No.25 | 4.00.00| US)楢崎
 *  2015/12/22| <40000-025> Ver.4.00.00 変更仕様No.25 | 4.00.00| US)萩尾
 *  2016/01/04| <40000-027> Ver.4.00.00 変更仕様No.27 | 4.00.00| US)萩尾
 *  2016/01/04| <40000-017> Ver.4.00.00 変更仕様No.17 | 4.00.00| US)清水
 *  2016/01/21| <40000-028> 変更仕様No.28             | 4.00.00| US)安永
 *  2016/01/26| <40000-028> Ver.4.00.00 変更仕様No.28 | 4.00.00| US)清水
 *  2016/08/11| <C1.01> 不具合分析画面 対応           | C1.01  | US)楢崎
 * -----------+---------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.service;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageOutputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.util.FW01_03_CreateSingleSelectTagUtil;
import jp.ysk.fw.util.FW01_03_CreateSingleSelectTagUtil.ADD_TYPE;
import jp.ysk.mmcloud.common.dao.CM_MstMainteStatusDao;
import jp.ysk.mmcloud.common.dto.CM_A03_SessionDto;
import jp.ysk.mmcloud.common.entity.customer.MstAlarmEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstDeviceEntity;
import jp.ysk.mmcloud.common.entity.customer.MstDeviceEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstDistributeDataEntity;
import jp.ysk.mmcloud.common.entity.customer.MstDistributeDataEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstDistributeDataVersionEntity;
import jp.ysk.mmcloud.common.entity.customer.MstDistributeDataVersionEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstDocumentEntity;
import jp.ysk.mmcloud.common.entity.customer.MstDocumentEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstGroupEntity;
import jp.ysk.mmcloud.common.entity.customer.MstMailTemplateEntity;
import jp.ysk.mmcloud.common.entity.customer.MstMainteStatusEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstModelEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstUserEntity;
import jp.ysk.mmcloud.common.entity.customer.MstUserEntityNames;
import jp.ysk.mmcloud.common.entity.customer.RelAlarmMainteEntityNames;
import jp.ysk.mmcloud.common.entity.customer.RelModelIconEntity;
import jp.ysk.mmcloud.common.entity.customer.RelModelIconEntityNames;
import jp.ysk.mmcloud.common.entity.customer.SysEnvEntity;
import jp.ysk.mmcloud.common.entity.customer.SysEnvEntityNames;
import jp.ysk.mmcloud.common.entity.customer.SysNameEntityNames;
import jp.ysk.mmcloud.common.entity.customer.TblAlarmStateDataEntityNames;
import jp.ysk.mmcloud.common.entity.customer.TblCommentEntityNames;
import jp.ysk.mmcloud.common.service.CM_AlarmHistoryService;
import jp.ysk.mmcloud.common.util.CM_DisplayCharResourceUtil;
import jp.ysk.mmcloud.common.util.CM_LoggerUtil;
import jp.ysk.mmcloud.common.util.CM_SysEnvDataUtil;
import jp.ysk.mmcloud.common.util.CM_SysNameDataUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.action.CM_A02_ListAction;
import jp.ysk.mmcloud.visualization.common.dao.CM_GetMstDataDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_MstDocumentDao;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaEquipEntityNames;
//import jp.ysk.mmcloud.visualization.common.entity.customer.MstErpModelGroupCategory01EntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaHinmokuEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaLineEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaMesWorkStepEntityNames;
//import jp.ysk.mmcloud.visualization.common.entity.customer.MstLineGroupEntityNames;
//import jp.ysk.mmcloud.visualization.common.entity.customer.MstLineGroupNameEntityNames;
//import jp.ysk.mmcloud.visualization.common.entity.customer.MstModelGroupEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantMierukaEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaProcessEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaSeizouLineEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaStationEntityNames;
import jp.ysk.mmcloud.visualization.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.visualization.common.util.CM_GraphUtil;
import jp.ysk.mmcloud.visualization.common.util.CM_MessageUtil;

import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.beans.util.Beans;
import org.seasar.framework.util.StringUtil;

/**
 *
 * マスターデータ取得サービス.<br>
 *<br>
 * 概要:<br>
 *   マスターデータ取得用サービスクラス
 *<br>
 */
public class CM_GetMstDataService extends CM_BaseService {

    /**
     *  (カラム名の別名)ユーザID.
     */
    private static final String MAPKEY_USER_ID = "userId";

    /**
     *  (カラム名の別名)ユーザ名.
     */
    private static final String MAPKEY_USER_NAME = "userName";

    /**
     *  改行タグ.
     */
    private static final String BR_CODE = "<br>";

    /**
     * Mapキー[グループツリーパス].
     */
    public static final String MAPKEY_TREE_PATH = "treePath";

    /**
     * Mapキー[グループツリーパス名].
     */
    public static final String MAPKEY_TREE_PATH_NAME = "treePathName";

    /**
     * ファイルパス.
     */
    private static final String MAPKEY_FILE_PATH = "filePath";

    /**
     * デフォルトファイルパス.
     */
    private static final String MAPKEY_DEFAULT_FILE_PATH = "defaultFilePath";

    /**
     * コンストラクタ.
     *<br>
     * 概要:<br>
     *   DB接続を行うサービス処理用コンストラクタ
     *<br>
     * @param _sessionDto 共通セッション情報
     */
    public CM_GetMstDataService(final CM_A03_SessionDto _sessionDto) {
        super(_sessionDto);
    }

//    /**
//     *
//     * 役割マスタ情報の取得.<br>
//     *<br>
//     * 概要:<br>
//     *   役割マスタ情報を取得する
//     *<br>
//     * @param _authCode 権限コード
//     * @return 役割マスタ情報
//     */
//    public List<BeanMap> getMstRoleList(final String _authCode) {
//
//        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
//        initCustomerDbDao(cmGetMstDataDao);
//        List<MstRoleEntity> mstDataInfo = null;
//
//        if (_authCode.equals(CM_A04_Const.SYS_ADMIN_AUTH_CD)) {
//            mstDataInfo = cmGetMstDataDao.getMstRoleList();
//        } else {
//            mstDataInfo = cmGetMstDataDao.getMstRolePublishList();
//        }
//
//        List<BeanMap> result = new ArrayList<BeanMap>();
//        BeanMap bm = null;
//        for (MstRoleEntity entity : mstDataInfo) {
//            bm = Beans.createAndCopy(BeanMap.class, entity).execute();
//            result.add(bm);
//        }
//        return result;
//    }
//
//    /**
//     *
//     * 役割マスタ情報の取得.<br>
//     *<br>
//     * 概要:<br>
//     *   役割マスタ情報を取得する
//     *<br>
//     * @param _roleSid 役割SID
//     * @return 役割マスタ情報
//     */
//    public BeanMap getMstRoleInfo(final Integer _roleSid) {
//
//        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
//        initCustomerDbDao(cmGetMstDataDao);
//
//        return cmGetMstDataDao.selectMstRoleInfo(_roleSid);
//    }

    /**
     *
     * ユーザマスタ情報の取得.<br>
     *<br>
     * 概要:<br>
     *   ユーザマスタ情報を取得する
     *<br>
     * @return ユーザマスタ情報
     */
    public List<BeanMap> getMstUserList() {

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);
        List<MstUserEntity> mstDataInfo = cmGetMstDataDao.getMstUserList();

        List<BeanMap> result = new ArrayList<BeanMap>();
        BeanMap bm = null;
        for (MstUserEntity entity : mstDataInfo) {
            bm = Beans.createAndCopy(BeanMap.class, entity).execute();
            result.add(bm);
        }
        return result;
    }

    /**
     *
     * 機器マスタ情報の取得.<br>
     *<br>
     * 概要:<br>
     *   機器マスタ情報を取得する
     *<br>
     * @return 機器マスタ情報
     */
    public List<BeanMap> getMstDeviceList() {

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);
        List<MstDeviceEntity> mstDataInfo = cmGetMstDataDao.getMstDeviceList();

        List<BeanMap> result = new ArrayList<BeanMap>();
        BeanMap bm = null;
        for (MstDeviceEntity entity : mstDataInfo) {
            bm = Beans.createAndCopy(BeanMap.class, entity).execute();
            result.add(bm);
        }
        return result;
    }

    /**
     *
     * 指定機器の情報取得.<br>
     *<br>
     * 概要:<br>
     *   指定機器の機器ID、名称を取得する
     *<br>
     * @param _deviceSid 機器SID
     * @return 件数
     */
    public BeanMap getDeviceInfo(final int _deviceSid) {

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);
        return cmGetMstDataDao.selectMachineInfo(_deviceSid);
    }

    /**
     *
     * 型番マスタ情報リストの取得.<br>
     *<br>
     * 概要:<br>
     *   型番マスタ情報リストを取得する
     *<br>
     * @return 型番マスタ情報リスト
     */
    public List<BeanMap> getMstModelList() {

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> modelNameList = cmGetMstDataDao.selectModelNameList(false, this.sessionDto.ssn_UserSID, false, true);

        return modelNameList;
    }

    /**
     *
     * 対象SIDの型番情報取得.<br>
     *<br>
     * 概要:<br>
     *   対象SIDの型番データを取得する。
     *<br>
     * @param _sid SID
     * @return SIDで指定されるデータ
     */
    public BeanMap getModelInfo(final int _sid) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        return cmGetMstDataDao.selectModelInfo(_sid);
    }

    /**
     *
     * グループマスタ情報の取得.<br>
     *<br>
     * 概要:<br>
     *   グループマスタ情報を取得する
     *<br>
     * @return グループマスタ情報
     */
    public List<BeanMap> getMstGroupList() {

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);
        List<MstGroupEntity> mstDataInfo = cmGetMstDataDao.getMstGroupList();

        List<BeanMap> result = new ArrayList<BeanMap>();
        BeanMap bm = null;
        for (MstGroupEntity entity : mstDataInfo) {
            bm = Beans.createAndCopy(BeanMap.class, entity).execute();
            result.add(bm);
        }
        return result;
    }

    /**
     *
     * グループツリー情報取得処理.<br>
     *<br>
     * 概要:<br>
     *   グループツリー情報を取得する
     *<br>
     * @param _userSid ユーザSID
     * @return  グループツリー情報
     */
    public List<BeanMap> getGroupTreeInfoList(final int _userSid) {

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> childTreeList = cmGetMstDataDao.getGroupTreeInfoList(_userSid);

        // 親ツリーを生成しない。
        //        List<BeanMap> parentTreeList = null;
        //        // ツリー情報が取得できた場合は、対象ユーザのルートノードの親ノード情報を取得
        //        if (childTreeList != null && childTreeList.size() > 0) {
        //            // 先頭のツリーパスを取得
        //            Object objTootTreePath = childTreeList.get(0).get(MstGroupEntityNames.treePath());
        //
        //            // ルートツリーパスが存在する場合は、親ノードのグループIDを取得
        //            if (!CM_CommonUtil.isNullOrBlank(objTootTreePath)) {
        //                String strTootTreePath = objTootTreePath.toString();
        //                String[] strGroupIdListTemp = strTootTreePath.split("\\.");
        //
        //                // 親ノードが存在する場合のみ親ノード情報を取得
        //                if (strGroupIdListTemp.length > 1) {
        //
        //                    // 最後のグループは現状のルートノードなので、それ以外の親ノード情報をセット
        //                    String[] strGroupIdList = new String[strGroupIdListTemp.length - 1];
        //                    for (int i = 0; i < strGroupIdListTemp.length - 1; i++) {
        //                        strGroupIdList[i] = strGroupIdListTemp[i];
        //                    }
        //
        //                    // 親ノード情報を取得
        //                    parentTreeList = cmGetMstDataDao.getParentGroupTreeInfoList(strGroupIdList);
        //
        //                    // 親ノード情報が取得できた場合は、対象ユーザのルートノードの親ノード情報を登録
        //                    if (parentTreeList != null && parentTreeList.size() > 0) {
        //                        for (int i = 0; i < parentTreeList.size(); i++) {
        //                            childTreeList.add(i, parentTreeList.get(i));
        //                        }
        //                    }
        //                }
        //            }
        //        }

        //データの抽出
        return childTreeList;
    }

    /**
     *
     * 点検保守状況一覧データ取得.<br>
     *<br>
     * 概要:<br>
     *   点検保守状況の一覧データを取得する
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @param _offsetInfo オフセット情報
     * @return 抽出データ
     */
    public List<BeanMap> getMainteStatusDataList(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo,
            final Map<String, Integer> _offsetInfo) {

        _formInfo.put(CM_MstMainteStatusDao.MAPKEY_TXT_USER_SID, this.sessionDto.ssn_UserSID);

        ////////////////////////////////////////////////////////////
        // 一覧取得処理

        CM_MstMainteStatusDao cmGetMstMainteStatusDao = new CM_MstMainteStatusDao();

        cmGetMstMainteStatusDao.setCustomerDbInfo(this.sessionDto.ssn_ConnectString,
                this.sessionDto.ssn_ConnectUserID, this.sessionDto.ssn_ConnectPassword);

        // ログインユーザーが管理者かどうかをチェック
        boolean isAdmin = CM_CommonUtil.checkSystemGroup(this.sessionDto);

        List<BeanMap> getData = cmGetMstMainteStatusDao.selecDataList(_formInfo, _mapSearchCondInfo, _offsetInfo, isAdmin);

        List<BeanMap> dataList = new ArrayList<BeanMap>();
        if (getData == null || getData.size() == 0) {
            // 取得したデータが0件の場合は処理修了
            return dataList;
        }

        final CM_AlarmHistoryService cmAlarmHistoryService = new CM_AlarmHistoryService(this.sessionDto);

        ////////////////////////////////////////////////////////////
        // データを画面表示用に変換
        for (BeanMap map : getData) {

            ////////////////////////////////////////////////////////////
            // 時刻変換
            if (map.get(MstMainteStatusEntityNames.mainteDatetime()) != null) {

                Timestamp mainteDatetime = (Timestamp) map.get(MstMainteStatusEntityNames.mainteDatetime());

                String mainteDatetimeWithTimeZone = CM_CommonUtil.getTimeGmtToTimezone(
                        mainteDatetime,
                        map.get(MstMainteStatusEntityNames.mainteTimezoneCd()).toString(),
                        CM_A04_Const.DATE_FORMAT_MIN_HYPHEN);

                String mainteDatatimeWithLoginUserLocale = CM_CommonUtil.getTimeGmtToTimezone(
                        mainteDatetime,
                        this.sessionDto.ssn_UserTimezoneCD,
                        CM_A04_Const.DATE_FORMAT_MIN_HYPHEN);


                map.put(MstMainteStatusEntityNames.mainteDatetime().toString(), mainteDatetimeWithTimeZone);
                map.put(CM_MstMainteStatusDao.MAPKEY_TXT_MAINTE_DATE_L, mainteDatatimeWithLoginUserLocale);

            } else {
                map.put(MstMainteStatusEntityNames.mainteDatetime().toString(), FW00_19_Const.HYPHEN_STR);
                map.put(CM_MstMainteStatusDao.MAPKEY_TXT_MAINTE_DATE_L, FW00_19_Const.HYPHEN_STR);
            }

            ////////////////////////////////////////////////////////////
            // 点検種別文字列変換
            BeanMap mainteType = CM_SysNameDataUtil.getName(this.sessionDto,
                    CM_A04_Const.SYS_NAME_MST_NAME_TYPE.MAINTE_TYPE,
                    map.get(MstMainteStatusEntityNames.type()).toString(),
                    this.sessionDto.ssn_UserLangCD);

            if (mainteType != null) {
                if (mainteType.get(SysNameEntityNames.name1()) != null) {
                    map.put(MstMainteStatusEntityNames.type().toString(), mainteType.get(SysNameEntityNames.name1()).toString());
                } else {
                    map.put(MstMainteStatusEntityNames.type().toString(), FW00_19_Const.HYPHEN_STR);
                }
            } else {
                map.put(MstMainteStatusEntityNames.type().toString(), FW00_19_Const.HYPHEN_STR);
            }

            ////////////////////////////////////////////////////////////
            // 点検ステータス文字列変換
            BeanMap mainteStatus = CM_SysNameDataUtil.getName(this.sessionDto,
                    CM_A04_Const.SYS_NAME_MST_NAME_TYPE.MAINTE_STATUS,
                    map.get(MstMainteStatusEntityNames.status()).toString(),
                    this.sessionDto.ssn_UserLangCD);

            if (mainteStatus != null) {
                if (mainteStatus.get(SysNameEntityNames.name1()) != null) {
                    map.put(MstMainteStatusEntityNames.status().toString(), mainteStatus.get(SysNameEntityNames.name1()).toString());
                } else {
                    map.put(MstMainteStatusEntityNames.status().toString(), FW00_19_Const.HYPHEN_STR);
                }
            } else {
                map.put(MstMainteStatusEntityNames.status().toString(), FW00_19_Const.HYPHEN_STR);
            }

            ////////////////////////////////////////////////////////////
            // 国旗表示のためのデータ取得
            String country_path = null;

            BeanMap country = CM_SysEnvDataUtil.selectSysEnv(this.sessionDto,
                    CM_A04_Const.SYS_ENV_MST_ENV_CD.COUNTRY_FLAG,
                    map.get(CM_MstMainteStatusDao.MAPKEY_TXT_COUNTRY_CD).toString());

            if (country.get(SysEnvEntityNames.name()) != null) {
                country_path = country.get(SysEnvEntityNames.name().toString()).toString();
            }

            map.put(CM_MstMainteStatusDao.MAPKEY_TXT_COUNTRY_CD, country_path);

            // アラーム名称
            String alarmName = (String) map.get(MstAlarmEntityNames.alarmName());
            map.put(MstAlarmEntityNames.alarmName().toString(), alarmName);

            // アラームレベル
            String alarmLevel = (String) map.get(MstAlarmEntityNames.alarmLevel());
            map.put(MstAlarmEntityNames.alarmLevel().toString(), alarmLevel);

            // アラーム判定データから情報取得
            List<BeanMap> alarmJudgeDataList = new ArrayList<BeanMap>();
            if (CM_CommonUtil.isNotNullOrBlank(map.get(RelAlarmMainteEntityNames.alarmStateDataSid().toString()))) {
                Long alarmStateDataSid = (Long) map.get(RelAlarmMainteEntityNames.alarmStateDataSid().toString());
                alarmJudgeDataList = cmAlarmHistoryService.getAlarmJudgeDataList(map, String.valueOf(alarmStateDataSid));
            }
            map.put(CM_A04_Const.ALARM_HISTORY_MAPKEY.ALARM_JUDGE_DATA, alarmJudgeDataList);

            // 削除フラグ
            Boolean deleteFlg = (Boolean) map.get(MstAlarmEntityNames.deleteFlag());
            map.put(MstMainteStatusEntityNames.deleteFlag().toString(), String.valueOf(deleteFlg));

            dataList.add(map);
        }

        return dataList;
    }

    /**
     *
     * 点検保守状況一覧データ取得.<br>
     *<br>
     * 概要:<br>
     *   点検保守状況の一覧データを取得する
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return 抽出データ
     */
    public List<BeanMap> getMainteStatusDataCSVList(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {

        _formInfo.put(CM_MstMainteStatusDao.MAPKEY_TXT_USER_SID, this.sessionDto.ssn_UserSID);

        ////////////////////////////////////////////////////////////
        // 一覧取得処理

        CM_MstMainteStatusDao cmGetMstMainteStatusDao = new CM_MstMainteStatusDao();

        cmGetMstMainteStatusDao.setCustomerDbInfo(this.sessionDto.ssn_ConnectString,
                this.sessionDto.ssn_ConnectUserID, this.sessionDto.ssn_ConnectPassword);

        // ログインユーザーが管理者かどうかをチェック
        boolean isAdmin = CM_CommonUtil.checkSystemGroup(this.sessionDto);

        List<BeanMap> getData = cmGetMstMainteStatusDao.selecDataCSVList(_formInfo, _mapSearchCondInfo, isAdmin);

        List<BeanMap> userList = new ArrayList<BeanMap>();
        if (getData == null || getData.size() == 0) {
            // 取得したデータが0件の場合は処理修了
            return userList;
        }

        ////////////////////////////////////////////////////////////
        // データを画面表示用に変換
        for (BeanMap map : getData) {

            ////////////////////////////////////////////////////////////
            // 時刻変換
            if (map.get(MstMainteStatusEntityNames.mainteDatetime()) != null) {

                Timestamp mainteDatetime = (Timestamp) map.get(MstMainteStatusEntityNames.mainteDatetime());

                String mainteDatetimeWithTimeZone = CM_CommonUtil.getTimeGmtToTimezone(
                        mainteDatetime,
                        map.get(MstMainteStatusEntityNames.mainteTimezoneCd()).toString(),
                        CM_A04_Const.DATE_FORMAT_MIN_HYPHEN);

                String mainteDatatimeWithLoginUserLocale = CM_CommonUtil.getTimeGmtToTimezone(
                        mainteDatetime,
                        this.sessionDto.ssn_UserTimezoneCD,
                        CM_A04_Const.DATE_FORMAT_MIN_HYPHEN);


                map.put(MstMainteStatusEntityNames.mainteDatetime().toString(), mainteDatetimeWithTimeZone);
                map.put(CM_MstMainteStatusDao.MAPKEY_TXT_MAINTE_DATE_L, mainteDatatimeWithLoginUserLocale);

            } else {
                map.put(MstMainteStatusEntityNames.mainteDatetime().toString(), FW00_19_Const.HYPHEN_STR);
                map.put(CM_MstMainteStatusDao.MAPKEY_TXT_MAINTE_DATE_L, FW00_19_Const.HYPHEN_STR);
            }

            ////////////////////////////////////////////////////////////
            // 点検種別文字列変換
            BeanMap mainteType = CM_SysNameDataUtil.getName(this.sessionDto,
                    CM_A04_Const.SYS_NAME_MST_NAME_TYPE.MAINTE_TYPE,
                    map.get(MstMainteStatusEntityNames.type()).toString(),
                    this.sessionDto.ssn_UserLangCD);

            if (mainteType != null) {
                if (mainteType.get(SysNameEntityNames.name1()) != null) {
                    map.put(MstMainteStatusEntityNames.type().toString(), mainteType.get(SysNameEntityNames.name1()).toString());
                } else {
                    map.put(MstMainteStatusEntityNames.type().toString(), FW00_19_Const.HYPHEN_STR);
                }
            } else {
                map.put(MstMainteStatusEntityNames.type().toString(), FW00_19_Const.HYPHEN_STR);
            }

            ////////////////////////////////////////////////////////////
            // 点検ステータス文字列変換
            BeanMap mainteStatus = CM_SysNameDataUtil.getName(this.sessionDto,
                    CM_A04_Const.SYS_NAME_MST_NAME_TYPE.MAINTE_STATUS,
                    map.get(MstMainteStatusEntityNames.status()).toString(),
                    this.sessionDto.ssn_UserLangCD);

            if (mainteStatus != null) {
                if (mainteStatus.get(SysNameEntityNames.name1()) != null) {
                    map.put(MstMainteStatusEntityNames.status().toString(), mainteStatus.get(SysNameEntityNames.name1()).toString());
                } else {
                    map.put(MstMainteStatusEntityNames.status().toString(), FW00_19_Const.HYPHEN_STR);
                }
            } else {
                map.put(MstMainteStatusEntityNames.status().toString(), FW00_19_Const.HYPHEN_STR);
            }

        }

        return getData;
    }

    /**
     *
     * 点検保守状況一覧データ取得.<br>
     *<br>
     * 概要:<br>
     *   点検保守状況の一覧データを取得する
     *<br>
     * @param _mainteStatusSid 点検保守SID
     * @return 抽出データ
     */
    public List<BeanMap> getMainteStatusCommentDataCSVList(final int _mainteStatusSid) {

        CM_MstMainteStatusDao cmGetMstMainteStatusDao = new CM_MstMainteStatusDao();
        cmGetMstMainteStatusDao.setCustomerDbInfo(this.sessionDto.ssn_ConnectString,
                this.sessionDto.ssn_ConnectUserID, this.sessionDto.ssn_ConnectPassword);

        List<BeanMap> getData = cmGetMstMainteStatusDao.selectComment(_mainteStatusSid);

        if (getData == null || getData.size() == 0) {
            // 取得したデータが0件の場合は処理終了（空リストを返す）
            List<BeanMap> tmp = new ArrayList<BeanMap>();
            return tmp;
        }

        for (BeanMap bm : getData) {

            // 時刻の変換
            Timestamp commentDatatime = (Timestamp) bm.get(TblCommentEntityNames.commentDatetime());

            String mainteDatatimeWithLoginUserLocale = CM_CommonUtil.getTimeGmtToTimezone(
                    commentDatatime,
                    this.sessionDto.ssn_UserTimezoneCD,
                    CM_A04_Const.DATE_FORMAT_MIN_HYPHEN);

            bm.put(TblCommentEntityNames.commentDatetime().toString(), mainteDatatimeWithLoginUserLocale);


            // 名前の生成
            String lastName = bm.get(MstUserEntityNames.userLastname()).toString();
            String firstName = bm.get(MstUserEntityNames.userFirstname()).toString();
            String name = lastName + FW00_19_Const.SPACE + firstName;
            bm.put(MAPKEY_USER_NAME, name);

            // コメント種別
            String commentType = bm.get(TblCommentEntityNames.commentType()).toString();
            if (CM_A04_Const.MST_MAINTE_STATUS_CONST.APPROVAL_COMMENT.equals(commentType)) {
                commentType = CM_DisplayCharResourceUtil.getDisplayCharValue(
                        this.sessionDto.ssn_CustomerCD, this.sessionDto.ssn_UserLangCD, "MMCDCA010040_029");
            } else {
                commentType = CM_DisplayCharResourceUtil.getDisplayCharValue(
                        this.sessionDto.ssn_CustomerCD, this.sessionDto.ssn_UserLangCD, "MMCDCA010040_030");
            }
            bm.put(TblCommentEntityNames.commentType().toString(), commentType);

            // コメントデータの改行コード置換
            String commentData = bm.get(TblCommentEntityNames.commentData()).toString();
            commentData = commentData.replaceAll(BR_CODE, FW00_19_Const.SPACE);
            bm.put(TblCommentEntityNames.commentData().toString(), commentData);

        }

        return getData;
    }

    /**
     *
     * 点検保守状況データ件数取得.<br>
     *<br>
     * 概要:<br>
     *   点検保守状況一覧のデータ件数を取得する
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return 件数
     */
    public long getMainteStatusDataCount(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {

        CM_MstMainteStatusDao cmGetMstMainteStatusDao = new CM_MstMainteStatusDao();
        cmGetMstMainteStatusDao.setCustomerDbInfo(this.sessionDto.ssn_ConnectString,
                this.sessionDto.ssn_ConnectUserID, this.sessionDto.ssn_ConnectPassword);

        // ログインユーザーが管理者かどうかをチェック
        boolean isAdmin = CM_CommonUtil.checkSystemGroup(this.sessionDto);

        _formInfo.put(CM_MstMainteStatusDao.MAPKEY_TXT_USER_SID, this.sessionDto.ssn_UserSID);

        //データ件数抽出
        return cmGetMstMainteStatusDao.selectDataListCount(_formInfo, _mapSearchCondInfo, isAdmin);
    }

    /**
     *
     * 点検保守状況データCSV出力件数取得.<br>
     *<br>
     * 概要:<br>
     *   点検保守状況一覧のCSVデータ件数を取得する
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return 件数
     */
    public long getMainteStatusCSVDataCount(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {

        long count = 0;

        CM_MstMainteStatusDao cmGetMstMainteStatusDao = new CM_MstMainteStatusDao();
        cmGetMstMainteStatusDao.setCustomerDbInfo(this.sessionDto.ssn_ConnectString,
                this.sessionDto.ssn_ConnectUserID, this.sessionDto.ssn_ConnectPassword);

        _formInfo.put(CM_MstMainteStatusDao.MAPKEY_TXT_USER_SID, this.sessionDto.ssn_UserSID);

        // ログインユーザーが管理者かどうかをチェック
        boolean isAdmin = CM_CommonUtil.checkSystemGroup(this.sessionDto);

        // データ件数抽出
        List<BeanMap> list = cmGetMstMainteStatusDao.selecDataCSVList(_formInfo, _mapSearchCondInfo, isAdmin);

        for (BeanMap data : list) {
            Integer sid = (Integer) data.get(MstMainteStatusEntityNames.sid());

            List<BeanMap> comments = cmGetMstMainteStatusDao.selectComment(sid);

            if (comments.isEmpty()) {
                count++;
            } else {
                count += comments.size();
            }
        }

        return count;
    }

    /**
     *
     * 点検保守状況データ件数取得.<br>
     *<br>
     * 概要:<br>
     *   点検保守状況データを1件取得する
     *<br>
     * @param _sid フォーム情報
     * @return 指定SIDの点検保守状況データ
     */
    public BeanMap getMainteStatusData(final Integer _sid) {

        CM_MstMainteStatusDao cmGetMstMainteStatusDao = new CM_MstMainteStatusDao();
        cmGetMstMainteStatusDao.setCustomerDbInfo(this.sessionDto.ssn_ConnectString,
                this.sessionDto.ssn_ConnectUserID, this.sessionDto.ssn_ConnectPassword);

        // データ抽出
        return cmGetMstMainteStatusDao.selectData(_sid);

    }

    /**
     *
     * 機器名称リスト取得.<br>
     *<br>
     * 概要:<br>
     *   機器名称とSIDのリストを取得する
     *<br>
     * @return 機器名称リスト
     */
    public List<BeanMap> getDeviceNameList() {

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 機器名称リスト抽出
        return cmGetMstDataDao.getDeviceNameList(this.sessionDto.ssn_UserSID);
    }

    /**
     *
     * 製品名称リスト取得.<br>
     *<br>
     * 概要:<br>
     *   製品名称と工場コードのリストを取得する
     *<br>
     *
     *@param _plantCode 工場コード
     *
     * @return 製品名称リスト
     */
    public List<BeanMap> getSeiHinNameList(final String _plantCode) {

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 製品名称リスト抽出
        return cmGetMstDataDao.getSeiHinNameList(_plantCode);
    }
    /**
    *
    * 製品名称プルダウンリスト取得.<br>
    *<br>
    * 概要:<br>
    *   製品名称のプルダウンリストを取得する
    *<br>
    *
    *@param _plantCode 工場コード
    *
    * @return 製品名称プルダウンリスト
    */
   public List<Map<String, String>> getSeiHinNamePld(final String _plantCode) {
       // 製品名称リスト抽出
       return getSeiHinNamePld(getSeiHinNameList(_plantCode));
   }
    /**
     * 製品名称プルダウンリストデータ取得.
     * @param _beanList 製品名称リスト
     * @return 製品プルダウンリストデータ
     */
    private List<Map<String, String>> getSeiHinNamePld(final List<BeanMap> _beanList) {
        final int len = CM_A04_Const.LENGTH.MODEL_NAME_MAX_LENGTH * 2;

        FW01_03_CreateSingleSelectTagUtil fw0103Util = new FW01_03_CreateSingleSelectTagUtil(
                MaHinmokuEntityNames.werks().toString(),
                MaHinmokuEntityNames.vtextInfo1().toString(),
                _beanList, len);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 工場名称リスト取得.<br>
     *<br>
     * 概要:<br>
     *   工場名称と工場コードのリストを取得する
     *<br>
     * @return 工場名称リスト
     */
    public List<BeanMap> getMstPlantNameList() {

        return getMstPlantNameListCore(false, this.sessionDto.ssn_UserSID);
    }

    /**
     * 工場プルダウンリストデータ取得.
     * @return 工場プルダウンリストデータ
     */
    public List<Map<String, String>> getPlantPld() {

        return this.getPlantNamePld(this.getMstPlantNameList(), false);
    }

//    /**
//     * 工場プルダウンリストデータ取得(作業者マスタに存在する工場のみ).
//     * @return 工場プルダウンリストデータ
//     */
//    public List<Map<String, String>> getUserPlantPld(final int _userSid) {
//
//        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
//        initCustomerDbDao(cmGetMstDataDao);
//
//        // 作業者マスタ取得
//        List<MstWorkerEntity> workerList = cmGetMstDataDao.getWorkerEntityList(_userSid);
//        // 全件表示フラグ
//        boolean allFlg = false;
//        // Map化
//        Map<String, MstWorkerEntity> workerMap = new HashMap<String, MstWorkerEntity>();
//        for (MstWorkerEntity workerInfo : workerList) {
//            workerMap.put(workerInfo.plantCode, workerInfo);
//            if (CM_A04_Const.ALL_PLANT_CODE.equals(workerInfo.plantCode)) {
//                allFlg = true;
//            }
//        }
//
//        // 工場名称リスト取得
//        List<BeanMap> plantNameList = this.getMstPlantNameList();
//
//        if (!allFlg) {
//            // 全件表示でない場合
//            for (int index = plantNameList.size() - 1; index >= 0; --index) {
//                BeanMap plantNameData = plantNameList.get(index);
//                String plantCd = (String) plantNameData.get(MaPlantEntityNames.plantCode().toString());
//                MstWorkerEntity workerInfo = workerMap.get(plantCd);
//                if (CM_CommonUtil.isNullOrBlank(workerInfo)) {
//                    // 作業者マスタに存在しない工場は削除
//                    plantNameList.remove(index);
//                }
//            }
//        }
//
//        return this.getPlantNamePld(plantNameList, false);
//    }

    /**
     * 物理的工場プルダウンリストデータ取得.
     * @return 物理的工場プルダウンリストデータ
     */
    public List<Map<String, String>> getPhysicalPlantPld() {

        return this.getPlantNamePld(this.getMstPlantNameListCore(true, null), false);
    }

    /**
     * 工場プルダウンリストデータ取得.
     * @param _isPhysical 物理データ判断
     * @param _userSid ユーザーSID
     * @return 工場プルダウンリストデータ
     */
    private List<BeanMap> getMstPlantNameListCore(final boolean _isPhysical, final Integer _userSid) {

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        if (_isPhysical) {
            // 工場名称リスト抽出
            return cmGetMstDataDao.getPhysicalMstPlantNameList();

        } else {

            // 工場名称リスト抽出
            return cmGetMstDataDao.getMstPlantNameList(_userSid);
        }
    }
    /**
     * 工場プルダウンリストデータ取得.
     * @param _plantList 工場名称リスト
     * @param _addFirstBlank 1件目に空白を追加するかどうか（true:追加する false:追加しない）
     * @return 工場プルダウンリストデータ
     */
    private List<Map<String, String>> getPlantNamePld(final List<BeanMap> _plantList, final boolean _addFirstBlank) {

        final int len = CM_A04_Const.LENGTH.MODEL_NAME_MAX_LENGTH * 2;

        FW01_03_CreateSingleSelectTagUtil fw0103Util = new FW01_03_CreateSingleSelectTagUtil(
                MaPlantEntityNames.plantCd().toString(),
                MaPlantEntityNames.plantNm().toString(),
                _plantList, len);

        if (_addFirstBlank) {
            fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);
        }

        return fw0103Util.getItemList();
    }

    /**
     * ライン名称リスト取得.<br>
     * @param _plantCode 工場コード
     * @return ライン名称リスト
     */
    public List<BeanMap> getMstLineGroupNameList(final String _plantCode) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 工場名称リスト抽出
        return cmGetMstDataDao.getMstLineGroupNameList(_plantCode);
    }

    /**
     * ライン名称リスト取得.<br>
     * @param _plantCode 工場コード
     * @param _seizouLnId 製造ライン（グループ）
     * @param _processId 工程ID
     * @return ライン名称リスト
     */
    public List<BeanMap> getMstLineNameList(final String _plantCode, final String _seizouLnId, final String _processId) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 製造ラインID
        Long seizouLnId = CM_CommonUtil.getLongVal(_seizouLnId);
        // 工程ID
        Long processId = CM_CommonUtil.getLongVal(_processId);

        // 工場名称リスト抽出
        return cmGetMstDataDao.getMstLineNameList(_plantCode, seizouLnId, processId);
    }

    /**
     * ライン名称リスト取得(製品別画面専用).<br>
     * @param _plantCode 工場コード
     * @return ライン名称リスト
     */
    public List<BeanMap> getTblLineGroupPulldownNameList(final String _plantCode) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 工場名称リスト抽出
        return cmGetMstDataDao.getTblLineGroupPulldownNameList(_plantCode);
    }

    /**
     * ラインプルダウンリストデータ取得.
     * @param _beanList ライン名称リスト
     * @return ラインプルダウンリストデータ
     */
    private List<Map<String, String>> getLineGroupPld(final List<BeanMap> _beanList) {

        final int len = CM_A04_Const.LENGTH.MODEL_NAME_MAX_LENGTH * 2;

        FW01_03_CreateSingleSelectTagUtil fw0103Util = new FW01_03_CreateSingleSelectTagUtil(
//                MstLineGroupEntityNames.lineGroupNo().toString(),
//                MstLineGroupNameEntityNames.lineGroupName().toString(),
                MaLineEntityNames.lnId().toString(),
                MaLineEntityNames.lnNm().toString(),
                _beanList, len);

//        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);

        return fw0103Util.getItemList();
    }

    /**
     * ラインプルダウンリストデータ取得.
     * @param _beanList ライン名称リスト
     * @param _blankFlg プルダウン先頭にブランクを入れるかどうか（trueならば先頭をブランクとする）
     * @return ラインプルダウンリストデータ
     */
    private List<Map<String, String>> getLineGroupPld(final List<BeanMap> _beanList, final boolean _blankFlg) {

        final int len = CM_A04_Const.LENGTH.MODEL_NAME_MAX_LENGTH * 2;

        FW01_03_CreateSingleSelectTagUtil fw0103Util = new FW01_03_CreateSingleSelectTagUtil(
//                MstLineGroupEntityNames.lineGroupNo().toString(),
//                MstLineGroupNameEntityNames.lineGroupName().toString(),
                MaLineEntityNames.lnId().toString(),
                MaLineEntityNames.lnNm().toString(),
                _beanList, len);

        if (_blankFlg) {
            fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);
        }

        return fw0103Util.getItemList();
    }

    /**
     * ラインプルダウンリストデータ取得.
     * @param _beanList ライン名称リスト
     * @param _blankFlg プルダウン先頭にブランクを入れるかどうか（trueならば先頭をブランクとする）
     * @return ラインプルダウンリストデータ
     */
    private List<Map<String, String>> getLinePld(final List<BeanMap> _beanList, final boolean _blankFlg) {

        final int len = CM_A04_Const.LENGTH.MODEL_NAME_MAX_LENGTH * 2;

        FW01_03_CreateSingleSelectTagUtil fw0103Util = new FW01_03_CreateSingleSelectTagUtil(
                MaLineEntityNames.lnId().toString(),
                MaLineEntityNames.lnNm().toString(),
                _beanList, len);

        if (_blankFlg) {
            fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);
        }

        return fw0103Util.getItemList();
    }

    /**
     * ラインプルダウンリストデータ取得.
     * @param _plantCode 工場コード
     * @return ラインプルダウンリストデータ
     */
    public List<Map<String, String>> getLineGroupPld(final String _plantCode) {

        return this.getLineGroupPld(this.getMstLineGroupNameList(_plantCode));
    }

    /**
     * ラインプルダウンリストデータ取得.
     * @param _plantCode 工場コード
     * @param _blankFlg プルダウン先頭にブランクを入れるかどうか（trueならば先頭をブランクとする）
     * @return ラインプルダウンリストデータ
     */
    public List<Map<String, String>> getLineGroupPld(final String _plantCode, final boolean _blankFlg) {

        return this.getLineGroupPld(this.getMstLineGroupNameList(_plantCode), _blankFlg);
    }

    /**
     * ラインプルダウンリストデータ取得.
     * @param _plantCode 工場コード
     * @param _seizouLnId 製造ライン（グループ）
     * @param _blankFlg プルダウン先頭にブランクを入れるかどうか（trueならば先頭をブランクとする）
     * @return ラインプルダウンリストデータ
     */
    public List<Map<String, String>> getLinePld(final String _plantCode, final String _seizouLnId, final String _processId, final boolean _blankFlg) {

        return this.getLinePld(this.getMstLineNameList(_plantCode, _seizouLnId, _processId), _blankFlg);
    }

    /**
     * ラインリストデータ取得.
     * @param _plantCode 工場コード
     * @param _seizouLnId 製造ライン（グループ）
     * @param _processId 工程ID
     * @param _lnId ラインID
     * @return ラインプルダウンリストデータ
     */
    public List<BeanMap> getMstLineList(final String _plantCode, final String _seizouLnId, final String _processId, final String _lnId) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 製造ラインID
        Long seizouLnId = CM_CommonUtil.getLongVal(_seizouLnId);
        // 工程ID
        Long processId = CM_CommonUtil.getLongVal(_processId);
        // ラインID
        Long lnId = CM_CommonUtil.getLongVal(_lnId);

        return cmGetMstDataDao.getMstLineList(_plantCode, seizouLnId, processId, lnId);
    }

    /**
     * 設備プルダウンリストデータ取得.
     *<br>
     * @param _beanList 設備名称リスト
     * @param _blankFlg プルダウン先頭にブランクを入れるかどうか（trueならば先頭をブランクとする）
     * @return 設備プルダウンリストデータ
     */
    private List<Map<String, String>> getEquipmentPld(final List<BeanMap> _beanList, final boolean _blankFlg) {

        final int len = CM_A04_Const.LENGTH.MODEL_NAME_MAX_LENGTH * 2;

        FW01_03_CreateSingleSelectTagUtil fw0103Util = new FW01_03_CreateSingleSelectTagUtil(
                MaEquipEntityNames.mainResNo().toString(),
                MaEquipEntityNames.mainResNo().toString(),
                _beanList, len);

        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);

        return fw0103Util.getItemList();
    }

    /**
     * 設備プルダウンリストデータ取得.
     *<br>
     * @param _plantCode 工場コード
     * @param _condLnId ラインID
     * @param _blankFlg プルダウン先頭にブランクを入れるかどうか（trueならば先頭をブランクとする）
     * @return 設備プルダウンリストデータ
     */
    public List<Map<String, String>> getEquipmentPld(final String _plantCode, final String _condLnId, final boolean _blankFlg) {
        return this.getEquipmentPld(this.getMstEquipmentNameList(_plantCode, _condLnId), _blankFlg);
    }

    /**
     * 設備名称リスト取得.
     *<br>
     * @param _plantCode 工場コード
     * @param _condLnId ラインID
     * @return 設備名称リスト
     */
    public List<BeanMap> getMstEquipmentNameList(final String _plantCode, final String _condLnId) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 設備名称リスト抽出
        return cmGetMstDataDao.getMstEquipmentNameList(_plantCode, _condLnId);
    }

    /**
     * 機種群名プルダウンリストデータ取得.
     *<br>
     * @param _beanList 機種群名リスト
     * @param _blankFlg プルダウン先頭にブランクを入れるかどうか（trueならば先頭をブランクとする）
     * @return 機種群名プルダウンリストデータ
     */
    private List<Map<String, String>> getModelGroupNamePld(final List<BeanMap> _beanList, final boolean _blankFlg) {

        final int len = CM_A04_Const.LENGTH.MODEL_NAME_MAX_LENGTH * 2;

        FW01_03_CreateSingleSelectTagUtil fw0103Util = new FW01_03_CreateSingleSelectTagUtil(
//                MstModelGroupEntityNames.modelGroupName().toString(),
//                MstModelGroupEntityNames.modelGroupName().toString(),
                MaHinmokuEntityNames.vtextInfo1().toString(),
                MaHinmokuEntityNames.vtextInfo1().toString(),
                _beanList, len);

        if (_blankFlg) {
            fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);
        }

        return fw0103Util.getItemList();
    }

    /**
     * 機種群名プルダウンリストデータ取得.
     *<br>
     * @param _plantCode 工場コード
     * @param _blankFlg プルダウン先頭にブランクを入れるかどうか（trueならば先頭をブランクとする）
     * @return 機種群名プルダウンリストデータ
     */
    public List<Map<String, String>> getModelGroupNamePld(final String _plantCode, final boolean _blankFlg) {

        return this.getModelGroupNamePld(this.getMstModelGroupNameList(_plantCode), _blankFlg);
    }

    /**
     * 機種群名リスト取得.
     *<br>
     * @param _plantCode 工場コード
     * @return 機種群名リスト
     */
    public List<BeanMap> getMstModelGroupNameList(final String _plantCode) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 設備名称リスト抽出
        return cmGetMstDataDao.getMstModelGroupNameList(_plantCode);
    }

    /**
     *
     * 機器名称リスト（削除済機器含む）取得.<br>
     *<br>
     * 概要:<br>
     *   機器名称とSIDのリスト（削除済機器含む）を取得する
     *<br>
     * @return 機器名称リスト（削除済機器含む）
     */
    public List<BeanMap> getDeviceNameListIncludeDeleted() {

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 機器名称リスト抽出
        return cmGetMstDataDao.getDeviceNameListIncludeDeleted(this.sessionDto.ssn_UserSID);

    }

    /**
     *
     * TKNファイル名プルダウン一覧取得.<br>
     *<br>
     * 概要:<br>
     * TKNファイル名プルダウン一覧取得処理
     *<br>
     * @return TKNファイル名プルダウン一覧
     */
    public List<Map<String, String>> getPldTknFileName() {
        List<BeanMap> itemList = this.getMstWorkStepTknFileName();
        return this.getPldTknFileName(itemList, false);
    }

    /**
     *
     * TKNファイル名一覧取得..<br>
     *<br>
     * 概要:<br>
     * TKNファイル名一覧取得処理
     *<br>
     * @return TKNファイル名一覧
     */
    public List<BeanMap> getMstWorkStepTknFileName() {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // TKNファイル名一覧抽出
        return cmGetMstDataDao.getMstWorkStepTknFileNameList();
    }

    /**
     *
     * TKNファイル名プルダウン一覧取得.<br>
     *<br>
     * 概要:<br>
     *  TKNファイル名プルダウン一覧取得処理
     *<br>
     * @param _itemList TKNファイル名一覧
     * @param _blankFlg 空白フラグ
     * @return TKNファイル名プルダウン一覧
     */
    public List<Map<String, String>> getPldTknFileName(final List<BeanMap> _itemList, final boolean _blankFlg) {
        final int len = CM_A04_Const.LENGTH.MODEL_NAME_MAX_LENGTH * 2;

        FW01_03_CreateSingleSelectTagUtil fw0103Util = new FW01_03_CreateSingleSelectTagUtil(
                MaMesWorkStepEntityNames.jobPtnName().toString(),
                MaMesWorkStepEntityNames.jobPtnName().toString(),
                _itemList, len);

        if (_blankFlg) {
            fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);
        }

        return fw0103Util.getItemList();
    }

    /**
     * CSVデータ取得.<br>
     *<br>
     * 概要:<br>
     *  CSV出力用のデータを取得する
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 詳細検索条件情報
     * @return pointData CSVデータ
     */
    public List<Map<String, String>> getMainteStatusCsvData(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo) {

        // 一覧情報取得を行う
        List<BeanMap> getData = this.getMainteStatusDataCSVList(_formInfo, _mapSearchCondInfo);

        List<Map<String, String>> csvDataList = new ArrayList<Map<String, String>>();

        if (getData == null || getData.size() == 0) {
            //取得したデータが0件の場合は処理修了
            return csvDataList;
        }

        int csvOutCount = 0;

        //抽出したデータを画面表示用に生成する
        for (int i = 0; i < getData.size(); i++) {
            if (csvOutCount >= CM_A02_ListAction.CSV_DATA_MAX) {
                break;
            }
            BeanMap map = getData.get(i);

            Map<String, String> csvDataMap = new HashMap<String, String>();

            String deletedMsg = CM_DisplayCharResourceUtil.getDisplayCharValue(
                    this.sessionDto.ssn_CustomerCD, this.sessionDto.ssn_UserLangCD, "MMCDCA000080_006");

            // データを入れていく
            // 所属グループ
            String treePathName = FW00_19_Const.EMPTY_STR;
            if (!CM_CommonUtil.isNullOrBlank(map.get("treePathName"))) {
                treePathName = String.valueOf(map.get("treePathName"));
            }
            csvDataMap.put("treePathName", treePathName);
            // 型番名称
            String modelName = FW00_19_Const.EMPTY_STR;
            if (!CM_CommonUtil.isNullOrBlank(map.get("modelName"))) {
                modelName = String.valueOf(map.get("modelName"));
            }
            csvDataMap.put("modelName", modelName);
            // 機器ID
            String deviceId = FW00_19_Const.EMPTY_STR;
            if (!CM_CommonUtil.isNullOrBlank(map.get("deviceId"))) {
                deviceId = String.valueOf(map.get("deviceId"));
            }
            csvDataMap.put("deviceId", deviceId);
            // 機器名称
            String deviceName = FW00_19_Const.EMPTY_STR;
            if (CM_CommonUtil.isNullOrBlank(map.get("deviceName"))) {
                Integer deviceSid = (Integer) map.get(MstMainteStatusEntityNames.deviceSid().toString());
                if (CM_CommonUtil.isNotNullOrBlank(deviceSid)) {
                    // 削除済
                    deviceName = deletedMsg + FW00_19_Const.PARENTHESIS_START_STR + String.valueOf(deviceSid) + FW00_19_Const.PARENTHESIS_END_STR;
                }
            } else {
                deviceName = String.valueOf(map.get("deviceName"));
            }
            csvDataMap.put("deviceName", deviceName);
            // 機器SID
            String deviceSid = FW00_19_Const.EMPTY_STR;
            if (!CM_CommonUtil.isNullOrBlank(map.get(MstMainteStatusEntityNames.deviceSid().toString()))) {
                deviceSid = String.valueOf(map.get(MstMainteStatusEntityNames.deviceSid().toString()));
            }
            csvDataMap.put(MstMainteStatusEntityNames.deviceSid().toString(), deviceSid);
            // 種別
            csvDataMap.put(MstMainteStatusEntityNames.type().toString(),
                    map.get(MstMainteStatusEntityNames.type().toString()).toString());
            // ステータス
            csvDataMap.put(MstMainteStatusEntityNames.status().toString(),
                    map.get(MstMainteStatusEntityNames.status().toString()).toString());
            // アラーム名称
            String alarmName = FW00_19_Const.EMPTY_STR;
            if (CM_CommonUtil.isNullOrBlank(map.get(MstAlarmEntityNames.alarmName().toString()))) {
                Integer alarmSid = (Integer) map.get(TblAlarmStateDataEntityNames.alarmSid().toString());
                if (CM_CommonUtil.isNotNullOrBlank(alarmSid)) {
                    // 削除済
                    alarmName = deletedMsg + FW00_19_Const.PARENTHESIS_START_STR + String.valueOf(alarmSid) + FW00_19_Const.PARENTHESIS_END_STR;
                }
            } else {
                alarmName = String.valueOf(map.get(MstAlarmEntityNames.alarmName().toString()));
            }
            csvDataMap.put(MstAlarmEntityNames.alarmName().toString(), alarmName);
            // 報告書名称
            csvDataMap.put(MstMainteStatusEntityNames.name().toString(),
                    map.get(MstMainteStatusEntityNames.name().toString()).toString());
            // 報告書No
            csvDataMap.put(MstMainteStatusEntityNames.mainteNo().toString(),
                    map.get(MstMainteStatusEntityNames.mainteNo().toString()).toString());
            // 実施日時
            csvDataMap.put(MstMainteStatusEntityNames.mainteDatetime().toString(),
                    map.get(MstMainteStatusEntityNames.mainteDatetime().toString()).toString());
            // 実施日時タイムゾーン
            csvDataMap.put(MstMainteStatusEntityNames.mainteTimezoneCd().toString(),
                    map.get(MstMainteStatusEntityNames.mainteTimezoneCd().toString()).toString());

            // 実施担当者
            csvDataMap.put(MstMainteStatusEntityNames.mainteUser().toString(),
                    map.get(MstMainteStatusEntityNames.mainteUser().toString()).toString());
            // 点検項目
            csvDataMap.put(MstMainteStatusEntityNames.mainteOutline().toString(),
                    map.get(MstMainteStatusEntityNames.mainteOutline().toString()).toString());
            // 点検結果
            csvDataMap.put(MstMainteStatusEntityNames.mainteResult().toString(),
                    map.get(MstMainteStatusEntityNames.mainteResult().toString()).toString());
            // 故障状況
            csvDataMap.put(MstMainteStatusEntityNames.failureOutline().toString(),
                    map.get(MstMainteStatusEntityNames.failureOutline().toString()).toString());
            // 処置・確認方法
            csvDataMap.put(MstMainteStatusEntityNames.actionOutline().toString(),
                    map.get(MstMainteStatusEntityNames.actionOutline().toString()).toString());
            // 原因・対策
            csvDataMap.put(MstMainteStatusEntityNames.couseOutline().toString(),
                    map.get(MstMainteStatusEntityNames.couseOutline().toString()).toString());
            // 備考
            csvDataMap.put(MstMainteStatusEntityNames.appendix().toString(),
                    map.get(MstMainteStatusEntityNames.appendix().toString()).toString());


            Integer mainteStatusSid = (Integer) map.get(MstMainteStatusEntityNames.sid());
            List<BeanMap> commentList = this.getMainteStatusCommentDataCSVList(mainteStatusSid);

            if (!commentList.isEmpty()) {

                // 先にCSV出力行数を計算し、CSV_DATA_MAXを超えるなら出力しない。
                csvOutCount += commentList.size();
                if (csvOutCount > CM_A02_ListAction.CSV_DATA_MAX) {
                    break;
                }

                for (BeanMap commentData : commentList) {

                    // コメント種別
                    csvDataMap.put(TblCommentEntityNames.commentType().toString(),
                            commentData.get(TblCommentEntityNames.commentType().toString()).toString());

                    // コメントユーザID
                    csvDataMap.put(MAPKEY_USER_ID, commentData.get(MAPKEY_USER_ID).toString());

                    // コメントユーザ名
                    csvDataMap.put(MAPKEY_USER_NAME, commentData.get(MAPKEY_USER_NAME).toString());

                    // コメント日時
                    csvDataMap.put(TblCommentEntityNames.commentDatetime().toString(),
                            commentData.get(TblCommentEntityNames.commentDatetime()).toString());

                    // タイムゾーン
                    csvDataMap.put(MstUserEntityNames.timezoneCd().toString(),
                            commentData.get(MstUserEntityNames.timezoneCd()).toString());

                    // コメント内容
                    csvDataMap.put(TblCommentEntityNames.commentData().toString(),
                            commentData.get(TblCommentEntityNames.commentData()).toString());

                    // リストにデータ追加
                    csvDataList.add(csvDataMap);

                    // 次のコメント行のために、データを空文字で上書き
                    csvDataMap = new HashMap<String, String>();

                    // 所属グループ
                    csvDataMap.put("treePathName", FW00_19_Const.EMPTY_STR);
                    // 型番名称
                    csvDataMap.put("modelName", FW00_19_Const.EMPTY_STR);
                    // 機器ID
                    csvDataMap.put("deviceId", FW00_19_Const.EMPTY_STR);
                    // 機器名称
                    csvDataMap.put("deviceName", FW00_19_Const.EMPTY_STR);
                    // 種別
                    csvDataMap.put(MstMainteStatusEntityNames.type().toString(), FW00_19_Const.EMPTY_STR);
                    // ステータス
                    csvDataMap.put(MstMainteStatusEntityNames.status().toString(), FW00_19_Const.EMPTY_STR);
                    // 報告書名称
                    csvDataMap.put(MstMainteStatusEntityNames.name().toString(), FW00_19_Const.EMPTY_STR);
                    // 報告書No
                    csvDataMap.put(MstMainteStatusEntityNames.mainteNo().toString(), FW00_19_Const.EMPTY_STR);
                    // 実施日時
                    csvDataMap.put(MstMainteStatusEntityNames.mainteDatetime().toString(), FW00_19_Const.EMPTY_STR);
                    // 実施日時タイムゾーン
                    csvDataMap.put(MstMainteStatusEntityNames.mainteTimezoneCd().toString(), FW00_19_Const.EMPTY_STR);
                    // 実施担当者
                    csvDataMap.put(MstMainteStatusEntityNames.mainteUser().toString(), FW00_19_Const.EMPTY_STR);
                    // 点検項目
                    csvDataMap.put(MstMainteStatusEntityNames.mainteOutline().toString(), FW00_19_Const.EMPTY_STR);
                    // 点検結果
                    csvDataMap.put(MstMainteStatusEntityNames.mainteResult().toString(), FW00_19_Const.EMPTY_STR);
                    // 故障状況
                    csvDataMap.put(MstMainteStatusEntityNames.failureOutline().toString(), FW00_19_Const.EMPTY_STR);
                    // 処置・確認方法
                    csvDataMap.put(MstMainteStatusEntityNames.actionOutline().toString(), FW00_19_Const.EMPTY_STR);
                    // 原因・対策
                    csvDataMap.put(MstMainteStatusEntityNames.couseOutline().toString(), FW00_19_Const.EMPTY_STR);
                    // 備考
                    csvDataMap.put(MstMainteStatusEntityNames.appendix().toString(), FW00_19_Const.EMPTY_STR);
                }
            } else {
                // コメント種別
                csvDataMap.put(TblCommentEntityNames.commentType().toString(), FW00_19_Const.EMPTY_STR);

                // コメントユーザID
                csvDataMap.put(MAPKEY_USER_ID, FW00_19_Const.EMPTY_STR);

                // コメントユーザ名
                csvDataMap.put(MAPKEY_USER_NAME, FW00_19_Const.EMPTY_STR);

                // コメント日時
                csvDataMap.put(TblCommentEntityNames.commentDatetime().toString(), FW00_19_Const.EMPTY_STR);

                // タイムゾーン
                csvDataMap.put(MstUserEntityNames.timezoneCd().toString(), FW00_19_Const.EMPTY_STR);

                // コメント内容
                csvDataMap.put(TblCommentEntityNames.commentData().toString(), FW00_19_Const.EMPTY_STR);

                csvDataList.add(csvDataMap);

                // 出力件数インクリメント
                csvOutCount++;
            }
        }

        return csvDataList;
    }


    /**
     *
     * 機器画像リスト取得.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _deviceId 機器ID
     * @return 機器画像リスト
     */
    public List<MstDocumentEntity> getDevicePicList(final String _deviceId) {
        CM_MstDocumentDao cmMstDocumentDao = new CM_MstDocumentDao();
        initCustomerDbDao(cmMstDocumentDao);

        String type = CM_A04_Const.DOCTYPE.DEVICE;

        // 機器画像リスト抽出
        return cmMstDocumentDao.getPicList(type, _deviceId);
    }

    /**
     *
     * 型番画像リスト取得.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _modelId 型番ID
     * @return 型番画像リスト
     */
    public List<MstDocumentEntity> getModelPicList(final String _modelId) {
        CM_MstDocumentDao cmMstDocumentDao = new CM_MstDocumentDao();
        initCustomerDbDao(cmMstDocumentDao);

        String type = CM_A04_Const.DOCTYPE.MODEL;

        // 機器画像リスト抽出
        return cmMstDocumentDao.getPicList(type, _modelId);
    }

    /**
     *
     * 資料情報取得.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _sid 資料SID
     * @return 資料情報
     */
    public MstDocumentEntity getDocInfo(final int _sid) {
        CM_MstDocumentDao cmMstDocumentDao = new CM_MstDocumentDao();
        initCustomerDbDao(cmMstDocumentDao);

        // 機器画像リスト抽出
        return cmMstDocumentDao.getDocInfo(_sid);
    }


    /**
     *
     * 機器名称-SIDプルダウン取得.<br>
     *<br>
     * 概要:<br>
     *   機器名称（ValueはSID）のプルダウンを取得する
     *
     * @return 機器名称プルダウン
     */
    public List<Map<String, String>> getDeviceNamePld() {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> deviceNameList =  cmGetMstDataDao.selectDeviceNameList(this.sessionDto.ssn_UserSID, false, null);

        final int len = CM_A04_Const.LENGTH.DEVICE_NAME_MAX_LENGTH * 2;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(MstDeviceEntityNames.sid().toString(), MstDeviceEntityNames.name().toString(), deviceNameList, len);

        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 機器名称-SIDプルダウン取得（削除済の機器も含む）.<br>
     *<br>
     * 概要:<br>
     *   機器名称（ValueはSID）のプルダウンを取得する（削除済の機器も含む）
     *
     * @return 機器名称プルダウン
     */
    public List<Map<String, String>> getDeviceNamePldIncludeDeleted() {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> deviceNameList =  cmGetMstDataDao.selectDeviceNameList(this.sessionDto.ssn_UserSID, true, null);

        final int len = CM_A04_Const.LENGTH.DEVICE_NAME_MAX_LENGTH * 2;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(MstDeviceEntityNames.sid().toString(), MstDeviceEntityNames.name().toString(), deviceNameList, len);

        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 機器名称-SIDプルダウン取得（削除済の機器も含む）.<br>
     *<br>
     * 概要:<br>
     *   引数指定の型番に紐づく機器名称（ValueはSID）のプルダウンを取得する（削除済の機器も含む）
     *
     * @param _modelSid 型番SID
     * @return 機器名称プルダウン
     */
    public List<Map<String, String>> getDeviceNamePldIncludeDeleted(final Integer _modelSid) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> deviceNameList =  cmGetMstDataDao.selectDeviceNameList(this.sessionDto.ssn_UserSID, true, _modelSid);

        final int len = CM_A04_Const.LENGTH.DEVICE_NAME_MAX_LENGTH * 2;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(MstDeviceEntityNames.sid().toString(), MstDeviceEntityNames.name().toString(), deviceNameList, len);

        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 機器名称-SIDプルダウン取得.<br>
     *<br>
     * 概要:<br>
     *   機器名称（ValueはSID）のプルダウンを取得する
     *
     * @param _modelSid 型番SID
     *
     * @return 機器名称プルダウン
     */
    public List<Map<String, String>> getDeviceNamePldByModelSid(final Integer _modelSid) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> deviceNameList =  cmGetMstDataDao.selectDeviceNameList(this.sessionDto.ssn_UserSID, false, _modelSid);

        final int len = CM_A04_Const.LENGTH.DEVICE_NAME_MAX_LENGTH * 2;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(MstDeviceEntityNames.sid().toString(), MstDeviceEntityNames.name().toString(), deviceNameList, len);

        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 機器名称-IDプルダウン取得（型番SID、グループIDでの絞込みあり）.<br>
     *<br>
     * 概要:<br>
     *   機器名称（ValueはID）のプルダウンを取得する
     *
     * @param _modelSid 型番SID
     * @param _groupId グループID
     *
     * @return 機器名称プルダウン
     */
    public List<Map<String, String>> getDeviceNamePldByModelSidGroupId(final Integer _modelSid, final String _groupId) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> deviceNameList =  cmGetMstDataDao.selectDeviceNameListByModelSidGroupId(_modelSid, _groupId, this.sessionDto.ssn_UserSID);

        final int len = CM_A04_Const.LENGTH.DEVICE_NAME_MAX_LENGTH * 2;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(MstDeviceEntityNames.sid().toString(), MstDeviceEntityNames.name().toString(), deviceNameList, len);

        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 機器名称-IDプルダウン取得（型番SID、グループパス配下での絞込みあり）.<br>
     *<br>
     * 概要:<br>
     *   機器名称（Valueはsid）のプルダウンを取得する
     *
     * @param _modelSid 型番SID
     * @param _groupPath グループパス
     *
     * @return 機器名称プルダウン
     */
    public List<Map<String, String>> getDeviceNamePldByModelSidGroupPath(final Integer _modelSid, final String _groupPath) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> deviceNameList =  cmGetMstDataDao.selectDeviceNameListByModelSidGroupPath(_modelSid, _groupPath, this.sessionDto.ssn_UserSID);

        final int len = CM_A04_Const.LENGTH.DEVICE_NAME_MAX_LENGTH * 2;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(MstDeviceEntityNames.sid().toString(), MstDeviceEntityNames.name().toString(), deviceNameList, len);

        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 機器名称-SIDプルダウン取得.<br>
     *<br>
     * 概要:<br>
     *   機器名称（ValueはSID）のプルダウンを取得する（プルダウン先頭に空データ無し）。
     *
     * @return 機器名称プルダウン
     */
    public List<Map<String, String>> getDeviceNameNotEmptyPld() {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> deviceNameList =  cmGetMstDataDao.selectDeviceNameList(this.sessionDto.ssn_UserSID, false, null);

        final int len = CM_A04_Const.LENGTH.DEVICE_NAME_MAX_LENGTH * 2;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(MstDeviceEntityNames.sid().toString(), MstDeviceEntityNames.name().toString(), deviceNameList, len);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 種別プルダウン取得.<br>
     *<br>
     * 概要:<br>
     *   種別のプルダウンを取得する
     *<br>
     * @return 種別プルダウン
     */
    public List<Map<String, String>> getFileKindPld() {

        List<BeanMap> fileKindList =
                CM_SysNameDataUtil.getNameList(this.sessionDto, CM_A04_Const.SYS_NAME_MST_NAME_TYPE.FILE_KIND, this.sessionDto.ssn_UserLangCD);

        final int len = CM_A04_Const.LENGTH.DOCMENT_FILEKIND_STRING_MAX_LENGTH;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(SysNameEntityNames.itemCd().toString(), SysNameEntityNames.name1().toString(), fileKindList, len);

        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 型番名称-SIDプルダウン取得.<br>
     *<br>
     * 概要:<br>
     *   型番名称（ValueはSID）のプルダウンを取得する
     *<br>
     * @return 型番名称プルダウン
     */
    public List<Map<String, String>> getModelNamePld() {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> modelNameList = cmGetMstDataDao.selectModelNameList(false, this.sessionDto.ssn_UserSID, false, false);

        return makeModelNameSidPld(modelNameList);
    }

    /**
     *
     * 型番名称-SIDプルダウン取得（削除データ、機器に紐づくグループ外型番含む）.<br>
     *<br>
     * 概要:<br>
     *   型番名称（ValueはSID）のプルダウンを取得する。<br>
     *   削除フラグがセットされたデータも含む。<br>
     *   また、ログインユーザの所属グループ内の機器に紐づくログインユーザの所属グループ外の型番も含む
     *<br>
     * @return 型番名称プルダウン
     */
    public List<Map<String, String>> getModelNamePldIncludeDeletedAndDevRelated() {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> modelNameList = cmGetMstDataDao.selectModelNameList(false, this.sessionDto.ssn_UserSID, true, true);

        return makeModelNameSidPld(modelNameList);
    }

    /**
     *
     * 型番名称-SIDプルダウン取得（通信プロファイル連結済み型番のみ）.<br>
     *<br>
     * 概要:<br>
     *   型番名称（ValueはSID）のプルダウンを取得する。<br>
     *   通信プロファイル連結済み型番のみを取得する。<br>
     *<br>
     * @return 型番名称プルダウン
     */
    public List<Map<String, String>> getModelNamePldProfileRelated() {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> modelNameList = cmGetMstDataDao.selectModelNameList(true, this.sessionDto.ssn_UserSID, false, false);

        return makeModelNameSidPld(modelNameList);
    }

    /**
     *
     * 型番名称-SIDプルダウン取得.<br>
     *<br>
     * 概要:<br>
     *   型番名称（ValueはSID）のプルダウンを取得する
     *<br>
     * @return 型番名称プルダウン
     */
    public List<Map<String, String>> getModelNamePldIncludeDeleted() {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> modelNameList = cmGetMstDataDao.selectModelNameList(false, this.sessionDto.ssn_UserSID, true, false);

        return makeModelNameSidPld(modelNameList);
    }

    /**
     *
     * 型番名称-SIDプルダウン取得.<br>
     *<br>
     * 概要:<br>
     *   型番名称（ValueはSID）のプルダウンを取得する
     *<br>
     * @param _profileRelated プロファイル連結済みデータ限定フラグ（true:限定する、false:全て）
     * @return 型番名称プルダウン
     */
    public List<Map<String, String>> getModelNamePldDeviceGroup(final boolean _profileRelated) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> modelNameList = cmGetMstDataDao.selectModelNameList(_profileRelated, this.sessionDto.ssn_UserSID, false, true);

        return makeModelNameSidPld(modelNameList);
    }

    /**
     *
     * 型番名称-SIDプルダウン生成処理.<br>
     *<br>
     * 概要:<br>
     *   型番名称（ValueはSID）のプルダウンを生成する
     *<br>
     * @param _modelNameList 型番情報リスト
     * @return 型番名称プルダウン
     */
    private List<Map<String, String>> makeModelNameSidPld(final List<BeanMap> _modelNameList) {
        final int len = CM_A04_Const.LENGTH.MODEL_NAME_MAX_LENGTH * 2;

        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(MstModelEntityNames.sid().toString(), MstModelEntityNames.name().toString(), _modelNameList, len);

        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 型番SID取得.<br>
     *<br>
     * 概要:<br>
     *   型番SIDを取得する
     *<br>
     * @param _deviceSid 機器SID
     * @return 型番ID
     */
    public String getModelSid(final String _deviceSid) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        return cmGetMstDataDao.getModelSid(_deviceSid);
    }

    /**
     *
     * 資料一覧データ数取得.<br>
     *<br>
     * 概要:<br>
     *   一覧のデータ数を取得する
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 検索条件情報Map
     * @param _txtDocType 種別
     * @return データ数
     */
    public long getDocumentDataListCount(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo, final String _txtDocType) {
        // データ数取得
        return this.getDocumentDataListCount(_formInfo, _mapSearchCondInfo, _txtDocType, null);
    }

    /**
     *
     * 資料一覧データ数取得.<br>
     *<br>
     * 概要:<br>
     *   一覧のデータ数を取得する
     *<br>
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 検索条件情報Map
     * @param _txtDocType 種別
     * @param _deleteFlg 削除フラグ (nullの場合指定なし)
     * @return データ数
     */
    public long getDocumentDataListCount(final BeanMap _formInfo, final Map<String, Object> _mapSearchCondInfo, final String _txtDocType,
            final Boolean _deleteFlg) {

        CM_MstDocumentDao cmMstDocumentDao = new CM_MstDocumentDao();
        cmMstDocumentDao.setCustomerDbInfo(this.sessionDto.ssn_ConnectString,
                this.sessionDto.ssn_ConnectUserID, this.sessionDto.ssn_ConnectPassword);

        long ret = 0;

        // ログインユーザーが管理者かどうかをチェック
        boolean isAdmin = CM_CommonUtil.checkSystemGroup(this.sessionDto);

        // データ数取得
        ret = cmMstDocumentDao.selectDocumentListCount(_formInfo, _mapSearchCondInfo,
                this.sessionDto.ssn_UserSID, _txtDocType, _deleteFlg, isAdmin);

        return ret;
    }


    /**
     *
     * 資料一覧データ取得.<br>
     *<br>
     * 概要:<br>
     *   一覧のデータを取得する
     *<br>
     * @param _sessionDto セッション情報
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 検索条件情報Map
     * @param _offsetInfo オフセット情報
     * @param _txtDocType 種別
     * @return 一覧データリスト
     */
    public List<BeanMap> getDocumentDataList(final CM_A03_SessionDto _sessionDto, final BeanMap _formInfo,
            final Map<String, Object> _mapSearchCondInfo, final Map<String, Integer> _offsetInfo, final String _txtDocType) {

        CM_MstDocumentDao cmMstDocumentDao = new CM_MstDocumentDao();
        cmMstDocumentDao.setCustomerDbInfo(this.sessionDto.ssn_ConnectString,
                this.sessionDto.ssn_ConnectUserID, this.sessionDto.ssn_ConnectPassword);

        List<BeanMap> ret = null;

        // ログインユーザーが管理者かどうかをチェック
        boolean isAdmin = CM_CommonUtil.checkSystemGroup(this.sessionDto);

        // データ取得
        List<BeanMap> documentList = cmMstDocumentDao.selectDocumentList(_formInfo, _mapSearchCondInfo, _offsetInfo,
                this.sessionDto.ssn_UserSID, _txtDocType, isAdmin);

        ret = new ArrayList<BeanMap>();

        for (BeanMap documentMap : documentList) {
            BeanMap tmpMap = new BeanMap();
            // 機器フラグ
            boolean isDevice = false;
            if (CM_A04_Const.DOCTYPE.DEVICE.equals(documentMap.get(MstDocumentEntityNames.docType()))) {
                isDevice = true;
            }

            // 削除フラグ
            tmpMap.put(MstDocumentEntityNames.deleteFlag().toString(), documentMap.get(MstDocumentEntityNames.deleteFlag()));

            // SID(ドキュメントマスタ）
            tmpMap.put(MstDocumentEntityNames.sid().toString(), documentMap.get(MstDocumentEntityNames.sid()));

            // キーコード
            tmpMap.put(MstDocumentEntityNames.keyCd().toString(), documentMap.get(MstDocumentEntityNames.keyCd()));

            // 文書区分
            tmpMap.put(MstDocumentEntityNames.docType().toString(), documentMap.get(MstDocumentEntityNames.docType()));

            // 機器名称
            Object deviceName = documentMap.get(CM_MstDocumentDao.DEVICENAME);
            if (isDevice && CM_CommonUtil.isNullOrBlank(deviceName)) {
                // 削除済みの場合
                if (CM_CommonUtil.isNotNullOrBlank(documentMap.get(MstDocumentEntityNames.keyCd()))) {
                    deviceName = CM_DisplayCharResourceUtil.getDisplayCharValue(this.sessionDto.ssn_CustomerCD,
                            this.sessionDto.ssn_UserLangCD, "MMCDCA000080_006");
                    deviceName += FW00_19_Const.PARENTHESIS_START_STR
                            + documentMap.get(MstDocumentEntityNames.keyCd()) + FW00_19_Const.PARENTHESIS_END_STR;
                }
            }
            tmpMap.put(CM_MstDocumentDao.DEVICENAME, deviceName);

            // 型番名称
            Object modelName = documentMap.get(CM_MstDocumentDao.MODELNAME);
            if (!isDevice && CM_CommonUtil.isNullOrBlank(modelName)) {
                // 削除済みの場合
                if (CM_CommonUtil.isNotNullOrBlank(documentMap.get(MstDocumentEntityNames.keyCd()))) {
                    modelName = CM_DisplayCharResourceUtil.getDisplayCharValue(this.sessionDto.ssn_CustomerCD,
                            this.sessionDto.ssn_UserLangCD, "MMCDCA000080_006");
                    modelName += FW00_19_Const.PARENTHESIS_START_STR
                            + documentMap.get(MstDocumentEntityNames.keyCd()) + FW00_19_Const.PARENTHESIS_END_STR;
                }
            }
            tmpMap.put(CM_MstDocumentDao.MODELNAME, modelName);

            // 種別
            String fileKind = documentMap.get(MstDocumentEntityNames.fileKind().toString()).toString();
            BeanMap fileKindMap = CM_SysNameDataUtil.getName(this.sessionDto,
                    CM_A04_Const.SYS_NAME_MST_NAME_TYPE.FILE_KIND, fileKind, this.sessionDto.ssn_UserLangCD);
            if (fileKindMap != null) {
                tmpMap.put(CM_MstDocumentDao.FILEKINDNAME, fileKindMap.get(SysNameEntityNames.name1()).toString());
            } else {
                tmpMap.put(CM_MstDocumentDao.FILEKINDNAME, FW00_19_Const.EMPTY_STR);
            }

            // 資料名
            tmpMap.put(MstDocumentEntityNames.docName().toString(), documentMap.get(MstDocumentEntityNames.docName()));

            // 資料No
            tmpMap.put(MstDocumentEntityNames.docNo().toString(), documentMap.get(MstDocumentEntityNames.docNo()));

            // アップロード日時
            Timestamp lastUpdTim = (Timestamp) documentMap.get(MstDocumentEntityNames.lastUpdTim());
            tmpMap.put(MstDocumentEntityNames.lastUpdTim().toString(),
                    CM_CommonUtil.getTimeGmtToTimezone(lastUpdTim, _sessionDto.ssn_UserTimezoneCD, CM_A04_Const.DATE_FORMAT));

            // メモ
            tmpMap.put(MstDocumentEntityNames.memo().toString(), documentMap.get(MstDocumentEntityNames.memo()));

            // アップロード先ファイルパスを取得する。
            String filePath = CM_CommonUtil.makeDocSaveFilePath(this.sessionDto,
                String.valueOf(documentMap.get(MstDocumentEntityNames.docType())), String.valueOf(documentMap.get(MstDocumentEntityNames.keyCd())));

            // ファイル名
            tmpMap.put(MstDocumentEntityNames.fileName().toString(), documentMap.get(MstDocumentEntityNames.fileName()));

            ret.add(tmpMap);
        }

        return ret;
    }

    /**
     *
     * CSV用資料一覧データ取得.<br>
     *<br>
     * 概要:<br>
     *   資料一覧のCSV用データを取得する
     *<br>
     * @param _sessionDto セッション情報
     * @param _formInfo フォーム情報
     * @param _mapSearchCondInfo 検索条件情報Map
     * @param _txtDocType 種別
     * @return 資料一覧CSV用データリスト
     */
    public List<BeanMap> getDocumentListCSV(final CM_A03_SessionDto _sessionDto, final BeanMap _formInfo,
            final Map<String, Object> _mapSearchCondInfo, final String _txtDocType) {

        CM_MstDocumentDao cmMstDocumentDao = new CM_MstDocumentDao();
        cmMstDocumentDao.setCustomerDbInfo(this.sessionDto.ssn_ConnectString,
                this.sessionDto.ssn_ConnectUserID, this.sessionDto.ssn_ConnectPassword);

        List<BeanMap> ret = new ArrayList<BeanMap>();

        // ログインユーザーが管理者かどうかをチェック
        boolean isAdmin = CM_CommonUtil.checkSystemGroup(this.sessionDto);

        // データ取得
        List<BeanMap> documentList = cmMstDocumentDao.selectDocumentListCSV(_formInfo, _mapSearchCondInfo,
                this.sessionDto.ssn_UserSID, _txtDocType, isAdmin);

        if (documentList == null || documentList.size() == 0) {
            // 取得したデータが0件の場合は処理修了
            return ret;
        }

        // システムの改行文字コードを取得
        String returnCode = System.getProperty("line.separator");

        //抽出したデータをCSV用に生成する
        for (BeanMap documentMap : documentList) {
            BeanMap tmpMap = new BeanMap();
            // 機器フラグ
            boolean isDevice = false;
            if (CM_A04_Const.DOCTYPE.DEVICE.equals(documentMap.get(MstDocumentEntityNames.docType()))) {
                isDevice = true;
            }

            // 削除フラグ
            tmpMap.put(MstDocumentEntityNames.deleteFlag().toString(), documentMap.get(MstDocumentEntityNames.deleteFlag()));

            // 機器名称
            Object deviceName = documentMap.get(CM_MstDocumentDao.DEVICENAME);
            if (isDevice && CM_CommonUtil.isNullOrBlank(deviceName)) {
                // 削除済みの場合
                if (CM_CommonUtil.isNotNullOrBlank(documentMap.get(MstDocumentEntityNames.keyCd()))) {
                    deviceName = CM_DisplayCharResourceUtil.getDisplayCharValue(this.sessionDto.ssn_CustomerCD,
                            this.sessionDto.ssn_UserLangCD, "MMCDCA000080_006");
                    deviceName += FW00_19_Const.PARENTHESIS_START_STR
                            + documentMap.get(MstDocumentEntityNames.keyCd()) + FW00_19_Const.PARENTHESIS_END_STR;
                }
            }
            tmpMap.put(CM_MstDocumentDao.DEVICENAME, deviceName);

            // 型番名称
            Object modelName = documentMap.get(CM_MstDocumentDao.MODELNAME);
            if (!isDevice && CM_CommonUtil.isNullOrBlank(modelName)) {
                // 削除済みの場合
                if (CM_CommonUtil.isNotNullOrBlank(documentMap.get(MstDocumentEntityNames.keyCd()))) {
                    modelName = CM_DisplayCharResourceUtil.getDisplayCharValue(this.sessionDto.ssn_CustomerCD,
                            this.sessionDto.ssn_UserLangCD, "MMCDCA000080_006");
                    modelName += FW00_19_Const.PARENTHESIS_START_STR
                            + documentMap.get(MstDocumentEntityNames.keyCd()) + FW00_19_Const.PARENTHESIS_END_STR;
                }
            }
            tmpMap.put(CM_MstDocumentDao.MODELNAME, modelName);

            // 種別
            String fileKind = documentMap.get(MstDocumentEntityNames.fileKind().toString()).toString();
            BeanMap fileKindMap = CM_SysNameDataUtil.getName(this.sessionDto,
                    CM_A04_Const.SYS_NAME_MST_NAME_TYPE.FILE_KIND, fileKind, this.sessionDto.ssn_UserLangCD);
            if (fileKindMap != null) {
                tmpMap.put(CM_MstDocumentDao.FILEKINDNAME, fileKindMap.get(SysNameEntityNames.name1()).toString());
            } else {
                tmpMap.put(CM_MstDocumentDao.FILEKINDNAME, FW00_19_Const.EMPTY_STR);
            }

            // 資料No
            tmpMap.put(MstDocumentEntityNames.docNo().toString(), documentMap.get(MstDocumentEntityNames.docNo()));

            // 資料名
            tmpMap.put(MstDocumentEntityNames.docName().toString(), documentMap.get(MstDocumentEntityNames.docName()));

            // アップロード日時
            Timestamp lastUpdTim = (Timestamp) documentMap.get(MstDocumentEntityNames.lastUpdTim());
            tmpMap.put(MstDocumentEntityNames.lastUpdTim().toString(),
                    CM_CommonUtil.getTimeGmtToTimezone(lastUpdTim, _sessionDto.ssn_UserTimezoneCD, CM_A04_Const.DATE_FORMAT));

            // メモ
            if (documentMap.get(MstDocumentEntityNames.memo()) != null) {
                String memo = documentMap.get(MstDocumentEntityNames.memo()).toString();
                memo = memo.replaceAll(returnCode, FW00_19_Const.SPACE);
                tmpMap.put(MstDocumentEntityNames.memo().toString(), memo);
            } else {
                tmpMap.put(MstDocumentEntityNames.memo().toString(), FW00_19_Const.EMPTY_STR);
            }

            ret.add(tmpMap);
        }

        return ret;
    }

    /**
     *
     * 種別（配信データ）プルダウン取得.<br>
     *<br>
     * 概要:<br>
     *   種別（配信データ）のプルダウンを取得する
     *<br>
     * @return 種別（配信データ）プルダウン
     */
    public List<Map<String, String>> getDistributionDataTypePld() {

        List<BeanMap> fileTypeList =
                CM_SysNameDataUtil.getNameList(this.sessionDto, CM_A04_Const.SYS_NAME_MST_NAME_TYPE.FILE_TYPE, this.sessionDto.ssn_UserLangCD);

        final int len = CM_A04_Const.LENGTH.DISTRIBUTION_DATA_FILETYPE_STRING_MAX_LENGTH;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(SysNameEntityNames.itemCd().toString(), SysNameEntityNames.name1().toString(), fileTypeList, len);

        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);

        return fw0103Util.getItemList();
    }

//    /**
//     *
//     * 通信プロファイル情報取得処理.<br>
//     *<br>
//     * 概要:<br>
//     *   通信プロファイル情報を取得する
//     *<br>
//     * @param _profileSid 通信プロファイルSID
//     * @return 通信プロファイル情報
//     */
//    public MstProfileEntity getProfileInfo(final Integer _profileSid) {
//        CM_MstProfileDao clsCM_MstProfileDao = new CM_MstProfileDao();
//        initCustomerDbDao(clsCM_MstProfileDao);
//
//        return clsCM_MstProfileDao.selectProfileInfo(_profileSid);
//    }

//    /**
//     *
//     * プロファイル削除チェック.<br>
//     * <br>
//     * 概要:<br>
//     *
//     * @param _profileSid プロファイルSID
//     * @return 削除フラグ
//     */
//    public boolean isProfileDeleted(final String _profileSid) {
//        MstProfileEntity profile = this.getProfileInfo(Integer.valueOf(_profileSid));
//        return profile.deleteFlag;
//    }
//
//    /**
//     *
//     * 通信プロファイル名リストデータ取得処理.<br>
//     *<br>
//     * 概要:<br>
//     *   通信プロファイル名リストデータを取得する
//     *<br>
//     * @return 通信プロファイル名リスト
//     */
//    public List<BeanMap> getProfileNameList() {
//        CM_MstProfileDao clsCM_MstProfileDao = new CM_MstProfileDao();
//        initCustomerDbDao(clsCM_MstProfileDao);
//
//        // checkHasGroup関数の返り値がtrueの場合、ログインユーザの所属グループ配下のプロファイルを取得
//        // checkHasGroup関数の返り値がfalseの場合、グループ制御なしでプロファイル情報を取得
//        return clsCM_MstProfileDao.selectProfileNameList(
//                this.sessionDto.ssn_UserSID, CM_CommonUtil.checkHasGroup(this.sessionDto), false);
//    }
//
//    /**
//     *
//     * 通信プロファイル名称プルダウン取得処理（削除データ含む）.<br>
//     *<br>
//     * 概要:<br>
//     *   通信プロファイル名称プルダウンデータ（削除済みプロファイル含む）を取得する
//     *<br>
//     * @return 通信プロファイル名称プルダウンデータ
//     */
//    public List<Map<String, String>> getProfileNamePldIncludeDeleted() {
//        CM_MstProfileDao clsCM_MstProfileDao = new CM_MstProfileDao();
//        initCustomerDbDao(clsCM_MstProfileDao);
//
//        // checkHasGroup関数の返り値がtrueの場合、ログインユーザの所属グループ配下のプロファイルを取得
//        // checkHasGroup関数の返り値がfalseの場合、グループ制御なしでプロファイル情報を取得
//        List<BeanMap> list = clsCM_MstProfileDao.selectProfileNameList(
//                this.sessionDto.ssn_UserSID, CM_CommonUtil.checkHasGroup(this.sessionDto), true);
//
//        final int len = CM_A04_Const.LENGTH.PROFILE_NAME_MAX_LENGTH * 2;
//        FW01_03_CreateSingleSelectTagUtil fw0103Util = new FW01_03_CreateSingleSelectTagUtil(MstProfileEntityNames.sid().toString(),
//                MstProfileEntityNames.profileName().toString(), list, len);
//
//        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);
//
//        return fw0103Util.getItemList();
//
//    }


//    /**
//     *
//     * 通信プロファイル名リストデータ取得処理.<br>
//     * <br>
//     * 概要:<br>
//     * 通信プロファイル名リストデータを取得する <br>
//     *
//     * @return 通信プロファイル名リスト
//     */
//    public List<Map<String, String>> getProfileNamePldList() {
//        List<BeanMap> profileNamelist = this.getProfileNameList();
//
//        final int len = CM_A04_Const.LENGTH.DISTRIBUTION_DATA_NAME_STRING_MAX_LENGTH * 2;
//        FW01_03_CreateSingleSelectTagUtil fw0103Util = new FW01_03_CreateSingleSelectTagUtil(MstProfileEntityNames.sid().toString(), MstProfileEntityNames
//                .profileName().toString(), profileNamelist, len);
//
//        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);
//
//        return fw0103Util.getItemList();
//    }

    /**
     *
     * 配信データ名称プルダウン取得.<br>
     *<br>
     * 概要:<br>
     *   配信データ名称のプルダウンを取得する
     *<br>
     * @param _modelSid 型番SID
     * @return 配信データ名称プルダウン
     */
    public List<Map<String, String>> getDistributionDataNamePldByModelSid(final Integer _modelSid) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> distributionDataNameList = cmGetMstDataDao.selectDistributionDataNameListByModelSid(_modelSid);

        final int len = CM_A04_Const.LENGTH.DISTRIBUTION_DATA_NAME_STRING_MAX_LENGTH * 2;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(MstDistributeDataEntityNames.sid().toString(),
                        MstDistributeDataEntityNames.name().toString(), distributionDataNameList, len);

        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 配信データバージョンプルダウン取得.<br>
     *<br>
     * 概要:<br>
     *   配信データバージョンのプルダウンを取得する
     *<br>
     * @param _distSid 配信データSID
     * @return 配信データバージョンプルダウン
     */
    public List<Map<String, String>> getDistributionVersionPld(final Integer _distSid) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        List<BeanMap> distributionDataVersionList = cmGetMstDataDao.selectDistributionDataVersionList(_distSid);

        final int len = CM_A04_Const.LENGTH.DISTRIBUTION_DATA_VERSION_STRING_MAX_LENGTH * 2;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(MstDistributeDataVersionEntityNames.version().toString(),
                        MstDistributeDataVersionEntityNames.version().toString(), distributionDataVersionList, len);

        fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);

        return fw0103Util.getItemList();
    }

    /**
     *
     * 機器に対するグループIDおよびグループ情報（ツリーパス名称、グループ名称）取得.<br>
     *<br>
     * 概要:<br>
     *   機器に対するグループIDおよびグループ情報（ツリーパス名称、グループ名称）を取得する
     *<br>
     * @param _deviceSid 機器SID
     * @return グループ情報を格納したMAP
     */
    public BeanMap getGroupInfoForDeviceSid(final int _deviceSid) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        return cmGetMstDataDao.getGroupInfoForDeviceSid(_deviceSid);
    }

    /**
     *
     * 型番に対するグループIDおよびグループ情報（ツリーパス、ツリーパス名称、グループ名称）取得.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _modelSid 型番SID
     * @return グループ情報を格納したMAP
     */
    public BeanMap getGroupInfoForModelSid(final int _modelSid) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        return cmGetMstDataDao.getGroupInfoForModelSid(_modelSid);
    }

    /**
     *
     * 通信プロファイルに対するグループIDおよびグループ情報（ツリーパス、ツリーパス名称、グループ名称）取得.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _profileSid 通信プロファイルSID
     * @return グループ情報を格納したMAP
     */
    public BeanMap getGroupInfoForProfileSid(final int _profileSid) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        return cmGetMstDataDao.getGroupInfoForProfileSid(_profileSid);
    }

    /**
     * グループ情報取得処理.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _groupId グループID
     * @return グループ情報
     */
    public MstGroupEntity getGroupInfo(final String _groupId) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        return cmGetMstDataDao.getGroupInfo(_groupId);
    }

    /**
     * 指定された役割を使用している一般ユーザ数を取得する.<br>
     *<br>
     * 概要:<br>
     *<br>
     * @param _roleSid 役割SID
     * @return 指定された役割に紐づく一般ユーザ数
     */
    public long countUserListByRole(final Integer _roleSid) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        return cmGetMstDataDao.countUserListByRole(_roleSid);
    }

    /**
     *
     * 指定したグループがログインユーザの所属グループ配下かチェックする.<br>
     *<br>
     * 概要:<br>
     *   指定したグループがログインユーザの所属グループ配下かチェックする処理
     *<br>
     * @param _mstGroupEntity グループ情報
     * @return チェック結果(true：ログインユーザの所属グループ配下　false:ログインユーザの所属グループ配下でない)
     */
    public boolean checkUnderTheGroup(final MstGroupEntity _mstGroupEntity) {

        MstGroupEntity userGroupEntity = this.getGroupInfo(this.sessionDto.ssn_UserGroupSetting[0].ssn_GroupId);

        return this.checkUnderTheGroup(_mstGroupEntity, userGroupEntity);
    }

    /**
     *
     * 指定したグループが指定した所属グループ配下かチェックする.<br>
     *<br>
     * 概要:<br>
     *   指定したグループが指定した所属グループ配下かチェックする処理
     *<br>
     * @param _mstGroupEntity チェックしたいグループ情報
     * @param _userGroupEntity  所属グループのグループ情報
     * @return チェック結果(true：指定の所属グループ配下　false:指定の所属グループ配下でない)
     */
    public boolean checkUnderTheGroup(final MstGroupEntity _mstGroupEntity, final MstGroupEntity _userGroupEntity) {

        if (_mstGroupEntity.treePath.length() < _userGroupEntity.treePath.length()) {
            // 指定したの所属グループ配下じゃないグループを指定している。
            return false;
        } else {
            String substrTreePath = _mstGroupEntity.treePath.substring(0, _userGroupEntity.treePath.length());
            if (0 != _userGroupEntity.treePath.compareTo(substrTreePath)) {
                // ログインユーザの所属グループ配下じゃないグループを指定している。
                return false;
            }
        }
        return true;
    }

    /**
     * システム管理者権限ユーザ数取得.<br>
     * <br>
     * 概要:<br>
     * 指定したユーザID以外のシステム管理者権限のユーザ数を取得する<br>
     *
     * @param _id ユーザID
     * @return システム管理者権限ユーザ数
     */
    public long getAdminUserNum(final String _id) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        return cmGetMstDataDao.selectAdminUserNum(_id);
    }

    /**
     *
     * ユーザマスタ情報取得.<br>
     *<br>
     * 概要:<br>
     *   ユーザSIDを元にユーザマスタ情報を取得
     *<br>
     * @param _sid ユーザSID
     * @return ユーザマスタ情報
     */
    public MstUserEntity getMstUserInfo(final Integer _sid) {
        if (CM_CommonUtil.isNullOrBlank(_sid)) {
            return null;
        }
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);
        return cmGetMstDataDao.getMstUserInfo(_sid);
    }

    /**
     * コマンドSID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 通信プロファイルに紐付くコマンドSIDを取得する。 <br/>
     *
     * @param _profileSid 通信プロファイルSID
     * @return コマンドSIDリスト
     */
    public List<Integer> getCommandSidList(final Integer _profileSid) {
        // 返却用リストの初期化
        List<Integer> ret = null;

        if (CM_CommonUtil.isNotNullOrBlank(_profileSid)) {
            // コマンドSIDを取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getCommandSidList(_profileSid);
        }

        return ret;
    }

    /**
     * データポイントSID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 通信コマンドに紐付くデータポイントSIDを取得する。 <br/>
     *
     * @param _commandSidList コマンドSIDリスト
     * @return データポイントSIDリスト
     */
    public List<Integer> getDataPointSidList(final List<Integer> _commandSidList) {
        // 返却用リストの初期化
        List<Integer> ret = null;

        if (CM_CommonUtil.isNotNullOrEmpty(_commandSidList)) {
            // データポイントSIDを取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getDataPointSidList(_commandSidList);
        }

        return ret;
    }

    /**
     * イベント変換SID取得.<br/>
     * <br/>
     * 概要:<br/>
     * データポイントに紐付くイベント変換SIDを取得する。 <br/>
     *
     * @param _datapointSidList データポイントSIDリスト
     * @return イベント変換SIDリスト
     */
    public List<Integer> getEventConvertSidList(final List<Integer> _datapointSidList) {
        // 返却用リストの初期化
        List<Integer> ret = null;

        if (CM_CommonUtil.isNotNullOrEmpty(_datapointSidList)) {
            // イベント変換SIDを取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getEventConvertSidList(_datapointSidList);
        }

        return ret;
    }

    /**
     * 稼動状態SID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 通信プロファイルに紐付く稼動状態SIDを取得する。 <br/>
     *
     * @param _profileSid 通信プロファイルSID
     * @return 稼動状態SIDリスト
     */
    public List<Integer> getDeviceStatusSidList(final Integer _profileSid) {
        // 返却用リストの初期化
        List<Integer> ret = null;

        if (CM_CommonUtil.isNotNullOrBlank(_profileSid)) {
            // 稼動状態SIDを取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getDeviceStatusSidList(_profileSid);
        }

        return ret;
    }

    /**
     * 状態値設定SID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 稼動状態に紐付く状態値設定SIDを取得する。 <br/>
     *
     * @param _deviceStatusSidList 稼動状態SIDリスト
     * @return 状態値設定SIDリスト
     */
    public List<Integer> getDeviceStatusSettingSidList(final List<Integer> _deviceStatusSidList) {
        // 返却用リストの初期化
        List<Integer> ret = null;

        if (CM_CommonUtil.isNotNullOrEmpty(_deviceStatusSidList)) {
            // 稼動状態SIDを取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getDeviceStatusSettingSidList(_deviceStatusSidList);
        }

        return ret;
    }

    /**
     * トレンドビューSID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 通信プロファイルに紐付くトレンドビューSIDを取得する。 <br/>
     *
     * @param _profileSid 通信プロファイルSID
     * @return トレンドビューSIDリスト
     */
    public List<Integer> getTrendViewSidList(final Integer _profileSid) {
        // 返却用リストの初期化
        List<Integer> ret = null;

        if (CM_CommonUtil.isNotNullOrBlank(_profileSid)) {
            // 稼動状態SIDを取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getTrendViewSidList(_profileSid);
        }

        return ret;
    }

    /**
     * アラームSID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 通信プロファイルに紐付くアラームSIDを取得する。 <br/>
     *
     * @param _profileSid 通信プロファイルSID
     * @return アラームSIDリスト
     */
    public List<Integer> getAlarmSidList(final Integer _profileSid) {
        // 返却用リストの初期化
        List<Integer> ret = null;

        if (CM_CommonUtil.isNotNullOrBlank(_profileSid)) {
            // 稼動状態SIDを取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getAlarmSidList(_profileSid);
        }

        return ret;
    }

    /**
     * 配信データSID取得.<br/>
     * <br/>
     * 概要:<br/>
     * 型番に紐付く配信データSIDを取得する。 <br/>
     *
     * @param _modelSid 型番SID
     * @return 配信データSIDリスト
     */
    public List<Integer> getDistributeDataSidList(final Integer _modelSid) {
        // 返却用リストの初期化
        List<Integer> ret = null;

        if (CM_CommonUtil.isNotNullOrBlank(_modelSid)) {
            // 稼動状態SIDを取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getDistributeDataSidList(_modelSid);
        }

        return ret;
    }

    /**
     * 配信データバージョン取得.<br/>
     * <br/>
     * 概要:<br/>
     * 配信データSIDに紐付く配信データバージョンを取得する。 <br/>
     *
     * @param _distributeDataSidList 配信データSIDリスト
     * @return 配信データバージョンリスト
     */
    public List<MstDistributeDataVersionEntity> getDistributeDataVersionList(final List<Integer> _distributeDataSidList) {
        // 返却用リストの初期化
        List<MstDistributeDataVersionEntity> ret = null;

        if (CM_CommonUtil.isNotNullOrEmpty(_distributeDataSidList)) {
            // 稼動状態SIDを取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getDistributeDataVersionList(_distributeDataSidList);
        }

        return ret;
    }

    /**
     * 配信データ情報を取得する.<br/>
     * <br/>
     * 概要:<br/>
     *   配信データマスタ情報を取得する。 <br/>
     * @param _sid 配信データSID
     * @return 配信データマスタ情報
     */
    public MstDistributeDataEntity getMstDistributeData(final Integer _sid) {
        // 返却用エンティティの初期化
        MstDistributeDataEntity ret = null;

        if (CM_CommonUtil.isNotNullOrBlank(_sid)) {
            // 配信データ取得
            final CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getMstDistributeData(_sid);
        }

        return ret;
    }

    /**
     * ドキュメント情報一覧取得.<br/>
     * <br/>
     * 概要:<br/>
     * 型番に紐付くドキュメント情報一覧を取得する。 <br/>
     *
     * @param _modelSid 型番SID
     * @return ドキュメント情報一覧リスト
     */
    public List<MstDocumentEntity> getDocumentList(final Integer _modelSid) {
        // 返却用リストの初期化
        List<MstDocumentEntity> ret = null;

        if (CM_CommonUtil.isNotNullOrBlank(_modelSid)) {
            CM_MstDocumentDao cmMstDocumentDao = new CM_MstDocumentDao();
            initCustomerDbDao(cmMstDocumentDao);

            ret = cmMstDocumentDao.getDocumentList(_modelSid);
        }

        return ret;
    }

    /**
     * アラームアイコンデータ取得処理.<br/>
     * <br/>
     * 概要:<br/>
     * 指定された型番に紐付くアラームアイコンデータを取得する。 <br/>
     *
     * @param _txtModelSid 型番SID（文字列）
     * @return アラームアイコンデータ
     */
    public List<BeanMap> getAlarmIconMapList(final String _txtModelSid) {
        // 返却用リストの初期化
        List<BeanMap> ret = new ArrayList<BeanMap>();

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);
        Map<String, String> iconDataMap = new HashMap<String, String>();

        if (CM_CommonUtil.isNotNullOrBlank(_txtModelSid)) {
            // 型番アイコン関連マスタから対象型番のデータを取得
            Integer modelSid = Integer.valueOf(_txtModelSid);
            List<RelModelIconEntity> iconDataList = cmGetMstDataDao.getAlarmIconData(modelSid);
            for (RelModelIconEntity iconData : iconDataList) {
                iconDataMap.put(iconData.iconType, iconData.fileName);
            }
        }

        // 名称マスタ（システム用）からアイコンタイプを取得
        List<BeanMap> sysNameMapList = CM_SysNameDataUtil.getNameList(
                this.sessionDto, CM_A04_Const.SYS_NAME_MST_NAME_TYPE.ICON_TYPE, this.sessionDto.ssn_UserLangCD);

        for (BeanMap sysNameMap : sysNameMapList) {
            // アイコンタイプに対して、デフォルトアイコンのパスを設定
            String iconType = (String) sysNameMap.get(SysNameEntityNames.itemCd());
            String filePath = FW00_19_Const.EMPTY_STR;

            if (iconDataMap.containsKey(iconType) && CM_CommonUtil.isNotNullOrBlank(iconDataMap.get(iconType))) {
                // DBにアイコンパスが登録されている場合
                String tmpFilePath = CM_CommonUtil.makeMapIconFilePath(this.sessionDto, _txtModelSid, iconDataMap.get(iconType));
                File file = new File(tmpFilePath);
                if (file.exists()) {
                    // ファイルが存在すれば、そのパスをセットする
                    filePath = tmpFilePath;
                }
            }

            // デフォルトファイルパスを取得
            String alarmLv = CM_A04_Const.AlarmIcon.getAlarmLv(iconType);
            String defaultFilePath = CM_CommonUtil.getDefaultMapIcon(alarmLv);

            // 表示用データの作成
            BeanMap dispIconDataMap = new BeanMap();
            dispIconDataMap.put(MstAlarmEntityNames.alarmLevel().toString(), (String) sysNameMap.get(SysNameEntityNames.name1()));
            dispIconDataMap.put(RelModelIconEntityNames.iconType().toString(), iconType);
            dispIconDataMap.put(MAPKEY_FILE_PATH, filePath);
            dispIconDataMap.put(MAPKEY_DEFAULT_FILE_PATH, defaultFilePath);

            ret.add(dispIconDataMap);
        }

        return ret;
    }

    /**
     * アラームアイコンデータ取得処理.<br/>
     * <br/>
     * 概要:<br/>
     * 指定された型番に紐付くアラームアイコンデータを取得する。 <br/>
     *
     * @param _txtModelSid 型番SID（文字列）
     * @return アラームLvとユーザアイコンパスのMap
     */
    public Map<String, String> getAlarmIconList(final String _txtModelSid) {
        // 返却用リストの初期化
        Map<String, String> ret = new HashMap<String, String>();

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        if (CM_CommonUtil.isNotNullOrBlank(_txtModelSid)) {
            // 型番アイコン関連マスタから対象型番のデータを取得
            Integer modelSid = Integer.valueOf(_txtModelSid);
            List<RelModelIconEntity> iconDataList = cmGetMstDataDao.getAlarmIconData(modelSid);
            HashMap<String, String> iconAlarmLv = new HashMap<String, String>();
            for (RelModelIconEntity iconData : iconDataList) {
                iconAlarmLv.put(CM_A04_Const.AlarmIcon.getAlarmLv(iconData.iconType), iconData.fileName);
                String fileFullPath = "";
                if (CM_CommonUtil.isNotNullOrBlank(iconAlarmLv.get(CM_A04_Const.AlarmIcon.getAlarmLv(iconData.iconType)))) {
                    fileFullPath
                        = CM_CommonUtil.makeIconDirPath(this.sessionDto, _txtModelSid) + iconAlarmLv.get(CM_A04_Const.AlarmIcon.getAlarmLv(iconData.iconType));
                } else {
                    fileFullPath = CM_CommonUtil.getDefaultMapIcon(iconAlarmLv.get(iconData.iconType));
                }

                File file = new File(fileFullPath);

                if (file.exists()) {
                    // ファイルのフルパスを取得
                    fileFullPath = file.getAbsolutePath();
                }
                ret.put(CM_A04_Const.AlarmIcon.getAlarmLv(iconData.iconType), fileFullPath);
            }
        }

        return ret;
    }

    /**
    *
    * 画像転送処理.<br/>
    *<br/>
    * 概要:<br/>
    * 失敗時は例外を出さない。戻り値で判別する。<br/>
    *<br/>
    * @param _response HTTPレスポンス
    * @param _srcPicFilePath 画像ファイルフルパス
    * @param _ext 拡張子
    * @return true:成功/false:失敗
    */
    public boolean downloadPicFileNoThrow(final HttpServletResponse _response, final String _srcPicFilePath, final String _ext,final CM_A03_SessionDto _sessionDto ) {
        boolean ret = true;

        ImageOutputStream ios = null;
        try {

            File picfile = new File(_srcPicFilePath);
            BufferedImage im = ImageIO.read(picfile);

            // 拡張子を小文字に変換
            String ext = _ext.toLowerCase();
            String mimeType;

            if (StringUtil.equals(ext, CM_A04_Const.PIC_EXT.BMP)) {
                mimeType = "image/x-bmp";
            } else if (StringUtil.equals(ext, CM_A04_Const.PIC_EXT.PNG)) {
                mimeType = "image/png";
            } else if (StringUtil.equals(ext, CM_A04_Const.PIC_EXT.GIF)) {
                mimeType = "image/gif";
            } else {
                mimeType = "image/jpeg";
            }

            _response.setContentType(mimeType);
            ServletOutputStream sos = _response.getOutputStream();
            ios = ImageIO.createImageOutputStream(sos);
            ImageIO.write(im, ext, ios);

        } catch (Exception e) {
            // 例外情報はログ出力
            CM_LoggerUtil.outputErrorLog(_sessionDto, e);

            ret = false;
        } finally {
            if (ios != null) {
                try {
                    ios.close();
                } catch (IOException e) {
                    // 例外情報はログ出力
                    CM_LoggerUtil.outputErrorLog(_sessionDto, e);
                }
            }
        }

        return ret;
    }



    /**
     * プロファイルに紐付くアラーム条件の件数を取得する.
     *
     * @param _profileSid プロファイルSID
     * @return プロファイルに紐付くアラーム条件数
     */
    public long getRelProfileAlarmCnt(final Integer _profileSid) {
        long ret = 0;
        if (CM_CommonUtil.isNotNullOrBlank(_profileSid)) {
            // 稼動状態SIDを取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getRelProfileAlarmCnt(_profileSid);
        }

        return ret;
    }

    /**
     * プロファイルに紐付くイベント変換情報の件数を取得する.
     *
     * @param _profileSid プロファイルSID
     * @return イベント変換情報の件数
     */
    public long getRelProfileEventCnt(final Integer _profileSid) {

        long ret = 0;
        if (CM_CommonUtil.isNotNullOrBlank(_profileSid)) {
            // 稼動状態SIDを取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getRelProfileEventCnt(_profileSid);
        }

        return ret;

    }

    /**
     * プロファイルに紐付くトレンドビューの件数を取得する.
     *
     * @param _profileSid プロファイルSID
     * @return プロファイルに紐付くトレンドビュー数
     */
    public long getRelProfileTrendViewCnt(final Integer _profileSid) {

        long ret = 0;
        if (CM_CommonUtil.isNotNullOrBlank(_profileSid)) {
            // 稼動状態SIDを取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getRelProfileTrendCnt(_profileSid);
        }

        return ret;
    }

    /**
     * 型番に紐付く配信データの件数を取得する.
     *
     * @param _modelSid 型番SID
     * @return 型番に紐付く配信データ数
     */
    public long getRelModelDistributeCnt(final Integer _modelSid) {

        long ret = 0;
        if (CM_CommonUtil.isNotNullOrBlank(_modelSid)) {
            // 稼動状態SIDを取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getRelModelDistributeCnt(_modelSid);
        }

        return ret;

    }

    /**
     * 型番に紐付く資料情報の数を取得.
     *
     * @param _modelSid 型番SID
     * @return 型番に紐付く資料情報数
     */
    public long getRelModelDocumentCnt(final Integer _modelSid) {

        long ret = 0;
        if (CM_CommonUtil.isNotNullOrBlank(_modelSid)) {
            // 稼動状態SIDを取得
            CM_MstDocumentDao cmMstDocumentDao = new CM_MstDocumentDao();
            initCustomerDbDao(cmMstDocumentDao);
            ret = cmMstDocumentDao.getRelModelDocumentCnt(_modelSid);
        }

        return ret;

    }

    /**
     * 機器に紐付く資料情報の数を取得.
     *
     * @param _deviceSid 機器SID
     * @return 機器に紐付く資料情報数
     */
    public long getRelDeviceDocumentCnt(final Integer _deviceSid) {

        long ret = 0;
        if (CM_CommonUtil.isNotNullOrBlank(_deviceSid)) {
            // 資料件数を取得
            CM_MstDocumentDao cmMstDocumentDao = new CM_MstDocumentDao();
            initCustomerDbDao(cmMstDocumentDao);
            ret = cmMstDocumentDao.getRelDeviceDocumentCnt(_deviceSid);
        }

        return ret;

    }

    /**
     * 機器に紐付く報告書の数を取得.
     *
     * @param _deviceSid 機器SID
     * @return 機器に紐付く報告書数
     */
    public long getRelDeviceReportCnt(final Integer _deviceSid) {

        long ret = 0;
        if (CM_CommonUtil.isNotNullOrBlank(_deviceSid)) {
            // 報告書件数を取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getRelDeviceReportCnt(_deviceSid);
        }

        return ret;

    }

    /**
     * 機器に紐付く配信状況の件数を取得.
     *
     * @param _deviceSid 機器SID
     * @return 機器に紐付く配信状況件数
     */
    public long getRelDeviceDistributeStatusCnt(final Integer _deviceSid) {

        long ret = 0;
        if (CM_CommonUtil.isNotNullOrBlank(_deviceSid)) {
            // 配信状況件数を取得
            CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
            initCustomerDbDao(cmGetMstDataDao);
            ret = cmGetMstDataDao.getRelDeviceDistributeStatusCnt(_deviceSid);
        }

        return ret;

    }

    /**
     * 型番とアイコンタイプに関連するアイコン情報を取得.
     *
     * @param _modelSid
     *            型番SID
     * @param _iconType
     *            アイコンタイプ
     * @return アイコン情報
     */
    public RelModelIconEntity getRelModelIconEntity(final Integer _modelSid, final String _iconType) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        return cmGetMstDataDao.getRelModelIconEntity(_modelSid, _iconType);
    }

    /**
     * 機器SIDに関連するアイコン情報リストを取得.
     *
     * @param _deviceSid
     *            機器SID
     * @return アイコン情報リスト
     */
    public List<RelModelIconEntity> getRelModelIconListByDiviceSid(final Integer _deviceSid) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        return cmGetMstDataDao.getRelModelIconListByDeviceSid(_deviceSid);
    }

    /**
     * 機器SIDに関連するMapアイコン画像情報を取得.
     *
     * @param _deviceSid
     *            機器SID
     * @return アラームアイコン情報 Map<アラームレベル、アイコンパス>
     */
    public Map<String, String> getMapIconPathInfo(final Integer _deviceSid) {
        // アラームアイコン情報 <アラームレベル、アイコンパス>
        Map<String, String> alarmIconInfo = new HashMap<String, String>();

        // 登録されたアイコンを設定
        List<RelModelIconEntity> modelIconList = this.getRelModelIconListByDiviceSid(_deviceSid);
        for (RelModelIconEntity relModelIconEntity : modelIconList) {
            // 型番SID
            Integer modelSid = relModelIconEntity.modelSid;
            // アイコン種別
            String iconType = relModelIconEntity.iconType;
            // アラームレベル
            String alarmLv = CM_A04_Const.AlarmIcon.getAlarmLv(iconType);

            // アイコンパス取得
            String iconPath = CM_CommonUtil.getMapIconPath(CM_A02_ListAction.ICON_IMAGE_DOWNLOAD_METHOD_NAME, modelSid, iconType);

            alarmIconInfo.put(alarmLv, iconPath);
        }

        // ディフォルトアイコンを設定
        for (CM_A04_Const.AlarmIcon alarm : CM_A04_Const.AlarmIcon.values()) {
            // アラームLv
            String alarmLv = alarm.alarmLv;

            if (alarmIconInfo.containsKey(alarmLv)) {
                // アイコン設定済みの場合スキップ
                continue;
            }

            // アイコンパス取得
            String iconPath = CM_CommonUtil.getDefaultMapIcon(alarmLv);

            alarmIconInfo.put(alarmLv, iconPath);
        }
        return alarmIconInfo;
    }

    /**
     *
     * 空き容量チェック.<br>
     * <br>
     * 概要:<br>
     * 空き容量をチェックする。 <br>
     *
     * @param _fileSize ファイルサイズ
     * @return 処理結果
     */
    public boolean checkDiskSpace(final int _fileSize) {

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        Integer amountUsed = cmGetMstDataDao.getAmountUsed();

        if (CM_CommonUtil.isNullOrBlank(amountUsed)) {
            amountUsed = 0;
        }

        long storageMax = (long) this.sessionDto.ssn_StorageMax * FW00_19_Const.MEGA_BYTES * FW00_19_Const.KILO_BYTES;
        long amountUse =  (long) amountUsed.intValue() *  FW00_19_Const.KILO_BYTES;

        if (storageMax < amountUse + (long) _fileSize) {

            // 使用量がディスク容量上限値を超えている場合
            return false;
        }

        return true;
    }

    /**
     *
     * 使用量容量取得.<br>
     * <br>
     * 概要:<br>
     * 使用量容量を取得する。 <br>
     *
     * @return 使用量（単位:byte)
     */
    public long getUesdDiskSpace() {

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        long amountUse = 0;
        Integer amountUsed = cmGetMstDataDao.getAmountUsed();

        if (CM_CommonUtil.isNotNullOrBlank(amountUsed)) {
            amountUse = (long) amountUsed.intValue() *  FW00_19_Const.KILO_BYTES;
        }

        return amountUse;
    }

   /**
    *
    * 機器登録台数チェック.<br>
    * <br>
    * 概要:<br>
    * 機器登録台数をチェックする. <br>
    *
    * @param _addCount 登録台数
    * @return 処理結果
    */
    public boolean checkDeviceCount(final long _addCount) {

        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        long deviceCount = cmGetMstDataDao.getDeviceCount();

        if (this.sessionDto.ssn_MaxDeviceNumber < deviceCount + _addCount) {

            // 登録後の機器台数が最大機器台数を超えている場合
            return false;
        }
        return true;
    }


    /**
     * 閾値越え通知メール送信処理.
     *
     * @param _fileSize ファイルサイズ
     */
    public void checkDiskThreshold(final int _fileSize) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        try {
            long usedSpace = this.getUesdDiskSpace() + _fileSize;

            long storageMax = (long) this.sessionDto.ssn_StorageMax * FW00_19_Const.MEGA_BYTES * FW00_19_Const.KILO_BYTES;
            List<BeanMap> thresholdList = CM_SysEnvDataUtil.selectListSysEnv(this.sessionDto, CM_A04_Const.SYS_ENV_MST_ENV_CD.CONTRACT_THRESHOLD);
            // 使用率
            BigDecimal decimalUsedSpace = new BigDecimal(usedSpace);
            BigDecimal decimalStorageMax = new BigDecimal(storageMax);
            BigDecimal usedRate = decimalUsedSpace.divide(decimalStorageMax).multiply(new BigDecimal(100));

            // 通知周期取得
            BeanMap noticePeriodEntity = CM_SysEnvDataUtil.selectSysEnv(this.sessionDto, CM_A04_Const.SYS_ENV_MST_ENV_CD.OVER_CAPACITY,
                    CM_A04_Const.SYS_ENV_MST_ITEM_CD.NOTICE_PERIOD);

            long noticePeriod = Integer.valueOf(noticePeriodEntity.get(SysEnvEntityNames.name()).toString()) * FW00_19_Const.SECOND * FW00_19_Const.MILLI;

            // 現在日取得
            Calendar calendar = Calendar.getInstance();
            Date dateNow = calendar.getTime();
            long longDateNow = dateNow.getTime();

            // 通信日時
            SysEnvEntity noticeDatetimeEntity = cmGetMstDataDao.getSysEnvEntity(CM_A04_Const.SYS_ENV_MST_ENV_CD.OVER_CAPACITY,
                    CM_A04_Const.SYS_ENV_MST_ITEM_CD.NOTICE_DATETIME);

            // 通知日時取得
            SimpleDateFormat sdf = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT_MIN);
            long longDate = 0;
            if (CM_CommonUtil.isNotNullOrBlank(noticeDatetimeEntity.name)) {
                Date date = sdf.parse(noticeDatetimeEntity.name);
                longDate = date.getTime();
            }
            // 通知フラグ
            BeanMap noticeFlgEntity = CM_SysEnvDataUtil.selectSysEnv(this.sessionDto, CM_A04_Const.SYS_ENV_MST_ENV_CD.OVER_CAPACITY,
                    CM_A04_Const.SYS_ENV_MST_ITEM_CD.NOTICE_FLAG);
            boolean noticeFlg = CM_CommonUtil.checkNoticeFlg(noticeFlgEntity.get(SysEnvEntityNames.name()).toString());

            // 前回通知閾値
            SysEnvEntity noticeThresholdEntity = cmGetMstDataDao.getSysEnvEntity(CM_A04_Const.SYS_ENV_MST_ENV_CD.OVER_CAPACITY,
                    CM_A04_Const.SYS_ENV_MST_ITEM_CD.NOTICE_THRESHOLD);

            Integer noticeThreshold = 0;
            if (CM_CommonUtil.isNotNullOrBlank(noticeThresholdEntity.name)) {
                noticeThreshold = Integer.valueOf(noticeThresholdEntity.name);
            }

            for (BeanMap thresholdInfo : thresholdList) {
                String strThresholdValue = thresholdInfo.get(SysEnvEntityNames.itemCd()).toString();
                Integer thresholdValue = Integer.valueOf(strThresholdValue);
                if (usedRate.floatValue() > thresholdValue) {
                    // 前回通知時間から通知周期を過ぎているまたは、前回の通知閾値と一致しているか
                    if (longDateNow - longDate > noticePeriod || thresholdValue != noticeThreshold) {

                        // 環境マスタ更新
                        // 通知日時
                        noticeDatetimeEntity.name = sdf.format(dateNow);
                        Timestamp timestampNow = new Timestamp(longDateNow);
                        noticeDatetimeEntity.updTim = timestampNow;
                        cmGetMstDataDao.updateSysEnvEntity(noticeDatetimeEntity);

                        // 通知閾値
                        noticeThresholdEntity.name = strThresholdValue;
                        noticeThresholdEntity.updTim = timestampNow;
                        cmGetMstDataDao.updateSysEnvEntity(noticeThresholdEntity);

                        List<String> mailAddressList = new ArrayList<String>();
                        // OEM事業者メールアドレス
                        if (CM_CommonUtil.isNotNullOrBlank(this.sessionDto.ssn_OemContactMailAddress1)) {
                            mailAddressList.add(this.sessionDto.ssn_OemContactMailAddress1);
                        }
                        if (CM_CommonUtil.isNotNullOrBlank(this.sessionDto.ssn_OemContactMailAddress2)) {
                            mailAddressList.add(this.sessionDto.ssn_OemContactMailAddress2);
                        }
                        if (noticeFlg) {
                            if (CM_CommonUtil.isNotNullOrBlank(this.sessionDto.ssn_ContactMailAddress1)) {
                                mailAddressList.add(this.sessionDto.ssn_ContactMailAddress1);
                            }
                            if (CM_CommonUtil.isNotNullOrBlank(this.sessionDto.ssn_ContactMailAddress2)) {
                                mailAddressList.add(this.sessionDto.ssn_ContactMailAddress2);
                            }
                        }
                        if (mailAddressList.size() > 0) {
                            Map<String, MstMailTemplateEntity> mailTemplate = this.getMailTemplateInfo(cmGetMstDataDao, thresholdValue);
                            CM_CommonUtil.sendOverCapacityErrorMail(this.sessionDto, mailTemplate, mailAddressList, strThresholdValue);
                        }
                    }
                    break;
                }
            }
        } catch (Exception e) {
            CM_LoggerUtil.outputErrorLog(this.sessionDto, e);
        }
    }

    /**
     * メールテンプレート一覧取得.
     *
     * @param _cmGetMstDataDao 環境マスタ処理Dao
     * @param _thresholdValue 閾値
     * @return メールテンプレート一覧
     */
    private Map<String, MstMailTemplateEntity> getMailTemplateInfo(final CM_GetMstDataDao _cmGetMstDataDao, final int _thresholdValue) {
        Map<String, MstMailTemplateEntity> ret = new HashMap<String, MstMailTemplateEntity>();
        final String mailType = String.valueOf(_thresholdValue);
        List<MstMailTemplateEntity> mailTemplateList = _cmGetMstDataDao.getMailTemplateEntity(CM_A04_Const.MAIL_ALARM_KIND.OVER_CAPACITY, mailType);

        for (MstMailTemplateEntity mailTemplate : mailTemplateList) {
            ret.put(mailTemplate.langCd, mailTemplate);
        }
        return ret;
    }

    /**
     * グラフ要素色の初期化.
     */
    public void initGraphColor() {

        CM_GraphUtil.initColorList(this.sessionDto);
    }

    /**
     * 工場マスタ取得.
     * @param _plantCode 工場コード
     * @return 工場マスタ
     */
    public MaPlantEntity getMaPlantEntity(final String _plantCode) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);
        return cmGetMstDataDao.getMstPlant(_plantCode);
    }

    /**
     * 機種カテゴリ名称リスト取得.
     * @param _plantCode 工場コード
     * @return 機種カテゴリ名称リストデータ
     */
    public List<BeanMap> getMstKishuCtlgNameList(final String _plantCode) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);
        // 機種カテゴリ名称名称リスト抽出
        return cmGetMstDataDao.getMstKishuCtlgNameList(_plantCode);
    }

    /**
     * 機種カテゴリプルダウンリストデータ取得.
     *
     * @param _plantCode
     *            工場コード
     * @param _hasEmpty
     *            空を含むかどうか
     * @return 機種カテゴリプルダウンリストデータ
     */
//    public List<Map<String, String>> getMstKishuCtlgPld(final String _plantCode, final boolean _hasEmpty) {
//        // 機種カテゴリリスト抽出
//        List<BeanMap> resList = this.getMstKishuCtlgNameList(_plantCode);
//        // プルダウン作成
//        int len = CM_A04_Const.LENGTH.MODEL_NAME_MAX_LENGTH * 2;
//
//        FW01_03_CreateSingleSelectTagUtil fw0103Util = new FW01_03_CreateSingleSelectTagUtil(MstErpModelGroupCategory01EntityNames.kishuCtgr().toString(),
//                MstErpModelGroupCategory01EntityNames.kishuName().toString(), resList, len);
//
//        if (_hasEmpty) {
//            fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);
//        }
//        return fw0103Util.getItemList();
//    }

    /**
     * 製造ライン名称リスト取得.
     * @param _plantCode 工場コード
     * @return 製造ラインマスタリストデータ
     */
    public List<BeanMap> getMstSeizouLineNameList(final String _plantCode) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 製造ライン名称リスト抽出
        return cmGetMstDataDao.getMstSeizouLineNameList(_plantCode);
    }

    /**
     * 製造ライン名称リスト取得（未来生産負荷状況用）.
     * @param _plantCode 工場コード
     * @return 製造ラインマスタリストデータ
     */
    public List<BeanMap> getMstSeizouLineNameListForMirai(final String _plantCode) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 製造ライン名称リスト抽出
        return cmGetMstDataDao.getMstSeizouLineNameListForMirai(_plantCode);
    }

    /**
     * 製造ラインプルダウンリストデータ取得.
     *
     * @param _plantCode 工場コード
     * @param _hasEmpty 空を含むかどうか
     * @return 製造ラインプルダウンリストデータ
     */
    public List<Map<String,String>> getMstSeizouLinePld(final String _plantCode, final boolean _hasEmpty) {
        // 製造ラインリスト抽出
        List<BeanMap> resList = this.getMstSeizouLineNameList(_plantCode);

        // プルダウン作成
        final int len = CM_A04_Const.LENGTH.SEIZO_LINE_NAME_MAX_LENGTH;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(
                        MaSeizouLineEntityNames.seizouLnId().toString(),
                        MaSeizouLineEntityNames.seizouLnNm().toString(),
                        resList, len);

        if (_hasEmpty) {
            fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);
        }
        return fw0103Util.getItemList();
    }

    /**
     * 製造ラインプルダウンリストデータ取得（未来生産負荷状況用）.
     *
     * @param _plantCode 工場コード
     * @param _hasEmpty 空を含むかどうか
     * @return 製造ラインプルダウンリストデータ
     */
    public List<Map<String,String>> getMstSeizouLinePldForMirai(final String _plantCode, final boolean _hasEmpty) {
        // 製造ラインリスト抽出
        List<BeanMap> resList = this.getMstSeizouLineNameListForMirai(_plantCode);

        // プルダウン作成
        final int len = CM_A04_Const.LENGTH.SEIZO_LINE_NAME_MAX_LENGTH;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(
                        MaSeizouLineEntityNames.seizouLnId().toString(),
                        MaSeizouLineEntityNames.seizouLnNm().toString(),
                        resList, len);

        if (_hasEmpty) {
            fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);
        }
        return fw0103Util.getItemList();
    }

    /**
     * 工程名称リスト取得.<br>
     * @param _plantCode 工場コード
     * @param _seizouLnId 製造ラインID
     * @return 工程名称リスト
     */
    public List<BeanMap> getMstProcessNameList(final String _plantCode, final String _seizouLnId) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 製造ラインID
        Long seizouLnId = CM_CommonUtil.getLongVal(_seizouLnId);

        // 工程名称リスト抽出
        return cmGetMstDataDao.getMstProcessNameList(_plantCode, seizouLnId);
    }
    /**
     * 工程プルダウンリストデータ取得.
     *
     * @param _plantCode 工場コード
     * @param _seizouLineId 製造ラインID
     * @param _hasEmpty 空を含むかどうか
     * @return 工程プルダウンリストデータ
     */
    public List<Map<String,String>> getMstProcessPld(
            final String _plantCode, final String _seizouLineId, final boolean _hasEmpty) {
        // 工程リスト抽出
        List<BeanMap> resList = this.getMstProcessNameList(_plantCode, _seizouLineId);

        // プルダウン作成
        final int len = CM_A04_Const.LENGTH.PROCESS_NAME_MAX_LENGTH;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(
                        MaProcessEntityNames.processId().toString()
                        , MaProcessEntityNames.processNm().toString()
                        , resList, len);

        if (_hasEmpty) {
            fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);
        }
        return fw0103Util.getItemList();
    }

    /**
     * ステーション名称リスト取得.<br>
     * @param _plantCode 工場コード
     * @param _seizouLnId 製造ラインID
     * @param _processId 工程ID
     * @param _lnId ラインID
     * @return ステーション名称リスト
     */
    public List<BeanMap> getMstStationNameList(
            final String _plantCode, final String _seizouLnId, final String _processId, final String _lnId) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 製造ラインID
        Long seizouLnId = CM_CommonUtil.getLongVal(_seizouLnId);
        // 工程ID
        Long processId = CM_CommonUtil.getLongVal(_processId);
        // ラインID
        Long lnId = CM_CommonUtil.getLongVal(_lnId);

        // ステーション名称リスト抽出
        return cmGetMstDataDao.getMstStationNameList(_plantCode, seizouLnId, processId, lnId);
    }
    /**
     * ステーションプルダウンリストデータ取得.
     *
     * @param _plantCode 工場コード
     * @param _seizouLineId 製造ラインID
     * @param _processId 工程ID
     * @param _lineId ラインID
     * @param _hasEmpty 空を含むかどうか
     * @return ステーションラインプルダウンリストデータ
     */
    public List<Map<String,String>> getMstStationPld(
            final String _plantCode, final String _seizouLineId, final String _processId, final String _lineId, final boolean _hasEmpty) {
        // ステーションリスト抽出
        List<BeanMap> resList = this.getMstStationNameList(_plantCode, _seizouLineId, _processId, _lineId);

        // プルダウン作成
        final int len = CM_A04_Const.LENGTH.STATION_NO_MAX_LENGTH;
        FW01_03_CreateSingleSelectTagUtil fw0103Util =
                new FW01_03_CreateSingleSelectTagUtil(
                        MaStationEntityNames.stId().toString()
                        , MaStationEntityNames.stNm().toString()
                        , resList, len);

        if (_hasEmpty) {
            fw0103Util.addOption(ADD_TYPE.FIRST, FW00_19_Const.EMPTY_STR, true);
        }
        return fw0103Util.getItemList();
    }

    /**
     * 警告メッセージ取得.
     * @return 警告メッセージ
     */
    public String getAlertMessage(final BeanMap formMap) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // sys_envからタイムアウト時間を取得
        String connectTime = null;
        if (CM_CommonUtil.isNullOrBlank(this.sessionDto.ssn_CustomerCD)) {
            return null;
        }

        BeanMap sysEnv = CM_SysEnvDataUtil.selectSysEnv(this.sessionDto,
                CM_A04_Const.SYS_ENV_MST_ENV_CD.MES_CONNECT_TIME,
                CM_A04_Const.SYS_ENV_MST_ITEM_CD.MES_CONNECT_DEF);

//        Date dat = new Date();
//        Timestamp now = new Timestamp(dat.getTime());
//        String strDate = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT_MONTH_MIN_HYPHEN).format(now);

        String strErrorMes;
        if (CM_CommonUtil.isNotNullOrBlank(sysEnv)) {
            connectTime = sysEnv.get(SysEnvEntityNames.name()).toString();

            // 実際の接続時間を取得
            long actConnectTime = cmGetMstDataDao.getMesConnectInfoDto(formMap);
            if (actConnectTime == -1) {
                // 取得できない場合は終了
                return null;
            }

            // エラー検出日時を取得
            Integer oi;

            Calendar now = Calendar.getInstance();
            long longNow = now.getTimeInMillis();
            long diff = longNow - actConnectTime;
            now.setTimeInMillis(diff);
            int intMonth = now.get(Calendar.MONTH) + 1;
            int intDay = now.get(Calendar.DAY_OF_MONTH);
            int intHour = now.get(Calendar.HOUR_OF_DAY);
            int intMin = now.get(Calendar.MINUTE);

            oi = new Integer(intMonth);
            String strMonth = oi.toString();
            if (strMonth.length() < 2) {
                strMonth = "0" + strMonth;
            }

            oi = new Integer(intDay);
            String strDay = oi.toString();
            if (strDay.length() < 2) {
                strDay = "0" + strDay;
            }

            oi = new Integer(intHour);
            String strHour = oi.toString();
            if (strHour.length() < 2) {
                strHour = "0" + strHour;
            }

            oi = new Integer(intMin);
            String strMin = oi.toString();
            if (strMin.length() < 2) {
                strMin = "0" + strMin;
            }

            String strDate = strMonth + "-" + strDay + " " + strHour + ":" + strMin;

            if (actConnectTime > Integer.parseInt(connectTime)) {

                strErrorMes = CM_MessageUtil.getMESErrorMessage(this.sessionDto, strDate);
            } else {
                strErrorMes = null;
            }
        } else {
            Date dat = new Date();
            Timestamp now = new Timestamp(dat.getTime());
            String strDate = new SimpleDateFormat(CM_A04_Const.DATE_FORMAT_MONTH_MIN_HYPHEN).format(now);
            strErrorMes = CM_MessageUtil.getMESDBErrorMessage(this.sessionDto, strDate);
        }

        // 警告メッセージ取得
        return strErrorMes;
    }

    /**
    *
    * ユーザ工場CD取得.<br>
    *<br>
    * 概要:<br>
    *  ユーザ工場CD取得処理<br>
    *  作業者マスタからログインユーザのIDを元に工場コードを取得する
    *<br>
    * @return ユーザ工場CD
    */
   public String getUserPlantCode() {
       return this.getCustomerDao().getUserPlantCode(this.sessionDto.ssn_UserID);
   }

    /**
     * 工程ID取得.<br>
     * @param _plantCode 工場コード
     * @param _seizouLnId 製造ラインID
     * @param _lnId ラインID
     * @return 工程IDリスト
     */
    public List<BeanMap> getMstProcessId(final String _plantCode, final String _seizouLnId, final String _lnId) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);

        // 製造ラインID
        Long seizouLnId = CM_CommonUtil.getLongVal(_seizouLnId);
        // ラインID
        Long lnId = CM_CommonUtil.getLongVal(_lnId);

        // 工程IDリスト抽出
        return cmGetMstDataDao.getMstProcessId(_plantCode, seizouLnId, lnId);
    }

    /**
     * 工場マスタ(見える化専用)取得.
     * @param _plantCode 工場コード
     * @return 工場マスタ(見える化専用)
     */
    public MaPlantMierukaEntity getMstPlantMierukaEntity(final String _plantCode) {
        CM_GetMstDataDao cmGetMstDataDao = new CM_GetMstDataDao();
        initCustomerDbDao(cmGetMstDataDao);
        return cmGetMstDataDao.getMstPlantMieruka(_plantCode);
    }

}
