/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/01| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.excel;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * Excelフォーマット情報.<br>
 *<br>
 * 概要:<br>
 *  Excelのフォーマット情報
 *<br>
 */
public class CM_ExcelFormat {

    /**
     * シート毎のフォーマット情報一覧.
     */
    List<CM_ExcelSheetInfoDto> sheetInfoList = new ArrayList<CM_ExcelSheetInfoDto>();

    /**
     * シート毎のフォーマット情報一覧を取得.
     *
     * @return シート毎のフォーマット情報一覧
     */
    public List<CM_ExcelSheetInfoDto> getSheetInfoList() {
        return this.sheetInfoList;
    }

    /**
     * シート毎のフォーマット情報一覧を設定する.
     *
     * @param _sheetInfoList シート毎のフォーマット情報一覧
     */
    public void setSheetInfoList(final List<CM_ExcelSheetInfoDto> _sheetInfoList) {
        this.sheetInfoList = _sheetInfoList;
    }

    /**
     *
     * シートのフォーマット情報設定.<br>
     *<br>
     * 概要:<br>
     *   シート毎のフォーマット情報一覧にシートのフォーマット情報を設定
     *<br>
     * @param _sheetInfo シートのフォーマット情報
     */
    public void addSheetInfo(final CM_ExcelSheetInfoDto _sheetInfo) {
        this.sheetInfoList.add(_sheetInfo);
    }

    /**
     * クローン処理.
     * @return クローン
     */
    public CM_ExcelFormat clone() {
        CM_ExcelFormat myObj = new CM_ExcelFormat();
        List<CM_ExcelSheetInfoDto> sheetInfoListBuf = new ArrayList<CM_ExcelSheetInfoDto>();
        myObj.setSheetInfoList(sheetInfoListBuf);
        for (CM_ExcelSheetInfoDto dtoObj : this.sheetInfoList) {
            CM_ExcelSheetInfoDto newObj = dtoObj.clone();
            sheetInfoListBuf.add(newObj);
        }
        return myObj;
    }
}
