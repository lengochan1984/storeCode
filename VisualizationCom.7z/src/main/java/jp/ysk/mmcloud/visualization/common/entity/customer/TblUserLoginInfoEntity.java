package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ユーザログイン情報
 * 
 */
@Entity
@Table(name = "tbl_user_login_info")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class TblUserLoginInfoEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** ユーザSID */
    @Id
    @Column(precision = 10, nullable = false, unique = true)
    public Integer userSid;

    /** パスワード入力ミス回数 : ・パスワード認証に失敗するたびに+1
・正常にログインできたら0にクリア
・パスワードが変更されたら0にクリア */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer passwdMissCount;

    /** 前回ログイン日時 */
    @Column(nullable = true, unique = false)
    public Timestamp lastLoginDatetime;

    /** 最終更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String lastUpdProg;

    /** 最終更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp lastUpdTim;
}
