/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/12/16| <20000-020> 変更仕様No.8           | 3.00.00| US)萩尾
 *  2015/08/18| <30003-061> 変更仕様No.34          | 3.01.00| US)萩尾
 *  2016/10/20| <C1.01> 検索条件出力対応           | C1.01  | US)萩尾
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.csv;

/**
 * CSV共通定数.<br>
 * <br>
 * 概要:<br>
 * CSV共通の定数クラスです
 * <br>
 */
public abstract class CM_Csv_Const {

    /**
     * 処理区分.
     */
    public static final String OPERATION_TYPE = "operationType";

    /**
     * バージョン.
     */
    public static final String VERSION = "version";

    /**
     * インポート可能なCSVファイルの最大サイズ.
     *
     */
    public static final int UPLOAD_CSV_FILE_MAX_SIZE = 1024 * 1024 * 5;

    /**
     * アップロード結果画面.
     */
    public static final String UPLOAD_RESULT_PAGE = "../common/com_csvuploadError.jsp";

    /**
     * インポート可能なCSVファイルの最大件数.
     */
    public static final int UPLOAD_CSV_FILE_MAX_LINE = 1000;

    /**
     * エリアキー:listArea.
     */
    public static final String AREA_KEY = "listArea";

    /**
     * エリアキー:infoArea.
     */
    public static final String AREA_KEY_INFO_AREA = "infoArea";

    /**
     * エリアキー:comSearchArea.
     */
    public static final String AREA_KEY_COM_SEARCH_AREA = "comSearchArea";

    /**
     * エリアキー:searchArea.
     */
    public static final String AREA_KEY_SEARCH_AREA = "searchArea";

    /**
     * コンバート処理用メソッド名共通部分定義.
     */
    public static final String COM_COMVERT_METHOD_NAME = "convertTo";

    /**
     * CSVマップデータキー(CSV取込で取り込む単位のCSVデータ用）.
     */
    public static final String CSV_MAP_KEY_BLOK_DATA = "csvBlockData";


    /**
     *
     * 処理区分定数.<br>
     * <br>
     * 概要:<br>
     * 処理区分の定数クラスです <br>
     */
    public abstract class OperationType {
        /**
         * INSERT : I.
         */
        public static final String INSERT = "I";

        /**
         * Update : U.
         */
        public static final String UPDATE = "U";
        /**
         * DELETE : D.
         */
        public static final String DELETE = "D";
    }

}
