package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ユーザ時計表示マスタ
 * 
 */
@Entity
@Table(name = "mst_user_clock_disp")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class MstUserClockDispEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** ユーザSID */
    @Id
    @Column(precision = 10, nullable = false, unique = false)
    public Integer userSid;

    /** 表示インデックス : 時計表示の位置。二番目、三番目のみ格納。（一番目はログインユーザのタイムゾーン用時計を表示）
 */
    @Id
    @Column(precision = 5, nullable = false, unique = false)
    public Short dispIndex;

    /** タイムゾーンCD : タイムゾーンを保持。
環境マスタの環境CD="timezone"とリンク。 */
    @Column(length = 64, nullable = false, unique = false)
    public String timezoneCd;

    /** 削除フラグ : true：有効、false：無効 */
    @Column(length = 1, nullable = false, unique = false)
    public Boolean deleteFlag;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
