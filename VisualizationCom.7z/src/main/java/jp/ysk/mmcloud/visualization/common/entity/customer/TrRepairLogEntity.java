package jp.ysk.mmcloud.visualization.common.entity.customer;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * リペアログ
 * 
 */
@Entity
@Table(name = "tr_repair_log")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2017/09/08 13:51:32")
public class TrRepairLogEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 登録日時 */
    @Column(nullable = true, unique = false)
    public Timestamp createdOn;

    /** 登録者 */
    @Column(length = 32, nullable = true, unique = false)
    public String createdBy;

    /** 更新日時 */
    @Column(nullable = true, unique = false)
    public Timestamp modifiedOn;

    /** 更新者 */
    @Column(length = 32, nullable = true, unique = false)
    public String modifiedBy;

    /** リペア番号 */
    @Id
    @Column(precision = 9, nullable = false, unique = true)
    public BigDecimal repairNo;

    /** 指図番号 */
    @Column(length = 12, nullable = true, unique = false)
    public String sasizuNo;

    /** 指図追番 */
    @Column(precision = 5, nullable = true, unique = false)
    public BigDecimal subNo;

    /** 作業順序 */
    @Column(length = 6, nullable = true, unique = false)
    public String sagyoSeq;

    /** 品目コード */
    @Column(length = 40, nullable = true, unique = false)
    public String buhinCd;

    /** 形式（品目テキスト） */
    @Column(length = 40, nullable = true, unique = false)
    public String katasiki;

    /** 製品シリアル番号 */
    @Column(length = 22, nullable = true, unique = false)
    public String seihinSn;

    /** リペア発生日時 */
    @Column(nullable = true, unique = false)
    public Timestamp occurTime;

    /** ラインID */
    @Column(precision = 8, nullable = true, unique = false)
    public BigDecimal lnId;

    /** ステーションID */
    @Column(precision = 8, nullable = true, unique = false)
    public BigDecimal stId;

    /** プラントコード */
    @Column(length = 10, nullable = true, unique = false)
    public String plantCd;

    /** 製造ラインコード */
    @Column(length = 10, nullable = true, unique = false)
    public String seizouLnCd;

    /** 製造ライン名 */
    @Column(length = 64, nullable = true, unique = false)
    public String seizouLnNm;

    /** 工程コード */
    @Column(length = 5, nullable = true, unique = false)
    public String processCd;

    /** 工程名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String processNm;

    /** ラインNo */
    @Column(length = 32, nullable = true, unique = false)
    public String lnNo;

    /** ライン名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String lnNm;

    /** ステーションNo */
    @Column(length = 8, nullable = true, unique = false)
    public String stNo;

    /** ステーション名称 */
    @Column(length = 64, nullable = true, unique = false)
    public String stNm;

    /** 作業区 */
    @Column(length = 8, nullable = true, unique = false)
    public String sagyoku;

    /** 設備識別ｺｰﾄﾞ */
    @Column(length = 10, nullable = true, unique = false)
    public String equipCd;

    /** アラームコード */
    @Column(length = 10, nullable = true, unique = false)
    public String almCd;

    /** リペア製品投入回数 */
    @Column(precision = 2, nullable = true, unique = false)
    public BigDecimal repairKaisu;

    /** 作業STEP */
    @Column(length = 8, nullable = true, unique = false)
    public String stepNo;

    /** 製品ロット番号 */
    @Column(length = 27, nullable = true, unique = false)
    public String seihinLn;

    /** 試験不具合現品番号 */
    @Column(length = 15, nullable = true, unique = false)
    public String testDefectNo;

    /** 試験日付 */
    @Column(length = 10, nullable = true, unique = false)
    public String testDate;

    /** 試験時刻 */
    @Column(length = 8, nullable = true, unique = false)
    public String testTime;

    /** 試験スペック名称 */
    @Column(length = 32, nullable = true, unique = false)
    public String testSpecName;

    /** 試験NGステップ番号 */
    @Column(length = 3, nullable = true, unique = false)
    public String testStepNo;

    /** 試験NGステップ名称 */
    @Column(length = 32, nullable = true, unique = false)
    public String testStepName;

    /** 試験データ（最小値） */
    @Column(length = 32, nullable = true, unique = false)
    public String testMinVal;

    /** 試験データ（最大値） */
    @Column(length = 32, nullable = true, unique = false)
    public String testMaxVal;

    /** 試験データ（測定値） */
    @Column(length = 32, nullable = true, unique = false)
    public String testDataVal;

    /** ユーザID */
    @Column(length = 16, nullable = true, unique = false)
    public String userId;

    /** リペアコメント */
    @Column(length = 128, nullable = true, unique = false)
    public String repairComment;

    /** 数字予備1 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum1;

    /** 数字予備2 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum2;

    /** 数字予備3 */
    @Column(precision = 12, nullable = true, unique = false)
    public BigDecimal spareNum3;

    /** 文字予備1 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText1;

    /** 文字予備2 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText2;

    /** 文字予備3 */
    @Column(length = 128, nullable = true, unique = false)
    public String spareText3;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;
}
