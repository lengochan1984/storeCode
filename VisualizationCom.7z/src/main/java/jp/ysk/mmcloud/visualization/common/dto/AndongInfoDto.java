package jp.ysk.mmcloud.visualization.common.dto;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import jp.ysk.mmcloud.common.util.CM_CommonUtil;

public class AndongInfoDto {

    /**
     * データ無し時表示文字.
     */
    private static final String NO_VALUE_LABEL = "―";

    /**
     * 正符号.
     */
    private static final String SIGN_PLUS = "+";

    /**
     * 予定数.
     */
    private Integer scheduleNum;

    /**
     * 実績数.
     */
    private Integer actualNum;

    /**
     * 計画数.
     */
    private Integer planNum;

    /**
     * 作業区前の滞留数.
     */
    private Integer preRetentionNum;

    /**
     * 滞留数.
     */
    private Integer retentionNum;

    /**
     * ライン内滞留数.
     */
    private Integer lineRetentionInside;

    /**
     * 完了時刻（予測）.
     */
    private Timestamp predictionCompletionTime = null;

    /**
     * 完了時刻（計画）.
     */
    private Timestamp planCompletionTime = null;

    /**
     * 計画数.
     * @return 計画数
     */
    public Integer getScheduleNum() {
        return this.scheduleNum;
    }

    /**
     * 計画数セット.
     * @param _value 計画数
     */
    public void setScheduleNum(final Integer _value) {
        this.scheduleNum = _value;
    }


    /**
     * 実績数.
     * @return 実績数
     */
    public Integer getActualNum() {
        return this.actualNum;
    }

    /**
     * 実績数セット.
     * @param _value 実績数
     */
    public void setActualNum(final Integer _value) {
        this.actualNum = _value;
    }


    /**
     * 計画数.
     * @return 計画数
     */
    public Integer getPlanNum() {
        return this.planNum;
    }

    /**
     * 計画数セット.
     * @param _value 計画数
     */
    public void setPlanNum(final Integer _value) {
        this.planNum = _value;
    }

    /**
     * ライン内滞留閾値(ラインマスタ).
     * @return ライン内滞留閾値
     */
    public Integer getLineRetentionInside() {
        return this.lineRetentionInside;
    }

    /**
     * ライン内滞留閾値(ラインマスタ)セット.
     * @param _value ライン内滞留閾値
     */
    public void setLineRetentionInside(final Integer _value) {
        this.lineRetentionInside = _value;
    }

    /**
     * 作業区前の滞留数.
     * @return 作業区前の滞留数
     */
    public Integer getPreRetentionNum() {
        return this.preRetentionNum;
    }

    /**
     * 作業区前の滞留数セット.
     * @param _value 作業区前の滞留数
     */
    public void setPreRetentionNum(final Integer _value) {
        this.preRetentionNum = _value;
    }

    /**
     * 作業区内の滞留数.
     * @return 作業区内の滞留数
     */
    public Integer getRetentionNum() {
        return this.retentionNum;
    }

    /**
     * 作業区内の滞留数セット.
     * @param _value 作業区内の滞留数
     */
    public void setRetentionNum(final Integer _value) {
        this.retentionNum = _value;
    }

    /**
     * 完了時刻(予測).
     * @return 完了時刻(予測)
     */
    public Timestamp getPredictionCompletionTime() {

        return this.predictionCompletionTime;
    }

    /**
     * 完了時刻(予測)セット.
     * @param _value 完了時刻(予測)セット
     */
    public void setPredictionCompletionTime(final Timestamp _value) {

        if (CM_CommonUtil.isNotNullOrBlank(_value)) {
            this.predictionCompletionTime = _value;
        }
    }

    /**
     * 完了時刻(計画).
     * @return 完了時刻(計画)
     */
    public Timestamp getPlanCompletionTime() {

        return this.planCompletionTime;
    }

    /**
     * 完了時刻(予測)セット.
     * @param _value 完了時刻(予測)セット
     */
    public void setPlanCompletionTime(final Timestamp _value) {

        if (CM_CommonUtil.isNotNullOrBlank(_value)) {
            this.planCompletionTime = _value;
        }
    }

    /**
     * 表示用ライン内滞留閾値.
     * @return 表示用ライン内滞留閾値
     */
    public String getLineRetentionInsideView() {

        return getViewValue(this.lineRetentionInside);
    }

    /**
     * 表示用作業区内の滞留数.
     * @return 表示用作業区内の滞留数
     */
    public String getRetentionNumView() {

        return getViewValue(this.retentionNum);
    }


    /**
     * 表示用実績数.
     * 概要:<br>
     * 予定数が存在する場合、実績値は最小値０で表示を行う.<br>
     * @return 表示用実績数
     */
    public String getActualNumView() {

        if (isExistScheduleNum()) {
            return getCalcratableValue(this.actualNum).toString();
        } else {
            return getViewValue(this.actualNum);
        }
    }

    /**
     * 表示用予定数.
     * @return 表示用予定数
     */
    public String getScheduleNumView() {

        return getViewValue(this.scheduleNum);
    }

    /**
     * 表示用計画数.
     * @return 表示用計画数
     */
    public String getPlanNumView() {

        return getViewValue(this.planNum);
    }

    /**
     * 表示用差分値取得.
     * 概要:<br>
     *
     * <br>
     * @return 表示用差分値
     */
    public String getDiffValueView() {

        if (isExistScheduleNum()) {
            Integer actual = 0;
            //予定あり
            if (isExistActualNum()) {
                actual = getCalcratableValue(this.actualNum);
            }
            return getSignedValueString(actual
                                            - getCalcratableValue(this.scheduleNum));

        } else {
            //予定なしは「－」
            return NO_VALUE_LABEL;
        }
    }

    /**
     * 表示用完了時刻(予測).
     * @return 表示用完了時刻(予測)
     */
    public String getPredictionCompletionTimeView() {

        if (CM_CommonUtil.isNotNullOrBlank(this.predictionCompletionTime)) {

            return new SimpleDateFormat("HH:mm").format(this.predictionCompletionTime);
        }

        return NO_VALUE_LABEL;
    }

    /**
     * 表示用完了時刻(計画).
     * @return 表示用完了時刻(計画)
     */
    public String getCompletionTimeView() {

        if (CM_CommonUtil.isNotNullOrBlank(this.planCompletionTime)) {

            return new SimpleDateFormat("HH:mm").format(this.planCompletionTime);
        }

        return NO_VALUE_LABEL;
    }


    /**
     * 表示用データ値取得.<br>
     * 概要:<br>
     * データ値(-1)は実績無しと判断し、"－"を返す.
     * @param _val 実績値
     * @return 表示用実績値
     */
    private String getViewValue(final Integer _val) {

        if (!isExistNumValue(_val)) {
            return NO_VALUE_LABEL;
        }

        return _val.toString();
    }

    /**
     * 計算用実績値取得.
     * @param _val 実績値
     * @return 計算用実績値
     */
    private Integer getCalcratableValue(final Integer _val) {

        if (!isExistNumValue(_val)) {
            return 0;
        }
        return _val;

    }

    /**
     * 符号表示.
     * @param _val 数値
     * @return 符号付数値文字列
     */
    private String getSignedValueString(final Integer _val) {

        if (_val < 0) {
            return _val.toString();
        } else {
            return SIGN_PLUS.concat(_val.toString());
        }
    }

    /**
     * 実績数に値が存在するか判断する.
     * @return True:実績数が存在する
     */
    private boolean isExistActualNum() {

        return isExistNumValue(this.actualNum);
    }

    /**
     * 予定数に値が存在するか判断する.
     * @return True:計画数が存在する
     */
    private boolean isExistScheduleNum() {

        return isExistNumValue(this.scheduleNum);
    }

    /**
     * 時間クリア処理.
     */
    public void clearTime() {
        this.predictionCompletionTime = null;
        this.planCompletionTime = null;
    }

    /**
     * データ有無判断.
     * <br>
     * 概要:<br>
     * Integer型データのデータ存在を判定する.<br>
     * nullまたは-1の場合、データ無しと判断する.<br>
     * @param _val 値
     * @return True:データ設定有り
     */
    private boolean isExistNumValue(final Integer _val) {

        return _val != null && _val != -1;
    }
}
