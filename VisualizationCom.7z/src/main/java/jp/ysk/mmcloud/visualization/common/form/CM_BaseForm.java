/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/07/20| <C1.01>　新規作成（共通化対応取込）                                  | C1.01  | US)萩尾
 *  2017/05/25| <C1.00>　C140100用の変数を追加する
 *  2017/06/09| <C1.02>　CSV出力にてSQL検索時にLIMITをつける対応                                  | C1.00  | YSK)ThanhDM
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.common.form;

import java.util.HashMap;
import java.util.Map;

import jp.ysk.fw.form.FW01_17_BaseForm;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.CM_A10_SearchPldTypeInfo;
import jp.ysk.mmcloud.visualization.common.CM_A11_SearchDateTypeInfo;

/**
*
* フォーム規定クラス.<br>
*<br>
* 概要:<br>
*   フォームクラスの最上位の親クラスで、フレームワークの共通処理を実装します
*<br>
*/
public class CM_BaseForm extends FW01_17_BaseForm {

    /**
     * 画面表示モード.
     */
    public static final String CM_HDN_PAGE_DISP_MODE = "hdnPageDispMode";

    /**
     * 表示件数.
     */
    public static final String FW0114FORM_LISTSIZE = "fw0114ListSize";

    /**
     * 現在ページ数.
     */
    public static final String FW0114FORM_PAGENO = "fw0114PageNo";

    /**
     * ソートキー.
     */
    public static final String FW0114FORM_SORTKEY = "fw0114SortKey";

    /**
     * ソート順.
     * A:ASC    D:DESC
     */
    public static final String FW0114FORM_SORTORDER = "fw0114SortOrder";

    /**
     * CSV最大出力件数.
     */
    public static final String FW0114FORM_CSVMAXSIZE = "fw0114CsvMaxSize";

    /**
     * 工場CD.
     */
    public static final String COM_PLANT_CODE = "comPlantCode";

    /**
     * ラインID.
     */
    public static final String LN_ID = "lnId";

    /**
     * 出力CSVタイプ.
     */
    public static final String HDN_DOWNLOAD_CSV_TYPE = "hdnDownloadCsvType";

    /**
     * 画面表示モード.
     */
    public String hdnPageDispMode = CM_A04_Const.PAGE_DISP_MODE.MODE_DISP;

    /**
     * (お気に入り)画面表示モード.
     */
    public String hdnFavoritePageDispMode = CM_A04_Const.PAGE_DISP_MODE.MODE_DISP;

    /**
     * 表示件数.
     */
    public String fw0114ListSize;

    /**
     * 現在ページ数.
     */
    public String fw0114PageNo;

    /**
     * ソートキー.
     */
    public String fw0114SortKey;

    /**
     * ソート順.
     * A:ASC    D:DESC
     */
    public String fw0114SortOrder;

    /**
     * 工場CD.
     */
    public String comPlantCode;

    /**
     * ラインID.
     */
    public String lnId;

    /**
     * 出力CSVタイプ.
     */
    public String hdnDownloadCsvType;

    /**
     * ログイン直後フラグ.
     */
    public static final String HDN_IS_LOGIN_FIRST_FLG = "hdnIsLoginFirstFlg";

    /**
     * ログイン直後フラグ.
     */
    public String hdnIsLoginFirstFlg;

    /**
     * お気に入り遷移番号.
     */
    public static final String HDN_FAVORITE_ACCESS_NO = "hdnFavoriteAccessNo";
    /**
     * お気に入り遷移番号.
     */
    public String hdnFavoriteAccessNo = null;

    /**
     * お気に入り番号.
     */
    public static final String HDN_FAVORITE_NO = "hdnFavoriteNo";
    /**
     * お気に入り番号.
     */
    public String hdnFavoriteNo;

    /**
     * お気に入り番号1.
     */
    public static final String HDN_FAVORITE_NO1 = "hdnFavoriteNo1";
    /**
     * お気に入り番号1.
     */
    public String hdnFavoriteNo1;

    /**
     * お気に入り番号2.
     */
    public static final String HDN_FAVORITE_NO2 = "hdnFavoriteNo2";
    /**
     * お気に入り番号2.
     */
    public String hdnFavoriteNo2;

    /**
     * お気に入り番号3.
     */
    public static final String HDN_FAVORITE_NO3 = "hdnFavoriteNo3";
    /**
     * お気に入り番号3.
     */
    public String hdnFavoriteNo3;

    /**
     * お気に入り番号4.
     */
    public static final String HDN_FAVORITE_NO4 = "hdnFavoriteNo4";
    /**
     * お気に入り番号4.
     */
    public String hdnFavoriteNo4;

    /**
     * お気に入り番号5.
     */
    public static final String HDN_FAVORITE_NO5 = "hdnFavoriteNo5";
    /**
     * お気に入り番号5.
     */
    public String hdnFavoriteNo5;

    /**
     * お気に入り番号4.
     */
    public static final String HDN_FAVORITE_NO6 = "hdnFavoriteNo6";
    /**
     * お気に入り番号6.
     */
    public String hdnFavoriteNo6;

    /**
     * お気に入り名称1.
     */
    public static final String HDN_FAVORITE_NAME1 = "hdnFavoriteName1";
    /**
     * お気に入り名称1.
     */
    public String hdnFavoriteName1;

    /**
     * お気に入り名称2.
     */
    public static final String HDN_FAVORITE_NAME2 = "hdnFavoriteName2";
    /**
     * お気に入り名称2.
     */
    public String hdnFavoriteName2;

    /**
     * お気に入り名称3.
     */
    public static final String HDN_FAVORITE_NAME3 = "hdnFavoriteName3";
    /**
     * お気に入り名称3.
     */
    public String hdnFavoriteName3;

    /**
     * お気に入り名称4.
     */
    public static final String HDN_FAVORITE_NAME4 = "hdnFavoriteName4";
    /**
     * お気に入り名称4.
     */
    public String hdnFavoriteName4;

    /**
     * お気に入り名称5.
     */
    public static final String HDN_FAVORITE_NAME5 = "hdnFavoriteName5";
    /**
     * お気に入り名称5.
     */
    public String hdnFavoriteName5;

    /**
     * お気に入り名称6.
     */
    public static final String HDN_FAVORITE_NAME6 = "hdnFavoriteName6";
    /**
     * お気に入り名称6.
     */
    public String hdnFavoriteName6;

    /**
     * リンクやブロックから遷移したフラグ.
     */
    public static final String HDN_LINK_JUMP = "hdnLinkJump";
    /**
     * リンクやブロックから遷移したフラグ.
     */
    public String hdnLinkJump;

    /**
     * 検索エリアオープン保持フラグ.
     */
    public static final String HDN_SEARCH_OPEN = "hdnSearchAreaOpen";
    /**
     * 検索エリアオープン保持フラグ.
     */
    public String hdnSearchAreaOpen;

    /**
     * アンドンエリアオープン保持フラグ.
     */
    public static final String HDN_ANDON_OPEN = "hdnAndonAreaOpen";
    /**
     * アンドンエリアオープン保持フラグ.
     */
    public String hdnAndonAreaOpen;

    /**
     * 処理実行フラグ.
     */
    public static final String HDN_PROCESS_EXEC_FLG = "hdnProcessExecFlg";
    /**
     * 処理実行フラグ.
     */
    public String hdnProcessExecFlg;

    /**
     * 工場開始日時.
     */
    public String plantStartDate = null;

    /**
     * 日付選択（CSV）（画面受け渡し用）..
     */
    public static final String COM_DATE_TYPE_CSV_DISP = "comDateTypeCsvDisp";
    /**
     * 日付選択（CSV）（画面受け渡し用）..
     */
    public String comDateTypeCsvDisp;

    /**
     * 日付検索条件From（CSV）（画面受け渡し用）.
     */
    public static final String COM_DATA_DATE_FROM_CSV_DISP = "comDataDateFromCsvDisp";
    /**
     * 日付検索条件From（CSV）（画面受け渡し用）.
     */
    public String comDataDateFromCsvDisp;

    /**
     * 日付検索条件To（CSV）（画面受け渡し用）.
     */
    public static final String COM_DATA_DATE_TO_CSV_DISP = "comDataDateToCsvDisp";
    /**
     * 日付検索条件To（CSV）（画面受け渡し用）.
     */
    public String comDataDateToCsvDisp;

    /**
     * 工場プルダウン変更前の工場コード.
     */
    public String hdnBeforePlantCode;

    /* ********************************************/
    // 共通検索項目
    /* ********************************************/
    /**
     * グループ(製造ラインID).
     */
    public static final String COM_SEIZOU_LN_ID = "comSeizouLnId";
    /**
     * グループ(製造ラインID).
     */
    public String comSeizouLnId;

    /**
     * 工程ID.
     */
    public static final String COM_PROCESS_ID = "comProcessId";
    /**
     * 工程ID.
     */
    public String comProcessId;

    /**
     * ラインID.
     */
    public static final String COM_LN_ID = "comLnId";
    /**
     * ラインID.
     */
    public String comLnId;

    /**
     * ステーションID.
     */
    public static final String COM_ST_ID = "comStId";
    /**
     * ステーションID.
     */
    public String comStId;

    /**
     * 日付選択（画面受け渡し用）.
     */
    public static final String COM_DATE_TYPE_DISP = "comDateTypeDisp";
    /**
     * 日付選択（画面受け渡し用）.
     */
    public String comDateTypeDisp;

    /**
     * 日付検索条件（画面受け渡し用）.
     */
    public static final String COM_DATA_DATE_DISP = "comDataDateDisp";
    /**
     * 日付検索条件（画面受け渡し用）.
     */
    public String comDataDateDisp;

    /**
     * 日付選択.
     */
    public static final String COM_DATE_TYPE = "comDateType";
    /**
     * 日付選択.
     */
    public String comDateType;

    /**
     * 日付検索条件（From）.
     */
    public static final String COM_DATA_DATE_FROM = "comDataDateFrom";
    /**
     * 日付検索条件（From）.
     */
    public String comDataDateFrom;

    /**
     * 日付検索条件（To）.
     */
    public static final String COM_DATA_DATE_TO = "comDataDateTo";
    /**
     * 日付検索条件（To）.
     */
    public String comDataDateTo;

    /**
     * 現在月度（画面受け渡し用）.
     */
    public static final String COM_CURRENT_YEAR_MONTH = "comCurrentYearMonth";
    /**
     * 現在月度（画面受け渡し用）.
     */
    public String comCurrentYearMonth;

//    /**
//     * 日付検索条件（From）.
//     */
//    public static final String COM_DATA_DATE_FROM_DISP = "comDataDateFromDisp";
//    /**
//     * 日付検索条件（From）.
//     */
//    public String comDataDateFromDisp;
//
//    /**
//     * 日付検索条件（To）.
//     */
//    public static final String COM_DATA_DATE_TO_DISP = "comDataDateToDisp";
//    /**
//     * 日付検索条件（To）.
//     */
//    public String comDataDateToDisp;

    /**
     * 日付検索条件（左／右ボタン）.
     */
    public static final String HDN_MOVE_DIRECTION = "hdnMoveDirection";
    /**
     * 日付検索条件（左／右ボタン）.
     */
    public String hdnMoveDirection;

    /**
     * 検索ワード.
     */
    public static final String COM_SEARCH_WORD = "comSearchWord";
    /**
     * 検索ワード.
     */
    public String comSearchWord;

    //C140100　ここから

    /**
     * CSV工場CD.
     */
    public static final String COM_PLANT_CODE_CSV = "comPlantCodeCSV";

    /**
     * CSV工場CD.
     */
    public String comPlantCodeCSV;

    /**
     * シリアル番号.
     */
    public static final String SERIAL_NUMBER = "serialNumber";
    /**
     * シリアル番号.
     */
    public String serialNumber;

    /**
     * CSVシリアル番号.
     */
    public static final String SERIAL_NUMBER_CSV = "serialNumberCSV";
    /**
     * CSVシリアル番号.
     */
    public String serialNumberCSV;

    /**
     * ライン番号.
     */
    public static final String LINE_NUMBER = "lineNo";
    /**
     * ライン番号.
     */
    public String lineNo;

    /**
     * ステージョン番号.
     */
    public static final String STATION_NUMBER = "stationNo";
    /**
     * ステージョン番号.
     */
    public String stationNo;

    //C140100 ここまで

    /**
     * ユーザタイムゾーン.
     */
    public static final String HDN_TIME_ZONE = "hdnTimeZone";
    /**
     * 検索ワード.
     */
    public String hdnTimeZone;

    /**
     * 共通検索　日時定義.
     */
    public static final String COM_SEARCH_DATE_TYPE = "comSearchDateType";

    /**
     * 共通検索プルダウン定義取得.<br>
     * ※共通検索機能を使用する場合、<br>
     * 　このメソッドをオーバーライドして実装して下さい。
     * @return 共通検索プルダウン定義
     */
    public CM_A10_SearchPldTypeInfo getComSearchPldType() {
        return null;
    }

    /**
     * 共通検索　日時定義取得.<br>
     * ※共通検索機能を使用する場合、<br>
     * 　このメソッドをオーバーライドして実装して下さい。
     * @return 共通検索日時定義
     */
    public CM_A11_SearchDateTypeInfo getComSearchDateType() {
        return null;
    }

    /**
     * 共通検索プルダウン定義が等しいかどうかを判定.
     * @param _searchPldTypeInfo 判定対象共通検索プルダウン定義
     */
    public boolean isSameSearchPldTypeInfo(final CM_A10_SearchPldTypeInfo _searchPldTypeInfo) {
        CM_A10_SearchPldTypeInfo mySearchPldTypeInfo = getComSearchPldType();
        if (mySearchPldTypeInfo == null) {
            return false;
        }
        boolean check = true;
        if (!mySearchPldTypeInfo.comSeizouLnIdType.equals(_searchPldTypeInfo.comSeizouLnIdType)
                || !mySearchPldTypeInfo.comProcessIdType.equals(_searchPldTypeInfo.comProcessIdType)
                || !mySearchPldTypeInfo.comLnIdType.equals(_searchPldTypeInfo.comLnIdType)
                || !mySearchPldTypeInfo.comStIdType.equals(_searchPldTypeInfo.comStIdType)) {
            check = false;
        }
        return check;
    }

    /* ********************************************/
    // 画面遷移用項目
    /* ********************************************/
    /**
     * 次画面ページID定義.
     */
    public static final String FW0114FORM_HDN_NEXT_PAGE_ID = "hdnNextPageId";
    /**
     * 次画面ページID.
     */
    public String hdnNextPageId;

    /**
     * 画面遷移フラグ.<br>
     */
    public static final String CM_LISTFORM_HDN_TRANSFER_FLAG = "hdnTransferFlag";
    /**
     * 画面遷移フラグ.
     */
    public String hdnTransferFlag;

    /**
     * リダイレクト用パラメータ.
     */
    public static final String HDN_REDIRECT_PARAM_MAP = "hdnRedirectParamMap";
    /**
     * リダイレクト用パラメータ.
     */
    public Map<String, String> hdnRedirectParamMap = new HashMap<String, String>();
}
