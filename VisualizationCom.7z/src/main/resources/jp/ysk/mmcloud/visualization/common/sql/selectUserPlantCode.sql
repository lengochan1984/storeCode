WITH allPlantCodeTable AS (
	SELECT
		plant_cd
	FROM
		ma_plant
	WHERE
		invalid_flag = 0
)

SELECT
	CASE WHEN COALESCE(ma_user.plant_cd, 'D0') = '##' THEN
		allPlantCodeTable.plant_cd
	ELSE
		COALESCE(ma_user.plant_cd, 'D0')
	END as plantCode
FROM
	mst_user
LEFT JOIN
	ma_user
ON
		mst_user.sid = ma_user.user_sid
	AND	ma_user.invalid_flag = 0
, allPlantCodeTable
WHERE
	mst_user.id = RTRIM(/*id*/'')
GROUP BY
	plantCode
ORDER BY
	plantCode
LIMIT 1
