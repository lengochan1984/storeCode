SELECT
--    case when A.single_line_flag = 1 then '-  ' || A.line_group_name
--    else A.line_group_name
--    end AS line_group_name
--FROM tbl_line_group_pulldown A
A.ln_nm AS ln_nm
FROM ma_line A
INNER JOIN ma_process B
        ON A.process_id = B.process_id
INNER JOIN ma_seizou_line C
    ON B.seizou_ln_id = C.seizou_ln_id
WHERE C.plant_cd = /*plantCd*/
AND A.ln_id = /*lnId*/1





