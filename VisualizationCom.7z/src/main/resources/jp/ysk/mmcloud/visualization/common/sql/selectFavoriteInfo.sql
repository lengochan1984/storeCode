SELECT
	param_name,
	param_value
FROM
	tr_search_condition
WHERE
		user_sid = /*userSid*/
	AND favorite_no = /*favoriteNo*/
ORDER BY
	condition_num
