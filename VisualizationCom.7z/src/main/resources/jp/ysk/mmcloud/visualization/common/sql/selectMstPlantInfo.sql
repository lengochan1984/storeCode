SELECT
    COALESCE(ma_plant.plant_s_nm, ma_plant.plant_cd) AS plant_nm,
    ma_plant.plant_cd

FROM
/*IF userSid != null */
    ma_user
LEFT JOIN
/*END*/
    ma_plant
/*IF userSid != null */
ON
    ma_plant.plant_cd = ma_user.plant_cd
    OR ma_user.plant_cd = /*allBaseAuth*/'##'
/*END*/

/*BEGIN*/
WHERE
    /*IF isPhysical == false */
    ma_plant.invalid_flag = 0
    /*END*/
    /*IF userSid != null */
    AND ma_user.invalid_flag = 0
    AND ma_user.user_sid = /*userSid*/
    /*END*/
/*END*/

GROUP BY
    ma_plant.invalid_flag,
    ma_plant.plant_cd,
    plant_nm

ORDER BY
/*IF isPhysical == false */
    ma_plant.plant_cd
 --ELSE
    ma_plant.invalid_flag,
    ma_plant.plant_cd
/*END*/
