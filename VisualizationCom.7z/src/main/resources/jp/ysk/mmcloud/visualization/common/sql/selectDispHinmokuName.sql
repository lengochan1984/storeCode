SELECT product_name
FROM (
        SELECT
            vtext_info1 AS product_name,
            '0@' || vtext_info1 AS product_id,
            MIN(invalid_flag) as invalid
        FROM ma_hinmoku
        WHERE
            werks = /*werks*/
        AND TRIM(vtext_info1) IS NOT NULL
        GROUP BY vtext_info1, werks
    UNION
        SELECT
            '-  ' || vtext_info2 AS product_name,
            '1@' || vtext_info2 AS product_id,
            MIN(invalid_flag) as invalid
        FROM ma_hinmoku
        WHERE
            werks = /*werks*/
        AND TRIM(vtext_info2) IS NOT NULL
        GROUP BY vtext_info2, werks
) ma_hinmoku
WHERE
    product_id = /*productId*/
