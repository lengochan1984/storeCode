SELECT A.ln_nm AS ln_nm,
       A.ln_id AS ln_id
FROM ma_line A
INNER JOIN ma_process B
        ON A.process_id = B.process_id
INNER JOIN ma_seizou_line C
    ON B.seizou_ln_id = C.seizou_ln_id
WHERE C.plant_cd = /*plant_code*/
      AND C.seizou_ln_id = cast(/*seizou_ln_id*/1 as numeric)
/*IF process_id != null */
    AND B.process_id = /*process_id*/1
/*END*/
/*IF ln_id != null */
    AND A.ln_id = /*ln_id*/1
/*END*/
--ORDER BY  A.ln_nm
   ORDER BY ln_nm
