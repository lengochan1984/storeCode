SELECT
    EXTRACT(EPOCH FROM now() - max(tr_equip_sts.upd_tim)) * 1000 AS connect_mesdb_tim
FROM
    tr_equip_sts
INNER JOIN ma_equip
-- ON tr_equip_sts.st_id = ma_equip.st_id
ON tr_equip_sts.main_res_no = ma_equip.main_res_no
AND tr_equip_sts.plant_cd = ma_equip.plant_cd
WHERE
    tr_equip_sts.plant_cd	= /*comPlantCode*/''
GROUP BY
	tr_equip_sts.plant_cd
