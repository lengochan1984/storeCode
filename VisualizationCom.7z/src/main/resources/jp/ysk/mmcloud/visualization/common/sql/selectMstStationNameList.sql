SELECT DISTINCT
    ma_station.st_id,
    ma_station.st_nm
FROM
    ma_station
INNER JOIN
    ma_line
ON
    ma_line.ln_id = ma_station.ln_id
INNER JOIN
    ma_process
ON
    ma_process.process_id = ma_line.process_id
INNER JOIN
    ma_seizou_line
ON
    ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id

WHERE
    ma_station.invalid_flag = 0
    AND ma_seizou_line.plant_cd = /*plant_code*/
/*IF seizouLineId != null */
    AND ma_seizou_line.seizou_ln_id = /*seizouLineId*/
/*END*/
/*IF processId != null */
    AND ma_process.process_id = /*processId*/
/*END*/
/*IF lnId != null */
    AND ma_line.ln_id = /*lnId*/
/*END*/

ORDER BY
    ma_station.st_nm ASC
