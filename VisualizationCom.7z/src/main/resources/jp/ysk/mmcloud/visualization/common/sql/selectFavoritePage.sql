SELECT
    tr_search_condition.favorite_no
    ,tr_search_condition.page_id
    ,tr_search_condition.favorite_name
FROM
    tr_search_condition
WHERE
    tr_search_condition.user_sid = /*userSid*/
    AND tr_search_condition.favorite_no >= 0
/*IF favoriteNo != null */
    AND tr_search_condition.favorite_no = /*favoriteNo*/
/*END*/
GROUP BY tr_search_condition.favorite_no, tr_search_condition.page_id, tr_search_condition.favorite_name
ORDER BY tr_search_condition.favorite_no ASC
