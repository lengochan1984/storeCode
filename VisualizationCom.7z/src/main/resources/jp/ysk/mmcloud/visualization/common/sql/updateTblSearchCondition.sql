UPDATE
    tr_search_condition

SET
    favorite_name = /*favoriteName*/,
    upd_prog = /*updProg*/,
    upd_tim = /*updTim*/,
    upd_user_sid = /*updUserSid*/

WHERE
    user_sid = /*userSid*/
AND favorite_no = /*favoriteNo*/
