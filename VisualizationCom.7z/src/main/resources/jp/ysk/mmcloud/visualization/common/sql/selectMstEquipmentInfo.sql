SELECT
    mse.equip_cd,
    mse.main_res_no

FROM
    ma_equip mse

/*IF lnId != null*/
INNER JOIN
    (
    SELECT
        ma_seizou_line.plant_cd,
        ma_station.st_id

    FROM
        ma_seizou_line
    INNER JOIN ma_process
        ON ma_process.seizou_ln_id = ma_seizou_line.seizou_ln_id
    INNER JOIN ma_line
        ON ma_line.process_id = ma_process.process_id
    INNER JOIN ma_station
        ON ma_station.ln_id = ma_line.ln_id

    WHERE
        ma_seizou_line.plant_cd = /*plantCode*/''
        AND ma_line.ln_id = /*lnId*/''
        AND ma_line.invalid_flag = 0
    ) AS lg

ON
    mse.plant_cd = lg.plant_cd
    AND mse.st_id = lg.st_id
/*END*/

WHERE
    mse.plant_cd = /*plantCode*/''
 and mse.main_res_no is not null
 and mse.main_res_no != ''