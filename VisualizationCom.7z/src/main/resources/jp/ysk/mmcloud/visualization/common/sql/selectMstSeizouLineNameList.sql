SELECT
    ma_seizou_line.seizou_ln_id,
	 ma_seizou_line.seizou_ln_nm
FROM
    ma_seizou_line
INNER JOIN
    ma_process
ON
    ma_process.seizou_ln_id = ma_seizou_line.seizou_ln_id
INNER JOIN
    ma_line
ON
        ma_line.process_id = ma_process.process_id
INNER JOIN
    ma_station
ON
        ma_line.ln_id = ma_station.ln_id
WHERE
        ma_seizou_line.plant_cd = ?
GROUP BY
    ma_seizou_line.seizou_ln_id,
    ma_seizou_line.seizou_ln_nm
ORDER BY
    ma_seizou_line.seizou_ln_id ASC
