SELECT A.ln_id,
       A.ln_nm
FROM ma_line A
INNER JOIN ma_process B
        ON A.process_id = B.process_id
INNER JOIN ma_seizou_line
    ON B.seizou_ln_id = ma_seizou_line.seizou_ln_id
WHERE ma_seizou_line.plant_cd = /*plant_code*/
/*IF seizou_ln_id != null */
        AND ma_seizou_line.seizou_ln_id = cast(/*seizou_ln_id*/1 as numeric)
/*END*/
/*IF process_id != null */
    AND B.process_id = cast(/*process_id*/1 as numeric)
/*END*/
ORDER BY  A.ln_nm
