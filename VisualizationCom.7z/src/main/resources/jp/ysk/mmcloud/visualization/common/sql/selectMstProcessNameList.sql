SELECT
    ma_process.process_id,
    ma_process.process_nm
FROM
    ma_process
INNER JOIN ma_seizou_line
    ON ma_process.seizou_ln_id = ma_seizou_line.seizou_ln_id
INNER JOIN
    ma_line
ON
        ma_line.process_id = ma_process.process_id
INNER JOIN
    ma_station
ON
    ma_line.ln_id = ma_station.ln_id
WHERE
        ma_seizou_line.plant_cd = /*plant_code*/
/*IF seizouLnId != null*/
    AND ma_seizou_line.seizou_ln_id = cast(/*seizouLnId*/1 as numeric)
/*END*/
GROUP BY
    ma_process.process_id,
    ma_process.process_nm
ORDER BY
    ma_process.process_id ASC
