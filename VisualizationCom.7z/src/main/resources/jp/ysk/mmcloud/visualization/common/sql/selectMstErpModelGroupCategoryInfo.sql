select kishu_name,
        kishu_ctgr
from (
     select kishu_name,
          ('02' || ':' || kishu_ctgr) as kishu_ctgr,
          10 as category_no

      from mst_erp_model_group_category_02

      where plant_code = /*comPlantCode*/''
          and invalid_flag = 0

    union

    select '----------------------------------------',
          ('00' || ':' || 'XX') as kishu_ctgr,
          19 as category_no

    union

  select kishu_name,
          ('01' || ':' || kishu_ctgr) as kishu_ctgr,
          20 as category_no

    from mst_erp_model_group_category_01
    where plant_code = /*comPlantCode*/''
          and invalid_flag = 0

) tem

order by category_no, kishu_ctgr asc