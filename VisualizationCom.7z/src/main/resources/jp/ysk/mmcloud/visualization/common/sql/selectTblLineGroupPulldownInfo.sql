SELECT A.ln_nm AS line_group_name,
       A.ln_id AS ln_id
FROM ma_line A
INNER JOIN ma_process B
        ON A.process_id = B.process_id
INNER JOIN ma_seizou_line C
    ON B.seizou_ln_id = C.seizou_ln_id
WHERE C.plant_cd = /*plant_code*/
   ORDER BY line_group_name
