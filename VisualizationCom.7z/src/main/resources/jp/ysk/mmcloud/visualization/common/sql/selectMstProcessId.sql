SELECT
    ma_process.process_id
FROM
    ma_line
INNER JOIN
    ma_station
ON
    ma_line.ln_id = ma_station.ln_id
INNER JOIN
	ma_process
ON
	ma_line.process_id = ma_process.process_id
INNER JOIN
	ma_seizou_line
ON
	ma_process.seizou_ln_id = ma_seizou_line.seizou_ln_id
WHERE
        ma_seizou_line.plant_cd		= /*plant_code*/'D0'
    AND ma_seizou_line.seizou_ln_id	= /*seizouLnId*/1
/*IF lnId != null */
    AND ma_line.ln_id = /*lnId*/1
/*END*/
GROUP BY
    ma_process.process_id
ORDER BY
    ma_process.process_id
