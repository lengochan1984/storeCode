SELECT
    SUM(
        CASE A.schedule_num
            WHEN -1 THEN null
            ELSE A.schedule_num
        END ) AS schedule_num
    , SUM(
        CASE A.actual_num
            WHEN -1 THEN null
            ELSE A.actual_num
        END ) AS actual_num
    , SUM(
        CASE A.plan_num
            WHEN -1 THEN null
            ELSE A.plan_num
        END ) AS plan_num
    , SUM(
        CASE A.pre_retention_num
            WHEN -1 THEN null
            ELSE A.pre_retention_num
        END ) AS pre_retention_num
    , SUM(
        CASE A.retention_num
            WHEN -1 THEN null
            ELSE A.retention_num
        END ) AS retention_num
    /*IF comLineNo != null*/
    , SUM(
        CASE B.stay_inside_th
            WHEN -1 THEN null
            ELSE B.stay_inside_th
        END ) AS stay_inside_th
    --ELSE
    , null AS stay_inside_th
    /*END*/
    , MAX(A.prediction_completion_time) AS prediction_completion_time
    , MAX(A.plan_completion_time) AS plan_completion_time
FROM
    ag_line_work_current A
    /*IF comLineNo != null*/
    INNER JOIN ma_line B
    ON (
        B.invalid_flag = 0
        AND
        A.ln_id = B.ln_id
    )
    INNER JOIN ma_process
        ON B.process_id = ma_process.process_id
    INNER JOIN ma_seizou_line D
    ON (
        D.invalid_flag = 0
        AND
        ma_process.seizou_ln_id = D.seizou_ln_id
    )
    WHERE
        D.plant_cd = /*comPlantCode*/'S'
        AND
        D.seizou_ln_id = /*comSeizouLnId*/'S'
        AND
        B.ln_id = /*comLnId*/
        /*END*/
    --ELSE
    --AND
    --B.ln_no = '-1'

