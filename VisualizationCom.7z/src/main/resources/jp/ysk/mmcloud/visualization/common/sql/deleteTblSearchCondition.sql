DELETE FROM
    tr_search_condition
WHERE
    user_sid = /*userSid*/
AND
    favorite_no = /*favoriteNo*/
