SELECT
    tkn_file_name
FROM
    mst_work_step_tkn
GROUP BY tkn_file_name
ORDER BY tkn_file_name
