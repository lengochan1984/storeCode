SELECT A.ln_nm, A.ln_id AS ln_id
FROM ma_line A
INNER JOIN ma_process
        ON A.process_id = ma_process.process_id
INNER JOIN ma_seizou_line
    ON ma_process.seizou_ln_id = ma_seizou_line.seizou_ln_id
WHERE ma_seizou_line.plant_cd = /*plant_code*/
ORDER BY  A.ln_nm