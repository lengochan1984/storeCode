select
    vtext_info1
from (
    select
        vtext_info1 as vtext_info1,
        '0@' || vtext_info1 as plant_cd,
        min(invalid_flag) as invalid
    from
        ma_hinmoku
    where
            werks =  /*plantCd*/
        and trim(vtext_info1) is not null
        and trim(vtext_info1) <> '(no name)'
        and matnr in (
				 select
                    ma_mes_proc_man.buhin_cd
                from
                    ma_mes_proc_man
                inner join
                    ma_mes_work_step
                on
                    ma_mes_work_step.proc_man_id = ma_mes_proc_man.proc_man_id
                where
                        substring(job_ptn_name, 12, 2) = /*plantCd*/
                group by
                    ma_mes_proc_man.buhin_cd
        )
    group by
        vtext_info1,
        plant_cd
		
		
		union

    select
        '-  ' || vtext_info2 as vtext_info1,
        '1@' || vtext_info2 as plant_cd ,
        min(invalid_flag) as invalid
    from
        ma_hinmoku
    where
            werks = /*plantCd*/
        and trim(vtext_info2) is not null
        and trim(vtext_info2) <> '(no name)'
        and matnr in (
                select
                    ma_mes_proc_man.buhin_cd
                from
                    ma_mes_proc_man
                inner join
                    ma_mes_work_step
                on
                    ma_mes_work_step.proc_man_id = ma_mes_proc_man.proc_man_id
                where
                        substring(job_ptn_name, 12, 2) = /*plantCd*/
                group by
                    ma_mes_proc_man.buhin_cd
        )
    group by
        vtext_info2,
        plant_cd

) ma_hinmoku

order by
    invalid,
    plant_cd
