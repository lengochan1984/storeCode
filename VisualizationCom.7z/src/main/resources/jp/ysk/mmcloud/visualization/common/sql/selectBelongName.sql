SELECT
    TBL.belong_name AS belong_name
FROM
    (
        SELECT
            belong_name
        FROM
            ma_user
        WHERE
            RTRIM(ma_user.user_id) = /*id*/
        AND invalid_flag = '0'
        AND
        (
            ma_user.plant_cd = /*plantCd*/
        OR  ma_user.plant_cd = '##'
        )
        ORDER BY plant_cd ASC
    )TBL
OFFSET 0 LIMIT 1
