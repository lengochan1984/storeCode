SELECT
    vtext_info2,
    job_ptn_id,
    step_no,
    data_date,
    seizou_ln_cd,
    seizou_ln_nm,
    process_cd,
    process_nm,
    ln_no,
    ln_nm,
    job_ptn_name,
    standard_manhour,
    work_manhour_average,
    standard_deviation,
    parameter,
    ins_prog,
    ins_tim,
    ins_user_sid,
    upd_prog,
    upd_tim,
    upd_user_sid

FROM
    ag_work_manhour_mng_s_daily

/*BEGIN*/
WHERE
    /*IF addDatetime != null*/
        (ins_tim >= /*addDatetime*/ AND upd_tim is null)
    OR  upd_tim >= /*addDatetime*/
    /*END*/
/*END*/

ORDER BY
    COALESCE(upd_tim, ins_tim)
