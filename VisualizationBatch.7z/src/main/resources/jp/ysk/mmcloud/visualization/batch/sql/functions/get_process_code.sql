﻿--CREATE OR REPLACE FUNCTION get_process_code(
--    character,
--    character)
  CREATE OR REPLACE FUNCTION get_process_code(
  --  character,
    varchar)
  RETURNS character AS
$BODY$
SELECT
	ma_process.process_cd
FROM
	ma_process
INNER JOIN
	ma_line
ON
	--ma_process.plant_code = ma_line.plant_code
	ma_process.process_id = ma_line.process_id
--AND
	--ma_process.process_code = ma_line.process_code
--INNER JOIN
	--ma_line_group
--ON
	--ma_line_group.plant_code = ma_line.plant_code
--AND
	--ma_line_group.line_no = ma_line.line_no
WHERE
--		ma_process.process_no =
--		(
--			SELECT
--				MIN(ma_process.process_no) process_no
--			FROM
--				(
--				SELECT
--					ma_line_group.line_group_no,
--					ma_line_group.line_no,
--					ma_line_group.plant_code
-- 				FROM
--  					ma_line_group
--  				WHERE
-- 					ma_line_group.plant_code = ($1)
-- 				AND
-- 					ma_line_group.line_group_no = ($2)
-- 				) line_group_info
-- 			INNER JOIN
-- 				ma_line
-- 			ON
-- 				line_group_info.plant_code = ma_line.plant_code
-- 			AND
-- 				line_group_info.line_no = ma_line.line_no
-- 			INNER JOIN
-- 				ma_process
-- 			ON
-- 				ma_line.plant_code = ma_process.plant_code
-- 			AND
-- 				ma_line.process_code = ma_process.process_code
-- 			GROUP BY line_group_info.line_group_no
-- 		)
		ma_line.ln_no = ($1)
$BODY$
  LANGUAGE sql;
