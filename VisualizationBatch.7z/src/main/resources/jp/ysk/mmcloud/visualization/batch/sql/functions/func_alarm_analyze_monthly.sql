﻿CREATE or REPLACE FUNCTION func_alarm_analyze_monthly(
	in	i_batch_name	varchar,			-- バッチ処理名称
	in	i_log_type		numeric,			-- ログ種別(開始、および　各バッチ処理の復帰値)
											-- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
	in	i_user_sid		numeric,			-- 登録ユーザSID
	in	i_from_time		timestamp,			-- 集計開始日時(日単位)
	in	i_to_time		timestamp,			-- 集計終了日時(日単位)
	out	o_ret_cd		int,				-- 関数復帰値	RET_OK(= 0):正常終了
	out	o_sqlerr		varchar,			-- ＤＢ異常発生時のエラーコード
	out	o_errmsg		varchar,			-- 異常発生時のエラーメッセージ
	out	o_errpnt		varchar				-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　不具合解析(月別)作成サービス
--　ソースプログラム名　：　func_alarm_analyze_monthly.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　不具合解析(月別)を作成する
--
--　履歴
--  Ver.  作成日			作成者		COMMENT
--  1.0   2016/12/16	H.Nakamura	新規作成
--  1.2   2017/08/01	ThanhDM		DB変更対応
--******************************************************************************
DECLARE
	----------------------------------------------------------------------------
	--						標準定数定義
	----------------------------------------------------------------------------
	-- 戻り値
	RET_OK		CONSTANT int := 0 ;						-- 正常終了コード
	RET_NG		CONSTANT int := -1 ;					-- 異常終了コード
	-- 真偽値
	CST_TRUE	CONSTANT int := 1 ;						-- 真
	CST_FALSE	CONSTANT int := 0 ;						-- 偽

	----------------------------------------------------------------------------
	--						標準変数定義
	----------------------------------------------------------------------------
	cst_MY_PRG	CONSTANT CHAR(32)	 := 'func_alarm_analyze_monthly';		-- プログラム名
	cst_UPD_TIM	CHAR(17) ;													-- 更新時間
	l_err_pnt	CHAR(64) ;													-- エラー発生ポイント
	errbuff		varchar(256);												-- メッセージバッファ

	----------------------------------------------------------------------------
	--						定数定義
	----------------------------------------------------------------------------
	CST_SAGYO_MODE_LOW		CONSTANT int := 1;				-- 作業モード：作業者レベル低
	CST_SAGYO_MODE_MIDDLE	CONSTANT int := 2;				-- 作業モード：作業者レベル中
	CST_SAGYO_MODE_HIGH		CONSTANT int := 3;				-- 作業モード：作業者レベル高
	CST_SAGYO_MODE_E_LOW	CONSTANT int := 4;				-- 作業モード：設備レベル低
	CST_SAGYO_MODE_E_MIDDLE	CONSTANT int := 5;				-- 作業モード：設備レベル中
	CST_SAGYO_MODE_E_HIGH	CONSTANT int := 6;				-- 作業モード：設備レベル高

	----------------------------------------------------------------------------
	--						変数定義
	----------------------------------------------------------------------------
	-- 共通変数
	rtn_sql_no		text;							-- DBエラー情報(エラー番号)
	rtn_sql_msg		text;							-- DBエラー情報(エラーメッセージ)
	rtn_sql_detail	text;							-- DBエラー情報(エラー詳細)
	rtn_sql_hint	text;							-- DBエラー情報(エラーヒント)
	rtn_sql_stack	text;							-- DBエラー情報(エラー発生呼出しスタック)

	-- ローカル変数
	l_exec_datetime				timestamp;			-- 関数実行日時
	l_proc_start_time			timestamp;			-- 処理開始日
	l_proc_end_time				timestamp;			-- 処理終了日
	l_proc_start_time_all		timestamp;			-- 処理開始日(全体)
	l_proc_end_time_all			timestamp;			-- 処理終了日(全体)
	l_running_start_datetime	timestamp;			-- 稼働開始日時(年度開始日時)

	l_st_id						numeric(8)	; 		-- ステーションID
	l_alm_cd					varchar(10)	; 		-- アラームコード
	l_data_date					timestamp	; 		-- データ日時
	l_plant_cd					varchar(10)	; 		-- プラントコード
	l_plant_cd_wk				char(10);			-- 工場コード
	l_seizou_ln_cd				varchar(10)	; 		-- 製造ラインコード
	l_seizou_ln_nm				varchar(64)	; 		-- 製造ライン名
	l_process_cd				char(5); 			-- 工程コード
	l_process_nm				varchar(64)	; 		-- 工程名称
	l_ln_no						varchar(32)	; 		-- ラインNo
	l_ln_nm						varchar(64)	; 		-- ライン名称
	l_st_no						varchar(8)	; 		-- ステーションNo
	l_st_nm						varchar(64)	; 		-- ステーション名称
	l_main_res_no				varchar(12)	; 		-- メインリソース番号
	l_main_res_nm				varchar(256);		-- メインリソース名称
	l_sagyoku					char(8); 			-- 作業区
	l_occur_count				int; 				-- 発生回数
	l_last_occur_datetime		timestamp; 			-- 最終発生時刻
	l_recovery_time				int;				-- 復旧時間

	----------------------------------------------------------------------------
	--						カーソル定義
	----------------------------------------------------------------------------
	-- 工場マスタ
	CUR_MA_PLANT	CURSOR FOR
		SELECT
			PLANT_CD				as plantCd,
			RUNNING_START_DATETIME	as runningStartDatetime
		FROM
			MA_PLANT
		WHERE
			INVALID_FLAG = 0
		ORDER BY
			PLANT_CD
	;

	OPENFLG_MA_PLANT	int;	-- カーソルオープン状態

	-- 不具合解析(日別)
	CUR_AG_ALARM_ANALIZE_DAILY	CURSOR FOR
		SELECT
			MAX(PLANT_CD)		as plantCd,
			MAX(LN_NO)			as lnNo,
			MAX(LN_NM)			as lnNm,
			MAX(SEIZOU_LN_CD)	as seizouLnCd,
			MAX(SEIZOU_LN_NM)	as seizouLnNm,
			MAX(PROCESS_CD)		as processCd,
			MAX(PROCESS_NM)		as processNm,
			ST_ID				as stId,
			MAX(ST_NO)			as stNo,
			MAX(ST_NM)			as stNm,
			ALM_CD				as almCd,
			MAX(MAIN_RES_NM)	as mainResNm,
			MAX(MAIN_RES_NO),
			SUM(OCCUR_COUNT),
			MAX(LAST_OCCUR_DATETIME),
			SUM(RECOVERY_TIME),
			MAX(SAGYOKU)
		FROM
			AG_ALARM_ANALIZE_DAILY
		WHERE
				PLANT_CD	=	l_plant_cd_wk
			AND	DATA_DATE	>=	l_proc_start_time
			AND	DATA_DATE	<=	l_proc_end_time
		GROUP BY
			ST_ID,
			ALM_CD
	;

	OPENFLG_AG_ALARM_ANALIZE_DAILY		int;	-- カーソルオープン状態

	-- 不具合解析(月別)
	CUR_AG_ALARM_ANALIZE_MONTHLY	CURSOR FOR
		SELECT
			*
		FROM
			AG_ALARM_ANALIZE_MONTHLY
		WHERE
				ST_ID				= l_st_id
			AND	ALM_CD				= l_alm_cd
			AND	DATA_DATE			= l_proc_start_time
		FOR UPDATE NOWAIT
	;

	OPENFLG_AG_ALARM_ANALIZE_MONTHLY		int;	-- カーソルオープン状態
	REC_AG_ALARM_ANALIZE_MONTHLY			AG_ALARM_ANALIZE_MONTHLY%ROWTYPE;

BEGIN
	----------------------------------------------------------------------------
	--						初期処理
	----------------------------------------------------------------------------
	raise info 'Start Function [%]', clock_timestamp()::timestamp;

	-- 共通変数初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S001';

	-- 共通出力パラメータ初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
	o_ret_cd	:= RET_OK;
	o_sqlerr	:= ' ';
	o_errmsg	:= ' ';
	o_errpnt	:= ' ';

	-- 関数実行日時
	l_exec_datetime := clock_timestamp();

	-- 集計開始/終了日時補正
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
	IF i_from_time IS NULL THEN
		i_from_time := l_exec_datetime;
	END IF;
	IF i_to_time IS NULL OR i_from_time > i_to_time THEN
		i_to_time := l_exec_datetime;
	END IF;

	-- カーソルオープン状態初期化
	OPENFLG_MA_PLANT 					:= CST_FALSE;
	OPENFLG_AG_ALARM_ANALIZE_DAILY 		:= CST_FALSE;
	OPENFLG_AG_ALARM_ANALIZE_MONTHLY 	:= CST_FALSE;

	----------------------------------------------------------------------------
	-- メイン処理
	----------------------------------------------------------------------------
	<< MAIN_LOOP >>
	LOOP

		------------------------------------------------------------------------
		-- 工場ごとに稼働開始日時が異なるので、工場マスタで処理を回す
		------------------------------------------------------------------------
		-- 工場マスタを開いているならクローズ
		l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
		IF OPENFLG_MA_PLANT = CST_TRUE THEN
			CLOSE CUR_MA_PLANT;
			OPENFLG_MA_PLANT := CST_FALSE;
		END IF;

		-- 工場マスタをオープン
		l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
		OPEN CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_TRUE;

		<< PLANT_LOOP >>
		LOOP
			-- 工場マスタからフェッチ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
			FETCH CUR_MA_PLANT INTO l_plant_cd_wk, l_running_start_datetime;
			IF FOUND = FALSE THEN
				EXIT PLANT_LOOP;
			END IF;

			IF l_running_start_datetime IS NULL THEN
				-- NULLの場合はデフォルト値をセット
				l_err_pnt := RTRIM(cst_MY_PRG) || '_301';
				l_running_start_datetime = timestamp '0001-03-21 07:00:00';
			END IF;

			-- 処理開始日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_202';
			SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM') || '-' || to_char(l_running_start_datetime, 'DD HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_all;
			<< START_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_302';
				IF i_from_time >= l_proc_start_time_all THEN
					EXIT START_TIME_LOOP;
				END IF;
				l_proc_start_time_all := l_proc_start_time_all + interval '-1 months';
			END LOOP	START_TIME_LOOP;

			-- 処理終了日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_203';
			SELECT l_proc_start_time_all + interval '1 months' + interval '-1 milliseconds' INTO l_proc_end_time_all;
			<< END_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_303';
				IF i_to_time <= l_proc_end_time_all THEN
					EXIT END_TIME_LOOP;
				END IF;
				l_proc_end_time_all := l_proc_end_time_all + interval '1 months';
			END LOOP	END_TIME_LOOP;

			-- 処理開始/終了日時
			l_err_pnt := RTRIM(cst_MY_PRG) || '_204';
			l_proc_start_time := l_proc_start_time_all;
			l_proc_end_time := l_proc_start_time + interval '1 months' + interval '-1 milliseconds';

			<< TIME_LOOP >>
			LOOP

				-- 不具合解析(日別)を開いているならクローズ
				IF OPENFLG_AG_ALARM_ANALIZE_DAILY = CST_TRUE THEN
					CLOSE CUR_AG_ALARM_ANALIZE_DAILY;
					OPENFLG_AG_ALARM_ANALIZE_DAILY := CST_FALSE;
				END IF;

				-- 不具合解析(日別)をオープン
				l_err_pnt := RTRIM(cst_MY_PRG) || '_304';
				OPEN CUR_AG_ALARM_ANALIZE_DAILY;
				OPENFLG_AG_ALARM_ANALIZE_DAILY := CST_TRUE;

				<< AG_ALARM_ANALIZE_DAILY_LOOP >>
				LOOP
					-- 不具合解析(日別)からフェッチ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_401';
					FETCH CUR_AG_ALARM_ANALIZE_DAILY INTO
						l_plant_cd
						, l_ln_no
						, l_ln_nm
						, l_seizou_ln_cd
						, l_seizou_ln_nm
						, l_process_cd
						, l_process_nm
						, l_st_id
						, l_st_no
						, l_st_nm
						, l_alm_cd
						, l_main_res_nm
						, l_main_res_no
						, l_occur_count
						, l_last_occur_datetime
						, l_recovery_time
						, l_sagyoku;
					IF FOUND = FALSE THEN
						EXIT AG_ALARM_ANALIZE_DAILY_LOOP;
					END IF;

					-- 不具合解析(月別)に既に集計データが存在するかを確認
					-- 不具合解析(月別)を開いているならクローズ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_402';
					IF OPENFLG_AG_ALARM_ANALIZE_MONTHLY = CST_TRUE THEN
						CLOSE CUR_AG_ALARM_ANALIZE_MONTHLY;
						OPENFLG_AG_ALARM_ANALIZE_MONTHLY := CST_FALSE;
					END IF;

					-- 不具合解析(月別)をオープン
					l_err_pnt := RTRIM(cst_MY_PRG) || '_403';
					OPEN CUR_AG_ALARM_ANALIZE_MONTHLY;
					OPENFLG_AG_ALARM_ANALIZE_MONTHLY := CST_TRUE;

					-- 不具合解析(月別)からフェッチ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_404';
					FETCH CUR_AG_ALARM_ANALIZE_MONTHLY INTO REC_AG_ALARM_ANALIZE_MONTHLY;
					IF FOUND = FALSE THEN
						-- 不具合解析(月別)に格納
						l_err_pnt := RTRIM(cst_MY_PRG) || '_501';
						INSERT INTO AG_ALARM_ANALIZE_MONTHLY
						(
							ST_ID	, 					--	ステーションID
							ALM_CD	, 					--	アラームコード
							DATA_DATE	, 				--	データ日時
							PLANT_CD	, 				--	プラントコード
							SEIZOU_LN_CD	, 			--	製造ラインコード
							SEIZOU_LN_NM	,			--	製造ライン名
							PROCESS_CD	, 				--	工程コード
							PROCESS_NM	, 				--	工程名称
							LN_NO	, 					--	ラインNO
							LN_NM	, 					--	ライン名称
							ST_NO	, 					--	ステーションNO
							ST_NM	, 					--	ステーション名称
							MAIN_RES_NO	, 				--	メインリソース番号
							MAIN_RES_NM	, 				--	メインリソース名称
							SAGYOKU	, 					--	作業区
							OCCUR_COUNT	, 				--	発生回数
							LAST_OCCUR_DATETIME	, 		--	最終発生時刻
							RECOVERY_TIME	, 			--	復旧時間
							INS_PROG	, 				--	登録プログラム名
							INS_TIM	, 					--	登録日時
							INS_USER_SID	, 			--	登録ユーザSID
							UPD_PROG	, 				--	更新プログラム名
							UPD_TIM	, 					--	更新日時
							UPD_USER_SID				--	更新ユーザSID
						)
						VALUES
						(
							l_st_id	, 					--	ステーションID
							l_alm_cd	, 				--	アラームコード
							l_proc_start_time	, 		--	データ日時
							l_plant_cd	, 				--	プラントコード
							l_seizou_ln_cd	, 			--	製造ラインコード
							l_seizou_ln_nm	, 			--	製造ライン名
							l_process_cd	, 			--	工程コード
							l_process_nm	, 			--	工程名称
							l_ln_no	, 					--	ラインNo
							l_ln_nm	, 					--	ライン名称
							l_st_no	, 					--	ステーションNo
							l_st_nm	, 					--	ステーション名称
							l_main_res_no	, 			--	メインリソース番号
							l_main_res_nm	, 			--	メインリソース名称
							l_sagyoku	, 				--	作業区
							l_occur_count	, 			--	発生回数
							l_last_occur_datetime	, 	--	最終発生時刻
							l_recovery_time	, 			--	復旧時間
							cst_MY_PRG,					-- 登録プログラム
							l_exec_datetime,			-- 登録日時
							i_user_sid,					-- 登録ユーザSID
							cst_MY_PRG,					-- 更新プログラム
							l_exec_datetime,			-- 更新日時
							i_user_sid					-- 更新ユーザSID
						);
					ELSE
						-- 不具合解析(月別)を更新
						l_err_pnt := RTRIM(cst_MY_PRG) || '_502';
						UPDATE AG_ALARM_ANALIZE_MONTHLY SET
							  PLANT_CD				= l_plant_cd				-- プラントコード
							, SEIZOU_LN_CD			= l_seizou_ln_cd			-- 製造ラインコード
							, SEIZOU_LN_NM			= l_seizou_ln_nm			-- 製造ライン名
							, PROCESS_CD			= l_process_cd				-- 工程コード
							, PROCESS_NM			= l_process_nm				-- 工程名称
							, LN_NO					= l_ln_no					-- ラインNO
							, LN_NM					= l_ln_nm					-- ライン名称
							, ST_NO					= l_st_no					-- ステーションNO
							, ST_NM					= l_st_nm					-- ステーション名称
							, MAIN_RES_NO			= l_main_res_no				-- メインリソース番号
							, MAIN_RES_NM			= l_main_res_nm				-- メインリソース名称
							, SAGYOKU				= l_sagyoku					-- 作業区
							, OCCUR_COUNT			= l_occur_count				-- 発生回数
							, LAST_OCCUR_DATETIME	= l_last_occur_datetime		-- 最終発生時刻
							, RECOVERY_TIME			= l_recovery_time			-- 復旧時間
							, OCCUR_COUNT			= l_occur_count				-- 発生回数
							, LAST_OCCUR_DATETIME	= l_last_occur_datetime		-- 最終発生時刻
							, RECOVERY_TIME			= l_recovery_time			-- 復旧時間
							, SAGYOKU				= l_sagyoku					-- 作業区
							, UPD_PROG				= cst_MY_PRG				-- 更新プログラム
							, UPD_TIM				= l_exec_datetime			-- 更新日時
							, UPD_USER_SID			= i_user_sid				-- 更新ユーザSID
						WHERE CURRENT OF CUR_AG_ALARM_ANALIZE_MONTHLY;
					END IF;

				END LOOP	AG_ALARM_ANALIZE_DAILY_LOOP;

				-- 次の処理日時を設定
				l_proc_start_time	:= l_proc_start_time + interval '1 months';
				l_proc_end_time		:= l_proc_end_time + interval '1 months';

				-- 処理開始日時が処理終了日時(全体)を超えている場合は処理終了
				IF l_proc_end_time_all < l_proc_start_time THEN
					EXIT TIME_LOOP;
				END IF;

			END LOOP	TIME_LOOP;

		END LOOP	PLANT_LOOP;

		EXIT MAIN_LOOP;
	END LOOP	MAIN_LOOP;

	----------------------------------------------------------------------------
	--						終了処理
	----------------------------------------------------------------------------
	-- カーソルクローズ
	l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
	IF OPENFLG_MA_PLANT = CST_TRUE THEN
		CLOSE CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E002';
	IF OPENFLG_AG_ALARM_ANALIZE_DAILY = CST_TRUE THEN
		CLOSE CUR_AG_ALARM_ANALIZE_DAILY;
		OPENFLG_AG_ALARM_ANALIZE_DAILY := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
	IF OPENFLG_AG_ALARM_ANALIZE_MONTHLY = CST_TRUE THEN
		CLOSE CUR_AG_ALARM_ANALIZE_MONTHLY;
		OPENFLG_AG_ALARM_ANALIZE_MONTHLY := CST_FALSE;
	END IF;

	raise info 'End Function [%]', clock_timestamp()::timestamp;

EXCEPTION WHEN OTHERS THEN
	-- DB例外情報収集
	GET STACKED DIAGNOSTICS rtn_sql_no     = RETURNED_SQLSTATE,
							rtn_sql_msg    = MESSAGE_TEXT,
							rtn_sql_detail = PG_EXCEPTION_DETAIL,
							rtn_sql_hint   = PG_EXCEPTION_HINT,
							rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

	raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
	raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

	o_ret_cd := RET_NG;
	o_sqlerr := substr(rtn_sql_no, 1, 15);
	o_errmsg := substr(rtn_sql_msg, 1, 127);
	o_errpnt := l_err_pnt;

	raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;
