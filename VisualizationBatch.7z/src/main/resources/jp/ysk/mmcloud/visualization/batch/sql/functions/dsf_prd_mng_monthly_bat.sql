CREATE or REPLACE FUNCTION dsf_prd_mng_monthly_bat(
	in	i_batch_name	varchar,			-- バッチ処理名称
	in	i_log_type		numeric,			-- ログ種別(開始、および　各バッチ処理の復帰値)
											-- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
	in	i_user_sid		numeric,			-- 登録ユーザSID
	in	i_from_time		timestamp,			-- 集計開始日時(空の場合は当月を対象とする)
	in	i_to_time		timestamp,			-- 集計終了日時(空の場合は当月を対象とする)
	out	o_ret_cd		int,				-- 関数復帰値	RET_OK(= 0):正常終了
	out	o_sqlerr		varchar,			-- ＤＢ異常発生時のエラーコード
	out	o_errmsg		varchar,			-- 異常発生時のエラーメッセージ
	out	o_errpnt		varchar				-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　[サイネージ用]製品生産計画実績(月別)作成サービス
--　ソースプログラム名　：　dsf_prd_mng_monthly_bat.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　[サイネージ用]製品生産計画実績(月別)を作成する
--
--　履歴
--  Ver.  作成日			作成者		COMMENT
--  1.0   2016/08/29		H.Nakamura	新規作成
--******************************************************************************
DECLARE
	----------------------------------------------------------------------------
	--						標準定数定義
	----------------------------------------------------------------------------
	-- 戻り値
	RET_OK		CONSTANT int := 0 ;						-- 正常終了コード
	RET_NG		CONSTANT int := -1 ;					-- 異常終了コード
	-- 真偽値
	CST_TRUE	CONSTANT int := 1 ;						-- 真
	CST_FALSE	CONSTANT int := 0 ;						-- 偽

	----------------------------------------------------------------------------
	--						標準変数定義
	----------------------------------------------------------------------------
	cst_MY_PRG	CONSTANT CHAR(32)	 := 'dsf_prd_mng_monthly_bat';			-- プログラム名
	cst_UPD_TIM	CHAR(17) ;													-- 更新時間
	l_err_pnt	CHAR(64) ;													-- エラー発生ポイント
	errbuff		varchar(256);												-- メッセージバッファ

	----------------------------------------------------------------------------
	--						定数定義
	----------------------------------------------------------------------------
	CST_INVALID_VALUE	CONSTANT int := -1;			-- 無効値

	----------------------------------------------------------------------------
	--						変数定義
	----------------------------------------------------------------------------
	-- 共通変数
	rtn_sql_no		text;							-- DBエラー情報(エラー番号)
	rtn_sql_msg		text;							-- DBエラー情報(エラーメッセージ)
	rtn_sql_detail	text;							-- DBエラー情報(エラー詳細)
	rtn_sql_hint	text;							-- DBエラー情報(エラーヒント)
	rtn_sql_stack	text;							-- DBエラー情報(エラー発生呼出しスタック)

	-- ローカル変数
	l_exec_datetime				timestamp;			-- 関数実行日時
	l_proc_start_time			timestamp;			-- 処理開始日時
	l_proc_end_time				timestamp;			-- 処理終了日時
	l_proc_start_time_all		timestamp;			-- 処理開始日時(全体)
	l_proc_end_time_all			timestamp;			-- 処理終了日時(全体)
	l_running_start_datetime	timestamp;			-- 稼働開始日時(年度開始日時)
	l_plant_cd					varchar(10);		-- 工場コード
	l_plant_cd_wk				varchar(10);		-- 工場コード
	l_buhin_cd					char(40);			-- 品目コード
	l_vtext_info1				varchar(40);		-- 品目階層TEXT_その1
	l_vtext_info2				varchar(40);		-- 品目階層TEXT_その2
	l_upd_date					timestamp;			-- 更新日時
	l_plan_num					int;				-- 計画(当月)台数
	l_plan_value				bigint;				-- 計画(当月)金額
	l_actual_num				int;				-- 実績(当月)台数
	l_actual_value				bigint;				-- 実績(当月)金額

	----------------------------------------------------------------------------
	--						カーソル定義
	----------------------------------------------------------------------------
	-- 工場マスタ
	CUR_MA_PLANT	CURSOR FOR
		SELECT
			T0.PLANT_CD					as plantCode,
			T0.RUNNING_START_DATETIME	as runningStartDatetime
		FROM
			MA_PLANT	T0
		WHERE
			T0.INVALID_FLAG = 0
		ORDER BY
			T0.PLANT_CD
	;

	OPENFLG_MA_PLANT	int;	-- カーソルオープン状態


	-- [サイネージ用]製品生産計画実績(月別)(クリア用)
	CUR_DS_PRODUCT_MNG_MONTHLY_CLEAR	CURSOR FOR
		SELECT
			*
		FROM
			DS_PRODUCT_MNG_MONTHLY
		WHERE
				PLANT_CD	=  l_plant_cd
			AND	DATA_DATE	>= l_proc_start_time
			AND	DATA_DATE	<= l_proc_end_time
		FOR UPDATE NOWAIT
	;

	OPENFLG_DS_PRODUCT_MNG_MONTHLY_CLEAR	int;	-- カーソルオープン状態
	REC_DS_PRODUCT_MNG_MONTHLY_CLEAR		DS_PRODUCT_MNG_MONTHLY%ROWTYPE;


	-- [サイネージ用]製品生産計画実績(日別)
	CUR_DS_PRODUCT_MNG_DAILY	CURSOR FOR
		SELECT
			PLANT_CD			as plantCode,
			BUHIN_CD			as hinmokuCode,
			VTEXT_INFO1			as vtextInfo1,
			VTEXT_INFO2			as vtextInfo2,
			MAX(UPD_DATE)		as updDate,
			SUM(PLAN_NUM)		as planNum,
			SUM(PLAN_VALUE)		as planValue,
			SUM(ACTUAL_NUM)		as actualNum,
			SUM(ACTUAL_VALUE)	as actualValue
		FROM
			DS_PRODUCT_MNG_DAILY
		WHERE
				PLANT_CD		=	l_plant_cd_wk
			AND	DATA_DATE		>=	l_proc_start_time
			AND DATA_DATE		<=	l_proc_end_time
		GROUP BY
			PLANT_CD, BUHIN_CD, VTEXT_INFO1, VTEXT_INFO2
	;

	OPENFLG_DS_PRODUCT_MNG_DAILY	int;	-- カーソルオープン状態


	-- [サイネージ用]製品生産計画実績(月別)
	CUR_DS_PRODUCT_MNG_MONTHLY	CURSOR FOR
		SELECT
			  *
		FROM
			DS_PRODUCT_MNG_MONTHLY
		WHERE
				PLANT_CD		= l_plant_cd
			AND BUHIN_CD		= l_buhin_cd
			AND VTEXT_INFO1		= l_vtext_info1
			AND VTEXT_INFO2		= l_vtext_info2
			AND DATA_DATE		= l_proc_start_time
		FOR UPDATE NOWAIT
	;

	OPENFLG_DS_PRODUCT_MNG_MONTHLY	int;	-- カーソルオープン状態
	REC_DS_PRODUCT_MNG_MONTHLY		DS_PRODUCT_MNG_MONTHLY%ROWTYPE;

BEGIN
	----------------------------------------------------------------------------
	--						初期処理
	----------------------------------------------------------------------------
	raise info 'Start Function [%]', clock_timestamp()::timestamp;

	-- 共通変数初期化
	l_err_pnt		:= RTRIM(cst_MY_PRG) || '_S001';

	-- 共通出力パラメータ初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
	o_ret_cd	:= RET_OK;
	o_sqlerr	:= ' ';
	o_errmsg	:= ' ';
	o_errpnt	:= ' ';

	-- 関数実行日時
	l_exec_datetime := clock_timestamp();

	-- 集計開始/終了日時補正
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
	IF i_from_time IS NULL THEN
		i_from_time := l_exec_datetime;
	END IF;
	IF i_to_time IS NULL OR i_from_time > i_to_time THEN
		i_to_time := l_exec_datetime;
	END IF;

	-- カーソルオープン状態初期化
	OPENFLG_MA_PLANT := CST_FALSE;
	OPENFLG_DS_PRODUCT_MNG_MONTHLY_CLEAR := CST_FALSE;
	OPENFLG_DS_PRODUCT_MNG_DAILY := CST_FALSE;
	OPENFLG_DS_PRODUCT_MNG_MONTHLY := CST_FALSE;

	----------------------------------------------------------------------------
	-- メイン処理
	----------------------------------------------------------------------------
	<< MAIN_LOOP >>
	LOOP

		------------------------------------------------------------------------
		-- 工場ごとに稼働開始日時が異なるので、工場マスタで処理を回す
		------------------------------------------------------------------------
		-- 工場マスタを開いているならクローズ
		l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
		IF OPENFLG_MA_PLANT = CST_TRUE THEN
			CLOSE CUR_MA_PLANT;
			OPENFLG_MA_PLANT := CST_FALSE;
		END IF;

		-- 工場マスタをオープン
		l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
		OPEN CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_TRUE;

		<< PLANT_LOOP >>
		LOOP
			-- 工場マスタからフェッチ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_103';
			FETCH CUR_MA_PLANT INTO l_plant_cd_wk, l_running_start_datetime;
			IF FOUND = FALSE THEN
				EXIT PLANT_LOOP;
			END IF;

			IF l_running_start_datetime IS NULL THEN
				-- NULLの場合はデフォルト値をセット
				l_err_pnt := RTRIM(cst_MY_PRG) || '_104';
				l_running_start_datetime = timestamp '0001-03-21 07:00:00';
			END IF;

			-- 処理開始日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_105';
			SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM') || '-' || to_char(l_running_start_datetime, 'DD HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_all;
			<< START_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_106';
				IF i_from_time >= l_proc_start_time_all THEN
					EXIT START_TIME_LOOP;
				END IF;
				l_proc_start_time_all := l_proc_start_time_all + interval '-1 months';
			END LOOP	START_TIME_LOOP;

			-- 処理終了日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_107';
			SELECT l_proc_start_time_all + interval '1 months' + interval '-1 milliseconds' INTO l_proc_end_time_all;
			<< END_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_108';
				IF i_to_time <= l_proc_end_time_all THEN
					EXIT END_TIME_LOOP;
				END IF;
				l_proc_end_time_all := l_proc_end_time_all + interval '1 months';
			END LOOP	END_TIME_LOOP;

			-- 処理開始/終了日時
			l_err_pnt := RTRIM(cst_MY_PRG) || '_109';
			l_proc_start_time := l_proc_start_time_all;
			l_proc_end_time := l_proc_start_time + interval '1 months' + interval '-1 milliseconds';

			<< TIME_LOOP >>
			LOOP

				----------------------------------------------------------------
				-- 計画をクリア
				----------------------------------------------------------------
				-- [サイネージ用]製品生産計画実績(月別)(クリア用)をオープン
				l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
				OPEN CUR_DS_PRODUCT_MNG_MONTHLY_CLEAR;
				OPENFLG_DS_PRODUCT_MNG_MONTHLY_CLEAR := CST_TRUE;

				<< DS_PRODUCT_MNG_MONTHLY_CLEAR_LOOP >>
				LOOP
					-- [サイネージ用]製品生産計画実績(月別)(クリア用)からフェッチ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_202';
					FETCH CUR_DS_PRODUCT_MNG_MONTHLY_CLEAR INTO REC_DS_PRODUCT_MNG_MONTHLY_CLEAR;
					IF FOUND = FALSE THEN
						-- データがない場合
						l_err_pnt := RTRIM(cst_MY_PRG) || '_203';
						EXIT DS_PRODUCT_MNG_MONTHLY_CLEAR_LOOP;
					END IF;

					-- [サイネージ用]製品生産計画実績(月別)(クリア用)を更新
					l_err_pnt := RTRIM(cst_MY_PRG) || '_204';
					UPDATE
						DS_PRODUCT_MNG_DAILY
					SET
						PLAN_NUM		= 0,				-- 計画台数
						ACTUAL_NUM		= 0,				-- 実績台数
						PLAN_VALUE		= 0,				-- 計画金額
						ACTUAL_VALUE	= 0,				-- 実績金額
						UPD_PROG		= cst_MY_PRG,		-- 更新プログラム
						UPD_TIM			= l_exec_datetime,	-- 更新日時
						UPD_USER_SID	= i_user_sid		-- 更新ユーザSID
					WHERE CURRENT OF CUR_DS_PRODUCT_MNG_MONTHLY_CLEAR;
				END LOOP	DS_PRODUCT_MNG_MONTHLY_CLEAR_LOOP;

				-- [サイネージ用]製品生産計画実績(月別)(クリア用)をクローズ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_205';
				CLOSE CUR_DS_PRODUCT_MNG_MONTHLY_CLEAR;
				OPENFLG_DS_PRODUCT_MNG_MONTHLY_CLEAR := CST_FALSE;

				----------------------------------------------------------------
				-- 計画＆実績を設定
				----------------------------------------------------------------
				-- [サイネージ用]製品生産計画実績(日別)を開いているならクローズ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_301';
				IF OPENFLG_DS_PRODUCT_MNG_DAILY = CST_TRUE THEN
					CLOSE CUR_DS_PRODUCT_MNG_DAILY;
					OPENFLG_DS_PRODUCT_MNG_DAILY := CST_FALSE;
				END IF;

				-- [サイネージ用]製品生産計画実績(日別)をオープン
				l_err_pnt := RTRIM(cst_MY_PRG) || '_302';
				OPEN CUR_DS_PRODUCT_MNG_DAILY;
				OPENFLG_DS_PRODUCT_MNG_DAILY := CST_TRUE;

				<< DS_PRODUCT_MNG_DAILY_LOOP >>
				LOOP
					-- [サイネージ用]製品生産計画実績(日別)からフェッチ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_303';
					FETCH CUR_DS_PRODUCT_MNG_DAILY INTO l_plant_cd, l_buhin_cd, l_vtext_info1, l_vtext_info2, l_upd_date, l_plan_num, l_plan_value, l_actual_num, l_actual_value;
					IF FOUND = FALSE THEN
						-- データがない場合
						l_err_pnt := RTRIM(cst_MY_PRG) || '_304';
						EXIT DS_PRODUCT_MNG_DAILY_LOOP;
					END IF;

					-- [サイネージ用]製品生産計画実績(月別)にデータがあるか確認
					l_err_pnt := RTRIM(cst_MY_PRG) || '_305';
					IF OPENFLG_DS_PRODUCT_MNG_MONTHLY = CST_TRUE THEN
						CLOSE CUR_DS_PRODUCT_MNG_MONTHLY;
						OPENFLG_DS_PRODUCT_MNG_MONTHLY := CST_FALSE;
					END IF;

					-- [サイネージ用]製品生産計画実績(月別)をオープン
					l_err_pnt := RTRIM(cst_MY_PRG) || '_306';
					OPEN CUR_DS_PRODUCT_MNG_MONTHLY;
					OPENFLG_DS_PRODUCT_MNG_MONTHLY := CST_TRUE;

					l_err_pnt := RTRIM(cst_MY_PRG) || '_307';
					FETCH CUR_DS_PRODUCT_MNG_MONTHLY INTO REC_DS_PRODUCT_MNG_MONTHLY;
					IF FOUND = FALSE THEN
						-- [サイネージ用]製品生産計画実績(月別)に格納
						l_err_pnt := RTRIM(cst_MY_PRG) || '_308';
						INSERT INTO DS_PRODUCT_MNG_MONTHLY
						(
							  PLANT_CD			 	  				-- プラントコード
							, BUHIN_CD			 	  				-- 品目コード
							, DATA_DATE			 	  				-- データ日時
							, VTEXT_INFO1			  				-- 品目階層TEXT_その1
							, VTEXT_INFO2			  				-- 品目階層TEXT_その2
							, UPD_DATE			 	  				-- 更新日時
							, PLAN_NUM			 	  				-- 計画台数
							, ACTUAL_NUM			  				-- 実績台数
							, PLAN_VALUE			  				-- 計画金額
							, ACTUAL_VALUE			  				-- 実績金額
							, INS_PROG		   		  				-- 登録プログラム名
							, INS_TIM		   		  				-- 登録日時
							, INS_USER_SID			  				-- 登録ユーザSID
							, UPD_PROG			 	  				-- 更新プログラム名
							, UPD_TIM			 	  				-- 更新日時
							, UPD_USER_SID			  				-- 更新ユーザSID
						)
						VALUES
						(
							  l_plant_cd		 	  				-- プラントコード
							, l_buhin_cd		 	  				-- 品目コード
							, l_proc_start_time	 	  				-- データ日時
							, l_vtext_info1			  				-- 品目階層TEXT_その1
							, l_vtext_info2			  				-- 品目階層TEXT_その2
							, l_upd_date		 	  				-- 更新日時
							, l_plan_num			 	  			-- 計画台数
							, l_actual_num			  				-- 実績台数
							, l_plan_value			  				-- 計画金額
							, l_actual_value			  			-- 実績金額
							, cst_MY_PRG							-- 登録プログラム
							, l_exec_datetime						-- 登録日時
							, i_user_sid							-- 登録ユーザSID
							, cst_MY_PRG							-- 更新プログラム
							, l_exec_datetime						-- 更新日時
							, i_user_sid							-- 更新ユーザSID
						);
					ELSE
						-- [サイネージ用]製品生産計画実績(月別)を更新
						l_err_pnt := RTRIM(cst_MY_PRG) || '_309';
						UPDATE DS_PRODUCT_MNG_MONTHLY SET
							  UPD_DATE		= l_upd_date		 	-- 更新日時
							, PLAN_NUM 		= l_plan_num			-- 計画台数
							, ACTUAL_NUM 	= l_actual_num			-- 実績台数
							, PLAN_VALUE	= l_plan_value			-- 計画金額
							, ACTUAL_VALUE	= l_actual_value		-- 実績金額
							, UPD_PROG		= cst_MY_PRG			-- 更新プログラム
							, UPD_TIM		= l_exec_datetime		-- 更新日時
							, UPD_USER_SID	= i_user_sid			-- 更新ユーザSID
						WHERE CURRENT OF CUR_DS_PRODUCT_MNG_MONTHLY;
					END IF;

				END LOOP	DS_PRODUCT_MNG_DAILY_LOOP;

				-- 次の処理日時を設定
				l_proc_start_time	:= l_proc_start_time + interval '1 months';
				l_proc_end_time		:= l_proc_end_time + interval '1 months';

				-- 処理開始日時が処理終了日時(全体)を超えている場合は処理終了
				IF l_proc_end_time_all < l_proc_start_time THEN
					EXIT TIME_LOOP;
				END IF;

			END LOOP	TIME_LOOP;

		END LOOP	PLANT_LOOP;

		EXIT MAIN_LOOP;
	END LOOP	MAIN_LOOP;

	----------------------------------------------------------------------------
	--						終了処理
	----------------------------------------------------------------------------
	-- カーソルクローズ
	l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
	IF OPENFLG_MA_PLANT = CST_TRUE THEN
		CLOSE CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E002';
	IF OPENFLG_DS_PRODUCT_MNG_MONTHLY_CLEAR = CST_TRUE THEN
		CLOSE CUR_DS_PRODUCT_MNG_MONTHLY_CLEAR;
		OPENFLG_DS_PRODUCT_MNG_MONTHLY_CLEAR := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
	IF OPENFLG_DS_PRODUCT_MNG_DAILY = CST_TRUE THEN
		CLOSE CUR_DS_PRODUCT_MNG_DAILY;
		OPENFLG_DS_PRODUCT_MNG_DAILY := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E004';
	IF OPENFLG_DS_PRODUCT_MNG_MONTHLY = CST_TRUE THEN
		CLOSE CUR_DS_PRODUCT_MNG_MONTHLY;
		OPENFLG_DS_PRODUCT_MNG_MONTHLY := CST_FALSE;
	END IF;

	raise info 'End Function [%]', clock_timestamp()::timestamp;

EXCEPTION WHEN OTHERS THEN
	-- DB例外情報収集
	GET STACKED DIAGNOSTICS rtn_sql_no     = RETURNED_SQLSTATE,
							rtn_sql_msg    = MESSAGE_TEXT,
							rtn_sql_detail = PG_EXCEPTION_DETAIL,
							rtn_sql_hint   = PG_EXCEPTION_HINT,
							rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

	raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
	raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

	o_ret_cd := RET_NG;
	o_sqlerr := substr(rtn_sql_no, 1, 15);
	o_errmsg := substr(rtn_sql_msg, 1, 127);
	o_errpnt := l_err_pnt;

	raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;
