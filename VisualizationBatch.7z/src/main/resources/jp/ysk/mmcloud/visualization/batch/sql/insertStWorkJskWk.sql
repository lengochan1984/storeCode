WITH
    val AS (
        SELECT
            (   (
                /*createdOn*/,
                /*createdBy*/,
                /*modifiedOn*/,
                /*modifiedBy*/,
				/*sasizuNo*/,
				/*subNo*/,
				/*sagyoSeq*/,
				/*repairKaisu*/,
				/*stId*/,
				/*plantCd*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*processCd*/,
				/*processNm*/,
				/*lnNo*/,
				/*lnNm*/,
				/*stNo*/,
				/*stNm*/,
				/*sagyoku*/,
				/*sagyoNo*/,
				/*equipCd*/,
				/*syainNo*/,
				/*workStaTime*/,
				/*workEndTime*/,
				/*workStaStep*/,
				/*workEndStep*/,
				/*workTime*/,
				/*hantei*/,
				/*almCd*/,
				/*sagyoJyotai*/,
				/*sagyokuLastSt*/,
				/*sousinFlag*/,
				/*sousinDate*/,
                /*spareNum1*/,
                /*spareNum2*/,
                /*spareNum3*/,
                /*spareText1*/,
                /*spareText2*/,
                /*spareText3*/,
                'insert-TR_ST_WORK_JSK_WK',
                now(),
                0,
                'insert-TR_ST_WORK_JSK_WK',
                now(),
                0
                )::TR_ST_WORK_JSK_WK).*
    ),

    upd AS (
        UPDATE
            TR_ST_WORK_JSK_WK
        SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			plant_cd			= /*plantCd*/,
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
			process_cd			= /*processCd*/,
			process_nm			= /*processNm*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			st_no				= /*stNo*/,
			st_nm				= /*stNm*/,
			sagyoku				= /*sagyoku*/,
			sagyo_no			= /*sagyoNo*/,
			equip_cd			= /*equipCd*/,
			syain_no			= /*syainNo*/,
			work_end_time		= CAST(/*workEndTime*/ AS timestamp),
			work_sta_step		= /*workStaStep*/,
			work_end_step		= /*workEndStep*/,
			work_time			= CAST(/*workTime*/ AS numeric),
			hantei				= CAST(/*hantei*/ AS numeric),
			alm_cd				= /*almCd*/,
			sagyo_jyotai		= CAST(/*sagyoJyotai*/ AS numeric),
			sagyoku_last_st		= /*sagyokuLastSt*/,
			sousin_flag			= CAST(/*sousinFlag*/ AS numeric),
			sousin_date			= CAST(/*sousinDate*/ AS timestamp),
            spare_num1			= CAST(/*spareNum1*/ AS numeric),
            spare_num2			= CAST(/*spareNum2*/ AS numeric),
            spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog = 'update-TR_ST_WORK_JSK_WK',
			upd_tim  = now(),
			upd_user_sid = 0
        FROM
            val
        WHERE
            TR_ST_WORK_JSK_WK.sasizu_no		= /*sasizuNo*/
        AND TR_ST_WORK_JSK_WK.sub_no		= /*subNo*/
        AND TR_ST_WORK_JSK_WK.sagyo_seq		= /*sagyoSeq*/
        AND TR_ST_WORK_JSK_WK.repair_kaisu	= /*repairKaisu*/
        AND TR_ST_WORK_JSK_WK.st_id			= /*stId*/
        AND TR_ST_WORK_JSK_WK.work_sta_time	= /*workStaTime*/

        RETURNING
            TR_ST_WORK_JSK_WK.sasizu_no,
            TR_ST_WORK_JSK_WK.sub_no,
            TR_ST_WORK_JSK_WK.sagyo_seq,
            TR_ST_WORK_JSK_WK.repair_kaisu,
            TR_ST_WORK_JSK_WK.st_id,
            TR_ST_WORK_JSK_WK.work_sta_time
    )

INSERT INTO
    TR_ST_WORK_JSK_WK
SELECT
    *
FROM
    val
WHERE
    (sasizu_no, sub_no, sagyo_seq, repair_kaisu, st_id, work_sta_time)
        NOT IN (SELECT sasizu_no, sub_no, sagyo_seq, repair_kaisu, st_id, work_sta_time FROM upd);
