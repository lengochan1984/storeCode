CREATE OR REPLACE FUNCTION get_group_tree_path_name(text)
  RETURNS text AS
$BODY$
select 
	array_to_string(array(
		select 
			group_name.group_name 
		from 
			( 
				select 
					tbl_group_base.group_id, 
					tbl_group_base.group_row_num, 
					row_number() over(partition by tbl_group_base.group_row_num) as group_part_row_num, 
					tbl_group_base.tree_path_part 
				from 
					( 
						select 
							group_id, 
							row_number() over() as group_row_num, 
							regexp_split_to_table(ltree2text(tree_path), '\.') as tree_path_part 
						from 
							mst_group 
						where 
							group_id = ($1) 
					) tbl_group_base 
				where 
					tbl_group_base.tree_path_part not like 'SYS%' 
			) tbl_group_part_base 
		inner join 
			mst_group group_name 
		on 
			tbl_group_part_base.tree_path_part = group_name.group_id 
		where 
			group_base.group_id = tbl_group_part_base.group_id 
		order by 
			tbl_group_part_base.group_row_num asc, 
			tbl_group_part_base.group_part_row_num asc 
	), '-') 
from 
	mst_group group_base 
where 
	group_base.group_id = ($1) 
$BODY$
  LANGUAGE sql;
