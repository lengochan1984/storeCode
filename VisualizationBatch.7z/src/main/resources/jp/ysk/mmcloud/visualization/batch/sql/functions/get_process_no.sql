CREATE OR REPLACE FUNCTION get_process_no(
	character,
	character)
  RETURNS integer AS
$BODY$
SELECT 
	mst_process.process_no
FROM
	mst_process
INNER JOIN
	mst_line
ON
	mst_process.plant_code = mst_line.plant_code
AND
	mst_process.process_code = mst_line.process_code
INNER JOIN
	mst_line_group
ON
	mst_line_group.plant_code = mst_line.plant_code
AND
	mst_line_group.line_no = mst_line.line_no
WHERE
		mst_process.process_no = 
		(
			SELECT
				MIN(mst_process.process_no) process_no
			FROM
				(
				SELECT
					mst_line_group.line_group_no,
					mst_line_group.line_no,
					mst_line_group.plant_code
				FROM
					mst_line_group
				WHERE
					mst_line_group.plant_code = ($1)
				AND
					mst_line_group.line_group_no = ($2)
				) line_group_info
			INNER JOIN
				mst_line
			ON
				line_group_info.plant_code = mst_line.plant_code
			AND
				line_group_info.line_no = mst_line.line_no
			INNER JOIN
				mst_process
			ON
				mst_line.plant_code = mst_process.plant_code
			AND
				mst_line.process_code = mst_process.process_code
			GROUP BY line_group_info.line_group_no
		)
	AND	mst_line_group.line_group_no = ($2)
$BODY$
  LANGUAGE sql;
