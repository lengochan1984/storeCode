SELECT
    CREATED_ON,
    CREATED_BY,
    COALESCE(MODIFIED_ON, CREATED_ON) AS MODIFIED_ON,
    COALESCE(MODIFIED_BY, CREATED_BY) AS MODIFIED_BY,
    SASIZU_NO,
    SUB_NO,
    SAGYO_SEQ,
    REPAIR_KAISU,
    LN_ID,
    PLANT_CD,
    SEIZOU_LN_CD,
    SEIZOU_LN_NM,
    PROCESS_CD,
    PROCESS_NM,
    LN_NO,
    LN_NM,
    END_ST_ID,
    END_ST_NO,
    END_ST_NM,
    END_SAGYOKU,
    END_STEP_NO,
    END_TIME,
    HANTEI,
    ALM_CD,
    SAGYO_JYOTAI,
    SAGYO_KEKA,
    START_ST_ID,
    START_ST_NO,
    START_ST_NM,
    START_SAGYOKU,
    START_STEP_NO,
    START_TIME,
    STOP_TIME,
    STOP_TIME2,
    N_LN_ID,
    N_SEIZOU_LN_CD,
    N_SEIZOU_LN_NM,
    N_PROCESS_CD,
    N_PROCESS_NM,
    N_LN_NO,
    N_LN_NM,
    N_SAGYO_SEQ,
    SPARE_NUM1,
    SPARE_NUM2,
    SPARE_NUM3,
    SPARE_TEXT1,
    SPARE_TEXT2,
    SPARE_TEXT3

FROM
    TR_LINE_TM_INFO

WHERE
    N_LN_ID != null
    /*IF addDatetime != null */
    AND (
        (CREATED_ON >= /*addDatetime*/ AND MODIFIED_ON is null)
    OR  MODIFIED_ON >= /*addDatetime*/
    )
    /*END*/

ORDER BY
    COALESCE(MODIFIED_ON, CREATED_ON)
