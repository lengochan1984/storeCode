﻿CREATE or REPLACE FUNCTION func_work_manhour_mng_daily(
	in	i_batch_name	varchar,			-- バッチ処理名称
	in	i_log_type		numeric,			-- ログ種別(開始、および　各バッチ処理の復帰値)
											-- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
	in	i_user_sid		numeric,			-- 登録ユーザSID
	in	i_from_time		timestamp,			-- 集計開始日時(日単位)
	in	i_to_time		timestamp,			-- 集計終了日時(日単位)
	out	o_ret_cd		int,				-- 関数復帰値	RET_OK(= 0):正常終了
	out	o_sqlerr		varchar,			-- ＤＢ異常発生時のエラーコード
	out	o_errmsg		varchar,			-- 異常発生時のエラーメッセージ
	out	o_errpnt		varchar				-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　作業工数実績(日別)作成サービス
--　ソースプログラム名　：　func_work_manhour_mng_daily.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　作業工数実績(日別)を作成する
--
--　履歴
--  Ver.  作成日			作成者		COMMENT
--  1.0   2017/03/09		H.Nakamura	新規作成
--  1.1   2017/09/01		H.Nakamura	MMsF対応
--******************************************************************************
DECLARE
	----------------------------------------------------------------------------
	--						標準定数定義
	----------------------------------------------------------------------------
	-- 戻り値
	RET_OK		CONSTANT int := 0 ;						-- 正常終了コード
	RET_NG		CONSTANT int := -1 ;					-- 異常終了コード
	-- 真偽値
	CST_TRUE	CONSTANT int := 1 ;						-- 真
	CST_FALSE	CONSTANT int := 0 ;						-- 偽

	----------------------------------------------------------------------------
	--						標準変数定義
	----------------------------------------------------------------------------
	cst_MY_PRG	CONSTANT CHAR(32)	 := 'func_work_manhour_mng_daily';		-- プログラム名
	cst_UPD_TIM	CHAR(17) ;													-- 更新時間
	l_err_pnt	CHAR(64) ;													-- エラー発生ポイント
	errbuff		varchar(256);												-- メッセージバッファ

	----------------------------------------------------------------------------
	--						定数定義
	----------------------------------------------------------------------------
	CST_SAGYO_MODE_LOW		CONSTANT int := 1;				-- 作業モード：作業者レベル低
	CST_SAGYO_MODE_MIDDLE	CONSTANT int := 2;				-- 作業モード：作業者レベル中
	CST_SAGYO_MODE_HIGH		CONSTANT int := 3;				-- 作業モード：作業者レベル高

	----------------------------------------------------------------------------
	--						変数定義
	----------------------------------------------------------------------------
	-- 共通変数
	rtn_sql_no		text;							-- DBエラー情報(エラー番号)
	rtn_sql_msg		text;							-- DBエラー情報(エラーメッセージ)
	rtn_sql_detail	text;							-- DBエラー情報(エラー詳細)
	rtn_sql_hint	text;							-- DBエラー情報(エラーヒント)
	rtn_sql_stack	text;							-- DBエラー情報(エラー発生呼出しスタック)

	-- ローカル変数
	l_exec_datetime				timestamp;			-- 関数実行日時
	l_proc_start_time			timestamp;			-- 処理開始日
	l_proc_end_time				timestamp;			-- 処理終了日
	l_proc_start_time_all		timestamp;			-- 処理開始日(全体)
	l_proc_end_time_all			timestamp;			-- 処理終了日(全体)
	l_running_start_datetime	timestamp;			-- 稼働開始日時(年度開始日時)
	l_plant_cd					varchar(10);		-- プラントコード
	l_plant_cd_wk 				varchar(10);		-- プラントコード
	l_seizou_ln_cd				varchar(10);		-- 製造ラインコード
	l_seizou_ln_nm				varchar(64);		-- 製造ライン名
	l_process_cd				char(5);			-- 工程コード
	l_process_nm				varchar(64);		-- 工程名称
	l_ln_no						varchar(32);		-- ライン番号
	l_ln_nm						varchar(64);		-- ライン名称
	l_job_ptn_id				numeric;			-- 作業パターンID
	l_job_ptn_name				varchar(64);		-- 作業パターン名
	l_sasizu_no					char(12);			-- 指図番号
	l_sub_no					numeric;			-- 指図追番
	l_step_no					char(8);			-- 作業STEP
	l_standard_manhour			int;				-- 標準工数
	l_work_manhour_average		numeric;			-- 実績平均
	l_standard_deviation		numeric;			-- 標準偏差
	l_parameter					int;				-- 母数

	----------------------------------------------------------------------------
	--						カーソル定義
	----------------------------------------------------------------------------
	-- 工場マスタ
	CUR_MA_PLANT	CURSOR FOR
		SELECT
			PLANT_CD					as plantCd,
			RUNNING_START_DATETIME		as runningStartDatetime
		FROM
			MA_PLANT
		--WHERE
		--	INVALID_FLAG = 0
		ORDER BY
			PLANT_CD
	;

	OPENFLG_MA_PLANT	int;	-- カーソルオープン状態

	-- 作業ログ(作業用)
	CUR_TR_WORK_STEP_JSK	CURSOR FOR
		SELECT
			T0.SASIZU_NO,
			T0.SUB_NO,
			T6.JOB_PTN_ID,
			T0.STEP_NO,
			T0.SEIZOU_LN_CD,
			T0.SEIZOU_LN_NM,
			T0.PROCESS_CD,
			T0.PROCESS_NM,
			T0.LN_NO,
			T0.LN_NM,
			T5.JOB_PTN_NAME,
			COALESCE(CASE T0.SAGYO_MODE
				WHEN CST_SAGYO_MODE_LOW		THEN CAST(AVG(T6.STD_HOUR_HIGH) as integer)
				WHEN CST_SAGYO_MODE_MIDDLE	THEN CAST(AVG(T6.STD_HOUR_MIDDLE) as integer)
				WHEN CST_SAGYO_MODE_HIGH	THEN CAST(AVG(T6.STD_HOUR_LOW) as integer)
				else 0
			END, 0)					as standardManhour,
			AVG(T0.WORK_TIME)		as workManhourAverage,
			STDDEV(T0.WORK_TIME)	as standardDeviation,
			COUNT(*)				as parameter
		FROM
			TR_WORK_STEP_JSK	T0
		INNER JOIN
			TR_SASIZU_INFO	T1
		ON
			T0.SASIZU_NO	= T1.SASIZU_NO
		INNER JOIN
			MA_STATION	T3
		ON
				T0.ST_ID		= T3.ST_ID
		--	AND	T3.INVALID_FLAG	= 0
		INNER JOIN
			TR_SASIZU_MAN	T4
		ON
			T0.SASIZU_NO	= T4.SASIZU_NO
		INNER JOIN
		(
			SELECT
				SUB.*
			FROM
			(
				SELECT
					*,
					ROW_NUMBER() OVER (PARTITION BY PROC_MAN_ID, LN_ID ORDER BY MODIFIED_ON DESC, JOB_PTN_ID DESC) as rowIndex
				FROM
					MA_MES_WORK_STEP
			) SUB
			WHERE
				SUB.rowIndex = 1
		) T5
		ON
				T4.PROC_MAN_ID	= T5.PROC_MAN_ID
			AND	T3.LN_ID		= T5.LN_ID
		--	AND	T5.INVALID_FLAG	= 0
		INNER JOIN
			MA_MES_WK_STEP_DTL	T6
		ON
				T5.JOB_PTN_ID	= T6.JOB_PTN_ID
			AND	T0.STEP_NO		= T6.STEP_NO
		WHERE
				T0.PLANT_CD	=	l_plant_cd_wk
			AND	T0.END_TIME	>=	l_proc_start_time
			AND	T0.END_TIME	<=	l_proc_end_time
		GROUP BY
			T0.SASIZU_NO,
			T0.SUB_NO,
			T6.JOB_PTN_ID,
			T0.STEP_NO,
			T0.SEIZOU_LN_CD,
			T0.SEIZOU_LN_NM,
			T0.PROCESS_CD,
			T0.PROCESS_NM,
			T0.LN_NO,
			T0.LN_NM,
			T0.SAGYO_MODE,
			T5.JOB_PTN_NAME
	;

	OPENFLG_TR_WORK_STEP_JSK		int;	-- カーソルオープン状態

	-- 作業工数実績(日別)
	CUR_AG_WORK_MANHOUR_MNG_DAILY	CURSOR FOR
		SELECT
			*
		FROM
			AG_WORK_MANHOUR_MNG_DAILY
		WHERE
				SASIZU_NO	= l_sasizu_no
			AND	SUB_NO		= l_sub_no
			AND	JOB_PTN_ID	= l_job_ptn_id
			AND	STEP_NO		= l_step_no
			AND	DATA_DATE	= l_proc_start_time
		FOR UPDATE NOWAIT
	;

	OPENFLG_AG_WORK_MANHOUR_MNG_DAILY		int;	-- カーソルオープン状態
	REC_AG_WORK_MANHOUR_MNG_DAILY			AG_WORK_MANHOUR_MNG_DAILY%ROWTYPE;

BEGIN
	----------------------------------------------------------------------------
	--						初期処理
	----------------------------------------------------------------------------
	raise info 'Start Function [%]', clock_timestamp()::timestamp;

	-- 共通変数初期化
	l_err_pnt		:= RTRIM(cst_MY_PRG) || '_S001';

	-- 共通出力パラメータ初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
	o_ret_cd	:= RET_OK;
	o_sqlerr	:= ' ';
	o_errmsg	:= ' ';
	o_errpnt	:= ' ';

	-- 関数実行日時
	l_exec_datetime := clock_timestamp();

	-- 集計開始/終了日時補正
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
	IF i_from_time IS NULL THEN
		i_from_time := l_exec_datetime;
	END IF;
	IF i_to_time IS NULL OR i_from_time > i_to_time THEN
		i_to_time := l_exec_datetime;
	END IF;

	-- カーソルオープン状態初期化
	OPENFLG_MA_PLANT := CST_FALSE;
	OPENFLG_TR_WORK_STEP_JSK := CST_FALSE;
	OPENFLG_AG_WORK_MANHOUR_MNG_DAILY := CST_FALSE;

	----------------------------------------------------------------------------
	-- メイン処理
	----------------------------------------------------------------------------
	<< MAIN_LOOP >>
	LOOP

		------------------------------------------------------------------------
		-- 工場ごとに稼働開始日時が異なるので、工場マスタで処理を回す
		------------------------------------------------------------------------
		-- 工場マスタを開いているならクローズ
		l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
		IF OPENFLG_MA_PLANT = CST_TRUE THEN
			CLOSE CUR_MA_PLANT;
			OPENFLG_MA_PLANT := CST_FALSE;
		END IF;

		-- 工場マスタをオープン
		l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
		OPEN CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_TRUE;

		<< PLANT_LOOP >>
		LOOP
			-- 工場マスタからフェッチ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
			FETCH CUR_MA_PLANT INTO l_plant_cd_wk, l_running_start_datetime;
			IF FOUND = FALSE THEN
				EXIT PLANT_LOOP;
			END IF;

			IF l_running_start_datetime IS NULL THEN
				-- NULLの場合はデフォルト値をセット
				l_err_pnt := RTRIM(cst_MY_PRG) || '_301';
				l_running_start_datetime = timestamp '0001-03-21 07:00:00';
			END IF;

			-- 処理開始日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_202';
			SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_all;
			<< START_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_302';
				IF i_from_time >= l_proc_start_time_all THEN
					EXIT START_TIME_LOOP;
				END IF;
				l_proc_start_time_all := l_proc_start_time_all + interval '-1 days';
			END LOOP	START_TIME_LOOP;

			-- 処理終了日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_203';
			SELECT l_proc_start_time_all + interval '1 days' + interval '-1 milliseconds' INTO l_proc_end_time_all;
			<< END_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_303';
				IF i_to_time <= l_proc_end_time_all THEN
					EXIT END_TIME_LOOP;
				END IF;
				l_proc_end_time_all := l_proc_end_time_all + interval '1 days';
			END LOOP	END_TIME_LOOP;

			-- 処理開始/終了日時
			l_err_pnt := RTRIM(cst_MY_PRG) || '_204';
			l_proc_start_time := l_proc_start_time_all;
			l_proc_end_time := l_proc_start_time + interval '1 days' + interval '-1 milliseconds';

			<< TIME_LOOP >>
			LOOP

				-- 作業ログ(作業用)を開いているならクローズ
				IF OPENFLG_TR_WORK_STEP_JSK = CST_TRUE THEN
					CLOSE CUR_TR_WORK_STEP_JSK;
					OPENFLG_TR_WORK_STEP_JSK := CST_FALSE;
				END IF;

				-- 作業ログ(作業用)オープン
				l_err_pnt := RTRIM(cst_MY_PRG) || '_304';
				OPEN CUR_TR_WORK_STEP_JSK;
				OPENFLG_TR_WORK_STEP_JSK := CST_TRUE;

				<< WORK_LOG_WK_LOOP >>
				LOOP
					-- 作業ログ(作業用)フェッチ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_401';
					FETCH CUR_TR_WORK_STEP_JSK INTO l_sasizu_no, l_sub_no, l_job_ptn_id, l_step_no, l_seizou_ln_cd, l_seizou_ln_nm, l_process_cd, l_process_nm, l_ln_no, l_ln_nm, l_job_ptn_name, l_standard_manhour, l_work_manhour_average, l_standard_deviation, l_parameter;
					IF FOUND = FALSE THEN
						EXIT WORK_LOG_WK_LOOP;
					END IF;

					-- 標準偏差がNULLの場合は、0を設定する
					-- 母数が1の場合にNULLとして計算される
					IF (l_standard_deviation IS NULL) = TRUE
					THEN
						l_standard_deviation := 0;
					END IF;

					-- 作業工数実績(日別)に既に集計データが存在するかを確認
					-- 作業工数実績(日別)を開いているならクローズ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_402';
					IF OPENFLG_AG_WORK_MANHOUR_MNG_DAILY = CST_TRUE THEN
						CLOSE CUR_AG_WORK_MANHOUR_MNG_DAILY;
						OPENFLG_AG_WORK_MANHOUR_MNG_DAILY := CST_FALSE;
					END IF;

					-- 作業工数実績(日別)をオープン
					l_err_pnt := RTRIM(cst_MY_PRG) || '_403';
					OPEN CUR_AG_WORK_MANHOUR_MNG_DAILY;
					OPENFLG_AG_WORK_MANHOUR_MNG_DAILY := CST_TRUE;

					-- 作業工数実績(日別)からフェッチ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_404';
					FETCH CUR_AG_WORK_MANHOUR_MNG_DAILY INTO REC_AG_WORK_MANHOUR_MNG_DAILY;
					IF FOUND = FALSE THEN

						-- 作業工数実績(日別)に格納
						l_err_pnt := RTRIM(cst_MY_PRG) || '_501';
						INSERT INTO AG_WORK_MANHOUR_MNG_DAILY
						(
							  SASIZU_NO								-- 指図番号
							, SUB_NO								-- 指図追番
							, JOB_PTN_ID							-- 作業パターンID
							, STEP_NO								-- 作業ステップ番号
							, DATA_DATE								-- データ日付
							, SEIZOU_LN_CD							-- 製造ラインコード
							, SEIZOU_LN_NM							-- 製造ライン名
							, PROCESS_CD							-- 工程コード
							, PROCESS_NM							-- 工程名称
							, LN_NO 								-- ラインNo
							, LN_NM 								-- ライン名称
							, JOB_PTN_NAME							-- 作業パターン名
							, STANDARD_MANHOUR						-- 標準工数
							, WORK_MANHOUR_AVERAGE					-- 実績平均
							, STANDARD_DEVIATION					-- 標準偏差
							, PARAMETER								-- 母数
							, INS_PROG								-- 登録プログラム名
							, INS_TIM								-- 登録日時
							, INS_USER_SID							-- 登録ユーザSID
							, UPD_PROG								-- 更新プログラム名
							, UPD_TIM								-- 更新日時
							, UPD_USER_SID							-- 更新ユーザSID
						)
						VALUES
						(
							  l_sasizu_no							-- 指図番号
							, l_sub_no								-- 指図追番
							, l_job_ptn_id							-- 作業パターンID
							, l_step_no								-- 作業ステップ番号
							, l_proc_start_time						-- データ日付
							, l_seizou_ln_cd						-- 製造ラインコード
							, l_seizou_ln_nm						-- 製造ライン名
							, l_process_cd							-- 工程コード
							, l_process_nm							-- 工程名称
							, l_ln_no 								-- ラインNo
							, l_ln_nm 								-- ライン名称
							, l_job_ptn_name						-- 作業パターン名
							, l_standard_manhour					-- 標準工数
							, l_work_manhour_average				-- 実績平均
							, l_standard_deviation					-- 標準偏差
							, l_parameter							-- 母数
							, cst_MY_PRG							-- 登録プログラム
							, l_exec_datetime						-- 登録日時
							, i_user_sid							-- 登録ユーザSID
							, cst_MY_PRG							-- 更新プログラム
							, l_exec_datetime						-- 更新日時
							, i_user_sid							-- 更新ユーザSID
						);
					ELSE
						-- 作業工数実績(日別)を更新
						l_err_pnt := RTRIM(cst_MY_PRG) || '_502';
						UPDATE AG_WORK_MANHOUR_MNG_DAILY SET
							  SEIZOU_LN_CD			= l_seizou_ln_cd			-- 製造ラインコード
							, SEIZOU_LN_NM			= l_seizou_ln_nm			-- 製造ライン名
							, PROCESS_CD			= l_process_cd				-- 工程コード
							, PROCESS_NM			= l_process_nm				-- 工程名称
							, LN_NO					= l_ln_no					-- ラインNo
							, LN_NM					= l_ln_nm					-- ライン名称
							, JOB_PTN_NAME			= l_job_ptn_name			-- 作業パターン名
							, STANDARD_MANHOUR		= l_standard_manhour		-- 標準工数
							, WORK_MANHOUR_AVERAGE	= l_work_manhour_average	-- 実績平均
							, STANDARD_DEVIATION	= l_standard_deviation		-- 標準偏差
							, PARAMETER				= l_parameter				-- 母数
							, UPD_PROG				= cst_MY_PRG				-- 更新プログラム
							, UPD_TIM				= l_exec_datetime			-- 更新日時
							, UPD_USER_SID			= i_user_sid				-- 更新ユーザSID
						WHERE CURRENT OF CUR_AG_WORK_MANHOUR_MNG_DAILY;
					END IF;

				END LOOP	WORK_LOG_WK_LOOP;

				-- 次の処理日時を設定
				l_proc_start_time	:= l_proc_start_time + interval '1 days';
				l_proc_end_time		:= l_proc_end_time + interval '1 days';

				-- 処理開始日時が処理終了日時(全体)を超えている場合は処理終了
				IF l_proc_end_time_all < l_proc_start_time THEN
					EXIT TIME_LOOP;
				END IF;

			END LOOP	TIME_LOOP;

		END LOOP	PLANT_LOOP;

		EXIT MAIN_LOOP;
	END LOOP	MAIN_LOOP;

	----------------------------------------------------------------------------
	--						終了処理
	----------------------------------------------------------------------------
	-- カーソルクローズ
	l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
	IF OPENFLG_MA_PLANT = CST_TRUE THEN
		CLOSE CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E002';
	IF OPENFLG_TR_WORK_STEP_JSK = CST_TRUE THEN
		CLOSE CUR_TR_WORK_STEP_JSK;
		OPENFLG_TR_WORK_STEP_JSK := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
	IF OPENFLG_AG_WORK_MANHOUR_MNG_DAILY = CST_TRUE THEN
		CLOSE CUR_AG_WORK_MANHOUR_MNG_DAILY;
		OPENFLG_AG_WORK_MANHOUR_MNG_DAILY := CST_FALSE;
	END IF;

	raise info 'End Function [%]', clock_timestamp()::timestamp;

EXCEPTION WHEN OTHERS THEN
	-- DB例外情報収集
	GET STACKED DIAGNOSTICS rtn_sql_no     = RETURNED_SQLSTATE,
							rtn_sql_msg    = MESSAGE_TEXT,
							rtn_sql_detail = PG_EXCEPTION_DETAIL,
							rtn_sql_hint   = PG_EXCEPTION_HINT,
							rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

	raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
	raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

	o_ret_cd := RET_NG;
	o_sqlerr := substr(rtn_sql_no, 1, 15);
	o_errmsg := substr(rtn_sql_msg, 1, 127);
	o_errpnt := l_err_pnt;

	raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;
