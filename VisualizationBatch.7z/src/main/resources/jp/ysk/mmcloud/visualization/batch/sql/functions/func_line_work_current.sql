CREATE or REPLACE FUNCTION func_line_work_current(
	in	i_batch_name	varchar,			-- バッチ処理名称
	in	i_log_type		numeric,			-- ログ種別(開始、および　各バッチ処理の復帰値)
											-- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
	in	i_user_sid		numeric,			-- 登録ユーザSID
	in	i_from_time		timestamp,			-- 集計開始日時(空の場合は当日を対象とする)
	in	i_to_time		timestamp,			-- 集計終了日時(空の場合は当日を対象とする)
	out	o_ret_cd		int,				-- 関数復帰値	RET_OK(= 0):正常終了
	out	o_sqlerr		varchar,			-- ＤＢ異常発生時のエラーコード
	out	o_errmsg		varchar,			-- 異常発生時のエラーメッセージ
	out	o_errpnt		varchar				-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　ライン予定/実績/計画(現状)作成サービス
--　ソースプログラム名　：　func_line_work_current.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　ライン予定/実績/計画(現状)を作成する
--
--　履歴
--	Ver.  作成日			作成者		COMMENT
--	1.0   2016/12/05	H.Nakamura	新規作成
--	1.1   2016/12/15	J.Ito		計画系設定値の登録追加
--  1.2   2017/08/01	ThanhDM		DB変更対応
--******************************************************************************
DECLARE
	----------------------------------------------------------------------------
	--						標準定数定義
	----------------------------------------------------------------------------
	-- 戻り値
	RET_OK		CONSTANT int := 0 ;						-- 正常終了コード
	RET_NG		CONSTANT int := -1 ;					-- 異常終了コード
	-- 真偽値
	CST_TRUE	CONSTANT int := 1 ;						-- 真
	CST_FALSE	CONSTANT int := 0 ;						-- 偽

	----------------------------------------------------------------------------
	--						標準変数定義
	----------------------------------------------------------------------------
	cst_MY_PRG	CONSTANT CHAR(32)	 := 'func_line_work_current';			-- プログラム名
	cst_UPD_TIM	CHAR(17) ;													-- 更新時間
	l_err_pnt	CHAR(64) ;													-- エラー発生ポイント
	errbuff		varchar(256);												-- メッセージバッファ

	----------------------------------------------------------------------------
	--						定数定義
	----------------------------------------------------------------------------
	CST_BATCH_FLG				CONSTANT int		:= 1;		-- バッチ処理フラグ
	CST_ALL_LN_ID				CONSTANT int		:= -1;		-- ラインID
	CST_ALL_ST_ID				CONSTANT int		:= -1;		-- ステーションID

	----------------------------------------------------------------------------
	--						変数定義
	----------------------------------------------------------------------------
	-- 共通変数
	rtn_sql_no		text;							-- DBエラー情報(エラー番号)
	rtn_sql_msg		text;							-- DBエラー情報(エラーメッセージ)
	rtn_sql_detail	text;							-- DBエラー情報(エラー詳細)
	rtn_sql_hint	text;							-- DBエラー情報(エラーヒント)
	rtn_sql_stack	text;							-- DBエラー情報(エラー発生呼出しスタック)

	-- ローカル変数
	l_exec_datetime					timestamp;		-- 関数実行日時
	l_proc_start_time				timestamp;		-- 処理開始日
	l_proc_end_time					timestamp;		-- 処理終了日
	l_proc_start_time_all			timestamp;		-- 処理開始日(全体)
	l_proc_end_time_all				timestamp;		-- 処理終了日(全体)
	l_running_start_datetime		timestamp;		-- 稼働開始日時(年度開始日時)

	l_ln_id							numeric(8);		-- ラインID
	l_plant_cd						char(10);		-- 工場コード
	l_upd_date						timestamp;		-- 更新日時
	l_upd_date_wk					timestamp;		-- 更新日時
	l_schedule_num					int;			-- 予測数
	l_actual_num					int;			-- 実績数
	l_actual_num_wk					int;			-- 実績数(作業用)
	l_plan_num						int;			-- 計画数
	l_plan_num_wk					int;			-- 計画数(当日)(作業用)
	l_plan_num_1_wk					int;			-- 計画数(前日)(作業用)
	l_plan_num_2_wk					int;			-- 計画数(前々日)(作業用)
	l_current_datetime				timestamp;		-- 現在日時
	l_prediction_completion_time	timestamp;		-- 完了時刻(予測)
	l_plan_completion_time			timestamp;		-- 完了時刻(計画)
	l_pre_retention_num				int;			-- ライン前の滞留数
	l_retention_num					int;			-- ライン内の滞留数
	l_after_retention_num			int; 			-- ライン後の滞留数
	l_product_record_count			int;			-- 製品生産計画実績チェック用カウント
	l_line_trace_log_num			int;			-- ライントレースログ数
	l_btw_lines_trace_log_num1		int;			-- ライン間トレースログ数
	l_btw_lines_trace_log_num2		int;			-- ライン間トレースログ数
	l_actual_check_num				int;			-- 製造ラインごとの実績が上がっているライン数
	-- v1.01 add
	l_plan_tmp_num					int;			-- 計画データから算出した場合の計画台数

	----------------------------------------------------------------------------
	--						カーソル定義
	----------------------------------------------------------------------------
	--------------------------------------------------
	-- マスタ
	--------------------------------------------------
	-- 工場マスタ
	CUR_MA_PLANT	CURSOR FOR
		SELECT
			PLANT_CD					as plantCd,
			RUNNING_START_DATETIME		as runningStartDatetime
		FROM
			MA_PLANT
		--WHERE
		--	INVALID_FLAG = 0
		ORDER BY
			PLANT_CD
	;

	OPENFLG_MA_PLANT	int;	-- カーソルオープン状態

	-- ラインマスタ
	CUR_MA_LINE	CURSOR FOR
		SELECT
			T0.LN_ID
		FROM
			MA_LINE T0
		INNER JOIN
			MA_PROCESS T1
		ON
				T0.PROCESS_ID 	= T1.PROCESS_ID
		--	AND	T1.INVALID_FLAG	= 0
		INNER JOIN
			MA_SEIZOU_LINE T2
		ON
				T1.SEIZOU_LN_ID = T2.SEIZOU_LN_ID
		--	AND	T2.INVALID_FLAG	= 0
		WHERE
				T2.PLANT_CD		= l_plant_cd
		--	AND	T0.INVALID_FLAG	= 0
		ORDER BY
			T0.LN_ID
	;

	OPENFLG_MA_LINE		int;	-- カーソルオープン状態


	--------------------------------------------------
	-- 実績数/計画数
	--------------------------------------------------
	-- 製品生産計画実績(日別)から実績数と計画数を取得する
	-- ※CONSTRAINT ag_product_mng_daily_pri PRIMARY KEY (seizou_ln_id, ln_id, st_id, buhin_cd, data_date, vtext_info1)
	-- 　条件がユニークになっているので、1レコード分しか取得されない
	CUR_AG_PRODUCT_MNG_DAILY CURSOR FOR
		SELECT
			  SUM(ACTUAL_THE_DAY_NUM)
			, SUM(PLAN_THE_DAY_NUM)
			, SUM(PLAN_BEFORE_THE_DAY_NUM)
			, SUM(PLAN_BEFORE_TWO_DAYS_NUM)
			, MAX(UPD_DATE)
		FROM
			AG_PRODUCT_MNG_DAILY
		WHERE
				LN_ID			= l_ln_id
			AND	ST_ID			= CST_ALL_ST_ID
			AND	DATA_DATE		= l_proc_start_time
		GROUP BY
			SEIZOU_LN_ID, LN_ID, ST_ID, BUHIN_CD, DATA_DATE, VTEXT_INFO1
	;

	OPENFLG_AG_PRODUCT_MNG_DAILY		int;	-- カーソルオープン状態


	--------------------------------------------------
	-- 滞留数
	--------------------------------------------------
	-- 該当時間にデータがあるかチェック
	CUR_LINE_WORK_JSK_CHECK	CURSOR FOR
		SELECT
			T1.lineTraceLogNum,
			T2.btwLinesTraceLogNum,
			T3.btwLinesTraceLogNum
		FROM
		(
			SELECT
				COUNT(*) as lineTraceLogNum
			FROM
				TR_LINE_WORK_JSK
			WHERE
				LN_ID = l_ln_id
			GROUP BY
				LN_ID
		) T1,
		(
			SELECT
				COUNT(*) as btwLinesTraceLogNum
			FROM
				TR_LINE_TM_INFO
			WHERE
				N_LN_ID = l_ln_id
			GROUP BY
				LN_ID
		) T2,
		(
			SELECT
				COUNT(*) as btwLinesTraceLogNum
			FROM
				TR_LINE_TM_INFO
			WHERE
				LN_ID = l_ln_id
			GROUP BY
				LN_ID
		) T3
	;

	OPENFLG_LINE_WORK_JSK_CHECK	int;	-- カーソルオープン状態


	-- ライントレースログサマリー(ライン内の滞留数)
	CUR_LINE_WORK_JSK_SUMMARY_RETENTION	CURSOR FOR
		SELECT
			MAX(T.modifiedOn),
			SUM(T.retentionNum)
		FROM
		(
			SELECT
				T0.LN_ID			as lnId,
				MAX(T0.MODIFIED_ON)	as modifiedOn,
				COUNT(*)			as retentionNum
			FROM
			(
				SELECT
					SUB0.*
				FROM
					TR_LINE_WORK_JSK SUB0
				WHERE
					EXISTS (
						SELECT
							1
						FROM
							TR_LINE_WORK_JSK SUB1
						WHERE
								SUB0.SASIZU_NO	= SUB1.SASIZU_NO
							AND	SUB0.SUB_NO		= SUB1.SUB_NO
							AND	SUB0.SAGYO_SEQ	= SUB1.SAGYO_SEQ
							AND	SUB0.LN_ID		= SUB1.LN_ID
						GROUP BY
							SUB1.SASIZU_NO,
							SUB1.SUB_NO,
							SUB1.SAGYO_SEQ,
							SUB1.LN_ID
						HAVING
							MAX(SUB1.REPAIR_KAISU) = SUB0.REPAIR_KAISU
					)
			) T0
			INNER JOIN
				TR_SASIZU_INFO	T1
			ON
				T1.SASIZU_NO			=	T0.SASIZU_NO
			INNER JOIN
				TR_SASIZU_JSK	T2
			ON
					T2.SASIZU_NO		=	T1.SASIZU_NO
				AND	T2.SEISAN_JYOTAI	>=	0
				AND	T2.SEISAN_JYOTAI	<	90
			WHERE
					T0.LN_ID			=	l_ln_id
				AND	T0.START_TIME		<=	l_current_datetime
				AND	(
						T0.END_TIME		IS NULL
					OR	T0.END_TIME		> l_current_datetime
				)
			GROUP BY
				T0.LN_ID

		UNION ALL

			SELECT
				T0.N_LN_ID			as lnId,
				MAX(T0.MODIFIED_ON)	as modifiedOn,
				COUNT(*)			as retentionNum
			FROM
			(
				SELECT
					SUB0.*
				FROM
					TR_LINE_TM_INFO SUB0
				WHERE
					EXISTS (
						SELECT
							1
						FROM
							TR_LINE_TM_INFO SUB1
						WHERE
								SUB0.SASIZU_NO	= SUB1.SASIZU_NO
							AND	SUB0.SUB_NO		= SUB1.SUB_NO
							AND	SUB0.SAGYO_SEQ	= SUB1.SAGYO_SEQ
							AND	SUB0.LN_ID		= SUB1.LN_ID
						GROUP BY
							SUB1.SASIZU_NO,
							SUB1.SUB_NO,
							SUB1.SAGYO_SEQ,
							SUB1.LN_ID
						HAVING
							MAX(SUB1.REPAIR_KAISU) = SUB0.REPAIR_KAISU
					)
			) T0
			INNER JOIN
				TR_SASIZU_INFO	T1
			ON
				T1.SASIZU_NO			=	T0.SASIZU_NO
			INNER JOIN
				TR_SASIZU_JSK	T2
			ON
					T2.SASIZU_NO		=	T1.SASIZU_NO
				AND	T2.SEISAN_JYOTAI	>=	0
				AND	T2.SEISAN_JYOTAI	<	90
			WHERE
					T0.N_LN_ID			=	l_ln_id
				AND	T0.LN_ID			=	T0.N_LN_ID
				AND	T0.END_TIME			<=	l_current_datetime
				AND
				(
						T0.START_TIME	IS NULL
					OR	T0.START_TIME	> l_current_datetime
				)
			GROUP BY
				T0.N_LN_ID
		) T
		GROUP BY
			T.lnId
	;

	OPENFLG_LINE_WORK_JSK_SUMMARY_RETENTION	int;	-- カーソルオープン状態


	-- ライン間トレースログサマリー(ライン前の滞留数)
	CUR_LINE_TM_INFO_SUMMARY_PRE_RETENTION CURSOR FOR
		SELECT
			MAX(T0.MODIFIED_ON),
			COUNT(*)
		FROM
		(
			SELECT
				SUB0.*
			FROM
				TR_LINE_TM_INFO SUB0
			WHERE
				EXISTS (
					SELECT
						1
					FROM
						TR_LINE_TM_INFO SUB1
					WHERE
							SUB0.SASIZU_NO	= SUB1.SASIZU_NO
						AND	SUB0.SUB_NO		= SUB1.SUB_NO
						AND	SUB0.SAGYO_SEQ	= SUB1.SAGYO_SEQ
						AND	SUB0.LN_ID		= SUB1.LN_ID
					GROUP BY
						SUB1.SASIZU_NO,
						SUB1.SUB_NO,
						SUB1.SAGYO_SEQ,
						SUB1.LN_ID
					HAVING
						MAX(SUB1.REPAIR_KAISU) = SUB0.REPAIR_KAISU
				)
		) T0
		INNER JOIN
			TR_SASIZU_INFO	T1
		ON
			T1.SASIZU_NO			=	T0.SASIZU_NO
		INNER JOIN
			TR_SASIZU_JSK	T2
		ON
				T2.SASIZU_NO		=	T1.SASIZU_NO
			AND	T2.SEISAN_JYOTAI	>=	0
			AND	T2.SEISAN_JYOTAI	<	90
		WHERE
				T0.N_LN_ID			=	l_ln_id
			AND	T0.LN_ID			=	T0.N_LN_ID
			AND	T0.END_TIME			<=	l_current_datetime
			AND
			(
					T0.START_TIME	IS NULL
				OR	T0.START_TIME	> l_current_datetime
			)
			AND	(
					T0.SAGYO_SEQ	IS NULL
				OR	T0.SAGYO_SEQ	= '0'
			)
		GROUP BY
			T0.N_LN_ID
	;

	OPENFLG_LINE_TM_INFO_SUMMARY_PRE_RETENTION int;	-- カーソルオープン状態


	-- ライン間トレースログサマリー(ライン後の滞留数)
	CUR_LINE_TM_INFO_SUMMARY_AFTER_RETENTION	CURSOR FOR
		SELECT
			MAX(T0.MODIFIED_ON),
			COUNT(*)
		FROM
		(
			SELECT
				SUB0.*
			FROM
				TR_LINE_TM_INFO SUB0
			WHERE
				EXISTS (
					SELECT
						1
					FROM
						TR_LINE_TM_INFO SUB1
					WHERE
							SUB0.SASIZU_NO	= SUB1.SASIZU_NO
						AND	SUB0.SUB_NO		= SUB1.SUB_NO
						AND	SUB0.SAGYO_SEQ	= SUB1.SAGYO_SEQ
						AND	SUB0.LN_ID		= SUB1.LN_ID
					GROUP BY
						SUB1.SASIZU_NO,
						SUB1.SUB_NO,
						SUB1.SAGYO_SEQ,
						SUB1.LN_ID
					HAVING
						MAX(SUB1.REPAIR_KAISU) = SUB0.REPAIR_KAISU
				)
		) T0
		INNER JOIN
			TR_SASIZU_INFO	T1
		ON
			T1.SASIZU_NO			=	T0.SASIZU_NO
		INNER JOIN
			TR_SASIZU_JSK	T2
		ON
				T2.SASIZU_NO		=	T1.SASIZU_NO
			AND	T2.SEISAN_JYOTAI	>=	0
			AND	T2.SEISAN_JYOTAI	<	90
		WHERE
				T0.LN_ID			=	l_ln_id
			AND	T0.LN_ID			!=	T0.N_LN_ID
			AND	T0.END_TIME			<=	l_current_datetime
			AND
			(
					T0.START_TIME	IS NULL
				OR	T0.START_TIME	> l_current_datetime
			)
		GROUP BY
			T0.LN_ID
	;

	OPENFLG_LINE_TM_INFO_SUMMARY_AFTER_RETENTION		int;	-- カーソルオープン状態


	--------------------------------------------------
	-- ライン予定/実績/計画(現状)
	--------------------------------------------------
	CUR_AG_LINE_WORK_CURRENT	CURSOR FOR
		SELECT
			*
		FROM
			AG_LINE_WORK_CURRENT
		WHERE
			LN_ID = l_ln_id
		FOR UPDATE NOWAIT
	;

	OPENFLG_AG_LINE_WORK_CURRENT		int;	-- カーソルオープン状態
	REC_AG_LINE_WORK_CURRENT			AG_LINE_WORK_CURRENT%ROWTYPE;

BEGIN
	----------------------------------------------------------------------------
	--						初期処理
	----------------------------------------------------------------------------
	raise info 'Start Function [%]', clock_timestamp()::timestamp;

	-- 共通変数初期化
	l_err_pnt		:= RTRIM(cst_MY_PRG) || '_S001';

	-- 共通出力パラメータ初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
	o_ret_cd	:= RET_OK;
	o_sqlerr	:= ' ';
	o_errmsg	:= ' ';
	o_errpnt	:= ' ';

	-- 関数実行日時
	l_exec_datetime := clock_timestamp();

	-- 集計開始/終了日時補正
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
	IF (i_from_time IS NULL) OR (l_exec_datetime < i_from_time) THEN
		i_from_time := l_exec_datetime;
	END IF;
	IF (i_to_time IS NULL) OR (l_exec_datetime < i_to_time) OR (i_from_time > i_to_time) THEN
		i_to_time := l_exec_datetime;
	END IF;

	-- ローカル変数初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
	l_actual_num		:= -1;
	l_plan_num			:= -1;
	l_retention_num		:= -1;
	l_pre_retention_num	:= -1;
	OPENFLG_MA_PLANT := CST_FALSE;
	OPENFLG_MA_LINE := CST_FALSE;
	OPENFLG_AG_PRODUCT_MNG_DAILY := CST_FALSE;
	OPENFLG_LINE_WORK_JSK_CHECK := CST_FALSE;
	OPENFLG_LINE_WORK_JSK_SUMMARY_RETENTION := CST_FALSE;
	OPENFLG_LINE_TM_INFO_SUMMARY_PRE_RETENTION := CST_FALSE;
	OPENFLG_LINE_TM_INFO_SUMMARY_AFTER_RETENTION := CST_FALSE;
	OPENFLG_AG_LINE_WORK_CURRENT := CST_FALSE;

	----------------------------------------------------------------------------
	-- メイン処理
	----------------------------------------------------------------------------
	<< MAIN_LOOP >>
	LOOP

		------------------------------------------------------------------------
		-- 工場ごとに稼働開始日時が異なるので、工場マスタで処理を回す
		------------------------------------------------------------------------
		-- 工場マスタを開いているならクローズ
		l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
		IF OPENFLG_MA_PLANT = CST_TRUE THEN
			CLOSE CUR_MA_PLANT;
			OPENFLG_MA_PLANT := CST_FALSE;
		END IF;

		-- 工場マスタをオープン
		l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
		OPEN CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_TRUE;

		<< PLANT_LOOP >>
		LOOP
			-- 工場マスタからフェッチ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_103';
			FETCH CUR_MA_PLANT INTO l_plant_cd, l_running_start_datetime;
			IF FOUND = FALSE THEN
				EXIT PLANT_LOOP;
			END IF;

			IF l_running_start_datetime IS NULL THEN
				-- NULLの場合はデフォルト値をセット
				l_err_pnt := RTRIM(cst_MY_PRG) || '_104';
				l_running_start_datetime = timestamp '0001-03-21 07:00:00';
			END IF;

			-- 処理開始日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_105';
			SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_all;
			<< START_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_106';
				IF i_from_time >= l_proc_start_time_all THEN
					EXIT START_TIME_LOOP;
				END IF;
				l_proc_start_time_all := l_proc_start_time_all + interval '-1 days';
			END LOOP	START_TIME_LOOP;

			-- 処理終了日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_107';
			SELECT l_proc_start_time_all + interval '1 days' + interval '-1 milliseconds' INTO l_proc_end_time_all;
			<< END_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_108';
				IF i_to_time <= l_proc_end_time_all THEN
					EXIT END_TIME_LOOP;
				END IF;
				l_proc_end_time_all := l_proc_end_time_all + interval '1 days';
			END LOOP	END_TIME_LOOP;

			l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
			-- ラインマスタを開いているならクローズ
			IF OPENFLG_MA_LINE = CST_TRUE THEN
				CLOSE CUR_MA_LINE;
				OPENFLG_MA_LINE := CST_FALSE;
			END IF;

			-- ラインマスタをオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_202';
			OPEN CUR_MA_LINE;
			OPENFLG_MA_LINE := CST_TRUE;

			<< LINE_LOOP >>
			LOOP

				-- ラインマスタのカーソルからフェッチする
				l_err_pnt := RTRIM(cst_MY_PRG) || '_203';
				FETCH CUR_MA_LINE INTO l_ln_id;
				IF FOUND = FALSE THEN
					EXIT LINE_LOOP;
				END IF;

				-- 処理開始/終了日時
				l_err_pnt := RTRIM(cst_MY_PRG) || '_204';
				l_proc_start_time := l_proc_start_time_all;
				l_proc_end_time := l_proc_start_time + interval '1 days' + interval '-1 milliseconds';

				<< TIME_LOOP >>
				LOOP
					IF (l_exec_datetime >= l_proc_start_time) AND
					   (l_exec_datetime <= l_proc_end_time)
					THEN
						-- 当日の場合、現在日時は関数実行日時
						l_current_datetime := l_exec_datetime;
					ELSE
						-- 過去の場合、現在日時は処理最終日時
						l_current_datetime := l_proc_end_time;
					END IF;

					------------------------------------------------------------
					-- 実績数/計画数
					------------------------------------------------------------
					-- 製品生産計画実績(日別)を開いているならクローズ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_301';
					IF OPENFLG_AG_PRODUCT_MNG_DAILY = CST_TRUE THEN
						CLOSE CUR_AG_PRODUCT_MNG_DAILY;
						OPENFLG_AG_PRODUCT_MNG_DAILY := CST_FALSE;
					END IF;

					-- 製品生産計画実績(日別)をオープン
					l_err_pnt := RTRIM(cst_MY_PRG) || '_302';
					OPEN CUR_AG_PRODUCT_MNG_DAILY;
					OPENFLG_AG_PRODUCT_MNG_DAILY := CST_TRUE;

					-- 初期化
					l_err_pnt := RTRIM(cst_MY_PRG) || '_303';
					l_actual_num			:= -1;
					l_plan_num				:= -1;
					l_upd_date				:= l_proc_start_time;
					l_product_record_count	:= 0;

					<< AG_PRODUCT_MNG_DAILY_LOOP >>
					LOOP
						-- 製品生産計画実績(日別)からフェッチ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_304';
						FETCH CUR_AG_PRODUCT_MNG_DAILY INTO l_actual_num_wk, l_plan_num_wk, l_plan_num_1_wk, l_plan_num_2_wk, l_upd_date_wk;
						IF FOUND = FALSE THEN
							l_err_pnt := RTRIM(cst_MY_PRG) || '_305';
							-- レコードが一つもない場合は、該当ラインにデータなしとして作成
							IF l_product_record_count = 0 THEN
								l_err_pnt := RTRIM(cst_MY_PRG) || '_306';
								l_actual_num	:= -1;
								l_plan_num		:= -1;
								l_upd_date		:= l_proc_start_time;
							END IF;
							EXIT AG_PRODUCT_MNG_DAILY_LOOP;
						END IF;

						-- 実績数計算
						l_err_pnt := RTRIM(cst_MY_PRG) || '_307';
						IF l_actual_num_wk != -1 THEN
							l_err_pnt := RTRIM(cst_MY_PRG) || '_308';
							IF l_actual_num = -1 THEN
								l_actual_num := l_actual_num_wk;
							ELSE
								l_actual_num := l_actual_num + l_actual_num_wk;
							END IF;
						END IF;

						-- 計画数計算
						-- 当日
						l_err_pnt := RTRIM(cst_MY_PRG) || '_309';
						IF l_plan_num_wk != -1 THEN
							l_err_pnt := RTRIM(cst_MY_PRG) || '_310';
							IF l_plan_num = -1 THEN
								l_plan_num := l_plan_num_wk;
							ELSE
								l_plan_num := l_plan_num + l_plan_num_wk;
							END IF;
						END IF;

						-- 前日
						l_err_pnt := RTRIM(cst_MY_PRG) || '_311';
						IF l_plan_num_1_wk != -1 THEN
							l_err_pnt := RTRIM(cst_MY_PRG) || '_312';
							IF l_plan_num = -1 THEN
								l_plan_num := l_plan_num_1_wk;
							ELSE
								l_plan_num := l_plan_num + l_plan_num_1_wk;
							END IF;
						END IF;

						-- 前々日
						l_err_pnt := RTRIM(cst_MY_PRG) || '_313';
						IF l_plan_num_2_wk != -1 THEN
							l_err_pnt := RTRIM(cst_MY_PRG) || '_314';
							IF l_plan_num = -1 THEN
								l_plan_num := l_plan_num_2_wk;
							ELSE
								l_plan_num := l_plan_num + l_plan_num_2_wk;
							END IF;
						END IF;

						-- 更新日時
						l_err_pnt := RTRIM(cst_MY_PRG) || '_317';
						IF  l_upd_date_wk IS NOT NULL AND  l_upd_date_wk >  l_upd_date THEN
							l_err_pnt := RTRIM(cst_MY_PRG) || '_318';
							 l_upd_date :=  l_upd_date_wk;
						END IF;

						-- 処理数インクリメント
						l_err_pnt := RTRIM(cst_MY_PRG) || '_319';
						l_product_record_count := l_product_record_count + 1;
					END LOOP	AG_PRODUCT_MNG_DAILY_LOOP;

					------------------------------------------------------------
					-- 予定数/完了時刻(予測)/完了時刻(計画)
					------------------------------------------------------------
					l_err_pnt := RTRIM(cst_MY_PRG) || '_404';
					-- MMsFでは計画系がないので、値なし
					l_schedule_num := -1;
					l_prediction_completion_time := null;
					l_plan_completion_time := null;

					------------------------------------------------------------
					-- 滞留数
					------------------------------------------------------------
					-- 該当ラインのデータがあるかチェック
					-- ある場合のみ滞留数の集計を行う
					l_err_pnt := RTRIM(cst_MY_PRG) || '_501';
					IF OPENFLG_LINE_WORK_JSK_CHECK = CST_TRUE THEN
						CLOSE CUR_LINE_WORK_JSK_CHECK;
						OPENFLG_LINE_WORK_JSK_CHECK := CST_FALSE;
					END IF;

					l_err_pnt := RTRIM(cst_MY_PRG) || '_502';
					OPEN CUR_LINE_WORK_JSK_CHECK;
					OPENFLG_LINE_WORK_JSK_CHECK := CST_TRUE;

					l_err_pnt := RTRIM(cst_MY_PRG) || '_503';
					FETCH CUR_LINE_WORK_JSK_CHECK INTO
						l_line_trace_log_num,
						l_btw_lines_trace_log_num1,
						l_btw_lines_trace_log_num2;

					l_err_pnt := RTRIM(cst_MY_PRG) || '_504';
					IF FOUND = FALSE THEN
						-- データがない
						l_err_pnt := RTRIM(cst_MY_PRG) || '_505';
						l_retention_num			:= -1;
						l_pre_retention_num		:= -1;
						l_after_retention_num	:= -1;
					ELSE

						IF l_line_trace_log_num > 0 OR l_btw_lines_trace_log_num1 > 0 OR l_btw_lines_trace_log_num2 > 0 THEN
							--[note]
							-- ラインデータはあるが実績数が-1の場合は、0にする
							-- -1のほうが良い場合は以下のコードを削除する
							IF l_actual_num = -1 THEN
								l_actual_num := 0;
							END IF;
						END IF;

						------------------------------------------------------------
						-- ライン内の滞留数
						------------------------------------------------------------
						IF l_line_trace_log_num IS NULL OR l_line_trace_log_num = 0 THEN
							l_retention_num		:= -1;
						ELSE
							-- ライントレースログ(ライン内の滞留数)を開いているならクローズ
							l_err_pnt := RTRIM(cst_MY_PRG) || '_601';
							IF OPENFLG_LINE_WORK_JSK_SUMMARY_RETENTION = CST_TRUE THEN
								CLOSE CUR_LINE_WORK_JSK_SUMMARY_RETENTION;
								OPENFLG_LINE_WORK_JSK_SUMMARY_RETENTION := CST_FALSE;
							END IF;

							l_err_pnt := RTRIM(cst_MY_PRG) || '_602';
							OPEN CUR_LINE_WORK_JSK_SUMMARY_RETENTION;
							OPENFLG_LINE_WORK_JSK_SUMMARY_RETENTION := CST_TRUE;

							l_err_pnt := RTRIM(cst_MY_PRG) || '_603';
							FETCH CUR_LINE_WORK_JSK_SUMMARY_RETENTION INTO l_upd_date_wk, l_retention_num;
							IF FOUND = FALSE THEN
								l_err_pnt := RTRIM(cst_MY_PRG) || '_604';
								-- [note]
								-- サマリーした結果データが見つからなかった場合、0にする。
								-- -1に変更する場合、ここを変更したらよい。
								l_retention_num := 0;
							ELSE
								l_err_pnt := RTRIM(cst_MY_PRG) || '_607';
								IF ( l_upd_date IS NULL AND  l_upd_date_wk IS NOT NULL) OR ( l_upd_date <  l_upd_date_wk) THEN
									l_err_pnt := RTRIM(cst_MY_PRG) || '_608';
									 l_upd_date :=  l_upd_date_wk;
								END IF;
							END IF;
						END IF;

						------------------------------------------------------------
						-- ライン前の滞留数
						------------------------------------------------------------
						IF l_btw_lines_trace_log_num IS NULL OR l_btw_lines_trace_log_num = 0 THEN
							l_pre_retention_num	:= -1;
						ELSE
							-- ライントレースログ(ライン内の滞留数)を開いているならクローズ
							l_err_pnt := RTRIM(cst_MY_PRG) || '_701';
							IF OPENFLG_LINE_TM_INFO_SUMMARY_PRE_RETENTION = CST_TRUE THEN
								CLOSE CUR_LINE_TM_INFO_SUMMARY_PRE_RETENTION;
								OPENFLG_LINE_TM_INFO_SUMMARY_PRE_RETENTION := CST_FALSE;
							END IF;

							l_err_pnt := RTRIM(cst_MY_PRG) || '_702';
							OPEN CUR_LINE_TM_INFO_SUMMARY_PRE_RETENTION;
							OPENFLG_LINE_TM_INFO_SUMMARY_PRE_RETENTION := CST_TRUE;

							l_err_pnt := RTRIM(cst_MY_PRG) || '_703';
							FETCH CUR_LINE_TM_INFO_SUMMARY_PRE_RETENTION INTO
								l_upd_date_wk,
								l_pre_retention_num;
							IF FOUND = FALSE THEN
								-- [note]
								-- サマリーした結果データが見つからなかった場合、0にする。
								-- -1に変更する場合、ここを変更したらよい。
								l_pre_retention_num := 0;
							ELSE
								l_err_pnt := RTRIM(cst_MY_PRG) || '_706';
								IF ( l_upd_date IS NULL AND  l_upd_date_wk IS NOT NULL) OR ( l_upd_date <  l_upd_date_wk) THEN
									l_err_pnt := RTRIM(cst_MY_PRG) || '_707';
									 l_upd_date :=  l_upd_date_wk;
								END IF;
							END IF;
						END IF;

						------------------------------------------------------------
						-- ライン後の滞留数
						------------------------------------------------------------
						IF l_btw_lines_trace_log_num2 IS NULL OR l_btw_lines_trace_log_num2 = 0 THEN
							l_after_retention_num	:= -1;
						ELSE
							-- ライントレースログ(ライン後の滞留数)を開いているならクローズ
							l_err_pnt := RTRIM(cst_MY_PRG) || '_708';
							IF OPENFLG_LINE_TM_INFO_SUMMARY_AFTER_RETENTION = CST_TRUE THEN
								CLOSE CUR_LINE_TM_INFO_SUMMARY_AFTER_RETENTION;
								OPENFLG_LINE_TM_INFO_SUMMARY_AFTER_RETENTION := CST_FALSE;
							END IF;

							l_err_pnt := RTRIM(cst_MY_PRG) || '_709';
							OPEN CUR_LINE_TM_INFO_SUMMARY_AFTER_RETENTION;
							OPENFLG_LINE_TM_INFO_SUMMARY_AFTER_RETENTION := CST_TRUE;

							l_err_pnt := RTRIM(cst_MY_PRG) || '_710';
							FETCH CUR_LINE_TM_INFO_SUMMARY_AFTER_RETENTION INTO l_upd_date_wk, l_after_retention_num;
							IF FOUND = FALSE THEN
								-- [note]
								-- サマリーした結果データが見つからなかった場合、0にする。
								-- -1に変更する場合、ここを変更したらよい。
								l_after_retention_num := 0;
							ELSE
								l_err_pnt := RTRIM(cst_MY_PRG) || '_713';
								IF (l_upd_date IS NULL AND l_upd_date_wk IS NOT NULL) OR (l_upd_date < l_upd_date_wk) THEN
									l_err_pnt := RTRIM(cst_MY_PRG) || '_714';
									l_upd_date := l_upd_date_wk;
								END IF;
							END IF;
						END IF;

						-- データが入っていない場合は初期値を入れる
						l_err_pnt := RTRIM(cst_MY_PRG) || '_507';
						IF  l_upd_date IS NULL THEN
							 l_upd_date := l_proc_start_time;
						END IF;

					END IF;

					------------------------------------------------------------
					-- ライン予定/実績/計画(現状)に格納
					------------------------------------------------------------
					-- ライン予定/実績/計画(現状)を開いているならクローズ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_901';
					IF OPENFLG_AG_LINE_WORK_CURRENT = CST_TRUE THEN
						CLOSE CUR_AG_LINE_WORK_CURRENT;
						OPENFLG_AG_LINE_WORK_CURRENT := CST_FALSE;
					END IF;

					l_err_pnt := RTRIM(cst_MY_PRG) || '_902';
					-- ライン予定/実績/計画(現状)をオープン
					OPEN CUR_AG_LINE_WORK_CURRENT;
					OPENFLG_AG_LINE_WORK_CURRENT := CST_TRUE;

					l_err_pnt := RTRIM(cst_MY_PRG) || '_903';
					-- ライン予定/実績/計画(現状)に格納
					FETCH CUR_AG_LINE_WORK_CURRENT INTO REC_AG_LINE_WORK_CURRENT;
					IF FOUND = FALSE THEN
						-- データがない場合
						l_err_pnt := RTRIM(cst_MY_PRG) || '_904';
						INSERT INTO AG_LINE_WORK_CURRENT
						(
							LN_ID, 							-- ラインID
							UPD_DATE, 						-- 更新日時
							SCHEDULE_NUM, 					-- 予定数
							ACTUAL_NUM, 					-- 実績数
							PLAN_NUM, 						-- 計画数
							PREDICTION_COMPLETION_TIME, 	-- 完了時刻(予測)
							PLAN_COMPLETION_TIME, 			-- 完了時刻(計画)
							PRE_RETENTION_NUM, 				-- ライン前の滞留数
							RETENTION_NUM, 					-- ライン内の滞留数
							AFTER_RETENTION_NUM, 			-- ライン後の滞留数
							INS_PROG, 						-- 登録プログラム名
							INS_TIM, 						-- 登録日時
							INS_USER_SID, 					-- 登録ユーザSID
							UPD_PROG, 						-- 更新プログラム名
							UPD_TIM, 						-- 更新日時
							UPD_USER_SID 					-- 更新ユーザSID
						)
						VALUES
						(
							l_ln_id, 						-- ラインID
							l_upd_date, 					-- 更新日時
							l_schedule_num, 				-- 予定数
							l_actual_num, 					-- 実績数
							l_plan_num, 					-- 計画数
							l_prediction_completion_time, 	-- 完了時刻(予測)
							l_plan_completion_time, 		-- 完了時刻(計画)
							l_pre_retention_num, 			-- ライン前の滞留数
							l_retention_num, 				-- ライン内の滞留数
							l_after_retention_num, 			-- ライン後の滞留数
							cst_MY_PRG,						-- 登録プログラム
							l_exec_datetime,				-- 登録日時
							i_user_sid,						-- 登録ユーザSID
							cst_MY_PRG,						-- 更新プログラム
							l_exec_datetime,				-- 更新日時
							i_user_sid						-- 更新ユーザSID
						);
					ELSE
						l_err_pnt := RTRIM(cst_MY_PRG) || '_905';
						UPDATE
							AG_LINE_WORK_CURRENT
						SET
							  UPD_DATE						= l_upd_date					-- 更新日時
							, SCHEDULE_NUM					= l_schedule_num				-- 予定数
							, ACTUAL_NUM					= l_actual_num					-- 実績数
							, PLAN_NUM						= l_plan_num					-- 計画数
							, PREDICTION_COMPLETION_TIME	= l_prediction_completion_time	-- 完了時刻(予測)
							, PLAN_COMPLETION_TIME			= l_plan_completion_time		-- 完了時刻(計画)
							, PRE_RETENTION_NUM				= l_pre_retention_num			-- ライン前の滞留数
							, RETENTION_NUM					= l_retention_num				-- ライン内の滞留数
							, AFTER_RETENTION_NUM			= l_after_retention_num 		-- ライン後の滞留数
							, UPD_PROG						= cst_MY_PRG					-- 更新プログラム
							, UPD_TIM						= l_exec_datetime				-- 更新日時
							, UPD_USER_SID					= i_user_sid					-- 更新ユーザSID
						WHERE CURRENT OF CUR_AG_LINE_WORK_CURRENT;
					END IF;

					-- 次の処理日時を設定
					l_proc_start_time	:= l_proc_start_time + interval '1 days';
					l_proc_end_time		:= l_proc_end_time + interval '1 days';

					-- 処理開始日時が処理終了日時(全体)を超えている場合は処理終了
					IF l_proc_end_time_all < l_proc_start_time THEN
						EXIT TIME_LOOP;
					END IF;

				END LOOP	TIME_LOOP;

			END LOOP	LINE_LOOP;

		END LOOP	PLANT_LOOP;

		EXIT MAIN_LOOP;
	END LOOP	MAIN_LOOP;

	----------------------------------------------------------------------------
	--						終了処理
	----------------------------------------------------------------------------
	-- カーソルクローズ
	l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
	IF OPENFLG_MA_PLANT = CST_TRUE THEN
		CLOSE CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E002';
	IF OPENFLG_MA_LINE = CST_TRUE THEN
		CLOSE CUR_MA_LINE;
		OPENFLG_MA_LINE := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
	IF OPENFLG_AG_PRODUCT_MNG_DAILY = CST_TRUE THEN
		CLOSE CUR_AG_PRODUCT_MNG_DAILY;
		OPENFLG_AG_PRODUCT_MNG_DAILY := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E004';
	IF OPENFLG_LINE_WORK_JSK_CHECK = CST_TRUE THEN
		CLOSE CUR_LINE_WORK_JSK_CHECK;
		OPENFLG_LINE_WORK_JSK_CHECK := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E005';
	IF OPENFLG_LINE_WORK_JSK_SUMMARY_RETENTION = CST_TRUE THEN
		CLOSE CUR_LINE_WORK_JSK_SUMMARY_RETENTION;
		OPENFLG_LINE_WORK_JSK_SUMMARY_RETENTION := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E006';
	IF OPENFLG_LINE_TM_INFO_SUMMARY_PRE_RETENTION = CST_TRUE THEN
		CLOSE CUR_LINE_TM_INFO_SUMMARY_PRE_RETENTION;
		OPENFLG_LINE_TM_INFO_SUMMARY_PRE_RETENTION := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E007';
	IF OPENFLG_AG_LINE_WORK_CURRENT = CST_TRUE THEN
		CLOSE CUR_AG_LINE_WORK_CURRENT;
		OPENFLG_AG_LINE_WORK_CURRENT := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E008';
	IF OPENFLG_LINE_TM_INFO_SUMMARY_AFTER_RETENTION = CST_TRUE THEN
		CLOSE CUR_LINE_TM_INFO_SUMMARY_AFTER_RETENTION;
		OPENFLG_LINE_TM_INFO_SUMMARY_AFTER_RETENTION := CST_FALSE;
	END IF;

	raise info 'End Function [%]', clock_timestamp()::timestamp;

EXCEPTION WHEN OTHERS THEN
	-- DB例外情報収集
	GET STACKED DIAGNOSTICS rtn_sql_no	   = RETURNED_SQLSTATE,
							rtn_sql_msg    = MESSAGE_TEXT,
							rtn_sql_detail = PG_EXCEPTION_DETAIL,
							rtn_sql_hint   = PG_EXCEPTION_HINT,
							rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

	raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
	raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

	o_ret_cd := RET_NG;
	o_sqlerr := substr(rtn_sql_no, 1, 15);
	o_errmsg := substr(rtn_sql_msg, 1, 127);
	o_errpnt := l_err_pnt;

	raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;
