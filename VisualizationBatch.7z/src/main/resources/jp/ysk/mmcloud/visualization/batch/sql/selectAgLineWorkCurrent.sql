SELECT
    ln_id,
    upd_date,
    schedule_num,
    actual_num,
    plan_num,
    prediction_completion_time,
    plan_completion_time,
    pre_retention_num,
    retention_num,
    after_retention_num,
    ins_prog,
    ins_tim,
    ins_user_sid,
    upd_prog,
    upd_tim,
    upd_user_sid

FROM
    ag_line_work_current

/*BEGIN*/
WHERE
    /*IF addDatetime != null*/
        (ins_tim >= /*addDatetime*/ AND upd_tim is null)
    OR  upd_tim >= /*addDatetime*/
    /*END*/
/*END*/

ORDER BY
    COALESCE(upd_tim, ins_tim)
