UPDATE
    MA_USER
SET
    user_sid = T.sid,
    upd_prog = 'update-MA_USER',
    upd_tim  = now(),
    upd_user_sid = 0
FROM(
    SELECT
        sid,
        id
    FROM
        MST_USER
)T
WHERE
        MA_USER.user_id = T.id
    AND	MA_USER.user_id = ?
