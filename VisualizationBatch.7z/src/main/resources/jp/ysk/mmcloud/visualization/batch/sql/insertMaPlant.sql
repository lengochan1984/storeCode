WITH
	val AS (
		SELECT
			(	(
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*invalidFlag*/,
				/*plantCd*/,
				/*plantNm*/,
				/*plantSNm*/,
				/*plantAddr*/,
				/*companyCd*/,
				/*mailServer*/,
				/*mailAccount*/,
				/*mailPassword*/,
				/*timeAjustment*/,
				/*timeServer*/,
				/*erpHenkoDate*/,
				/*erpSakujyoFlg*/,
				/*runningStartDatetime*/,
				/*latitude*/,
				/*longitude*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
				'insert-MA_PLANT',
				now(),
				0,
				'insert-MA_PLANT',
				now(),
				0
				)::MA_PLANT).*
	),

	upd AS (
		UPDATE
			MA_PLANT
		SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			invalid_flag		= /*invalidFlag*/,
			plant_nm			= /*plantNm*/,
			plant_s_nm			= /*plantSNm*/,
			plant_addr			= /*plantAddr*/,
			company_cd			= /*companyCd*/,
			mail_server			= /*mailServer*/,
			mail_account		= /*mailAccount*/,
			mail_password		= /*mailPassword*/,
			time_ajustment		= CAST(/*timeAjustment*/ AS numeric),
			time_server			= /*timeServer*/,
			erp_henko_date		= CAST(/*erpHenkoDate*/ AS timestamp),
			erp_sakujyo_flg		= /*erpSakujyoFlg*/,
			running_start_datetime	= CAST(/*runningStartDatetime*/ AS timestamp),
			latitude			= CAST(/*latitude*/ AS numeric),
			longitude			= CAST(/*longitude*/ AS numeric),
			spare_num1			= CAST(/*spareNum1*/ AS numeric),
			spare_num2			= CAST(/*spareNum2*/ AS numeric),
			spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-MA_PLANT',
			upd_tim 			= now(),
			upd_user_sid		= 0
		FROM
			val
		WHERE
			MA_PLANT.plant_cd = /*plantCd*/

		RETURNING
			MA_PLANT.plant_cd
	)

INSERT INTO
	MA_PLANT
SELECT
	*
FROM
	val
WHERE
	(plant_cd)
		NOT IN (SELECT plant_cd FROM upd);
