WITH
    val AS (
        SELECT
            (   (
                /*createdOn*/,
                /*createdBy*/,
                /*modifiedOn*/,
                /*modifiedBy*/,
				/*mainResNo*/,
				/*plantCd*/,
				/*eventTime*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*processCd*/,
				/*processNm*/,
				/*lnNo*/,
				/*lnNm*/,
				/*stNo*/,
				/*stNm*/,
				/*onlineFlg*/,
				/*stsCd*/,
				/*almCd*/,
				/*mainteSkdCnt*/,
				/*mainteCnt*/,
				/*uptime*/,
                /*spareNum1*/,
                /*spareNum2*/,
                /*spareNum3*/,
                /*spareText1*/,
                /*spareText2*/,
                /*spareText3*/,
                'insert-TR_EQUIP_STS_LOG_WK',
                now(),
                0,
                'insert-TR_EQUIP_STS_LOG_WK',
                now(),
                0
                )::TR_EQUIP_STS_LOG_WK).*
    ),

    upd AS (
        UPDATE
            TR_EQUIP_STS_LOG_WK
        SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
			process_cd			= /*processCd*/,
			process_nm			= /*processNm*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			st_no				= /*stNo*/,
			st_nm				= /*stNm*/,
			online_flg			= CAST(/*onlineFlg*/ AS decimal),
			sts_cd				= /*stsCd*/,
			alm_cd				= /*almCd*/,
			mainte_skd_cnt		= CAST(/*mainteSkdCnt*/ AS numeric),
			mainte_cnt			= CAST(/*mainteCnt*/ AS numeric),
			uptime				= CAST(/*uptime*/ AS numeric),
            spare_num1			= CAST(/*spareNum1*/ AS numeric),
            spare_num2			= CAST(/*spareNum2*/ AS numeric),
            spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
            upd_prog            = 'update-TR_EQUIP_STS_LOG_WK',
            upd_tim             = now(),
            upd_user_sid        = 0
        FROM
            val
        WHERE
            TR_EQUIP_STS_LOG_WK.main_res_no		= /*mainResNo*/
        AND TR_EQUIP_STS_LOG_WK.plant_cd		= /*plantCd*/
        AND TR_EQUIP_STS_LOG_WK.event_time		= /*eventTime*/

        RETURNING
            TR_EQUIP_STS_LOG_WK.main_res_no,
            TR_EQUIP_STS_LOG_WK.plant_cd,
            TR_EQUIP_STS_LOG_WK.event_time
    )

INSERT INTO
    TR_EQUIP_STS_LOG_WK
SELECT
    *
FROM
    val
WHERE
    (main_res_no, plant_cd, event_time)
        NOT IN (SELECT main_res_no, plant_cd, event_time FROM upd);