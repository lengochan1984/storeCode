WITH
	val AS (
		SELECT
			(	(
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*invalidFlag*/,
				/*seizouLnId*/,
				/*plantCd*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*ctrlServerIp*/,
				/*ctrlServerPort*/,
				0,
				/*workStepEnd*/,
				/*procSeqChk*/,
				/*lnOverLn*/,
				/*sasizuRouteControl*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
				'insert-MA_SEIZOU_LINE',
				now(),
				0,
				'insert-MA_SEIZOU_LINE',
				now(),
				0
				)::MA_SEIZOU_LINE).*
	),

	upd AS (
		UPDATE
			MA_SEIZOU_LINE
		SET
			modified_on				= CAST(/*modifiedOn*/ AS timestamp),
			modified_by				= /*modifiedBy*/,
			invalid_flag			= /*invalidFlag*/,
			plant_cd				= /*plantCd*/,
			seizou_ln_cd			= /*seizouLnCd*/,
			seizou_ln_nm			= /*seizouLnNm*/,
			ctrl_server_ip			= /*ctrlServerIp*/,
			ctrl_server_port		= CAST(/*ctrlServerPort*/ AS numeric),
			work_step_end			= CAST(/*workStepEnd*/ AS smallint),
			proc_seq_chk			= CAST(/*procSeqChk*/ AS smallint),
			ln_over_ln				= CAST(/*lnOverLn*/ AS smallint),
			sasizu_route_control	= CAST(/*sasizuRouteControl*/ AS smallint),
			spare_num1				= CAST(/*spareNum1*/ AS numeric),
			spare_num2				= CAST(/*spareNum2*/ AS numeric),
			spare_num3				= CAST(/*spareNum3*/ AS numeric),
			spare_text1				= /*spareText1*/,
			spare_text2				= /*spareText2*/,
			spare_text3				= /*spareText3*/,
			upd_prog				= 'update-MA_SEIZOU_LINE',
			upd_tim					= now(),
			upd_user_sid			= 0
		FROM
			val
		WHERE
			MA_SEIZOU_LINE.seizou_ln_id = /*seizouLnId*/

		RETURNING
			MA_SEIZOU_LINE.seizou_ln_id
	)

INSERT INTO
	MA_SEIZOU_LINE
SELECT
	*
FROM
	val
WHERE
	(seizou_ln_id)
		NOT IN (SELECT seizou_ln_id FROM upd);
