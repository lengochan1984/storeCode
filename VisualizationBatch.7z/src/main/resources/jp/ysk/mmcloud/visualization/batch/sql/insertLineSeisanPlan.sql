WITH
    val AS (
        SELECT
            (   (
                now(),
                'insert-TR_LINE_SEISAN_PLAN',
                now(),
                'insert-TR_LINE_SEISAN_PLAN',
				/*seisanBi*/,
				/*lnId*/,
				/*lnNo*/,
				/*lnNm*/,
				/*seisanKeikaku*/,
				/*seisanYotei*/,
                /*spareNum1*/,
                /*spareNum2*/,
                /*spareNum3*/,
                /*spareText1*/,
                /*spareText2*/,
                /*spareText3*/,
                /*insProg*/,
                /*insTim*/,
                /*insUserSid*/,
                /*updProg*/,
                /*updTim*/,
                /*updUserSid*/
                )::TR_LINE_SEISAN_PLAN).*
    ),

    upd AS (
        UPDATE
            TR_LINE_SEISAN_PLAN
        SET
			modified_on         = now(),
			modified_by			= 'update-TR_LINE_SEISAN_PLAN',
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			seisan_keikaku		= CAST(/*seisanKeikaku*/ AS integer),
			seisan_yotei		= CAST(/*seisanYotei*/ AS integer),
            spare_num1			= CAST(/*spareNum1*/ AS numeric),
            spare_num2			= CAST(/*spareNum2*/ AS numeric),
            spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			ins_prog			= /*insProg*/,
			ins_tim				= CAST(/*insTim*/ AS timestamp),
			ins_user_sid		= CAST(/*insUserSid*/ AS integer),
			upd_prog			= /*updProg*/,
			upd_tim				= CAST(/*updTim*/ AS timestamp),
			upd_user_sid		= CAST(/*updUserSid*/ AS integer)
        FROM
            val
        WHERE
            TR_LINE_SEISAN_PLAN.seisan_bi	= /*seisanBi*/
        AND TR_LINE_SEISAN_PLAN.ln_id		= /*lnId*/

        RETURNING
            TR_LINE_SEISAN_PLAN.seisan_bi,
            TR_LINE_SEISAN_PLAN.ln_id
    )

INSERT INTO
    TR_LINE_SEISAN_PLAN
SELECT
    *
FROM
    val
WHERE
    (seisan_bi, ln_id)
        NOT IN (SELECT seisan_bi, ln_id FROM upd);
