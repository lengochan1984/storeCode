
WITH
    val AS (
        SELECT
            (   (
                /*createdOn*/,
                /*createdBy*/,
                /*modifiedOn*/,
                /*modifiedBy*/,
				/*sasizuNo*/,
				/*subNo*/,
				/*sagyoSeq*/,
				/*stId*/,
				/*stepNo*/,
				/*startTime*/,
				/*endTime*/,
				/*workTime*/,
				/*plantCd*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*processCd*/,
				/*processNm*/,
				/*lnNo*/,
				/*lnNm*/,
				/*stNo*/,
				/*stNm*/,
				/*sagyoku*/,
				/*pgmNo*/,
				/*userId*/,
				/*kiguFugou*/,
				/*partsMaterial*/,
				/*partsCode*/,
				/*partSn*/,
				/*torqueId*/,
				/*torqueCount*/,
				/*torqueNeedCount*/,
				/*testDevice*/,
				/*testDeviceRst*/,
				/*checkBox*/,
				/*senserNow*/,
				/*senserNext*/,
				/*logTypeId*/,
				/*logData*/,
				/*sagyoMode*/,
                /*spareNum1*/,
                /*spareNum2*/,
                /*spareNum3*/,
                /*spareText1*/,
                /*spareText2*/,
                /*spareText3*/,
                'insert-TR_WORK_STEP_JSK_WK',
                now(),
                0,
                'insert-TR_WORK_STEP_JSK_WK',
                now(),
                0
                )::TR_WORK_STEP_JSK_WK).*
    ),

    upd AS (
        UPDATE
            TR_WORK_STEP_JSK_WK
        SET
			modified_on         = CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			end_time			= CAST(/*endTime*/ AS timestamp),
			work_time			= CAST(/*workTime*/ AS numeric),
			plant_cd			= /*plantCd*/,
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
			process_cd			= /*processCd*/,
			process_nm			= /*processNm*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			st_no				= /*stNo*/,
			st_nm				= /*stNm*/,
			sagyoku				= /*sagyoku*/,
			pgm_no				= /*pgmNo*/,
			user_id				= /*userId*/,
			kigu_fugou			= /*kiguFugou*/,
			parts_material		= /*partsMaterial*/,
			parts_code			= /*partsCode*/,
			part_sn				= /*partSn*/,
			torque_id			= /*torqueId*/,
			torque_count		= CAST(/*torqueCount*/ AS numeric),
			torque_need_count	= CAST(/*torqueNeedCount*/ AS numeric),
			test_device			= /*testDevice*/,
			test_device_rst		= /*testDeviceRst*/,
			check_box			= /*checkBox*/,
			senser_now			= /*senserNow*/,
			senser_next			= /*senserNext*/,
			log_type_id			= /*logTypeId*/,
			log_data			= /*logData*/,
			sagyo_mode			= CAST(/*sagyoMode*/ AS numeric),
            spare_num1			= CAST(/*spareNum1*/ AS numeric),
            spare_num2			= CAST(/*spareNum2*/ AS numeric),
            spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog            = 'update-TR_WORK_STEP_JSK_WK',
            upd_tim             = now(),
            upd_user_sid        = 0
        FROM
            val
        WHERE
            TR_WORK_STEP_JSK_WK.sasizu_no		= /*sasizuNo*/
        AND TR_WORK_STEP_JSK_WK.sub_no			= /*subNo*/
        AND TR_WORK_STEP_JSK_WK.sagyo_seq		= /*sagyoSeq*/
        AND TR_WORK_STEP_JSK_WK.st_id			= /*stId*/
        AND TR_WORK_STEP_JSK_WK.step_no			= /*stepNo*/
        AND TR_WORK_STEP_JSK_WK.start_time		= /*startTime*/

        RETURNING
            TR_WORK_STEP_JSK_WK.sasizu_no,
            TR_WORK_STEP_JSK_WK.sub_no,
            TR_WORK_STEP_JSK_WK.sagyo_seq,
            TR_WORK_STEP_JSK_WK.st_id,
            TR_WORK_STEP_JSK_WK.step_no,
            TR_WORK_STEP_JSK_WK.start_time
    )

INSERT INTO
    TR_WORK_STEP_JSK_WK
SELECT
    *
FROM
    val
WHERE
    (sasizu_no, sub_no, sagyo_seq, st_id, step_no, start_time)
        NOT IN (SELECT sasizu_no, sub_no, sagyo_seq, st_id, step_no, start_time FROM upd);
