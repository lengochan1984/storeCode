SELECT
    CREATED_ON,
    CREATED_BY,
    COALESCE(MODIFIED_ON, CREATED_ON) AS MODIFIED_ON,
    COALESCE(MODIFIED_BY, CREATED_BY) AS MODIFIED_BY,
    ST_ID,
    ALM_CD,
    OCCURED_ON,
    RECOVERED_ON,
    TIME_DIFF,
    USER_ID,
    MAIN_RES_NO,
    MAIN_RES_NM,
    PLANT_CD,
    SEIZOU_LN_CD,
    SEIZOU_LN_NM,
    PROCESS_CD,
    PROCESS_NM,
    LN_NO,
    LN_NM,
    ST_NO,
    ST_NM,
    SAGYOKU,
    SPARE_NUM1,
    SPARE_NUM2,
    SPARE_NUM3,
    SPARE_TEXT1,
    SPARE_TEXT2,
    SPARE_TEXT3

FROM
    TR_EQUIP_ALM_JSK

/*BEGIN*/
WHERE
    /*IF addDatetime != null */
        (CREATED_ON >= /*addDatetime*/ AND MODIFIED_ON is null)
    OR  MODIFIED_ON >= /*addDatetime*/
    /*END*/
/*END*/

ORDER BY
    COALESCE(MODIFIED_ON, CREATED_ON)
