WITH
	val AS (
		SELECT
			(	(
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*invalidFlag*/,
				/*equipCd*/,
				/*almCd*/,
				/*almLevel*/,
				/*almMsg*/,
				/*almDetail*/,
				/*almGuide*/,
				/*almClrFlg*/,
				/*recoverFlg*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
				'insert-MA_EQUIP_ALM_CD',
				now(),
				0,
				'insert-MA_EQUIP_ALM_CD',
				now(),
				0
				)::MA_EQUIP_ALM_CD).*
	),

	upd AS (
		UPDATE
			MA_EQUIP_ALM_CD
		SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			invalid_flag		= /*invalidFlag*/,
			alm_level			= CAST(/*almLevel*/ AS numeric),
			alm_msg				= /*almMsg*/,
			alm_detail			= /*almDetail*/,
			alm_guide			= /*almGuide*/,
			alm_clr_flg			= CAST(/*almClrFlg*/ AS numeric),
			recover_flg			= CAST(/*recoverFlg*/ AS numeric),
			spare_num1			= CAST(/*spareNum1*/ AS numeric),
			spare_num2			= CAST(/*spareNum2*/ AS numeric),
			spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-MA_EQUIP_ALM_CD',
			upd_tim 			= now(),
			upd_user_sid		= 0
		FROM
			val
		WHERE
				MA_EQUIP_ALM_CD.equip_cd	= /*equipCd*/
			AND MA_EQUIP_ALM_CD.alm_cd		= /*almCd*/

		RETURNING
			MA_EQUIP_ALM_CD.equip_cd,
			MA_EQUIP_ALM_CD.alm_cd
	)

INSERT INTO
	MA_EQUIP_ALM_CD
SELECT
	*
FROM
	val
WHERE
	(equip_cd, alm_cd)
		NOT IN (SELECT equip_cd, alm_cd FROM upd);
