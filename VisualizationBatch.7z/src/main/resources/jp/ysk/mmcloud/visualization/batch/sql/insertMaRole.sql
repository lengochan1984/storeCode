WITH
	val AS (
		SELECT
			(	(
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*invalidFlag*/,
				/*roleCd*/,
				/*roleNm*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
				'insert-MA_ROLE',
				now(),
				0,
				'insert-MA_ROLE',
				now(),
				0
				)::MA_ROLE).*
	),

	upd AS (
		UPDATE
			MA_ROLE
		SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			invalid_flag		= /*invalidFlag*/,
			role_nm				= /*roleNm*/,
			spare_num1			= CAST(/*spareNum1*/ AS numeric),
			spare_num2			= CAST(/*spareNum2*/ AS numeric),
			spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-MA_ROLE',
			upd_tim 			= now(),
			upd_user_sid		= 0
		FROM
			val
		WHERE
			MA_ROLE.role_cd = /*roleCd*/

		RETURNING
			MA_ROLE.role_cd
	)

INSERT INTO
	MA_ROLE
SELECT
	*
FROM
	val
WHERE
	(role_cd)
		NOT IN (SELECT role_cd FROM upd);
