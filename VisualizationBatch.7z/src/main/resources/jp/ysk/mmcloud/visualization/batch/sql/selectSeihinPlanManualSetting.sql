SELECT
    t0.ln_id
  , t0.vtext_info1
  , t0.data_date
  , t0.sid
  , t0.display_order
  , t0.plan_num
  , t0.last_line_flag
  , t0.ins_prog
  , t0.ins_tim
  , t0.ins_user_sid
  , t0.upd_prog
  , t0.upd_tim
  , t0.upd_user_sid
FROM
    tr_seihin_plan_manual_setting t0
    INNER JOIN ma_line t1 ON t1.ln_id = t0.ln_id
    INNER JOIN ma_process t2 ON t2.process_id = t1.process_id
    INNER JOIN ma_seizou_line t3 ON t3.seizou_ln_id = t2.seizou_ln_id
    INNER JOIN ma_plant t4 ON t4.plant_cd = t3.plant_cd

WHERE
    t4.plant_cd = /*plantCd*/
    /*IF addDatetime != null */
    AND (
        t0.ins_tim >= /*addDatetime*/
    OR  t0.upd_tim >= /*addDatetime*/
    )
    /*END*/
ORDER BY
    t0.ln_id, t0.vtext_info1, t0.data_date
