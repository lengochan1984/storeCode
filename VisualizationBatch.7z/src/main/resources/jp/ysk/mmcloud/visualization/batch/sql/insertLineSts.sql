WITH
    val AS (
        SELECT
            (   (
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*lnId*/,
				/*onlineFlg*/,
				/*seisanFlg*/,
				/*lnStatus*/,
				/*menteMode*/,
				/*lnStsFrame*/,
				/*lnStsIcon*/,
                /*spareNum1*/,
                /*spareNum2*/,
                /*spareNum3*/,
                /*spareText1*/,
                /*spareText2*/,
                /*spareText3*/,
                'insert-TR_LINE_STS',
                now(),
                0,
                'insert-TR_LINE_STS',
                now(),
                0
                )::TR_LINE_STS).*
    ),

    upd AS (
        UPDATE
            TR_LINE_STS
        SET
			modified_on         = CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			online_flg			= CAST(/*onlineFlg*/ AS numeric),
			seisan_flg			= CAST(/*seisanFlg*/ AS numeric),
			ln_status			= CAST(/*lnStatus*/ AS numeric),
			mente_mode			= CAST(/*menteMode*/ AS numeric),
			ln_sts_frame		= CAST(/*lnStsFrame*/ AS integer),
			ln_sts_icon			= CAST(/*lnStsIcon*/ AS integer),
            spare_num1			= CAST(/*spareNum1*/ AS numeric),
            spare_num2			= CAST(/*spareNum2*/ AS numeric),
            spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-TR_LINE_STS',
			upd_tim				= now(),
			upd_user_sid		= 0

        FROM
            val
        WHERE
            TR_LINE_STS.ln_id   	= /*lnId*/

        RETURNING
            TR_LINE_STS.ln_id
    )

INSERT INTO
    TR_LINE_STS
SELECT
    *
FROM
    val
WHERE
    (ln_id)
        NOT IN (SELECT ln_id FROM upd);