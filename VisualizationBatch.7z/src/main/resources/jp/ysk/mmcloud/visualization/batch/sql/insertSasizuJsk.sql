
WITH
    val AS (
        SELECT
            (  (
                /*createdOn*/,
                /*createdBy*/,
                /*modifiedOn*/,
                /*modifiedBy*/,
				/*sasizuNo*/,
				/*sikanBi*/,
				/*sikanSu*/,
				/*sikanKbn*/,
				/*startDate*/,
				/*endDate*/,
				/*seisanJyotai*/,
				/*jyotaiHenkoDate*/,
				/*sekininsyaId*/,
				/*repairSu*/,
				/*lineChgFlg*/,
				/*tonyuSu*/,
                /*spareNum1*/,
                /*spareNum2*/,
                /*spareNum3*/,
                /*spareText1*/,
                /*spareText2*/,
                /*spareText3*/,
				'insert-TR_SASIZU_JSK',
                now(),
                0,
                'insert-TR_SASIZU_JSK',
                now(),
                0
                )::TR_SASIZU_JSK).*
    ),

    upd AS (
        UPDATE
            TR_SASIZU_JSK
        SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			sikan_bi			= /*sikanBi*/,
			sikan_su			= CAST(/*sikanSu*/ AS numeric),
			sikan_kbn			= /*sikanKbn*/,
			start_date			= CAST(/*startDate*/ AS timestamp),
			end_date			= CAST(/*endDate*/ AS timestamp),
			seisan_jyotai		= CAST(/*seisanJyotai*/ AS integer),
			jyotai_henko_date	= CAST(/*jyotaiHenkoDate*/ AS timestamp),
			sekininsya_id		= /*sekininsyaId*/,
			repair_su			= CAST(/*repairSu*/ AS numeric),
			line_chg_flg		= /*lineChgFlg*/,
			tonyu_su			= CAST(/*tonyuSu*/ AS numeric),
            spare_num1			= CAST(/*spareNum1*/ AS numeric),
            spare_num2			= CAST(/*spareNum2*/ AS numeric),
            spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-TR_SASIZU_JSK',
			upd_tim				= now(),
			upd_user_sid		= 0
        FROM
            val
        WHERE
            TR_SASIZU_JSK.sasizu_no = /*sasizuNo*/

        RETURNING
            TR_SASIZU_JSK.sasizu_no
    )

INSERT INTO
    TR_SASIZU_JSK
SELECT
    *
FROM
    val
WHERE
    (sasizu_no) NOT IN (SELECT sasizu_no FROM upd);