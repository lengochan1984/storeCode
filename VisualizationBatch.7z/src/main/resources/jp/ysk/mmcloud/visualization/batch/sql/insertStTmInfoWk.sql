WITH
    val AS (
        SELECT
            (   (
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*sasizuNo*/,
				/*subNo*/,
				/*sagyoSeq*/,
				/*repairKaisu*/,
				/*stId*/,
				/*plantCd*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*processCd*/,
				/*processNm*/,
				/*lnNo*/,
				/*lnNm*/,
				/*stNo*/,
				/*stNm*/,
				/*sagyoku*/,
				/*endTime*/,
				/*endStepNo*/,
				/*hantei*/,
				/*alarmMode*/,
				/*sagyoJyotai*/,
				/*sagyoKeka*/,
				/*nStartTime*/,
				/*nSeizouLnCd*/,
				/*nSeizouLnNm*/,
				/*nProcessCd*/,
				/*nProcessNm*/,
				/*nLnNo*/,
				/*nLnNm*/,
				/*nStId*/,
				/*nStNo*/,
				/*nStNm*/,
				/*nSagyoku*/,
				/*stopTime*/,
				/*stopTime2*/,
				/*nSagyoSeq*/,
				/*sousinFlag*/,
				/*sousinDate*/,
                /*spareNum1*/,
                /*spareNum2*/,
                /*spareNum3*/,
                /*spareText1*/,
                /*spareText2*/,
                /*spareText3*/,
                'insert-TR_ST_TM_INFO_WK',
                now(),
                0,
                'insert-TR_ST_TM_INFO_WK',
                now(),
                0
                )::TR_ST_TM_INFO_WK).*
    ),

    upd AS (
        UPDATE
            TR_ST_TM_INFO_WK
        SET
			modified_on         = CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			plant_cd			= /*plantCd*/,
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
			process_cd			= /*processCd*/,
			process_nm			= /*processNm*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			st_no				= /*stNo*/,
			st_nm				= /*stNm*/,
			sagyoku				= /*sagyoku*/,
			end_step_no			= /*endStepNo*/,
			hantei				= CAST(/*hantei*/ AS numeric),
			alarm_mode			= /*alarmMode*/,
			sagyo_jyotai		= CAST(/*sagyoJyotai*/ AS numeric),
			sagyo_keka			= CAST(/*sagyoKeka*/ AS numeric),
			n_start_time		= CAST(/*nStartTime*/ AS timestamp),
			n_seizou_ln_cd		= /*nSeizouLnCd*/,
			n_seizou_ln_nm		= /*nSeizouLnNm*/,
			n_process_cd		= /*nProcessCd*/,
			n_process_nm		= /*nProcessNm*/,
			n_ln_no				= /*nLnNo*/,
			n_ln_nm				= /*nLnNm*/,
			n_st_id				= CAST(/*nStId*/ AS numeric),
			n_st_no				= /*nStNo*/,
			n_st_nm				= /*nStNm*/,
			n_sagyoku			= /*nSagyoku*/,
			stop_time			= CAST(/*stopTime*/ AS numeric),
			stop_time2			= CAST(/*stopTime2*/ AS numeric),
			n_sagyo_seq			= /*nSagyoSeq*/,
			sousin_flag			= CAST(/*sousinFlag*/ AS numeric),
			sousin_date			= CAST(/*sousinDate*/ AS timestamp),
            spare_num1			= CAST(/*spareNum1*/ AS numeric),
            spare_num2			= CAST(/*spareNum2*/ AS numeric),
            spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
            upd_prog            = 'update-TR_ST_TM_INFO_WK',
            upd_tim             = now(),
            upd_user_sid        = 0
        FROM
            val
        WHERE
            TR_ST_TM_INFO_WK.sasizu_no		= /*sasizuNo*/
        AND TR_ST_TM_INFO_WK.sub_no			= /*subNo*/
        AND TR_ST_TM_INFO_WK.sagyo_seq		= /*sagyoSeq*/
        AND TR_ST_TM_INFO_WK.repair_kaisu	= /*repairKaisu*/
        AND TR_ST_TM_INFO_WK.st_id			= /*stId*/
        AND TR_ST_TM_INFO_WK.end_time		= /*endTime*/

        RETURNING
            TR_ST_TM_INFO_WK.sasizu_no,
            TR_ST_TM_INFO_WK.sub_no,
            TR_ST_TM_INFO_WK.sagyo_seq,
            TR_ST_TM_INFO_WK.repair_kaisu,
            TR_ST_TM_INFO_WK.st_id,
            TR_ST_TM_INFO_WK.end_time
    )

INSERT INTO
    TR_ST_TM_INFO_WK
SELECT
    *
FROM
    val
WHERE
   (sasizu_no, sub_no, sagyo_seq, repair_kaisu, st_id, end_time)
        NOT IN (SELECT sasizu_no, sub_no, sagyo_seq, repair_kaisu, st_id, end_time FROM upd);