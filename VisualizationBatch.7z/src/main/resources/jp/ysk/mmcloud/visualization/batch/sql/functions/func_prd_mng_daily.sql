CREATE or REPLACE FUNCTION func_prd_mng_daily(
	in	i_batch_name	varchar,			-- バッチ処理名称
	in	i_log_type		numeric,			-- ログ種別(開始、および　各バッチ処理の復帰値)
											-- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
	in	i_user_sid		numeric,			-- 登録ユーザSID
	in	i_from_time		timestamp,			-- 集計開始日時(空の場合は当日を対象とする)
	in	i_to_time		timestamp,			-- 集計終了日時(空の場合は当日を対象とする)
	out	o_ret_cd		int,				-- 関数復帰値	RET_OK(= 0):正常終了
	out	o_sqlerr		varchar,			-- ＤＢ異常発生時のエラーコード
	out	o_errmsg		varchar,			-- 異常発生時のエラーメッセージ
	out	o_errpnt		varchar				-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　製品生産計画実績(日別)作成サービス
--　ソースプログラム名　：　func_prd_mng_daily.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　製品生産計画実績(日別)を作成する
--
--　履歴
--  Ver.  作成日			作成者		COMMENT
--  1.0   2016/12/01		H.Nakamura	新規作成
--	1.1   2017/08/31		H.Nakamura	MMsF対応
--******************************************************************************
DECLARE
	----------------------------------------------------------------------------
	--						標準定数定義
	----------------------------------------------------------------------------
	-- 戻り値
	RET_OK		CONSTANT int := 0 ;						-- 正常終了コード
	RET_NG		CONSTANT int := -1 ;					-- 異常終了コード
	-- 真偽値
	CST_TRUE	CONSTANT int := 1 ;						-- 真
	CST_FALSE	CONSTANT int := 0 ;						-- 偽

	----------------------------------------------------------------------------
	--						標準変数定義
	----------------------------------------------------------------------------
	cst_MY_PRG	CONSTANT CHAR(32)	 := 'func_prd_mng_daily';				-- プログラム名
	cst_UPD_TIM	CHAR(17) ;													-- 更新時間
	l_err_pnt	CHAR(64) ;													-- エラー発生ポイント
	errbuff		varchar(256);												-- メッセージバッファ

	----------------------------------------------------------------------------
	--						定数定義
	----------------------------------------------------------------------------
	CST_PLANNING_SYSTEM_ENABLE	CONSTANT int		:= 1;		-- 計画系システム導入あり

	----------------------------------------------------------------------------
	--						変数定義
	----------------------------------------------------------------------------
	-- 共通変数
	rtn_sql_no		text;							-- DBエラー情報(エラー番号)
	rtn_sql_msg		text;							-- DBエラー情報(エラーメッセージ)
	rtn_sql_detail	text;							-- DBエラー情報(エラー詳細)
	rtn_sql_hint	text;							-- DBエラー情報(エラーヒント)
	rtn_sql_stack	text;							-- DBエラー情報(エラー発生呼出しスタック)

	-- ローカル変数
	l_exec_datetime					timestamp;		-- 関数実行日時
	l_proc_start_time				timestamp;		-- 処理開始日
	l_proc_end_time					timestamp;		-- 処理終了日
	l_proc_start_time_all			timestamp;		-- 処理開始日(全体)
	l_proc_end_time_all				timestamp;		-- 処理終了日(全体)
	l_running_start_datetime		timestamp;		-- 稼働開始日時(年度開始日時)
	l_planning_system				int;			-- 計画系システム導入状況
	l_plant_cd						char(10);		-- 工場コード
	l_plant_cd_wk 					char(10);		-- 工場コード
	l_seizou_ln_id					int;			-- 製造ラインID
	l_seizou_ln_id_wk				int;			-- 製造ラインID
	l_seizou_ln_cd					char(10);		-- 製造ラインコード
	l_seizou_ln_nm					char(64);		-- 製造ライン名
	l_process_cd					char(5);		-- 工程コード
	l_process_nm					char(64);		-- 工程名称
	l_ln_id							int;			-- ラインID
	l_ln_no							char(32);		-- ライン番号
	l_ln_nm							char(64);		-- ライン名称
	l_st_id							int;			-- ステーションID
	l_st_no							char(8);		-- ステーション番号
	l_st_nm							char(64);		-- ステーション名称
	l_buhin_cd						char(40);		-- 品目コード
	l_upd_date						timestamp;		-- 更新日時
	l_plan_the_day_num				int;			-- 計画(当日)台数
	l_plan_before_the_day_num		int;			-- 計画(前日)台数
	l_plan_before_two_days_num		int;			-- 計画(前日)台数
	l_actual_the_day_num			int;			-- 実績台数
	l_plan_the_day_value			int;			-- 計画(当日)金額
	l_plan_before_the_day_value		int;			-- 計画(前日)金額
	l_plan_before_two_days_value	int;			-- 計画(前日)金額
	l_actual_the_day_value			int;			-- 実績金額
	l_vtext_info1					varchar(40);	-- 品目階層TEXT_その1
	l_vtext_info2 					varchar(40);	-- 品目階層TEXT_その2

	----------------------------------------------------------------------------
	--						カーソル定義
	----------------------------------------------------------------------------
	-- 工場マスタ
	CUR_MA_PLANT	CURSOR FOR
		SELECT
			PLANT_CD					as plantCd,
			RUNNING_START_DATETIME		as runningStartDatetime
		FROM
			MA_PLANT
		--WHERE
		--	INVALID_FLAG = 0
		ORDER BY
			PLANT_CD
	;

	OPENFLG_MA_PLANT	int;	-- カーソルオープン状態

	-- 製品生産計画実績(日別)(クリア用)
	CUR_AG_PRODUCT_MNG_DAILY_CLEAR	CURSOR FOR
		SELECT
			*
		FROM
			AG_PRODUCT_MNG_DAILY
		WHERE
				PLANT_CD	=  l_plant_cd_wk
			AND	DATA_DATE	>= l_proc_start_time_all
			AND	DATA_DATE	<= l_proc_end_time_all
		FOR UPDATE NOWAIT
	;

	OPENFLG_AG_PRODUCT_MNG_DAILY_CLEAR	int;	-- カーソルオープン状態
	REC_AG_PRODUCT_MNG_DAILY_CLEAR		AG_PRODUCT_MNG_DAILY%ROWTYPE;

	-- 製造ラインマスタ
	CUR_MA_SEIZOU_LINE	CURSOR FOR
		SELECT
			SEIZOU_LN_ID	as seizouLnId,
		--	PLANNING_SYSTEM	as planningSystem
			0	as planningSystem		-- 計画系システム導入状況なし
		FROM
			MA_SEIZOU_LINE
		WHERE
				PLANT_CD		= l_plant_cd_wk
		--	AND	INVALID_FLAG	= 0
		ORDER BY
			SEIZOU_LN_ID
	;

	OPENFLG_MA_SEIZOU_LINE	int;	-- カーソルオープン状態

	-- 製品計画台数(手動設定)
	CUR_TR_SEIHIN_PLAN_MANUAL_SETTING	CURSOR FOR
		SELECT
			T3.SEIZOU_LN_ID		as seizouLnId,
			T0.LN_ID			as lnId,
			-1					as stId,
			''					as buhinCd,
			T0.VTEXT_INFO1		as vtextInfo1,
			''					as vtextInfo2,
			T3.PLANT_CD			as plantCd,
			T3.SEIZOU_LN_CD		as seizouLnCd,
			T3.SEIZOU_LN_NM		as seizouLnNm,
			T2.PROCESS_CD		as processCd,
			T2.PROCESS_NM		as processNm,
			T1.LN_NO			as lnNo,
			T1.LN_NM			as lnNm,
			NULL				as stNo,
			NULL				as stNm,
			MAX(T0.UPD_TIM)		as updDate,
			SUM(T0.PLAN_NUM)	as planTheDayNum,
			0					as planTheDayValue
		FROM
			TR_SEIHIN_PLAN_MANUAL_SETTING	T0
		INNER JOIN
			MA_LINE	T1
		ON
				T0.LN_ID		= T1.LN_ID
		--	AND	T1.INVALID_FLAG	= 0
		INNER JOIN
			MA_PROCESS	T2
		ON
				T1.PROCESS_ID	= T2.PROCESS_ID
		--	AND	T2.INVALID_FLAG	= 0
		INNER JOIN
			MA_SEIZOU_LINE	T3
		ON
				T2.SEIZOU_LN_ID	= T3.SEIZOU_LN_ID
		--	AND	T3.INVALID_FLAG	= 0
		WHERE
				T3.SEIZOU_LN_ID	=	l_seizou_ln_id_wk
			AND	to_timestamp(to_char(T0.DATA_DATE, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS')	>= l_proc_start_time
			AND	to_timestamp(to_char(T0.DATA_DATE, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS')	<= l_proc_end_time
			AND	T0.PLAN_NUM		>=	0
		GROUP BY
			T3.SEIZOU_LN_ID,
			T0.LN_ID,
			T0.VTEXT_INFO1,
			T3.PLANT_CD,
			T3.SEIZOU_LN_CD,
			T3.SEIZOU_LN_NM,
			T2.PROCESS_CD,
			T2.PROCESS_NM,
			T1.LN_NO,
			T1.LN_NM

		UNION ALL

		-- 製造ライン全体の計画台数　最終ラインの計画台数の合計値とする
		SELECT
			T3.SEIZOU_LN_ID		as seizouLnId,
			-1					as lnId,
			-1					as stId,
			''					as buhinCd,
			T0.VTEXT_INFO1		as vtextInfo1,
			''					as vtextInfo2,
			T3.PLANT_CD			as plantCd,
			T3.SEIZOU_LN_CD		as seizouLnCd,
			T3.SEIZOU_LN_NM		as seizouLnNm,
			NULL				as processCd,
			NULL				as processNm,
			NULL				as lnNo,
			NULL				as lnNm,
			NULL				as stNo,
			NULL				as stNm,
			MAX(T0.UPD_TIM)		as updDate,
			SUM(T0.PLAN_NUM)	as planTheDayNum,
			0					as planTheDayValue
		FROM
			TR_SEIHIN_PLAN_MANUAL_SETTING	T0
		INNER JOIN
			MA_LINE	T1
		ON
				T0.LN_ID		= T1.LN_ID
		--	AND	T1.INVALID_FLAG	= 0
		INNER JOIN
			MA_PROCESS	T2
		ON
				T1.PROCESS_ID	= T2.PROCESS_ID
		--	AND	T2.INVALID_FLAG	= 0
		INNER JOIN
			MA_SEIZOU_LINE	T3
		ON
				T2.SEIZOU_LN_ID	= T3.SEIZOU_LN_ID
		--	AND	T3.INVALID_FLAG	= 0
		WHERE
				T3.SEIZOU_LN_ID		=	l_seizou_ln_id_wk
			AND	to_timestamp(to_char(T0.DATA_DATE, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS')	>= l_proc_start_time
			AND	to_timestamp(to_char(T0.DATA_DATE, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS')	<= l_proc_end_time
			AND	T0.PLAN_NUM			>=	0
			AND	T0.LAST_LINE_FLAG	=	1
		GROUP BY
			T3.SEIZOU_LN_ID,
			T0.VTEXT_INFO1,
			T3.PLANT_CD,
			T3.SEIZOU_LN_CD,
			T3.SEIZOU_LN_NM
	;

	OPENFLG_TR_SEIHIN_PLAN_MANUAL_SETTING	int;	-- カーソルオープン状態

	-- 製品生産計画実績(時間別)[計画(当日)]
	CUR_AG_PRODUCT_MNG_HOURLY_PLAN_TODAY	CURSOR FOR
		SELECT
			SEIZOU_LN_ID,
			LN_ID,
			ST_ID,
			BUHIN_CD,
			VTEXT_INFO1,
			VTEXT_INFO2,
			MAX(PLANT_CD),
			MAX(SEIZOU_LN_CD),
			MAX(SEIZOU_LN_NM),
			MAX(PROCESS_CD),
			MAX(PROCESS_NM),
			MAX(LN_NO),
			MAX(LN_NM),
			MAX(ST_NO),
			MAX(ST_NM),
			MAX(UPD_DATE),
			SUM(PLAN_THE_DAY_NUM),
			SUM(PLAN_THE_DAY_VALUE)
		FROM
			AG_PRODUCT_MNG_HOURLY
		WHERE
				SEIZOU_LN_ID		=  l_seizou_ln_id_wk
			AND	DATA_DATE			>= l_proc_start_time
			AND	DATA_DATE			<= l_proc_end_time
			AND	PLAN_THE_DAY_NUM	!= -1
			AND	PLAN_THE_DAY_VALUE	!= -1
		GROUP BY
			SEIZOU_LN_ID,
			LN_ID,
			ST_ID,
			BUHIN_CD,
			VTEXT_INFO1,
			VTEXT_INFO2
	;

	OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_TODAY	int;	-- カーソルオープン状態	

	-- 製品生産計画実績(時間別)[計画(前日)]
	CUR_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY	CURSOR FOR
		SELECT
			SEIZOU_LN_ID,
			LN_ID,
			ST_ID,
			BUHIN_CD,
			VTEXT_INFO1,
			VTEXT_INFO2,
			MAX(PLANT_CD),
			MAX(SEIZOU_LN_CD),
			MAX(SEIZOU_LN_NM),
			MAX(PROCESS_CD),
			MAX(PROCESS_NM),
			MAX(LN_NO),
			MAX(LN_NM),
			MAX(ST_NO),
			MAX(ST_NM),
			MAX(UPD_DATE),
			SUM(PLAN_BEFORE_THE_DAY_NUM),
			SUM(PLAN_BEFORE_THE_DAY_VALUE)
		FROM
			AG_PRODUCT_MNG_HOURLY
		WHERE
				SEIZOU_LN_ID				=  l_seizou_ln_id_wk
			AND	DATA_DATE					>= l_proc_start_time
			AND	DATA_DATE					<= l_proc_end_time
			AND	PLAN_BEFORE_THE_DAY_NUM		!= -1
			AND	PLAN_BEFORE_THE_DAY_VALUE	!= -1
		GROUP BY
			SEIZOU_LN_ID,
			LN_ID,
			ST_ID,
			BUHIN_CD,
			VTEXT_INFO1,
			VTEXT_INFO2
	;

	OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY	int;	-- カーソルオープン状態	

	-- 製品生産計画実績(時間別)[計画(前々日)]
	CUR_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS	CURSOR FOR
		SELECT
			SEIZOU_LN_ID,
			LN_ID,
			ST_ID,
			BUHIN_CD,
			VTEXT_INFO1,
			VTEXT_INFO2,
			MAX(PLANT_CD),
			MAX(SEIZOU_LN_CD),
			MAX(SEIZOU_LN_NM),
			MAX(PROCESS_CD),
			MAX(PROCESS_NM),
			MAX(LN_NO),
			MAX(LN_NM),
			MAX(ST_NO),
			MAX(ST_NM),
			MAX(UPD_DATE),
			SUM(PLAN_BEFORE_TWO_DAYS_NUM),
			SUM(PLAN_BEFORE_TWO_DAYS_VALUE)
		FROM
			AG_PRODUCT_MNG_HOURLY
		WHERE
				SEIZOU_LN_ID				=  l_seizou_ln_id_wk
			AND	DATA_DATE					>= l_proc_start_time
			AND	DATA_DATE					<= l_proc_end_time
			AND	PLAN_BEFORE_TWO_DAYS_NUM	!= -1
			AND	PLAN_BEFORE_TWO_DAYS_VALUE	!= -1
		GROUP BY
			SEIZOU_LN_ID,
			LN_ID,
			ST_ID,
			BUHIN_CD,
			VTEXT_INFO1,
			VTEXT_INFO2
	;

	OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS	int;	-- カーソルオープン状態	

	-- 製品生産計画実績(時間別)[実績]
	CUR_AG_PRODUCT_MNG_HOURLY_ACTUAL	CURSOR FOR
		SELECT
			SEIZOU_LN_ID,
			LN_ID,
			ST_ID,
			BUHIN_CD,
			VTEXT_INFO1,
			VTEXT_INFO2,
			MAX(PLANT_CD),
			MAX(SEIZOU_LN_CD),
			MAX(SEIZOU_LN_NM),
			MAX(PROCESS_CD),
			MAX(PROCESS_NM),
			MAX(LN_NO),
			MAX(LN_NM),
			MAX(ST_NO),
			MAX(ST_NM),
			MAX(UPD_DATE),
			SUM(ACTUAL_THE_DAY_NUM),
			SUM(ACTUAL_THE_DAY_VALUE)
		FROM
			AG_PRODUCT_MNG_HOURLY
		WHERE
				SEIZOU_LN_ID			=  l_seizou_ln_id_wk
			AND	DATA_DATE				>= l_proc_start_time
			AND	DATA_DATE				<= l_proc_end_time
			AND	ACTUAL_THE_DAY_NUM		!= -1
			AND	ACTUAL_THE_DAY_VALUE	!= -1
		GROUP BY
			SEIZOU_LN_ID,
			LN_ID,
			ST_ID,
			BUHIN_CD,
			VTEXT_INFO1,
			VTEXT_INFO2
	;

	OPENFLG_AG_PRODUCT_MNG_HOURLY_ACTUAL	int;	-- カーソルオープン状態	

	-- 製品生産計画実績(日別)
	CUR_AG_PRODUCT_MNG_DAILY	CURSOR FOR
		SELECT
			  *
		FROM
			AG_PRODUCT_MNG_DAILY
		WHERE
				SEIZOU_LN_ID	= l_seizou_ln_id
			AND	LN_ID 			= l_ln_id
			AND	ST_ID			= l_st_id
			AND	BUHIN_CD		= l_buhin_cd
			AND	DATA_DATE		= l_proc_start_time
			AND	VTEXT_INFO1		= l_vtext_info1
		FOR UPDATE NOWAIT
	;

	OPENFLG_AG_PRODUCT_MNG_DAILY	int;	-- カーソルオープン状態	
	REC_AG_PRODUCT_MNG_DAILY		AG_PRODUCT_MNG_DAILY%ROWTYPE;

BEGIN
	----------------------------------------------------------------------------
	--						初期処理
	----------------------------------------------------------------------------
	raise info 'Start Function [%]', clock_timestamp()::timestamp;

	-- 共通変数初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S001';

	-- 共通出力パラメータ初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
	o_ret_cd	:= RET_OK;
	o_sqlerr	:= ' ';
	o_errmsg	:= ' ';
	o_errpnt	:= ' ';

	-- 関数実行日時
	l_exec_datetime := clock_timestamp();

	-- 集計開始/終了日時補正
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
	IF i_from_time IS NULL THEN
		i_from_time := l_exec_datetime;
	END IF;
	IF i_to_time IS NULL OR i_from_time > i_to_time THEN
		i_to_time := l_exec_datetime;
	END IF;

	-- ローカル変数初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S004';
	OPENFLG_MA_PLANT := CST_FALSE;
	OPENFLG_AG_PRODUCT_MNG_DAILY_CLEAR := CST_FALSE;
	OPENFLG_MA_SEIZOU_LINE := CST_FALSE;
	OPENFLG_TR_SEIHIN_PLAN_MANUAL_SETTING := CST_FALSE;
	OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_TODAY := CST_FALSE;
	OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY := CST_FALSE;
	OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS := CST_FALSE;
	OPENFLG_AG_PRODUCT_MNG_HOURLY_ACTUAL := CST_FALSE;
	OPENFLG_AG_PRODUCT_MNG_DAILY := CST_FALSE;

	----------------------------------------------------------------------------
	-- メイン処理
	----------------------------------------------------------------------------
	<< MAIN_LOOP >>
	LOOP

		------------------------------------------------------------------------
		-- 工場ごとに稼働開始日時が異なるので、工場マスタで処理を回す
		------------------------------------------------------------------------
		-- 工場マスタを開いているならクローズ
		l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
		IF OPENFLG_MA_PLANT = CST_TRUE THEN
			CLOSE CUR_MA_PLANT;
			OPENFLG_MA_PLANT := CST_FALSE;
		END IF;

		-- 工場マスタをオープン
		l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
		OPEN CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_TRUE;

		<< PLANT_LOOP >>
		LOOP
			-- 工場マスタからフェッチ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_103';
			FETCH CUR_MA_PLANT INTO l_plant_cd_wk, l_running_start_datetime;
			IF FOUND = FALSE THEN
				EXIT PLANT_LOOP;
			END IF;

			IF l_running_start_datetime IS NULL THEN
				-- NULLの場合はデフォルト値をセット
				l_err_pnt := RTRIM(cst_MY_PRG) || '_104';
				l_running_start_datetime = timestamp '0001-03-21 07:00:00';
			END IF;

			-- 処理開始日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_105';
			SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_all;
			<< START_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_106';
				IF i_from_time >= l_proc_start_time_all THEN
					EXIT START_TIME_LOOP;
				END IF;
				l_proc_start_time_all := l_proc_start_time_all + interval '-1 days';
			END LOOP	START_TIME_LOOP;

			-- 処理終了日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_107';
			SELECT l_proc_start_time_all + interval '1 days' + interval '-1 milliseconds' INTO l_proc_end_time_all;
			<< END_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_108';
				IF i_to_time <= l_proc_end_time_all THEN
					EXIT END_TIME_LOOP;
				END IF;
				l_proc_end_time_all := l_proc_end_time_all + interval '1 days';
			END LOOP	END_TIME_LOOP;

			------------------------------------
			-- 計画/実績を一旦クリア
			------------------------------------
			-- 製品生産計画実績(日別)(クリア用)を開いているならクローズ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
			IF OPENFLG_AG_PRODUCT_MNG_DAILY_CLEAR = CST_TRUE THEN
				CLOSE CUR_AG_PRODUCT_MNG_DAILY_CLEAR;
				OPENFLG_AG_PRODUCT_MNG_DAILY_CLEAR := CST_FALSE;
			END IF;

			-- 製品生産計画実績(日別)(クリア用)をオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_202';
			OPEN CUR_AG_PRODUCT_MNG_DAILY_CLEAR;
			OPENFLG_AG_PRODUCT_MNG_DAILY_CLEAR := CST_TRUE;

			<< PRODUCT_MANAGEMENT_DAILY_CLEAR_LOOP >>
			LOOP
				-- 製品生産計画実績(日別)(クリア用)からフェッチ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_203';
				FETCH CUR_AG_PRODUCT_MNG_DAILY_CLEAR INTO REC_AG_PRODUCT_MNG_DAILY_CLEAR;
				IF FOUND = FALSE THEN
					-- 該当データがない場合
					EXIT PRODUCT_MANAGEMENT_DAILY_CLEAR_LOOP;
				END IF;

				-- 製品生産計画実績(日別)を更新
				l_err_pnt := RTRIM(cst_MY_PRG) || '_204';
				UPDATE
					AG_PRODUCT_MNG_DAILY
				SET
					  PLAN_THE_DAY_NUM				= -1				-- 計画(当日)台数
					, PLAN_BEFORE_THE_DAY_NUM		= -1				-- 計画(前日)台数
					, PLAN_BEFORE_TWO_DAYS_NUM		= -1				-- 計画(前々日)台数
					, ACTUAL_THE_DAY_NUM			= -1				-- 実績台数
					, PLAN_THE_DAY_VALUE			= -1				-- 計画(当日)金額
					, PLAN_BEFORE_THE_DAY_VALUE		= -1				-- 計画(前日)金額
					, PLAN_BEFORE_TWO_DAYS_VALUE	= -1				-- 計画(前々日)金額
					, ACTUAL_THE_DAY_VALUE			= -1				-- 実績金額
					, UPD_PROG						= cst_MY_PRG		-- 更新プログラム
					, UPD_TIM						= l_exec_datetime	-- 更新日時
					, UPD_USER_SID					= i_user_sid		-- 更新ユーザSID
				WHERE CURRENT OF CUR_AG_PRODUCT_MNG_DAILY_CLEAR;
			END LOOP	PRODUCT_MANAGEMENT_DAILY_CLEAR_LOOP;

			------------------------------------------------------------------------
			-- 計画系システム導入状況で計画値の取得先が変わるので、
			-- 製造ラインマスタで回す
			------------------------------------------------------------------------
			-- 製造ラインマスタを開いているならクローズ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_301';
			IF OPENFLG_MA_SEIZOU_LINE = CST_TRUE THEN
				CLOSE CUR_MA_SEIZOU_LINE;
				OPENFLG_MA_SEIZOU_LINE := CST_FALSE;
			END IF;

			-- 製造ラインマスタをオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_302';
			OPEN CUR_MA_SEIZOU_LINE;
			OPENFLG_MA_SEIZOU_LINE := CST_TRUE;

			<< SEIZOU_LINE_LOOP >>
			LOOP
				-- 製造ラインマスタからフェッチ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_303';
				FETCH CUR_MA_SEIZOU_LINE INTO l_seizou_ln_id_wk, l_planning_system;
				IF FOUND = FALSE THEN
					EXIT SEIZOU_LINE_LOOP;
				END IF;

				-- 処理開始/終了日時
				l_err_pnt := RTRIM(cst_MY_PRG) || '_304';
				l_proc_start_time := l_proc_start_time_all;
				l_proc_end_time := l_proc_start_time + interval '1 days' + interval '-1 milliseconds';

				<< TIME_LOOP >>
				LOOP

					IF l_planning_system = CST_PLANNING_SYSTEM_ENABLE THEN
						-- 計画系システム導入ありの場合
						-- →製品生産計画実績(時間別)から計画値を集計する

						----------------------------------------------------------------------------
						-- 計画(当日)
						----------------------------------------------------------------------------
						-- 製品生産計画実績(時間別)[計画(当日)]を開いているならクローズ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_401';
						IF OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_TODAY = CST_TRUE THEN
							CLOSE CUR_AG_PRODUCT_MNG_HOURLY_PLAN_TODAY;
							OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_TODAY := CST_FALSE;
						END IF;

						-- 製品生産計画実績(時間別)[計画(当日)]をオープン
						l_err_pnt := RTRIM(cst_MY_PRG) || '_402';
						OPEN CUR_AG_PRODUCT_MNG_HOURLY_PLAN_TODAY;
						OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_TODAY := CST_TRUE;

						<< AG_PRODUCT_MNG_HOURLY_PLAN_TODAY_LOOP >>
						LOOP
							-- 製品生産計画実績(時間別)[計画(当日)]からフェッチ
							l_err_pnt := RTRIM(cst_MY_PRG) || '_403';
							FETCH CUR_AG_PRODUCT_MNG_HOURLY_PLAN_TODAY INTO l_seizou_ln_id, l_ln_id, l_st_id, l_buhin_cd, l_vtext_info1, l_vtext_info2, l_plant_cd, l_seizou_ln_cd, l_seizou_ln_nm, l_process_cd, l_process_nm, l_ln_no, l_ln_nm, l_st_no, l_st_nm, l_upd_date, l_plan_the_day_num, l_plan_the_day_value;
							IF FOUND = FALSE THEN
								EXIT AG_PRODUCT_MNG_HOURLY_PLAN_TODAY_LOOP;
							END IF;

							-- 製品生産計画実績(日別)にデータがあるか確認
							l_err_pnt := RTRIM(cst_MY_PRG) || '_404';
							IF OPENFLG_AG_PRODUCT_MNG_DAILY = CST_TRUE THEN
								CLOSE CUR_AG_PRODUCT_MNG_DAILY;
								OPENFLG_AG_PRODUCT_MNG_DAILY := CST_FALSE;
							END IF;

							-- 製品生産計画実績(日別)をオープン
							l_err_pnt := RTRIM(cst_MY_PRG) || '_405';
							OPEN CUR_AG_PRODUCT_MNG_DAILY;
							OPENFLG_AG_PRODUCT_MNG_DAILY := CST_TRUE;

							l_err_pnt := RTRIM(cst_MY_PRG) || '_406';
							FETCH CUR_AG_PRODUCT_MNG_DAILY INTO REC_AG_PRODUCT_MNG_DAILY;
							IF FOUND = FALSE THEN
								-- 製品生産計画実績(日別)に格納
								l_err_pnt := RTRIM(cst_MY_PRG) || '_407';
								INSERT INTO AG_PRODUCT_MNG_DAILY
								(
									  SEIZOU_LN_ID							-- 製造ラインID
									, LN_ID									-- ラインID
									, ST_ID									-- ステーションID
									, BUHIN_CD								-- 品目コード
									, DATA_DATE								-- データ日時
									, VTEXT_INFO1 							-- 品目階層TEXT_その1
									, VTEXT_INFO2 							-- 品目階層TEXT_その2
									, PLANT_CD								-- プラントコード
									, SEIZOU_LN_CD							-- 製造ラインコード
									, SEIZOU_LN_NM							-- 製造ライン名
									, PROCESS_CD							-- 工程コード
									, PROCESS_NM							-- 工程名称
									, LN_NO									-- ラインNo
									, LN_NM									-- ライン名称
									, ST_NO									-- ステーションNo
									, ST_NM									-- ステーション名称
									, UPD_DATE								-- 更新日時
									, PLAN_THE_DAY_NUM						-- 計画(当日)台数
									, PLAN_BEFORE_THE_DAY_NUM 				-- 計画(前日)台数
									, PLAN_BEFORE_TWO_DAYS_NUM				-- 計画(前々日)台数
									, ACTUAL_THE_DAY_NUM					-- 実績(当日)台数
									, PLAN_THE_DAY_VALUE					-- 計画(当日)金額
									, PLAN_BEFORE_THE_DAY_VALUE				-- 計画(前日)金額
									, PLAN_BEFORE_TWO_DAYS_VALUE			-- 計画(前々日)金額
									, ACTUAL_THE_DAY_VALUE					-- 実績(当日)金額
									, INS_PROG								-- 登録プログラム名
									, INS_TIM 								-- 登録日時
									, INS_USER_SID							-- 登録ユーザSID
									, UPD_PROG								-- 更新プログラム名
									, UPD_TIM 								-- 更新日時
									, UPD_USER_SID							-- 更新ユーザSID
								)
								VALUES
								(
									  l_seizou_ln_id						-- 製造ラインID
									, l_ln_id								-- ラインID
									, l_st_id								-- ステーションID
									, l_buhin_cd							-- 品目コード
									, l_proc_start_time						-- データ日時
									, l_vtext_info1 						-- 品目階層TEXT_その1
									, l_vtext_info2 						-- 品目階層TEXT_その2
									, l_plant_cd							-- プラントコード
									, l_seizou_ln_cd						-- 製造ラインコード
									, l_seizou_ln_nm						-- 製造ライン名
									, l_process_cd							-- 工程コード
									, l_process_nm							-- 工程名称
									, l_ln_no								-- ラインNo
									, l_ln_nm								-- ライン名称
									, l_st_no								-- ステーションNo
									, l_st_nm								-- ステーション名称
									, l_upd_date							-- 更新日時
									, l_plan_the_day_num					-- 計画(当日)台数
									, -1 									-- 計画(前日)台数
									, -1									-- 計画(前々日)台数
									, -1									-- 実績(当日)台数
									, l_plan_the_day_value					-- 計画(当日)金額
									, -1									-- 計画(前日)金額
									, -1									-- 計画(前々日)金額
									, -1									-- 実績(当日)金額
									, cst_MY_PRG							-- 登録プログラム名
									, l_exec_datetime						-- 登録日時
									, i_user_sid							-- 登録ユーザSID
									, cst_MY_PRG							-- 更新プログラム名
									, l_exec_datetime						-- 更新日時
									, i_user_sid							-- 更新ユーザSID
								);
							ELSE
								-- 製品生産計画実績(日別)を更新
								l_err_pnt := RTRIM(cst_MY_PRG) || '_408';
								UPDATE AG_PRODUCT_MNG_DAILY SET
									  VTEXT_INFO2				= l_vtext_info2 				-- 品目階層TEXT_その2
									, PLANT_CD					= l_plant_cd					-- プラントコード
									, SEIZOU_LN_CD				= l_seizou_ln_cd				-- 製造ラインコード
									, SEIZOU_LN_NM				= l_seizou_ln_nm				-- 製造ライン名
									, PROCESS_CD				= l_process_cd					-- 工程コード
									, PROCESS_NM				= l_process_nm					-- 工程名称
									, LN_NO 					= l_ln_no						-- ラインNo
									, LN_NM 					= l_ln_nm						-- ライン名称
									, ST_NO 					= l_st_no						-- ステーションNo
									, ST_NM 					= l_st_nm						-- ステーション名称
									, UPD_DATE					= l_upd_date					-- 更新日時
									, PLAN_THE_DAY_NUM			= l_plan_the_day_num			-- 計画(当日)台数
									, PLAN_THE_DAY_VALUE		= l_plan_the_day_value			-- 計画(当日)金額
									, UPD_PROG					= cst_MY_PRG					-- 更新プログラム
									, UPD_TIM					= l_exec_datetime				-- 更新日時
									, UPD_USER_SID				= i_user_sid					-- 更新ユーザSID
								WHERE CURRENT OF CUR_AG_PRODUCT_MNG_DAILY;
							END IF;

						END LOOP	AG_PRODUCT_MNG_HOURLY_PLAN_TODAY_LOOP;

						----------------------------------------------------------------------------
						-- 計画(前日)
						----------------------------------------------------------------------------
						-- 製品生産計画実績(時間別)[計画(前日)]を開いているならクローズ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_501';
						IF OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY = CST_TRUE THEN
							CLOSE CUR_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY;
							OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY := CST_FALSE;
						END IF;

						-- 製品生産計画実績(時間別)[計画(前日)]をオープン
						l_err_pnt := RTRIM(cst_MY_PRG) || '_502';
						OPEN CUR_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY;
						OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY := CST_TRUE;

						<< AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY_LOOP >>
						LOOP
							-- 製品生産計画実績(時間別)[計画(前日)]からフェッチ
							l_err_pnt := RTRIM(cst_MY_PRG) || '_503';
							FETCH CUR_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY INTO l_seizou_ln_id, l_ln_id, l_st_id, l_buhin_cd, l_vtext_info1, l_vtext_info2, l_plant_cd, l_seizou_ln_cd, l_seizou_ln_nm, l_process_cd, l_process_nm, l_ln_no, l_ln_nm, l_st_no, l_st_nm, l_upd_date, l_plan_before_the_day_num, l_plan_before_the_day_value;
							IF FOUND = FALSE THEN
								EXIT AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY_LOOP;
							END IF;

							-- 製品生産計画実績(日別)にデータがあるか確認
							l_err_pnt := RTRIM(cst_MY_PRG) || '_504';
							IF OPENFLG_AG_PRODUCT_MNG_DAILY = CST_TRUE THEN
								CLOSE CUR_AG_PRODUCT_MNG_DAILY;
								OPENFLG_AG_PRODUCT_MNG_DAILY := CST_FALSE;
							END IF;

							-- 製品生産計画実績(日別)をオープン
							l_err_pnt := RTRIM(cst_MY_PRG) || '_505';
							OPEN CUR_AG_PRODUCT_MNG_DAILY;
							OPENFLG_AG_PRODUCT_MNG_DAILY := CST_TRUE;

							l_err_pnt := RTRIM(cst_MY_PRG) || '_506';
							FETCH CUR_AG_PRODUCT_MNG_DAILY INTO REC_AG_PRODUCT_MNG_DAILY;
							IF FOUND = FALSE THEN
								-- 製品生産計画実績(日別)に格納
								l_err_pnt := RTRIM(cst_MY_PRG) || '_507';
								INSERT INTO AG_PRODUCT_MNG_DAILY
								(
									  SEIZOU_LN_ID							-- 製造ラインID
									, LN_ID									-- ラインID
									, ST_ID									-- ステーションID
									, BUHIN_CD								-- 品目コード
									, DATA_DATE								-- データ日時
									, VTEXT_INFO1 							-- 品目階層TEXT_その1
									, VTEXT_INFO2 							-- 品目階層TEXT_その2
									, PLANT_CD								-- プラントコード
									, SEIZOU_LN_CD							-- 製造ラインコード
									, SEIZOU_LN_NM							-- 製造ライン名
									, PROCESS_CD							-- 工程コード
									, PROCESS_NM							-- 工程名称
									, LN_NO									-- ラインNo
									, LN_NM									-- ライン名称
									, ST_NO									-- ステーションNo
									, ST_NM									-- ステーション名称
									, UPD_DATE								-- 更新日時
									, PLAN_THE_DAY_NUM						-- 計画(当日)台数
									, PLAN_BEFORE_THE_DAY_NUM 				-- 計画(前日)台数
									, PLAN_BEFORE_TWO_DAYS_NUM				-- 計画(前々日)台数
									, ACTUAL_THE_DAY_NUM					-- 実績(当日)台数
									, PLAN_THE_DAY_VALUE					-- 計画(当日)金額
									, PLAN_BEFORE_THE_DAY_VALUE				-- 計画(前日)金額
									, PLAN_BEFORE_TWO_DAYS_VALUE			-- 計画(前々日)金額
									, ACTUAL_THE_DAY_VALUE					-- 実績(当日)金額
									, INS_PROG								-- 登録プログラム名
									, INS_TIM 								-- 登録日時
									, INS_USER_SID							-- 登録ユーザSID
									, UPD_PROG								-- 更新プログラム名
									, UPD_TIM 								-- 更新日時
									, UPD_USER_SID							-- 更新ユーザSID
								)
								VALUES
								(
									  l_seizou_ln_id						-- 製造ラインID
									, l_ln_id								-- ラインID
									, l_st_id								-- ステーションID
									, l_buhin_cd							-- 品目コード
									, l_proc_start_time						-- データ日時
									, l_vtext_info1 						-- 品目階層TEXT_その1
									, l_vtext_info2 						-- 品目階層TEXT_その2
									, l_plant_cd							-- プラントコード
									, l_seizou_ln_cd						-- 製造ラインコード
									, l_seizou_ln_nm						-- 製造ライン名
									, l_process_cd							-- 工程コード
									, l_process_nm							-- 工程名称
									, l_ln_no								-- ラインNo
									, l_ln_nm								-- ライン名称
									, l_st_no								-- ステーションNo
									, l_st_nm								-- ステーション名称
									, l_upd_date							-- 更新日時
									, -1									-- 計画(当日)台数
									, l_plan_before_the_day_num 			-- 計画(前日)台数
									, -1									-- 計画(前々日)台数
									, -1									-- 実績(当日)台数
									, -1									-- 計画(当日)金額
									, l_plan_before_the_day_value			-- 計画(前日)金額
									, -1									-- 計画(前々日)金額
									, -1									-- 実績(当日)金額
									, cst_MY_PRG							-- 登録プログラム名
									, l_exec_datetime						-- 登録日時
									, i_user_sid							-- 登録ユーザSID
									, cst_MY_PRG							-- 更新プログラム名
									, l_exec_datetime						-- 更新日時
									, i_user_sid							-- 更新ユーザSID
								);
							ELSE
								-- 製品生産計画実績(日別)を更新
								l_err_pnt := RTRIM(cst_MY_PRG) || '_508';
								UPDATE AG_PRODUCT_MNG_DAILY SET
									  PLANT_CD					= l_plant_cd					-- プラントコード
									, SEIZOU_LN_CD				= l_seizou_ln_cd				-- 製造ラインコード
									, SEIZOU_LN_NM				= l_seizou_ln_nm				-- 製造ライン名
									, PROCESS_CD				= l_process_cd					-- 工程コード
									, PROCESS_NM				= l_process_nm					-- 工程名称
									, LN_NO 					= l_ln_no						-- ラインNo
									, LN_NM 					= l_ln_nm						-- ライン名称
									, ST_NO 					= l_st_no						-- ステーションNo
									, ST_NM 					= l_st_nm						-- ステーション名称
									, UPD_DATE					= l_upd_date					-- 更新日時
									, PLAN_BEFORE_THE_DAY_NUM	= l_plan_before_the_day_num		-- 計画(前日)台数
									, PLAN_BEFORE_THE_DAY_VALUE	= l_plan_before_the_day_value	-- 計画(前日)金額
									, UPD_PROG					= cst_MY_PRG					-- 更新プログラム
									, UPD_TIM					= l_exec_datetime				-- 更新日時
									, UPD_USER_SID				= i_user_sid					-- 更新ユーザSID
								WHERE CURRENT OF CUR_AG_PRODUCT_MNG_DAILY;
							END IF;

						END LOOP	AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY_LOOP;

						----------------------------------------------------------------------------
						-- 計画(前々日)
						----------------------------------------------------------------------------
						-- 製品生産計画実績(時間別)[計画(前々日)]を開いているならクローズ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_601';
						IF OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS = CST_TRUE THEN
							CLOSE CUR_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS;
							OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS := CST_FALSE;
						END IF;

						-- 製品生産計画実績(時間別)[計画(前々日)]をオープン
						l_err_pnt := RTRIM(cst_MY_PRG) || '_602';
						OPEN CUR_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS;
						OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS := CST_TRUE;

						<< AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS_LOOP >>
						LOOP
							-- 製品生産計画実績(時間別)[計画(前々日)]からフェッチ
							l_err_pnt := RTRIM(cst_MY_PRG) || '_603';
							FETCH CUR_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS INTO l_seizou_ln_id, l_ln_id, l_st_id, l_buhin_cd, l_vtext_info1, l_vtext_info2, l_plant_cd, l_seizou_ln_cd, l_seizou_ln_nm, l_process_cd, l_process_nm, l_ln_no, l_ln_nm, l_st_no, l_st_nm, l_upd_date, l_plan_before_two_days_num, l_plan_before_two_days_value;
							IF FOUND = FALSE THEN
								EXIT AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS_LOOP;
							END IF;

							-- 製品生産計画実績(日別)にデータがあるか確認
							l_err_pnt := RTRIM(cst_MY_PRG) || '_604';
							IF OPENFLG_AG_PRODUCT_MNG_DAILY = CST_TRUE THEN
								CLOSE CUR_AG_PRODUCT_MNG_DAILY;
								OPENFLG_AG_PRODUCT_MNG_DAILY := CST_FALSE;
							END IF;

							-- 製品生産計画実績(日別)をオープン
							l_err_pnt := RTRIM(cst_MY_PRG) || '_605';
							OPEN CUR_AG_PRODUCT_MNG_DAILY;
							OPENFLG_AG_PRODUCT_MNG_DAILY := CST_TRUE;

							l_err_pnt := RTRIM(cst_MY_PRG) || '_606';
							FETCH CUR_AG_PRODUCT_MNG_DAILY INTO REC_AG_PRODUCT_MNG_DAILY;
							IF FOUND = FALSE THEN
								-- 製品生産計画実績(日別)に格納
								l_err_pnt := RTRIM(cst_MY_PRG) || '_607';
								INSERT INTO AG_PRODUCT_MNG_DAILY
								(
									  SEIZOU_LN_ID							-- 製造ラインID
									, LN_ID									-- ラインID
									, ST_ID									-- ステーションID
									, BUHIN_CD								-- 品目コード
									, DATA_DATE								-- データ日時
									, VTEXT_INFO1 							-- 品目階層TEXT_その1
									, VTEXT_INFO2 							-- 品目階層TEXT_その2
									, PLANT_CD								-- プラントコード
									, SEIZOU_LN_CD							-- 製造ラインコード
									, SEIZOU_LN_NM							-- 製造ライン名
									, PROCESS_CD							-- 工程コード
									, PROCESS_NM							-- 工程名称
									, LN_NO									-- ラインNo
									, LN_NM									-- ライン名称
									, ST_NO									-- ステーションNo
									, ST_NM									-- ステーション名称
									, UPD_DATE								-- 更新日時
									, PLAN_THE_DAY_NUM						-- 計画(当日)台数
									, PLAN_BEFORE_THE_DAY_NUM 				-- 計画(前日)台数
									, PLAN_BEFORE_TWO_DAYS_NUM				-- 計画(前々日)台数
									, ACTUAL_THE_DAY_NUM					-- 実績(当日)台数
									, PLAN_THE_DAY_VALUE					-- 計画(当日)金額
									, PLAN_BEFORE_THE_DAY_VALUE				-- 計画(前日)金額
									, PLAN_BEFORE_TWO_DAYS_VALUE			-- 計画(前々日)金額
									, ACTUAL_THE_DAY_VALUE					-- 実績(当日)金額
									, INS_PROG								-- 登録プログラム名
									, INS_TIM 								-- 登録日時
									, INS_USER_SID							-- 登録ユーザSID
									, UPD_PROG								-- 更新プログラム名
									, UPD_TIM 								-- 更新日時
									, UPD_USER_SID							-- 更新ユーザSID
								)
								VALUES
								(
									  l_seizou_ln_id						-- 製造ラインID
									, l_ln_id								-- ラインID
									, l_st_id								-- ステーションID
									, l_buhin_cd							-- 品目コード
									, l_proc_start_time						-- データ日時
									, l_vtext_info1 						-- 品目階層TEXT_その1
									, l_vtext_info2 						-- 品目階層TEXT_その2
									, l_plant_cd							-- プラントコード
									, l_seizou_ln_cd						-- 製造ラインコード
									, l_seizou_ln_nm						-- 製造ライン名
									, l_process_cd							-- 工程コード
									, l_process_nm							-- 工程名称
									, l_ln_no								-- ラインNo
									, l_ln_nm								-- ライン名称
									, l_st_no								-- ステーションNo
									, l_st_nm								-- ステーション名称
									, l_upd_date							-- 更新日時
									, -1									-- 計画(当日)台数
									, -1 									-- 計画(前日)台数
									, l_plan_before_two_days_num			-- 計画(前々日)台数
									, -1									-- 実績(当日)台数
									, -1									-- 計画(当日)金額
									, -1									-- 計画(前日)金額
									, l_plan_before_two_days_value			-- 計画(前々日)金額
									, -1									-- 実績(当日)金額
									, cst_MY_PRG							-- 登録プログラム名
									, l_exec_datetime						-- 登録日時
									, i_user_sid							-- 登録ユーザSID
									, cst_MY_PRG							-- 更新プログラム名
									, l_exec_datetime						-- 更新日時
									, i_user_sid							-- 更新ユーザSID
								);
							ELSE
								-- 製品生産計画実績(日別)を更新
								l_err_pnt := RTRIM(cst_MY_PRG) || '_608';
								UPDATE AG_PRODUCT_MNG_DAILY SET
									  PLANT_CD						= l_plant_cd					-- プラントコード
									, SEIZOU_LN_CD					= l_seizou_ln_cd				-- 製造ラインコード
									, SEIZOU_LN_NM					= l_seizou_ln_nm				-- 製造ライン名
									, PROCESS_CD					= l_process_cd					-- 工程コード
									, PROCESS_NM					= l_process_nm					-- 工程名称
									, LN_NO 						= l_ln_no						-- ラインNo
									, LN_NM 						= l_ln_nm						-- ライン名称
									, ST_NO 						= l_st_no						-- ステーションNo
									, ST_NM 						= l_st_nm						-- ステーション名称
									, UPD_DATE						= l_upd_date					-- 更新日時
									, PLAN_BEFORE_TWO_DAYS_NUM		= l_plan_before_two_days_num	-- 計画(前々日)台数
									, PLAN_BEFORE_TWO_DAYS_VALUE	= l_plan_before_two_days_value	-- 計画(前々日)金額
									, UPD_PROG						= cst_MY_PRG					-- 更新プログラム
									, UPD_TIM						= l_exec_datetime				-- 更新日時
									, UPD_USER_SID					= i_user_sid					-- 更新ユーザSID
								WHERE CURRENT OF CUR_AG_PRODUCT_MNG_DAILY;
							END IF;

						END LOOP	AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS_LOOP;

					ELSE
						-- 計画系システム導入なしの場合
						-- →製品計画台数(手動設定)から計画値を集計する

						-- 製品計画台数(手動設定)を開いているならクローズ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_601';
						IF OPENFLG_TR_SEIHIN_PLAN_MANUAL_SETTING = CST_TRUE THEN
							CLOSE CUR_TR_SEIHIN_PLAN_MANUAL_SETTING;
							OPENFLG_TR_SEIHIN_PLAN_MANUAL_SETTING := CST_FALSE;
						END IF;

						-- 製品計画台数(手動設定)をオープン
						l_err_pnt := RTRIM(cst_MY_PRG) || '_602';
						OPEN CUR_TR_SEIHIN_PLAN_MANUAL_SETTING;
						OPENFLG_TR_SEIHIN_PLAN_MANUAL_SETTING := CST_TRUE;

						<< TR_SEIHIN_PLAN_MANUAL_SETTING_LOOP >>
						LOOP
							-- 製品計画台数(手動設定)からフェッチ
							l_err_pnt := RTRIM(cst_MY_PRG) || '_603';
							FETCH CUR_TR_SEIHIN_PLAN_MANUAL_SETTING INTO l_seizou_ln_id, l_ln_id, l_st_id, l_buhin_cd, l_vtext_info1, l_vtext_info2, l_plant_cd, l_seizou_ln_cd, l_seizou_ln_nm, l_process_cd, l_process_nm, l_ln_no, l_ln_nm, l_st_no, l_st_nm, l_upd_date, l_plan_the_day_num, l_plan_the_day_value;
							IF FOUND = FALSE THEN
								EXIT TR_SEIHIN_PLAN_MANUAL_SETTING_LOOP;
							END IF;

							-- 製品生産計画実績(日別)にデータがあるか確認
							l_err_pnt := RTRIM(cst_MY_PRG) || '_604';
							IF OPENFLG_AG_PRODUCT_MNG_DAILY = CST_TRUE THEN
								CLOSE CUR_AG_PRODUCT_MNG_DAILY;
								OPENFLG_AG_PRODUCT_MNG_DAILY := CST_FALSE;
							END IF;

							-- 製品生産計画実績(日別)をオープン
							l_err_pnt := RTRIM(cst_MY_PRG) || '_605';
							OPEN CUR_AG_PRODUCT_MNG_DAILY;
							OPENFLG_AG_PRODUCT_MNG_DAILY := CST_TRUE;

							l_err_pnt := RTRIM(cst_MY_PRG) || '_606';
							FETCH CUR_AG_PRODUCT_MNG_DAILY INTO REC_AG_PRODUCT_MNG_DAILY;
							IF FOUND = FALSE THEN
								-- 製品生産計画実績(日別)に格納
								l_err_pnt := RTRIM(cst_MY_PRG) || '_607';
								INSERT INTO AG_PRODUCT_MNG_DAILY
								(
									  SEIZOU_LN_ID							-- 製造ラインID
									, LN_ID									-- ラインID
									, ST_ID									-- ステーションID
									, BUHIN_CD								-- 品目コード
									, DATA_DATE								-- データ日時
									, VTEXT_INFO1 							-- 品目階層TEXT_その1
									, VTEXT_INFO2 							-- 品目階層TEXT_その2
									, PLANT_CD								-- プラントコード
									, SEIZOU_LN_CD							-- 製造ラインコード
									, SEIZOU_LN_NM							-- 製造ライン名
									, PROCESS_CD							-- 工程コード
									, PROCESS_NM							-- 工程名称
									, LN_NO									-- ラインNo
									, LN_NM									-- ライン名称
									, ST_NO									-- ステーションNo
									, ST_NM									-- ステーション名称
									, UPD_DATE								-- 更新日時
									, PLAN_THE_DAY_NUM						-- 計画(当日)台数
									, PLAN_BEFORE_THE_DAY_NUM 				-- 計画(前日)台数
									, PLAN_BEFORE_TWO_DAYS_NUM				-- 計画(前々日)台数
									, ACTUAL_THE_DAY_NUM					-- 実績(当日)台数
									, PLAN_THE_DAY_VALUE					-- 計画(当日)金額
									, PLAN_BEFORE_THE_DAY_VALUE				-- 計画(前日)金額
									, PLAN_BEFORE_TWO_DAYS_VALUE			-- 計画(前々日)金額
									, ACTUAL_THE_DAY_VALUE					-- 実績(当日)金額
									, INS_PROG								-- 登録プログラム名
									, INS_TIM 								-- 登録日時
									, INS_USER_SID							-- 登録ユーザSID
									, UPD_PROG								-- 更新プログラム名
									, UPD_TIM 								-- 更新日時
									, UPD_USER_SID							-- 更新ユーザSID
								)
								VALUES
								(
									  l_seizou_ln_id						-- 製造ラインID
									, l_ln_id								-- ラインID
									, l_st_id								-- ステーションID
									, l_buhin_cd							-- 品目コード
									, l_proc_start_time						-- データ日時
									, l_vtext_info1 						-- 品目階層TEXT_その1
									, l_vtext_info2 						-- 品目階層TEXT_その2
									, l_plant_cd							-- プラントコード
									, l_seizou_ln_cd						-- 製造ラインコード
									, l_seizou_ln_nm						-- 製造ライン名
									, l_process_cd							-- 工程コード
									, l_process_nm							-- 工程名称
									, l_ln_no								-- ラインNo
									, l_ln_nm								-- ライン名称
									, l_st_no								-- ステーションNo
									, l_st_nm								-- ステーション名称
									, l_upd_date							-- 更新日時
									, l_plan_the_day_num					-- 計画(当日)台数
									, -1 									-- 計画(前日)台数
									, -1									-- 計画(前々日)台数
									, -1									-- 実績(当日)台数
									, l_plan_the_day_value					-- 計画(当日)金額
									, -1									-- 計画(前日)金額
									, -1									-- 計画(前々日)金額
									, -1									-- 実績(当日)金額
									, cst_MY_PRG							-- 登録プログラム名
									, l_exec_datetime						-- 登録日時
									, i_user_sid							-- 登録ユーザSID
									, cst_MY_PRG							-- 更新プログラム名
									, l_exec_datetime						-- 更新日時
									, i_user_sid							-- 更新ユーザSID
								);
							ELSE
								-- 製品生産計画実績(日別)を更新
								l_err_pnt := RTRIM(cst_MY_PRG) || '_608';
								UPDATE AG_PRODUCT_MNG_DAILY SET
									  PLANT_CD					= l_plant_cd					-- プラントコード
									, SEIZOU_LN_CD				= l_seizou_ln_cd				-- 製造ラインコード
									, SEIZOU_LN_NM				= l_seizou_ln_nm				-- 製造ライン名
									, PROCESS_CD				= l_process_cd					-- 工程コード
									, PROCESS_NM				= l_process_nm					-- 工程名称
									, LN_NO 					= l_ln_no						-- ラインNo
									, LN_NM 					= l_ln_nm						-- ライン名称
									, ST_NO 					= l_st_no						-- ステーションNo
									, ST_NM 					= l_st_nm						-- ステーション名称
									, UPD_DATE					= l_upd_date					-- 更新日時
									, PLAN_THE_DAY_NUM			= l_plan_the_day_num			-- 計画(当日)台数
									, PLAN_THE_DAY_VALUE		= l_plan_the_day_value			-- 計画(当日)金額
									, UPD_PROG					= cst_MY_PRG					-- 更新プログラム
									, UPD_TIM					= l_exec_datetime				-- 更新日時
									, UPD_USER_SID				= i_user_sid					-- 更新ユーザSID
								WHERE CURRENT OF CUR_AG_PRODUCT_MNG_DAILY;
							END IF;

						END LOOP	TR_SEIHIN_PLAN_MANUAL_SETTING_LOOP;
					END IF;

					----------------------------------------------------------------------------
					-- 実績
					----------------------------------------------------------------------------
					-- 製品生産計画実績(時間別)[実績]を開いているならクローズ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_801';
					IF OPENFLG_AG_PRODUCT_MNG_HOURLY_ACTUAL = CST_TRUE THEN
						CLOSE CUR_AG_PRODUCT_MNG_HOURLY_ACTUAL;
						OPENFLG_AG_PRODUCT_MNG_HOURLY_ACTUAL := CST_FALSE;
					END IF;

					-- 製品生産計画実績(時間別)[実績]をオープン
					l_err_pnt := RTRIM(cst_MY_PRG) || '_802';
					OPEN CUR_AG_PRODUCT_MNG_HOURLY_ACTUAL;
					OPENFLG_AG_PRODUCT_MNG_HOURLY_ACTUAL := CST_TRUE;

					<< AG_PRODUCT_MNG_HOURLY_ACTUAL_LOOP >>
					LOOP
						-- 製品生産計画実績(時間別)[実績]からフェッチ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_803';
						FETCH CUR_AG_PRODUCT_MNG_HOURLY_ACTUAL INTO l_seizou_ln_id, l_ln_id, l_st_id, l_buhin_cd, l_vtext_info1, l_vtext_info2, l_plant_cd, l_seizou_ln_cd, l_seizou_ln_nm, l_process_cd, l_process_nm, l_ln_no, l_ln_nm, l_st_no, l_st_nm, l_upd_date, l_actual_the_day_num, l_actual_the_day_value;
						IF FOUND = FALSE THEN
							EXIT AG_PRODUCT_MNG_HOURLY_ACTUAL_LOOP;
						END IF;

						-- 製品生産計画実績(日別)にデータがあるか確認
						l_err_pnt := RTRIM(cst_MY_PRG) || '_804';
						IF OPENFLG_AG_PRODUCT_MNG_DAILY = CST_TRUE THEN
							CLOSE CUR_AG_PRODUCT_MNG_DAILY;
							OPENFLG_AG_PRODUCT_MNG_DAILY := CST_FALSE;
						END IF;

						-- 製品生産計画実績(日別)をオープン
						l_err_pnt := RTRIM(cst_MY_PRG) || '_805';
						OPEN CUR_AG_PRODUCT_MNG_DAILY;
						OPENFLG_AG_PRODUCT_MNG_DAILY := CST_TRUE;

						l_err_pnt := RTRIM(cst_MY_PRG) || '_806';
						FETCH CUR_AG_PRODUCT_MNG_DAILY INTO REC_AG_PRODUCT_MNG_DAILY;
						IF FOUND = FALSE THEN
							-- 製品生産計画実績に格納
							l_err_pnt := RTRIM(cst_MY_PRG) || '_807';
							INSERT INTO AG_PRODUCT_MNG_DAILY
							(
								  SEIZOU_LN_ID							-- 製造ラインID
								, LN_ID									-- ラインID
								, ST_ID									-- ステーションID
								, BUHIN_CD								-- 品目コード
								, DATA_DATE								-- データ日時
								, VTEXT_INFO1 							-- 品目階層TEXT_その1
								, VTEXT_INFO2 							-- 品目階層TEXT_その2
								, PLANT_CD								-- プラントコード
								, SEIZOU_LN_CD							-- 製造ラインコード
								, SEIZOU_LN_NM							-- 製造ライン名
								, PROCESS_CD							-- 工程コード
								, PROCESS_NM							-- 工程名称
								, LN_NO									-- ラインNo
								, LN_NM									-- ライン名称
								, ST_NO									-- ステーションNo
								, ST_NM									-- ステーション名称
								, UPD_DATE								-- 更新日時
								, PLAN_THE_DAY_NUM						-- 計画(当日)台数
								, PLAN_BEFORE_THE_DAY_NUM 				-- 計画(前日)台数
								, PLAN_BEFORE_TWO_DAYS_NUM				-- 計画(前々日)台数
								, ACTUAL_THE_DAY_NUM					-- 実績(当日)台数
								, PLAN_THE_DAY_VALUE					-- 計画(当日)金額
								, PLAN_BEFORE_THE_DAY_VALUE				-- 計画(前日)金額
								, PLAN_BEFORE_TWO_DAYS_VALUE			-- 計画(前々日)金額
								, ACTUAL_THE_DAY_VALUE					-- 実績(当日)金額
								, INS_PROG								-- 登録プログラム名
								, INS_TIM 								-- 登録日時
								, INS_USER_SID							-- 登録ユーザSID
								, UPD_PROG								-- 更新プログラム名
								, UPD_TIM 								-- 更新日時
								, UPD_USER_SID							-- 更新ユーザSID
							)
							VALUES
							(
								  l_seizou_ln_id						-- 製造ラインID
								, l_ln_id								-- ラインID
								, l_st_id								-- ステーションID
								, l_buhin_cd							-- 品目コード
								, l_proc_start_time						-- データ日時
								, l_vtext_info1 						-- 品目階層TEXT_その1
								, l_vtext_info2 						-- 品目階層TEXT_その2
								, l_plant_cd							-- プラントコード
								, l_seizou_ln_cd						-- 製造ラインコード
								, l_seizou_ln_nm						-- 製造ライン名
								, l_process_cd							-- 工程コード
								, l_process_nm							-- 工程名称
								, l_ln_no								-- ラインNo
								, l_ln_nm								-- ライン名称
								, l_st_no								-- ステーションNo
								, l_st_nm								-- ステーション名称
								, l_upd_date							-- 更新日時
								, -1									-- 計画(当日)台数
								, -1 									-- 計画(前日)台数
								, -1									-- 計画(前々日)台数
								, l_actual_the_day_num					-- 実績(当日)台数
								, -1									-- 計画(当日)金額
								, -1									-- 計画(前日)金額
								, -1									-- 計画(前々日)金額
								, l_actual_the_day_value				-- 実績(当日)金額
								, cst_MY_PRG							-- 登録プログラム名
								, l_exec_datetime						-- 登録日時
								, i_user_sid							-- 登録ユーザSID
								, cst_MY_PRG							-- 更新プログラム名
								, l_exec_datetime						-- 更新日時
								, i_user_sid							-- 更新ユーザSID
							);
						ELSE
							-- 製品生産計画実績の実績台数と実績金額を更新
							l_err_pnt := RTRIM(cst_MY_PRG) || '_808';
							UPDATE AG_PRODUCT_MNG_DAILY SET
								  PLANT_CD						= l_plant_cd					-- プラントコード
								, SEIZOU_LN_CD					= l_seizou_ln_cd				-- 製造ラインコード
								, SEIZOU_LN_NM					= l_seizou_ln_nm				-- 製造ライン名
								, PROCESS_CD					= l_process_cd					-- 工程コード
								, PROCESS_NM					= l_process_nm					-- 工程名称
								, LN_NO 						= l_ln_no						-- ラインNo
								, LN_NM 						= l_ln_nm						-- ライン名称
								, ST_NO 						= l_st_no						-- ステーションNo
								, ST_NM 						= l_st_nm						-- ステーション名称
								, UPD_DATE						= l_upd_date					-- 更新日時
								, ACTUAL_THE_DAY_NUM			= l_actual_the_day_num			-- 実績(当日)台数
								, ACTUAL_THE_DAY_VALUE			= l_actual_the_day_value		-- 実績(当日)金額
								, UPD_PROG						= cst_MY_PRG					-- 更新プログラム
								, UPD_TIM						= l_exec_datetime				-- 更新日時
								, UPD_USER_SID					= i_user_sid					-- 更新ユーザSID
							WHERE CURRENT OF CUR_AG_PRODUCT_MNG_DAILY;
						END IF;

					END LOOP	AG_PRODUCT_MNG_HOURLY_ACTUAL_LOOP;

					-- 次の処理日時を設定
					l_proc_start_time	:= l_proc_start_time + interval '1 days';
					l_proc_end_time		:= l_proc_end_time + interval '1 days';

					-- 処理開始日時が処理終了日時(全体)を超えている場合は処理終了
					IF l_proc_end_time_all < l_proc_start_time THEN
						EXIT TIME_LOOP;
					END IF;

				END LOOP	TIME_LOOP;

			END LOOP	SEIZOU_LINE_LOOP;

		END LOOP	PLANT_LOOP;

		-- すべてが無効値となった場合は、レコード削除
		l_err_pnt := RTRIM(cst_MY_PRG) || '_901';
		DELETE FROM
			AG_PRODUCT_MNG_DAILY
		WHERE
				PLAN_THE_DAY_NUM			= -1
			AND	PLAN_BEFORE_THE_DAY_NUM		= -1
			AND	PLAN_BEFORE_TWO_DAYS_NUM	= -1
			AND	ACTUAL_THE_DAY_NUM			= -1
			AND	PLAN_THE_DAY_VALUE			= -1
			AND	PLAN_BEFORE_THE_DAY_VALUE	= -1
			AND	PLAN_BEFORE_TWO_DAYS_VALUE	= -1
			AND	ACTUAL_THE_DAY_VALUE		= -1
		;

		EXIT MAIN_LOOP;
	END LOOP	MAIN_LOOP;

	----------------------------------------------------------------------------
	--						終了処理
	----------------------------------------------------------------------------
	-- カーソルクローズ
	l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
	IF OPENFLG_MA_PLANT = CST_TRUE THEN
		CLOSE CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E002';
	IF OPENFLG_AG_PRODUCT_MNG_DAILY_CLEAR = CST_TRUE THEN
		CLOSE CUR_AG_PRODUCT_MNG_DAILY_CLEAR;
		OPENFLG_AG_PRODUCT_MNG_DAILY_CLEAR := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
	IF OPENFLG_MA_SEIZOU_LINE = CST_TRUE THEN
		CLOSE CUR_MA_SEIZOU_LINE;
		OPENFLG_MA_SEIZOU_LINE := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E004';
	IF OPENFLG_TR_SEIHIN_PLAN_MANUAL_SETTING = CST_TRUE THEN
		CLOSE CUR_TR_SEIHIN_PLAN_MANUAL_SETTING;
		OPENFLG_TR_SEIHIN_PLAN_MANUAL_SETTING := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E005';
	IF OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_TODAY = CST_TRUE THEN
		CLOSE CUR_AG_PRODUCT_MNG_HOURLY_PLAN_TODAY;
		OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_TODAY := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E006';
	IF OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY = CST_TRUE THEN
		CLOSE CUR_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY;
		OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_1DAY := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E007';
	IF OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS = CST_TRUE THEN
		CLOSE CUR_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS;
		OPENFLG_AG_PRODUCT_MNG_HOURLY_PLAN_BEFORE_2DAYS := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E008';
	IF OPENFLG_AG_PRODUCT_MNG_HOURLY_ACTUAL = CST_TRUE THEN
		CLOSE CUR_AG_PRODUCT_MNG_HOURLY_ACTUAL;
		OPENFLG_AG_PRODUCT_MNG_HOURLY_ACTUAL := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E009';
	IF OPENFLG_AG_PRODUCT_MNG_DAILY = CST_TRUE THEN
		CLOSE CUR_AG_PRODUCT_MNG_DAILY;
		OPENFLG_AG_PRODUCT_MNG_DAILY := CST_FALSE;
	END IF;

	raise info 'End Function [%]', clock_timestamp()::timestamp;

EXCEPTION WHEN OTHERS THEN
	-- DB例外情報収集
	GET STACKED DIAGNOSTICS rtn_sql_no     = RETURNED_SQLSTATE,
							rtn_sql_msg    = MESSAGE_TEXT,
							rtn_sql_detail = PG_EXCEPTION_DETAIL,
							rtn_sql_hint   = PG_EXCEPTION_HINT,
							rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

	raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
	raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

	o_ret_cd := RET_NG;
	o_sqlerr := substr(rtn_sql_no, 1, 15);
	o_errmsg := substr(rtn_sql_msg, 1, 127);
	o_errpnt := l_err_pnt;

	raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;
