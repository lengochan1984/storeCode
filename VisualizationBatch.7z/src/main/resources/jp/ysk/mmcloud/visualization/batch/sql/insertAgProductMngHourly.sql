WITH
    val AS (
        SELECT
            (   (
				/*seizouLnId*/,
				/*lnId*/,
				/*stId*/,
				/*buhinCd*/,
				/*dataDate*/,
				/*vtextInfo1*/,
				/*vtextInfo2*/,
				/*plantCd*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*processCd*/,
				/*processNm*/,
				/*lnNo*/,
				/*lnNm*/,
				/*stNo*/,
				/*stNm*/,
				/*updDate*/,
				/*planTheDayNum*/,
				/*planBeforeTheDayNum*/,
				/*planBeforeTwoDaysNum*/,
				/*actualTheDayNum*/,
				/*planTheDayValue*/,
				/*planBeforeTheDayValue*/,
				/*planBeforeTwoDaysValue*/,
				/*actualTheDayValue*/,
				/*insProg*/,
				/*insTim*/,
				/*insUserSid*/,
				/*updProg*/,
				/*updTim*/,
				/*updUserSid*/
                )::ag_product_mng_hourly).*
    ),

    upd AS (
        UPDATE
            ag_product_mng_hourly
        SET
			vtext_info2			= /*vtextInfo2*/,
			plant_cd			= /*plantCd*/,
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
			process_cd			= /*processCd*/,
			process_nm			= /*processNm*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			st_no				= /*stNo*/,
			st_nm				= /*stNm*/,
			upd_date			= CAST(/*updDate*/ AS timestamp),
			plan_the_day_num			= CAST(/*planTheDayNum*/ AS integer),
			plan_before_the_day_num		= CAST(/*planBeforeTheDayNum*/ AS integer),
			plan_before_two_days_num	= CAST(/*planBeforeTwoDaysNum*/ AS integer),
			actual_the_day_num			= CAST(/*actualTheDayNum*/ AS integer),
			plan_the_day_value			= CAST(/*planTheDayValue*/ AS integer),
			plan_before_the_day_value	= CAST(/*planBeforeTheDayValue*/ AS integer),
			plan_before_two_days_value	= CAST(/*planBeforeTwoDaysValue*/ AS integer),
			actual_the_day_value		= CAST(/*actualTheDayValue*/ AS integer),
			ins_prog			= /*insProg*/,
			ins_tim				= CAST(/*insTim*/ AS timestamp),
			ins_user_sid		= CAST(/*insUserSid*/ AS integer),
			upd_prog			= /*updProg*/,
			upd_tim				= CAST(/*updTim*/ AS timestamp),
			upd_user_sid		= CAST(/*updUserSid*/ AS integer)
        FROM
            val
        WHERE
            ag_product_mng_hourly.seizou_ln_id	= /*seizouLnId*/
        AND ag_product_mng_hourly.ln_id			= /*lnId*/
        AND ag_product_mng_hourly.st_id			= /*stId*/
        AND ag_product_mng_hourly.buhin_cd		= /*buhinCd*/
        AND ag_product_mng_hourly.data_date		= /*dataDate*/
        AND ag_product_mng_hourly.vtext_info1	= /*vtextInfo1*/

        RETURNING
            ag_product_mng_hourly.seizou_ln_id,
            ag_product_mng_hourly.ln_id,
            ag_product_mng_hourly.st_id,
            ag_product_mng_hourly.buhin_cd,
            ag_product_mng_hourly.data_date,
            ag_product_mng_hourly.vtext_info1
    )

INSERT INTO
    ag_product_mng_hourly
SELECT
    *
FROM
    val
WHERE
    (seizou_ln_id, ln_id, st_id, buhin_cd, data_date, vtext_info1)
        NOT IN (SELECT seizou_ln_id, ln_id, st_id, buhin_cd, data_date, vtext_info1 FROM upd);
