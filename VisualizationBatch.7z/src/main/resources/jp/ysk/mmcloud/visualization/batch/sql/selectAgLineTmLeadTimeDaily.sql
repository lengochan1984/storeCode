SELECT
    ln_id,
    n_ln_id,
    sasizu_no,
    sub_no,
    data_date,
    plant_cd,
    seizou_ln_cd,
    seizou_ln_nm,
    process_cd,
    process_nm,
    ln_no,
    ln_nm,
    lead_time,
    n_process_cd,
    n_process_nm,
    n_ln_no,
    n_ln_nm,
    ins_prog,
    ins_tim,
    ins_user_sid,
    upd_prog,
    upd_tim,
    upd_user_sid

FROM
    ag_line_tm_lead_time_daily

/*BEGIN*/
WHERE
    /*IF addDatetime != null*/
        (ins_tim >= /*addDatetime*/ AND upd_tim is null)
    OR  upd_tim >= /*addDatetime*/
    /*END*/
/*END*/

ORDER BY
    COALESCE(upd_tim, ins_tim)
