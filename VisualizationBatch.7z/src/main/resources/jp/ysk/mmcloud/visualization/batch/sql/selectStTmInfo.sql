SELECT
    CREATED_ON,
    CREATED_BY,
    COALESCE(MODIFIED_ON, CREATED_ON) as MODIFIED_ON,
    COALESCE(MODIFIED_BY, CREATED_BY) as MODIFIED_BY,
    SASIZU_NO,
    SUB_NO,
    SAGYO_SEQ,
    REPAIR_KAISU,
    ST_ID,
    PLANT_CD,
    SEIZOU_LN_CD,
    SEIZOU_LN_NM,
    PROCESS_CD,
    PROCESS_NM,
    LN_NO,
    LN_NM,
    ST_NO,
    ST_NM,
    SAGYOKU,
    END_TIME,
    END_STEP_NO,
    HANTEI,
    ALARM_MODE,
    SAGYO_JYOTAI,
    SAGYO_KEKA,
    N_START_TIME,
    N_SEIZOU_LN_CD,
    N_SEIZOU_LN_NM,
    N_PROCESS_CD,
    N_PROCESS_NM,
    N_LN_NO,
    N_LN_NM,
    N_ST_ID,
    N_ST_NO,
    N_ST_NM,
    N_SAGYOKU,
    STOP_TIME,
    STOP_TIME2,
    N_SAGYO_SEQ,
    SOUSIN_FLAG,
    SOUSIN_DATE,
    SPARE_NUM1,
    SPARE_NUM2,
    SPARE_NUM3,
    SPARE_TEXT1,
    SPARE_TEXT2,
    SPARE_TEXT3

FROM
    TR_ST_TM_INFO
WHERE
    N_ST_ID != null
    /*IF addDatetime != null */
    AND (
        (CREATED_ON >= /*addDatetime*/ AND MODIFIED_ON is null)
    OR  MODIFIED_ON >= /*addDatetime*/
    )
    /*END*/

ORDER BY
    COALESCE(MODIFIED_ON, CREATED_ON)
