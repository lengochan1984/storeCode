WITH
    val AS (
        SELECT
            (   (
                /*createdOn*/,
                /*createdBy*/,
                /*modifiedOn*/,
                /*modifiedBy*/,
				/*sasizuNo*/,
				/*subNo*/,
				/*sagyoSeq*/,
				/*repairKaisu*/,
				/*lnId*/,
				/*plantCd*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*processCd*/,
				/*processNm*/,
				/*lnNo*/,
				/*lnNm*/,
				/*startStId*/,
				/*startStNo*/,
				/*startStNm*/,
				/*startSagyoku*/,
				/*startStepNo*/,
				/*startTime*/,
				/*endStId*/,
				/*endStNo*/,
				/*endStNm*/,
				/*endSagyoku*/,
				/*endStepNo*/,
				/*endTime*/,
				/*workTime*/,
				/*hantei*/,
				/*almCd*/,
				/*sagyoSts*/,
				/*sagyoKeka*/,
                /*spareNum1*/,
                /*spareNum2*/,
                /*spareNum3*/,
                /*spareText1*/,
                /*spareText2*/,
                /*spareText3*/,
                'insert-TR_LINE_WORK_JSK_WK',
                now(),
                0,
                'insert-TR_LINE_WORK_JSK_WK',
                now(),
                0
                )::TR_LINE_WORK_JSK_WK).*
    ),

    upd AS (
        UPDATE
            TR_LINE_WORK_JSK_WK
        SET
			modified_on     	= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			plant_cd			= /*plantCd*/,
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
			process_cd			= /*processCd*/,
			process_nm			= /*processNm*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			start_st_id			= CAST(/*startStId*/ AS numeric),
			start_st_no			= /*startStNo*/,
			start_st_nm			= /*startStNm*/,
			start_sagyoku		= /*startSagyoku*/,
			start_step_no		= /*startStepNo*/,
			start_time			= CAST(/*startTime*/ AS timestamp),
			end_st_id			= CAST(/*endStId*/ AS numeric),
			end_st_no			= /*endStNo*/,
			end_st_nm			= /*endStNm*/,
			end_sagyoku			= /*endSagyoku*/,
			end_step_no			= /*endStepNo*/,
			end_time			= CAST(/*endTime*/ AS timestamp),
			work_time			= CAST(/*workTime*/ AS numeric),
			hantei				= CAST(/*hantei*/ AS numeric),
			alm_cd				= /*almCd*/,
			sagyo_sts			= CAST(/*sagyoSts*/ AS numeric),
			sagyo_keka			= CAST(/*sagyoKeka*/ AS numeric),
            spare_num1			= CAST(/*spareNum1*/ AS numeric),
            spare_num2			= CAST(/*spareNum2*/ AS numeric),
            spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-TR_LINE_WORK_JSK_WK',
			upd_tim				= now(),
			upd_user_sid		= 0

        FROM
            val
        WHERE
            TR_LINE_WORK_JSK_WK.sasizu_no		= /*sasizuNo*/
        AND TR_LINE_WORK_JSK_WK.sub_no			= /*subNo*/
        AND TR_LINE_WORK_JSK_WK.sagyo_seq		= /*sagyoSeq*/
        AND TR_LINE_WORK_JSK_WK.repair_kaisu	= /*repairKaisu*/
		AND TR_LINE_WORK_JSK_WK.ln_id			= /*lnId*/

        RETURNING
            TR_LINE_WORK_JSK_WK.sasizu_no,
            TR_LINE_WORK_JSK_WK.sub_no,
            TR_LINE_WORK_JSK_WK.sagyo_seq,
            TR_LINE_WORK_JSK_WK.repair_kaisu,
			TR_LINE_WORK_JSK_WK.ln_id
    )

INSERT INTO
    TR_LINE_WORK_JSK_WK
SELECT
    *
FROM
    val
WHERE
    (sasizu_no, sub_no, sagyo_seq, repair_kaisu, ln_id)
        NOT IN (SELECT sasizu_no, sub_no, sagyo_seq, repair_kaisu, ln_id FROM upd);