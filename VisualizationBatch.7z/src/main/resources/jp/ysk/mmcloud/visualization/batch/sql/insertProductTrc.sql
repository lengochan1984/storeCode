WITH
    val AS (
        SELECT
            (   (
                /*createdOn*/,
                /*createdBy*/,
                /*modifiedOn*/,
                /*modifiedBy*/,
				/*sasizuNo*/,
				/*subNo*/,
				/*sagyoSeq*/,
				/*sireiSu*/,
				/*buhinCd*/,
				/*syainNo*/,
				/*seihinSn*/,
				/*seihinLn*/,
				/*orderNo*/,
				/*prgno*/,
				/*startDate*/,
				/*endDate*/,
				/*hantei*/,
				/*seisanJyotai*/,
				/*repairKaisu*/,
				/*seizouLnId*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
                /*spareNum1*/,
                /*spareNum2*/,
                /*spareNum3*/,
                /*spareText1*/,
                /*spareText2*/,
                /*spareText3*/,
                'insert-TR_PRODUCT_TRC',
                now(),
                0,
                'insert-TR_PRODUCT_TRC',
                now(),
                0
                )::TR_PRODUCT_TRC).*
    ),

    upd AS (
        UPDATE
            TR_PRODUCT_TRC
        SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			sirei_su			= CAST(/*sireiSu*/ AS numeric),
			buhin_cd			= /*buhinCd*/,
			syain_no			= /*syainNo*/,
			seihin_sn			= /*seihinSn*/,
			seihin_ln			= /*seihinLn*/,
			order_no			= /*orderNo*/,
			prgno				= /*prgno*/,
			start_date			= CAST(/*startDate*/ AS timestamp),
			end_date			= CAST(/*endDate*/ AS timestamp),
			hantei				= CAST(/*hantei*/ AS numeric),
			seisan_jyotai		= CAST(/*seisanJyotai*/ AS integer),
			repair_kaisu		= CAST(/*repairKaisu*/ AS numeric),
			seizou_ln_id		= CAST(/*seizouLnId*/ AS numeric),
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
            spare_num1			= CAST(/*spareNum1*/ AS numeric),
            spare_num2			= CAST(/*spareNum2*/ AS numeric),
            spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog = 'update-TR_PRODUCT_TRC',
			upd_tim  = now(),
			upd_user_sid = 0
        FROM
            val
        WHERE
            TR_PRODUCT_TRC.sasizu_no = /*sasizuNo*/
        AND TR_PRODUCT_TRC.sub_no    = /*subNo*/
		AND TR_PRODUCT_TRC.sagyo_seq    = /*sagyoSeq*/

        RETURNING
            TR_PRODUCT_TRC.sasizu_no,
            TR_PRODUCT_TRC.sub_no,
			TR_PRODUCT_TRC.sagyo_seq
    )

INSERT INTO
    TR_PRODUCT_TRC
SELECT
    *
FROM
    val
WHERE
    (sasizu_no, sub_no, sagyo_seq) NOT IN (SELECT sasizu_no, sub_no, sagyo_seq FROM upd);
