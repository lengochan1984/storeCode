CREATE or REPLACE FUNCTION func_make_plans(
	in	i_batch_name	varchar,			-- バッチ処理名称
	in	i_log_type		numeric,			-- ログ種別(開始、および　各バッチ処理の復帰値)
											-- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
	in	i_user_sid		numeric,			-- 登録ユーザSID
	in	i_from_time		timestamp,			-- 集計開始日時(空の場合は当日を対象とする)
	in	i_to_time		timestamp,			-- 集計終了日時(空の場合は当日を対象とする)
	out	o_ret_cd		int,				-- 関数復帰値	RET_OK(= 0):正常終了
	out	o_sqlerr		varchar,			-- ＤＢ異常発生時のエラーコード
	out	o_errmsg		varchar,			-- 異常発生時のエラーメッセージ
	out	o_errpnt		varchar				-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　生産計画作成サービス
--　ソースプログラム名　：　func_prd_mng_hourly.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　生産計画を作成する
--
--　履歴
--	Ver.  作成日			作成者		COMMENT
--	1.0   2007/02/01		H.Nakamura	新規作成
--******************************************************************************
DECLARE
	----------------------------------------------------------------------------
	--						標準定数定義
	----------------------------------------------------------------------------
	-- 戻り値
	RET_OK		CONSTANT int := 0 ;						-- 正常終了コード
	RET_NG		CONSTANT int := -1 ;					-- 異常終了コード
	-- 真偽値
	CST_TRUE	CONSTANT int := 1 ;						-- 真
	CST_FALSE	CONSTANT int := 0 ;						-- 偽

	----------------------------------------------------------------------------
	--						標準変数定義
	----------------------------------------------------------------------------
	cst_MY_PRG	CONSTANT CHAR(32)	 := 'func_make_plans';				-- プログラム名
	cst_UPD_TIM	CHAR(17) ;												-- 更新時間
	l_err_pnt	CHAR(64) ;												-- エラー発生ポイント
	errbuff		varchar(256);											-- メッセージバッファ

	----------------------------------------------------------------------------
	--						定数定義
	----------------------------------------------------------------------------
	CST_FUNC_NAME_PLAN_MNG_HOURLY		CONSTANT char(32)	:= 'func_plan_mng_hourly';			-- 製品生産計画実績(時間別)(計画)ファンクション名

	----------------------------------------------------------------------------
	--						変数定義
	----------------------------------------------------------------------------
	-- 共通変数
	rtn_sql_no		text;							-- DBエラー情報(エラー番号)
	rtn_sql_msg		text;							-- DBエラー情報(エラーメッセージ)
	rtn_sql_detail	text;							-- DBエラー情報(エラー詳細)
	rtn_sql_hint	text;							-- DBエラー情報(エラーヒント)
	rtn_sql_stack	text;							-- DBエラー情報(エラー発生呼出しスタック)

	-- ローカル変数
	l_exec_datetime				timestamp;			-- 関数実行日時
	l_proc_start_time_hourly	timestamp;			-- 処理開始日時(時間別)
	l_proc_end_time_hourly		timestamp;			-- 処理終了日時(時間別)
	l_proc_start_time_daily		timestamp;			-- 処理開始日時(日次)
	l_proc_end_time_daily		timestamp;			-- 処理終了日時(日次)
	l_proc_start_time_monthly	timestamp;			-- 処理開始日時(月次)
	l_proc_end_time_monthly		timestamp;			-- 処理終了日時(月次)
	l_proc_start_time_yearly	timestamp;			-- 処理開始日時(年次)
	l_proc_end_time_yearly		timestamp;			-- 処理終了日時(年次)
	l_plant_code				char(2);			-- 工場コード
	l_running_start_datetime	timestamp;			-- 稼働開始日時(年度開始日時)
	o_ret_cd_wk					int;
	o_sqlerr_wk					varchar;
	o_errmsg_wk					varchar;
	o_errpnt_wk					varchar;

	----------------------------------------------------------------------------
	--						カーソル定義
	----------------------------------------------------------------------------
	-- 工場マスタ
	CUR_MST_PLANT	CURSOR FOR
		SELECT
			T0.PLANT_CODE				as plantCode,
			T1.RUNNING_START_DATETIME	as runningStartDatetime
		FROM
			MST_PLANT	T0
		LEFT OUTER JOIN
			MST_PLANT_MIERUKA	T1
		ON
				T1.PLANT_CODE	= T0.PLANT_CODE
			AND	T1.INVALID_FLAG	= 0
		WHERE
			T0.INVALID_FLAG = 0
		ORDER BY
			T0.PLANT_CODE
	;

	OPENFLG_MST_PLANT	int;	-- カーソルオープン状態

	-- 製品生産計画実績(時間別)
	CUR_TBL_PRODUCT_MANAGEMENT_HOURLY	CURSOR FOR
		SELECT
			*
		FROM
			TBL_PRODUCT_MANAGEMENT_HOURLY
		WHERE
				PLANT_CODE	=  l_plant_code
			AND	DATA_DATE	>= l_proc_start_time_hourly
			AND	DATA_DATE	<= l_proc_end_time_hourly
		FOR UPDATE NOWAIT
	;

	OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY	int;	-- カーソルオープン状態
	REC_TBL_PRODUCT_MANAGEMENT_HOURLY		TBL_PRODUCT_MANAGEMENT_HOURLY%ROWTYPE;

	-- 製品生産計画実績(日別)
	CUR_TBL_PRODUCT_MANAGEMENT_DAILY	CURSOR FOR
		SELECT
			*
		FROM
			TBL_PRODUCT_MANAGEMENT_DAILY
		WHERE
				PLANT_CODE	=  l_plant_code
			AND	DATA_DATE	>= l_proc_start_time_daily
			AND	DATA_DATE	<= l_proc_end_time_daily
		FOR UPDATE NOWAIT
	;

	OPENFLG_TBL_PRODUCT_MANAGEMENT_DAILY	int;	-- カーソルオープン状態
	REC_TBL_PRODUCT_MANAGEMENT_DAILY		TBL_PRODUCT_MANAGEMENT_DAILY%ROWTYPE;

	-- 製品生産計画実績(年別)
	CUR_TBL_PRODUCT_MANAGEMENT_MONTHLY	CURSOR FOR
		SELECT
			*
		FROM
			TBL_PRODUCT_MANAGEMENT_MONTHLY
		WHERE
				PLANT_CODE	=  l_plant_code
			AND	DATA_DATE	>= l_proc_start_time_monthly
			AND	DATA_DATE	<= l_proc_end_time_monthly
		FOR UPDATE NOWAIT
	;

	OPENFLG_TBL_PRODUCT_MANAGEMENT_MONTHLY	int;	-- カーソルオープン状態
	REC_TBL_PRODUCT_MANAGEMENT_MONTHLY		TBL_PRODUCT_MANAGEMENT_MONTHLY%ROWTYPE;

	-- ライン計画/実績(時間別)
	CUR_TBL_LINE_WORK_HOURLY	CURSOR FOR
		SELECT
			*
		FROM
			TBL_LINE_WORK_HOURLY
		WHERE
				PLANT_CODE	=  l_plant_code
			AND	DATA_DATE	>= l_proc_start_time_hourly
			AND	DATA_DATE	<= l_proc_end_time_hourly
		FOR UPDATE NOWAIT
	;

	OPENFLG_TBL_LINE_WORK_HOURLY	int;	-- カーソルオープン状態
	REC_TBL_LINE_WORK_HOURLY		TBL_LINE_WORK_HOURLY%ROWTYPE;

	-- ライン計画/実績(日別)
	CUR_TBL_LINE_WORK_DAILY	CURSOR FOR
		SELECT
			*
		FROM
			TBL_LINE_WORK_DAILY
		WHERE
				PLANT_CODE	=  l_plant_code
			AND	DATA_DATE	>= l_proc_start_time_daily
			AND	DATA_DATE	<= l_proc_end_time_daily
		FOR UPDATE NOWAIT
	;

	OPENFLG_TBL_LINE_WORK_DAILY	int;	-- カーソルオープン状態
	REC_TBL_LINE_WORK_DAILY		TBL_LINE_WORK_DAILY%ROWTYPE;

	-- ライン計画/実績(月別)
	CUR_TBL_LINE_WORK_MONTHLY	CURSOR FOR
		SELECT
			*
		FROM
			TBL_LINE_WORK_MONTHLY
		WHERE
				PLANT_CODE	=  l_plant_code
			AND	DATA_DATE	>= l_proc_start_time_monthly
			AND	DATA_DATE	<= l_proc_end_time_monthly
		FOR UPDATE NOWAIT
	;

	OPENFLG_TBL_LINE_WORK_MONTHLY	int;	-- カーソルオープン状態
	REC_TBL_LINE_WORK_MONTHLY		TBL_LINE_WORK_MONTHLY%ROWTYPE;

	-- [サイネージ用]製品生産計画実績(日別)
	CUR_TBL_DS_PRODUCT_MNG_DAILY	CURSOR FOR
		SELECT
			*
		FROM
			TBL_DS_PRODUCT_MNG_DAILY
		WHERE
				PLANT_CODE	=  l_plant_code
			AND	DATA_DATE	>= l_proc_start_time_daily
			AND	DATA_DATE	<= l_proc_end_time_daily
		FOR UPDATE NOWAIT
	;

	OPENFLG_TBL_DS_PRODUCT_MNG_DAILY	int;	-- カーソルオープン状態
	REC_TBL_DS_PRODUCT_MNG_DAILY		TBL_DS_PRODUCT_MNG_DAILY%ROWTYPE;

	-- [サイネージ用]製品生産計画実績(月別)
	CUR_TBL_DS_PRODUCT_MNG_MONTHLY	CURSOR FOR
		SELECT
			*
		FROM
			TBL_DS_PRODUCT_MNG_MONTHLY
		WHERE
				PLANT_CODE	=  l_plant_code
			AND	DATA_DATE	>= l_proc_start_time_monthly
			AND	DATA_DATE	<= l_proc_end_time_monthly
		FOR UPDATE NOWAIT
	;

	OPENFLG_TBL_DS_PRODUCT_MNG_MONTHLY	int;	-- カーソルオープン状態
	REC_TBL_DS_PRODUCT_MNG_MONTHLY		TBL_DS_PRODUCT_MNG_MONTHLY%ROWTYPE;

	-- [サイネージ用]製品生産計画実績(年別)
	CUR_TBL_DS_PRODUCT_MNG_YEARLY	CURSOR FOR
		SELECT
			*
		FROM
			TBL_DS_PRODUCT_MNG_YEARLY
		WHERE
				PLANT_CODE	=  l_plant_code
			AND	DATA_DATE	>= l_proc_start_time_yearly
			AND	DATA_DATE	<= l_proc_end_time_yearly
		FOR UPDATE NOWAIT
	;

	OPENFLG_TBL_DS_PRODUCT_MNG_YEARLY	int;	-- カーソルオープン状態
	REC_TBL_DS_PRODUCT_MNG_YEARLY		TBL_DS_PRODUCT_MNG_YEARLY%ROWTYPE;

	-- MESデータ連携記録テーブル
	CUR_TBL_TRANSFER_DATETIME	CURSOR FOR
		SELECT
			*
		FROM
			TBL_TRANSFER_DATETIME
		WHERE
			ADD_TABLE_NAME = CST_FUNC_NAME_PLAN_MNG_HOURLY
		FOR UPDATE NOWAIT
	;

	OPENFLG_TBL_TRANSFER_DATETIME	int;	-- カーソルオープン状態
	REC_TBL_TRANSFER_DATETIME		TBL_TRANSFER_DATETIME%ROWTYPE;

BEGIN
	----------------------------------------------------------------------------
	--						初期処理
	----------------------------------------------------------------------------
	raise info 'Start Function [%]', clock_timestamp()::timestamp;

	-- 共通変数初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S001';

	-- 共通出力パラメータ初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
	o_ret_cd	:= RET_OK;
	o_sqlerr	:= ' ';
	o_errmsg	:= ' ';
	o_errpnt	:= ' ';

	-- 関数実行日時
	l_exec_datetime := clock_timestamp();

	-- 集計開始/終了日時補正
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
	IF i_from_time IS NULL THEN
		i_from_time := l_exec_datetime;
	END IF;
	IF i_to_time IS NULL OR i_from_time > i_to_time THEN
		i_to_time := l_exec_datetime;
	END IF;

	-- ローカル変数初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S004';
	OPENFLG_MST_PLANT := CST_FALSE;
	OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY := CST_FALSE;
	OPENFLG_TBL_PRODUCT_MANAGEMENT_DAILY := CST_FALSE;
	OPENFLG_TBL_PRODUCT_MANAGEMENT_MONTHLY := CST_FALSE;
	OPENFLG_TBL_LINE_WORK_HOURLY := CST_FALSE;
	OPENFLG_TBL_LINE_WORK_DAILY := CST_FALSE;
	OPENFLG_TBL_LINE_WORK_MONTHLY := CST_FALSE;
	OPENFLG_TBL_DS_PRODUCT_MNG_DAILY := CST_FALSE;
	OPENFLG_TBL_DS_PRODUCT_MNG_MONTHLY := CST_FALSE;
	OPENFLG_TBL_DS_PRODUCT_MNG_YEARLY := CST_FALSE;
	OPENFLG_TBL_TRANSFER_DATETIME := CST_FALSE;

	----------------------------------------------------------------------------
	-- メイン処理
	----------------------------------------------------------------------------
	<< MAIN_LOOP >>
	LOOP
		--------------------------------------------------------
		-- 計画値クリア
		--------------------------------------------------------
		------------------------------------------------------------------------
		-- 工場ごとに稼働開始日時が異なるので、工場マスタで処理を回す
		------------------------------------------------------------------------
		-- 工場マスタを開いているならクローズ
		l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
		IF OPENFLG_MST_PLANT = CST_TRUE THEN
			CLOSE CUR_MST_PLANT;
			OPENFLG_MST_PLANT := CST_FALSE;
		END IF;

		-- 工場マスタをオープン
		l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
		OPEN CUR_MST_PLANT;
		OPENFLG_MST_PLANT := CST_TRUE;

		<< PLANT_LOOP >>
		LOOP
			-- 工場マスタからフェッチ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_103';
			FETCH CUR_MST_PLANT INTO l_plant_code, l_running_start_datetime;
			IF FOUND = FALSE THEN
				EXIT PLANT_LOOP;
			END IF;

			IF l_running_start_datetime IS NULL THEN
				-- NULLの場合はデフォルト値をセット
				l_err_pnt := RTRIM(cst_MY_PRG) || '_104';
				l_running_start_datetime = timestamp '0001-03-21 07:00:00';
			END IF;

			-- 処理開始日時(時間別)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_105';
			SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_hourly;
			<< START_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_106';
				IF i_from_time >= l_proc_start_time_hourly THEN
					EXIT START_TIME_LOOP;
				END IF;
				l_proc_start_time_hourly := l_proc_start_time_hourly + interval '-1 days';
			END LOOP	START_TIME_LOOP;

			-- 処理終了日時(時間別)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_107';
			SELECT l_proc_start_time_hourly + interval '1 days' + interval '-1 milliseconds' INTO l_proc_end_time_hourly;
			<< END_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_108';
				IF i_to_time <= l_proc_end_time_hourly THEN
					EXIT END_TIME_LOOP;
				END IF;
				l_proc_end_time_hourly := l_proc_end_time_hourly + interval '1 days';
			END LOOP	END_TIME_LOOP;

			-- 処理開始日時(日次)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_109';
			l_proc_start_time_daily := l_proc_start_time_hourly;

			-- 処理終了日時(日次)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_110';
			l_proc_end_time_daily := l_proc_end_time_hourly;

			-- 処理開始日時(月次)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_111';
			SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM') || '-' || to_char(l_running_start_datetime, 'DD HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_monthly;
			<< START_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_112';
				IF i_from_time >= l_proc_start_time_monthly THEN
					EXIT START_TIME_LOOP;
				END IF;
				l_proc_start_time_monthly := l_proc_start_time_monthly + interval '-1 months';
			END LOOP	START_TIME_LOOP;

			-- 処理終了日時(月次)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_113';
			SELECT l_proc_start_time_monthly + interval '1 months' + interval '-1 milliseconds' INTO l_proc_end_time_monthly;
			<< END_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_114';
				IF i_to_time <= l_proc_end_time_monthly THEN
					EXIT END_TIME_LOOP;
				END IF;
				l_proc_end_time_monthly := l_proc_end_time_monthly + interval '1 months';
			END LOOP	END_TIME_LOOP;

			-- 処理開始日時(年次)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_115';
			SELECT to_timestamp(to_char(i_from_time, 'YYYY') || '-' || to_char(l_running_start_datetime, 'MM-DD HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_yearly;
			<< START_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_116';
				IF i_from_time >= l_proc_start_time_yearly THEN
					EXIT START_TIME_LOOP;
				END IF;
				l_proc_start_time_yearly := l_proc_start_time_yearly + interval '-1 years';
			END LOOP	START_TIME_LOOP;

			-- 処理終了日時(年次)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_117';
			SELECT l_proc_start_time_yearly + interval '1 years' + interval '-1 milliseconds' INTO l_proc_end_time_yearly;
			<< END_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_118';
				IF i_to_time <= l_proc_end_time_yearly THEN
					EXIT END_TIME_LOOP;
				END IF;
				l_proc_end_time_yearly := l_proc_end_time_yearly + interval '1 years';
			END LOOP	END_TIME_LOOP;

			--------------------------------------------
			-- 製品生産計画実績(時間別)
			--------------------------------------------
--			raise info 'Init Plans TBL_PRODUCT_MANAGEMENT_HOURLY [%][% - %]', l_plant_code, l_proc_start_time_hourly, l_proc_end_time_hourly;
			-- 製品生産計画実績(時間別)をオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
			OPEN CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;
			OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY := CST_TRUE;

			<< PROC_LOOP >>
			LOOP
				-- 製品生産計画実績(時間別)からフェッチ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_202';
				FETCH CUR_TBL_PRODUCT_MANAGEMENT_HOURLY INTO REC_TBL_PRODUCT_MANAGEMENT_HOURLY;
				IF FOUND = FALSE THEN
					-- データがない場合
					l_err_pnt := RTRIM(cst_MY_PRG) || '_203';
					EXIT PROC_LOOP;
				END IF;

				-- 製品生産計画実績(時間別)を更新
				l_err_pnt := RTRIM(cst_MY_PRG) || '_204';
				UPDATE
					TBL_PRODUCT_MANAGEMENT_HOURLY
				SET
					PLAN_THE_DAY_NUM			= -1,				-- 計画(当日)台数
					PLAN_BEFORE_THE_DAY_NUM		= -1,				-- 計画(前日)台数
					PLAN_BEFORE_TWO_DAYS_NUM	= -1,				-- 計画(前々日)台数
					PLAN_THE_DAY_VALUE			= -1,				-- 計画(当日)金額
					PLAN_BEFORE_THE_DAY_VALUE	= -1,				-- 計画(前日)金額
					PLAN_BEFORE_TWO_DAYS_VALUE	= -1,				-- 計画(前々日)金額
					UPD_PROG					= cst_MY_PRG,		-- 更新プログラム
					UPD_TIM						= l_exec_datetime,	-- 更新日時
					UPD_USER_SID				= i_user_sid		-- 更新ユーザSID
				WHERE CURRENT OF CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;
			END LOOP	PROC_LOOP;

			-- 製品生産計画実績(時間別)をクローズ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_205';
			CLOSE CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;
			OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY := CST_FALSE;

			--------------------------------------------
			-- 製品生産計画実績(日別)
			--------------------------------------------
--			raise info 'Init Plans TBL_PRODUCT_MANAGEMENT_DAILY [%][% - %]', l_plant_code, l_proc_start_time_daily, l_proc_end_time_daily;
			-- 製品生産計画実績(日別)をオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_301';
			OPEN CUR_TBL_PRODUCT_MANAGEMENT_DAILY;
			OPENFLG_TBL_PRODUCT_MANAGEMENT_DAILY := CST_TRUE;

			<< PROC_LOOP >>
			LOOP
				-- 製品生産計画実績(日別)からフェッチ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_302';
				FETCH CUR_TBL_PRODUCT_MANAGEMENT_DAILY INTO REC_TBL_PRODUCT_MANAGEMENT_DAILY;
				IF FOUND = FALSE THEN
					-- データがない場合
					l_err_pnt := RTRIM(cst_MY_PRG) || '_303';
					EXIT PROC_LOOP;
				END IF;

				-- 製品生産計画実績(日別)を更新
				l_err_pnt := RTRIM(cst_MY_PRG) || '_304';
				UPDATE
					TBL_PRODUCT_MANAGEMENT_DAILY
				SET
					PLAN_THE_DAY_NUM			= -1,				-- 計画(当日)台数
					PLAN_BEFORE_THE_DAY_NUM		= -1,				-- 計画(前日)台数
					PLAN_BEFORE_TWO_DAYS_NUM	= -1,				-- 計画(前々日)台数
					PLAN_THE_DAY_VALUE			= -1,				-- 計画(当日)金額
					PLAN_BEFORE_THE_DAY_VALUE	= -1,				-- 計画(前日)金額
					PLAN_BEFORE_TWO_DAYS_VALUE	= -1,				-- 計画(前々日)金額
					UPD_PROG					= cst_MY_PRG,		-- 更新プログラム
					UPD_TIM						= l_exec_datetime,	-- 更新日時
					UPD_USER_SID				= i_user_sid		-- 更新ユーザSID
				WHERE CURRENT OF CUR_TBL_PRODUCT_MANAGEMENT_DAILY;
			END LOOP	PROC_LOOP;

			-- 製品生産計画実績(日別)をクローズ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_305';
			CLOSE CUR_TBL_PRODUCT_MANAGEMENT_DAILY;
			OPENFLG_TBL_PRODUCT_MANAGEMENT_DAILY := CST_FALSE;

			--------------------------------------------
			-- 製品生産計画実績(月別)
			--------------------------------------------
--			raise info 'Init Plans TBL_PRODUCT_MANAGEMENT_MONTHLY [%][% - %]', l_plant_code, l_proc_start_time_monthly, l_proc_end_time_monthly;
			-- 製品生産計画実績(月別)をオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_401';
			OPEN CUR_TBL_PRODUCT_MANAGEMENT_MONTHLY;
			OPENFLG_TBL_PRODUCT_MANAGEMENT_MONTHLY := CST_TRUE;

			<< PROC_LOOP >>
			LOOP
				-- 製品生産計画実績(月別)からフェッチ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_402';
				FETCH CUR_TBL_PRODUCT_MANAGEMENT_MONTHLY INTO REC_TBL_PRODUCT_MANAGEMENT_MONTHLY;
				IF FOUND = FALSE THEN
					-- データがない場合
					l_err_pnt := RTRIM(cst_MY_PRG) || '_403';
					EXIT PROC_LOOP;
				END IF;

				-- 製品生産計画実績(月別)を更新
				l_err_pnt := RTRIM(cst_MY_PRG) || '_404';
				UPDATE
					TBL_PRODUCT_MANAGEMENT_MONTHLY
				SET
					PLAN_THE_DAY_NUM			= -1,				-- 計画(当日)台数
					PLAN_BEFORE_THE_DAY_NUM		= -1,				-- 計画(前日)台数
					PLAN_BEFORE_TWO_DAYS_NUM	= -1,				-- 計画(前々日)台数
					PLAN_THE_DAY_VALUE			= -1,				-- 計画(当日)金額
					PLAN_BEFORE_THE_DAY_VALUE	= -1,				-- 計画(前日)金額
					PLAN_BEFORE_TWO_DAYS_VALUE	= -1,				-- 計画(前々日)金額
					UPD_PROG					= cst_MY_PRG,		-- 更新プログラム
					UPD_TIM						= l_exec_datetime,	-- 更新日時
					UPD_USER_SID				= i_user_sid		-- 更新ユーザSID
				WHERE CURRENT OF CUR_TBL_PRODUCT_MANAGEMENT_MONTHLY;
			END LOOP	PROC_LOOP;

			-- 製品生産計画実績(月別)クローズ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_405';
			CLOSE CUR_TBL_PRODUCT_MANAGEMENT_MONTHLY;
			OPENFLG_TBL_PRODUCT_MANAGEMENT_MONTHLY := CST_FALSE;

			--------------------------------------------
			-- ライン計画/実績(時間別)
			--------------------------------------------
--			raise info 'Init Plans TBL_LINE_WORK_HOURLY [%][% - %]', l_plant_code, l_proc_start_time_hourly, l_proc_end_time_hourly;
			-- ライン計画/実績(時間別)をオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_501';
			OPEN CUR_TBL_LINE_WORK_HOURLY;
			OPENFLG_TBL_LINE_WORK_HOURLY := CST_TRUE;

			<< PROC_LOOP >>
			LOOP
				-- ライン計画/実績(時間別)からフェッチ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_502';
				FETCH CUR_TBL_LINE_WORK_HOURLY INTO REC_TBL_LINE_WORK_HOURLY;
				IF FOUND = FALSE THEN
					-- データがない場合
					l_err_pnt := RTRIM(cst_MY_PRG) || '_503';
					EXIT PROC_LOOP;
				END IF;

				-- ライン計画/実績(時間別)を更新
				l_err_pnt := RTRIM(cst_MY_PRG) || '_504';
				UPDATE
					TBL_LINE_WORK_HOURLY
				SET
					PLAN_NUM		= -1,				-- 計画数
					UPD_PROG		= cst_MY_PRG,		-- 更新プログラム
					UPD_TIM			= l_exec_datetime,	-- 更新日時
					UPD_USER_SID	= i_user_sid		-- 更新ユーザSID
				WHERE CURRENT OF CUR_TBL_LINE_WORK_HOURLY;
			END LOOP	PROC_LOOP;

			-- ライン計画/実績(時間別)クローズ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_505';
			CLOSE CUR_TBL_LINE_WORK_HOURLY;
			OPENFLG_TBL_LINE_WORK_HOURLY := CST_FALSE;

			--------------------------------------------
			-- ライン計画/実績(日別)
			--------------------------------------------
--			raise info 'Init Plans TBL_LINE_WORK_DAILY [%][% - %]', l_plant_code, l_proc_start_time_daily, l_proc_end_time_daily;
			-- ライン計画/実績(日別)をオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_601';
			OPEN CUR_TBL_LINE_WORK_DAILY;
			OPENFLG_TBL_LINE_WORK_DAILY := CST_TRUE;

			<< PROC_LOOP >>
			LOOP
				-- ライン計画/実績(日別)からフェッチ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_602';
				FETCH CUR_TBL_LINE_WORK_DAILY INTO REC_TBL_LINE_WORK_DAILY;
				IF FOUND = FALSE THEN
					-- データがない場合
					l_err_pnt := RTRIM(cst_MY_PRG) || '_603';
					EXIT PROC_LOOP;
				END IF;

				-- ライン計画/実績(日別)を更新
				l_err_pnt := RTRIM(cst_MY_PRG) || '_604';
				UPDATE
					TBL_LINE_WORK_DAILY
				SET
					PLAN_NUM		= -1,				-- 計画数
					UPD_PROG		= cst_MY_PRG,		-- 更新プログラム
					UPD_TIM			= l_exec_datetime,	-- 更新日時
					UPD_USER_SID	= i_user_sid		-- 更新ユーザSID
				WHERE CURRENT OF CUR_TBL_LINE_WORK_DAILY;
			END LOOP	PROC_LOOP;

			-- ライン計画/実績(日別)をクローズ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_605';
			CLOSE CUR_TBL_LINE_WORK_DAILY;
			OPENFLG_TBL_LINE_WORK_DAILY := CST_FALSE;

			--------------------------------------------
			-- ライン計画/実績(月別)
			--------------------------------------------
--			raise info 'Init Plans TBL_LINE_WORK_MONTHLY [%][% - %]', l_plant_code, l_proc_start_time_monthly, l_proc_end_time_monthly;
			-- ライン計画/実績(月別)をオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_701';
			OPEN CUR_TBL_LINE_WORK_MONTHLY;
			OPENFLG_TBL_LINE_WORK_MONTHLY := CST_TRUE;

			<< PROC_LOOP >>
			LOOP
				-- ライン計画/実績(月別)からフェッチ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_702';
				FETCH CUR_TBL_LINE_WORK_MONTHLY INTO REC_TBL_LINE_WORK_MONTHLY;
				IF FOUND = FALSE THEN
					-- データがない場合
					l_err_pnt := RTRIM(cst_MY_PRG) || '_703';
					EXIT PROC_LOOP;
				END IF;

				-- ライン計画/実績(月別)を更新
				l_err_pnt := RTRIM(cst_MY_PRG) || '704';
				UPDATE
					TBL_LINE_WORK_MONTHLY
				SET
					PLAN_NUM		= -1,				-- 計画数
					UPD_PROG		= cst_MY_PRG,		-- 更新プログラム
					UPD_TIM			= l_exec_datetime,	-- 更新日時
					UPD_USER_SID	= i_user_sid		-- 更新ユーザSID
				WHERE CURRENT OF CUR_TBL_LINE_WORK_MONTHLY;
			END LOOP	PROC_LOOP;

			-- ライン計画/実績(月別)をクローズ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_705';
			CLOSE CUR_TBL_LINE_WORK_MONTHLY;
			OPENFLG_TBL_LINE_WORK_MONTHLY := CST_FALSE;

			--------------------------------------------
			-- [サイネージ用]製品生産計画実績(日別)
			--------------------------------------------
--			raise info 'Init Plans TBL_DS_PRODUCT_MNG_DAILY [%][% - %]', l_plant_code, l_proc_start_time_daily, l_proc_end_time_daily;
			-- [サイネージ用]製品生産計画実績(日別)をオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_801';
			OPEN CUR_TBL_DS_PRODUCT_MNG_DAILY;
			OPENFLG_TBL_DS_PRODUCT_MNG_DAILY := CST_TRUE;

			<< PROC_LOOP >>
			LOOP
				-- [サイネージ用]製品生産計画実績(日別)からフェッチ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_802';
				FETCH CUR_TBL_DS_PRODUCT_MNG_DAILY INTO REC_TBL_DS_PRODUCT_MNG_DAILY;
				IF FOUND = FALSE THEN
					-- データがない場合
					l_err_pnt := RTRIM(cst_MY_PRG) || '_803';
					EXIT PROC_LOOP;
				END IF;

				-- [サイネージ用]製品生産計画実績(日別)を更新
				l_err_pnt := RTRIM(cst_MY_PRG) || '_804';
				UPDATE
					TBL_DS_PRODUCT_MNG_DAILY
				SET
					PLAN_NUM		= 0,				-- 計画数
					UPD_PROG		= cst_MY_PRG,		-- 更新プログラム
					UPD_TIM			= l_exec_datetime,	-- 更新日時
					UPD_USER_SID	= i_user_sid		-- 更新ユーザSID
				WHERE CURRENT OF CUR_TBL_DS_PRODUCT_MNG_DAILY;
			END LOOP	PROC_LOOP;

			-- [サイネージ用]製品生産計画実績(日別)をクローズ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_805';
			CLOSE CUR_TBL_DS_PRODUCT_MNG_DAILY;
			OPENFLG_TBL_DS_PRODUCT_MNG_DAILY := CST_FALSE;

			--------------------------------------------
			-- [サイネージ用]製品生産計画実績(月別)
			--------------------------------------------
--			raise info 'Init Plans TBL_DS_PRODUCT_MNG_MONTHLY [%][% - %]', l_plant_code, l_proc_start_time_monthly, l_proc_end_time_monthly;
			-- [サイネージ用]製品生産計画実績(月別)をオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_901';
			OPEN CUR_TBL_DS_PRODUCT_MNG_MONTHLY;
			OPENFLG_TBL_DS_PRODUCT_MNG_MONTHLY := CST_TRUE;

			<< PROC_LOOP >>
			LOOP
				-- [サイネージ用]製品生産計画実績(月別)からフェッチ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_902';
				FETCH CUR_TBL_DS_PRODUCT_MNG_MONTHLY INTO REC_TBL_DS_PRODUCT_MNG_MONTHLY;
				IF FOUND = FALSE THEN
					-- データがない場合
					l_err_pnt := RTRIM(cst_MY_PRG) || '_903';
					EXIT PROC_LOOP;
				END IF;

				-- [サイネージ用]製品生産計画実績(月別)を更新
				l_err_pnt := RTRIM(cst_MY_PRG) || '_904';
				UPDATE
					TBL_DS_PRODUCT_MNG_MONTHLY
				SET
					PLAN_NUM		= 0,				-- 計画数
					UPD_PROG		= cst_MY_PRG,		-- 更新プログラム
					UPD_TIM			= l_exec_datetime,	-- 更新日時
					UPD_USER_SID	= i_user_sid		-- 更新ユーザSID
				WHERE CURRENT OF CUR_TBL_DS_PRODUCT_MNG_MONTHLY;
			END LOOP	PROC_LOOP;

			-- [サイネージ用]製品生産計画実績(月別)をクローズ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_905';
			CLOSE CUR_TBL_DS_PRODUCT_MNG_MONTHLY;
			OPENFLG_TBL_DS_PRODUCT_MNG_MONTHLY := CST_FALSE;

			--------------------------------------------
			-- [サイネージ用]製品生産計画実績(年別)
			--------------------------------------------
--			raise info 'Init Plans TBL_DS_PRODUCT_MNG_YEARLY [%][% - %]', l_plant_code, l_proc_start_time_yearly, l_proc_end_time_yearly;
			-- [サイネージ用]製品生産計画実績(年別)をオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_A01';
			OPEN CUR_TBL_DS_PRODUCT_MNG_YEARLY;
			OPENFLG_TBL_DS_PRODUCT_MNG_YEARLY := CST_TRUE;

			<< PROC_LOOP >>
			LOOP
				-- [サイネージ用]製品生産計画実績(年別)からフェッチ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_A02';
				FETCH CUR_TBL_DS_PRODUCT_MNG_YEARLY INTO REC_TBL_DS_PRODUCT_MNG_YEARLY;
				IF FOUND = FALSE THEN
					-- データがない場合
					l_err_pnt := RTRIM(cst_MY_PRG) || '_A03';
					EXIT PROC_LOOP;
				END IF;

				-- [サイネージ用]製品生産計画実績(年別)を更新
				l_err_pnt := RTRIM(cst_MY_PRG) || '_A04';
				UPDATE
					TBL_DS_PRODUCT_MNG_YEARLY
				SET
					PLAN_NUM		= 0,				-- 計画数
					UPD_PROG		= cst_MY_PRG,		-- 更新プログラム
					UPD_TIM			= l_exec_datetime,	-- 更新日時
					UPD_USER_SID	= i_user_sid		-- 更新ユーザSID
				WHERE CURRENT OF CUR_TBL_DS_PRODUCT_MNG_YEARLY;
			END LOOP	PROC_LOOP;

			-- [サイネージ用]製品生産計画実績(年別)をクローズ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_A05';
			CLOSE CUR_TBL_DS_PRODUCT_MNG_YEARLY;
			OPENFLG_TBL_DS_PRODUCT_MNG_YEARLY := CST_FALSE;

		END LOOP	PLANT_LOOP;

		-- 工場マスタをクローズ
		l_err_pnt := RTRIM(cst_MY_PRG) || '_119';
		CLOSE CUR_MST_PLANT;
		OPENFLG_MST_PLANT := CST_FALSE;

		--------------------------------------------------------
		-- 計画値設定＆再集計
		--------------------------------------------------------
		--------------------------------------------
		-- MESデータ連携記録テーブル
		--------------------------------------------
		-- MESデータ連携記録テーブルをオープン
		l_err_pnt := RTRIM(cst_MY_PRG) || '_801';
		OPEN CUR_TBL_TRANSFER_DATETIME;
		OPENFLG_TBL_TRANSFER_DATETIME := CST_TRUE;

		<< PROC_LOOP >>
		LOOP
			-- MESデータ連携記録テーブルからフェッチ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_802';
			FETCH CUR_TBL_TRANSFER_DATETIME INTO REC_TBL_TRANSFER_DATETIME;
			IF FOUND = FALSE THEN
				-- データがない場合
				l_err_pnt := RTRIM(cst_MY_PRG) || '_803';
				EXIT PROC_LOOP;
			END IF;

			-- MESデータ連携記録テーブルを削除
			l_err_pnt := RTRIM(cst_MY_PRG) || '_804';
			DELETE
			FROM
				TBL_TRANSFER_DATETIME
			WHERE CURRENT OF CUR_TBL_TRANSFER_DATETIME;
		END LOOP	PROC_LOOP;

		-- MESデータ連携記録テーブルをクローズ
		l_err_pnt := RTRIM(cst_MY_PRG) || '_805';
		CLOSE CUR_TBL_TRANSFER_DATETIME;
		OPENFLG_TBL_TRANSFER_DATETIME := CST_FALSE;

		-- 製品生産計画実績(時間別)(計画)
		l_err_pnt := RTRIM(cst_MY_PRG) || '_B01';
		SELECT * INTO o_ret_cd_wk, o_sqlerr_wk, o_errmsg_wk, o_errpnt_wk FROM func_plan_mng_hourly(i_batch_name, i_log_type, i_user_sid, i_from_time, i_to_time);
		IF o_ret_cd_wk = RET_NG THEN
			o_ret_cd = o_ret_cd_wk;
			o_sqlerr = o_sqlerr_wk;
			o_errmsg = o_errmsg_wk;
			o_errpnt = o_errpnt_wk;
			EXIT MAIN_LOOP;
		END IF;

		-- 製品生産計画実績(日別)
		l_err_pnt := RTRIM(cst_MY_PRG) || '_B02';
		SELECT * INTO o_ret_cd_wk, o_sqlerr_wk, o_errmsg_wk, o_errpnt_wk FROM func_prd_mng_daily(i_batch_name, i_log_type, i_user_sid, i_from_time, i_to_time);
		IF o_ret_cd_wk = RET_NG THEN
			o_ret_cd = o_ret_cd_wk;
			o_sqlerr = o_sqlerr_wk;
			o_errmsg = o_errmsg_wk;
			o_errpnt = o_errpnt_wk;
			EXIT MAIN_LOOP;
		END IF;

		-- 製品生産計画実績(年別)
		l_err_pnt := RTRIM(cst_MY_PRG) || '_B03';
		SELECT * INTO o_ret_cd_wk, o_sqlerr_wk, o_errmsg_wk, o_errpnt_wk FROM func_prd_mng_monthly(i_batch_name, i_log_type, i_user_sid, i_from_time, i_to_time);
		IF o_ret_cd_wk = RET_NG THEN
			o_ret_cd = o_ret_cd_wk;
			o_sqlerr = o_sqlerr_wk;
			o_errmsg = o_errmsg_wk;
			o_errpnt = o_errpnt_wk;
			EXIT MAIN_LOOP;
		END IF;

		-- ライン計画/実績(時間別)
		l_err_pnt := RTRIM(cst_MY_PRG) || '_B04';
		SELECT * INTO o_ret_cd_wk, o_sqlerr_wk, o_errmsg_wk, o_errpnt_wk FROM func_line_work_hourly(i_batch_name, i_log_type, i_user_sid, i_from_time, i_to_time);
		IF o_ret_cd_wk = RET_NG THEN
			o_ret_cd = o_ret_cd_wk;
			o_sqlerr = o_sqlerr_wk;
			o_errmsg = o_errmsg_wk;
			o_errpnt = o_errpnt_wk;
			EXIT MAIN_LOOP;
		END IF;

		-- ライン計画/実績(日別)
		l_err_pnt := RTRIM(cst_MY_PRG) || '_B05';
		SELECT * INTO o_ret_cd_wk, o_sqlerr_wk, o_errmsg_wk, o_errpnt_wk FROM func_line_work_daily(i_batch_name, i_log_type, i_user_sid, i_from_time, i_to_time);
		IF o_ret_cd_wk = RET_NG THEN
			o_ret_cd = o_ret_cd_wk;
			o_sqlerr = o_sqlerr_wk;
			o_errmsg = o_errmsg_wk;
			o_errpnt = o_errpnt_wk;
			EXIT MAIN_LOOP;
		END IF;

		-- ライン計画/実績(月別)
		l_err_pnt := RTRIM(cst_MY_PRG) || '_B06';
		SELECT * INTO o_ret_cd_wk, o_sqlerr_wk, o_errmsg_wk, o_errpnt_wk FROM func_line_work_monthly(i_batch_name, i_log_type, i_user_sid, i_from_time, i_to_time);
		IF o_ret_cd_wk = RET_NG THEN
			o_ret_cd = o_ret_cd_wk;
			o_sqlerr = o_sqlerr_wk;
			o_errmsg = o_errmsg_wk;
			o_errpnt = o_errpnt_wk;
			EXIT MAIN_LOOP;
		END IF;

		-- [サイネージ用]製品生産計画実績(日別)
		l_err_pnt := RTRIM(cst_MY_PRG) || '_B07';
		SELECT * INTO o_ret_cd_wk, o_sqlerr_wk, o_errmsg_wk, o_errpnt_wk FROM dsf_prd_mng_daily_bat(i_batch_name, i_log_type, i_user_sid, i_from_time, i_to_time);
		IF o_ret_cd_wk = RET_NG THEN
			o_ret_cd = o_ret_cd_wk;
			o_sqlerr = o_sqlerr_wk;
			o_errmsg = o_errmsg_wk;
			o_errpnt = o_errpnt_wk;
			EXIT MAIN_LOOP;
		END IF;

		-- [サイネージ用]製品生産計画実績(月別)
		l_err_pnt := RTRIM(cst_MY_PRG) || '_B08';
		SELECT * INTO o_ret_cd_wk, o_sqlerr_wk, o_errmsg_wk, o_errpnt_wk FROM dsf_prd_mng_monthly_bat(i_batch_name, i_log_type, i_user_sid, i_from_time, i_to_time);
		IF o_ret_cd_wk = RET_NG THEN
			o_ret_cd = o_ret_cd_wk;
			o_sqlerr = o_sqlerr_wk;
			o_errmsg = o_errmsg_wk;
			o_errpnt = o_errpnt_wk;
			EXIT MAIN_LOOP;
		END IF;

		-- [サイネージ用]製品生産計画実績(年別)
		l_err_pnt := RTRIM(cst_MY_PRG) || '_B09';
		SELECT * INTO o_ret_cd_wk, o_sqlerr_wk, o_errmsg_wk, o_errpnt_wk FROM dsf_prd_mng_yearly_bat(i_batch_name, i_log_type, i_user_sid, i_from_time, i_to_time);
		IF o_ret_cd_wk = RET_NG THEN
			o_ret_cd = o_ret_cd_wk;
			o_sqlerr = o_sqlerr_wk;
			o_errmsg = o_errmsg_wk;
			o_errpnt = o_errpnt_wk;
			EXIT MAIN_LOOP;
		END IF;

		EXIT MAIN_LOOP;
	END LOOP	MAIN_LOOP;

	----------------------------------------------------------------------------
	--						終了処理
	----------------------------------------------------------------------------
	-- カーソルクローズ
	l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
	IF OPENFLG_MST_PLANT = CST_TRUE THEN
		CLOSE CUR_MST_PLANT;
		OPENFLG_MST_PLANT := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E002';
	IF OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY = CST_TRUE THEN
		CLOSE CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;
		OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
	IF OPENFLG_TBL_PRODUCT_MANAGEMENT_DAILY = CST_TRUE THEN
		CLOSE CUR_TBL_PRODUCT_MANAGEMENT_DAILY;
		OPENFLG_TBL_PRODUCT_MANAGEMENT_DAILY := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E004';
	IF OPENFLG_TBL_PRODUCT_MANAGEMENT_MONTHLY = CST_TRUE THEN
		CLOSE CUR_TBL_PRODUCT_MANAGEMENT_MONTHLY;
		OPENFLG_TBL_PRODUCT_MANAGEMENT_MONTHLY := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E005';
	IF OPENFLG_TBL_LINE_WORK_HOURLY = CST_TRUE THEN
		CLOSE CUR_TBL_LINE_WORK_HOURLY;
		OPENFLG_TBL_LINE_WORK_HOURLY := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E006';
	IF OPENFLG_TBL_LINE_WORK_DAILY = CST_TRUE THEN
		CLOSE CUR_TBL_LINE_WORK_DAILY;
		OPENFLG_TBL_LINE_WORK_DAILY := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E007';
	IF OPENFLG_TBL_LINE_WORK_MONTHLY = CST_TRUE THEN
		CLOSE CUR_TBL_LINE_WORK_MONTHLY;
		OPENFLG_TBL_LINE_WORK_MONTHLY := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E008';
	IF OPENFLG_TBL_DS_PRODUCT_MNG_DAILY = CST_TRUE THEN
		CLOSE CUR_TBL_DS_PRODUCT_MNG_DAILY;
		OPENFLG_TBL_DS_PRODUCT_MNG_DAILY := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E009';
	IF OPENFLG_TBL_DS_PRODUCT_MNG_MONTHLY = CST_TRUE THEN
		CLOSE CUR_TBL_DS_PRODUCT_MNG_MONTHLY;
		OPENFLG_TBL_DS_PRODUCT_MNG_MONTHLY := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E010';
	IF OPENFLG_TBL_DS_PRODUCT_MNG_YEARLY = CST_TRUE THEN
		CLOSE CUR_TBL_DS_PRODUCT_MNG_YEARLY;
		OPENFLG_TBL_DS_PRODUCT_MNG_YEARLY := CST_FALSE;
	END IF;

	raise info 'End Function [%]', clock_timestamp()::timestamp;

EXCEPTION WHEN OTHERS THEN
	-- DB例外情報収集
	GET STACKED DIAGNOSTICS rtn_sql_no	   = RETURNED_SQLSTATE,
							rtn_sql_msg    = MESSAGE_TEXT,
							rtn_sql_detail = PG_EXCEPTION_DETAIL,
							rtn_sql_hint   = PG_EXCEPTION_HINT,
							rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

	raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
	raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

	o_ret_cd := RET_NG;
	o_sqlerr := substr(rtn_sql_no, 1, 15);
	o_errmsg := substr(rtn_sql_msg, 1, 127);
	o_errpnt := l_err_pnt;

	raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;