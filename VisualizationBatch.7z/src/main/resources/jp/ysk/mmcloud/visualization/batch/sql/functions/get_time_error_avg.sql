﻿CREATE OR REPLACE FUNCTION get_time_error_avg(
    in	i_plant_cd	char(2),			-- 工場コード
    in	i_ln_no		char(20),			-- ライン番号
    in	i_from_time	timestamp,		-- 集計開始日時(空の場合は当日を対象とする)
    in	i_to_time		timestamp		-- 集計終了日時(空の場合は当日を対象とする)

)  RETURNS timestamp with time zone AS
$BODY$

select
	(case when min(end_date) > now() then min(end_date) else now() end)
		 + 
	sum(
		case 
		when 
--			seisan_jyotai <	90 
		(seisan_jyotai_det is null or seisan_jyotai_det	<	90)
		and (sagyo_sts is null or sagyo_sts	<	90) 
		then tact_tim else INTERVAL'0 day' end) as yosoku_tim
from
	(
	select
-- 		y.total_uncreate_num,
-- 		y.sycle_tim,
-- 		y.tact_tim,
		z.end_date - z.start_date as tact_tim,
--		x.seisan_jyotai,
		z.seisan_jyotai	as seisan_jyotai_det,
		w.sagyo_sts,
-- 		y.start_date,
-- 		y.end_date
		z.start_date,
		z.end_date
	from
		
		tr_sasizu_info	x

-- 
-- 		
-- 		(	select
-- 				a.seq					as	total_uncreate_num,
-- 				a.sasizu_no,
-- 				a.sub_no,
-- 				a.start_date,
-- 				a.end_date,
-- 				a.end_date - a.start_date as sycle_tim,
-- 				b.end_date - a.end_date as tact_tim
-- 			from
-- 				(
-- 				select
-- 					row_number() over(order by max(i.end_date))	as seq,
-- 					i.sasizu_no,
-- 					i.sub_no,
-- 					i.plant_cd,
-- 					i.ln_no,
-- 					min(i.initial_start_date)as initial_start_date,
-- 					max(i.initial_end_date) as initial_end_date,
-- 					min(i.start_date) as start_date,
-- 					max(i.end_date) as end_date
-- 				from
-- 				    tbl_seihin_plan			i,
-- 					(select
-- 						plant_cd,
-- 						ln_no,
-- 						station_no
-- 					from
-- 						mst_convert_line
-- 					where
-- 						plant_cd	=	($1)
-- 					and	ln_no		=	($2)
-- 					and	end_flag	=	1)	j
-- 				where
-- 					i.plant_cd	=	($1)
-- 				and	i.ln_no		=	($2)
-- 				and	i.end_date		>=	($3)
-- 				and	i.end_date		<=	($4)
-- 				and	i.invalid_flag	=	0
-- 				and	i.plant_cd	=	j.plant_cd
-- 				and	i.ln_no		=	j.ln_no
-- 				and	i.station_no	=	j.station_no
-- 				group by
-- 				    i.sasizu_no,
-- 				    i.sub_no,
-- 				    i.plant_cd,
-- 				    i.ln_no
-- 				)		a,
-- 				(	
-- 				select
-- 					row_number() over(order by max(i.end_date))	as seq,
-- 					i.sasizu_no,
-- 					i.sub_no,
-- 					i.plant_cd,
-- 					i.ln_no,
-- 					min(i.initial_start_date)as initial_start_date,
-- 					max(i.initial_end_date) as initial_end_date,
-- 					min(i.start_date) as start_date,
-- 					max(i.end_date) as end_date
-- 				from
-- 				    tbl_seihin_plan			i,
-- 					(select
-- 						plant_cd,
-- 						ln_no,
-- 						station_no
-- 					from
-- 						mst_convert_line
-- 					where
-- 						plant_cd	=	($1)
-- 					and	ln_no		=	($2)
-- 					and	end_flag	=	1)	j
-- 				where
-- 					i.plant_cd	=	($1)
-- 				and	i.ln_no		=	($2)
-- 				and	i.end_date		>=	($3)
-- 				and	i.end_date		<=	($4)
-- 				and	i.invalid_flag	=	0
-- 				and	i.plant_cd	=	j.plant_cd
-- 				and	i.ln_no		=	j.ln_no
-- 				and	i.station_no	=	j.station_no
-- 				group by
-- 				    i.sasizu_no,
-- 				    i.sub_no,
-- 				    i.plant_cd,
-- 				    i.ln_no
-- 				)		b
-- 			where
-- 				a.seq = (b.seq - 1)
-- 		)				y
	
	left outer join
		tr_product_trc	z
	on
-- 		y.sasizu_no		=	z.sasizu_no
-- 	and	y.sub_no		=	z.sub_no
		x.sasizu_no		=	z.sasizu_no
	left outer join
		tr_line_work_jsk	w
	on
		w.plant_cd	=	($1)
-- 	and	y.sasizu_no		=	w.sasizu_no
-- 	and	y.sub_no		=	w.sub_no
	and	z.sasizu_no		=	w.sasizu_no
	and	w.ln_no		=	($2)
	
	where
		x.sasizu_no		=	w.sasizu_no
	and	x.werks	=	($1)
)	i


$BODY$
LANGUAGE sql;
