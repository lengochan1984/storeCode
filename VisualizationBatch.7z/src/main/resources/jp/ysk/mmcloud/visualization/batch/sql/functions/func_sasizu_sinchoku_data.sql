CREATE or REPLACE FUNCTION func_sasizu_sinchoku_data(
    in	i_batch_name	varchar,			-- バッチ処理名称
    in	i_log_type		numeric,			-- ログ種別(開始、および　各バッチ処理の復帰値)
                                            -- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
    in	i_user_sid		numeric,			-- 登録ユーザSID
    in	i_from_time		timestamp,			-- 集計開始日時(空の場合は当日を対象とする)
    in	i_to_time		timestamp,			-- 集計終了日時(空の場合は当日を対象とする)
    out	o_ret_cd		int,				-- 関数復帰値	RET_OK(= 0):正常終了
    out	o_sqlerr		varchar,			-- ＤＢ異常発生時のエラーコード
    out	o_errmsg		varchar,			-- 異常発生時のエラーメッセージ
    out	o_errpnt		varchar				-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　指図進捗情報作成サービス
--　ソースプログラム名　：　func_sasizu_sinchoku_data.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　製品生産計画実績(時間別)を作成する
--
--　履歴
--  Ver.  作成日			作成者		COMMENT
--  1.0   2016/12/15	J.Ito			新規作成
--******************************************************************************
DECLARE
    ----------------------------------------------------------------------------
    --						標準定数定義
    ----------------------------------------------------------------------------
    -- 戻り値
    RET_OK		CONSTANT int := 0 ;					-- 正常終了コード
    RET_NG		CONSTANT int := -1 ;				-- 異常終了コード
    -- 真偽値
    CST_TRUE	CONSTANT int := 1 ;					-- 真
    CST_FALSE	CONSTANT int := 0 ;					-- 偽

    ----------------------------------------------------------------------------
    --						標準変数定義
    ----------------------------------------------------------------------------
    cst_MY_PRG	CONSTANT CHAR(32)	 := 'func_sasizu_sinchoku_data';-- プログラム名
    cst_UPD_TIM	CHAR(17) ;							-- 更新時間
    l_err_pnt	CHAR(64) ;							-- エラー発生ポイント
    errbuff		varchar(256);						-- メッセージバッファ

    ----------------------------------------------------------------------------
    --						定数定義
    ----------------------------------------------------------------------------
    CST_ALL_LINE_NO		CONSTANT char(20)	:= '-1';-- ライン番号

    ----------------------------------------------------------------------------
    --						変数定義
    ----------------------------------------------------------------------------
    -- 共通変数
    rtn_sql_no		text;							-- DBエラー情報(エラー番号)
    rtn_sql_msg		text;							-- DBエラー情報(エラーメッセージ)
    rtn_sql_detail	text;							-- DBエラー情報(エラー詳細)
    rtn_sql_hint	text;							-- DBエラー情報(エラーヒント)
    rtn_sql_stack	text;							-- DBエラー情報(エラー発生呼出しスタック)

    -- ローカル変数
    l_exec_datetime				timestamp;			-- 関数実行日時
    l_proc_start_time_all		timestamp;			-- 処理開始日(全体)
    l_proc_end_time_all			timestamp;			-- 処理終了日(全体)
    l_proc_start_time_day		timestamp;			-- 処理開始日(日)
    l_proc_end_time_day			timestamp;			-- 処理終了日(日)
    l_running_start_datetime	timestamp;			-- 稼働開始日時(年度開始日時)

    l_exec_datetime_tmp			timestamp;			-- 関数実行仮日時
    l_exit_roop_flg				int;
    l_insertupdate_flg			int;
    l_update_flg				int;

    l_plant_code				char(2);			-- 工場コード
    l_seizou_line_cd			char(5);			-- 製造ライン
    l_line_no					char(20);			-- ライン番号
    l_data_date					timestamp;			-- データ日時
    l_seq_num					int;				-- シーケンス番号(同日同ライン内)

    l_sasizu_no					char(12);			--指図番号
    l_keikaku_num				integer;			--計画台数
    l_first_end_date			timestamp;			--作業終了予定　初回日時
    l_last_end_date				timestamp;			--作業終了予定　最終日時
    l_first_end_jisseki_date	timestamp;			--作業終了実績　初回日時
    l_last_end_jisseki_date		timestamp;			--作業終了実績　最終日時
    l_color_no					integer;			--表示色用の番号

    l_jisseki_num				integer;			--実績台数
    l_jisseki_num_rec			integer;			--実績台数 (登録用)

    l_sasizu_no_rec				char(12);			--指図番号 (登録用)
    l_keikaku_num_rec			integer;			--計画台数 (登録用)
    l_first_end_date_rec		timestamp;			--作業終了予定　初回日時 (登録用)
    l_last_end_date_rec			timestamp;			--作業終了予定　最終日時 (登録用)
    l_first_end_jisseki_date_rec	timestamp;		--作業終了実績　初回日時 (登録用)
    l_last_end_jisseki_date_rec	timestamp;			--作業終了実績　最終日時 (登録用)
    l_color_no_rec				integer;			--表示色用の番号 (登録用)

    l_sasizu_no_tmp				char(12);			-- 指図番号(暫定)
    l_sub_no	                integer;			-- 副番
    l_start_date            	timestamp;			-- 開始予定日時
    l_end_date              	timestamp;			-- 終了予定日時
    l_line_kanryo_flg       	integer;			-- ライン内完了フラグ
    l_product_kanryo_flg	    integer;			-- 製造完了フラグ
    l_takt_tim	              	interval;			-- 予定時間


    ----------------------------------------------------------------------------
    --						カーソル定義
    ----------------------------------------------------------------------------
    -- 工場マスタ
	CUR_MST_PLANT	CURSOR FOR
		SELECT
			T0.PLANT_CODE				as plantCode,
			T1.RUNNING_START_DATETIME	as runningStartDatetime
		FROM
			MST_PLANT	T0
		LEFT OUTER JOIN
			MST_PLANT_MIERUKA	T1
		ON
				T1.PLANT_CODE	= T0.PLANT_CODE
			AND	T1.INVALID_FLAG	= 0
		WHERE
			T0.INVALID_FLAG = 0
		ORDER BY
			T0.PLANT_CODE
	;
    OPENFLG_MST_PLANT	int;	-- カーソルオープン状態

    -- 製造ライン、ライン(指図追番単位計画のキー)
    CUR_TBL_SEIHIN_PLAN_KEYS CURSOR FOR
    SELECT
        a.seizou_line_cd,
        b.line_no
    FROM
        mst_seizou_line	a,
        mst_line		b,
        mst_station		c
    WHERE
        a.plant_code	=	l_plant_code
    AND	a.plant_code	=	b.plant_code
    AND	b.plant_code	=	c.plant_code
    AND	b.line_no		=	c.line_no
    GROUP BY
        a.plant_code,
        a.seizou_line_cd,
        b.process_code,
        b.line_no
    ORDER BY
        a.plant_code,
        a.seizou_line_cd,
        b.process_code,
        b.line_no
    ;
    OPENFLG_TBL_SEIHIN_PLAN_KEYS int;	-- カーソルオープン状態

    -- 指図追番単位計画
    CUR_TBL_SEIHIN_PLAN CURSOR FOR
        SELECT
            sasizu_no,
            sub_no,
            start_date,
            end_date,
            line_kanryo_flg,
            product_kanryo_flg
--			takt_tim
        FROM(
            SELECT
                a.plant_code,
                d.seizou_line_cd,
                a.line_no,
                a.sasizu_no,
                a.sub_no,
                min(a.start_date) as start_date,
                max(a.end_date) as end_date,
                case when COALESCE(min(b.sagyou_jyotai), 0) >= 90 then 1 else 0 end	as line_kanryo_flg,
                case when COALESCE(min(c.seisan_jyotai), 0) >= 90 then 1 else 0 end	as product_kanryo_flg,
--				max(a.end_date) - min(a.start_date) as takt_tim,
                min(a.station_no) as fist_station,
                max(a.station_no) as last_station

            from
                tbl_seihin_plan				a

            left outer join
                tbl_line_trace_log_wk		b
            on
                a.sasizu_no		=	b.sasizu_no
            and	a.sub_no		=	b.sub_no
            and	a.plant_code	=	b.plant_code
            and	a.line_no		=	b.line_no

            left outer join
                tbl_product_trace_log_wk	c
            on
                a.sasizu_no		=	c.sasizu_no
            and	a.sub_no		=	c.sub_no
            ,
            mst_line						d

            where
                a.plant_code	=	l_plant_code
            and	a.line_no		=	l_line_no
            and	a.start_date		>=	l_proc_start_time_day
            and	a.end_date		>		l_proc_start_time_day
            and	a.end_date		<=	l_proc_end_time_day
            and	a.invalid_flag		=		0
            and	a.plant_code	=	d.plant_code
            and	a.line_no		=	d.line_no
            and	d.seizou_line_cd=	l_seizou_line_cd
            group by
                a.sasizu_no,
                a.sub_no,
                a.plant_code,
                d.seizou_line_cd,
                a.line_no
        )	x

        where
            last_station in (
                SELECT
                    station_no
                FROM
                    mst_convert_line
                WHERE
                    plant_code	= l_plant_code
                AND	line_no		= l_line_no
                AND	end_flag	= 1
            )

        order by
            plant_code,
            seizou_line_cd,
            line_no,
            end_date,
            start_date
    ;
    OPENFLG_TBL_SEIHIN_PLAN int;	-- カーソルオープン状態


    ------------------------------------------------------------
    -- 格納先
    ------------------------------------------------------------
    -- 指図進捗情報
    CUR_TBL_SASIZU_SINCHOKU_DATA	CURSOR FOR
        SELECT
            *
        FROM
            tbl_sasizu_sinchoku_data	a
        WHERE
            a.plant_code	=	l_plant_code
        AND	a.seizou_line_cd=	l_seizou_line_cd
        AND	a.line_no		=	l_line_no
        AND	a.data_date		= 	l_proc_start_time_day
        AND	a.seq_num		= 	l_seq_num
        FOR UPDATE NOWAIT
    ;
    OPENFLG_TBL_SASIZU_SINCHOKU_DATA	int;	-- カーソルオープン状態
    REC_TBL_SASIZU_SINCHOKU_DATA	TBL_SASIZU_SINCHOKU_DATA%ROWTYPE;

BEGIN
    ----------------------------------------------------------------------------
    --						初期処理
    ----------------------------------------------------------------------------
    raise info 'Start Function [%]', clock_timestamp()::timestamp;

    -- 共通変数初期化
    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S001';

    -- 共通出力パラメータ初期化
    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
    o_ret_cd	:= RET_OK;
    o_sqlerr	:= ' ';
    o_errmsg	:= ' ';
    o_errpnt	:= ' ';

    -- 関数実行日時
    l_exec_datetime := clock_timestamp();
    -- 集計開始/終了日時補正
    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
    IF i_from_time IS NULL THEN
        i_from_time := l_exec_datetime;
    END IF;
    IF i_to_time IS NULL OR i_from_time > i_to_time THEN
        i_to_time := l_exec_datetime;
    END IF;

    -- ローカル変数初期化
    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S004';

    -- カーソルオープン状態変数初期化
    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S005';
    OPENFLG_MST_PLANT				:= CST_FALSE;
    OPENFLG_TBL_SEIHIN_PLAN_KEYS	:= CST_FALSE;
    OPENFLG_TBL_SEIHIN_PLAN			:= CST_FALSE;
    OPENFLG_TBL_SASIZU_SINCHOKU_DATA:= CST_FALSE;

    ----------------------------------------------------------------------------
    -- メイン処理
    ----------------------------------------------------------------------------
    << MAIN_LOOP >>
    LOOP

        ------------------------------------------------------------------------
        -- 工場ごとに稼働開始日時が異なるので、工場マスタで処理を回す
        ------------------------------------------------------------------------
        -- 工場マスタを開いているならクローズ
        l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
        IF OPENFLG_MST_PLANT = CST_TRUE THEN
            CLOSE CUR_MST_PLANT;
            OPENFLG_MST_PLANT := CST_FALSE;
        END IF;

        -- 工場マスタをオープン
        l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
        OPEN CUR_MST_PLANT;
        OPENFLG_MST_PLANT := CST_TRUE;

        << PLANT_LOOP >>
        LOOP
            -- 工場マスタからフェッチ
            l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
            FETCH CUR_MST_PLANT INTO l_plant_code, l_running_start_datetime;
            IF FOUND = FALSE THEN
                EXIT PLANT_LOOP;
            END IF;


            -- 製造ライン、ライン(指図追番単位計画のキー)を開いているならクローズ
            l_err_pnt := RTRIM(cst_MY_PRG) || '_301';
            IF OPENFLG_TBL_SEIHIN_PLAN_KEYS = CST_TRUE THEN
                CLOSE CUR_TBL_SEIHIN_PLAN_KEYS;
                OPENFLG_TBL_SEIHIN_PLAN_KEYS := CST_FALSE;
            END IF;

            -- 製造ライン、ライン(指図追番単位計画のキー)をオープン
            l_err_pnt := RTRIM(cst_MY_PRG) || '_302';
            OPEN CUR_TBL_SEIHIN_PLAN_KEYS;
            OPENFLG_TBL_SEIHIN_PLAN_KEYS := CST_TRUE;

            << TBL_SEIHIN_PLAN_KEYS_LOOP >>
            LOOP
                l_err_pnt := RTRIM(cst_MY_PRG) || '_303';
                FETCH CUR_TBL_SEIHIN_PLAN_KEYS INTO l_seizou_line_cd, l_line_no;
                IF FOUND = FALSE THEN
                    -- 該当データがない場合
                    EXIT TBL_SEIHIN_PLAN_KEYS_LOOP;
                END IF;

                -- 工場稼働日時を設定
                IF l_running_start_datetime IS NULL THEN
                    -- NULLの場合はデフォルト値をセット
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_401';
                    l_running_start_datetime = timestamp '0001-03-21 07:00:00';
                END IF;

                   -- 処理開始日時(全体)設定
                l_err_pnt := RTRIM(cst_MY_PRG) || '_402';
                SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_all;
                << START_TIME_LOOP >>
                LOOP
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_403';
                    IF i_from_time >= l_proc_start_time_all THEN
                        EXIT START_TIME_LOOP;
                    END IF;
                    l_proc_start_time_all := l_proc_start_time_all + interval '-1 days';
                END LOOP	START_TIME_LOOP;

                -- 処理終了日時(全体)設定
                l_err_pnt := RTRIM(cst_MY_PRG) || '_404';
                SELECT l_proc_start_time_all + interval '1 days' + interval '-1 milliseconds' INTO l_proc_end_time_all;
                << END_TIME_LOOP >>
                LOOP
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_405';
                       IF i_to_time <= l_proc_end_time_all THEN
                        EXIT END_TIME_LOOP;
                    END IF;
                    l_proc_end_time_all := l_proc_end_time_all + interval '1 days';
                END LOOP	END_TIME_LOOP;

                -- 処理開始/終了(日)日時
                l_err_pnt := RTRIM(cst_MY_PRG) || '_406';
                l_proc_start_time_day := l_proc_start_time_all;
                l_proc_end_time_day := l_proc_start_time_day + interval '1 days' + interval '-1 milliseconds';

                << TIME_DAY_LOOP >>
                LOOP
                    -- 生産日を取得
                    l_data_date	:=	l_proc_start_time_day;

                    -- 指図 色番号を設定する
                    SELECT INTO	o_ret_cd, o_sqlerr, o_errmsg, o_errpnt
                        *
                    FROM
                        func_sasizu_sinchoku_color_no(
                            2,
                            9999,
                            l_plant_code,
                            l_proc_start_time_day,
                            l_proc_end_time_day
                        )
                    ;
                    IF o_ret_cd	= RET_NG THEN
                        -- 指図 色番号を設定する処理失敗した場合
                        l_err_pnt := RTRIM(cst_MY_PRG) || '_406';
                        RETURN;
                    END IF;


                     -- 指図追番単位計画を開いているならクローズ
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_501';
                    IF OPENFLG_TBL_SEIHIN_PLAN = CST_TRUE THEN
                        CLOSE CUR_TBL_SEIHIN_PLAN;
                        OPENFLG_TBL_SEIHIN_PLAN := CST_FALSE;
                    END IF;

                    -- 指図追番単位計画をオープン
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_502';
                    OPEN CUR_TBL_SEIHIN_PLAN;
                    OPENFLG_TBL_SEIHIN_PLAN := CST_TRUE;

                    -- 指図番号とシーケンス番号(同日同ライン内)の初期化
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_502-1';
                    l_seq_num			:=	0;
                    l_jisseki_num		:=	0;
                    l_sasizu_no			:=	'';
                    l_exit_roop_flg		:=	0;
                    l_insertupdate_flg	:=	0;

                    << TBL_SEIHIN_PLAN_LOOP >>
                    LOOP
                        -- 指図追番単位計画の取得変数の初期化
                        l_err_pnt := RTRIM(cst_MY_PRG) || '_502-2';
                        l_sasizu_no_tmp		:=	'';
                        l_sub_no					:=	0;
                        l_start_date				:=	timestamp '0001-01-1 00:00:00';
                        l_end_date				:=	timestamp '0001-01-1 00:00:00';
                        l_line_kanryo_flg		:=	0;
                        l_product_kanryo_flg	:=	0;
                        l_takt_tim					:=	interval'0 milliseconds';

                        l_err_pnt := RTRIM(cst_MY_PRG) || '_503';
                        FETCH CUR_TBL_SEIHIN_PLAN
                        INTO l_sasizu_no_tmp, l_sub_no, l_start_date, l_end_date, l_line_kanryo_flg, l_product_kanryo_flg;
                        IF FOUND = FALSE THEN
                            -- 該当データがない場合
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_504';
                            l_exit_roop_flg = 1;

                            IF l_sasizu_no <> '' THEN
                                l_err_pnt := RTRIM(cst_MY_PRG) || '_504-1';
                                -- データを登録用に移す
                                l_sasizu_no_rec					:=	l_sasizu_no;
                                l_keikaku_num_rec			:=	l_keikaku_num;
                                l_first_end_date_rec			:=	l_first_end_date;
                                l_last_end_date_rec			:=	l_last_end_date;
                                l_jisseki_num_rec				:=	l_jisseki_num;
                                l_insertupdate_flg				:=	1;
                            END IF;

                        ELSE
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_505';
                            -- 該当データがある場合

                            IF l_sasizu_no = l_sasizu_no_tmp AND (l_start_date - l_last_end_date) < interval'10 minute' THEN
                                l_err_pnt := RTRIM(cst_MY_PRG) || '_506';
                                -- 同じ指図が継続している場合

                                -- 計画台数に＋１、作業終了予定　最終日時を更新
                                l_keikaku_num				:=	l_keikaku_num + 1;
                                l_last_end_date				:=	l_end_date;
                                IF l_line_kanryo_flg = 1 OR l_product_kanryo_flg = 1 THEN
                                    l_err_pnt := RTRIM(cst_MY_PRG) || '_507';
                                    -- ライン、または製造品が完了している場合
                                    -- 作業終了実績　最終日時に作業時間を加算
                                    l_jisseki_num := l_jisseki_num + 1;

                                END IF;

                            ELSIF l_sasizu_no = '' THEN
                                l_err_pnt := RTRIM(cst_MY_PRG) || '_508';
                                -- 指図番号が初期値=ループ初回の場合

                                l_sasizu_no					:=	l_sasizu_no_tmp;
                                l_keikaku_num				:=	1;
                                l_first_end_date				:=	l_start_date;
                                l_last_end_date				:=	l_end_date;
                                l_jisseki_num					:=	0;

                                IF l_line_kanryo_flg = 1 OR l_product_kanryo_flg = 1 THEN
                                    l_err_pnt := RTRIM(cst_MY_PRG) || '_509';
                                    -- ライン、または製造品が完了している場合
                                    l_jisseki_num 			:= 1;

                                END IF;

                            ELSE
                                l_err_pnt := RTRIM(cst_MY_PRG) || '_510';
                                -- 異なる指図番号が取得された場合

                                -- データを登録用に移す
                                l_sasizu_no_rec				:=	l_sasizu_no;
                                l_keikaku_num_rec		:=	l_keikaku_num;
                                l_first_end_date_rec		:=	l_first_end_date;
                                l_last_end_date_rec		:=	l_last_end_date;
                                l_jisseki_num_rec			:=	l_jisseki_num;
                                l_insertupdate_flg			:=	1;

                                -- 取得データを初回に設定しておく
                                l_sasizu_no					:=	l_sasizu_no_tmp;
                                l_keikaku_num				:=	1;
                                l_first_end_date				:=	l_start_date;
                                IF l_first_end_date < l_last_end_date_rec THEN
                                    l_err_pnt := RTRIM(cst_MY_PRG) || '_511';
                                    -- 取得データの開始時刻が、前データの終了よりおそい場合
                                    l_first_end_date			:=	l_last_end_date_rec;
                                    l_start_date				:=	l_first_end_date;

                                END IF;
                                l_last_end_date				:=	l_end_date;
                                l_jisseki_num					:=	0;
                                IF l_line_kanryo_flg = 1 OR l_product_kanryo_flg = 1 THEN
                                    l_err_pnt := RTRIM(cst_MY_PRG) || '_512';
                                    -- ライン、または製造品が完了している場合
                                    l_jisseki_num 			:= 1;

                                END IF;

                            END IF;

                        END IF;


                        IF l_insertupdate_flg	=	1 THEN
                            -- データ挿入・更新が必要な場合
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_600';

                            -- シーケンス番号(同日同ライン内)をインクリメント
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_601';
                            l_seq_num := l_seq_num + 1;

                            -- 表示色用の番号を設定
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_602';
                            l_color_no := 0;
                            SELECT
                                COALESCE(MIN(b.color_no), max(a.color_no)+1) AS target_color_no
                            INTO
                                l_color_no
                            FROM
                                tbl_sasizu_sinchoku_color_no	a

                            LEFT OUTER JOIN
                                tbl_sasizu_sinchoku_color_no	b
                            ON
                                a.plant_code	=	b.plant_code
                            AND	a.data_date		=	b.data_date
                            AND	b.sasizu_no		=	l_sasizu_no_rec

                            WHERE
                                a.plant_code	=	l_plant_code
                            AND	a.data_date		=	l_data_date
                            ;
                            IF FOUND = FALSE THEN
                                l_color_no := l_seq_num;
                            END IF;


                            -- 実績時刻の算出
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_603';
                            IF l_jisseki_num_rec > l_keikaku_num_rec THEN
                                l_jisseki_num_rec := l_keikaku_num_rec;

                            END IF;
                            l_first_end_jisseki_date_rec:=	l_first_end_date_rec;
                            l_last_end_jisseki_date_rec	:=	l_first_end_date_rec
                                +	((l_last_end_date_rec - l_first_end_date_rec) / l_keikaku_num_rec * l_jisseki_num_rec );

                            -- 実績時刻差が誤差で大きくなった場合は修正
                            IF l_last_end_date_rec <= l_last_end_jisseki_date_rec THEN
                                l_last_end_jisseki_date_rec		:= l_last_end_date_rec;

                            -- 実績時刻差が小さい場合、表示に現れないので拡大
                            ELSIF l_last_end_date_rec - l_first_end_date_rec >= interval'10 minute' AND l_last_end_date_rec - l_last_end_jisseki_date_rec < interval'5 minute' THEN
                                l_last_end_jisseki_date_rec		:= l_last_end_date_rec - interval'5 minute';

                            ELSIF l_last_end_date_rec - l_first_end_date_rec >= interval'5 minute' AND l_last_end_date_rec - l_last_end_jisseki_date_rec < interval'3 minute' THEN
                                l_last_end_jisseki_date_rec		:= l_last_end_date_rec - interval'3 minute';

                            END IF;


                            -- 指図進捗情報を開いているならクローズ
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_701';
                            IF OPENFLG_TBL_SASIZU_SINCHOKU_DATA = CST_TRUE THEN
                                CLOSE CUR_TBL_SASIZU_SINCHOKU_DATA;
                                OPENFLG_TBL_SASIZU_SINCHOKU_DATA := CST_FALSE;
                            END IF;

                            -- 指図進捗情報をオープン
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_702';
                            OPEN CUR_TBL_SASIZU_SINCHOKU_DATA;
                            OPENFLG_TBL_SASIZU_SINCHOKU_DATA := CST_TRUE;

                            l_err_pnt := RTRIM(cst_MY_PRG) || '_703';
                            FETCH CUR_TBL_SASIZU_SINCHOKU_DATA INTO REC_TBL_SASIZU_SINCHOKU_DATA;
                            IF FOUND = FALSE THEN
                                -- 製品生産計画実績(時間別)に格納
                                l_err_pnt := RTRIM(cst_MY_PRG) || '_704';
                                INSERT INTO tbl_sasizu_sinchoku_data  (
                                      plant_code				-- 工場コード
                                    , seizou_line_cd			-- 製造ラインコード
                                    , line_no					-- ライン番号
                                    , data_date					-- データ日付
                                    , seq_num					-- シーケンス番号(同日同ライン内)
                                    , sasizu_no					-- 指図番号
                                    , keikaku_num				-- 計画台数
                                    , first_end_date			-- 作業終了予定　初回日時
                                    , last_end_date				-- 作業終了予定　最終日時
                                    , first_end_jisseki_date	-- 作業終了実績　初回日時
                                    , last_end_jisseki_date		-- 作業終了実績　最終日時
                                    , color_no					-- 表示色用の番号
                                    , yobi1						-- 実績台数
                                    , yobi2						-- 予備
                                    , yobi3						-- 予備
                                    , yobi4						-- 予備
                                    , ins_prog					-- 登録プログラム名
                                    , ins_tim					-- 登録日時
                                    , ins_user_sid				-- 登録ユーザSID
                                    , upd_prog					-- 更新プログラム名
                                    , upd_tim					-- 更新日時
                                    , upd_user_sid				-- 更新ユーザSID
                                )

                                VALUES (
                                      l_plant_code				-- 工場コード
                                    , l_seizou_line_cd			-- 製造ラインコード
                                    , l_line_no					-- ライン番号
                                    , l_data_date				-- データ日付
                                    , l_seq_num					-- シーケンス番号(同日同ライン内)
                                    , l_sasizu_no_rec			-- 指図番号
                                    , l_keikaku_num_rec		-- 計画台数
                                    , l_first_end_date_rec		-- 作業終了予定　初回日時
                                    , l_last_end_date_rec		-- 作業終了予定　最終日時
                                    , l_first_end_jisseki_date_rec	-- 作業終了実績　初回日時
                                    , l_last_end_jisseki_date_rec	-- 作業終了実績　最終日時
                                    , l_color_no				-- 表示色用の番号
                                    , l_jisseki_num_rec			-- 実績台数
                                    , null						-- 予備
                                    , null						-- 予備
                                    , null						-- 予備
                                    , cst_MY_PRG				-- 登録プログラム名
                                    , l_exec_datetime			-- 登録日時
                                    , i_user_sid				-- 登録ユーザSID
                                    , cst_MY_PRG				-- 更新プログラム名
                                    , l_exec_datetime			-- 更新日時
                                    , i_user_sid				-- 更新ユーザSID
                                );
                            ELSE
                                -- 製品生産計画実績(時間別)の実績台数と実績金額を更新
                                l_err_pnt := RTRIM(cst_MY_PRG) || '_705';
                                <<DUMMY_LOOP>>
                                LOOP
                                    l_update_flg	:= 	1;
                                    -- 更新要素に違いがない場合、アップデート
                                    EXIT DUMMY_LOOP WHEN l_sasizu_no_rec 		!=	REC_TBL_SASIZU_SINCHOKU_DATA.sasizu_no;
                                    EXIT DUMMY_LOOP WHEN l_keikaku_num_rec 		!=	REC_TBL_SASIZU_SINCHOKU_DATA.keikaku_num;
                                    EXIT DUMMY_LOOP WHEN l_first_end_date_rec	!=	REC_TBL_SASIZU_SINCHOKU_DATA.first_end_date;
                                    EXIT DUMMY_LOOP WHEN l_last_end_date_rec	!=	REC_TBL_SASIZU_SINCHOKU_DATA.last_end_date;
                                    EXIT DUMMY_LOOP WHEN l_first_end_jisseki_date_rec	!= REC_TBL_SASIZU_SINCHOKU_DATA.first_end_jisseki_date;
                                    EXIT DUMMY_LOOP WHEN l_last_end_jisseki_date_rec	!= REC_TBL_SASIZU_SINCHOKU_DATA.last_end_jisseki_date;
                                    EXIT DUMMY_LOOP WHEN l_color_no				!=	REC_TBL_SASIZU_SINCHOKU_DATA.color_no;
                                    EXIT DUMMY_LOOP WHEN l_jisseki_num_rec		!=	REC_TBL_SASIZU_SINCHOKU_DATA.yobi1;

                                    -- 相違なし=アップデート不要
                                    l_err_pnt := RTRIM(cst_MY_PRG) || '_706';
                                    l_update_flg	:=	0;
                                    EXIT DUMMY_LOOP;
                                END LOOP DUMMY_LOOP;

                                l_err_pnt := RTRIM(cst_MY_PRG) || '_707';
                                IF	l_update_flg	=	1 THEN

                                    l_err_pnt := RTRIM(cst_MY_PRG) || '_708';
                                    UPDATE tbl_sasizu_sinchoku_data
                                    SET
                                          sasizu_no				=	l_sasizu_no_rec				-- 指図番号
                                        , keikaku_num			=	l_keikaku_num_rec			-- 計画台数
                                        , first_end_date		=	l_first_end_date_rec		-- 作業終了予定　初回日時
                                        , last_end_date			=	l_last_end_date_rec			-- 作業終了予定　最終日時
                                        , first_end_jisseki_date=	l_first_end_jisseki_date_rec-- 作業終了実績　初回日時
                                        , last_end_jisseki_date	=	l_last_end_jisseki_date_rec	-- 作業終了実績　最終日時
                                        , color_no				=	l_color_no					-- 表示色用の番号
                                        , yobi1					=	l_jisseki_num_rec			-- 実績台数
                                        , UPD_PROG				= 	cst_MY_PRG					-- 更新プログラム
                                        , UPD_TIM				=	l_exec_datetime				-- 更新日時
                                        , UPD_USER_SID			=	i_user_sid					-- 更新ユーザSID
                                    WHERE CURRENT OF CUR_TBL_SASIZU_SINCHOKU_DATA
                                    ;
                                END IF;

                            END IF;

                        END IF;
                        l_insertupdate_flg	:= 0;

                        -- 終了フラグが立っていない場合、ループ継続
                        l_err_pnt := RTRIM(cst_MY_PRG) || '_801';
                        IF l_exit_roop_flg	= 1 THEN

                            -- 終了フラグが立っている場合、以降のシーケンス番号のデータを削除
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_802';
                            DELETE FROM tbl_sasizu_sinchoku_data a
                            WHERE
                                a.plant_code	=	l_plant_code
                            AND	a.seizou_line_cd=	l_seizou_line_cd
                            AND	a.line_no		=	l_line_no
                            AND	a.data_date		= 	l_data_date
                            AND	a.seq_num		> 	l_seq_num
                            ;


                            -- 終了フラグを落として、ループを終了
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_802';
                            EXIT TBL_SEIHIN_PLAN_LOOP;
                        END IF;
                        l_exit_roop_flg		:=	0;

                    END LOOP TBL_SEIHIN_PLAN_LOOP;


                    -- 予定数を取得する際の、最終日時を取得
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_901';
                    l_exec_datetime_tmp	:=	l_proc_end_time_day;
                    IF l_exec_datetime_tmp >=	l_exec_datetime THEN
                        l_exec_datetime_tmp	:=	l_exec_datetime;
                    END IF;

                    -- 次の処理日時(日)を設定
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_902';
                    l_proc_start_time_day	:= l_proc_start_time_day + interval '1 days';
                    l_proc_end_time_day		:= l_proc_end_time_day + interval '1 days';

                    -- 処理開始日時(日)が処理終了日時(全体)を超えている場合は処理終了
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_903';
                    IF l_proc_end_time_all < l_proc_start_time_day THEN
                        EXIT TIME_DAY_LOOP;
                    END IF;

                END LOOP	TIME_DAY_LOOP;

            END LOOP	TBL_SEIHIN_PLAN_KEYS_LOOP;

        END LOOP	PLANT_LOOP;

        EXIT MAIN_LOOP;
    END LOOP	MAIN_LOOP;

    ----------------------------------------------------------------------------
    --						終了処理
    ----------------------------------------------------------------------------
    -- カーソルクローズ
    -- 工場マスタ
    l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
    IF OPENFLG_MST_PLANT = CST_TRUE THEN
        CLOSE CUR_MST_PLANT;
        OPENFLG_MST_PLANT := CST_FALSE;
    END IF;

    -- 製造ライン、ライン(指図追番単位計画のキー)
    l_err_pnt := RTRIM(cst_MY_PRG) || '_E002';
    IF OPENFLG_TBL_SEIHIN_PLAN_KEYS = CST_TRUE THEN
        CLOSE CUR_TBL_SEIHIN_PLAN_KEYS;
        OPENFLG_TBL_SEIHIN_PLAN_KEYS := CST_FALSE;
    END IF;

    -- 指図追番単位計画
    l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
    IF OPENFLG_TBL_SEIHIN_PLAN = CST_TRUE THEN
        CLOSE CUR_TBL_SEIHIN_PLAN;
        OPENFLG_TBL_SEIHIN_PLAN := CST_FALSE;
    END IF;

    -- 指図進捗情報
    l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
    IF OPENFLG_TBL_SASIZU_SINCHOKU_DATA = CST_TRUE THEN
        CLOSE CUR_TBL_SASIZU_SINCHOKU_DATA;
        OPENFLG_TBL_SASIZU_SINCHOKU_DATA := CST_FALSE;
    END IF;

    raise info 'End Function [%]', clock_timestamp()::timestamp;

EXCEPTION WHEN OTHERS THEN
    -- DB例外情報収集
    GET STACKED DIAGNOSTICS rtn_sql_no     = RETURNED_SQLSTATE,
                            rtn_sql_msg    = MESSAGE_TEXT,
                            rtn_sql_detail = PG_EXCEPTION_DETAIL,
                            rtn_sql_hint   = PG_EXCEPTION_HINT,
                            rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

    raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
    raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

    o_ret_cd := RET_NG;
    o_sqlerr := substr(rtn_sql_no, 1, 15);
    o_errmsg := substr(rtn_sql_msg, 1, 127);
    o_errpnt := l_err_pnt;

    raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;