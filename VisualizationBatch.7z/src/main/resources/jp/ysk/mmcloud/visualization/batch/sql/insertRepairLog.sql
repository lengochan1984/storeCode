WITH
    val AS (
        SELECT
            (   (
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*repairNo*/,
				/*sasizuNo*/,
				/*subNo*/,
				/*sagyoSeq*/,
				/*buhinCd*/,
				/*katasiki*/,
				/*seihinSn*/,
				/*occurTime*/,
				/*lnId*/,
				/*stId*/,
				/*plantCd*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*processCd*/,
				/*processNm*/,
				/*lnNo*/,
				/*lnNm*/,
				/*stNo*/,
				/*stNm*/,
				/*sagyoku*/,
				/*equipCd*/,
				/*almCd*/,
				/*repairKaisu*/,
				/*stepNo*/,
				/*seihinLn*/,
				/*testDefectNo*/,
				/*testDate*/,
				/*testTime*/,
				/*testSpecName*/,
				/*testStepNo*/,
				/*testStepName*/,
				/*testMinVal*/,
				/*testMaxVal*/,
				/*testDataVal*/,
				/*userId*/,
				/*repairComment*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
                'insert-TR_REPAIR_LOG',
                now(),
                0,
                'insert-TR_REPAIR_LOG',
                now(),
                0
                )::TR_REPAIR_LOG).*
    ),

    upd AS (
        UPDATE
            TR_REPAIR_LOG
        SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			sasizu_no			= /*sasizuNo*/,
			sub_no				= CAST(/*subNo*/ AS numeric),
			sagyo_seq			= /*sagyoSeq*/,
			buhin_cd			= /*buhinCd*/,
			katasiki			= /*katasiki*/,
			seihin_sn			= /*seihinSn*/,
			occur_time			= CAST(/*occurTime*/ AS timestamp),
			ln_id				= CAST(/*lnId*/ AS numeric),
			st_id				= CAST(/*stId*/ AS numeric),
			plant_cd			= /*plantCd*/,
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
			process_cd			= /*processCd*/,
			process_nm			= /*processNm*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			st_no				= /*stNo*/,
			st_nm				= /*stNm*/,
			sagyoku				= /*sagyoku*/,
			equip_cd			= /*equipCd*/,
			alm_cd				= /*almCd*/,
			repair_kaisu		= CAST(/*repairKaisu*/ AS numeric),
			step_no				= /*stepNo*/,
			seihin_ln			= /*seihinLn*/,
			test_defect_no		= /*testDefectNo*/,
			test_date			= /*testDate*/,
			test_time			= /*testTime*/,
			test_spec_name		= /*testSpecName*/,
			test_step_no		= /*testStepNo*/,
			test_step_name		= /*testStepName*/,
			test_min_val		= /*testMinVal*/,
			test_max_val		= /*testMaxVal*/,
			test_data_val		= /*testDataVal*/,
			user_id				= /*userId*/,
			repair_comment		= /*repairComment*/,
            spare_num1			= CAST(/*spareNum1*/ AS numeric),
            spare_num2			= CAST(/*spareNum2*/ AS numeric),
            spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
            upd_prog            = 'update-TR_REPAIR_LOG',
            upd_tim             = now(),
            upd_user_sid        = 0
        FROM
            val
        WHERE
            TR_REPAIR_LOG.repair_no    = /*repairNo*/
        RETURNING
            TR_REPAIR_LOG.repair_no
    )

INSERT INTO
    TR_REPAIR_LOG
SELECT
    *
FROM
    val
WHERE
    (repair_no)
        NOT IN (SELECT repair_no FROM upd);