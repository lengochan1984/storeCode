SELECT
    plant_cd,
    invalid_flag,
    mes_db_connect_info,
    mes_db_user_id,
    mes_db_password,
    ins_prog,
    ins_tim,
    ins_user_sid,
    upd_prog,
    upd_tim,
    upd_user_sid

FROM
    ma_plant_mieruka

WHERE
    invalid_flag = 0
/*IF plantCd != null*/
AND
    plant_cd = /*plantCd*/
/*END*/

ORDER BY
    plant_cd

