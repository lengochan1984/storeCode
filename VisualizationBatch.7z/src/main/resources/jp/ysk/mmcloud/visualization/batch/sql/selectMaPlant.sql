SELECT
    CREATED_ON,
    CREATED_BY,
    CASE WHEN HIS_KBN != 'D' THEN COALESCE(MODIFIED_ON, CREATED_ON) ELSE EVENT_TIME END AS MODIFIED_ON,
    COALESCE(MODIFIED_BY, CREATED_BY) AS MODIFIED_BY,
    CASE WHEN HIS_KBN != 'D' THEN 0 ELSE 1 END AS INVALID_FLAG,
    PLANT_CD,
    PLANT_NM,
    PLANT_S_NM,
    PLANT_ADDR,
    COMPANY_CD,
    MAIL_SERVER,
    MAIL_ACCOUNT,
    MAIL_PASSWORD,
    TIME_AJUSTMENT,
    TIME_SERVER,
    COALESCE(TO_TIMESTAMP(RTRIM(TO_CHAR(ERP_HENKO_BI, 'YYYY-MM-DD') || REPLACE(ERP_HENKO_JI, ':', '')), 'YYYY-MM-DDHH24MISS'), null) AS ERP_HENKO_DATE,
    ERP_SAKUJYO_FLG,
    COALESCE(running_start_datetime, '0001-03-21 07:00:00') AS running_start_datetime,
    COALESCE(latitude, 0) AS latitude,
    COALESCE(longitude, 0) AS longitude,
    SPARE_NUM1,
    SPARE_NUM2,
    SPARE_NUM3,
    SPARE_TEXT1,
    SPARE_TEXT2,
    SPARE_TEXT3

FROM
(
    SELECT
        SUB.*
    FROM
    (
        SELECT
            *,
            ROW_NUMBER() OVER (PARTITION BY PLANT_CD ORDER BY EVENT_TIME DESC) AS rowIndex
        FROM
            MA_PLANT_HIS
    ) SUB
    WHERE
        SUB.rowIndex = 1
) T

WHERE
        PLANT_CD != '##'
    /*IF addDatetime != null*/
    AND (
            (CREATED_ON >= /*addDatetime*/ AND MODIFIED_ON is null)
        OR  MODIFIED_ON >= /*addDatetime*/
    )
    /*END*/

ORDER BY
    CASE WHEN HIS_KBN != 'D' THEN COALESCE(MODIFIED_ON, CREATED_ON) ELSE EVENT_TIME END
