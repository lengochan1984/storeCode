WITH
    val AS (
        SELECT
            (   (
				/*stId*/,
				/*updDate*/,
				/*scheduleNum*/,
				/*actualNum*/,
				/*planNum*/,
				/*predictionCompletionTime*/,
				/*planCompletionTime*/,
				/*preRetentionNum*/,
				/*retentionNum*/,
				/*insProg*/,
				/*insTim*/,
				/*insUserSid*/,
				/*updProg*/,
				/*updTim*/,
				/*updUserSid*/
                )::ag_st_work_current).*
    ),

    upd AS (
        UPDATE
            ag_st_work_current
        SET
			upd_date			= CAST(/*updDate*/ AS timestamp),
			schedule_num		= CAST(/*scheduleNum*/ AS integer),
			actual_num			= CAST(/*actualNum*/ AS integer),
			plan_num			= CAST(/*planNum*/ AS integer),
			prediction_completion_time	= CAST(/*predictionCompletionTime*/ AS timestamp),
			plan_completion_time		= CAST(/*planCompletionTime*/ AS timestamp),
			pre_retention_num	= CAST(/*preRetentionNum*/ AS integer),
			retention_num		= CAST(/*retentionNum*/ AS integer),
			ins_prog			= /*insProg*/,
			ins_tim				= CAST(/*insTim*/ AS timestamp),
			ins_user_sid		= CAST(/*insUserSid*/ AS integer),
			upd_prog			= /*updProg*/,
			upd_tim				= CAST(/*updTim*/ AS timestamp),
			upd_user_sid		= CAST(/*updUserSid*/ AS integer)
        FROM
            val
        WHERE
            ag_st_work_current.ST_ID = /*stId*/

        RETURNING
            ag_st_work_current.ST_ID
    )

INSERT INTO
    ag_st_work_current
SELECT
    *
FROM
    val
WHERE
    (ST_ID)
        NOT IN (SELECT ST_ID FROM upd);
