SELECT
    seizou_ln_id,
    ln_id,
    st_id,
    buhin_cd,
    data_date,
    vtext_info1,
    vtext_info2,
    plant_cd,
    seizou_ln_cd,
    seizou_ln_nm,
    process_cd,
    process_nm,
    ln_no,
    ln_nm,
    st_no,
    st_nm,
    upd_date,
    plan_the_day_num,
    plan_before_the_day_num,
    plan_before_two_days_num,
    actual_the_day_num,
    plan_the_day_value,
    plan_before_the_day_value,
    plan_before_two_days_value,
    actual_the_day_value,
    ins_prog,
    ins_tim,
    ins_user_sid,
    upd_prog,
    upd_tim,
    upd_user_sid

FROM
    ag_product_mng_daily

/*BEGIN*/
WHERE
    /*IF addDatetime != null*/
        (ins_tim >= /*addDatetime*/ AND upd_tim is null)
    OR  upd_tim >= /*addDatetime*/
    /*END*/
/*END*/

ORDER BY
    COALESCE(upd_tim, ins_tim)
