WITH
	val AS (
		SELECT
			(	(
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*invalidFlag*/,
				/*userId*/,
				/*lnId*/,
				/*skillLevel*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
				'insert-MA_USER_SKILL',
				now(),
				0,
				'insert-MA_USER_SKILL',
				now(),
				0
				)::MA_USER_SKILL).*
	),

	upd AS (
		UPDATE
			MA_USER_SKILL
		SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			invalid_flag		= /*invalidFlag*/,
			skill_level			= CAST(/*skillLevel*/ AS numeric),
			spare_num1			= CAST(/*spareNum1*/ AS numeric),
			spare_num2			= CAST(/*spareNum2*/ AS numeric),
			spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-MA_USER_SKILL',
			upd_tim 			= now(),
			upd_user_sid		= 0
		FROM
			val
		WHERE
				MA_USER_SKILL.user_id	= /*userId*/
			AND MA_USER_SKILL.ln_id		= /*lnId*/

		RETURNING
			MA_USER_SKILL.user_id,
			MA_USER_SKILL.ln_id
	)

INSERT INTO
	MA_USER_SKILL
SELECT
	*
FROM
	val
WHERE
	(user_id, ln_id)
		NOT IN (SELECT user_id, ln_id FROM upd);
