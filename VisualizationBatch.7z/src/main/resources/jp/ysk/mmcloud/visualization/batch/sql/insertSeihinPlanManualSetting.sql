WITH
    val AS (
        SELECT
            (   (
				/*lnId*/,
				/*vtextInfo1*/,
				/*dataDate*/,
				/*sid*/,
				/*displayOrder*/,
                /*planNum*/,
                /*lastLineFlag*/,
                /*insProg*/,
                /*insTim*/,
                /*insUserSid*/,
                /*updProg*/,
                /*updTim*/,
                /*updUserSid*/
                )::TR_SEIHIN_PLAN_MANUAL_SETTING).*
    ),

    upd AS (
        UPDATE
            TR_SEIHIN_PLAN_MANUAL_SETTING
        SET
			sid					= CAST(/*sid*/ AS integer),
			display_order		= CAST(/*displayOrder*/ AS integer),
            plan_num			= CAST(/*planNum*/ AS integer),
            last_line_flag		= CAST(/*lastLineFlag*/ AS integer),
			ins_prog			= /*insProg*/,
			ins_tim				= CAST(/*insTim*/ AS timestamp),
			ins_user_sid		= CAST(/*insUserSid*/ AS integer),
			upd_prog			= /*updProg*/,
			upd_tim				= CAST(/*updTim*/ AS timestamp),
			upd_user_sid		= CAST(/*updUserSid*/ AS integer)
        FROM
            val
        WHERE
            TR_SEIHIN_PLAN_MANUAL_SETTING.ln_id			= /*lnId*/
        AND TR_SEIHIN_PLAN_MANUAL_SETTING.vtext_info1	= /*vtextInfo1*/
        AND TR_SEIHIN_PLAN_MANUAL_SETTING.data_date		= /*dataDate*/

        RETURNING
            TR_SEIHIN_PLAN_MANUAL_SETTING.ln_id,
            TR_SEIHIN_PLAN_MANUAL_SETTING.vtext_info1,
            TR_SEIHIN_PLAN_MANUAL_SETTING.data_date
    )

INSERT INTO
    TR_SEIHIN_PLAN_MANUAL_SETTING
SELECT
    *
FROM
    val
WHERE
    (ln_id, vtext_info1, data_date)
        NOT IN (SELECT ln_id, vtext_info1, data_date FROM upd);
