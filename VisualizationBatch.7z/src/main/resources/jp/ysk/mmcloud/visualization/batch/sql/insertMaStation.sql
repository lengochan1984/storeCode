WITH
	val AS (
		SELECT
			(	(
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*invalidFlag*/,
				/*stId*/,
				/*stNo*/,
				/*stNm*/,
				/*lnId*/,
				/*paraGroupNo*/,
				/*prodStartFlag*/,
				/*stayNumInside*/,
				/*stayNumBefore*/,
				/*bunFlag*/,
				/*stdHourHigh*/,
				/*stdHourMiddle*/,
				/*stdHourLow*/,
				/*opcuaSvId*/,
				/*plcId*/,
				/*lineEndSt*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
				'insert-MA_STATION',
				now(),
				0,
				'insert-MA_STATION',
				now(),
				0
				)::MA_STATION).*
	),

	upd AS (
		UPDATE
			MA_STATION
		SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			invalid_flag		= /*invalidFlag*/,
			st_no				= /*stNo*/,
			st_nm				= /*stNm*/,
			ln_id				= CAST(/*lnId*/ AS numeric),
			para_group_no		= /*paraGroupNo*/,
			prod_start_flag  	= CAST(/*prodStartFlag*/ AS decimal),
			stay_num_inside		= CAST(/*stayNumInside*/ AS numeric),
			stay_num_before		= CAST(/*stayNumBefore*/ AS numeric),
			bun_flag			= CAST(/*bunFlag*/ AS decimal),
			std_hour_high		= CAST(/*stdHourHigh*/ AS numeric),
			std_hour_middle		= CAST(/*stdHourMiddle*/ AS numeric),
			std_hour_low		= CAST(/*stdHourLow*/ AS numeric),
			opcua_sv_id			= CAST(/*opcuaSvId*/ AS numeric),
			plc_id				= CAST(/*plcId*/ AS numeric),
			line_end_st			= CAST(/*lineEndSt*/ AS smallint),
			spare_num1			= CAST(/*spareNum1*/ AS numeric),
			spare_num2			= CAST(/*spareNum2*/ AS numeric),
			spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-MA_STATION',
			upd_tim 			= now(),
			upd_user_sid		= 0
		FROM
			val
		WHERE
			MA_STATION.st_id	= /*stId*/

		RETURNING
			MA_STATION.st_id
	)

INSERT INTO
	MA_STATION
SELECT
	*
FROM
	val
WHERE
	(st_id)
		NOT IN (SELECT st_id FROM upd);
