WITH
	val AS (
		SELECT
			(  (
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*syoriKbn*/,
				/*invalidFlag*/,
				/*sasizuNo*/,
				/*sasizuType*/,
				/*werks*/,
				/*orderNo*/,
				/*koNo*/,
				/*tyumonnusi*/,
				/*buhinCd*/,
				/*katasiki*/,
				/*sireiSu*/,
				/*pSasizuNo*/,
				/*wbs*/,
				/*wbsProjectType*/,
				/*hyojyunGenka*/,
				/*sagyoStaBi*/,
				/*kanYoteiBi*/,
				/*yokyuNoki*/,
				/*sagyoku*/,
				/*hasseiDate*/,
				/*henkoDate*/,
				/*torikesiDate*/,
				/*sireiSuOrg*/,
				/*sasizuHenkoDate*/,
				/*startSubNo*/,
				/*pVersion*/,
				/*orderDate*/,
				/*deliveryDate*/,
				/*purchaseDate*/,
				/*lDeliveryDate*/,
				/*factoryDate*/,
				/*snKihon*/,
				/*lotKihon*/,
				/*groupCnt*/,
				/*erpHenkoDate*/,
				/*erpSakujyoFlg*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
				'insert-TR_SASIZU_INFO',
				now(),
				0,
				'insert-TR_SASIZU_INFO',
				now(),
				0
				)::TR_SASIZU_INFO).*
	),

	upd AS (
		UPDATE
			TR_SASIZU_INFO
		SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			syori_kbn			= /*syoriKbn*/,
			invalid_flag		= /*invalidFlag*/,
			sasizu_type			= /*sasizuType*/,
			werks				= /*werks*/,
			order_no			= /*orderNo*/,
			ko_no				= /*koNo*/,
			tyumonnusi			= /*tyumonnusi*/,
			buhin_cd			= /*buhinCd*/,
			katasiki			= /*katasiki*/,
			sirei_su			= CAST(/*sireiSu*/ AS numeric),
			p_sasizu_no			= /*pSasizuNo*/,
			wbs					= /*wbs*/,
			wbs_project_type	= /*wbsProjectType*/,
			hyojyun_genka		= CAST(/*hyojyunGenka*/ AS numeric),
			sagyo_sta_bi		= /*sagyoStaBi*/,
			kan_yotei_bi		= /*kanYoteiBi*/,
			yokyu_noki			= /*yokyuNoki*/,
			sagyoku				= /*sagyoku*/,
			hassei_date			= CAST(/*hasseiDate*/ AS timestamp),
			henko_date			= CAST(/*henkoDate*/ AS timestamp),
			torikesi_date		= CAST(/*torikesiDate*/ AS timestamp),
			sirei_su_org		= CAST(/*sireiSuOrg*/ AS numeric),
			sasizu_henko_date	= CAST(/*sasizuHenkoDate*/ AS timestamp),
			start_sub_no		= CAST(/*startSubNo*/ AS numeric),
			p_version			= /*pVersion*/,
			order_date			= /*orderDate*/,
			delivery_date		= /*deliveryDate*/,
			purchase_date		= /*purchaseDate*/,
			l_delivery_date		= /*lDeliveryDate*/,
			factory_date		= /*factoryDate*/,
			sn_kihon			= /*snKihon*/,
			lot_kihon			= /*lotKihon*/,
			group_cnt			= CAST(/*groupCnt*/ AS numeric),
			erp_henko_date		= CAST(/*erpHenkoDate*/ AS timestamp),
			erp_sakujyo_flg		= /*erpSakujyoFlg*/,
			spare_num1			= CAST(/*spareNum1*/ AS numeric),
			spare_num2			= CAST(/*spareNum2*/ AS numeric),
			spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-TR_SASIZU_INFO',
			upd_tim				= now(),
			upd_user_sid		= 0
		FROM
			val
		WHERE
			TR_SASIZU_INFO.sasizu_no = /*sasizuNo*/

		RETURNING
			TR_SASIZU_INFO.sasizu_no
	)

INSERT INTO
	TR_SASIZU_INFO
SELECT
	*
FROM
	val
WHERE
	(sasizu_no) NOT IN (SELECT sasizu_no FROM upd);
