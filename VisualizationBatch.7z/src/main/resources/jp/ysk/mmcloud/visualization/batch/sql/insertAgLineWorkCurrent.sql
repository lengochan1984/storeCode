WITH
    val AS (
        SELECT
            (   (
				/*lnId*/,
				/*updDate*/,
				/*scheduleNum*/,
				/*actualNum*/,
				/*planNum*/,
				/*predictionCompletionTime*/,
				/*planCompletionTime*/,
				/*preRetentionNum*/,
				/*retentionNum*/,
				/*afterRetentionNum*/,
				/*insProg*/,
				/*insTim*/,
				/*insUserSid*/,
				/*updProg*/,
				/*updTim*/,
				/*updUserSid*/
                )::ag_line_work_current).*
    ),

    upd AS (
        UPDATE
            ag_line_work_current
        SET
			upd_date			= CAST(/*updDate*/ AS timestamp),
			schedule_num		= CAST(/*scheduleNum*/ AS integer),
			actual_num			= CAST(/*actualNum*/ AS integer),
			plan_num			= CAST(/*planNum*/ AS integer),
			prediction_completion_time	= CAST(/*predictionCompletionTime*/ AS timestamp),
			plan_completion_time		= CAST(/*planCompletionTime*/ AS timestamp),
			pre_retention_num	= CAST(/*preRetentionNum*/ AS integer),
			retention_num		= CAST(/*retentionNum*/ AS integer),
			after_retention_num	= CAST(/*afterRetentionNum*/ AS integer),
			ins_prog			= /*insProg*/,
			ins_tim				= CAST(/*insTim*/ AS timestamp),
			ins_user_sid		= CAST(/*insUserSid*/ AS integer),
			upd_prog			= /*updProg*/,
			upd_tim				= CAST(/*updTim*/ AS timestamp),
			upd_user_sid		= CAST(/*updUserSid*/ AS integer)
        FROM
            val
        WHERE
            ag_line_work_current.LN_ID = /*lnId*/

        RETURNING
            ag_line_work_current.LN_ID
    )

INSERT INTO
    ag_line_work_current
SELECT
    *
FROM
    val
WHERE
    (LN_ID)
        NOT IN (SELECT LN_ID FROM upd);
