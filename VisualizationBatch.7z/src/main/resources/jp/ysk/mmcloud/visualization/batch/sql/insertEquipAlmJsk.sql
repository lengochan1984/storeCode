WITH
    val AS (
        SELECT
            (   (
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*stId*/,
				/*almCd*/,
				/*occuredOn*/,
				/*recoveredOn*/,
				/*timeDiff*/,
				/*userId*/,
				/*mainResNo*/,
				/*mainResNm*/,
				/*plantCd*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*processCd*/,
				/*processNm*/,
				/*lnNo*/,
				/*lnNm*/,
				/*stNo*/,
				/*stNm*/,
				/*sagyoku*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
                'insert-TR_EQUIP_ALM_JSK',
                now(),
                0,
                'insert-TR_EQUIP_ALM_JSK',
                now(),
                0
                )::TR_EQUIP_ALM_JSK).*
    ),

    upd AS (
        UPDATE
            TR_EQUIP_ALM_JSK
        SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			recovered_on		= CAST(/*recoveredOn*/ AS timestamp),
			time_diff			= CAST(/*timeDiff*/ AS numeric),
			user_id				= /*userId*/,
			main_res_no			= /*mainResNo*/,
			main_res_nm			= /*mainResNm*/,
			plant_cd			= /*plantCd*/,
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
			process_cd			= /*processCd*/,
			process_nm			= /*processNm*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			st_no				= /*stNo*/,
			st_nm				= /*stNm*/,
			sagyoku				= /*sagyoku*/,
            spare_num1			= CAST(/*spareNum1*/ AS numeric),
            spare_num2			= CAST(/*spareNum2*/ AS numeric),
            spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog            = 'update-TR_EQUIP_ALM_JSK',
            upd_tim             = now(),
            upd_user_sid        = 0
        FROM
            val
        WHERE TR_EQUIP_ALM_JSK.st_id		= /*stId*/
        AND TR_EQUIP_ALM_JSK.alm_cd			= /*almCd*/
        AND TR_EQUIP_ALM_JSK.occured_on		= /*occuredOn*/

        RETURNING
            TR_EQUIP_ALM_JSK.st_id,
            TR_EQUIP_ALM_JSK.alm_cd,
            TR_EQUIP_ALM_JSK.occured_on
    )

INSERT INTO
    TR_EQUIP_ALM_JSK
SELECT
    *
FROM
    val
WHERE
    (st_id, alm_cd, occured_on)
        NOT IN (SELECT st_id, alm_cd, occured_on FROM upd);
