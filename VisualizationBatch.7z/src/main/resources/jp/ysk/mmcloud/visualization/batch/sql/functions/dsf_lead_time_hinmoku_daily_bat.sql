﻿CREATE or REPLACE FUNCTION dsf_lead_time_hinmoku_daily_bat(
	in	i_batch_name	varchar,			-- バッチ処理名称
	in	i_log_type		numeric,			-- ログ種別(開始、および　各バッチ処理の復帰値)
											-- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
	in	i_user_sid		numeric,			-- 登録ユーザSID
	in	i_from_time		timestamp,			-- 集計開始日時(空の場合は当日を対象とする)
	in	i_to_time		timestamp,			-- 集計終了日時(空の場合は当日を対象とする)
	out	o_ret_cd		int,				-- 関数復帰値	RET_OK(= 0):正常終了
	out	o_sqlerr		varchar,			-- ＤＢ異常発生時のエラーコード
	out	o_errmsg		varchar,			-- 異常発生時のエラーメッセージ
	out	o_errpnt		varchar				-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　[サイネージ用]品目別リードタイムデータ(日別)作成サービス
--　ソースプログラム名　：　dsf_lead_time_hinmoku_daily_bat.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　[サイネージ用]品目別リードタイムデータ(日別)を作成する
--
--　履歴
--  Ver.  作成日			作成者		COMMENT
--  1.0   2016/08/25		H.Nakamura	新規作成
--******************************************************************************
DECLARE
	----------------------------------------------------------------------------
	--						標準定数定義
	----------------------------------------------------------------------------
	-- 戻り値
	RET_OK		CONSTANT int := 0 ;						-- 正常終了コード
	RET_NG		CONSTANT int := -1 ;					-- 異常終了コード
	-- 真偽値
	CST_TRUE	CONSTANT int := 1 ;						-- 真
	CST_FALSE	CONSTANT int := 0 ;						-- 偽

	----------------------------------------------------------------------------
	--						標準変数定義
	----------------------------------------------------------------------------
	cst_MY_PRG	CONSTANT CHAR(32)	 := 'dsf_lead_time_hinmoku_daily_bat';	-- プログラム名
	cst_UPD_TIM	CHAR(17) ;													-- 更新時間
	l_err_pnt	CHAR(64) ;													-- エラー発生ポイント
	errbuff		varchar(256);												-- メッセージバッファ

	----------------------------------------------------------------------------
	--						定数定義
	----------------------------------------------------------------------------
	CST_SEISAN_JYOTAI_END	CONSTANT int := 90;				-- 生産状態：生産完了

	----------------------------------------------------------------------------
	--						変数定義
	----------------------------------------------------------------------------
	-- 共通変数
	rtn_sql_no		text;							-- DBエラー情報(エラー番号)
	rtn_sql_msg		text;							-- DBエラー情報(エラーメッセージ)
	rtn_sql_detail	text;							-- DBエラー情報(エラー詳細)
	rtn_sql_hint	text;							-- DBエラー情報(エラーヒント)
	rtn_sql_stack	text;							-- DBエラー情報(エラー発生呼出しスタック)

	-- ローカル変数
	l_exec_datetime				timestamp;			-- 関数実行日時
	l_proc_start_time			timestamp;			-- 処理開始日
	l_proc_end_time				timestamp;			-- 処理終了日
	l_proc_start_time_all		timestamp;			-- 処理開始日(全体)
	l_proc_end_time_all			timestamp;			-- 処理終了日(全体)
	l_running_start_datetime	timestamp;			-- 稼働開始日時(年度開始日時)
	l_plant_cd					varchar(10);		-- プラントコード
	l_plant_cd_wk				varchar(10);		-- プラントコード
	l_sasizu_no					char(12);			-- 指図番号
	l_sub_no					numeric(5);			-- 指図追番
	l_hinmoku_code				char(40);			-- 品目コード
	l_lead_time					bigint;				-- リードタイム

	----------------------------------------------------------------------------
	--						カーソル定義
	----------------------------------------------------------------------------
	-- 工場マスタ
	CUR_MA_PLANT	CURSOR FOR
		SELECT
			T0.PLANT_CD					as plantCode,
			T0.RUNNING_START_DATETIME	as runningStartDatetime
		FROM
			MA_PLANT	T0
		WHERE
			T0.INVALID_FLAG = 0
		ORDER BY
			T0.PLANT_CD
	;

	OPENFLG_MA_PLANT	int;	-- カーソルオープン状態


	-- 製品トレースログ(作業用)
	CUR_TR_PRODUCT_TRC_WK	CURSOR FOR
		SELECT
			T1.WERKS				as plantCode,
			T0.SASIZU_NO			as sasizuNo,
			T0.SUB_NO				as subNo,
			T0.BUHIN_CD				as hinmokuCode,
			TRUNC(SUM(EXTRACT(EPOCH FROM(T0.END_DATE - T0.START_DATE)) * 1000))	as leadTime
		FROM
			TR_PRODUCT_TRC_WK	T0,
			TR_SASIZU_INFO		T1
		WHERE
				T0.SASIZU_NO			=	T1.SASIZU_NO
			AND	T1.WERKS				=	l_plant_cd_wk
			AND	T0.SEISAN_JYOTAI		=	CST_SEISAN_JYOTAI_END
			AND	T0.END_DATE				>=	l_proc_start_time
			AND	T0.END_DATE				<=	l_proc_end_time
		GROUP BY
			plantCode, sasizuNo, subNo, hinmokuCode
	;

	OPENFLG_TR_PRODUCT_TRC_WK		int;	-- カーソルオープン状態


	-- [サイネージ用]品目別リードタイムデータ(日別)
	CUR_DS_LEAD_TIME_HINMOKU_DAILY	CURSOR FOR
		SELECT
			*
		FROM
			DS_LEAD_TIME_HINMOKU_DAILY
		WHERE
				PLANT_CD		= l_plant_cd
			AND	SASIZU_NO		= l_sasizu_no
			AND	SUB_NO			= l_sub_no
			AND	BUHIN_CD		= l_hinmoku_code
			AND	DATA_DATE		= l_proc_start_time
		FOR UPDATE NOWAIT
	;

	OPENFLG_DS_LEAD_TIME_HINMOKU_DAILY	int;	-- カーソルオープン状態
	REC_DS_LEAD_TIME_HINMOKU_DAILY		DS_LEAD_TIME_HINMOKU_DAILY%ROWTYPE;

BEGIN
	----------------------------------------------------------------------------
	--						初期処理
	----------------------------------------------------------------------------
	raise info 'Start Function [%]', clock_timestamp()::timestamp;

	-- 共通変数初期化
	l_err_pnt		:= RTRIM(cst_MY_PRG) || '_S001';

	-- 共通出力パラメータ初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
	o_ret_cd	:= RET_OK;
	o_sqlerr	:= ' ';
	o_errmsg	:= ' ';
	o_errpnt	:= ' ';

	-- 関数実行日時
	l_exec_datetime := clock_timestamp();

	-- 集計開始/終了日時補正
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
	IF i_from_time IS NULL THEN
		i_from_time := l_exec_datetime;
	END IF;
	IF i_to_time IS NULL OR i_from_time > i_to_time THEN
		i_to_time := l_exec_datetime;
	END IF;

	-- カーソルオープン状態初期化
	OPENFLG_MA_PLANT := CST_FALSE;
	OPENFLG_TR_PRODUCT_TRC_WK := CST_FALSE;
	OPENFLG_DS_LEAD_TIME_HINMOKU_DAILY := CST_FALSE;

	----------------------------------------------------------------------------
	-- メイン処理
	----------------------------------------------------------------------------
	<< MAIN_LOOP >>
	LOOP

		------------------------------------------------------------------------
		-- 工場ごとに稼働開始日時が異なるので、工場マスタで処理を回す
		------------------------------------------------------------------------
		-- 工場マスタを開いているならクローズ
		l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
		IF OPENFLG_MA_PLANT = CST_TRUE THEN
			CLOSE CUR_MA_PLANT;
			OPENFLG_MA_PLANT := CST_FALSE;
		END IF;

		-- 工場マスタをオープン
		l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
		OPEN CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_TRUE;

		<< PLANT_LOOP >>
		LOOP
			-- 工場マスタからフェッチ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
			FETCH CUR_MA_PLANT INTO l_plant_cd_wk, l_running_start_datetime;
			IF FOUND = FALSE THEN
				EXIT PLANT_LOOP;
			END IF;

			IF l_running_start_datetime IS NULL THEN
				-- NULLの場合はデフォルト値をセット
				l_err_pnt := RTRIM(cst_MY_PRG) || '_202';
				l_running_start_datetime = timestamp '0001-03-21 07:00:00';
			END IF;

			-- 処理開始日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_203';
			SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_all;
			<< START_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_LP01';
				IF i_from_time >= l_proc_start_time_all THEN
					EXIT START_TIME_LOOP;
				END IF;
				l_proc_start_time_all := l_proc_start_time_all + interval '-1 days';
			END LOOP	START_TIME_LOOP;

			-- 処理終了日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_204';
			SELECT l_proc_start_time_all + interval '1 days' + interval '-1 milliseconds' INTO l_proc_end_time_all;
			<< END_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_LP02';
				IF i_to_time <= l_proc_end_time_all THEN
					EXIT END_TIME_LOOP;
				END IF;
				l_proc_end_time_all := l_proc_end_time_all + interval '1 days';
			END LOOP	END_TIME_LOOP;

			-- 処理開始/終了日時
			l_err_pnt := RTRIM(cst_MY_PRG) || '_205';
			l_proc_start_time := l_proc_start_time_all;
			l_proc_end_time := l_proc_start_time + interval '1 days' + interval '-1 milliseconds';

			<< TIME_LOOP >>
			LOOP

				-- 製品トレースログ(作業用)を開いているならクローズ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_301';
				IF OPENFLG_TR_PRODUCT_TRC_WK = CST_TRUE THEN
					CLOSE CUR_TR_PRODUCT_TRC_WK;
					OPENFLG_TR_PRODUCT_TRC_WK := CST_FALSE;
				END IF;

				-- 製品トレースログ(作業用)オープン
				l_err_pnt := RTRIM(cst_MY_PRG) || '_302';
				OPEN CUR_TR_PRODUCT_TRC_WK;
				OPENFLG_TR_PRODUCT_TRC_WK := CST_TRUE;

				<< PRODUCT_TRACE_LOG_WK_LOOP >>
				LOOP
					-- 製品トレースログ(作業用)フェッチ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_401';
					FETCH CUR_TR_PRODUCT_TRC_WK INTO l_plant_cd, l_sasizu_no, l_sub_no, l_hinmoku_code, l_lead_time;
					IF FOUND = FALSE THEN
						EXIT PRODUCT_TRACE_LOG_WK_LOOP;
					END IF;

					-- [サイネージ用]品目別リードタイムデータ(日別)に既に集計データが存在するかを確認
					-- [サイネージ用]品目別リードタイムデータ(日別)を開いているならクローズ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_402';
					IF OPENFLG_DS_LEAD_TIME_HINMOKU_DAILY = CST_TRUE THEN
						CLOSE CUR_DS_LEAD_TIME_HINMOKU_DAILY;
						OPENFLG_DS_LEAD_TIME_HINMOKU_DAILY := CST_FALSE;
					END IF;

					-- [サイネージ用]品目別リードタイムデータ(日別)をオープン
					l_err_pnt := RTRIM(cst_MY_PRG) || '_403';
					OPEN CUR_DS_LEAD_TIME_HINMOKU_DAILY;
					OPENFLG_DS_LEAD_TIME_HINMOKU_DAILY := CST_TRUE;

					-- [サイネージ用]品目別リードタイムデータ(日別)からフェッチ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_404';
					FETCH CUR_DS_LEAD_TIME_HINMOKU_DAILY INTO REC_DS_LEAD_TIME_HINMOKU_DAILY;
					IF FOUND = FALSE THEN
						-- [サイネージ用]品目別リードタイムデータ(日別)に格納
						l_err_pnt := RTRIM(cst_MY_PRG) || '_501';
						INSERT INTO DS_LEAD_TIME_HINMOKU_DAILY
						(
							  PLANT_CD								-- プラントコード
							, SASIZU_NO								-- 指図番号
							, SUB_NO								-- 指図追番
							, BUHIN_CD								-- 品目コード
							, DATA_DATE								-- データ日付
							, LEAD_TIME								-- リードタイム
							, INS_PROG								-- 登録プログラム名
							, INS_TIM								-- 登録日時
							, INS_USER_SID							-- 登録ユーザSID
							, UPD_PROG								-- 更新プログラム名
							, UPD_TIM								-- 更新日時
							, UPD_USER_SID							-- 更新ユーザSID
						)
						VALUES
						(
							  l_plant_cd							-- プラントコード
							, l_sasizu_no							-- 指図番号
							, l_sub_no								-- 指図追番
							, l_hinmoku_code						-- 品目コード
							, l_proc_start_time						-- データ日付
							, l_lead_time							-- リードタイム
							, cst_MY_PRG							-- 登録プログラム
							, l_exec_datetime						-- 登録日時
							, i_user_sid							-- 登録ユーザSID
							, cst_MY_PRG							-- 更新プログラム
							, l_exec_datetime						-- 更新日時
							, i_user_sid							-- 更新ユーザSID
						);
					ELSE
						-- [サイネージ用]品目別リードタイムデータ(日別)を更新
						l_err_pnt := RTRIM(cst_MY_PRG) || '_502';
						UPDATE DS_LEAD_TIME_HINMOKU_DAILY SET
							  LEAD_TIME		= l_lead_time			-- リードタイム
							, UPD_PROG		= cst_MY_PRG			-- 更新プログラム
							, UPD_TIM		= l_exec_datetime		-- 更新日時
							, UPD_USER_SID	= i_user_sid			-- 更新ユーザSID
						WHERE CURRENT OF CUR_DS_LEAD_TIME_HINMOKU_DAILY;
					END IF;

				END LOOP	PRODUCT_TRACE_LOG_WK_LOOP;

				-- 次の処理日時を設定
				l_proc_start_time	:= l_proc_start_time + interval '1 days';
				l_proc_end_time		:= l_proc_end_time + interval '1 days';

				-- 処理開始日時が処理終了日時(全体)を超えている場合は処理終了
				IF l_proc_end_time_all < l_proc_start_time THEN
					EXIT TIME_LOOP;
				END IF;

			END LOOP	TIME_LOOP;

		END LOOP	PLANT_LOOP;

		EXIT MAIN_LOOP;
	END LOOP	MAIN_LOOP;

	----------------------------------------------------------------------------
	--						終了処理
	----------------------------------------------------------------------------
	-- カーソルクローズ
	l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
	IF OPENFLG_MA_PLANT = CST_TRUE THEN
		CLOSE CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E002';
	IF OPENFLG_TR_PRODUCT_TRC_WK = CST_TRUE THEN
		CLOSE CUR_TR_PRODUCT_TRC_WK;
		OPENFLG_TR_PRODUCT_TRC_WK := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
	IF OPENFLG_DS_LEAD_TIME_HINMOKU_DAILY = CST_TRUE THEN
		CLOSE CUR_DS_LEAD_TIME_HINMOKU_DAILY;
		OPENFLG_DS_LEAD_TIME_HINMOKU_DAILY := CST_FALSE;
	END IF;

	raise info 'End Function [%]', clock_timestamp()::timestamp;

EXCEPTION WHEN OTHERS THEN
	-- DB例外情報収集
	GET STACKED DIAGNOSTICS rtn_sql_no     = RETURNED_SQLSTATE,
							rtn_sql_msg    = MESSAGE_TEXT,
							rtn_sql_detail = PG_EXCEPTION_DETAIL,
							rtn_sql_hint   = PG_EXCEPTION_HINT,
							rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

	raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
	raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

	o_ret_cd := RET_NG;
	o_sqlerr := substr(rtn_sql_no, 1, 15);
	o_errmsg := substr(rtn_sql_msg, 1, 127);
	o_errpnt := l_err_pnt;

	raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;
