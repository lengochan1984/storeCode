WITH
    val AS (
        SELECT
            (   (
				/*vtextInfo2*/,
				/*jobPtnId*/,
				/*stepNo*/,
				/*dataDate*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*processCd*/,
				/*processNm*/,
				/*lnNo*/,
				/*lnNm*/,
				/*jobPtnName*/,
				/*standardManhour*/,
				/*workManhourAverage*/,
				/*standardDeviation*/,
				/*parameter*/,
				/*insProg*/,
				/*insTim*/,
				/*insUserSid*/,
				/*updProg*/,
				/*updTim*/,
				/*updUserSid*/
                )::ag_work_manhour_mng_s_daily).*
    ),

    upd AS (
        UPDATE
            ag_work_manhour_mng_s_daily
        SET
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
			process_cd			= /*processCd*/,
			process_nm			= /*processNm*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			job_ptn_name		= /*jobPtnName*/,
			standard_manhour	= CAST(/*standardManhour*/ AS integer),
			work_manhour_average	= CAST(/*workManhourAverage*/ AS numeric),
			standard_deviation	= CAST(/*standardDeviation*/ AS numeric),
			parameter			= CAST(/*parameter*/ AS integer),
			ins_prog			= /*insProg*/,
			ins_tim				= CAST(/*insTim*/ AS timestamp),
			ins_user_sid		= CAST(/*insUserSid*/ AS integer),
			upd_prog			= /*updProg*/,
			upd_tim				= CAST(/*updTim*/ AS timestamp),
			upd_user_sid		= CAST(/*updUserSid*/ AS integer)
        FROM
            val
        WHERE
            ag_work_manhour_mng_s_daily.vtext_info2	= /*vtextInfo2*/
        AND ag_work_manhour_mng_s_daily.job_ptn_id	= /*jobPtnId*/
        AND ag_work_manhour_mng_s_daily.step_no		= /*stepNo*/
        AND ag_work_manhour_mng_s_daily.data_date	= /*dataDate*/

        RETURNING
            ag_work_manhour_mng_s_daily.vtext_info2,
            ag_work_manhour_mng_s_daily.job_ptn_id,
            ag_work_manhour_mng_s_daily.step_no,
            ag_work_manhour_mng_s_daily.data_date
    )

INSERT INTO
    ag_work_manhour_mng_s_daily
SELECT
    *
FROM
    val
WHERE
    (vtext_info2, job_ptn_id, step_no, data_date)
        NOT IN (SELECT vtext_info2, job_ptn_id, step_no, data_date FROM upd);
