WITH
	val AS (
		SELECT
			(	(
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*invalidFlag*/,
				/*mainResNo*/,
				/*plantCd*/,
				/*mainResNm*/,
				/*equipCd*/,
				/*fixedAssetNo*/,
				/*inventoryNo*/,
				/*equipLevel*/,
				/*stId*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
				'insert-MA_EQUIP',
				now(),
				0,
				'insert-MA_EQUIP',
				now(),
				0
				)::MA_EQUIP).*
	),

	upd AS (
		UPDATE
			MA_EQUIP
		SET
			modified_on 		= CAST(/*modifiedOn*/ AS timestamp),
			modified_by 		= /*modifiedBy*/,
			invalid_flag		= /*invalidFlag*/,
			main_res_nm 		= /*mainResNm*/,
			equip_cd			= /*equipCd*/,
			fixed_asset_no		= /*fixedAssetNo*/,
			inventory_no		= /*inventoryNo*/,
			equip_level 		= CAST(/*equipLevel*/ AS numeric),
			st_id				= CAST(/*stId*/ AS numeric),
			spare_num1			= CAST(/*spareNum1*/ AS numeric),
			spare_num2			= CAST(/*spareNum2*/ AS numeric),
			spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1 		= /*spareText1*/,
			spare_text2 		= /*spareText2*/,
			spare_text3 		= /*spareText3*/,
			upd_prog			= 'update-MA_EQUIP',
			upd_tim 			= now(),
			upd_user_sid		= 0
		FROM
			val
		WHERE
				MA_EQUIP.main_res_no	= /*mainResNo*/
			AND	MA_EQUIP.plant_cd		= /*plantCd*/

		RETURNING
			MA_EQUIP.main_res_no,
			MA_EQUIP.plant_cd
	)

INSERT INTO
	MA_EQUIP
SELECT
	*
FROM
	val
WHERE
	(main_res_no, plant_cd)
		NOT IN (SELECT main_res_no, plant_cd FROM upd);
