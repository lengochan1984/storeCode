WITH
	val AS (
		SELECT
			(  (
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*invalidFlag*/,
				/*sasizuNo*/,
				/*procManId*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
				'insert-TR_SASIZU_MAN',
				now(),
				0,
				'insert-TR_SASIZU_MAN',
				now(),
				0
				)::TR_SASIZU_MAN).*
	),

	upd AS (
		UPDATE
			TR_SASIZU_MAN
		SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			invalid_flag		= /*invalidFlag*/,
			proc_man_id			= CAST(/*procManId*/ AS numeric),
			spare_num1			= CAST(/*spareNum1*/ AS numeric),
			spare_num2			= CAST(/*spareNum2*/ AS numeric),
			spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-TR_SASIZU_MAN',
			upd_tim				= now(),
			upd_user_sid		= 0
		FROM
			val
		WHERE
			TR_SASIZU_MAN.sasizu_no = /*sasizuNo*/

		RETURNING
			TR_SASIZU_MAN.sasizu_no
	)

INSERT INTO
	TR_SASIZU_MAN
SELECT
	*
FROM
	val
WHERE
	(sasizu_no) NOT IN (SELECT sasizu_no FROM upd);
