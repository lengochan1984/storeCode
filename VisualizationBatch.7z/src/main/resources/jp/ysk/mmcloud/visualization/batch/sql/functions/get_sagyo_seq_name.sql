create or replace function get_sagyo_seq_name(varchar, varchar)
returns text
AS '
DECLARE
	p1 alias for $1;
	p2 alias for $2;
	ret varchar(128);
BEGIN
	IF (p1 IS NULL) THEN
		ret := ''-'';
	ELSIF (p1 = ''0'') THEN
		-- 本線
		SELECT
			name1
		INTO
			ret
		FROM
			sys_name
		WHERE
				name_type = ''sagyo_seq''
			and	item_cd = ''0''
			and	lang_cd = p2;
	ELSE
		-- 平行
		SELECT
			name1 || p1
		INTO
			ret
		FROM
			sys_name
		WHERE
				name_type = ''sagyo_seq''
			and	item_cd = ''1''
			and	lang_cd = p2;
	END IF;

	RETURN ret;
END;
'
language 'plpgsql';
