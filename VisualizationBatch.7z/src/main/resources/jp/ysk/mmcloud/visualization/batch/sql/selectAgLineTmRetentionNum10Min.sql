SELECT
    ln_id,
    n_ln_id,
    data_date,
    plant_cd,
    seizou_ln_cd,
    seizou_ln_nm,
    process_cd,
    process_nm,
    ln_no,
    ln_nm,
    n_process_cd,
    n_process_nm,
    n_ln_no,
    n_ln_nm,
    retention_num,
    cost_price,
    ins_prog,
    ins_tim,
    ins_user_sid,
    upd_prog,
    upd_tim,
    upd_user_sid

FROM
    ag_line_tm_retention_num_10min

/*BEGIN*/
WHERE
    /*IF addDatetime != null*/
        (ins_tim >= /*addDatetime*/ AND upd_tim is null)
    OR  upd_tim >= /*addDatetime*/
    /*END*/
/*END*/

ORDER BY
    COALESCE(upd_tim, ins_tim)
