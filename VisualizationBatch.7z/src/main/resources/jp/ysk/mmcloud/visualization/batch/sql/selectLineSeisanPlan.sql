SELECT
    t0.created_on
  , t0.created_by
  , t0.modified_on
  , t0.modified_by
  , t0.seisan_bi
  , t0.ln_id
  , t0.ln_no
  , t0.ln_nm
  , t0.seisan_keikaku
  , t0.seisan_yotei
  , t0.spare_num1
  , t0.spare_num2
  , t0.spare_num3
  , t0.spare_text1
  , t0.spare_text2
  , t0.spare_text3
  , t0.ins_prog
  , t0.ins_tim
  , t0.ins_user_sid
  , t0.upd_prog
  , t0.upd_tim
  , t0.upd_user_sid
FROM
    tr_line_seisan_plan t0
    INNER JOIN ma_line t1 ON t1.ln_id = t0.ln_id
    INNER JOIN ma_process t2 ON t2.process_id = t1.process_id
    INNER JOIN ma_seizou_line t3 ON t3.seizou_ln_id = t2.seizou_ln_id
    INNER JOIN ma_plant t4 ON t4.plant_cd = t3.plant_cd

WHERE
    t4.plant_cd = /*plantCd*/
    /*IF addDatetime != null */
    AND (
        t0.ins_tim >= /*addDatetime*/
    OR  t0.upd_tim >= /*addDatetime*/
    )
    /*END*/
ORDER BY
    t0.seisan_bi,t0.ln_id
