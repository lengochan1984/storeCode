WITH
    val AS (
        SELECT
            (   (
                /*createdOn*/,
                /*createdBy*/,
                /*modifiedOn*/,
                /*modifiedBy*/,
				/*lnId*/,
				/*opeKind*/,
				/*startTime*/,
				/*endTime*/,
				/*timeDiff*/,
				/*stNo*/,
				/*syainNo*/,
				/*plantCd*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*processCd*/,
				/*processNm*/,
				/*lnNo*/,
				/*lnNm*/,
                /*spareNum1*/,
                /*spareNum2*/,
                /*spareNum3*/,
                /*spareText1*/,
                /*spareText2*/,
                /*spareText3*/,
                'insert-TR_LINE_OPE_LOG',
                now(),
                0,
                'insert-TR_LINE_OPE_LOG',
                now(),
                0
                )::TR_LINE_OPE_LOG).*
    ),

    upd AS (
        UPDATE
            TR_LINE_OPE_LOG
        SET
			modified_on         = CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			end_time			= CAST(/*endTime*/ AS timestamp),
			time_diff			= CAST(/*timeDiff*/ AS numeric),
			st_no				= /*stNo*/,
			syain_no			= /*syainNo*/,
			plant_cd			= /*plantCd*/,
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
			process_cd			= /*processCd*/,
			process_nm			= /*processNm*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
            spare_num1			= CAST(/*spareNum1*/ AS numeric),
            spare_num2			= CAST(/*spareNum2*/ AS numeric),
            spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
            upd_prog            = 'update-TR_LINE_OPE_LOG',
            upd_tim             = now(),
            upd_user_sid        = 0
        FROM
            val
        WHERE
            TR_LINE_OPE_LOG.ln_id		= /*lnId*/
        AND TR_LINE_OPE_LOG.ope_kind	= /*opeKind*/
        AND TR_LINE_OPE_LOG.start_time	= /*startTime*/

        RETURNING
            TR_LINE_OPE_LOG.ln_id,
            TR_LINE_OPE_LOG.ope_kind,
            TR_LINE_OPE_LOG.start_time
    )

INSERT INTO
    TR_LINE_OPE_LOG
SELECT
    *
FROM
    val
WHERE
    (ln_id, ope_kind, start_time)
        NOT IN (SELECT ln_id, ope_kind, start_time FROM upd);
