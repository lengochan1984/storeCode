WITH
    val AS (
        SELECT
            (   (
				/*lnId*/,
				/*nLnId*/,
				/*dataDate*/,
				/*plantCd*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*processCd*/,
				/*processNm*/,
				/*lnNo*/,
				/*lnNm*/,
				/*nProcessCd*/,
				/*nProcessNm*/,
				/*nLnNo*/,
				/*nLnNm*/,
				/*retentionNum*/,
				/*costPrice*/,
				/*insProg*/,
				/*insTim*/,
				/*insUserSid*/,
				/*updProg*/,
				/*updTim*/,
				/*updUserSid*/
                )::ag_line_tm_retention_num_10min).*
    ),

    upd AS (
        UPDATE
            ag_line_tm_retention_num_10min
        SET
			plant_cd			= /*plantCd*/,
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
			process_cd			= /*processCd*/,
			process_nm			= /*processNm*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			retention_num		= CAST(/*retentionNum*/ AS integer),
			cost_price			= CAST(/*costPrice*/ AS integer),
			ins_prog			= /*insProg*/,
			ins_tim				= CAST(/*insTim*/ AS timestamp),
			ins_user_sid		= CAST(/*insUserSid*/ AS integer),
			upd_prog			= /*updProg*/,
			upd_tim				= CAST(/*updTim*/ AS timestamp),
			upd_user_sid		= CAST(/*updUserSid*/ AS integer)
        FROM
            val
        WHERE
            ag_line_tm_retention_num_10min.LN_ID = /*lnId*/
        AND ag_line_tm_retention_num_10min.N_LN_ID = /*nLnId*/
        AND ag_line_tm_retention_num_10min.data_date = /*dataDate*/

        RETURNING
            ag_line_tm_retention_num_10min.LN_ID,
            ag_line_tm_retention_num_10min.N_LN_ID,
            ag_line_tm_retention_num_10min.data_date
    )

INSERT INTO
    ag_line_tm_retention_num_10min
SELECT
    *
FROM
    val
WHERE
    (LN_ID, N_LN_ID, data_date)
        NOT IN (SELECT LN_ID, N_LN_ID, data_date FROM upd);
