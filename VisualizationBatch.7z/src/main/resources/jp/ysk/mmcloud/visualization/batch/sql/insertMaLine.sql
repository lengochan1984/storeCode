WITH
	val AS (
		SELECT
			(	(
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*invalidFlag*/,
				/*lnId*/,
				/*lnNo*/,
				/*lnNm*/,
				/*processId*/,
				/*typicalLnId*/,
				/*stayInsideTh*/,
				/*stayBeforeTh*/,
				/*stayAfterTh*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
				'insert-MA_LINE',
				now(),
				0,
				'insert-MA_LINE',
				now(),
				0
				)::MA_LINE).*
	),

	upd AS (
		UPDATE
			MA_LINE
		SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			invalid_flag		= /*invalidFlag*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			process_id			= CAST(/*processId*/ AS numeric),
			typical_ln_id		= /*typicalLnId*/,
			stay_inside_th		= CAST(/*stayInsideTh*/ AS numeric),
			stay_before_th		= CAST(/*stayBeforeTh*/ AS numeric),
			stay_after_th		= CAST(/*stayAfterTh*/ AS numeric),
			spare_num1			= CAST(/*spareNum1*/ AS numeric),
			spare_num2			= CAST(/*spareNum2*/ AS numeric),
			spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-MA_LINE',
			upd_tim 			= now(),
			upd_user_sid		= 0
		FROM
			val
		WHERE
			MA_LINE.ln_id = /*lnId*/

		RETURNING
			MA_LINE.ln_id
	)

INSERT INTO
	MA_LINE
SELECT
	*
FROM
	val
WHERE
	(ln_id)
		NOT IN (SELECT ln_id FROM upd);
