SELECT
    CREATED_ON,
    CREATED_BY,
    CASE WHEN HIS_KBN != 'D' THEN COALESCE(MODIFIED_ON, CREATED_ON) ELSE EVENT_TIME END AS MODIFIED_ON,
    COALESCE(MODIFIED_BY, CREATED_BY) AS MODIFIED_BY,
    CASE WHEN HIS_KBN != 'D' THEN 0 ELSE 1 END AS INVALID_FLAG,
    MATNR,
    MBRSH,
    MTART,
    WERKS,
    BISMT,
    LABOR,
    PRDHA,
    MSTAE,
    MSTDE,
    MTPOS_MARA,
    FERTH,
    NORMT,
    ZEINR,
    ZEIAR,
    ZEIVR,
    AESZN,
    BLANZ,
    MEINS,
    MATKL,
    GEWEI,
    TRAGR,
    RBNRM,
    SPART,
    WRKST,
    DWERK,
    SKTOF,
    VERSG,
    KONDM,
    MTPOS,
    PRODH,
    MVGR1,
    MVGR2,
    MTVFP,
    LADGR,
    PRCTR,
    MMSTA,
    DISMM,
    DISPO,
    DISLS,
    BESKZ,
    SOBSL,
    DZEIT,
    FHORI,
    EISBE,
    PERKZ,
    STRGR,
    VRMOD,
    VINT1,
    VINT2,
    WZEIT,
    SBDKZ,
    FEVOR,
    SFCPF,
    LOSGR,
    EKGRP,
    KAUTB,
    WEBAZ,
    KORDB,
    USEQU,
    MTVER,
    DISGR,
    MAABC,
    MINBE,
    LFRHY,
    FXHOR,
    BSTMI,
    BSTMA,
    BSTFE,
    RDPRF,
    BSTRF,
    PLIFZ,
    FABKZ,
    LGPRO,
    LGFSB,
    EPRIO,
    MISKZ,
    KAUSF,
    MATGR,
    QMATA,
    TAXM1,
    ALAND,
    MAKTX,
    REVLV,
    RAUBE,
    BSTME,
    UEETK,
    LGRAD,
    SCHGT,
    LVORM1,
    LVORM2,
    TDLINE,
    VTEXT_INFO1,
    VTEXT_INFO2,
    EAN_CODE,
    GENSANKOKU,
    GENSANKOKU_NM,
    COALESCE(TO_TIMESTAMP(RTRIM(TO_CHAR(ERP_HENKO_BI, 'YYYY-MM-DD') || REPLACE(ERP_HENKO_JI, ':', '')), 'YYYY-MM-DDHH24MISS'), null) as ERP_HENKO_DATE,
    SPARE_NUM1,
    SPARE_NUM2,
    SPARE_NUM3,
    SPARE_TEXT1,
    SPARE_TEXT2,
    SPARE_TEXT3

FROM
(
    SELECT
        SUB.*
    FROM
    (
        SELECT
            *,
            ROW_NUMBER() OVER (PARTITION BY MATNR, WERKS ORDER BY EVENT_TIME DESC) AS rowIndex
        FROM
            MA_HINMOKU_HIS
    ) SUB
    WHERE
        SUB.rowIndex = 1
) T

/*BEGIN*/
WHERE
    /*IF addDatetime != null */
        (CREATED_ON >= /*addDatetime*/ AND MODIFIED_ON is null)
    OR  MODIFIED_ON >= /*addDatetime*/
    /*END*/
/*END*/

ORDER BY
    CASE WHEN HIS_KBN != 'D' THEN COALESCE(MODIFIED_ON, CREATED_ON) ELSE EVENT_TIME END
