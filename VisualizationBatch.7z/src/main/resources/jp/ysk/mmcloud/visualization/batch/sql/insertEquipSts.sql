WITH
    val AS (
        SELECT
            (   (
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*mainResNo*/,
				/*plantCd*/,
				/*onlineFlg*/,
				/*stsCd*/,
				/*almCd*/,
				/*mainteSkdCnt*/,
				/*mainteCnt*/,
				/*uptime*/,
                /*spareNum1*/,
                /*spareNum2*/,
                /*spareNum3*/,
                /*spareText1*/,
                /*spareText2*/,
                /*spareText3*/,
                'insert-TR_EQUIP_STS',
                now(),
                0,
                'insert-TR_EQUIP_STS',
                now(),
                0
                )::TR_EQUIP_STS).*
    ),

    upd AS (
        UPDATE
            TR_EQUIP_STS
        SET
			modified_on         = CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			online_flg			= CAST(/*onlineFlg*/ AS decimal),
			sts_cd				= /*stsCd*/,
			alm_cd				= /*almCd*/,
			mainte_skd_cnt		= CAST(/*mainteSkdCnt*/ AS numeric),
			mainte_cnt			= CAST(/*mainteCnt*/ AS numeric),
			uptime				= CAST(/*uptime*/ AS numeric),
            spare_num1			= CAST(/*spareNum1*/ AS numeric),
            spare_num2			= CAST(/*spareNum2*/ AS numeric),
            spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-TR_EQUIP_STS',
			upd_tim				= now(),
			upd_user_sid		= 0

        FROM
            val
        WHERE
            TR_EQUIP_STS.main_res_no   	= /*mainResNo*/
		AND TR_EQUIP_STS.plant_cd    	= /*plantCd*/

        RETURNING
            TR_EQUIP_STS.main_res_no,
            TR_EQUIP_STS.plant_cd
    )

INSERT INTO
    TR_EQUIP_STS
SELECT
    *
FROM
    val
WHERE
    (main_res_no, plant_cd)
        NOT IN (SELECT main_res_no, plant_cd FROM upd);