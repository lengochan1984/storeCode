﻿CREATE or REPLACE FUNCTION func_station_work_current(
	in	i_batch_name	varchar,			-- バッチ処理名称
	in	i_log_type		numeric,			-- ログ種別(開始、および　各バッチ処理の復帰値)
											-- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
	in	i_user_sid		numeric,			-- 登録ユーザSID
	in	i_from_time		timestamp,			-- 集計開始日時(空の場合は当日を対象とする)
	in	i_to_time		timestamp,			-- 集計終了日時(空の場合は当日を対象とする)
	out	o_ret_cd		int,				-- 関数復帰値	RET_OK(= 0):正常終了
	out	o_sqlerr		varchar,			-- ＤＢ異常発生時のエラーコード
	out	o_errmsg		varchar,			-- 異常発生時のエラーメッセージ
	out	o_errpnt		varchar				-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　ステーション予定/実績/計画(現状)作成サービス
--　ソースプログラム名　：　func_station_work_current.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　ステーション予定/実績/計画(現状)を作成する
--
--　履歴
--  Ver.  作成日			作成者		COMMENT
--  1.0   2016/12/05		H.Nakamura	新規作成
--  1.1   2017/06/09		H.Nakamura	処理速度改善
--******************************************************************************
DECLARE
	----------------------------------------------------------------------------
	--						標準定数定義
	----------------------------------------------------------------------------
	-- 戻り値
	RET_OK		CONSTANT int := 0 ;						-- 正常終了コード
	RET_NG		CONSTANT int := -1 ;					-- 異常終了コード
	-- 真偽値
	CST_TRUE	CONSTANT int := 1 ;						-- 真
	CST_FALSE	CONSTANT int := 0 ;						-- 偽

	----------------------------------------------------------------------------
	--						標準変数定義
	----------------------------------------------------------------------------
	cst_MY_PRG	CONSTANT CHAR(32)	 := 'func_station_work_current';		-- プログラム名
	cst_UPD_TIM	CHAR(17) ;													-- 更新時間
	l_err_pnt	CHAR(64) ;													-- エラー発生ポイント
	errbuff		varchar(256);												-- メッセージバッファ

	----------------------------------------------------------------------------
	--						定数定義
	----------------------------------------------------------------------------
	CST_ALL_ST_ID	CONSTANT int	:= -1;			-- ステーションID

	----------------------------------------------------------------------------
	--						変数定義
	----------------------------------------------------------------------------
	-- 共通変数
	rtn_sql_no		text;							-- DBエラー情報(エラー番号)
	rtn_sql_msg		text;							-- DBエラー情報(エラーメッセージ)
	rtn_sql_detail	text;							-- DBエラー情報(エラー詳細)
	rtn_sql_hint	text;							-- DBエラー情報(エラーヒント)
	rtn_sql_stack	text;							-- DBエラー情報(エラー発生呼出しスタック)

	-- ローカル変数
	l_exec_datetime					timestamp;		-- 関数実行日時
	l_proc_start_time				timestamp;		-- 処理開始日
	l_proc_end_time					timestamp;		-- 処理終了日
	l_proc_start_time_all			timestamp;		-- 処理開始日(全体)
	l_proc_end_time_all				timestamp;		-- 処理終了日(全体)
	l_running_start_datetime		timestamp;		-- 稼働開始日時(年度開始日時)
	l_plant_cd						char(10);		-- 工場コード
	l_st_id							int;			-- ステーションID
	l_upd_date						timestamp;		-- 更新日時
	l_schedule_num					int;			-- 予測数
	l_actual_num					int;			-- 実績数
	l_plan_num						int;			-- 計画数
	l_current_datetime				timestamp;		-- 現在日時
	l_prediction_completion_time	timestamp;		-- 完了時刻(予測)
	l_plan_completion_time			timestamp;		-- 完了時刻(計画)
	l_pre_retention_num				int;			-- ライン前の滞留数
	l_retention_num					int;			-- ライン内の滞留数

	----------------------------------------------------------------------------
	--						カーソル定義
	----------------------------------------------------------------------------
	--------------------------------------------------
	-- マスタ
	--------------------------------------------------
	-- 工場マスタ
	CUR_MA_PLANT	CURSOR FOR
		SELECT
			PLANT_CD					as plantCd,
			RUNNING_START_DATETIME		as runningStartDatetime
		FROM
			MA_PLANT
		--WHERE
		--	INVALID_FLAG = 0
		ORDER BY
			PLANT_CD
	;

	OPENFLG_MA_PLANT	int;	-- カーソルオープン状態


	-- 各種データ取得
	CUR_GET_DATA	CURSOR FOR
		SELECT
			T0.ST_ID,
			CASE WHEN T2.UPD_DATE IS NOT NULL AND T2.UPD_DATE >= COALESCE(T3.UPD_DATE, '0001-01-01 00:00:00') AND T2.UPD_DATE >= COALESCE(T4.UPD_DATE, '0001-01-01 00:00:00') AND T2.UPD_DATE >= COALESCE(T5.UPD_DATE, '0001-01-01 00:00:00') THEN T2.UPD_DATE
			     WHEN T3.UPD_DATE IS NOT NULL AND T3.UPD_DATE >= COALESCE(T2.UPD_DATE, '0001-01-01 00:00:00') AND T3.UPD_DATE >= COALESCE(T4.UPD_DATE, '0001-01-01 00:00:00') AND T3.UPD_DATE >= COALESCE(T5.UPD_DATE, '0001-01-01 00:00:00') THEN T3.UPD_DATE
			     WHEN T4.UPD_DATE IS NOT NULL AND T4.UPD_DATE >= COALESCE(T2.UPD_DATE, '0001-01-01 00:00:00') AND T4.UPD_DATE >= COALESCE(T3.UPD_DATE, '0001-01-01 00:00:00') AND T4.UPD_DATE >= COALESCE(T5.UPD_DATE, '0001-01-01 00:00:00') THEN T4.UPD_DATE
			     ELSE COALESCE(T5.UPD_DATE, L_PROC_START_TIME)
			     END AS UPD_DATE,
			-1 AS SCHEDULE_NUM,
			CASE WHEN T2.ACTUAL_NUM IS NOT NULL THEN T2.ACTUAL_NUM ELSE CASE WHEN T6.LOG_NUM > 0 OR T7.LOG_NUM > 0 THEN 0 ELSE -1 END END AS ACTUAL_NUM,
			CASE WHEN T3.PLAN_NUM IS NOT NULL THEN T3.PLAN_NUM ELSE -1 END AS PLAN_NUM,
			NULL AS PREDICTION_COMPLETION_TIME,
			NULL AS PLAN_COMPLETION_TIME,
			CASE WHEN T4.PRE_RETENTION_NUM IS NOT NULL THEN T4.PRE_RETENTION_NUM ELSE CASE WHEN T6.LOG_NUM > 0 THEN 0 ELSE -1 END END AS PRE_RETENTION_NUM,
			CASE WHEN T5.RETENTION_NUM IS NOT NULL THEN T5.RETENTION_NUM ELSE CASE WHEN T7.LOG_NUM > 0 THEN 0 ELSE -1 END END AS RETENTION_NUM
		FROM
		(
			SELECT
				SUB0.ST_ID
			FROM
				MA_STATION		SUB0
			INNER JOIN
				MA_LINE			SUB1
			ON
					SUB0.LN_ID			= SUB1.LN_ID
			--	AND	SUB1.INVALID_FLAG	= 0
			INNER JOIN
				MA_PROCESS		SUB2
			ON
					SUB1.PROCESS_ID		= SUB2.PROCESS_ID
			--	AND	SUB2.INVALID_FLAG	= 0
			INNER JOIN
				MA_SEIZOU_LINE	SUB3
			ON
					SUB2.SEIZOU_LN_ID	= SUB3.SEIZOU_LN_ID
			--	AND	SUB3.INVALID_FLAG	= 0
				AND	SUB3.PLANT_CD		= l_plant_cd
			--WHERE
			--	SUB0.INVALID_FLAG	= 0
		) T0

		-- 実績
		LEFT OUTER JOIN
		(
			SELECT
				ST_ID,
				MAX(UPD_DATE)			AS UPD_DATE,
				SUM(ACTUAL_THE_DAY_NUM)	AS ACTUAL_NUM
			FROM
				AG_PRODUCT_MNG_DAILY
			WHERE
					ACTUAL_THE_DAY_NUM	>=	0
				AND	ST_ID				!=	CST_ALL_ST_ID
				AND	DATA_DATE			=	l_proc_start_time
			GROUP BY
				ST_ID
		) T2
		ON
			T0.ST_ID	= T2.ST_ID

		-- 計画
		LEFT OUTER JOIN
		(
			SELECT
				ST_ID,
				MAX(UPD_DATE)	AS UPD_DATE,
				SUM(PLAN_NUM)	AS PLAN_NUM
			FROM
			(
				-- 計画(当日)
				SELECT
					ST_ID,
					MAX(UPD_DATE)			AS UPD_DATE,
					SUM(PLAN_THE_DAY_NUM)	AS PLAN_NUM
				FROM
					AG_PRODUCT_MNG_DAILY
				WHERE
						PLAN_THE_DAY_NUM	>=	0
					AND	ST_ID				!=	CST_ALL_ST_ID
					AND	DATA_DATE			=	l_proc_start_time
				GROUP BY
					ST_ID

				UNION ALL

				-- 計画(前日)
				SELECT
					ST_ID,
					MAX(UPD_DATE)					AS UPD_DATE,
					SUM(PLAN_BEFORE_THE_DAY_NUM)	AS PLAN_NUM
				FROM
					AG_PRODUCT_MNG_DAILY
				WHERE
						PLAN_BEFORE_THE_DAY_NUM	>=	0
					AND	ST_ID					!=	CST_ALL_ST_ID
					AND	DATA_DATE				=	l_proc_start_time
				GROUP BY
					ST_ID

				UNION ALL

				-- 計画(前々日以前)
				SELECT
					ST_ID,
					MAX(UPD_DATE)					AS UPD_DATE,
					SUM(PLAN_BEFORE_TWO_DAYS_NUM)	AS PLAN_NUM
				FROM
					AG_PRODUCT_MNG_DAILY
				WHERE
						PLAN_BEFORE_TWO_DAYS_NUM	>=	0
					AND	ST_ID						!=	CST_ALL_ST_ID
					AND	DATA_DATE					=	l_proc_start_time
				GROUP BY
					ST_ID
			) SUB
			GROUP BY
				ST_ID
		) T3
		ON
			T0.ST_ID	= T3.ST_ID

		-- 前滞留
		LEFT OUTER JOIN
		(
			SELECT
				SUB0.N_ST_ID			AS ST_ID,
				MAX(SUB0.MODIFIED_ON)	AS UPD_DATE,
				COUNT(*)				AS PRE_RETENTION_NUM
			FROM
			(
				SELECT
					SUB00.*
				FROM
					TR_ST_TM_INFO SUB00
				WHERE
					EXISTS (
						SELECT
							1
						FROM
							TR_ST_TM_INFO SUB01
						WHERE
								SUB00.SASIZU_NO	= SUB01.SASIZU_NO
							AND	SUB00.SUB_NO	= SUB01.SUB_NO
							AND	SUB00.SAGYO_SEQ	= SUB01.SAGYO_SEQ
							AND	SUB00.ST_ID		= SUB01.ST_ID
							AND	SUB00.END_TIME	= SUB01.END_TIME
						GROUP BY
							SUB01.SASIZU_NO,
							SUB01.SUB_NO,
							SUB01.SAGYO_SEQ,
							SUB01.ST_ID,
							SUB01.END_TIME
						HAVING
							MAX(SUB01.REPAIR_KAISU) = SUB00.REPAIR_KAISU
					)
			) SUB0
			INNER JOIN
				TR_SASIZU_JSK	SUB1
			ON
					SUB0.SASIZU_NO		=	SUB1.SASIZU_NO
				AND	SUB1.SEISAN_JYOTAI	>=	0
				AND	SUB1.SEISAN_JYOTAI	<	90
			INNER JOIN
				MA_STATION	SUB2
			ON
					SUB0.ST_ID			= SUB2.ST_ID
			--	AND	SUB2.INVALID_FLAG	= 0
			INNER JOIN
				MA_STATION	SUB3
			ON
					SUB0.N_ST_ID		= SUB3.ST_ID
			--	AND	SUB3.INVALID_FLAG	= 0
			WHERE
					SUB0.ST_ID	!=	SUB0.N_ST_ID
				AND	SUB0.END_TIME	<=	l_current_datetime
				AND	(
						SUB0.N_START_TIME	IS NULL
					OR	SUB0.N_START_TIME	> l_current_datetime
				)
				AND	(
						SUB0.SAGYO_SEQ	= '0'
					OR	SUB2.LN_ID		= SUB3.LN_ID
				)
			GROUP BY
				SUB0.N_ST_ID
		) T4
		ON
			T0.ST_ID	= T4.ST_ID

		-- 内滞留
		LEFT OUTER JOIN
		(
			SELECT
				T.ST_ID					AS ST_ID,
				MAX(T.UPD_DATE)			AS UPD_DATE,
				SUM(T.RETENTION_NUM)	AS RETENTION_NUM
			FROM
			(
				SELECT
					SUB0.ST_ID				AS ST_ID,
					MAX(SUB0.MODIFIED_ON)	AS UPD_DATE,
					COUNT(*)				AS RETENTION_NUM
				FROM
				(
					SELECT
						SUB00.*
					FROM
						TR_ST_WORK_JSK SUB00
					WHERE
						EXISTS (
							SELECT
								1
							FROM
								TR_ST_WORK_JSK SUB01
							WHERE
									SUB00.SASIZU_NO		= SUB01.SASIZU_NO
								AND	SUB00.SUB_NO		= SUB01.SUB_NO
								AND	SUB00.SAGYO_SEQ		= SUB01.SAGYO_SEQ
								AND	SUB00.ST_ID			= SUB01.ST_ID
								AND	SUB00.WORK_STA_TIME	= SUB01.WORK_STA_TIME
							GROUP BY
								SUB01.SASIZU_NO,
								SUB01.SUB_NO,
								SUB01.SAGYO_SEQ,
								SUB01.ST_ID,
								SUB01.WORK_STA_TIME
							HAVING
								MAX(SUB01.REPAIR_KAISU) = SUB00.REPAIR_KAISU
						)
				) SUB0
				INNER JOIN
					TR_SASIZU_JSK	SUB1
				ON
						SUB0.SASIZU_NO		=	SUB1.SASIZU_NO
					AND	SUB1.SEISAN_JYOTAI	>=	0
					AND	SUB1.SEISAN_JYOTAI	<	90
				WHERE
						SUB0.WORK_STA_TIME	<=	l_current_datetime
					AND	(
							SUB0.WORK_END_TIME	IS NULL
						OR	SUB0.WORK_END_TIME	> l_current_datetime
					)
				GROUP BY
					SUB0.ST_ID

				UNION ALL

				SELECT
					SUB0.N_ST_ID			AS ST_ID,
					MAX(SUB0.MODIFIED_ON)	AS UPD_DATE,
					COUNT(*)				AS RETENTION_NUM
				FROM
				(
					SELECT
						SUB00.*
					FROM
						TR_ST_TM_INFO SUB00
					WHERE
						EXISTS (
							SELECT
								1
							FROM
								TR_ST_TM_INFO SUB01
							WHERE
									SUB00.SASIZU_NO	= SUB01.SASIZU_NO
								AND	SUB00.SUB_NO	= SUB01.SUB_NO
								AND	SUB00.SAGYO_SEQ	= SUB01.SAGYO_SEQ
								AND	SUB00.ST_ID		= SUB01.ST_ID
								AND	SUB00.END_TIME	= SUB01.END_TIME
							GROUP BY
								SUB01.SASIZU_NO,
								SUB01.SUB_NO,
								SUB01.SAGYO_SEQ,
								SUB01.ST_ID,
								SUB01.END_TIME
							HAVING
								MAX(SUB01.REPAIR_KAISU) = SUB00.REPAIR_KAISU
						)
				) SUB0
				INNER JOIN
					TR_SASIZU_JSK	SUB1
				ON
						SUB0.SASIZU_NO		=	SUB1.SASIZU_NO
					AND	SUB1.SEISAN_JYOTAI	>=	0
					AND	SUB1.SEISAN_JYOTAI	<	90
				WHERE
						SUB0.ST_ID		=	SUB0.N_ST_ID
					AND	SUB0.END_TIME	<=	l_current_datetime
					AND	(
							SUB0.N_START_TIME	IS NULL
						OR	SUB0.N_START_TIME	> l_current_datetime
					)
				GROUP BY
					SUB0.N_ST_ID
			) T
			GROUP BY
				T.ST_ID
		) T5
		ON
			T0.ST_ID	= T5.ST_ID

		-- ステーション間トレースログ数
		LEFT OUTER JOIN
		(
			SELECT
				N_ST_ID		AS ST_ID,
				COUNT(*)	AS LOG_NUM
			FROM
				TR_ST_TM_INFO
			GROUP BY
				N_ST_ID
		) T6
		ON
			T0.ST_ID	= T6.ST_ID

		-- ステーショントレースログ数
		LEFT OUTER JOIN
		(
			SELECT
				ST_ID,
				COUNT(*)	AS LOG_NUM
			FROM
				TR_ST_WORK_JSK
			GROUP BY
				ST_ID
		) T7
		ON
			T0.ST_ID	= T7.ST_ID

		ORDER BY
			T0.ST_ID
	;

	OPENFLG_GET_DATA		int;	-- カーソルオープン状態


	--------------------------------------------------
	-- ステーション予定/実績/計画(現状)
	--------------------------------------------------
	CUR_AG_ST_WORK_CURRENT	CURSOR FOR
		SELECT
			  *
		FROM
			AG_ST_WORK_CURRENT
		WHERE
			ST_ID	= l_st_id
		FOR UPDATE NOWAIT
	;

	OPENFLG_AG_ST_WORK_CURRENT		int;	-- カーソルオープン状態
	REC_AG_ST_WORK_CURRENT			AG_ST_WORK_CURRENT%ROWTYPE;

BEGIN
	----------------------------------------------------------------------------
	--						初期処理
	----------------------------------------------------------------------------
	raise info 'Start Function [%]', clock_timestamp()::timestamp;

	-- 共通変数初期化
	l_err_pnt		:= RTRIM(cst_MY_PRG) || '_S001';

	-- 共通出力パラメータ初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
	o_ret_cd	:= RET_OK;
	o_sqlerr	:= ' ';
	o_errmsg	:= ' ';
	o_errpnt	:= ' ';

	-- 関数実行日時
	l_exec_datetime := clock_timestamp();

	-- 集計開始/終了日時補正
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
	IF (i_from_time IS NULL) OR (l_exec_datetime < i_from_time) THEN
		i_from_time := l_exec_datetime;
	END IF;
	IF (i_to_time IS NULL) OR (l_exec_datetime < i_to_time) OR (i_from_time > i_to_time) THEN
		i_to_time := l_exec_datetime;
	END IF;

	-- ローカル変数初期化
	OPENFLG_MA_PLANT := CST_FALSE;
	OPENFLG_GET_DATA := CST_FALSE;
	OPENFLG_AG_ST_WORK_CURRENT := CST_FALSE;

	----------------------------------------------------------------------------
	-- メイン処理
	----------------------------------------------------------------------------
	<< MAIN_LOOP >>
	LOOP

		------------------------------------------------------------------------
		-- 工場ごとに稼働開始日時が異なるので、工場マスタで処理を回す
		------------------------------------------------------------------------
		-- 工場マスタを開いているならクローズ
		l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
		IF OPENFLG_MA_PLANT = CST_TRUE THEN
			CLOSE CUR_MA_PLANT;
			OPENFLG_MA_PLANT := CST_FALSE;
		END IF;

		-- 工場マスタをオープン
		l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
		OPEN CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_TRUE;

		<< PLANT_LOOP >>
		LOOP
			-- 工場マスタからフェッチ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_103';
			FETCH CUR_MA_PLANT INTO l_plant_cd, l_running_start_datetime;
			IF FOUND = FALSE THEN
				EXIT PLANT_LOOP;
			END IF;

			IF l_running_start_datetime IS NULL THEN
				-- NULLの場合はデフォルト値をセット
				l_err_pnt := RTRIM(cst_MY_PRG) || '_104';
				l_running_start_datetime = timestamp '0001-03-21 07:00:00';
			END IF;

			-- 処理開始日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_105';
			SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_all;
			<< START_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_106';
				IF i_from_time >= l_proc_start_time_all THEN
					EXIT START_TIME_LOOP;
				END IF;
				l_proc_start_time_all := l_proc_start_time_all + interval '-1 days';
			END LOOP	START_TIME_LOOP;

			-- 処理終了日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_107';
			SELECT l_proc_start_time_all + interval '1 days' + interval '-1 milliseconds' INTO l_proc_end_time_all;
			<< END_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_108';
				IF i_to_time <= l_proc_end_time_all THEN
					EXIT END_TIME_LOOP;
				END IF;
				l_proc_end_time_all := l_proc_end_time_all + interval '1 days';
			END LOOP	END_TIME_LOOP;

			-- 処理開始/終了日時
			l_err_pnt := RTRIM(cst_MY_PRG) || '_109';
			l_proc_start_time := l_proc_start_time_all;
			l_proc_end_time := l_proc_start_time + interval '1 days' + interval '-1 milliseconds';

			<< TIME_LOOP >>
			LOOP
				IF (l_exec_datetime >= l_proc_start_time) AND
				   (l_exec_datetime <= l_proc_end_time)
				THEN
					-- 当日の場合、現在日時は関数実行日時
					l_current_datetime := l_exec_datetime;
				ELSE
					-- 過去の場合、現在日時は処理最終日時
					l_current_datetime := l_proc_end_time;
				END IF;

				-- 各種データ取得を開いているならクローズ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
				IF OPENFLG_GET_DATA = CST_TRUE THEN
					CLOSE CUR_GET_DATA;
					OPENFLG_GET_DATA := CST_FALSE;
				END IF;

				-- 各種データ取得をオープン
				l_err_pnt := RTRIM(cst_MY_PRG) || '_202';
				OPEN CUR_GET_DATA;
				OPENFLG_GET_DATA := CST_TRUE;

				<< GET_DATA >>
				LOOP
					-- 各種データ取得からフェッチ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_203';
					FETCH CUR_GET_DATA INTO l_st_id, l_upd_date, l_schedule_num, l_actual_num, l_plan_num, l_prediction_completion_time, l_plan_completion_time, l_pre_retention_num, l_retention_num;
					IF FOUND = FALSE THEN
						l_err_pnt := RTRIM(cst_MY_PRG) || '_204';
						EXIT GET_DATA;
					END IF;

					------------------------------------------------------------
					-- ステーション予定/実績/計画(現状)に格納
					------------------------------------------------------------
					-- ステーション予定/実績/計画(現状)を開いているならクローズ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_301';
					IF OPENFLG_AG_ST_WORK_CURRENT = CST_TRUE THEN
						CLOSE CUR_AG_ST_WORK_CURRENT;
						OPENFLG_AG_ST_WORK_CURRENT := CST_FALSE;
					END IF;

					l_err_pnt := RTRIM(cst_MY_PRG) || '_302';
					-- ステーション予定/実績/計画(現状)をオープン
					OPEN CUR_AG_ST_WORK_CURRENT;
					OPENFLG_AG_ST_WORK_CURRENT := CST_TRUE;

					l_err_pnt := RTRIM(cst_MY_PRG) || '_303';
					-- ステーション予定/実績/計画(現状)に格納
					FETCH CUR_AG_ST_WORK_CURRENT INTO REC_AG_ST_WORK_CURRENT;
					IF FOUND = FALSE THEN
						-- データがない場合
						l_err_pnt := RTRIM(cst_MY_PRG) || '_304';
						INSERT INTO AG_ST_WORK_CURRENT
						(
							  ST_ID									-- ステーションID
							, UPD_DATE								-- 更新日時
							, SCHEDULE_NUM							-- 予定数
							, ACTUAL_NUM							-- 実績数
							, PLAN_NUM								-- 計画数
							, PREDICTION_COMPLETION_TIME			-- 完了時刻(予測)
							, PLAN_COMPLETION_TIME					-- 完了時刻(計画)
							, PRE_RETENTION_NUM						-- ステーション前の滞留数
							, RETENTION_NUM							-- ステーション内の滞留数
							, INS_PROG								-- 登録プログラム名
							, INS_TIM								-- 登録日時
							, INS_USER_SID							-- 登録ユーザSID
							, UPD_PROG								-- 更新プログラム名
							, UPD_TIM								-- 更新日時
							, UPD_USER_SID							-- 更新ユーザSID
						)
						VALUES
						(
							  l_st_id								-- ステーションID
							, l_upd_date							-- 更新日時
							, l_schedule_num						-- 予定数
							, l_actual_num							-- 実績数
							, l_plan_num							-- 計画数
							, l_prediction_completion_time			-- 完了時刻(予測)
							, l_plan_completion_time				-- 完了時刻(計画)
							, l_pre_retention_num					-- ステーション前の滞留数
							, l_retention_num						-- ステーション内の滞留数
							, cst_MY_PRG							-- 登録プログラム
							, l_exec_datetime						-- 登録日時
							, i_user_sid							-- 登録ユーザSID
							, cst_MY_PRG							-- 更新プログラム
							, l_exec_datetime						-- 更新日時
							, i_user_sid							-- 更新ユーザSID
						);
					ELSE
						l_err_pnt := RTRIM(cst_MY_PRG) || '_305';
						UPDATE
							AG_ST_WORK_CURRENT
						SET
							  UPD_DATE						= l_upd_date					-- 更新日時
							, SCHEDULE_NUM					= l_schedule_num				-- 予定数
							, ACTUAL_NUM					= l_actual_num					-- 実績数
							, PLAN_NUM						= l_plan_num					-- 計画数
							, PREDICTION_COMPLETION_TIME	= l_prediction_completion_time	-- 完了時刻(予測)
							, PLAN_COMPLETION_TIME			= l_plan_completion_time		-- 完了時刻(計画)
							, PRE_RETENTION_NUM				= l_pre_retention_num			-- ステーション前の滞留数
							, RETENTION_NUM					= l_retention_num				-- ステーション内の滞留数
							, UPD_PROG						= cst_MY_PRG					-- 更新プログラム
							, UPD_TIM						= l_exec_datetime				-- 更新日時
							, UPD_USER_SID					= i_user_sid					-- 更新ユーザSID
						WHERE CURRENT OF CUR_AG_ST_WORK_CURRENT;
					END IF;

				END LOOP	GET_DATA;

				-- 次の処理日時を設定
				l_proc_start_time	:= l_proc_start_time + interval '1 days';
				l_proc_end_time		:= l_proc_end_time + interval '1 days';

				-- 処理開始日時が処理終了日時(全体)を超えている場合は処理終了
				IF l_proc_end_time_all < l_proc_start_time THEN
					EXIT TIME_LOOP;
				END IF;

			END LOOP	TIME_LOOP;

		END LOOP	PLANT_LOOP;

		EXIT MAIN_LOOP;
	END LOOP	MAIN_LOOP;

	----------------------------------------------------------------------------
	--						終了処理
	----------------------------------------------------------------------------
	-- カーソルクローズ
	l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
	IF OPENFLG_MA_PLANT = CST_TRUE THEN
		CLOSE CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E002';
	IF OPENFLG_GET_DATA = CST_TRUE THEN
		CLOSE CUR_GET_DATA;
		OPENFLG_GET_DATA := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
	IF OPENFLG_AG_ST_WORK_CURRENT = CST_TRUE THEN
		CLOSE CUR_AG_ST_WORK_CURRENT;
		OPENFLG_AG_ST_WORK_CURRENT := CST_FALSE;
	END IF;

	raise info 'End Function [%]', clock_timestamp()::timestamp;

EXCEPTION WHEN OTHERS THEN
	-- DB例外情報収集
	GET STACKED DIAGNOSTICS rtn_sql_no     = RETURNED_SQLSTATE,
							rtn_sql_msg    = MESSAGE_TEXT,
							rtn_sql_detail = PG_EXCEPTION_DETAIL,
							rtn_sql_hint   = PG_EXCEPTION_HINT,
							rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

	raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
	raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

	o_ret_cd := RET_NG;
	o_sqlerr := substr(rtn_sql_no, 1, 15);
	o_errmsg := substr(rtn_sql_msg, 1, 127);
	o_errpnt := l_err_pnt;

	raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;
