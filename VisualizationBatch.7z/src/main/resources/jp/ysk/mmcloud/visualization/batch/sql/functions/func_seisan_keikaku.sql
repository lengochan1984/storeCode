﻿CREATE or REPLACE FUNCTION func_seisan_keikaku(
	in	i_batch_name	varchar,			-- バッチ処理名称
	in	i_log_type		numeric,			-- ログ種別(開始、および　各バッチ処理の復帰値)
											-- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
	in	i_user_sid		numeric,			-- 登録ユーザSID
	in	i_from_time		timestamp,			-- 集計開始日時(空の場合は当日を対象とする)
	in	i_to_time		timestamp,			-- 集計終了日時(空の場合は当日を対象とする)
	out	o_ret_cd		int,				-- 関数復帰値	RET_OK(= 0):正常終了
	out	o_sqlerr		varchar,			-- ＤＢ異常発生時のエラーコード
	out	o_errmsg		varchar,			-- 異常発生時のエラーメッセージ
	out	o_errpnt		varchar				-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　ライン生産計画作成サービス
--　ソースプログラム名　：　func_seisan_keikaku.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　製品生産計画実績(時間別)を作成する
--
--　履歴
--	Ver.  作成日			作成者		COMMENT
--	1.0   2016/12/15		J.Ito		新規作成
--	1.1   2017/01/05		J.Ito		テーブル”指図追番単位計画”のカラム”削除フラグ”追加対応
--	1.2   2017/02/09		H.Nakamura	計画数手動設定対応
--******************************************************************************
DECLARE
	----------------------------------------------------------------------------
	--						標準定数定義
	----------------------------------------------------------------------------
	-- 戻り値
	RET_OK		CONSTANT int := 0 ;						-- 正常終了コード
	RET_NG		CONSTANT int := -1 ;					-- 異常終了コード
	-- 真偽値
	CST_TRUE	CONSTANT int := 1 ;						-- 真
	CST_FALSE	CONSTANT int := 0 ;						-- 偽

	----------------------------------------------------------------------------
	--						標準変数定義
	----------------------------------------------------------------------------
	cst_MY_PRG	CONSTANT CHAR(32)	 := 'func_seisan_keikaku';				-- プログラム名
	cst_UPD_TIM	CHAR(17) ;													-- 更新時間
	l_err_pnt	CHAR(64) ;													-- エラー発生ポイント
	errbuff		varchar(256);												-- メッセージバッファ

	----------------------------------------------------------------------------
	--						定数定義
	----------------------------------------------------------------------------
	CST_ALL_ln_no				CONSTANT char(20)	:= '-1';	-- ライン番号
	CST_PLANNING_SYSTEM_ENABLE	CONSTANT int		:= 1;		-- 計画系システム導入あり

	----------------------------------------------------------------------------
	--						変数定義
	----------------------------------------------------------------------------
	-- 共通変数
	rtn_sql_no		text;							-- DBエラー情報(エラー番号)
	rtn_sql_msg		text;							-- DBエラー情報(エラーメッセージ)
	rtn_sql_detail	text;							-- DBエラー情報(エラー詳細)
	rtn_sql_hint	text;							-- DBエラー情報(エラーヒント)
	rtn_sql_stack	text;							-- DBエラー情報(エラー発生呼出しスタック)

	-- ローカル変数
	l_exec_datetime				timestamp;			-- 関数実行日時
	l_proc_start_time_all		timestamp;			-- 処理開始日(全体)
	l_proc_end_time_all			timestamp;			-- 処理終了日(全体)
	l_proc_start_time_day		timestamp;			-- 処理開始日(日)
	l_proc_end_time_day			timestamp;			-- 処理終了日(日)
	l_running_start_datetime	timestamp;			-- 稼働開始日時(年度開始日時)
	l_planning_system			int;				-- 計画系システム導入状況
	l_multi_line				boolean;			-- マルチライン対応状況

	l_exec_datetime_tmp			timestamp;			-- 関数実行仮日時
	l_exec_datetime_tmp2		timestamp;			-- 検索期間仮日時

	l_plant_code				char(2);			-- 工場コード
	l_ln_id						numeric;				-- ラインID
	--l_seizou_line_cd			char(5);			-- 製造ラインコード
	l_ln_no					char(20);			-- ライン番号
	l_upd_date					timestamp;			-- 更新日時

	l_seisan_bi					char(8);			-- 生産日
	l_seisan_keikaku			int;				-- 生産計画数
	l_seisan_yotei				int;				-- 生産予定数

	----------------------------------------------------------------------------
	--						カーソル定義
	----------------------------------------------------------------------------
	-- 工場マスタ
	CUR_MST_PLANT	CURSOR FOR
		SELECT
			T0.plant_cd				as plantCode,
			T0.RUNNING_START_DATETIME	as runningStartDatetime
		FROM
			ma_plant	T0
		--LEFT OUTER JOIN
		--	ma_plant_mieruka	T1
		--ON
		--		T1.plant_cd	= T0.plant_cd
		--	AND	T1.INVALID_FLAG	= 0
		--WHERE
		--	T0.INVALID_FLAG = 0
		ORDER BY
			T0.plant_cd
	;
	OPENFLG_MST_PLANT	int;	-- カーソルオープン状態

	-- 製造ラインマスタ
--	CUR_MST_SEIZOU_LINE	CURSOR FOR
--		SELECT
--			T0.SEIZOU_LINE_CD	as seizouLineCd,
--			T0.PLANNING_SYSTEM	as planningSystem,
--			CASE WHEN
--				EXISTS(
--					SELECT
--						*
--					FROM
--						MST_CONVERT_LINE
--					WHERE
--							PLANT_CODE		= T0.PLANT_CODE
--						AND	SEIZOU_LINE_CD	= T0.SEIZOU_LINE_CD
--				)
--			THEN
--				-- 変換テーブルにデータあり = マルチライン非対応
--				FALSE
--			ELSE
--				-- 変換テーブルにデータあり = マルチライン対応
--				TRUE
--			END					as multiLine
--		FROM
--			MST_SEIZOU_LINE T0
--		WHERE
--				T0.PLANT_CODE	= l_plant_code
--			AND	T0.INVALID_FLAG	= 0
--	;

--	OPENFLG_MST_SEIZOU_LINE	int;	-- カーソルオープン状態

	-- MESライン
	CUR_MST_CONVERT_LINE	CURSOR FOR
--		SELECT
--			CASE WHEN
--				l_multi_line = FALSE
--			THEN
--				T0.MES_ln_no
--			ELSE
--				T1.ln_no
--			END	as lineNo
--		FROM
--		(
--			SELECT
--				MST_CONVERT_LINE.MES_ln_no
--			FROM
--				MST_CONVERT_LINE
--			INNER JOIN
--				MST_LINE
--			ON
--					MST_LINE.INVALID_FLAG	= 0
--				AND	MST_LINE.PLANT_CODE		= MST_CONVERT_LINE.PLANT_CODE
--				AND	MST_LINE.ln_no		= MST_CONVERT_LINE.ln_no
--			WHERE
--					MST_CONVERT_LINE.PLANT_CODE		= l_plant_code
--				AND	MST_CONVERT_LINE.SEIZOU_LINE_CD	= l_seizou_line_cd
--		) T0,
--		(
			SELECT
				ln_id,
				ln_no
			FROM
				ma_line
			--WHERE
			--		INVALID_FLAG	= 0
--				AND	PLANT_CODE		= l_plant_code
--				AND	SEIZOU_LINE_CD	= l_seizou_line_cd
--		) T1
		GROUP BY
			ln_id,
			ln_no
	;
	OPENFLG_MST_CONVERT_LINE		int;	-- カーソルオープン状態

	-- 製品計画台数(手動設定)
	CUR_TBL_SEIHIN_PLAN_MANUAL_SETTING	CURSOR FOR
		SELECT
			SUM(PLAN_NUM)
		FROM
			tr_seihin_plan_manual_setting
		WHERE
			--	PLANT_CODE	= l_plant_code
			-- AND	ln_no		= l_ln_no
			ln_id	= l_ln_id
			AND	to_timestamp(to_char(DATA_DATE, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS')	>= l_proc_start_time_day
			AND	to_timestamp(to_char(DATA_DATE, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS')	<= l_proc_end_time_day
			AND	PLAN_NUM	>= 0
	;
	OPENFLG_TBL_SEIHIN_PLAN_MANUAL_SETTING		int;	-- カーソルオープン状態

	------------------------------------------------------------
	-- 格納先
	------------------------------------------------------------
	-- ライン生産計画(アンドン用)
	CUR_TBL_SEISAN_KEIKAKU	CURSOR FOR
		SELECT
		   *
		FROM
			tr_line_seisan_plan	A
		WHERE
				-- A.PLANT_CODE	=	l_plant_code
				A.ln_id			=	l_ln_id
			AND	A.ln_no		=	l_ln_no
			AND	A.SEISAN_BI		= 	l_seisan_bi
		FOR UPDATE NOWAIT
	;
	OPENFLG_TBL_SEISAN_KEIKAKU	int;	-- カーソルオープン状態
	REC_TBL_SEISAN_KEIKAKU		tr_line_seisan_plan%ROWTYPE;

BEGIN
	----------------------------------------------------------------------------
	--						初期処理
	----------------------------------------------------------------------------
	raise info 'Start Function [%]', clock_timestamp()::timestamp;

	-- 共通変数初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S001';

	-- 共通出力パラメータ初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
	o_ret_cd	:= RET_OK;
	o_sqlerr	:= ' ';
	o_errmsg	:= ' ';
	o_errpnt	:= ' ';

	-- 関数実行日時
	l_exec_datetime := clock_timestamp();

	-- 集計開始/終了日時補正
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
	IF i_from_time IS NULL THEN
		i_from_time := l_exec_datetime;
	END IF;
	IF i_to_time IS NULL OR i_from_time > i_to_time THEN
		i_to_time := l_exec_datetime;
	END IF;

	-- ローカル変数初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S004';
	OPENFLG_MST_PLANT := CST_FALSE;
	OPENFLG_MST_CONVERT_LINE := CST_FALSE;
	OPENFLG_TBL_SEIHIN_PLAN_MANUAL_SETTING := CST_FALSE;
	OPENFLG_TBL_SEISAN_KEIKAKU := CST_FALSE;

	----------------------------------------------------------------------------
	-- メイン処理
	----------------------------------------------------------------------------
	<< MAIN_LOOP >>
	LOOP

		------------------------------------------------------------------------
		-- 工場ごとに稼働開始日時が異なるので、工場マスタで処理を回す
		------------------------------------------------------------------------
		-- 工場マスタを開いているならクローズ
		l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
		IF OPENFLG_MST_PLANT = CST_TRUE THEN
			CLOSE CUR_MST_PLANT;
			OPENFLG_MST_PLANT := CST_FALSE;
		END IF;

		-- 工場マスタをオープン
		l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
		OPEN CUR_MST_PLANT;
		OPENFLG_MST_PLANT := CST_TRUE;

		<< PLANT_LOOP >>
		LOOP
			-- 工場マスタからフェッチ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
			FETCH CUR_MST_PLANT INTO l_plant_code, l_running_start_datetime;
			IF FOUND = FALSE THEN
				EXIT PLANT_LOOP;
			END IF;

			-- 工場稼働日時を設定
			IF l_running_start_datetime IS NULL THEN
				-- NULLの場合はデフォルト値をセット
				l_err_pnt := RTRIM(cst_MY_PRG) || '_202';
				l_running_start_datetime = timestamp '0001-03-21 07:00:00';
			END IF;

			   -- 処理開始日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_203';
			SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_all;
			<< START_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_204';
				IF i_from_time >= l_proc_start_time_all THEN
					EXIT START_TIME_LOOP;
				END IF;
				l_proc_start_time_all := l_proc_start_time_all + interval '-1 days';
			END LOOP	START_TIME_LOOP;

			-- 処理終了日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_205';
			SELECT l_proc_start_time_all + interval '1 days' + interval '-1 milliseconds' INTO l_proc_end_time_all;
			<< END_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_206';
				   IF i_to_time <= l_proc_end_time_all THEN
					EXIT END_TIME_LOOP;
				END IF;
				l_proc_end_time_all := l_proc_end_time_all + interval '1 days';
			END LOOP	END_TIME_LOOP;

			------------------------------------------------------------------------
			-- 計画系システム導入状況で計画値の取得先が変わるので、
			-- 製造ラインマスタで回す
			------------------------------------------------------------------------
			-- 製造ラインマスタを開いているならクローズ
--			l_err_pnt := RTRIM(cst_MY_PRG) || '_301';
--			IF OPENFLG_MST_SEIZOU_LINE = CST_TRUE THEN
--				CLOSE CUR_MST_SEIZOU_LINE;
--				OPENFLG_MST_SEIZOU_LINE := CST_FALSE;
--			END IF;

			-- 製造ラインマスタをオープン
--			l_err_pnt := RTRIM(cst_MY_PRG) || '_302';
--			OPEN CUR_MST_SEIZOU_LINE;
--			OPENFLG_MST_SEIZOU_LINE := CST_TRUE;

--			<< SEIZOU_LINE_LOOP >>
--			LOOP
				-- 製造ラインマスタからフェッチ
--				l_err_pnt := RTRIM(cst_MY_PRG) || '_303';
--				FETCH CUR_MST_SEIZOU_LINE INTO l_seizou_line_cd, l_planning_system, l_multi_line;
--				IF FOUND = FALSE THEN
--					EXIT SEIZOU_LINE_LOOP;
--				END IF;

				-- MESラインを開いているならクローズ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_401';
				IF OPENFLG_MST_CONVERT_LINE = CST_TRUE THEN
					CLOSE CUR_MST_CONVERT_LINE;
					OPENFLG_MST_CONVERT_LINE := CST_FALSE;
				END IF;

				-- MESラインをオープン
				l_err_pnt := RTRIM(cst_MY_PRG) || '_402';
				OPEN CUR_MST_CONVERT_LINE;
				OPENFLG_MST_CONVERT_LINE := CST_TRUE;

				<< MST_CONVERT_LINE_LOOP >>
				LOOP
					l_err_pnt := RTRIM(cst_MY_PRG) || '_403';
					FETCH CUR_MST_CONVERT_LINE INTO l_ln_id, l_ln_no;
					IF FOUND = FALSE THEN
						-- 該当データがない場合
						EXIT MST_CONVERT_LINE_LOOP;
					END IF;

					-- 処理開始/終了(日)日時
					l_err_pnt := RTRIM(cst_MY_PRG) || '_404';
					l_proc_start_time_day := l_proc_start_time_all;
					l_proc_end_time_day := l_proc_start_time_day + interval '1 days' + interval '-1 milliseconds';

					<< TIME_DAY_LOOP >>
					LOOP
						IF l_planning_system = CST_PLANNING_SYSTEM_ENABLE THEN
							-- 計画系システム導入ありの場合

							----------------------------------------------------------------------------
							-- ライン計画数取得
							----------------------------------------------------------------------------
							-- 生産日を取得
							l_err_pnt := RTRIM(cst_MY_PRG) || '_501';
							l_seisan_bi	:=	to_char(l_proc_start_time_day, 'YYYYMMDD');

							-- 予定数を取得する際の、最終日時を取得
							l_err_pnt := RTRIM(cst_MY_PRG) || '_502';
							l_exec_datetime_tmp	:=	l_proc_end_time_day;
							IF l_exec_datetime_tmp >=	l_exec_datetime THEN
								l_exec_datetime_tmp	:=	l_exec_datetime;
							END IF;
							-- 開始ラインを検索する際の、最終日を取得
							l_err_pnt := RTRIM(cst_MY_PRG) || '_503';
							l_exec_datetime_tmp2	:=	l_proc_end_time_day + interval '-15 days';

							l_seisan_keikaku	:=	-1;
							l_seisan_yotei		:=	-1;
							-- 生産計画数/予定数を取得
							l_err_pnt := RTRIM(cst_MY_PRG) || '_504';
							SELECT INTO
									l_seisan_keikaku,
									l_seisan_yotei

									sum(case when c.end_date >= l_proc_start_time_day and c.end_date <=	l_proc_end_time_day then 1 else 0 end) as seisan_keikaku,
									sum(case when c.end_date >= l_proc_start_time_day and c.end_date <	l_exec_datetime_tmp then 1 else 0 end) as seisan_yotei
-- 							FROM
-- 								tbl_seihin_plan		c
-- 							LEFT OUTER JOIN
-- 								tr_product_trc	a1
-- 							ON
-- 									c.sasizu_no	= a1.sasizu_no
-- 								AND	c.sub_no	= a1.sub_no
 							FROM
 								tr_product_trc		c
							LEFT OUTER JOIN
								tr_line_work_jsk	a2
							ON
									c.sasizu_no		= a2.sasizu_no
								AND	c.sub_no		= a2.sub_no
								AND	c.ln_no		= a2.ln_no,
								(
									SELECT
										a.plant_cd,
										a.sasizu_no,
										a.sub_no
									FROM
--										tbl_seihin_plan		a
										tr_product_trc		a
									WHERE
										a.plant_cd	=	l_plant_code
									AND	a.ln_no		=	l_ln_no
									AND	a.end_date		>=	l_exec_datetime_tmp2
									AND	a.end_date		<=	l_proc_end_time_day
									AND	a.invalid_flag	=	0
									GROUP BY
										a.plant_cd,
										a.sasizu_no,
										a.sub_no
								)	d
							WHERE
--									(a1.seisan_jyotai	is null	or (a1.actual_end_datetime	>=	l_proc_start_time_day	and a1.actual_end_datetime	<=	l_proc_end_time_day))
--								AND	(a2.sagyou_jyotai	is null	or (a2.end_datetime			>=	l_proc_start_time_day	and a2.end_datetime			<=	l_proc_end_time_day))
									c.plant_cd	=	d.plant_cd
								AND	c.sasizu_no		=	d.sasizu_no
								AND	c.sub_no		=	d.sub_no
								AND	c.end_date		>=	l_proc_start_time_day
								AND	c.end_date		<=	l_proc_end_time_day
--								AND	(c.ln_no = 'INSPEX' AND c.station_no = 'ST01')	-- note:(電)特殊仕様 最終ライン/STが特定されている
								AND	(c.ln_no = 'INSPEX')	-- note:(電)特殊仕様 最終ラインが特定されている
								AND	c.invalid_flag	=	0
							GROUP BY
								c.plant_cd
							;
							-- データが存在しない場合、計画値・予定値を無効値(NULL)にする
							l_err_pnt := RTRIM(cst_MY_PRG) || '_505';
							IF FOUND = FALSE OR l_seisan_keikaku is NULL OR l_seisan_keikaku = -1 THEN
								l_err_pnt := RTRIM(cst_MY_PRG) || '_506';
								l_seisan_keikaku	:=	NULL;
								l_seisan_yotei		:=	NULL;

							ELSIF l_seisan_keikaku is NULL OR l_seisan_keikaku = -1 THEN
								l_err_pnt := RTRIM(cst_MY_PRG) || '_507';
								l_seisan_keikaku	:=	0;
								l_seisan_yotei		:=	0;

							END IF;

						ELSE
							-- 計画系システム導入なしの場合

							-- 製品計画台数(手動設定)を開いているならクローズ
							l_err_pnt := RTRIM(cst_MY_PRG) || '_601';
							IF OPENFLG_TBL_SEIHIN_PLAN_MANUAL_SETTING = CST_TRUE THEN
								CLOSE CUR_TBL_SEIHIN_PLAN_MANUAL_SETTING;
								OPENFLG_TBL_SEIHIN_PLAN_MANUAL_SETTING := CST_FALSE;
							END IF;

							-- 製品計画台数(手動設定)をオープン
							l_err_pnt := RTRIM(cst_MY_PRG) || '_602';
							OPEN CUR_TBL_SEIHIN_PLAN_MANUAL_SETTING;
							OPENFLG_TBL_SEIHIN_PLAN_MANUAL_SETTING := CST_TRUE;

							-- 製品計画台数(手動設定)からフェッチ
							l_err_pnt := RTRIM(cst_MY_PRG) || '_603';
							FETCH CUR_TBL_SEIHIN_PLAN_MANUAL_SETTING INTO l_seisan_keikaku;
							IF FOUND = FALSE THEN
								l_seisan_keikaku := null;
							END IF;

							-- 生産日を設定
							l_err_pnt := RTRIM(cst_MY_PRG) || '_604';
							l_seisan_bi	:=	to_char(l_proc_start_time_day, 'YYYYMMDD');

							-- 計画系システムなしの場合、生産予定数はnull固定
							l_seisan_yotei := NULL;

						END IF;

						-- ライン生産計画(アンドン用)にデータがあるか確認
						l_err_pnt := RTRIM(cst_MY_PRG) || '_701';
						IF OPENFLG_TBL_SEISAN_KEIKAKU = CST_TRUE THEN
							CLOSE CUR_TBL_SEISAN_KEIKAKU;
							OPENFLG_TBL_SEISAN_KEIKAKU := CST_FALSE;
						END IF;

						-- ライン生産計画(アンドン用)をオープン
						l_err_pnt := RTRIM(cst_MY_PRG) || '_702';
						OPEN CUR_TBL_SEISAN_KEIKAKU;
						OPENFLG_TBL_SEISAN_KEIKAKU := CST_TRUE;

						l_err_pnt := RTRIM(cst_MY_PRG) || '_703';
						FETCH CUR_TBL_SEISAN_KEIKAKU INTO REC_TBL_SEISAN_KEIKAKU;
						IF FOUND = FALSE THEN
							-- 製品生産計画実績(ライン生産計画(アンドン用)に格納
							l_err_pnt := RTRIM(cst_MY_PRG) || '_704';
							INSERT INTO tr_line_seisan_plan
							(
								  created_on		--登録日時
								, created_by		--登録者
								, modified_on		--更新日時
								, modified_by		--更新者
								, SEISAN_BI			--生産日
								--, PLANT_CODE		--工場コード
								, ln_id				--ラインID
								, ln_no				--ライン番号
								, SEISAN_KEIKAKU	--生産計画数
								, SEISAN_YOTEI		--生産予定数
								, spare_num1		--数字予備1
								, spare_num2		--数字予備2
								, spare_num3		--数字予備3
								, spare_text1		--文字予備1
								, spare_text2		--文字予備2
								, spare_text3		--文字予備3
								, INS_PROG			--登録プログラム名
								, INS_TIM			--登録日時
								, INS_USER_SID		--登録ユーザSID
								, UPD_PROG			--更新プログラム名
								, UPD_TIM			--更新日時
								, UPD_USER_SID		--更新ユーザSID
							)
							VALUES
							(
								  null				-- 登録日時
								, null				-- 登録者
								, null				-- 更新日時
								, null				-- 更新者
								, l_seisan_bi		-- 生産日
								--, l_plant_code		-- 工場コード
								, l_ln_id			-- ラインID
								, l_ln_no			-- ライン番号
								, l_seisan_keikaku	-- 生産計画数
								, l_seisan_yotei	-- 生産予定数
								, null				-- 数字予備1
								, null				-- 数字予備2
								, null				-- 数字予備3
								, null				-- 文字予備1
								, null				-- 文字予備2
								, null				--文字予備3
								, cst_MY_PRG		-- 登録プログラム名
								, l_exec_datetime	-- 登録日時
								, i_user_sid		-- 登録ユーザSID
								, cst_MY_PRG		-- 更新プログラム名
								, l_exec_datetime	-- 更新日時
								, i_user_sid		-- 更新ユーザSID
							);
						ELSE
							-- ライン生産計画(アンドン用)を更新
							l_err_pnt := RTRIM(cst_MY_PRG) || '_705';
							UPDATE tr_line_seisan_plan SET
								   SEISAN_BI		= l_seisan_bi			-- 生産日
								 , SEISAN_KEIKAKU	= l_seisan_keikaku		-- 生産計画数
								 , SEISAN_YOTEI		= l_seisan_yotei		-- 生産予定数
								 , UPD_PROG			= cst_MY_PRG			-- 更新プログラム
								 , UPD_TIM			= l_exec_datetime		-- 更新日時
								 , UPD_USER_SID		= i_user_sid			-- 更新ユーザSID
							WHERE CURRENT OF CUR_TBL_SEISAN_KEIKAKU;
						END IF;

						-- 次の処理日時(日)を設定
						l_err_pnt := RTRIM(cst_MY_PRG) || '_706';
						l_proc_start_time_day	:= l_proc_start_time_day + interval '1 days';
						l_proc_end_time_day		:= l_proc_end_time_day + interval '1 days';

						-- 処理開始日時(日)が処理終了日時(全体)を超えている場合は処理終了
						l_err_pnt := RTRIM(cst_MY_PRG) || '_707';
						IF l_proc_end_time_all < l_proc_start_time_day THEN
							EXIT TIME_DAY_LOOP;
						END IF;

					END LOOP	TIME_DAY_LOOP;
				END LOOP	MST_CONVERT_LINE_LOOP;

			--END LOOP	SEIZOU_LINE_LOOP;

		END LOOP	PLANT_LOOP;

		EXIT MAIN_LOOP;
	END LOOP	MAIN_LOOP;

	----------------------------------------------------------------------------
	--						終了処理
	----------------------------------------------------------------------------
	-- カーソルクローズ
	l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
	IF OPENFLG_MST_PLANT = CST_TRUE THEN
		CLOSE CUR_MST_PLANT;
		OPENFLG_MST_PLANT := CST_FALSE;
	END IF;

--	l_err_pnt := RTRIM(cst_MY_PRG) || '_E002';
--	IF OPENFLG_MST_SEIZOU_LINE = CST_TRUE THEN
--		CLOSE CUR_MST_SEIZOU_LINE;
--		OPENFLG_MST_SEIZOU_LINE := CST_FALSE;
--	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
	IF OPENFLG_MST_CONVERT_LINE = CST_TRUE THEN
		CLOSE CUR_MST_CONVERT_LINE;
		OPENFLG_MST_CONVERT_LINE := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E004';
	IF OPENFLG_TBL_SEIHIN_PLAN_MANUAL_SETTING = CST_TRUE THEN
		CLOSE CUR_TBL_SEIHIN_PLAN_MANUAL_SETTING;
		OPENFLG_TBL_SEIHIN_PLAN_MANUAL_SETTING := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E005';
	IF OPENFLG_TBL_SEISAN_KEIKAKU = CST_TRUE THEN
		CLOSE CUR_TBL_SEISAN_KEIKAKU;
		OPENFLG_TBL_SEISAN_KEIKAKU := CST_FALSE;
	END IF;

	raise info 'End Function [%]', clock_timestamp()::timestamp;

EXCEPTION WHEN OTHERS THEN
	-- DB例外情報収集
	GET STACKED DIAGNOSTICS rtn_sql_no	   = RETURNED_SQLSTATE,
							rtn_sql_msg    = MESSAGE_TEXT,
							rtn_sql_detail = PG_EXCEPTION_DETAIL,
							rtn_sql_hint   = PG_EXCEPTION_HINT,
							rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

	raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
	raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

	o_ret_cd := RET_NG;
	o_sqlerr := substr(rtn_sql_no, 1, 15);
	o_errmsg := substr(rtn_sql_msg, 1, 127);
	o_errpnt := l_err_pnt;

	raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;