﻿CREATE OR REPLACE FUNCTION get_line_name(
    character,
    character)
  RETURNS text AS
$BODY$
DECLARE
	RET_NAME varchar(128);			-- ライン名
BEGIN
    RET_NAME := ($2); --初期値設定

	SELECT 
	    ma_line.ln_nm
	INTO RET_NAME
	FROM
	    ma_line 
	--INNER JOIN mst_line_group_name ON mst_line_group_name.plant_code = mst_line_group.plant_code
	--AND mst_line_group_name.line_group_no = mst_line_group.line_group_no
	WHERE
		ma_line.ln_no = ($2);
	    --mst_line_group.plant_code = ($1)
	--AND mst_line_group.line_no = ($2)
    --AND mst_line_group.single_line_flag = 1;

	IF RET_NAME IS NULL OR RET_NAME = '' THEN
	    RET_NAME := ($2);
	END IF;
	
	RETURN RET_NAME;
	
EXCEPTION WHEN OTHERS THEN
    RETURN RET_NAME;
END;
$BODY$
  LANGUAGE plpgsql;
