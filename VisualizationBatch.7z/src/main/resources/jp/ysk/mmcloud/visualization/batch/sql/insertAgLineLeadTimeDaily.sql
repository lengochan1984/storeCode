WITH
    val AS (
        SELECT
            (   (
				/*lnId*/,
				/*sasizuNo*/,
				/*subNo*/,
				/*dataDate*/,
				/*plantCd*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*processCd*/,
				/*processNm*/,
				/*lnNo*/,
				/*lnNm*/,
				/*leadTime*/,
				/*insProg*/,
				/*insTim*/,
				/*insUserSid*/,
				/*updProg*/,
				/*updTim*/,
				/*updUserSid*/
                )::ag_line_lead_time_daily).*
    ),

    upd AS (
        UPDATE
            ag_line_lead_time_daily
        SET
			plant_cd			= /*plantCd*/,
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
			process_cd			= /*processCd*/,
			process_nm			= /*processNm*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			lead_time			= CAST(/*leadTime*/ AS bigint),
			ins_prog			= /*insProg*/,
			ins_tim				= CAST(/*insTim*/ AS timestamp),
			ins_user_sid		= CAST(/*insUserSid*/ AS integer),
			upd_prog			= /*updProg*/,
			upd_tim				= CAST(/*updTim*/ AS timestamp),
			upd_user_sid		= CAST(/*updUserSid*/ AS integer)
        FROM
            val
        WHERE
            ag_line_lead_time_daily.ln_id		= /*lnId*/
        AND ag_line_lead_time_daily.sasizu_no	= /*sasizuNo*/
        AND ag_line_lead_time_daily.sub_no		= /*subNo*/
        AND ag_line_lead_time_daily.data_date	= /*dataDate*/

        RETURNING
            ag_line_lead_time_daily.ln_id,
            ag_line_lead_time_daily.sasizu_no,
            ag_line_lead_time_daily.sub_no,
            ag_line_lead_time_daily.data_date
    )

INSERT INTO
    ag_line_lead_time_daily
SELECT
    *
FROM
    val
WHERE
    (ln_id, sasizu_no, sub_no, data_date)
        NOT IN (SELECT ln_id, sasizu_no, sub_no, data_date FROM upd);
