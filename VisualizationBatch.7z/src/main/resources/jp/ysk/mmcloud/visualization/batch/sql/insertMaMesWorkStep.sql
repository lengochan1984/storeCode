WITH
	val AS (
		SELECT
			(	(
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*invalidFlag*/,
				/*createDate*/,
				/*jobPtnId*/,
				/*jobPtnName*/,
				/*lnId*/,
				/*procManId*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
				'insert-MA_MES_WORK_STEP',
				now(),
				0,
				'insert-MA_MES_WORK_STEP',
				now(),
				0
				)::MA_MES_WORK_STEP).*
	),

	upd AS (
		UPDATE
			MA_MES_WORK_STEP
		SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			invalid_flag		= /*invalidFlag*/,
			create_date			= CAST(/*createDate*/ AS timestamp),
			job_ptn_name		= /*jobPtnName*/,
			ln_id				= CAST(/*lnId*/ AS numeric),
			proc_man_id			= CAST(/*procManId*/ AS numeric),
			spare_num1			= CAST(/*spareNum1*/ AS numeric),
			spare_num2			= CAST(/*spareNum2*/ AS numeric),
			spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-MA_MES_WORK_STEP',
			upd_tim 			= now(),
			upd_user_sid		= 0
		FROM
			val
		WHERE
			MA_MES_WORK_STEP.job_ptn_id	 = /*jobPtnId*/

		RETURNING
			MA_MES_WORK_STEP.job_ptn_id
	)

INSERT INTO
	MA_MES_WORK_STEP
SELECT
	*
FROM
	val
WHERE
	(job_ptn_id)
		NOT IN (SELECT job_ptn_id FROM upd);
