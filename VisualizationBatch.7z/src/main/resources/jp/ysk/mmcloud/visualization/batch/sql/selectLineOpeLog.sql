SELECT
    CREATED_ON,
    CREATED_BY,
    COALESCE(MODIFIED_ON, CREATED_ON) AS MODIFIED_ON,
    COALESCE(MODIFIED_BY, CREATED_BY) AS MODIFIED_BY,
    LN_ID,
    OPE_KIND,
    START_TIME,
    END_TIME,
    TIME_DIFF,
    ST_NO,
    SYAIN_NO,
    PLANT_CD,
    SEIZOU_LN_CD,
    SEIZOU_LN_NM,
    PROCESS_CD,
    PROCESS_NM,
    LN_NO,
    LN_NM,
    SPARE_NUM1,
    SPARE_NUM2,
    SPARE_NUM3,
    SPARE_TEXT1,
    SPARE_TEXT2,
    SPARE_TEXT3

FROM
    TR_LINE_OPE_LOG

/*BEGIN*/
WHERE
    /*IF addDatetime != null */
        (CREATED_ON >= /*addDatetime*/ AND MODIFIED_ON is null)
    OR  MODIFIED_ON >= /*addDatetime*/
    /*END*/
/*END*/
ORDER BY
    COALESCE(MODIFIED_ON, CREATED_ON)
