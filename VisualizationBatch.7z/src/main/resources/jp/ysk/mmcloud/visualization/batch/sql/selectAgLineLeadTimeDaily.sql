SELECT
    ln_id,
    sasizu_no,
    sub_no,
    data_date,
    plant_cd,
    seizou_ln_cd,
    seizou_ln_nm,
    process_cd,
    process_nm,
    ln_no,
    ln_nm,
    lead_time,
    ins_prog,
    ins_tim,
    ins_user_sid,
    upd_prog,
    upd_tim,
    upd_user_sid

FROM
    ag_line_lead_time_daily

/*BEGIN*/
WHERE
    /*IF addDatetime != null*/
        (ins_tim >= /*addDatetime*/ AND upd_tim is null)
    OR  upd_tim >= /*addDatetime*/
    /*END*/
/*END*/

ORDER BY
    COALESCE(upd_tim, ins_tim)
