CREATE or REPLACE FUNCTION func_plan_mng_hourly(
    in		i_batch_name	varchar,			-- バッチ処理名称
    in		i_log_type			numeric,			-- ログ種別(開始、および　各バッチ処理の復帰値)
                                                            -- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
    in		i_user_sid			numeric,			-- 登録ユーザSID
    in		i_from_time		timestamp,		-- 集計開始日時(空の場合は当日を対象とする)
    in		i_to_time			timestamp,		-- 集計終了日時(空の場合は当日を対象とする)
    out	o_ret_cd			int,					-- 関数復帰値	RET_OK(= 0):正常終了
    out	o_sqlerr				varchar,			-- ＤＢ異常発生時のエラーコード
    out	o_errmsg			varchar,			-- 異常発生時のエラーメッセージ
    out	o_errpnt			varchar			-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　製品生産計画実績(時間別)-計画台数取得サービス
--　ソースプログラム名　：　func_plan_mng_hourly.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　製品生産計画実績(時間別)の計画台数を算出する
--
--　履歴
--  Ver.  作成日				作成者				COMMENT
--  1.0   2016/12/19	J.Ito					新規作成
--******************************************************************************
DECLARE
    ----------------------------------------------------------------------------
    --						標準定数定義
    ----------------------------------------------------------------------------
    -- 戻り値
    RET_OK			CONSTANT int :=	0 ;					-- 正常終了コード
    RET_NG		CONSTANT int :=	-1 ;					-- 異常終了コード
    -- 真偽値
    CST_TRUE		CONSTANT int := 1 ;					-- 真
    CST_FALSE	CONSTANT int := 0 ;					-- 偽

    ----------------------------------------------------------------------------
    --						標準変数定義
    ----------------------------------------------------------------------------
    cst_MY_PRG	CONSTANT CHAR(32)	 := 'func_plan_mng_hourly';
                                                                            -- プログラム名
    cst_UPD_TIM	CHAR(17) ;									-- 更新時間
    l_err_pnt		CHAR(64) ;									-- エラー発生ポイント
    errbuff			varchar(256);								-- メッセージバッファ

    ----------------------------------------------------------------------------
    --						定数定義
    ----------------------------------------------------------------------------
    CST_ALL_LINE_NO		CONSTANT char(20)	:= '-1';
                                                                            -- ライン番号
    CST_ALL_STATION_NO	CONSTANT char(8)	:= '-1';
                                                                            -- ステーション番号

    ----------------------------------------------------------------------------
    --						変数定義
    ----------------------------------------------------------------------------
    -- 共通変数
    rtn_sql_no			text;							-- DBエラー情報(エラー番号)
    rtn_sql_msg		text;							-- DBエラー情報(エラーメッセージ)
    rtn_sql_detail		text;							-- DBエラー情報(エラー詳細)
    rtn_sql_hint		text;							-- DBエラー情報(エラーヒント)
    rtn_sql_stack		text;							-- DBエラー情報(エラー発生呼出しスタック)

    -- ローカル変数
    l_exec_datetime				timestamp;			-- 関数実行日時
    l_proc_start_time				timestamp;			-- 処理開始日
    l_proc_end_time				timestamp;			-- 処理終了日
    l_proc_start_time_all			timestamp;			-- 処理開始日(全体)
    l_proc_end_time_all			timestamp;			-- 処理終了日(全体)
    l_proc_start_time_day		timestamp;			-- 処理開始日(日)
    l_proc_end_time_day			timestamp;			-- 処理終了日(日)
    l_running_start_datetime	timestamp;			-- 稼働開始日時(年度開始日時)

    l_proc_start_time_today					timestamp;		-- 処理開始日(当日)
    l_proc_end_time_today						timestamp;		-- 処理終了日(当日)
    l_proc_start_time_before_the_day		timestamp;		-- 処理開始日(前日)
    l_proc_end_time_before_the_day		timestamp;		-- 処理終了日(前日)
    l_proc_start_time_before_two_days	timestamp;		-- 処理開始日(前々日以前)
    l_proc_end_time_before_two_days		timestamp;		-- 処理終了日(前々日以前)

    l_plant_code						char(2);			-- 工場コード
    l_plant_code_wk				char(2);			-- 工場コード(work)
    l_seizou_line_cd					char(5);			-- 製造ラインコード
    l_line_no							char(20);			-- ライン番号
    l_station_no						char(8);			-- ステーション番号
    l_model_group_name			varchar(60);		-- 機種群名
    l_model_series_name			varchar(60);		-- シリーズ名
    l_hinmoku_code					char(20);			-- 品目コード
    l_sagyoku							char(8);			-- 作業区
    l_upd_date						timestamp;		-- 更新日時
    l_plan_the_day_num					int;	-- 計画(当日)台数
    l_plan_the_day_value					numeric;	-- 計画(当日)金額
    l_plan_before_the_day_num		int;	-- 計画(前日)台数
    l_plan_before_the_day_value		numeric;	-- 計画(前日)金額
    l_plan_before_two_days_num		int;	-- 計画(前々日以前)台数
    l_plan_before_two_days_value	numeric;	-- 計画(前々日以前)金額

    ----------------------------------------------------------------------------
    --						カーソル定義
    ----------------------------------------------------------------------------
    -- 工場マスタ
	CUR_MST_PLANT	CURSOR FOR
		SELECT
			T0.PLANT_CODE				as plantCode,
			T1.RUNNING_START_DATETIME	as runningStartDatetime
		FROM
			MST_PLANT	T0
		LEFT OUTER JOIN
			MST_PLANT_MIERUKA	T1
		ON
				T1.PLANT_CODE	= T0.PLANT_CODE
			AND	T1.INVALID_FLAG	= 0
		WHERE
			T0.INVALID_FLAG = 0
		ORDER BY
			T0.PLANT_CODE
	;

    OPENFLG_MST_PLANT	int;	-- カーソルオープン状態

    --------------------------------------------------
    -- 実績数
    --------------------------------------------------
    -- 指図追番単位計画　(ステーションごと)
    CUR_TBL_SEIHIN_PLAN_FOR_STATION	CURSOR FOR
    SELECT
        d.seizou_line_cd,											/* 製造ラインコード */
        a.line_no,														/* ラインコード */
        a.station_no,													/* ステーション番号 */
        min(b.sagyoku)		as	sagyoku,						/* 作業区(仮に指図の指定作業区を取得) */
        min(c.vtext6)		as	model_group_name,		/* 機種群名 */
        min(c.vtext8)		as	model_series_name,		/* シリーズ名 */
        c.hinmoku_code,											/* 品目コード */
        /* 計画台数・金額 - (当日) */
        sum(case when a.invalid_flag = 0 and a.initial_end_date  >= l_proc_start_time_today then 1 else 0 end) as today_yotei_num,
        MAX(b.hyojyun_genka) * sum(case when a.invalid_flag = 0 and a.initial_end_date  >= l_proc_start_time_today then 1 else 0 end) as today_yotei_genka,
        /* 計画台数・金額 - (前日) */
        sum(case when a.invalid_flag = 0 and a.initial_end_date >= l_proc_start_time_before_the_day and a.initial_end_date <= l_proc_end_time_before_the_day then 1 else 0 end) as yesterday_yotei_num,
        MAX(b.hyojyun_genka) * sum(case when a.invalid_flag = 0 and a.initial_end_date >= l_proc_start_time_before_the_day and a.initial_end_date <= l_proc_end_time_before_the_day then 1 else 0 end) as yesterday_yotei_genka,
        /* 計画台数・金額 - (前々日以前) */
        sum(case when a.invalid_flag = 0 and a.initial_end_date <  l_proc_start_time_before_the_day then 1 else 0 end) as beforeyesterday_yotei_num,
        MAX(b.hyojyun_genka) * sum(case when a.invalid_flag = 0 and a.initial_end_date < l_proc_start_time_before_the_day then 1 else 0 end) as beforeyesterday_yotei_genka,
        max(a.upd_date)		as	upd_date					/* 最新更新日時 */

    FROM
        (
            SELECT
                x.sasizu_no,
                x.sub_no,
                x.plant_code,
                y.seizou_line_cd,
                x.line_no,
                x.station_no,
                MIN(x.initial_start_date)	AS	initial_start_date,
                MAX(x.initial_end_date)		AS	initial_end_date,
                MIN(x.start_date)				AS	start_date,
                MAX(x.end_date)				AS	end_date,
                MAX(x.upd_date)				AS	upd_date,
                x.invalid_flag						AS	invalid_flag
            FROM
                tbl_seihin_plan				x,
                mst_line						y
            WHERE
                x.end_date		>=	l_proc_start_time
            AND	x.end_date	<=	l_proc_end_time
            AND	x.plant_code	=		y.plant_code
            AND	x.line_no		=		y.line_no
            GROUP BY
                x.sasizu_no,
                x.sub_no,
                x.plant_code,
                y.seizou_line_cd,
                x.line_no,
                x.station_no,
                x.invalid_flag
        )								a

        LEFT OUTER JOIN
            tbl_product_trace_log_wk	a1
        ON
            a.sasizu_no		= a1.sasizu_no
        AND	a.sub_no		= a1.sub_no

        LEFT OUTER JOIN
            tbl_line_trace_log_wk	a2
        ON
            a.sasizu_no		= a2.sasizu_no
        AND	a.sub_no		= a2.sub_no
        AND	a.line_no		= a2.line_no,

        tbl_sashizu_management	b,
        mst_hinmoku					c,
        mst_line							d

    WHERE
        a.plant_code			=		l_plant_code
    AND	a.sasizu_no		=		b.sasizu_no
--    AND	(b.actual_end_date	IS NULL	OR (b.actual_end_date			>=	l_proc_start_time_today	AND	b.actual_end_date			<=	l_proc_end_time_today))
--    AND	(a1.seisan_jyotai		IS NULL	OR (a1.actual_end_datetime	>=	l_proc_start_time_today	AND a1.actual_end_datetime	<=	l_proc_end_time_today))
--    AND	(a2.sagyou_jyotai		IS NULL	OR (a2.end_datetime				>=	l_proc_start_time_today	AND a2.end_datetime			<=	l_proc_end_time_today))
    AND	b.buhin_cd			=	c.hinmoku_code
    AND	a.line_no			=	d.line_no
    GROUP BY
        a.plant_code,
        d.seizou_line_cd,
        a.line_no,
        a.station_no,
        c.hinmoku_code
    ;
    OPENFLG_TBL_SEIHIN_PLAN_FOR_STATION		int;	-- カーソルオープン状態


    -- 指図追番単位計画(ラインごと)
    CUR_TBL_SEIHIN_PLAN_FOR_LINE	CURSOR FOR
    SELECT
        d.seizou_line_cd,											/* 製造ラインコード */
        a.line_no,														/* ラインコード */
        CST_ALL_STATION_NO
                                    as		station_no,				/* ステーション番号 (ライン番号ごとの合計値なので、-1固定) */
        min(b.sagyoku)		as		sagyoku,					/* 作業区(仮に指図の指定作業区を取得) */
        min(c.vtext6)		as		model_group_name,	/* 機種群名 */
        min(c.vtext8)		as		model_series_name,	/* シリーズ名 */
        c.hinmoku_code,											/* 品目コード */
        /* 計画台数・金額 - (当日) */
        sum(case when a.invalid_flag = 0 and a.initial_end_date  >= l_proc_start_time_today then 1 else 0 end) as today_yotei_num,
        MAX(b.hyojyun_genka) * sum(case when a.invalid_flag = 0 and a.initial_end_date  >= l_proc_start_time_today then 1 else 0 end) as today_yotei_genka,
        /* 計画台数・金額 - (前日) */
        sum(case when a.invalid_flag = 0 and a.initial_end_date >= l_proc_start_time_before_the_day and a.initial_end_date <= l_proc_end_time_before_the_day then 1 else 0 end) as yesterday_yotei_num,
        MAX(b.hyojyun_genka) * sum(case when a.invalid_flag = 0 and a.initial_end_date >= l_proc_start_time_before_the_day and a.initial_end_date <= l_proc_end_time_before_the_day then 1 else 0 end) as yesterday_yotei_genka,
        /* 計画台数・金額 - (前々日以前) */
        sum(case when a.invalid_flag = 0 and a.initial_end_date <  l_proc_start_time_before_the_day then 1 else 0 end) as beforeyesterday_yotei_num,
        MAX(b.hyojyun_genka) * sum(case when a.invalid_flag = 0 and a.initial_end_date < l_proc_start_time_before_the_day then 1 else 0 end) as beforeyesterday_yotei_genka,
        max(a.upd_date)		as	upd_date					/* 最新更新日時 */

    FROM
        (
            SELECT
                x.sasizu_no,
                x.sub_no,
                x.plant_code,
                y.seizou_line_cd,
                x.line_no,
                x.station_no,
                MIN(x.initial_start_date)	AS	initial_start_date,
                MAX(x.initial_end_date)		AS	initial_end_date,
                MIN(x.start_date)				AS	start_date,
                MAX(x.end_date)				AS	end_date,
                MAX(x.upd_date)				AS	upd_date,
                x.invalid_flag						AS	invalid_flag
            FROM
                tbl_seihin_plan				x,
                mst_line						y,
                (	SELECT
                        plant_code,
                        line_no,
                        station_no
                    FROM
                        mst_convert_line
                    WHERE
                        plant_code		= l_plant_code
                    AND	end_flag	= 1)	z
            WHERE
                    x.end_date		>=	l_proc_start_time
            AND	x.end_date	<=	l_proc_end_time
            AND	x.plant_code	=		y.plant_code
            AND	x.line_no		=		y.line_no
            AND	x.plant_code	=		z.plant_code
            AND	x.line_no		=		z.line_no
            AND	x.station_no 	=		z.station_no
            GROUP BY
                x.sasizu_no,
                x.sub_no,
                x.plant_code,
                y.seizou_line_cd,
                x.line_no,
                x.station_no,
                x.invalid_flag
        )								a

        LEFT OUTER JOIN
            tbl_product_trace_log_wk	a1
        ON
            a.sasizu_no		= a1.sasizu_no
        AND	a.sub_no		= a1.sub_no

        LEFT OUTER JOIN
            tbl_line_trace_log_wk	a2
        ON
            a.sasizu_no		= a2.sasizu_no
        AND	a.sub_no		= a2.sub_no
        AND	a.line_no		= a2.line_no,

        tbl_sashizu_management	b,
        mst_hinmoku					c,
        mst_line							d

    WHERE
        a.plant_code			=		l_plant_code
    AND	a.sasizu_no		=		b.sasizu_no
--    AND	(b.actual_end_date	IS NULL	OR (b.actual_end_date			>=	l_proc_start_time_today	AND	b.actual_end_date			<=	l_proc_end_time_today))
--    AND	(a1.seisan_jyotai		IS NULL	OR (a1.actual_end_datetime	>=	l_proc_start_time_today	AND a1.actual_end_datetime	<=	l_proc_end_time_today))
--    AND	(a2.sagyou_jyotai		IS NULL	OR (a2.end_datetime				>=	l_proc_start_time_today	AND a2.end_datetime			<=	l_proc_end_time_today))
    AND	b.buhin_cd			=	c.hinmoku_code
    AND	a.line_no			=	d.line_no
    GROUP BY
        a.plant_code,
        d.seizou_line_cd,
        a.line_no,
        c.hinmoku_code
    ;
    OPENFLG_TBL_SEIHIN_PLAN_FOR_LINE		int;	-- カーソルオープン状態


    -- 指図追番単位計画(製造ラインごと)
    CUR_TBL_SEIHIN_PLAN_FOR_SEIZOLINE	CURSOR FOR
    SELECT
        d.seizou_line_cd,											/* 製造ラインコード */
        CST_ALL_LINE_NO
                                    as		line_no,						/* ラインコード */
        CST_ALL_STATION_NO
                                    as		station_no,				/* ステーション番号 (ライン番号ごとの合計値なので、-1固定) */
        min(b.sagyoku)		as		sagyoku,					/* 作業区(仮に指図の指定作業区を取得) */
        min(c.vtext6)		as		model_group_name,	/* 機種群名 */
        min(c.vtext8)		as		model_series_name,	/* シリーズ名 */
        c.hinmoku_code,											/* 品目コード */
        /* 計画台数・金額 - (当日) */
        sum(case when a.invalid_flag = 0 and a.initial_end_date  >= l_proc_start_time_today then 1 else 0 end) as today_yotei_num,
        MAX(b.hyojyun_genka) * sum(case when a.invalid_flag = 0 and a.initial_end_date  >= l_proc_start_time_today then 1 else 0 end) as today_yotei_genka,
        /* 計画台数・金額 - (前日) */
        sum(case when a.invalid_flag = 0 and a.initial_end_date >= l_proc_start_time_before_the_day and a.initial_end_date <= l_proc_end_time_before_the_day then 1 else 0 end) as yesterday_yotei_num,
        MAX(b.hyojyun_genka) * sum(case when a.invalid_flag = 0 and a.initial_end_date >= l_proc_start_time_before_the_day and a.initial_end_date <= l_proc_end_time_before_the_day then 1 else 0 end) as yesterday_yotei_genka,
        /* 計画台数・金額 - (前々日以前) */
        sum(case when a.invalid_flag = 0 and a.initial_end_date <  l_proc_start_time_before_the_day then 1 else 0 end) as beforeyesterday_yotei_num,
        MAX(b.hyojyun_genka) * sum(case when a.invalid_flag = 0 and a.initial_end_date < l_proc_start_time_before_the_day then 1 else 0 end) as beforeyesterday_yotei_genka,
        max(a.upd_date)		as	upd_date					/* 最新更新日時 */

    FROM
        (
            SELECT
                x.sasizu_no,
                x.sub_no,
                x.plant_code,
                y.seizou_line_cd,
                x.line_no,
                x.station_no,
                MIN(x.initial_start_date)	AS	initial_start_date,
                MAX(x.initial_end_date)		AS	initial_end_date,
                MIN(x.start_date)				AS	start_date,
                MAX(x.end_date)				AS	end_date,
                MAX(x.upd_date)				AS	upd_date,
                x.invalid_flag						AS	invalid_flag
            FROM
                tbl_seihin_plan				x,
                mst_line						y,
                (	SELECT
                        plant_code,
                        line_no,
                        station_no
                    FROM
                        mst_convert_line
                    WHERE
                        plant_code					= l_plant_code
                    AND	mes_line_end_flag	= 1
                )									z
            WHERE
                x.end_date		>=	l_proc_start_time
            AND	x.end_date	<=	l_proc_end_time
            AND	x.plant_code	=		y.plant_code
            AND	x.line_no		=		y.line_no
            AND	x.plant_code	=		z.plant_code
            AND	x.line_no		=		z.line_no
            AND	x.station_no 	=		z.station_no
            GROUP BY
                x.sasizu_no,
                x.sub_no,
                x.plant_code,
                y.seizou_line_cd,
                x.line_no,
                x.station_no,
                x.invalid_flag
        )								a

        LEFT OUTER JOIN
            tbl_product_trace_log_wk	a1
        ON
            a.sasizu_no		= a1.sasizu_no
        AND	a.sub_no		= a1.sub_no,

        tbl_sashizu_management	b,
        mst_hinmoku					c,
        mst_line							d

    WHERE
        a.plant_code			=		l_plant_code
    AND	a.sasizu_no		=		b.sasizu_no
--    AND	(b.actual_end_date	IS NULL	OR (b.actual_end_date			>=	l_proc_start_time_today	AND	b.actual_end_date			<=	l_proc_end_time_today))
--    AND	(a1.seisan_jyotai		IS NULL	OR (a1.actual_end_datetime	>=	l_proc_start_time_today	AND a1.actual_end_datetime	<=	l_proc_end_time_today))
    AND	b.buhin_cd			=	c.hinmoku_code
    AND	a.line_no			=	d.line_no
    GROUP BY
        a.plant_code,
        d.seizou_line_cd,
        c.hinmoku_code
    ;
    OPENFLG_TBL_SEIHIN_PLAN_FOR_SEIZOLINE		int;	-- カーソルオープン状態

    ------------------------------------------------------------
    -- 格納先
    ------------------------------------------------------------
    -- 製品生産計画実績(時間別)
    CUR_TBL_PRODUCT_MANAGEMENT_HOURLY	CURSOR FOR
        SELECT
              *
        FROM
            TBL_PRODUCT_MANAGEMENT_HOURLY
        WHERE
                PLANT_CODE						= l_plant_code
            AND	SEIZOU_LINE_CD			= l_seizou_line_cd
            AND	LINE_NO						= l_line_no
            AND	STATION_NO					= l_station_no
            AND	HINMOKU_CODE			= l_hinmoku_code
            AND	DATA_DATE					= l_proc_start_time
            AND	MODEL_GROUP_NAME	= l_model_group_name
            AND	MODEL_SERIES_NAME	= l_model_series_name
        FOR UPDATE NOWAIT
    ;

    OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY	int;	-- カーソルオープン状態
    REC_TBL_PRODUCT_MANAGEMENT_HOURLY		TBL_PRODUCT_MANAGEMENT_HOURLY%ROWTYPE;

BEGIN
    ----------------------------------------------------------------------------
    --						初期処理
    ----------------------------------------------------------------------------
    raise info 'Start Function [%]', clock_timestamp()::timestamp;

    -- 共通変数初期化
    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S001';

    -- 共通出力パラメータ初期化
    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
    o_ret_cd	:= RET_OK;
    o_sqlerr	:= ' ';
    o_errmsg	:= ' ';
    o_errpnt	:= ' ';

    -- 関数実行日時
    l_exec_datetime := clock_timestamp();

    -- 集計開始/終了日時補正
    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
    IF i_from_time IS NULL THEN
        i_from_time := l_exec_datetime;
    END IF;
    IF i_to_time IS NULL OR i_from_time > i_to_time THEN
        i_to_time := l_exec_datetime;
    END IF;

    -- ローカル変数初期化
    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S004';
    OPENFLG_MST_PLANT											:= CST_FALSE;
    OPENFLG_TBL_SEIHIN_PLAN_FOR_STATION			:= CST_FALSE;
    OPENFLG_TBL_SEIHIN_PLAN_FOR_LINE					:= CST_FALSE;
    OPENFLG_TBL_SEIHIN_PLAN_FOR_SEIZOLINE		:= CST_FALSE;
    OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY	:= CST_FALSE;

    ----------------------------------------------------------------------------
    -- メイン処理
    ----------------------------------------------------------------------------
    << MAIN_LOOP >>
    LOOP

        ------------------------------------------------------------------------
        -- 工場ごとに稼働開始日時が異なるので、工場マスタで処理を回す
        ------------------------------------------------------------------------
        -- 工場マスタを開いているならクローズ
        l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
        IF OPENFLG_MST_PLANT = CST_TRUE THEN
            CLOSE CUR_MST_PLANT;
            OPENFLG_MST_PLANT := CST_FALSE;
        END IF;

        -- 工場マスタをオープン
        l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
        OPEN CUR_MST_PLANT;
        OPENFLG_MST_PLANT := CST_TRUE;

        << PLANT_LOOP >>
        LOOP
            -- 工場マスタからフェッチ
            l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
            FETCH CUR_MST_PLANT INTO l_plant_code,	l_running_start_datetime;
            IF FOUND = FALSE THEN
                EXIT PLANT_LOOP;
            END IF;

            IF l_running_start_datetime IS NULL THEN
                -- NULLの場合はデフォルト値をセット
                l_err_pnt := RTRIM(cst_MY_PRG) || '_301';
                l_running_start_datetime = timestamp '0001-03-21 07:00:00';
            END IF;

            -- 処理開始日時(全体)設定
            l_err_pnt := RTRIM(cst_MY_PRG) || '_202';
            SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_all;
            << START_TIME_LOOP >>
            LOOP
                l_err_pnt := RTRIM(cst_MY_PRG) || '_302';
                IF i_from_time >= l_proc_start_time_all THEN
                    EXIT START_TIME_LOOP;
                END IF;
                l_proc_start_time_all := l_proc_start_time_all + interval '-1 days';
            END LOOP	START_TIME_LOOP;

            -- 処理終了日時(全体)設定
            l_err_pnt := RTRIM(cst_MY_PRG) || '_203';
            SELECT l_proc_start_time_all + interval '1 days' + interval '-1 milliseconds' INTO l_proc_end_time_all;
            << END_TIME_LOOP >>
            LOOP
                l_err_pnt := RTRIM(cst_MY_PRG) || '_303';
                IF i_to_time <= l_proc_end_time_all THEN
                    EXIT END_TIME_LOOP;
                END IF;
                l_proc_end_time_all := l_proc_end_time_all + interval '1 days';
            END LOOP	END_TIME_LOOP;
            -- 計画は、通常で翌々日までを作成
            l_proc_end_time_all := l_proc_end_time_all + interval '2 days';

            -- 処理開始/終了(日)日時
            l_err_pnt := RTRIM(cst_MY_PRG) || '_204';
            l_proc_start_time_day := l_proc_start_time_all;
            l_proc_end_time_day := l_proc_start_time_day + interval '1 days' + interval '-1 milliseconds';

            << TIME_DAY_LOOP >>
            LOOP
                -- 処理開始/終了日時
                l_err_pnt := RTRIM(cst_MY_PRG) || '_304';
                l_proc_start_time := l_proc_start_time_day;
                l_proc_end_time := l_proc_start_time + interval '1 hours' + '-1 milliseconds';

                -- 当日、前日、前々日を設定
                l_proc_start_time_today					:= l_proc_start_time_day;
                l_proc_end_time_today						:= l_proc_end_time_day;
                l_proc_start_time_before_the_day		:= l_proc_start_time_today	+ interval '-1 days' ;
                l_proc_end_time_before_the_day		:= l_proc_end_time_today		+ interval '-1 days' ;
                l_proc_start_time_before_two_days	:= l_proc_start_time_before_the_day	+ interval '-1 days' ;
                l_proc_end_time_before_two_days		:= l_proc_end_time_before_the_day	+ interval '-1 days' ;

                << TIME_LOOP >>
                LOOP
                    ----------------------------------------------------------------------------
                    -- 実績数取得
                    ----------------------------------------------------------------------------
                    --------------------------------------------------
                    -- ステーション毎
                    --------------------------------------------------
                    -- 指図追番単位計画(ステーションごと)を開いているならクローズ
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_401';
                    IF OPENFLG_TBL_SEIHIN_PLAN_FOR_STATION = CST_TRUE THEN
                        CLOSE CUR_TBL_SEIHIN_PLAN_FOR_STATION;
                        OPENFLG_TBL_SEIHIN_PLAN_FOR_STATION := CST_FALSE;
                    END IF;

                    -- 指図追番単位計画　(ステーションごと)をオープン
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_402';
                    OPEN CUR_TBL_SEIHIN_PLAN_FOR_STATION;
                    OPENFLG_TBL_SEIHIN_PLAN_FOR_STATION := CST_TRUE;

                    << SEIHIN_PLAN_FOR_STATION_LOOP >>
                    LOOP
                        l_err_pnt := RTRIM(cst_MY_PRG) || '_403';
                        FETCH
                            CUR_TBL_SEIHIN_PLAN_FOR_STATION
                        INTO
                            l_seizou_line_cd,
                            l_line_no,
                            l_station_no,
                            l_sagyoku,
                            l_model_group_name,
                            l_model_series_name,
                            l_hinmoku_code,
                            l_plan_the_day_num,
                            l_plan_the_day_value,
                            l_plan_before_the_day_num,
                            l_plan_before_the_day_value,
                            l_plan_before_two_days_num,
                            l_plan_before_two_days_value,
                            l_upd_date;
                        IF FOUND = FALSE THEN
                            -- 該当データがない場合、次の処理開始～終了日時にすすむ
                            EXIT SEIHIN_PLAN_FOR_STATION_LOOP;
                        END IF;

                        -- 本日分の台数が0の場合、台数・金額を無効(-1)にする
                        IF l_plan_the_day_num	= 0	THEN
                            l_plan_the_day_num					:= -1;
                            l_plan_the_day_value					:= -1;
                        END IF;
                        -- 前日分の台数が0の場合、台数・金額を無効(-1)にする
                        IF l_plan_before_the_day_num	= 0	THEN
                            l_plan_before_the_day_num		:= -1;
                            l_plan_before_the_day_value		:= -1;
                        END IF;
                        -- 前々日以前分の台数が0の場合、台数・金額を無効(-1)にする
                        IF l_plan_before_two_days_num	= 0	THEN
                            l_plan_before_two_days_num		:= -1;
                            l_plan_before_two_days_value	:= -1;
                        END IF;

                        -- 製品生産計画実績(時間別)にデータがあるか確認
                        l_err_pnt := RTRIM(cst_MY_PRG) || '_501';
                        IF OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY = CST_TRUE THEN
                            CLOSE CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;
                            OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY := CST_FALSE;
                        END IF;

                        -- 製品生産計画実績(時間別)をオープン
                        l_err_pnt := RTRIM(cst_MY_PRG) || '_502';
                        OPEN CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;
                        OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY := CST_TRUE;

                        -- 製品生産計画実績(時間別)フェッチから、レコード取得
                        l_err_pnt := RTRIM(cst_MY_PRG) || '_503';
                        FETCH CUR_TBL_PRODUCT_MANAGEMENT_HOURLY INTO REC_TBL_PRODUCT_MANAGEMENT_HOURLY;
                        IF FOUND = FALSE THEN
                            -- 製品生産計画実績(時間別)にレコードが存在しない場合、

                            -- 製品生産計画実績(時間別)に新規作成格納
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_601';
                            INSERT INTO TBL_PRODUCT_MANAGEMENT_HOURLY
                            (
                                  PLANT_CODE								-- 工場コード
                                , SEIZOU_LINE_CD						-- 製造ラインコード
                                , LINE_NO										-- ライン番号
                                , STATION_NO								-- ステーション番号
                                , SAGYOKU									-- 作業区
                                , HINMOKU_CODE							-- 品目コード
                                , DATA_DATE									-- データ日時
                                , UPD_DATE									-- 更新日時
                                , PLAN_THE_DAY_NUM					-- 計画(当日)台数
                                , PLAN_BEFORE_THE_DAY_NUM		-- 計画(前日)台数
                                , PLAN_BEFORE_TWO_DAYS_NUM	-- 計画(前々日)台数
                                , ACTUAL_THE_DAY_NUM				-- 実績(当日)台数
                                , PLAN_MONTHLY_NUM					-- 月度計画台数
                                , ERP_NUM									-- ERP所要日台数
                                , PLAN_ZAIKAN_NUM						-- 計画(材完)台数
                                , PLAN_STOCKOUT_NUM				-- 計画(欠品)台数
                                , PLAN_THE_DAY_VALUE					-- 計画(当日)金額
                                , PLAN_BEFORE_THE_DAY_VALUE		-- 計画(前日)金額
                                , PLAN_BEFORE_TWO_DAYS_VALUE	-- 計画(前々日)金額
                                , ACTUAL_THE_DAY_VALUE			-- 実績(当日)金額
                                , PLAN_MONTHLY_VALUE				-- 月度計画金額
                                , ERP_VALUE									-- ERP所要日金額
                                , PLAN_ZAIKAN_VALUE					-- 計画(材完)金額
                                , PLAN_STOCKOUT_VALUE				-- 計画(欠品)金額
                                , MODEL_GROUP_NAME					-- 機種群名
                                , MODEL_SERIES_NAME					-- シリーズ名
                                , INS_PROG									-- 登録プログラム名
                                , INS_TIM										-- 登録日時
                                , INS_USER_SID							-- 登録ユーザSID
                                , UPD_PROG									-- 更新プログラム名
                                , UPD_TIM										-- 更新日時
                                , UPD_USER_SID							-- 更新ユーザSID
                            )
                            VALUES
                            (
                                  l_plant_code								-- 工場コード
                                , l_seizou_line_cd							-- 製造ラインコード
                                , l_line_no										-- ライン番号
                                , l_station_no									-- ステーション番号
                                , l_sagyoku									-- 作業区
                                , l_hinmoku_code							-- 品目コード
                                , l_proc_start_time						-- データ日時
                                , l_upd_date									-- 更新日時
                                , l_plan_the_day_num					-- 計画(当日)台数
                                , l_plan_before_the_day_num			-- 計画(前日)台数
                                , l_plan_before_two_days_num		-- 計画(前々日)台数
                                , -1												-- 実績(当日)台数
                                , -1												-- 月度計画台数
                                , -1												-- ERP所要日台数
                                , -1												-- 計画(材完)台数
                                , -1												-- 計画(欠品)台数
                                , l_plan_the_day_value					-- 計画(当日)金額
                                , l_plan_before_the_day_value		-- 計画(前日)金額
                                , l_plan_before_two_days_value		-- 計画(前々日)金額
                                , -1												-- 実績(当日)金額
                                , -1												-- 月度計画金額
                                , -1												-- ERP所要日金額
                                , -1												-- 計画(材完)金額
                                , -1												-- 計画(欠品)金額
                                , l_model_group_name					-- 機種群名
                                , l_model_series_name					-- シリーズ名
                                , cst_MY_PRG								-- 登録プログラム名
                                , l_exec_datetime							-- 登録日時
                                , i_user_sid									-- 登録ユーザSID
                                , cst_MY_PRG								-- 更新プログラム名
                                , l_exec_datetime							-- 更新日時
                                , i_user_sid									-- 更新ユーザSID
                            );

                        ELSE
                            -- 製品生産計画実績(時間別)にレコードが存在する場合、

                            -- 更新の要否を確認
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_602';
                            IF		l_plan_the_day_num					= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_THE_DAY_NUM						THEN
                            IF		l_plan_before_the_day_num		= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_BEFORE_THE_DAY_NUM		THEN
                            IF		l_plan_before_two_days_num		= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_BEFORE_TWO_DAYS_NUM		THEN
                            IF		l_plan_the_day_value					= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_THE_DAY_VALUE					THEN
                            IF		l_plan_before_the_day_value		= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_BEFORE_THE_DAY_VALUE		THEN
                            IF		l_plan_before_two_days_value	= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_BEFORE_TWO_DAYS_VALUE	THEN
                                -- 違いがないので、更新せずに次のループに
                                l_err_pnt := RTRIM(cst_MY_PRG) || '_603';
                                CONTINUE SEIHIN_PLAN_FOR_STATION_LOOP;
                            END IF;
                            END IF;
                            END IF;
                            END IF;
                            END IF;
                            END IF;

                            -- 更新日時の新旧チェック、新しい方を設定
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_604';
                            IF		l_upd_date < REC_TBL_PRODUCT_MANAGEMENT_HOURLY.UPD_DATE		THEN
                                l_err_pnt := RTRIM(cst_MY_PRG) || '_604-2';
                                l_upd_date	:=		REC_TBL_PRODUCT_MANAGEMENT_HOURLY.UPD_DATE;
                            END IF;

                            -- 製品生産計画実績(時間別)の計画台数・金額を更新
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_605';
                            UPDATE TBL_PRODUCT_MANAGEMENT_HOURLY SET
                                 UPD_DATE										=	l_upd_date								-- 更新日時
                                ,PLAN_THE_DAY_NUM						= 	l_plan_the_day_num					-- 計画(当日)台数
                                ,PLAN_BEFORE_THE_DAY_NUM			= l_plan_before_the_day_num		-- 計画(前日)台数
                                ,PLAN_BEFORE_TWO_DAYS_NUM		= l_plan_before_two_days_num		-- 計画(前々日以前)台数
                                ,PLAN_THE_DAY_VALUE					= l_plan_the_day_value					-- 計画(当日)金額
                                ,PLAN_BEFORE_THE_DAY_VALUE		= l_plan_before_the_day_value		-- 計画(前日)金額
                                ,PLAN_BEFORE_TWO_DAYS_VALUE	= l_plan_before_two_days_value	-- 計画(前々日以前)金額
                                ,UPD_PROG										= cst_MY_PRG								-- 更新プログラム
                                ,UPD_TIM											= l_exec_datetime							-- 更新日時
                                ,UPD_USER_SID								= i_user_sid									-- 更新ユーザSID
                            WHERE CURRENT OF CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;

                        END IF;

                    END LOOP	 SEIHIN_PLAN_FOR_STATION_LOOP;


                    --------------------------------------------------
                    -- ライン毎
                    --------------------------------------------------
                    -- 指図追番単位計画(ラインごと)を開いているならクローズ
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_401';
                    IF OPENFLG_TBL_SEIHIN_PLAN_FOR_LINE = CST_TRUE THEN
                        CLOSE CUR_TBL_SEIHIN_PLAN_FOR_LINE;
                        OPENFLG_TBL_SEIHIN_PLAN_FOR_LINE := CST_FALSE;
                    END IF;

                    -- 指図追番単位計画(ラインごと)をオープン
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_701';
                    OPEN CUR_TBL_SEIHIN_PLAN_FOR_LINE;
                    OPENFLG_TBL_SEIHIN_PLAN_FOR_LINE := CST_TRUE;

                    << SEIHIN_PLAN_FOR_LINE_LOOP >>
                    LOOP
                        l_err_pnt := RTRIM(cst_MY_PRG) || '_702';
                        FETCH
                            CUR_TBL_SEIHIN_PLAN_FOR_LINE
                        INTO
                            l_seizou_line_cd,
                            l_line_no,
                            l_station_no,
                            l_sagyoku,
                            l_model_group_name,
                            l_model_series_name,
                            l_hinmoku_code,
                            l_plan_the_day_num,
                            l_plan_the_day_value,
                            l_plan_before_the_day_num,
                            l_plan_before_the_day_value,
                            l_plan_before_two_days_num,
                            l_plan_before_two_days_value,
                            l_upd_date;
                        IF FOUND = FALSE THEN
                            -- 該当データがない場合
                            EXIT SEIHIN_PLAN_FOR_LINE_LOOP;
                        END IF;

                        -- 本日分の台数が0の場合、台数・金額を無効(-1)にする
                        IF l_plan_the_day_num	= 0	THEN
                            l_plan_the_day_num					:= -1;
                            l_plan_the_day_value					:= -1;
                        END IF;
                        -- 前日分の台数が0の場合、台数・金額を無効(-1)にする
                        IF l_plan_before_the_day_num	= 0	THEN
                            l_plan_before_the_day_num		:= -1;
                            l_plan_before_the_day_value		:= -1;
                        END IF;
                        -- 前々日以前分の台数が0の場合、台数・金額を無効(-1)にする
                        IF l_plan_before_two_days_num	= 0	THEN
                            l_plan_before_two_days_num		:= -1;
                            l_plan_before_two_days_value	:= -1;
                        END IF;

                        -- 製品生産計画実績(時間別)にデータがあるか確認
                        l_err_pnt := RTRIM(cst_MY_PRG) || '_801';
                        IF OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY = CST_TRUE THEN
                            CLOSE CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;
                            OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY := CST_FALSE;
                        END IF;

                        -- 製品生産計画実績(時間別)をオープン
                        l_err_pnt := RTRIM(cst_MY_PRG) || '_802';
                        OPEN CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;
                        OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY := CST_TRUE;

                        l_err_pnt := RTRIM(cst_MY_PRG) || '_803';
                        FETCH CUR_TBL_PRODUCT_MANAGEMENT_HOURLY INTO REC_TBL_PRODUCT_MANAGEMENT_HOURLY;
                        IF FOUND = FALSE THEN
                            -- 製品生産計画実績(時間別)に格納
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_901';
                            INSERT INTO TBL_PRODUCT_MANAGEMENT_HOURLY
                            (
                                  PLANT_CODE								-- 工場コード
                                , SEIZOU_LINE_CD						-- 製造ラインコード
                                , LINE_NO										-- ライン番号
                                , STATION_NO								-- ステーション番号
                                , SAGYOKU									-- 作業区
                                , HINMOKU_CODE							-- 品目コード
                                , DATA_DATE									-- データ日時
                                , UPD_DATE									-- 更新日時
                                , PLAN_THE_DAY_NUM					-- 計画(当日)台数
                                , PLAN_BEFORE_THE_DAY_NUM		-- 計画(前日)台数
                                , PLAN_BEFORE_TWO_DAYS_NUM	-- 計画(前々日)台数
                                , ACTUAL_THE_DAY_NUM				-- 実績(当日)台数
                                , PLAN_MONTHLY_NUM					-- 月度計画台数
                                , ERP_NUM									-- ERP所要日台数
                                , PLAN_ZAIKAN_NUM						-- 計画(材完)台数
                                , PLAN_STOCKOUT_NUM				-- 計画(欠品)台数
                                , PLAN_THE_DAY_VALUE					-- 計画(当日)金額
                                , PLAN_BEFORE_THE_DAY_VALUE		-- 計画(前日)金額
                                , PLAN_BEFORE_TWO_DAYS_VALUE	-- 計画(前々日)金額
                                , ACTUAL_THE_DAY_VALUE			-- 実績(当日)金額
                                , PLAN_MONTHLY_VALUE				-- 月度計画金額
                                , ERP_VALUE									-- ERP所要日金額
                                , PLAN_ZAIKAN_VALUE					-- 計画(材完)金額
                                , PLAN_STOCKOUT_VALUE				-- 計画(欠品)金額
                                , MODEL_GROUP_NAME					-- 機種群名
                                , MODEL_SERIES_NAME					-- シリーズ名
                                , INS_PROG									-- 登録プログラム名
                                , INS_TIM										-- 登録日時
                                , INS_USER_SID							-- 登録ユーザSID
                                , UPD_PROG									-- 更新プログラム名
                                , UPD_TIM										-- 更新日時
                                , UPD_USER_SID							-- 更新ユーザSID
                            )
                            VALUES
                            (
                                  l_plant_code								-- 工場コード
                                , l_seizou_line_cd							-- 製造ラインコード
                                , l_line_no										-- ライン番号
                                , l_station_no									-- ステーション番号
                                , l_sagyoku									-- 作業区
                                , l_hinmoku_code							-- 品目コード
                                , l_proc_start_time						-- データ日時
                                , l_upd_date									-- 更新日時
                                , l_plan_the_day_num					-- 計画(当日)台数
                                , l_plan_before_the_day_num			-- 計画(前日)台数
                                , l_plan_before_two_days_num		-- 計画(前々日)台数
                                , -1												-- 実績(当日)台数
                                , -1												-- 月度計画台数
                                , -1												-- ERP所要日台数
                                , -1												-- 計画(材完)台数
                                , -1												-- 計画(欠品)台数
                                , l_plan_the_day_value					-- 計画(当日)金額
                                , l_plan_before_the_day_value		-- 計画(前日)金額
                                , l_plan_before_two_days_value		-- 計画(前々日)金額
                                , -1												-- 実績(当日)金額
                                , -1												-- 月度計画金額
                                , -1												-- ERP所要日金額
                                , -1												-- 計画(材完)金額
                                , -1												-- 計画(欠品)金額
                                , l_model_group_name					-- 機種群名
                                , l_model_series_name					-- シリーズ名
                                , cst_MY_PRG								-- 登録プログラム名
                                , l_exec_datetime							-- 登録日時
                                , i_user_sid									-- 登録ユーザSID
                                , cst_MY_PRG								-- 更新プログラム名
                                , l_exec_datetime							-- 更新日時
                                , i_user_sid									-- 更新ユーザSID
                            );

                        ELSE
                            -- 製品生産計画実績(時間別)にレコードが存在する場合、

                            -- 更新の要否を確認
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_902';
                            IF		l_plan_the_day_num					= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_THE_DAY_NUM						THEN
                            IF		l_plan_before_the_day_num		= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_BEFORE_THE_DAY_NUM		THEN
                            IF		l_plan_before_two_days_num		= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_BEFORE_TWO_DAYS_NUM		THEN
                            IF		l_plan_the_day_value					= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_THE_DAY_VALUE					THEN
                            IF		l_plan_before_the_day_value		= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_BEFORE_THE_DAY_VALUE		THEN
                            IF		l_plan_before_two_days_value	= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_BEFORE_TWO_DAYS_VALUE	THEN
                                -- 違いがないので、更新せずに次のループに
                                l_err_pnt := RTRIM(cst_MY_PRG) || '_903';
                                CONTINUE SEIHIN_PLAN_FOR_LINE_LOOP;
                            END IF;
                            END IF;
                            END IF;
                            END IF;
                            END IF;
                            END IF;

                            -- 更新日時の新旧チェック、新しい方を設定
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_904';
                            IF		REC_TBL_PRODUCT_MANAGEMENT_HOURLY.UPD_DATE > l_upd_date	THEN
                                l_err_pnt := RTRIM(cst_MY_PRG) || '_904-2';
                                l_upd_date	:=		REC_TBL_PRODUCT_MANAGEMENT_HOURLY.UPD_DATE;
                            END IF;

                            -- 製品生産計画実績(時間別)の計画台数・金額を更新
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_905';
                            UPDATE TBL_PRODUCT_MANAGEMENT_HOURLY SET
                                 UPD_DATE										=	l_upd_date								-- 更新日時
                                ,PLAN_THE_DAY_NUM						= 	l_plan_the_day_num					-- 計画(当日)台数
                                ,PLAN_BEFORE_THE_DAY_NUM			= l_plan_before_the_day_num		-- 計画(前日)台数
                                ,PLAN_BEFORE_TWO_DAYS_NUM		= l_plan_before_two_days_num		-- 計画(前々日以前)台数
                                ,PLAN_THE_DAY_VALUE					= l_plan_the_day_value					-- 計画(当日)金額
                                ,PLAN_BEFORE_THE_DAY_VALUE		= l_plan_before_the_day_value		-- 計画(前日)金額
                                ,PLAN_BEFORE_TWO_DAYS_VALUE	= l_plan_before_two_days_value	-- 計画(前日)金額
                                ,UPD_PROG										= cst_MY_PRG								-- 更新プログラム
                                ,UPD_TIM											= l_exec_datetime							-- 更新日時
                                ,UPD_USER_SID								= i_user_sid									-- 更新ユーザSID
                            WHERE CURRENT OF CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;

                        END IF;

                    END LOOP	SEIHIN_PLAN_FOR_LINE_LOOP;

                    --------------------------------------------------
                    -- 製造ラインごと
                    --------------------------------------------------
                    -- 製品トレースログを開いているならクローズ
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_1001';
                    IF OPENFLG_TBL_SEIHIN_PLAN_FOR_SEIZOLINE = CST_TRUE THEN
                        CLOSE CUR_TBL_SEIHIN_PLAN_FOR_SEIZOLINE;
                        OPENFLG_TBL_SEIHIN_PLAN_FOR_SEIZOLINE := CST_FALSE;
                    END IF;

                    -- 製品トレースログをオープン
                    l_err_pnt := RTRIM(cst_MY_PRG) || '_1002';
                    OPEN CUR_TBL_SEIHIN_PLAN_FOR_SEIZOLINE;
                    OPENFLG_TBL_SEIHIN_PLAN_FOR_SEIZOLINE := CST_TRUE;

                    << TBL_SEIHIN_PLAN_FOR_SEIZOLINE_LOOP >>
                    LOOP
                        -- 製品トレースログからフェッチ
                        l_err_pnt := RTRIM(cst_MY_PRG) || '_1003';
                        FETCH
                            CUR_TBL_SEIHIN_PLAN_FOR_SEIZOLINE
                        INTO
                            l_seizou_line_cd,
                            l_line_no,
                            l_station_no,
                            l_sagyoku,
                            l_model_group_name,
                            l_model_series_name,
                            l_hinmoku_code,
                            l_plan_the_day_num,
                            l_plan_the_day_value,
                            l_plan_before_the_day_num,
                            l_plan_before_the_day_value,
                            l_plan_before_two_days_num,
                            l_plan_before_two_days_value,
                            l_upd_date;
                        IF FOUND = FALSE THEN
                            -- データがない場合
                            EXIT TBL_SEIHIN_PLAN_FOR_SEIZOLINE_LOOP;
                        END IF;

                        -- 本日分の台数が0の場合、台数・金額を無効(-1)にする
                        IF l_plan_the_day_num	= 0	THEN
                            l_plan_the_day_num					:= -1;
                            l_plan_the_day_value					:= -1;
                        END IF;
                        -- 前日分の台数が0の場合、台数・金額を無効(-1)にする
                        IF l_plan_before_the_day_num	= 0	THEN
                            l_plan_before_the_day_num		:= -1;
                            l_plan_before_the_day_value		:= -1;
                        END IF;
                        -- 前々日以前分の台数が0の場合、台数・金額を無効(-1)にする
                        IF l_plan_before_two_days_num	= 0	THEN
                            l_plan_before_two_days_num		:= -1;
                            l_plan_before_two_days_value	:= -1;
                        END IF;

                        l_err_pnt := RTRIM(cst_MY_PRG) || '_1101';
                        -- 製品生産計画実績(時間別)にデータがあるか確認
                        IF OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY = CST_TRUE THEN
                            CLOSE CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;
                            OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY := CST_FALSE;
                        END IF;

                        l_err_pnt := RTRIM(cst_MY_PRG) || '_1102';
                        -- 製品生産計画実績(時間別)をオープン
                        OPEN CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;
                        OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY := CST_TRUE;

                        l_err_pnt := RTRIM(cst_MY_PRG) || '_1103';
                        FETCH CUR_TBL_PRODUCT_MANAGEMENT_HOURLY INTO REC_TBL_PRODUCT_MANAGEMENT_HOURLY;
                        IF FOUND = FALSE THEN
                            -- 製品生産計画実績(時間別)に格納
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_1201';
                            INSERT INTO TBL_PRODUCT_MANAGEMENT_HOURLY
                            (
                                  PLANT_CODE								-- 工場コード
                                , SEIZOU_LINE_CD						-- 製造ラインコード
                                , LINE_NO										-- ライン番号
                                , STATION_NO								-- ステーション番号
                                , SAGYOKU									-- 作業区
                                , HINMOKU_CODE							-- 品目コード
                                , DATA_DATE									-- データ日時
                                , UPD_DATE									-- 更新日時
                                , PLAN_THE_DAY_NUM					-- 計画(当日)台数
                                , PLAN_BEFORE_THE_DAY_NUM		-- 計画(前日)台数
                                , PLAN_BEFORE_TWO_DAYS_NUM	-- 計画(前々日)台数
                                , ACTUAL_THE_DAY_NUM				-- 実績(当日)台数
                                , PLAN_MONTHLY_NUM					-- 月度計画台数
                                , ERP_NUM									-- ERP所要日台数
                                , PLAN_ZAIKAN_NUM						-- 計画(材完)台数
                                , PLAN_STOCKOUT_NUM				-- 計画(欠品)台数
                                , PLAN_THE_DAY_VALUE					-- 計画(当日)金額
                                , PLAN_BEFORE_THE_DAY_VALUE		-- 計画(前日)金額
                                , PLAN_BEFORE_TWO_DAYS_VALUE	-- 計画(前々日)金額
                                , ACTUAL_THE_DAY_VALUE			-- 実績(当日)金額
                                , PLAN_MONTHLY_VALUE				-- 月度計画金額
                                , ERP_VALUE									-- ERP所要日金額
                                , PLAN_ZAIKAN_VALUE					-- 計画(材完)金額
                                , PLAN_STOCKOUT_VALUE				-- 計画(欠品)金額
                                , MODEL_GROUP_NAME					-- 機種群名
                                , MODEL_SERIES_NAME					-- シリーズ名
                                , INS_PROG									-- 登録プログラム名
                                , INS_TIM										-- 登録日時
                                , INS_USER_SID							-- 登録ユーザSID
                                , UPD_PROG									-- 更新プログラム名
                                , UPD_TIM										-- 更新日時
                                , UPD_USER_SID							-- 更新ユーザSID
                            )
                            VALUES
                            (
                                  l_plant_code								-- 工場コード
                                , l_seizou_line_cd							-- 製造ラインコード
                                , l_line_no										-- ライン番号
                                , l_station_no									-- ステーション番号
                                , l_sagyoku									-- 作業区
                                , l_hinmoku_code							-- 品目コード
                                , l_proc_start_time						-- データ日時
                                , l_upd_date									-- 更新日時
                                , l_plan_the_day_num					-- 計画(当日)台数
                                , l_plan_before_the_day_num			-- 計画(前日)台数
                                , l_plan_before_two_days_num		-- 計画(前々日)台数
                                , -1												-- 実績(当日)台数
                                , -1												-- 月度計画台数
                                , -1												-- ERP所要日台数
                                , -1												-- 計画(材完)台数
                                , -1												-- 計画(欠品)台数
                                , l_plan_the_day_value					-- 計画(当日)金額
                                , l_plan_before_the_day_value		-- 計画(前日)金額
                                , l_plan_before_two_days_value		-- 計画(前々日)金額
                                , -1												-- 実績(当日)金額
                                , -1												-- 月度計画金額
                                , -1												-- ERP所要日金額
                                , -1												-- 計画(材完)金額
                                , -1												-- 計画(欠品)金額
                                , l_model_group_name					-- 機種群名
                                , l_model_series_name					-- シリーズ名
                                , cst_MY_PRG								-- 登録プログラム名
                                , l_exec_datetime							-- 登録日時
                                , i_user_sid									-- 登録ユーザSID
                                , cst_MY_PRG								-- 更新プログラム名
                                , l_exec_datetime							-- 更新日時
                                , i_user_sid									-- 更新ユーザSID
                            );

                        ELSE
                            -- 製品生産計画実績(時間別)にレコードが存在する場合、

                            -- 更新の要否を確認
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_1202';
                            IF		l_plan_the_day_num					= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_THE_DAY_NUM						THEN
                            IF		l_plan_before_the_day_num		= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_BEFORE_THE_DAY_NUM		THEN
                            IF		l_plan_before_two_days_num		= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_BEFORE_TWO_DAYS_NUM		THEN
                            IF		l_plan_the_day_value					= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_THE_DAY_VALUE					THEN
                            IF		l_plan_before_the_day_value		= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_BEFORE_THE_DAY_VALUE		THEN
                            IF		l_plan_before_two_days_value	= REC_TBL_PRODUCT_MANAGEMENT_HOURLY.PLAN_BEFORE_TWO_DAYS_VALUE	THEN
                                -- 違いがないので、更新せずに次のループに
                                l_err_pnt := RTRIM(cst_MY_PRG) || '_1203';
                                CONTINUE TBL_SEIHIN_PLAN_FOR_SEIZOLINE_LOOP;
                            END IF;
                            END IF;
                            END IF;
                            END IF;
                            END IF;
                            END IF;

                            -- 更新日時の新旧チェック、新しい方を設定
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_1204';
                            IF		REC_TBL_PRODUCT_MANAGEMENT_HOURLY.UPD_DATE > l_upd_date	THEN
                                l_err_pnt := RTRIM(cst_MY_PRG) || '_1204-2';
                                l_upd_date	:=		REC_TBL_PRODUCT_MANAGEMENT_HOURLY.UPD_DATE;
                            END IF;

                            -- 製品生産計画実績(時間別)の計画台数・金額を更新
                            l_err_pnt := RTRIM(cst_MY_PRG) || '_1204';
                            UPDATE TBL_PRODUCT_MANAGEMENT_HOURLY SET
                                 UPD_DATE										=	l_upd_date								-- 更新日時
                                ,PLAN_THE_DAY_NUM						= 	l_plan_the_day_num					-- 計画(当日)台数
                                ,PLAN_BEFORE_THE_DAY_NUM			= l_plan_before_the_day_num		-- 計画(前日)台数
                                ,PLAN_BEFORE_TWO_DAYS_NUM		= l_plan_before_two_days_num		-- 計画(前々日以前)台数
                                ,PLAN_THE_DAY_VALUE					= l_plan_the_day_value					-- 計画(当日)金額
                                ,PLAN_BEFORE_THE_DAY_VALUE		= l_plan_before_the_day_value		-- 計画(前日)金額
                                ,PLAN_BEFORE_TWO_DAYS_VALUE	= l_plan_before_two_days_value	-- 計画(前日)金額
                                ,UPD_PROG										= cst_MY_PRG								-- 更新プログラム
                                ,UPD_TIM											= l_exec_datetime							-- 更新日時
                                ,UPD_USER_SID								= i_user_sid									-- 更新ユーザSID
                            WHERE CURRENT OF CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;

                        END IF;

                    END LOOP	TBL_SEIHIN_PLAN_FOR_SEIZOLINE_LOOP;

                    -- 次の処理日時を設定
                    l_proc_start_time	:= l_proc_start_time + interval '1 hours';
                    l_proc_end_time		:= l_proc_end_time + interval '1 hours';

                    -- 処理開始日時が処理終了日時(日)を超えている場合は処理終了
                    IF l_proc_end_time_day < l_proc_start_time THEN
                        EXIT TIME_LOOP;
                    END IF;

                END LOOP	TIME_LOOP;

                -- 次の処理日時(日)を設定
                l_err_pnt := RTRIM(cst_MY_PRG) || '_305';
                l_proc_start_time_day	:= l_proc_start_time_day + interval '1 days';
                l_proc_end_time_day		:= l_proc_end_time_day + interval '1 days';

                -- 処理開始日時(日)が処理終了日時(全体)を超えている場合は処理終了
                l_err_pnt := RTRIM(cst_MY_PRG) || '_306';
                IF l_proc_end_time_all < l_proc_start_time_day THEN
                    EXIT TIME_DAY_LOOP;
                END IF;

            END LOOP	TIME_DAY_LOOP;

        END LOOP	PLANT_LOOP;

        EXIT MAIN_LOOP;
    END LOOP	MAIN_LOOP;

    ----------------------------------------------------------------------------
    --						終了処理
    ----------------------------------------------------------------------------
    -- カーソルクローズ
    l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
    IF OPENFLG_MST_PLANT = CST_TRUE THEN
        CLOSE CUR_MST_PLANT;
        OPENFLG_MST_PLANT := CST_FALSE;
    END IF;

    l_err_pnt := RTRIM(cst_MY_PRG) || '_E002';
    IF OPENFLG_TBL_SEIHIN_PLAN_FOR_LINE = CST_TRUE THEN
        CLOSE CUR_TBL_SEIHIN_PLAN_FOR_STATION;
        OPENFLG_TBL_SEIHIN_PLAN_FOR_LINE := CST_FALSE;
    END IF;

    l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
    IF OPENFLG_TBL_SEIHIN_PLAN_FOR_LINE = CST_TRUE THEN
        CLOSE CUR_TBL_SEIHIN_PLAN_FOR_LINE;
        OPENFLG_TBL_SEIHIN_PLAN_FOR_LINE := CST_FALSE;
    END IF;

    l_err_pnt := RTRIM(cst_MY_PRG) || '_E004';
    IF OPENFLG_TBL_SEIHIN_PLAN_FOR_SEIZOLINE = CST_TRUE THEN
        CLOSE CUR_TBL_SEIHIN_PLAN_FOR_SEIZOLINE;
        OPENFLG_TBL_SEIHIN_PLAN_FOR_SEIZOLINE := CST_FALSE;
    END IF;

    l_err_pnt := RTRIM(cst_MY_PRG) || '_E005';
    IF OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY = CST_TRUE THEN
        CLOSE CUR_TBL_PRODUCT_MANAGEMENT_HOURLY;
        OPENFLG_TBL_PRODUCT_MANAGEMENT_HOURLY := CST_FALSE;
    END IF;

    raise info 'End Function [%]', clock_timestamp()::timestamp;

EXCEPTION WHEN OTHERS THEN
    -- DB例外情報収集
    GET STACKED DIAGNOSTICS rtn_sql_no     = RETURNED_SQLSTATE,
                            rtn_sql_msg    = MESSAGE_TEXT,
                            rtn_sql_detail = PG_EXCEPTION_DETAIL,
                            rtn_sql_hint   = PG_EXCEPTION_HINT,
                            rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

    raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
    raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

    o_ret_cd := RET_NG;
    o_sqlerr := substr(rtn_sql_no, 1, 15);
    o_errmsg := substr(rtn_sql_msg, 1, 127);
    o_errpnt := l_err_pnt;

    raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;