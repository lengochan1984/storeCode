WITH
	val AS (
		SELECT
			(	(
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*stId*/,
				/*stStatus*/,
				/*sijiWorkSupport*/,
				/*menteMode*/,
				/*userId*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
				'insert-TR_STATION_STS',
				now(),
				0,
				'insert-TR_STATION_STS',
				now(),
				0
				)::TR_STATION_STS).*
	),

	upd AS (
		UPDATE
			TR_STATION_STS
		SET
			modified_on 		= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			st_status           = CAST(/*stStatus*/ AS numeric),
			siji_work_support   = CAST(/*sijiWorkSupport*/ AS smallint),
			mente_mode          = CAST(/*menteMode*/ AS numeric),
			user_id             = /*userId*/,
			spare_num1			= CAST(/*spareNum1*/ AS numeric),
			spare_num2			= CAST(/*spareNum2*/ AS numeric),
			spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-TR_STATION_STS',
			upd_tim				= now(),
			upd_user_sid		= 0

		FROM
			val
		WHERE
			TR_STATION_STS.st_id	= /*stId*/

		RETURNING
			TR_STATION_STS.st_id
	)

INSERT INTO
	TR_STATION_STS
SELECT
	*
FROM
	val
WHERE
	(st_id)
		NOT IN (SELECT st_id FROM upd);