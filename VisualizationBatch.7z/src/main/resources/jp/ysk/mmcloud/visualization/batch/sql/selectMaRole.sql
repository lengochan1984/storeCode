SELECT
    CREATED_ON,
    CREATED_BY,
    CASE WHEN HIS_KBN != 'D' THEN COALESCE(MODIFIED_ON, CREATED_ON) ELSE EVENT_TIME END AS MODIFIED_ON,
    COALESCE(MODIFIED_BY, CREATED_BY) AS MODIFIED_BY,
    CASE WHEN HIS_KBN != 'D' THEN 0 ELSE 1 END AS INVALID_FLAG,
    ROLE_CD,
    ROLE_NM,
    SPARE_NUM1,
    SPARE_NUM2,
    SPARE_NUM3,
    SPARE_TEXT1,
    SPARE_TEXT2,
    SPARE_TEXT3

FROM
(
    SELECT
        SUB.*
    FROM
    (
        SELECT
            *,
            ROW_NUMBER() OVER (PARTITION BY ROLE_CD ORDER BY EVENT_TIME DESC) AS rowIndex
        FROM
            MA_ROLE_HIS
    ) SUB
    WHERE
        SUB.rowIndex = 1
) T

/*BEGIN*/
WHERE
    /*IF addDatetime != null */
        (CREATED_ON >= /*addDatetime*/ AND MODIFIED_ON is null)
    OR  MODIFIED_ON >= /*addDatetime*/
    /*END*/
/*END*/

ORDER BY
    CASE WHEN HIS_KBN != 'D' THEN COALESCE(MODIFIED_ON, CREATED_ON) ELSE EVENT_TIME END
