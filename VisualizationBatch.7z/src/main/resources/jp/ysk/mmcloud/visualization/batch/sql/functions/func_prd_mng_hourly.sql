CREATE or REPLACE FUNCTION func_prd_mng_hourly(
	in	i_batch_name	varchar,			-- バッチ処理名称
	in	i_log_type		numeric,			-- ログ種別(開始、および　各バッチ処理の復帰値)
											-- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
	in	i_user_sid		numeric,			-- 登録ユーザSID
	in	i_from_time 	timestamp,			-- 集計開始日時(空の場合は当日を対象とする)
	in	i_to_time		timestamp,			-- 集計終了日時(空の場合は当日を対象とする)
	out o_ret_cd		int,				-- 関数復帰値	RET_OK(= 0):正常終了
	out o_sqlerr		varchar,			-- ＤＢ異常発生時のエラーコード
	out o_errmsg		varchar,			-- 異常発生時のエラーメッセージ
	out o_errpnt		varchar 			-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　製品生産計画実績(時間別)作成サービス
--　ソースプログラム名　：　func_prd_mng_hourly.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　製品生産計画実績(時間別)を作成する
--
--　履歴
--	Ver.  作成日			作成者		COMMENT
--	1.0   2016/12/01		H.Nakamura	新規作成
--	1.1   2017/08/31		H.Nakamura	MMsF対応
--******************************************************************************
DECLARE
	----------------------------------------------------------------------------
	--						標準定数定義
	----------------------------------------------------------------------------
	-- 戻り値
	RET_OK		CONSTANT int := 0 ; 					-- 正常終了コード
	RET_NG		CONSTANT int := -1 ;					-- 異常終了コード
	-- 真偽値
	CST_TRUE	CONSTANT int := 1 ; 					-- 真
	CST_FALSE	CONSTANT int := 0 ; 					-- 偽

	----------------------------------------------------------------------------
	--						標準変数定義
	----------------------------------------------------------------------------
	cst_MY_PRG	CONSTANT CHAR(32)	 := 'func_prd_mng_hourly';				-- プログラム名
	cst_UPD_TIM CHAR(17) ;													-- 更新時間
	l_err_pnt	CHAR(64) ;													-- エラー発生ポイント
	errbuff 	varchar(256);												-- メッセージバッファ

	----------------------------------------------------------------------------
	--						定数定義
	----------------------------------------------------------------------------
	CST_ALL_LN_ID 	CONSTANT int	:= -1;			-- ラインID
	CST_ALL_ST_ID	CONSTANT int	:= -1;			-- ステーションID

	----------------------------------------------------------------------------
	--						変数定義
	----------------------------------------------------------------------------
	-- 共通変数
	rtn_sql_no		text;							-- DBエラー情報(エラー番号)
	rtn_sql_msg 	text;							-- DBエラー情報(エラーメッセージ)
	rtn_sql_detail	text;							-- DBエラー情報(エラー詳細)
	rtn_sql_hint	text;							-- DBエラー情報(エラーヒント)
	rtn_sql_stack	text;							-- DBエラー情報(エラー発生呼出しスタック)

	-- ローカル変数
	l_exec_datetime 			timestamp;			-- 関数実行日時
	l_proc_start_time			timestamp;			-- 処理開始日
	l_proc_end_time 			timestamp;			-- 処理終了日
	l_proc_start_time_all		timestamp;			-- 処理開始日(全体)
	l_proc_end_time_all 		timestamp;			-- 処理終了日(全体)
	l_proc_start_time_day		timestamp;			-- 処理開始日(日)
	l_proc_end_time_day 		timestamp;			-- 処理終了日(日)
	l_running_start_datetime	timestamp;			-- 稼働開始日時(年度開始日時)
	l_plant_cd					char(10);			-- 工場コード
	l_plant_cd_wk 				char(10);			-- 工場コード
	l_seizou_ln_id				int;				-- 製造ラインID
	l_seizou_ln_cd				char(10);			-- 製造ラインコード
	l_seizou_ln_nm				char(64);			-- 製造ライン名
	l_process_cd				char(5);			-- 工程コード
	l_process_nm				char(64);			-- 工程名称
	l_ln_id						int;				-- ラインID
	l_ln_no						char(32);			-- ライン番号
	l_ln_nm						char(64);			-- ライン名称
	l_st_id						int;				-- ステーションID
	l_st_no						char(8);			-- ステーション番号
	l_st_nm						char(64);			-- ステーション名称
	l_buhin_cd					char(40);			-- 品目コード
	l_data_date					timestamp;			-- データ日時
	l_upd_date					timestamp;			-- 更新日時
	l_actual_the_day_num		int;				-- 実績台数
	l_actual_the_day_value		int;				-- 実績金額
	l_actual_the_day_value_wk	numeric;			-- 実績金額(作業用)
	l_vtext_info1				varchar(40);		-- 品目階層TEXT_その1
	l_vtext_info2 				varchar(40);		-- 品目階層TEXT_その2

	----------------------------------------------------------------------------
	--						カーソル定義
	----------------------------------------------------------------------------
	-- 工場マスタ
	CUR_MA_PLANT	CURSOR FOR
		SELECT
			PLANT_CD					as plantCd,
			RUNNING_START_DATETIME		as runningStartDatetime
		FROM
			MA_PLANT
		--WHERE
		--	INVALID_FLAG = 0
		ORDER BY
			PLANT_CD
	;

	OPENFLG_MA_PLANT	int;	-- カーソルオープン状態

	--------------------------------------------------
	-- 実績数
	--------------------------------------------------
	-- 製品生産計画実績(時間別)(クリア用)
	CUR_AG_PRODUCT_MNG_HOURLY_CLEAR	CURSOR FOR
		SELECT
			*
		FROM
			AG_PRODUCT_MNG_HOURLY
		WHERE
				PLANT_CD	=  l_plant_cd_wk
			AND	DATA_DATE	>= l_proc_start_time_all
			AND	DATA_DATE	<= l_proc_end_time_all
		FOR UPDATE NOWAIT
	;

	OPENFLG_AG_PRODUCT_MNG_HOURLY_CLEAR	int;	-- カーソルオープン状態
	REC_AG_PRODUCT_MNG_HOURLY_CLEAR		AG_PRODUCT_MNG_HOURLY%ROWTYPE;

	-- 各種トレースログ(作業用)
	CUR_TR_TRACE_LOG	CURSOR FOR
		-- ステーションごと
		SELECT
			T6.SEIZOU_LN_ID							as seizouLnId,
			T4.LN_ID								as lnId,
			T1.ST_ID								as stId,
			T2.BUHIN_CD								as buhinCd,
			DATE_TRUNC('hour', T1.WORK_END_TIME)	as dataDate,
			T3.VTEXT_INFO1							as vtextInfo1,
			MAX(T3.VTEXT_INFO2)						as vtextInfo2,
			MAX(T1.PLANT_CD)						as plantCd,
			MAX(T1.SEIZOU_LN_CD)					as seizouLnCd,
			MAX(T1.SEIZOU_LN_NM)					as seizouLnNm,
			MAX(T1.PROCESS_CD)						as processCd,
			MAX(T1.PROCESS_NM)						as processNm,
			MAX(T1.LN_NO)							as lnNo,
			MAX(T1.LN_NM)							as lnNm,
			MAX(T1.ST_NO)							as stNo,
			MAX(T1.ST_NM)							as stNm,
			MAX(T1.MODIFIED_ON)						as updDate,
			COUNT(*)								as actualNum,
			SUM(T2.HYOJYUN_GENKA)					as actualValue
		FROM
		(
			SELECT
				SASIZU_NO			as sasizuNo,
				SUB_NO				as subNo,
				SAGYO_SEQ			as sagyoSeq,
				ST_ID				as stId,
				WORK_STA_TIME		as workStaTime,
				MAX(REPAIR_KAISU)	as maxRepairKaisu
			FROM
				TR_ST_WORK_JSK
			WHERE
					PLANT_CD		=	l_plant_cd_wk
				AND	WORK_END_TIME	>=	l_proc_start_time_day
				AND	WORK_END_TIME	<=	l_proc_end_time_day
			GROUP BY
				SASIZU_NO,
				SUB_NO,
				SAGYO_SEQ,
				ST_ID,
				WORK_STA_TIME
		) T0
		INNER JOIN
			TR_ST_WORK_JSK	T1
		ON
				T0.sasizuNo			= T1.SASIZU_NO
			AND	T0.subNo			= T1.SUB_NO
			AND	T0.sagyoSeq			= T1.SAGYO_SEQ
			AND	T0.maxRepairKaisu	= T1.REPAIR_KAISU
			AND	T0.stId				= T1.ST_ID
			AND	T0.workStaTime		= T1.WORK_STA_TIME
		INNER JOIN
			TR_SASIZU_INFO	T2
		ON
			T1.SASIZU_NO	= T2.SASIZU_NO
		INNER JOIN
			MA_HINMOKU	T3
		ON
				T2.BUHIN_CD		= T3.MATNR
		--	AND	T3.INVALID_FLAG	= 0
		INNER JOIN
			MA_STATION	T4
		ON
				T1.ST_ID		= T4.ST_ID
		--	AND	T4.INVALID_FLAG	= 0
		INNER JOIN
			MA_LINE	T5
		ON
				T4.LN_ID		= T5.LN_ID
		--	AND	T5.INVALID_FLAG	= 0
		INNER JOIN
			MA_PROCESS	T6
		ON
				T5.PROCESS_ID	= T6.PROCESS_ID
		--	AND	T6.INVALID_FLAG	= 0
		WHERE
				T1.SAGYO_JYOTAI	= 90
			AND	T1.HANTEI		= 1
			AND	T3.VTEXT_INFO1	IS NOT NULL
		GROUP BY
			T6.SEIZOU_LN_ID,
			T4.LN_ID,
			T1.ST_ID,
			T2.BUHIN_CD,
			DATE_TRUNC('hour', T1.WORK_END_TIME),
			T3.VTEXT_INFO1

		UNION ALL

		-- ラインごと
		SELECT
			T5.SEIZOU_LN_ID					as seizouLnId,
			T1.LN_ID						as lnId,
			CST_ALL_ST_ID					as stId,
			T2.BUHIN_CD						as buhinCd,
			DATE_TRUNC('hour', T1.END_TIME)	as dataDate,
			T3.VTEXT_INFO1					as vtextInfo1,
			MAX(T3.VTEXT_INFO2)				as vtextInfo2,
			MAX(T1.PLANT_CD)				as plantCd,
			MAX(T1.SEIZOU_LN_CD)			as seizouLnCd,
			MAX(T1.SEIZOU_LN_NM)			as seizouLnNm,
			MAX(T1.PROCESS_CD)				as processCd,
			MAX(T1.PROCESS_NM)				as processNm,
			MAX(T1.LN_NO)					as lnNo,
			MAX(T1.LN_NM)					as lnNm,
			NULL							as stNo,
			NULL							as stNm,
			MAX(T1.MODIFIED_ON)				as updDate,
			COUNT(*)						as actualNum,
			SUM(T2.HYOJYUN_GENKA)			as actualValue
		FROM
		(
			SELECT
				SASIZU_NO			as sasizuNo,
				SUB_NO				as subNo,
				SAGYO_SEQ			as sagyoSeq,
				LN_ID				as lnId,
				MAX(REPAIR_KAISU)	as maxRepairKaisu
			FROM
				TR_LINE_WORK_JSK
			WHERE
					PLANT_CD	=	l_plant_cd_wk
				AND	END_TIME	>=	l_proc_start_time_day
				AND	END_TIME	<=	l_proc_end_time_day
			GROUP BY
				SASIZU_NO,
				SUB_NO,
				SAGYO_SEQ,
				LN_ID
		) T0
		INNER JOIN
			TR_LINE_WORK_JSK	T1
		ON
				T0.sasizuNo			= T1.SASIZU_NO
			AND	T0.subNo			= T1.SUB_NO
			AND	T0.sagyoSeq			= T1.SAGYO_SEQ
			AND	T0.maxRepairKaisu	= T1.REPAIR_KAISU
			AND	T0.lnId				= T1.LN_ID
		INNER JOIN
			TR_SASIZU_INFO	T2
		ON
			T1.SASIZU_NO	= T2.SASIZU_NO
		INNER JOIN
			MA_HINMOKU	T3
		ON
				T2.BUHIN_CD		= T3.MATNR
		--	AND	T3.INVALID_FLAG	= 0
		INNER JOIN
			MA_LINE	T4
		ON
				T1.LN_ID		= T4.LN_ID
		--	AND	T4.INVALID_FLAG	= 0
		INNER JOIN
			MA_PROCESS	T5
		ON
				T4.PROCESS_ID	= T5.PROCESS_ID
		--	AND	T5.INVALID_FLAG	= 0
		WHERE
				T1.SAGYO_KEKA	= 90
			AND T3.VTEXT_INFO1	IS NOT NULL
		GROUP BY
			T5.SEIZOU_LN_ID,
			T1.LN_ID,
			T2.BUHIN_CD,
			DATE_TRUNC('hour', T1.END_TIME),
			T3.VTEXT_INFO1

		UNION ALL

		-- 製造ラインごと
		SELECT
			T1.SEIZOU_LN_ID					as seizouLnId,
			CST_ALL_LN_ID					as lnId,
			CST_ALL_ST_ID					as stId,
			T2.BUHIN_CD						as buhinCd,
			DATE_TRUNC('hour', T1.END_DATE)	as dataDate,
			T3.VTEXT_INFO1					as vtextInfo1,
			MAX(T3.VTEXT_INFO2)				as vtextInfo2,
			MAX(T4.PLANT_CD)				as plantCd,
			MAX(T1.SEIZOU_LN_CD)			as seizouLnCd,
			MAX(T1.SEIZOU_LN_NM)			as seizouLnNm,
			NULL							as processCd,
			NULL							as processNm,
			NULL							as lnNo,
			NULL							as lnNm,
			NULL							as stNo,
			NULL							as stNm,
			MAX(T1.MODIFIED_ON)				as updDate,
			COUNT(*)						as actualNum,
			SUM(T2.HYOJYUN_GENKA)			as actualValue
		FROM
			TR_PRODUCT_TRC	T1
		INNER JOIN
			TR_SASIZU_INFO	T2
		ON
			T1.SASIZU_NO	= T2.SASIZU_NO
		INNER JOIN
			MA_HINMOKU	T3
		ON
				T2.BUHIN_CD	= T3.MATNR
		--	AND	T3.INVALID_FLAG	= 0
		INNER JOIN
			MA_SEIZOU_LINE	T4
		ON
				T1.SEIZOU_LN_ID	= T4.SEIZOU_LN_ID
		--	AND	T4.INVALID_FLAG	= 0
		WHERE
				T4.PLANT_CD			=	l_plant_cd_wk
			AND	T1.SEISAN_JYOTAI	=	90
			AND	T1.HANTEI			=	1
			AND	T1.END_DATE			>=	l_proc_start_time_day
			AND	T1.END_DATE			<=	l_proc_end_time_day
			AND T3.VTEXT_INFO1		IS NOT NULL
		GROUP BY
			T1.SEIZOU_LN_ID,
			T2.BUHIN_CD,
			DATE_TRUNC('hour', T1.END_DATE),
			T3.VTEXT_INFO1
	;

	OPENFLG_TR_TRACE_LOG		int;	-- カーソルオープン状態

	------------------------------------------------------------
	-- 格納先
	------------------------------------------------------------
	-- 製品生産計画実績(時間別)
	CUR_AG_PRODUCT_MNG_HOURLY	CURSOR FOR
		SELECT
			  *
		FROM
			AG_PRODUCT_MNG_HOURLY
		WHERE
				SEIZOU_LN_ID	= l_seizou_ln_id
			AND	LN_ID 			= l_ln_id
			AND	ST_ID			= l_st_id
			AND	BUHIN_CD		= l_buhin_cd
			AND	DATA_DATE		= l_data_date
			AND	VTEXT_INFO1		= l_vtext_info1
		FOR UPDATE NOWAIT
	;

	OPENFLG_AG_PRODUCT_MNG_HOURLY	int;	-- カーソルオープン状態
	REC_AG_PRODUCT_MNG_HOURLY		AG_PRODUCT_MNG_HOURLY%ROWTYPE;

BEGIN
	----------------------------------------------------------------------------
	--						初期処理
	----------------------------------------------------------------------------
	raise info 'Start Function [%]', clock_timestamp()::timestamp;

	-- 共通変数初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S001';

	-- 共通出力パラメータ初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
	o_ret_cd	:= RET_OK;
	o_sqlerr	:= ' ';
	o_errmsg	:= ' ';
	o_errpnt	:= ' ';

	-- 関数実行日時
	l_exec_datetime := clock_timestamp();

	-- 集計開始/終了日時補正
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
	IF i_from_time IS NULL THEN
		i_from_time := l_exec_datetime;
	END IF;
	IF i_to_time IS NULL OR i_from_time > i_to_time THEN
		i_to_time := l_exec_datetime;
	END IF;

	-- ローカル変数初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S004';
	OPENFLG_MA_PLANT := CST_FALSE;
	OPENFLG_AG_PRODUCT_MNG_HOURLY_CLEAR := CST_FALSE;
	OPENFLG_TR_TRACE_LOG := CST_FALSE;
	OPENFLG_AG_PRODUCT_MNG_HOURLY := CST_FALSE;

	----------------------------------------------------------------------------
	-- メイン処理
	----------------------------------------------------------------------------
	<< MAIN_LOOP >>
	LOOP

		------------------------------------------------------------------------
		-- 工場ごとに稼働開始日時が異なるので、工場マスタで処理を回す
		------------------------------------------------------------------------
		-- 工場マスタを開いているならクローズ
		l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
		IF OPENFLG_MA_PLANT = CST_TRUE THEN
			CLOSE CUR_MA_PLANT;
			OPENFLG_MA_PLANT := CST_FALSE;
		END IF;

		-- 工場マスタをオープン
		l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
		OPEN CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_TRUE;

		<< PLANT_LOOP >>
		LOOP
			-- 工場マスタからフェッチ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_103';
			FETCH CUR_MA_PLANT INTO l_plant_cd_wk, l_running_start_datetime;
			IF FOUND = FALSE THEN
				EXIT PLANT_LOOP;
			END IF;

			IF l_running_start_datetime IS NULL THEN
				-- NULLの場合はデフォルト値をセット
				l_err_pnt := RTRIM(cst_MY_PRG) || '_104';
				l_running_start_datetime = timestamp '0001-03-21 07:00:00';
			END IF;

			-- 処理開始日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_105';
			SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_all;
			<< START_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_106';
				IF i_from_time >= l_proc_start_time_all THEN
					EXIT START_TIME_LOOP;
				END IF;
				l_proc_start_time_all := l_proc_start_time_all + interval '-1 days';
			END LOOP	START_TIME_LOOP;

			-- 処理終了日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_107';
			SELECT l_proc_start_time_all + interval '1 days' + interval '-1 milliseconds' INTO l_proc_end_time_all;
			<< END_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_108';
				IF i_to_time <= l_proc_end_time_all THEN
					EXIT END_TIME_LOOP;
				END IF;
				l_proc_end_time_all := l_proc_end_time_all + interval '1 days';
			END LOOP	END_TIME_LOOP;

			-- 処理開始/終了(日)日時
			l_err_pnt := RTRIM(cst_MY_PRG) || '_109';
			l_proc_start_time_day := l_proc_start_time_all;
			l_proc_end_time_day := l_proc_start_time_day + interval '1 days' + interval '-1 milliseconds';

			------------------------------------
			-- 実績数を一旦クリア
			------------------------------------
			-- 製品生産計画実績(時間別)(クリア用)を開いているならクローズ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
			IF OPENFLG_AG_PRODUCT_MNG_HOURLY_CLEAR = CST_TRUE THEN
				CLOSE CUR_AG_PRODUCT_MNG_HOURLY_CLEAR;
				OPENFLG_AG_PRODUCT_MNG_HOURLY_CLEAR := CST_FALSE;
			END IF;

			-- 製品生産計画実績(時間別)(クリア用)をオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_202';
			OPEN CUR_AG_PRODUCT_MNG_HOURLY_CLEAR;
			OPENFLG_AG_PRODUCT_MNG_HOURLY_CLEAR := CST_TRUE;

			<< PRODUCT_MANAGEMENT_HOURLY_CLEAR_LOOP >>
			LOOP
				-- 製品生産計画実績(時間別)(クリア用)からフェッチ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_203';
				FETCH CUR_AG_PRODUCT_MNG_HOURLY_CLEAR INTO REC_AG_PRODUCT_MNG_HOURLY_CLEAR;
				IF FOUND = FALSE THEN
					-- 該当データがない場合
					EXIT PRODUCT_MANAGEMENT_HOURLY_CLEAR_LOOP;
				END IF;

				-- 製品生産計画実績(時間別)を更新
				l_err_pnt := RTRIM(cst_MY_PRG) || '_204';
				UPDATE
					AG_PRODUCT_MNG_HOURLY
				SET
					  ACTUAL_THE_DAY_NUM	= -1				-- 実績台数
					, ACTUAL_THE_DAY_VALUE	= -1				-- 実績金額
					, UPD_PROG				= cst_MY_PRG		-- 更新プログラム
					, UPD_TIM				= l_exec_datetime	-- 更新日時
					, UPD_USER_SID			= i_user_sid		-- 更新ユーザSID
				WHERE CURRENT OF CUR_AG_PRODUCT_MNG_HOURLY_CLEAR;
			END LOOP	PRODUCT_MANAGEMENT_HOURLY_CLEAR_LOOP;

			<< TIME_DAY_LOOP >>
			LOOP
				----------------------------------------------------------------------------
				-- 実績数取得
				----------------------------------------------------------------------------
				-- 各種トレースログ(作業用)を開いているならクローズ
				l_err_pnt := RTRIM(cst_MY_PRG) || '_301';
				IF OPENFLG_TR_TRACE_LOG = CST_TRUE THEN
					CLOSE CUR_TR_TRACE_LOG;
					OPENFLG_TR_TRACE_LOG := CST_FALSE;
				END IF;

				-- 各種トレースログ(作業用)をオープン
				l_err_pnt := RTRIM(cst_MY_PRG) || '_302';
				OPEN CUR_TR_TRACE_LOG;
				OPENFLG_TR_TRACE_LOG := CST_TRUE;

				<< TRACE_LOG_LOOP >>
				LOOP
					l_err_pnt := RTRIM(cst_MY_PRG) || '_303';
					FETCH CUR_TR_TRACE_LOG INTO l_seizou_ln_id, l_ln_id, l_st_id, l_buhin_cd, l_data_date, l_vtext_info1, l_vtext_info2, l_plant_cd, l_seizou_ln_cd, l_seizou_ln_nm, l_process_cd, l_process_nm, l_ln_no, l_ln_nm, l_st_no, l_st_nm, l_upd_date, l_actual_the_day_num, l_actual_the_day_value_wk;
					IF FOUND = FALSE THEN
						-- 該当データがない場合
						EXIT TRACE_LOG_LOOP;
					END IF;

					l_actual_the_day_value := CAST( l_actual_the_day_value_wk as integer );

					-- 製品生産計画実績(時間別)にデータがあるか確認
					l_err_pnt := RTRIM(cst_MY_PRG) || '_304';
					IF OPENFLG_AG_PRODUCT_MNG_HOURLY = CST_TRUE THEN
						CLOSE CUR_AG_PRODUCT_MNG_HOURLY;
						OPENFLG_AG_PRODUCT_MNG_HOURLY := CST_FALSE;
					END IF;

					-- 製品生産計画実績(時間別)をオープン
					l_err_pnt := RTRIM(cst_MY_PRG) || '_305';
					OPEN CUR_AG_PRODUCT_MNG_HOURLY;
					OPENFLG_AG_PRODUCT_MNG_HOURLY := CST_TRUE;

					l_err_pnt := RTRIM(cst_MY_PRG) || '_306';
					FETCH CUR_AG_PRODUCT_MNG_HOURLY INTO REC_AG_PRODUCT_MNG_HOURLY;
					IF FOUND = FALSE THEN
						-- 製品生産計画実績(時間別)に格納
						l_err_pnt := RTRIM(cst_MY_PRG) || '_307';
						INSERT INTO AG_PRODUCT_MNG_HOURLY
						(
							  SEIZOU_LN_ID							-- 製造ラインID
							, LN_ID									-- ラインID
							, ST_ID									-- ステーションID
							, BUHIN_CD								-- 品目コード
							, DATA_DATE								-- データ日時
							, VTEXT_INFO1 							-- 品目階層TEXT_その1
							, VTEXT_INFO2 							-- 品目階層TEXT_その2
							, PLANT_CD								-- プラントコード
							, SEIZOU_LN_CD							-- 製造ラインコード
							, SEIZOU_LN_NM							-- 製造ライン名
							, PROCESS_CD							-- 工程コード
							, PROCESS_NM							-- 工程名称
							, LN_NO									-- ラインNo
							, LN_NM									-- ライン名称
							, ST_NO									-- ステーションNo
							, ST_NM									-- ステーション名称
							, UPD_DATE								-- 更新日時
							, PLAN_THE_DAY_NUM						-- 計画(当日)台数
							, PLAN_BEFORE_THE_DAY_NUM 				-- 計画(前日)台数
							, PLAN_BEFORE_TWO_DAYS_NUM				-- 計画(前々日)台数
							, ACTUAL_THE_DAY_NUM					-- 実績(当日)台数
							, PLAN_THE_DAY_VALUE					-- 計画(当日)金額
							, PLAN_BEFORE_THE_DAY_VALUE				-- 計画(前日)金額
							, PLAN_BEFORE_TWO_DAYS_VALUE			-- 計画(前々日)金額
							, ACTUAL_THE_DAY_VALUE					-- 実績(当日)金額
							, INS_PROG								-- 登録プログラム名
							, INS_TIM 								-- 登録日時
							, INS_USER_SID							-- 登録ユーザSID
							, UPD_PROG								-- 更新プログラム名
							, UPD_TIM 								-- 更新日時
							, UPD_USER_SID							-- 更新ユーザSID
						)
						VALUES
						(
							  l_seizou_ln_id						-- 製造ラインID
							, l_ln_id								-- ラインID
							, l_st_id								-- ステーションID
							, l_buhin_cd							-- 品目コード
							, l_data_date							-- データ日時
							, l_vtext_info1 						-- 品目階層TEXT_その1
							, l_vtext_info2 						-- 品目階層TEXT_その2
							, l_plant_cd							-- プラントコード
							, l_seizou_ln_cd						-- 製造ラインコード
							, l_seizou_ln_nm						-- 製造ライン名
							, l_process_cd							-- 工程コード
							, l_process_nm							-- 工程名称
							, l_ln_no								-- ラインNo
							, l_ln_nm								-- ライン名称
							, l_st_no								-- ステーションNo
							, l_st_nm								-- ステーション名称
							, l_upd_date							-- 更新日時
							, -1									-- 計画(当日)台数
							, -1 									-- 計画(前日)台数
							, -1									-- 計画(前々日)台数
							, l_actual_the_day_num					-- 実績(当日)台数
							, -1									-- 計画(当日)金額
							, -1									-- 計画(前日)金額
							, -1									-- 計画(前々日)金額
							, l_actual_the_day_value				-- 実績(当日)金額
							, cst_MY_PRG							-- 登録プログラム名
							, l_exec_datetime						-- 登録日時
							, i_user_sid							-- 登録ユーザSID
							, cst_MY_PRG							-- 更新プログラム名
							, l_exec_datetime						-- 更新日時
							, i_user_sid							-- 更新ユーザSID
						);
					ELSE
						-- 製品生産計画実績(時間別)の実績台数と実績金額を更新
						l_err_pnt := RTRIM(cst_MY_PRG) || '_308';
						UPDATE AG_PRODUCT_MNG_HOURLY SET
							  VTEXT_INFO2					= l_vtext_info2 				-- 品目階層TEXT_その2
							, PLANT_CD						= l_plant_cd					-- プラントコード
							, SEIZOU_LN_CD					= l_seizou_ln_cd				-- 製造ラインコード
							, SEIZOU_LN_NM					= l_seizou_ln_nm				-- 製造ライン名
							, PROCESS_CD					= l_process_cd					-- 工程コード
							, PROCESS_NM					= l_process_nm					-- 工程名称
							, LN_NO 						= l_ln_no						-- ラインNo
							, LN_NM 						= l_ln_nm						-- ライン名称
							, ST_NO 						= l_st_no						-- ステーションNo
							, ST_NM 						= l_st_nm						-- ステーション名称
							, UPD_DATE						= l_upd_date					-- 更新日時
							, ACTUAL_THE_DAY_NUM			= l_actual_the_day_num			-- 実績(当日)台数
							, ACTUAL_THE_DAY_VALUE			= l_actual_the_day_value		-- 実績(当日)金額
							, UPD_PROG						= cst_MY_PRG					-- 更新プログラム
							, UPD_TIM						= l_exec_datetime				-- 更新日時
							, UPD_USER_SID					= i_user_sid					-- 更新ユーザSID
						WHERE CURRENT OF CUR_AG_PRODUCT_MNG_HOURLY;
					END IF;

				END LOOP	TRACE_LOG_LOOP;

				-- 次の処理日時(日)を設定
				l_err_pnt := RTRIM(cst_MY_PRG) || '_401';
				l_proc_start_time_day	:= l_proc_start_time_day + interval '1 days';
				l_proc_end_time_day 	:= l_proc_end_time_day + interval '1 days';

				-- 処理開始日時(日)が処理終了日時(全体)を超えている場合は処理終了
				l_err_pnt := RTRIM(cst_MY_PRG) || '_402';
				IF l_proc_end_time_all < l_proc_start_time_day THEN
					EXIT TIME_DAY_LOOP;
				END IF;

			END LOOP	TIME_DAY_LOOP;

		END LOOP	PLANT_LOOP;

		-- すべてが無効値となった場合は、レコード削除
		l_err_pnt := RTRIM(cst_MY_PRG) || '_501';
		DELETE FROM
			AG_PRODUCT_MNG_HOURLY
		WHERE
				PLAN_THE_DAY_NUM			= -1
			AND	PLAN_BEFORE_THE_DAY_NUM		= -1
			AND	PLAN_BEFORE_TWO_DAYS_NUM	= -1
			AND	ACTUAL_THE_DAY_NUM			= -1
			AND	PLAN_THE_DAY_VALUE			= -1
			AND	PLAN_BEFORE_THE_DAY_VALUE	= -1
			AND	PLAN_BEFORE_TWO_DAYS_VALUE	= -1
			AND	ACTUAL_THE_DAY_VALUE		= -1
		;

		EXIT MAIN_LOOP;

	END LOOP	MAIN_LOOP;

	----------------------------------------------------------------------------
	--						終了処理
	----------------------------------------------------------------------------
	-- カーソルクローズ
	l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
	IF OPENFLG_MA_PLANT = CST_TRUE THEN
		CLOSE CUR_MA_PLANT;
		OPENFLG_MA_PLANT := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E002';
	IF OPENFLG_AG_PRODUCT_MNG_HOURLY_CLEAR = CST_TRUE THEN
		CLOSE CUR_AG_PRODUCT_MNG_HOURLY_CLEAR;
		OPENFLG_AG_PRODUCT_MNG_HOURLY_CLEAR := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
	IF OPENFLG_TR_TRACE_LOG = CST_TRUE THEN
		CLOSE CUR_TR_TRACE_LOG;
		OPENFLG_TR_TRACE_LOG := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E004';
	IF OPENFLG_AG_PRODUCT_MNG_HOURLY = CST_TRUE THEN
		CLOSE CUR_AG_PRODUCT_MNG_HOURLY;
		OPENFLG_AG_PRODUCT_MNG_HOURLY := CST_FALSE;
	END IF;

	raise info 'End Function [%]', clock_timestamp()::timestamp;

EXCEPTION WHEN OTHERS THEN
	-- DB例外情報収集
	GET STACKED DIAGNOSTICS rtn_sql_no	   = RETURNED_SQLSTATE,
							rtn_sql_msg    = MESSAGE_TEXT,
							rtn_sql_detail = PG_EXCEPTION_DETAIL,
							rtn_sql_hint   = PG_EXCEPTION_HINT,
							rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

	raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
	raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

	o_ret_cd := RET_NG;
	o_sqlerr := substr(rtn_sql_no, 1, 15);
	o_errmsg := substr(rtn_sql_msg, 1, 127);
	o_errpnt := l_err_pnt;

	raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;