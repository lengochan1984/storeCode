﻿CREATE or REPLACE FUNCTION func_preload_level_daily(
	in	i_batch_name	varchar,			-- バッチ処理名称
	in	i_log_type		numeric,			-- ログ種別(開始、および　各バッチ処理の復帰値)
											-- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
	in	i_user_sid		numeric,			-- 登録ユーザSID
	in	i_from_time		timestamp,			-- 集計開始日時
	in	i_to_time		timestamp,			-- 集計終了日時
	out	o_ret_cd		int,				-- 関数復帰値	RET_OK(= 0):正常終了
	out	o_sqlerr		varchar,			-- ＤＢ異常発生時のエラーコード
	out	o_errmsg		varchar,			-- 異常発生時のエラーメッセージ
	out	o_errpnt		varchar				-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　未来生産負荷状況(日別)作成サービス
--　ソースプログラム名　：　func_preload_level_daily.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　未来生産負荷状況(日別)を作成する
--
--　履歴
--  Ver.  作成日			作成者		COMMENT
--  1.0   2017/03/03		H.Nakamura	新規作成
--******************************************************************************
DECLARE
	----------------------------------------------------------------------------
	--						標準定数定義
	----------------------------------------------------------------------------
	-- 戻り値
	RET_OK		CONSTANT int := 0 ;						-- 正常終了コード
	RET_NG		CONSTANT int := -1 ;					-- 異常終了コード
	-- 真偽値
	CST_TRUE	CONSTANT int := 1 ;						-- 真
	CST_FALSE	CONSTANT int := 0 ;						-- 偽

	----------------------------------------------------------------------------
	--						標準変数定義
	----------------------------------------------------------------------------
	cst_MY_PRG	CONSTANT CHAR(32)	 := 'func_preload_level_daily';			-- プログラム名
	cst_UPD_TIM	CHAR(17) ;													-- 更新時間
	l_err_pnt	CHAR(64) ;													-- エラー発生ポイント
	errbuff		varchar(256);												-- メッセージバッファ

	----------------------------------------------------------------------------
	--						定数定義
	----------------------------------------------------------------------------
	CST_ALL_LINE_NO		CONSTANT char(20)	:= '-1';			-- ライン番号
	CST_CLASS_SHORTAGE	CONSTANT varchar(4)	:= '欠品';			-- 材完チェック区分：欠品

	----------------------------------------------------------------------------
	--						変数定義
	----------------------------------------------------------------------------
	-- 共通変数
	rtn_sql_no		text;							-- DBエラー情報(エラー番号)
	rtn_sql_msg		text;							-- DBエラー情報(エラーメッセージ)
	rtn_sql_detail	text;							-- DBエラー情報(エラー詳細)
	rtn_sql_hint	text;							-- DBエラー情報(エラーヒント)
	rtn_sql_stack	text;							-- DBエラー情報(エラー発生呼出しスタック)

	-- ローカル変数
	l_exec_datetime					timestamp;		-- 関数実行日時
	l_proc_exec_time				timestamp;		-- 関数実行日(開始日時)
	l_proc_exec_time_yesterday		timestamp;		-- 関数実行日前日(開始日時)
	l_proc_start_time				timestamp;		-- 処理開始日
	l_proc_end_time					timestamp;		-- 処理終了日
	l_proc_start_time_all			timestamp;		-- 処理開始日(全体)
	l_proc_end_time_all				timestamp;		-- 処理終了日(全体)
	l_running_start_datetime		timestamp;		-- 稼働開始日時(年度開始日時)
	l_upd_date						timestamp;		-- 更新日時
	l_plant_code					char(2);		-- 工場コード
	l_plant_code_wk					char(2);		-- 工場コード(作業用)
	l_seizou_line_cd				char(5);		-- 製造ラインコード
	l_line_no						char(20);		-- ライン番号
	l_planned_order_unknown_num		int;			-- 計画手配(未定)台数
	l_planned_order_shortage_num	int;			-- 計画手配(欠品)台数
	l_planned_order_zaikan_num		int;			-- 計画手配(材完)台数
	l_production_order_shortage_num	int;			-- 製造指図(欠品)台数
	l_production_order_zaikan_num	int;			-- 製造指図(材完)台数
	l_actual_num					int;			-- 実績台数
	l_order_delay_num				int;			-- オーダー遅れ台数
	l_stock_delay_num				int;			-- 在庫遅れ台数

	----------------------------------------------------------------------------
	--						カーソル定義
	----------------------------------------------------------------------------
	-- 工場マスタ
	CUR_MST_PLANT	CURSOR FOR
		SELECT
			T0.PLANT_CODE				as plantCode,
			T1.RUNNING_START_DATETIME	as runningStartDatetime
		FROM
			MST_PLANT	T0
		LEFT OUTER JOIN
			MST_PLANT_MIERUKA	T1
		ON
				T1.PLANT_CODE	= T0.PLANT_CODE
			AND	T1.INVALID_FLAG	= 0
		WHERE
			T0.INVALID_FLAG = 0
		ORDER BY
			T0.PLANT_CODE
	;

	OPENFLG_MST_PLANT	int;	-- カーソルオープン状態


	-- 指図追番単位計画/追番単位計画手配データ更新日時取得
	CUR_GET_UPD_DATE	CURSOR FOR
		SELECT
			MIN(T.updDate)
		FROM
		(
			-- 指図追番単位計画
			SELECT
				MAX(UPD_DATE)	AS updDate
			FROM
				TBL_SEIHIN_PLAN
			WHERE
				PLANT_CODE = l_plant_code_wk

			UNION ALL

			-- 追番単位計画手配データ
			SELECT
				MAX(UPD_DATE)	AS updDate
			FROM
				TBL_ORDER_PLAN
			WHERE
				PLANT_CODE = l_plant_code_wk
		)T
	;

	OPENFLG_GET_UPD_DATE		int;	-- カーソルオープン状態


	-- 未来生産負荷状況(日別)データ【実績】取得
	CUR_GET_PRELOAD_LEVEL_ACTUAL_NUM	CURSOR FOR
		SELECT
			T.plantCode		as plantCode,
			T.seizouLineCd	as seizouLineCd,
			T.lineNo		as lineNo,
			-1				as plannedOrderUnknownNum,
			-1				as plannedOrderShortageNum,
			-1				as plannedOrderZaikanNum,
			-1				as productionOrderShortageNum,
			-1				as productionOrderZaikanNum,
			T.actualNum		as actualNum,
			-1				as orderDelayNum,
			-1				as stockDelayNum
		FROM
		(
			-- 製造ラインごと
			SELECT
				T1.PLANT_CODE		as plantCode,
				T2.SEIZOU_LINE_CD	as seizouLineCd,
				CST_ALL_LINE_NO		as lineNo,
				COUNT(*)			as actualNum
			FROM
				TBL_PRODUCT_TRACE_LOG_WK T0
			INNER JOIN
				TBL_SASHIZU_MANAGEMENT T1
			ON
				T0.SASIZU_NO = T1.SASIZU_NO
			INNER JOIN
				MST_LINE T2
			ON
					T2.INVALID_FLAG	= 0
				AND	T1.PLANT_CODE	= T2.PLANT_CODE
				AND	T0.LINE_NO		= T2.LINE_NO
			INNER JOIN
				MST_SEIZOU_LINE	T3
			ON
					T3.INVALID_FLAG		= 0
				AND	T3.PLANNING_SYSTEM	= 1
				AND	T2.PLANT_CODE		= T3.PLANT_CODE
				AND	T2.SEIZOU_LINE_CD	= T3.SEIZOU_LINE_CD
			WHERE
					T1.PLANT_CODE				=	l_plant_code_wk
				AND	T0.ACTUAL_START_DATETIME	>=	l_proc_start_time
				AND	T0.ACTUAL_START_DATETIME	<=	l_proc_end_time
			GROUP BY
				plantCode,
				seizouLineCd,
				lineNo

			UNION ALL

			-- ラインごと
			SELECT
				T1.plantCode		as plantCode,
				T3.SEIZOU_LINE_CD	as seizouLineCd,
				T1.lineNo			as lineNo,
				COUNT(*)			as actualNum
			FROM
			(
				SELECT
					SASIZU_NO			as sashizuNo,
					SUB_NO				as subNo,
					PLANT_CODE			as plantCode,
					LINE_NO				as lineNo,
					MAX(REPAIR_KAISU)	as maxRepairKaisu
				FROM
					TBL_LINE_TRACE_LOG_WK
				WHERE
						PLANT_CODE		=	l_plant_code_wk
					AND	START_DATETIME	>=	l_proc_start_time
					AND	START_DATETIME	<=	l_proc_end_time
				GROUP BY
					SASIZU_NO, SUB_NO, PLANT_CODE, LINE_NO
			) T1
			INNER JOIN
				TBL_LINE_TRACE_LOG_WK T2
			ON
					T2.SASIZU_NO		=	T1.sashizuNo
				AND	T2.SUB_NO			=	T1.subNo
				AND	T2.PLANT_CODE		=	T1.plantCode
				AND	T2.LINE_NO			=	T1.lineNo
				AND	T2.REPAIR_KAISU		=	T1.maxRepairKaisu
				AND	T2.START_DATETIME	>=	l_proc_start_time
				AND	T2.START_DATETIME	<=	l_proc_end_time
			INNER JOIN
				MST_LINE T3
			ON
					T3.INVALID_FLAG	= 0
				AND	T1.plantCode	= T3.PLANT_CODE
				AND	T1.lineNo		= T3.LINE_NO
			INNER JOIN
				MST_SEIZOU_LINE	T4
			ON
					T4.INVALID_FLAG		= 0
				AND	T4.PLANNING_SYSTEM	= 1
				AND	T3.PLANT_CODE		= T4.PLANT_CODE
				AND	T3.SEIZOU_LINE_CD	= T4.SEIZOU_LINE_CD
			GROUP BY
				plantCode,
				seizouLineCd,
				lineNo
		)T
	;

	OPENFLG_GET_PRELOAD_LEVEL_ACTUAL_NUM		int;	-- カーソルオープン状態


	-- 未来生産負荷状況(日別)データ【遅れ(～一昨日)】取得
	CUR_GET_PRELOAD_LEVEL_DELAY_PAST_NUM	CURSOR FOR
		SELECT
			T.plantCode		as plantCode,
			T.seizouLineCd	as seizouLineCd,
			T.lineNo		as lineNo,
			-1				as plannedOrderUnknownNum,
			-1				as plannedOrderShortageNum,
			-1				as plannedOrderZaikanNum,
			-1				as productionOrderShortageNum,
			-1				as productionOrderZaikanNum,
			-1				as actualNum,
			T.orderDelayNum	as orderDelayNum,
			T.stockDelayNum	as stockDelayNum
		FROM
		(
			-- 昨日作成した最新スナップショットのデータから遅れ台数を取得する
			SELECT
				SUB0.PLANT_CODE			as plantCode,
				SUB0.SEIZOU_LINE_CD		as seizouLineCd,
				SUB0.LINE_NO			as lineNo,
				SUB0.ORDER_DELAY_NUM	as orderDelayNum,
				SUB0.STOCK_DELAY_NUM	as stockDelayNum
			FROM
			(
				SELECT
					*,
					ROW_NUMBER() OVER (PARTITION BY PLANT_CODE, SEIZOU_LINE_CD, LINE_NO, DATA_DATE ORDER BY SNAPSHOT_DATE DESC) as rowIndex
				FROM
					TBL_PRELOAD_LEVEL_DAILY
				WHERE
						PLANT_CODE		= l_plant_code_wk
					AND	DATA_DATE		= l_proc_start_time
					AND	SNAPSHOT_DATE	< l_proc_exec_time
				ORDER BY
					PLANT_CODE, SEIZOU_LINE_CD, LINE_NO
			)SUB0
			WHERE
				SUB0.rowIndex = 1
		)T
	;

	OPENFLG_GET_PRELOAD_LEVEL_DELAY_PAST_NUM		int;	-- カーソルオープン状態


	-- 未来生産負荷状況(日別)データ【遅れ(昨日)】取得
	CUR_GET_PRELOAD_LEVEL_DELAY_YESTERDAY_NUM	CURSOR FOR
		SELECT
			T.plantCode		as plantCode,
			T.seizouLineCd	as seizouLineCd,
			T.lineNo		as lineNo,
			-1				as plannedOrderUnknownNum,
			-1				as plannedOrderShortageNum,
			-1				as plannedOrderZaikanNum,
			-1				as productionOrderShortageNum,
			-1				as productionOrderZaikanNum,
			-1				as actualNum,
			SUM(
				CASE WHEN T.orderNo IS NOT NULL AND T.orderNo != '' THEN T.quantity
				ELSE 0
				END
			)				as orderDelayNum,
			SUM(
				CASE WHEN T.orderNo IS NULL OR T.orderNo = '' THEN T.quantity
				ELSE 0
				END
			)				as stockDelayNum
		FROM
		(
			-- 計画手配 - 製造ラインごと
			SELECT
				T0.PLANT_CODE						as plantCode,
				T1.SEIZOU_LINE_CD					as seizouLineCd,
				CST_ALL_LINE_NO						as lineNo,
				SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10)	as keikakutehaiNo,
				T0.SUB_NO							as subNo,
				MAX(T3.ZAIKAN_KBN)					as zaikanKbn,
				MIN(T0.START_DATE)					as startDate,
				MAX(T0.END_DATE)					as endDate,
				MAX(T0.QUANTITY)					as quantity,
				to_timestamp(MAX(T3.FACTORY_DATE) || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYYMMDD HH24:MI:SS.MS') + interval '1days' + interval '-1milliseconds'	as factoryDate,
				MAX(RTRIM(T3.ORDER_NO))				as orderNo
			FROM
				TBL_ORDER_PLAN T0
			INNER JOIN
				MST_LINE T1
			ON
					T1.INVALID_FLAG	= 0
				AND	T0.PLANT_CODE	= T1.PLANT_CODE
				AND	T0.LINE_NO		= T1.LINE_NO
			INNER JOIN
				MST_SEIZOU_LINE T2
			ON
					T2.INVALID_FLAG		= 0
				AND	T2.PLANNING_SYSTEM	= 1
				AND	T1.PLANT_CODE		= T2.PLANT_CODE
				AND	T1.SEIZOU_LINE_CD	= T2.SEIZOU_LINE_CD
			INNER JOIN
				TBL_PLANNED_ORDER T3
			ON
				SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10)	= T3.KEIKAKUTEHAI_NO
			WHERE
					T0.PLANT_CODE	= l_plant_code_wk
				AND	T0.INVALID_FLAG	= 0
				AND	T3.FACTORY_DATE	IS NOT NULL
				AND	T3.FACTORY_DATE	!= '00000000'
			GROUP BY
				T0.PLANT_CODE,
				T1.SEIZOU_LINE_CD,
				SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10),
				T0.SUB_NO

			UNION ALL

			-- 計画手配 - ラインごと
			SELECT
				T0.PLANT_CODE						as plantCode,
				T1.SEIZOU_LINE_CD					as seizouLineCd,
				T0.LINE_NO							as lineNo,
				SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10)	as keikakutehaiNo,
				T0.SUB_NO							as subNo,
				MAX(T3.ZAIKAN_KBN)					as zaikanKbn,
				MIN(T0.START_DATE)					as startDate,
				MAX(T0.END_DATE)					as endDate,
				MAX(T0.QUANTITY)					as quantity,
				to_timestamp(MAX(T3.FACTORY_DATE) || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYYMMDD HH24:MI:SS.MS') + interval '1days' + interval '-1milliseconds'	as factoryDate,
				MAX(RTRIM(T3.ORDER_NO))	as orderNo
			FROM
				TBL_ORDER_PLAN T0
			INNER JOIN
				MST_LINE T1
			ON
					T1.INVALID_FLAG	= 0
				AND	T0.PLANT_CODE	= T1.PLANT_CODE
				AND	T0.LINE_NO		= T1.LINE_NO
			INNER JOIN
				MST_SEIZOU_LINE T2
			ON
					T2.INVALID_FLAG		= 0
				AND	T2.PLANNING_SYSTEM	= 1
				AND	T1.PLANT_CODE		= T2.PLANT_CODE
				AND	T1.SEIZOU_LINE_CD	= T2.SEIZOU_LINE_CD
			INNER JOIN
				TBL_PLANNED_ORDER T3
			ON
				SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10)	= T3.KEIKAKUTEHAI_NO
			WHERE
					T0.PLANT_CODE	= l_plant_code_wk
				AND	T0.INVALID_FLAG	= 0
				AND	T3.FACTORY_DATE	IS NOT NULL
				AND	T3.FACTORY_DATE	!= '00000000'
			GROUP BY
				T0.PLANT_CODE,
				T1.SEIZOU_LINE_CD,
				T0.LINE_NO,
				SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10),
				T0.SUB_NO

			UNION ALL

			-- 製造指図 - 製造ラインごと
			SELECT
				T0.PLANT_CODE			as plantCode,
				T1.SEIZOU_LINE_CD		as seizouLineCd,
				CST_ALL_LINE_NO			as lineNo,
				T0.SASIZU_NO			as sasizuNo,
				T0.SUB_NO				as subNo,
				MAX(T3.SASIZU_KEP_KBN)	as sasizuKepKbn,
				MIN(T0.START_DATE)		as startDate,
				MAX(T0.END_DATE)		as endDate,
				MAX(T0.QUANTITY)		as quantity,
				to_timestamp(MAX(T3.FACTORY_DATE) || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYYMMDD HH24:MI:SS.MS') + interval '1days' + interval '-1milliseconds'	as factoryDate,
				MAX(RTRIM(T3.ORDER_NO))	as orderNo
			FROM
				TBL_SEIHIN_PLAN T0
			INNER JOIN
				MST_LINE T1
			ON
					T1.INVALID_FLAG	= 0
				AND	T0.PLANT_CODE	= T1.PLANT_CODE
				AND	T0.LINE_NO		= T1.LINE_NO
			INNER JOIN
				MST_SEIZOU_LINE T2
			ON
					T2.INVALID_FLAG		= 0
				AND	T2.PLANNING_SYSTEM	= 1
				AND	T1.PLANT_CODE		= T2.PLANT_CODE
				AND	T1.SEIZOU_LINE_CD	= T2.SEIZOU_LINE_CD
			INNER JOIN
				TBL_SASHIZU_MANAGEMENT T3
			ON
				T0.SASIZU_NO	= T3.SASIZU_NO
			LEFT OUTER JOIN
				TBL_PRODUCT_TRACE_LOG T4
			ON
					T4.SASIZU_NO			= T0.SASIZU_NO
				AND	T4.SUB_NO				= T0.SUB_NO
				-- 昨日までに終わっているもの
				AND	T4.seisan_jyotai		= 90
				AND	T4.hantei				= 1
				AND	T4.actual_end_datetime	< l_proc_exec_time
			WHERE
					T0.PLANT_CODE	= l_plant_code_wk
				AND	T0.INVALID_FLAG	= 0
				AND	T3.FACTORY_DATE	IS NOT NULL
				AND	T3.FACTORY_DATE	!= '00000000'
				-- T4が連結されなかったもの＝昨日までに終わっていないもの
				AND	T4.SASIZU_NO	IS NULL
			GROUP BY
				T0.PLANT_CODE,
				T1.SEIZOU_LINE_CD,
				T0.SASIZU_NO,
				T0.SUB_NO

			UNION ALL

			-- 製造指図 - ラインごと
			SELECT
				T0.PLANT_CODE			as plantCode,
				T1.SEIZOU_LINE_CD		as seizouLineCd,
				T0.LINE_NO				as lineNo,
				T0.SASIZU_NO			as sasizuNo,
				T0.SUB_NO				as subNo,
				MAX(T3.SASIZU_KEP_KBN)	as sasizuKepKbn,
				MIN(T0.START_DATE)		as startDate,
				MAX(T0.END_DATE)		as endDate,
				MAX(T0.QUANTITY)		as quantity,
				to_timestamp(MAX(T3.FACTORY_DATE) || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYYMMDD HH24:MI:SS.MS') + interval '1days' + interval '-1milliseconds'	as factoryDate,
				MAX(RTRIM(T3.ORDER_NO))	as orderNo
			FROM
				TBL_SEIHIN_PLAN T0
			INNER JOIN
				MST_LINE T1
			ON
					T1.INVALID_FLAG	= 0
				AND	T0.PLANT_CODE	= T1.PLANT_CODE
				AND	T0.LINE_NO		= T1.LINE_NO
			INNER JOIN
				MST_SEIZOU_LINE T2
			ON
					T2.INVALID_FLAG		= 0
				AND	T2.PLANNING_SYSTEM	= 1
				AND	T1.PLANT_CODE		= T2.PLANT_CODE
				AND	T1.SEIZOU_LINE_CD	= T2.SEIZOU_LINE_CD
			INNER JOIN
				TBL_SASHIZU_MANAGEMENT T3
			ON
				T0.SASIZU_NO	= T3.SASIZU_NO
			LEFT OUTER JOIN
			(
				SELECT
					*
				FROM
				(
					SELECT
						*,
						ROW_NUMBER() OVER (PARTITION BY SASIZU_NO, SUB_NO, PLANT_CODE, LINE_NO ORDER BY REPAIR_KAISU DESC) as rowIndex
					FROM
						TBL_LINE_TRACE_LOG
				)T
				WHERE
					-- リペア回数の最大値
					T.rowIndex = 1
			) T4
			ON
					T4.SASIZU_NO	= T0.sasizu_no
				AND	T4.SUB_NO		= T0.sub_no
				AND	T4.PLANT_CODE	= T0.plant_code
				AND	T4.LINE_NO		= T0.line_no
				-- 昨日までに終わっているもの
				AND	T4.sagyo_keka	= 90
				AND	T4.end_datetime	< l_proc_exec_time
			WHERE
					T0.PLANT_CODE	= l_plant_code_wk
				AND	T0.INVALID_FLAG	= 0
				AND	T3.FACTORY_DATE	IS NOT NULL
				AND	T3.FACTORY_DATE	!= '00000000'
				-- T4が連結されなかったもの＝昨日までに終わっていないもの
				AND	T4.SASIZU_NO	IS NULL
			GROUP BY
				T0.PLANT_CODE,
				T1.SEIZOU_LINE_CD,
				T0.LINE_NO,
				T0.SASIZU_NO,
				T0.SUB_NO
		)T
		WHERE
			-- 指図もしくは計画手配上、当日までに完成することになっているが、
			-- 作業終了予定日時が明日以降で計画されているものは遅れとみなす
				T.factoryDate	<= l_proc_end_time
			AND	T.endDate		>  l_proc_end_time
		GROUP BY
			T.plantCode,
			T.seizouLineCd,
			T.lineNo
	;

	OPENFLG_GET_PRELOAD_LEVEL_DELAY_YESTERDAY_NUM		int;	-- カーソルオープン状態


	-- 未来生産負荷状況(日別)データ【計画手配】取得
	CUR_GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM	CURSOR FOR
		SELECT
			T.plantCode						as plantCode,
			T.seizouLineCd					as seizouLineCd,
			T.lineNo						as lineNo,
			T.plannedOrderUnknownNum		as plannedOrderUnknownNum,
			T.plannedOrderShortageNum		as plannedOrderShortageNum,
			T.plannedOrderZaikanNum			as plannedOrderZaikanNum,
			-1								as productionOrderShortageNum,
			-1								as productionOrderZaikanNum,
			-1								as actualNum,
			-1								as orderDelayNum,
			-1								as stockDelayNum
		FROM
		(
			-- 製造ラインごと
			SELECT
				plantCode,
				seizouLineCd,
				CST_ALL_LINE_NO	as lineNo,
				SUM(
					CASE WHEN zaikanKbn IS NULL THEN quantity
					ELSE 0
					END
				) as plannedOrderUnknownNum,
				SUM(
					CASE WHEN zaikanKbn IS NOT NULL AND zaikanKbn = CST_CLASS_SHORTAGE THEN quantity
					ELSE 0
					END
				) as plannedOrderShortageNum,
				SUM(
					CASE WHEN zaikanKbn IS NOT NULL AND zaikanKbn != CST_CLASS_SHORTAGE THEN quantity
					ELSE 0
					END
				) as plannedOrderZaikanNum
			FROM
			(
				SELECT
					T0.PLANT_CODE						as plantCode,
					T1.SEIZOU_LINE_CD					as seizouLineCd,
					SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10)	as keikakutehaiNo,
					T0.SUB_NO							as subNo,
					MAX(T3.ZAIKAN_KBN)					as zaikanKbn,
					MIN(T0.START_DATE)					as startDate,
					MAX(T0.END_DATE)					as endDate,
					MAX(T0.QUANTITY)					as quantity
				FROM
					TBL_ORDER_PLAN T0
				INNER JOIN
					MST_LINE T1
				ON
						T1.INVALID_FLAG	= 0
					AND	T0.PLANT_CODE	= T1.PLANT_CODE
					AND	T0.LINE_NO		= T1.LINE_NO
				INNER JOIN
					MST_SEIZOU_LINE T2
				ON
						T2.INVALID_FLAG		= 0
					AND	T2.PLANNING_SYSTEM	= 1
					AND	T1.PLANT_CODE		= T2.PLANT_CODE
					AND	T1.SEIZOU_LINE_CD	= T2.SEIZOU_LINE_CD
				INNER JOIN
					TBL_PLANNED_ORDER T3
				ON
					SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10)	= T3.KEIKAKUTEHAI_NO
				WHERE
						T0.PLANT_CODE	= l_plant_code_wk
					AND	T0.INVALID_FLAG	= 0
				GROUP BY
					T0.PLANT_CODE,
					T1.SEIZOU_LINE_CD,
					SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10),
					T0.SUB_NO
			) tblPlannedOrderSeizouLine
			WHERE
					startDate	>= l_proc_start_time
				AND	startDate	<= l_proc_end_time
			GROUP BY
				plantCode,
				seizouLineCd

			UNION ALL

			-- ラインごと
			SELECT
				plantCode,
				seizouLineCd,
				lineNo,
				SUM(
					CASE WHEN zaikanKbn IS NULL THEN quantity
					ELSE 0
					END
				) as plannedOrderUnknownNum,
				SUM(
					CASE WHEN zaikanKbn IS NOT NULL AND zaikanKbn = CST_CLASS_SHORTAGE THEN quantity
					ELSE 0
					END
				) as plannedOrderShortageNum,
				SUM(
					CASE WHEN zaikanKbn IS NOT NULL AND zaikanKbn != CST_CLASS_SHORTAGE THEN quantity
					ELSE 0
					END
				) as plannedOrderZaikanNum
			FROM
			(
				SELECT
					T0.PLANT_CODE						as plantCode,
					T1.SEIZOU_LINE_CD					as seizouLineCd,
					T0.LINE_NO							as lineNo,
					SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10)	as keikakutehaiNo,
					T0.SUB_NO							as subNo,
					MAX(T3.ZAIKAN_KBN)					as zaikanKbn,
					MIN(T0.START_DATE)					as startDate,
					MAX(T0.END_DATE)					as endDate,
					MAX(T0.QUANTITY)					as quantity
				FROM
					TBL_ORDER_PLAN T0
				INNER JOIN
					MST_LINE T1
				ON
						T1.INVALID_FLAG	= 0
					AND	T0.PLANT_CODE	= T1.PLANT_CODE
					AND	T0.LINE_NO		= T1.LINE_NO
				INNER JOIN
					MST_SEIZOU_LINE T2
				ON
						T2.INVALID_FLAG		= 0
					AND	T2.PLANNING_SYSTEM	= 1
					AND	T1.PLANT_CODE		= T2.PLANT_CODE
					AND	T1.SEIZOU_LINE_CD	= T2.SEIZOU_LINE_CD
				INNER JOIN
					TBL_PLANNED_ORDER T3
				ON
					SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10)	= T3.KEIKAKUTEHAI_NO
				WHERE
						T0.PLANT_CODE	= l_plant_code_wk
					AND	T0.INVALID_FLAG	= 0
				GROUP BY
					T0.PLANT_CODE,
					T1.SEIZOU_LINE_CD,
					T0.LINE_NO,
					SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10),
					T0.SUB_NO
			) tblPlannedOrderLine
			WHERE
					startDate	>= l_proc_start_time
				AND	startDate	<= l_proc_end_time
			GROUP BY
				plantCode,
				seizouLineCd,
				lineNo
		)T
	;

	OPENFLG_GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM		int;	-- カーソルオープン状態


	-- 未来生産負荷状況(日別)データ【製造指図】取得
	CUR_GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM	CURSOR FOR
		SELECT
			T.plantCode						as plantCode,
			T.seizouLineCd					as seizouLineCd,
			T.lineNo						as lineNo,
			-1								as plannedOrderUnknownNum,
			-1								as plannedOrderShortageNum,
			-1								as plannedOrderZaikanNum,
			T.productionOrderShortageNum	as productionOrderShortageNum,
			T.productionOrderZaikanNum		as productionOrderZaikanNum,
			-1								as actualNum,
			-1								as orderDelayNum,
			-1								as stockDelayNum
		FROM
		(
			-- 製造ラインごと
			SELECT
				plantCode,
				seizouLineCd,
				CST_ALL_LINE_NO	as lineNo,
				SUM(
					CASE WHEN sasizuKepKbn = CST_CLASS_SHORTAGE THEN quantity
					ELSE 0
					END
				) as productionOrderShortageNum,
				SUM(
					CASE WHEN sasizuKepKbn != CST_CLASS_SHORTAGE THEN quantity
					ELSE 0
					END
				) as productionOrderZaikanNum
			FROM
			(
				SELECT
					T0.PLANT_CODE			as plantCode,
					T1.SEIZOU_LINE_CD		as seizouLineCd,
					T0.SASIZU_NO			as sasizuNo,
					T0.SUB_NO				as subNo,
					MAX(T3.SASIZU_KEP_KBN)	as sasizuKepKbn,
					MIN(T0.START_DATE)		as startDate,
					MAX(T0.END_DATE)		as endDate,
					MAX(T0.QUANTITY)		as quantity
				FROM
					TBL_SEIHIN_PLAN T0
				INNER JOIN
					MST_LINE T1
				ON
						T1.INVALID_FLAG	= 0
					AND	T0.PLANT_CODE	= T1.PLANT_CODE
					AND	T0.LINE_NO		= T1.LINE_NO
				INNER JOIN
					MST_SEIZOU_LINE T2
				ON
						T2.INVALID_FLAG		= 0
					AND	T2.PLANNING_SYSTEM	= 1
					AND	T1.PLANT_CODE		= T2.PLANT_CODE
					AND	T1.SEIZOU_LINE_CD	= T2.SEIZOU_LINE_CD
				INNER JOIN
					TBL_SASHIZU_MANAGEMENT T3
				ON
					T0.SASIZU_NO	= T3.SASIZU_NO
				WHERE
						T0.PLANT_CODE	= l_plant_code_wk
					AND	T0.INVALID_FLAG	= 0
				GROUP BY
					T0.PLANT_CODE,
					T1.SEIZOU_LINE_CD,
					T0.SASIZU_NO,
					T0.SUB_NO
			) tblSeihinPlanSeizouLine
			WHERE
					startDate	>= l_proc_start_time
				AND	startDate	<= l_proc_end_time
				-- 着手分は除外
				AND	NOT EXISTS(
					SELECT
						*
					FROM
						TBL_PRODUCT_TRACE_LOG
					WHERE
							SASIZU_NO	= sasizuNo
						AND	SUB_NO		= subNo
				)
			GROUP BY
				plantCode,
				seizouLineCd

			UNION ALL

			-- ラインごと
			SELECT
				plantCode,
				seizouLineCd,
				lineNo,
				SUM(
					CASE WHEN sasizuKepKbn = CST_CLASS_SHORTAGE THEN quantity
					ELSE 0
					END
				) as productionOrderShortageNum,
				SUM(
					CASE WHEN sasizuKepKbn != CST_CLASS_SHORTAGE THEN quantity
					ELSE 0
					END
				) as productionOrderZaikanNum
			FROM
			(
				SELECT
					T0.PLANT_CODE			as plantCode,
					T1.SEIZOU_LINE_CD		as seizouLineCd,
					T0.LINE_NO				as lineNo,
					T0.SASIZU_NO			as sasizuNo,
					T0.SUB_NO				as subNo,
					MAX(T3.SASIZU_KEP_KBN)	as sasizuKepKbn,
					MIN(T0.START_DATE)		as startDate,
					MAX(T0.END_DATE)		as endDate,
					MAX(T0.QUANTITY)		as quantity
				FROM
					TBL_SEIHIN_PLAN T0
				INNER JOIN
					MST_LINE T1
				ON
						T1.INVALID_FLAG	= 0
					AND	T0.PLANT_CODE	= T1.PLANT_CODE
					AND	T0.LINE_NO		= T1.LINE_NO
				INNER JOIN
					MST_SEIZOU_LINE T2
				ON
						T2.INVALID_FLAG		= 0
					AND	T2.PLANNING_SYSTEM	= 1
					AND	T1.PLANT_CODE		= T2.PLANT_CODE
					AND	T1.SEIZOU_LINE_CD	= T2.SEIZOU_LINE_CD
				INNER JOIN
					TBL_SASHIZU_MANAGEMENT T3
				ON
					T0.SASIZU_NO	= T3.SASIZU_NO
				WHERE
						T0.PLANT_CODE	= l_plant_code_wk
					AND	T0.INVALID_FLAG	= 0
				GROUP BY
					T0.PLANT_CODE,
					T1.SEIZOU_LINE_CD,
					T0.LINE_NO,
					T0.SASIZU_NO,
					T0.SUB_NO
			) tblSeihinPlanLine
			WHERE
					startDate	>= l_proc_start_time
				AND	startDate	<= l_proc_end_time
				-- 着手分は除外
				AND	NOT EXISTS(
					SELECT
						*
					FROM
						TBL_LINE_TRACE_LOG
					WHERE
							PLANT_CODE	= plantCode
						AND	LINE_NO		= lineNo
						AND	SASIZU_NO	= sasizuNo
						AND	SUB_NO		= subNo
				)
			GROUP BY
				plantCode,
				seizouLineCd,
				lineNo
		)T
	;

	OPENFLG_GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM		int;	-- カーソルオープン状態


	-- 未来生産負荷状況(日別)データ【遅れ(当日～)】取得
	CUR_GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM	CURSOR FOR
		SELECT
			T.plantCode		as plantCode,
			T.seizouLineCd	as seizouLineCd,
			T.lineNo		as lineNo,
			-1				as plannedOrderUnknownNum,
			-1				as plannedOrderShortageNum,
			-1				as plannedOrderZaikanNum,
			-1				as productionOrderShortageNum,
			-1				as productionOrderZaikanNum,
			-1				as actualNum,
			SUM(
				CASE WHEN T.orderNo IS NOT NULL AND T.orderNo != '' THEN T.quantity
				ELSE 0
				END
			)				as orderDelayNum,
			SUM(
				CASE WHEN T.orderNo IS NULL OR T.orderNo = '' THEN T.quantity
				ELSE 0
				END
			)				as stockDelayNum
		FROM
		(
			-- 計画手配 - 製造ラインごと
			SELECT
				T0.PLANT_CODE						as plantCode,
				T1.SEIZOU_LINE_CD					as seizouLineCd,
				CST_ALL_LINE_NO						as lineNo,
				SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10)	as keikakutehaiNo,
				T0.SUB_NO							as subNo,
				MAX(T3.ZAIKAN_KBN)					as zaikanKbn,
				MIN(T0.START_DATE)					as startDate,
				MAX(T0.END_DATE)					as endDate,
				MAX(T0.QUANTITY)					as quantity,
				to_timestamp(MAX(T3.FACTORY_DATE) || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYYMMDD HH24:MI:SS.MS') + interval '1days' + interval '-1milliseconds'	as factoryDate,
				MAX(RTRIM(T3.ORDER_NO))				as orderNo
			FROM
				TBL_ORDER_PLAN T0
			INNER JOIN
				MST_LINE T1
			ON
					T1.INVALID_FLAG	= 0
				AND	T0.PLANT_CODE	= T1.PLANT_CODE
				AND	T0.LINE_NO		= T1.LINE_NO
			INNER JOIN
				MST_SEIZOU_LINE T2
			ON
					T2.INVALID_FLAG		= 0
				AND	T2.PLANNING_SYSTEM	= 1
				AND	T1.PLANT_CODE		= T2.PLANT_CODE
				AND	T1.SEIZOU_LINE_CD	= T2.SEIZOU_LINE_CD
			INNER JOIN
				TBL_PLANNED_ORDER T3
			ON
				SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10)	= T3.KEIKAKUTEHAI_NO
			WHERE
					T0.PLANT_CODE	= l_plant_code_wk
				AND	T0.INVALID_FLAG	= 0
				AND	T3.FACTORY_DATE	IS NOT NULL
				AND	T3.FACTORY_DATE	!= '00000000'
			GROUP BY
				T0.PLANT_CODE,
				T1.SEIZOU_LINE_CD,
				SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10),
				T0.SUB_NO

			UNION ALL

			-- 計画手配 - ラインごと
			SELECT
				T0.PLANT_CODE						as plantCode,
				T1.SEIZOU_LINE_CD					as seizouLineCd,
				T0.LINE_NO							as lineNo,
				SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10)	as keikakutehaiNo,
				T0.SUB_NO							as subNo,
				MAX(T3.ZAIKAN_KBN)					as zaikanKbn,
				MIN(T0.START_DATE)					as startDate,
				MAX(T0.END_DATE)					as endDate,
				MAX(T0.QUANTITY)					as quantity,
				to_timestamp(MAX(T3.FACTORY_DATE) || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYYMMDD HH24:MI:SS.MS') + interval '1days' + interval '-1milliseconds'	as factoryDate,
				MAX(RTRIM(T3.ORDER_NO))	as orderNo
			FROM
				TBL_ORDER_PLAN T0
			INNER JOIN
				MST_LINE T1
			ON
					T1.INVALID_FLAG	= 0
				AND	T0.PLANT_CODE	= T1.PLANT_CODE
				AND	T0.LINE_NO		= T1.LINE_NO
			INNER JOIN
				MST_SEIZOU_LINE T2
			ON
					T2.INVALID_FLAG		= 0
				AND	T2.PLANNING_SYSTEM	= 1
				AND	T1.PLANT_CODE		= T2.PLANT_CODE
				AND	T1.SEIZOU_LINE_CD	= T2.SEIZOU_LINE_CD
			INNER JOIN
				TBL_PLANNED_ORDER T3
			ON
				SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10)	= T3.KEIKAKUTEHAI_NO
			WHERE
					T0.PLANT_CODE	= l_plant_code_wk
				AND	T0.INVALID_FLAG	= 0
				AND	T3.FACTORY_DATE	IS NOT NULL
				AND	T3.FACTORY_DATE	!= '00000000'
			GROUP BY
				T0.PLANT_CODE,
				T1.SEIZOU_LINE_CD,
				T0.LINE_NO,
				SUBSTR(T0.KEIKAKUTEHAI_NO, 1, 10),
				T0.SUB_NO

			UNION ALL

			-- 製造指図 - 製造ラインごと
			SELECT
				T0.PLANT_CODE			as plantCode,
				T1.SEIZOU_LINE_CD		as seizouLineCd,
				CST_ALL_LINE_NO			as lineNo,
				T0.SASIZU_NO			as sasizuNo,
				T0.SUB_NO				as subNo,
				MAX(T3.SASIZU_KEP_KBN)	as sasizuKepKbn,
				MIN(T0.START_DATE)		as startDate,
				MAX(T0.END_DATE)		as endDate,
				MAX(T0.QUANTITY)		as quantity,
				to_timestamp(MAX(T3.FACTORY_DATE) || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYYMMDD HH24:MI:SS.MS') + interval '1days' + interval '-1milliseconds'	as factoryDate,
				MAX(RTRIM(T3.ORDER_NO))	as orderNo
			FROM
				TBL_SEIHIN_PLAN T0
			INNER JOIN
				MST_LINE T1
			ON
					T1.INVALID_FLAG	= 0
				AND	T0.PLANT_CODE	= T1.PLANT_CODE
				AND	T0.LINE_NO		= T1.LINE_NO
			INNER JOIN
				MST_SEIZOU_LINE T2
			ON
					T2.INVALID_FLAG		= 0
				AND	T2.PLANNING_SYSTEM	= 1
				AND	T1.PLANT_CODE		= T2.PLANT_CODE
				AND	T1.SEIZOU_LINE_CD	= T2.SEIZOU_LINE_CD
			INNER JOIN
				TBL_SASHIZU_MANAGEMENT T3
			ON
				T0.SASIZU_NO	= T3.SASIZU_NO
			WHERE
					T0.PLANT_CODE	= l_plant_code_wk
				AND	T0.INVALID_FLAG	= 0
				AND	T3.FACTORY_DATE	IS NOT NULL
				AND	T3.FACTORY_DATE	!= '00000000'
			GROUP BY
				T0.PLANT_CODE,
				T1.SEIZOU_LINE_CD,
				T0.SASIZU_NO,
				T0.SUB_NO

			UNION ALL

			-- 製造指図 - ラインごと
			SELECT
				T0.PLANT_CODE			as plantCode,
				T1.SEIZOU_LINE_CD		as seizouLineCd,
				T0.LINE_NO				as lineNo,
				T0.SASIZU_NO			as sasizuNo,
				T0.SUB_NO				as subNo,
				MAX(T3.SASIZU_KEP_KBN)	as sasizuKepKbn,
				MIN(T0.START_DATE)		as startDate,
				MAX(T0.END_DATE)		as endDate,
				MAX(T0.QUANTITY)		as quantity,
				to_timestamp(MAX(T3.FACTORY_DATE) || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYYMMDD HH24:MI:SS.MS') + interval '1days' + interval '-1milliseconds'	as factoryDate,
				MAX(RTRIM(T3.ORDER_NO))	as orderNo
			FROM
				TBL_SEIHIN_PLAN T0
			INNER JOIN
				MST_LINE T1
			ON
					T1.INVALID_FLAG	= 0
				AND	T0.PLANT_CODE	= T1.PLANT_CODE
				AND	T0.LINE_NO		= T1.LINE_NO
			INNER JOIN
				MST_SEIZOU_LINE T2
			ON
					T2.INVALID_FLAG		= 0
				AND	T2.PLANNING_SYSTEM	= 1
				AND	T1.PLANT_CODE		= T2.PLANT_CODE
				AND	T1.SEIZOU_LINE_CD	= T2.SEIZOU_LINE_CD
			INNER JOIN
				TBL_SASHIZU_MANAGEMENT T3
			ON
				T0.SASIZU_NO	= T3.SASIZU_NO
			WHERE
					T0.PLANT_CODE	= l_plant_code_wk
				AND	T0.INVALID_FLAG	= 0
				AND	T3.FACTORY_DATE	IS NOT NULL
				AND	T3.FACTORY_DATE	!= '00000000'
			GROUP BY
				T0.PLANT_CODE,
				T1.SEIZOU_LINE_CD,
				T0.LINE_NO,
				T0.SASIZU_NO,
				T0.SUB_NO
		)T
		WHERE
			-- 指図もしくは計画手配上、当日までに完成することになっているが、
			-- 作業終了予定日時が明日以降で計画されているものは遅れとみなす
				T.factoryDate	<= l_proc_end_time
			AND	T.endDate		>  l_proc_end_time
		GROUP BY
			T.plantCode,
			T.seizouLineCd,
			T.lineNo
	;

	OPENFLG_GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM		int;	-- カーソルオープン状態


	-- 未来生産負荷状況(日別)
	CUR_TBL_PRELOAD_LEVEL_DAILY	CURSOR FOR
		SELECT
			*
		FROM
			TBL_PRELOAD_LEVEL_DAILY
		WHERE
				PLANT_CODE		= l_plant_code
			AND	SEIZOU_LINE_CD	= l_seizou_line_cd
			AND	LINE_NO			= l_line_no
			AND	DATA_DATE		= l_proc_start_time
			AND	SNAPSHOT_DATE	= l_exec_datetime
		FOR UPDATE NOWAIT
	;

	OPENFLG_TBL_PRELOAD_LEVEL_DAILY		int;	-- カーソルオープン状態
	REC_TBL_PRELOAD_LEVEL_DAILY			TBL_PRELOAD_LEVEL_DAILY%ROWTYPE;

BEGIN
	----------------------------------------------------------------------------
	--						初期処理
	----------------------------------------------------------------------------
	raise info 'Start Function [%]', clock_timestamp()::timestamp;

	-- 共通変数初期化
	l_err_pnt		:= RTRIM(cst_MY_PRG) || '_S001';

	-- 共通出力パラメータ初期化
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
	o_ret_cd	:= RET_OK;
	o_sqlerr	:= ' ';
	o_errmsg	:= ' ';
	o_errpnt	:= ' ';

	-- 関数実行日時
	l_exec_datetime := clock_timestamp();

	-- 集計開始/終了日時補正
	l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
	IF i_from_time IS NULL THEN
		i_from_time := l_exec_datetime;
	END IF;
	IF i_to_time IS NULL OR i_from_time > i_to_time THEN
		i_to_time := l_exec_datetime;
	END IF;

	-- ローカル変数初期化
	OPENFLG_MST_PLANT := CST_FALSE;
	OPENFLG_GET_UPD_DATE := CST_FALSE;
	OPENFLG_GET_PRELOAD_LEVEL_ACTUAL_NUM := CST_FALSE;
	OPENFLG_GET_PRELOAD_LEVEL_DELAY_PAST_NUM := CST_FALSE;
	OPENFLG_GET_PRELOAD_LEVEL_DELAY_YESTERDAY_NUM := CST_FALSE;
	OPENFLG_GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM := CST_FALSE;
	OPENFLG_GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM := CST_FALSE;
	OPENFLG_GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM := CST_FALSE;
	OPENFLG_TBL_PRELOAD_LEVEL_DAILY := CST_FALSE;

	----------------------------------------------------------------------------
	-- メイン処理
	----------------------------------------------------------------------------
	<< MAIN_LOOP >>
	LOOP

		------------------------------------------------------------------------
		-- 工場ごとに稼働開始日時が異なるので、工場マスタで処理を回す
		------------------------------------------------------------------------
		-- 工場マスタを開いているならクローズ
		l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
		IF OPENFLG_MST_PLANT = CST_TRUE THEN
			CLOSE CUR_MST_PLANT;
			OPENFLG_MST_PLANT := CST_FALSE;
		END IF;

		-- 工場マスタをオープン
		l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
		OPEN CUR_MST_PLANT;
		OPENFLG_MST_PLANT := CST_TRUE;

		<< PLANT_LOOP >>
		LOOP
			-- 工場マスタからフェッチ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_103';
			FETCH CUR_MST_PLANT INTO l_plant_code_wk, l_running_start_datetime;
			IF FOUND = FALSE THEN
				EXIT PLANT_LOOP;
			END IF;

			IF l_running_start_datetime IS NULL THEN
				-- NULLの場合はデフォルト値をセット
				l_err_pnt := RTRIM(cst_MY_PRG) || '_104';
				l_running_start_datetime = timestamp '0001-03-21 07:00:00';
			END IF;

			-- 処理開始日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_105';
			SELECT to_timestamp(to_char(i_from_time, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_start_time_all;
			<< START_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_106';
				IF i_from_time >= l_proc_start_time_all THEN
					EXIT START_TIME_LOOP;
				END IF;
				l_proc_start_time_all := l_proc_start_time_all + interval '-1 days';
			END LOOP	START_TIME_LOOP;

			-- 処理終了日時(全体)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_107';
			SELECT l_proc_start_time_all + interval '1 days' + interval '-1 milliseconds' INTO l_proc_end_time_all;
			<< END_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_108';
				IF i_to_time <= l_proc_end_time_all THEN
					EXIT END_TIME_LOOP;
				END IF;
				l_proc_end_time_all := l_proc_end_time_all + interval '1 days';
			END LOOP	END_TIME_LOOP;

			-- 関数実行日(開始日時)設定
			l_err_pnt := RTRIM(cst_MY_PRG) || '_109';
			SELECT to_timestamp(to_char(l_exec_datetime, 'YYYY-MM-DD') || ' ' || to_char(l_running_start_datetime, 'HH24:MI:SS') || '.000', 'YYYY-MM-DD HH24:MI:SS.MS') INTO l_proc_exec_time;
			<< EXEC_TIME_LOOP >>
			LOOP
				l_err_pnt := RTRIM(cst_MY_PRG) || '_110';
				IF l_exec_datetime >= l_proc_exec_time THEN
					EXIT EXEC_TIME_LOOP;
				END IF;
				l_proc_exec_time := l_proc_exec_time + interval '-1 days';
			END LOOP	EXEC_TIME_LOOP;

			-- 関数実行日前日(開始日時)設定
			l_proc_exec_time_yesterday = l_proc_exec_time + interval '-1 days';

			-- 指図追番単位計画/追番単位計画手配データ更新日時取得を開いているならクローズ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_111';
			IF OPENFLG_GET_UPD_DATE = CST_TRUE THEN
				CLOSE CUR_GET_UPD_DATE;
				OPENFLG_GET_UPD_DATE := CST_FALSE;
			END IF;

			-- 指図追番単位計画/追番単位計画手配データ更新日時取得をオープン
			l_err_pnt := RTRIM(cst_MY_PRG) || '_112';
			OPEN CUR_GET_UPD_DATE;
			OPENFLG_GET_UPD_DATE := CST_TRUE;

			-- 指図追番単位計画/追番単位計画手配データ更新日時取得からフェッチ
			l_err_pnt := RTRIM(cst_MY_PRG) || '_113';
			FETCH CUR_GET_UPD_DATE INTO l_upd_date;
			IF FOUND = FALSE OR l_upd_date is NULL THEN
				-- 該当データがない場合
				CONTINUE;
			END IF;

			IF l_upd_date < date_trunc('day', l_exec_datetime) THEN
				-- 最終更新日時が昨日以前＝計画系データの更新なしの場合は処理しない
				raise info 'Data Not updated [%] < [%]', l_upd_date, date_trunc('day', l_exec_datetime);
				CONTINUE;
			END IF;

			-- 処理開始/終了日時
			l_err_pnt := RTRIM(cst_MY_PRG) || '_114';
			l_proc_start_time := l_proc_start_time_all;
			l_proc_end_time := l_proc_start_time + interval '1 days' + interval '-1 milliseconds';

			<< TIME_LOOP >>
			LOOP
				----------------------------------------------------------------
				-- 実績(処理開始日時(全体)～昨日)
				----------------------------------------------------------------
				IF l_proc_start_time_all <= l_proc_start_time AND l_proc_start_time < l_proc_exec_time THEN

					------------------------------------
					-- 実績台数
					------------------------------------
					-- 未来生産負荷状況(日別)データ【実績】取得を開いているならクローズ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
					IF OPENFLG_GET_PRELOAD_LEVEL_ACTUAL_NUM = CST_TRUE THEN
						CLOSE CUR_GET_PRELOAD_LEVEL_ACTUAL_NUM;
						OPENFLG_GET_PRELOAD_LEVEL_ACTUAL_NUM := CST_FALSE;
					END IF;

					-- 未来生産負荷状況(日別)データ【実績】取得をオープン
					l_err_pnt := RTRIM(cst_MY_PRG) || '_202';
					OPEN CUR_GET_PRELOAD_LEVEL_ACTUAL_NUM;
					OPENFLG_GET_PRELOAD_LEVEL_ACTUAL_NUM := CST_TRUE;

					<< GET_PRELOAD_LEVEL_ACTUAL_NUM_LOOP >>
					LOOP
						-- 未来生産負荷状況(日別)データ【実績】取得からフェッチ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_203';
						FETCH CUR_GET_PRELOAD_LEVEL_ACTUAL_NUM INTO l_plant_code, l_seizou_line_cd, l_line_no, l_planned_order_unknown_num, l_planned_order_shortage_num, l_planned_order_zaikan_num, l_production_order_shortage_num, l_production_order_zaikan_num, l_actual_num, l_order_delay_num, l_stock_delay_num;
						IF FOUND = FALSE THEN
							-- 該当データがない場合
							EXIT GET_PRELOAD_LEVEL_ACTUAL_NUM_LOOP;
						END IF;

						-- 未来生産負荷状況(日別)に既に集計データが存在するかを確認
						-- 未来生産負荷状況(日別)を開いているならクローズ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_204';
						IF OPENFLG_TBL_PRELOAD_LEVEL_DAILY = CST_TRUE THEN
							CLOSE CUR_TBL_PRELOAD_LEVEL_DAILY;
							OPENFLG_TBL_PRELOAD_LEVEL_DAILY := CST_FALSE;
						END IF;

						-- 未来生産負荷状況(日別)をオープン
						l_err_pnt := RTRIM(cst_MY_PRG) || '_205';
						OPEN CUR_TBL_PRELOAD_LEVEL_DAILY;
						OPENFLG_TBL_PRELOAD_LEVEL_DAILY := CST_TRUE;

						-- 未来生産負荷状況(日別)からフェッチ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_206';
						FETCH CUR_TBL_PRELOAD_LEVEL_DAILY INTO REC_TBL_PRELOAD_LEVEL_DAILY;
						IF FOUND = FALSE THEN
							-- 未来生産負荷状況(日別)に格納
							l_err_pnt := RTRIM(cst_MY_PRG) || '_207';
							INSERT INTO TBL_PRELOAD_LEVEL_DAILY
							(
								  PLANT_CODE							-- 工場コード
								, SEIZOU_LINE_CD						-- 製造ラインコード
								, LINE_NO								-- ライン番号
								, DATA_DATE								-- データ日時
								, SNAPSHOT_DATE							-- スナップショット日時
								, PLANNED_ORDER_UNKNOWN_NUM				-- 計画手配(未定)台数
								, PLANNED_ORDER_SHORTAGE_NUM			-- 計画手配(欠品)台数
								, PLANNED_ORDER_ZAIKAN_NUM				-- 計画手配(材完)台数
								, PRODUCTION_ORDER_ZAIKAN_NUM			-- 製造指図(欠品)台数
								, PRODUCTION_ORDER_SHORTAGE_NUM			-- 製造指図(材完)台数
								, ACTUAL_NUM							-- 実績台数
								, ORDER_DELAY_NUM						-- オーダー遅れ台数
								, STOCK_DELAY_NUM						-- 在庫遅れ台数
								, INS_PROG								-- 登録プログラム名
								, INS_TIM								-- 登録日時
								, INS_USER_SID							-- 登録ユーザSID
								, UPD_PROG								-- 更新プログラム名
								, UPD_TIM								-- 更新日時
								, UPD_USER_SID							-- 更新ユーザSID
							)
							VALUES
							(
								  l_plant_code							-- 工場コード
								, l_seizou_line_cd						-- 製造ラインコード
								, l_line_no								-- ライン番号
								, l_proc_start_time						-- データ日時
								, l_exec_datetime						-- スナップショット日時
								, l_planned_order_unknown_num			-- 計画手配(未定)台数
								, l_planned_order_shortage_num			-- 計画手配(欠品)台数
								, l_planned_order_zaikan_num			-- 計画手配(材完)台数
								, l_production_order_zaikan_num			-- 製造指図(欠品)台数
								, l_production_order_shortage_num		-- 製造指図(材完)台数
								, l_actual_num							-- 実績台数
								, l_order_delay_num						-- オーダー遅れ台数
								, l_stock_delay_num						-- 在庫遅れ台数
								, cst_MY_PRG							-- 登録プログラム
								, l_exec_datetime						-- 登録日時
								, i_user_sid							-- 登録ユーザSID
								, cst_MY_PRG							-- 更新プログラム
								, l_exec_datetime						-- 更新日時
								, i_user_sid							-- 更新ユーザSID
							);
						ELSE
							-- 未来生産負荷状況(日別)を更新
							l_err_pnt := RTRIM(cst_MY_PRG) || '_208';
							UPDATE TBL_PRELOAD_LEVEL_DAILY SET
								  ACTUAL_NUM					= l_actual_num						-- 実績台数
								, UPD_PROG						= cst_MY_PRG						-- 更新プログラム
								, UPD_TIM						= l_exec_datetime					-- 更新日時
								, UPD_USER_SID					= i_user_sid						-- 更新ユーザSID
							WHERE CURRENT OF CUR_TBL_PRELOAD_LEVEL_DAILY;
						END IF;

					END LOOP	GET_PRELOAD_LEVEL_ACTUAL_NUM_LOOP;

					------------------------------------
					-- 遅れ台数
					------------------------------------
					IF l_proc_start_time = l_proc_exec_time_yesterday THEN
						--------------------------------
						-- 昨日
						--------------------------------
						-- 未来生産負荷状況(日別)データ【遅れ(昨日)】取得を開いているならクローズ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_301_1';
						IF OPENFLG_GET_PRELOAD_LEVEL_DELAY_YESTERDAY_NUM = CST_TRUE THEN
							CLOSE CUR_GET_PRELOAD_LEVEL_DELAY_YESTERDAY_NUM;
							OPENFLG_GET_PRELOAD_LEVEL_DELAY_YESTERDAY_NUM := CST_FALSE;
						END IF;

						-- 未来生産負荷状況(日別)データ【遅れ(昨日)】取得をオープン
						l_err_pnt := RTRIM(cst_MY_PRG) || '_302_1';
						OPEN CUR_GET_PRELOAD_LEVEL_DELAY_YESTERDAY_NUM;
						OPENFLG_GET_PRELOAD_LEVEL_DELAY_YESTERDAY_NUM := CST_TRUE;
					ELSE
						--------------------------------
						-- 処理開始日時(全体)～一昨日
						--------------------------------
						-- 未来生産負荷状況(日別)データ【遅れ(～一昨日)】取得を開いているならクローズ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_301_2';
						IF OPENFLG_GET_PRELOAD_LEVEL_DELAY_PAST_NUM = CST_TRUE THEN
							CLOSE CUR_GET_PRELOAD_LEVEL_DELAY_PAST_NUM;
							OPENFLG_GET_PRELOAD_LEVEL_DELAY_PAST_NUM := CST_FALSE;
						END IF;

						-- 未来生産負荷状況(日別)データ【遅れ(～一昨日)】取得をオープン
						l_err_pnt := RTRIM(cst_MY_PRG) || '_302_2';
						OPEN CUR_GET_PRELOAD_LEVEL_DELAY_PAST_NUM;
						OPENFLG_GET_PRELOAD_LEVEL_DELAY_PAST_NUM := CST_TRUE;
					END IF;

					<< GET_PRELOAD_LEVEL_DELAY_PAST_NUM_LOOP >>
					LOOP
						IF l_proc_start_time = l_proc_exec_time_yesterday THEN
							-- 未来生産負荷状況(日別)データ【遅れ(昨日)】取得からフェッチ
							l_err_pnt := RTRIM(cst_MY_PRG) || '_303_1';
							FETCH CUR_GET_PRELOAD_LEVEL_DELAY_YESTERDAY_NUM INTO l_plant_code, l_seizou_line_cd, l_line_no, l_planned_order_unknown_num, l_planned_order_shortage_num, l_planned_order_zaikan_num, l_production_order_shortage_num, l_production_order_zaikan_num, l_actual_num, l_order_delay_num, l_stock_delay_num;
						ELSE
							-- 未来生産負荷状況(日別)データ【遅れ(～一昨日)】取得からフェッチ
							l_err_pnt := RTRIM(cst_MY_PRG) || '_303_2';
							FETCH CUR_GET_PRELOAD_LEVEL_DELAY_PAST_NUM INTO l_plant_code, l_seizou_line_cd, l_line_no, l_planned_order_unknown_num, l_planned_order_shortage_num, l_planned_order_zaikan_num, l_production_order_shortage_num, l_production_order_zaikan_num, l_actual_num, l_order_delay_num, l_stock_delay_num;
						END IF;

						IF FOUND = FALSE THEN
							-- 該当データがない場合
							EXIT GET_PRELOAD_LEVEL_DELAY_PAST_NUM_LOOP;
						END IF;

						-- 未来生産負荷状況(日別)に既に集計データが存在するかを確認
						-- 未来生産負荷状況(日別)を開いているならクローズ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_304';
						IF OPENFLG_TBL_PRELOAD_LEVEL_DAILY = CST_TRUE THEN
							CLOSE CUR_TBL_PRELOAD_LEVEL_DAILY;
							OPENFLG_TBL_PRELOAD_LEVEL_DAILY := CST_FALSE;
						END IF;

						-- 未来生産負荷状況(日別)をオープン
						l_err_pnt := RTRIM(cst_MY_PRG) || '_305';
						OPEN CUR_TBL_PRELOAD_LEVEL_DAILY;
						OPENFLG_TBL_PRELOAD_LEVEL_DAILY := CST_TRUE;

						-- 未来生産負荷状況(日別)からフェッチ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_306';
						FETCH CUR_TBL_PRELOAD_LEVEL_DAILY INTO REC_TBL_PRELOAD_LEVEL_DAILY;
						IF FOUND = FALSE THEN
							-- 未来生産負荷状況(日別)に格納
							l_err_pnt := RTRIM(cst_MY_PRG) || '_307';
							INSERT INTO TBL_PRELOAD_LEVEL_DAILY
							(
								  PLANT_CODE							-- 工場コード
								, SEIZOU_LINE_CD						-- 製造ラインコード
								, LINE_NO								-- ライン番号
								, DATA_DATE								-- データ日時
								, SNAPSHOT_DATE							-- スナップショット日時
								, PLANNED_ORDER_UNKNOWN_NUM				-- 計画手配(未定)台数
								, PLANNED_ORDER_SHORTAGE_NUM			-- 計画手配(欠品)台数
								, PLANNED_ORDER_ZAIKAN_NUM				-- 計画手配(材完)台数
								, PRODUCTION_ORDER_ZAIKAN_NUM			-- 製造指図(欠品)台数
								, PRODUCTION_ORDER_SHORTAGE_NUM			-- 製造指図(材完)台数
								, ACTUAL_NUM							-- 実績台数
								, ORDER_DELAY_NUM						-- オーダー遅れ台数
								, STOCK_DELAY_NUM						-- 在庫遅れ台数
								, INS_PROG								-- 登録プログラム名
								, INS_TIM								-- 登録日時
								, INS_USER_SID							-- 登録ユーザSID
								, UPD_PROG								-- 更新プログラム名
								, UPD_TIM								-- 更新日時
								, UPD_USER_SID							-- 更新ユーザSID
							)
							VALUES
							(
								  l_plant_code							-- 工場コード
								, l_seizou_line_cd						-- 製造ラインコード
								, l_line_no								-- ライン番号
								, l_proc_start_time						-- データ日時
								, l_exec_datetime						-- スナップショット日時
								, l_planned_order_unknown_num			-- 計画手配(未定)台数
								, l_planned_order_shortage_num			-- 計画手配(欠品)台数
								, l_planned_order_zaikan_num			-- 計画手配(材完)台数
								, l_production_order_zaikan_num			-- 製造指図(欠品)台数
								, l_production_order_shortage_num		-- 製造指図(材完)台数
								, l_actual_num							-- 実績台数
								, l_order_delay_num						-- オーダー遅れ台数
								, l_stock_delay_num						-- 在庫遅れ台数
								, cst_MY_PRG							-- 登録プログラム
								, l_exec_datetime						-- 登録日時
								, i_user_sid							-- 登録ユーザSID
								, cst_MY_PRG							-- 更新プログラム
								, l_exec_datetime						-- 更新日時
								, i_user_sid							-- 更新ユーザSID
							);
						ELSE
							-- 未来生産負荷状況(日別)を更新
							l_err_pnt := RTRIM(cst_MY_PRG) || '_308';
							UPDATE TBL_PRELOAD_LEVEL_DAILY SET
								  ORDER_DELAY_NUM				= l_order_delay_num					-- オーダー遅れ台数
								, STOCK_DELAY_NUM				= l_stock_delay_num					-- 在庫遅れ台数
								, UPD_PROG						= cst_MY_PRG						-- 更新プログラム
								, UPD_TIM						= l_exec_datetime					-- 更新日時
								, UPD_USER_SID					= i_user_sid						-- 更新ユーザSID
							WHERE CURRENT OF CUR_TBL_PRELOAD_LEVEL_DAILY;
						END IF;

					END LOOP	GET_PRELOAD_LEVEL_DELAY_PAST_NUM_LOOP;

				----------------------------------------------------------------
				-- 計画(当日～処理終了日時(全体))
				----------------------------------------------------------------
				ELSE

					------------------------------------
					-- 計画手配台数
					------------------------------------
					-- 未来生産負荷状況(日別)データ【計画手配】取得を開いているならクローズ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_401';
					IF OPENFLG_GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM = CST_TRUE THEN
						CLOSE CUR_GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM;
						OPENFLG_GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM := CST_FALSE;
					END IF;

					-- 未来生産負荷状況(日別)データ【計画手配】取得をオープン
					l_err_pnt := RTRIM(cst_MY_PRG) || '_402';
					OPEN CUR_GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM;
					OPENFLG_GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM := CST_TRUE;

					<< GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM_LOOP >>
					LOOP
						-- 未来生産負荷状況(日別)データ【計画手配】取得からフェッチ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_403';
						FETCH CUR_GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM INTO l_plant_code, l_seizou_line_cd, l_line_no, l_planned_order_unknown_num, l_planned_order_shortage_num, l_planned_order_zaikan_num, l_production_order_shortage_num, l_production_order_zaikan_num, l_actual_num, l_order_delay_num, l_stock_delay_num;
						IF FOUND = FALSE THEN
							-- 該当データがない場合
							EXIT GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM_LOOP;
						END IF;

						-- 未来生産負荷状況(日別)に既に集計データが存在するかを確認
						-- 未来生産負荷状況(日別)を開いているならクローズ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_404';
						IF OPENFLG_TBL_PRELOAD_LEVEL_DAILY = CST_TRUE THEN
							CLOSE CUR_TBL_PRELOAD_LEVEL_DAILY;
							OPENFLG_TBL_PRELOAD_LEVEL_DAILY := CST_FALSE;
						END IF;

						-- 未来生産負荷状況(日別)をオープン
						l_err_pnt := RTRIM(cst_MY_PRG) || '_405';
						OPEN CUR_TBL_PRELOAD_LEVEL_DAILY;
						OPENFLG_TBL_PRELOAD_LEVEL_DAILY := CST_TRUE;

						-- 未来生産負荷状況(日別)からフェッチ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_406';
						FETCH CUR_TBL_PRELOAD_LEVEL_DAILY INTO REC_TBL_PRELOAD_LEVEL_DAILY;
						IF FOUND = FALSE THEN
							-- 未来生産負荷状況(日別)に格納
							l_err_pnt := RTRIM(cst_MY_PRG) || '_407';
							INSERT INTO TBL_PRELOAD_LEVEL_DAILY
							(
								  PLANT_CODE							-- 工場コード
								, SEIZOU_LINE_CD						-- 製造ラインコード
								, LINE_NO								-- ライン番号
								, DATA_DATE								-- データ日時
								, SNAPSHOT_DATE							-- スナップショット日時
								, PLANNED_ORDER_UNKNOWN_NUM				-- 計画手配(未定)台数
								, PLANNED_ORDER_SHORTAGE_NUM			-- 計画手配(欠品)台数
								, PLANNED_ORDER_ZAIKAN_NUM				-- 計画手配(材完)台数
								, PRODUCTION_ORDER_ZAIKAN_NUM			-- 製造指図(欠品)台数
								, PRODUCTION_ORDER_SHORTAGE_NUM			-- 製造指図(材完)台数
								, ACTUAL_NUM							-- 実績台数
								, ORDER_DELAY_NUM						-- オーダー遅れ台数
								, STOCK_DELAY_NUM						-- 在庫遅れ台数
								, INS_PROG								-- 登録プログラム名
								, INS_TIM								-- 登録日時
								, INS_USER_SID							-- 登録ユーザSID
								, UPD_PROG								-- 更新プログラム名
								, UPD_TIM								-- 更新日時
								, UPD_USER_SID							-- 更新ユーザSID
							)
							VALUES
							(
								  l_plant_code							-- 工場コード
								, l_seizou_line_cd						-- 製造ラインコード
								, l_line_no								-- ライン番号
								, l_proc_start_time						-- データ日時
								, l_exec_datetime						-- スナップショット日時
								, l_planned_order_unknown_num			-- 計画手配(未定)台数
								, l_planned_order_shortage_num			-- 計画手配(欠品)台数
								, l_planned_order_zaikan_num			-- 計画手配(材完)台数
								, l_production_order_zaikan_num			-- 製造指図(欠品)台数
								, l_production_order_shortage_num		-- 製造指図(材完)台数
								, l_actual_num							-- 実績台数
								, l_order_delay_num						-- オーダー遅れ台数
								, l_stock_delay_num						-- 在庫遅れ台数
								, cst_MY_PRG							-- 登録プログラム
								, l_exec_datetime						-- 登録日時
								, i_user_sid							-- 登録ユーザSID
								, cst_MY_PRG							-- 更新プログラム
								, l_exec_datetime						-- 更新日時
								, i_user_sid							-- 更新ユーザSID
							);
						ELSE
							-- 未来生産負荷状況(日別)を更新
							l_err_pnt := RTRIM(cst_MY_PRG) || '_408';
							UPDATE TBL_PRELOAD_LEVEL_DAILY SET
								  PLANNED_ORDER_UNKNOWN_NUM		= l_planned_order_unknown_num		-- 計画手配(未定)台数
								, PLANNED_ORDER_SHORTAGE_NUM	= l_planned_order_shortage_num		-- 計画手配(欠品)台数
								, PLANNED_ORDER_ZAIKAN_NUM		= l_planned_order_zaikan_num		-- 計画手配(材完)台数
								, UPD_PROG						= cst_MY_PRG						-- 更新プログラム
								, UPD_TIM						= l_exec_datetime					-- 更新日時
								, UPD_USER_SID					= i_user_sid						-- 更新ユーザSID
							WHERE CURRENT OF CUR_TBL_PRELOAD_LEVEL_DAILY;
						END IF;

					END LOOP	GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM_LOOP;

					------------------------------------
					-- 製造指図台数
					------------------------------------
					-- 未来生産負荷状況(日別)データ【製造指図】取得を開いているならクローズ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_501';
					IF OPENFLG_GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM = CST_TRUE THEN
						CLOSE CUR_GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM;
						OPENFLG_GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM := CST_FALSE;
					END IF;

					-- 未来生産負荷状況(日別)データ【製造指図】取得をオープン
					l_err_pnt := RTRIM(cst_MY_PRG) || '_502';
					OPEN CUR_GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM;
					OPENFLG_GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM := CST_TRUE;

					<< GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM_LOOP >>
					LOOP
						-- 未来生産負荷状況(日別)データ【製造指図】取得からフェッチ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_503';
						FETCH CUR_GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM INTO l_plant_code, l_seizou_line_cd, l_line_no, l_planned_order_unknown_num, l_planned_order_shortage_num, l_planned_order_zaikan_num, l_production_order_shortage_num, l_production_order_zaikan_num, l_actual_num, l_order_delay_num, l_stock_delay_num;
						IF FOUND = FALSE THEN
							-- 該当データがない場合
							EXIT GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM_LOOP;
						END IF;

						-- 未来生産負荷状況(日別)に既に集計データが存在するかを確認
						-- 未来生産負荷状況(日別)を開いているならクローズ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_504';
						IF OPENFLG_TBL_PRELOAD_LEVEL_DAILY = CST_TRUE THEN
							CLOSE CUR_TBL_PRELOAD_LEVEL_DAILY;
							OPENFLG_TBL_PRELOAD_LEVEL_DAILY := CST_FALSE;
						END IF;

						-- 未来生産負荷状況(日別)をオープン
						l_err_pnt := RTRIM(cst_MY_PRG) || '_505';
						OPEN CUR_TBL_PRELOAD_LEVEL_DAILY;
						OPENFLG_TBL_PRELOAD_LEVEL_DAILY := CST_TRUE;

						-- 未来生産負荷状況(日別)からフェッチ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_506';
						FETCH CUR_TBL_PRELOAD_LEVEL_DAILY INTO REC_TBL_PRELOAD_LEVEL_DAILY;
						IF FOUND = FALSE THEN
							-- 未来生産負荷状況(日別)に格納
							l_err_pnt := RTRIM(cst_MY_PRG) || '_507';
							INSERT INTO TBL_PRELOAD_LEVEL_DAILY
							(
								  PLANT_CODE							-- 工場コード
								, SEIZOU_LINE_CD						-- 製造ラインコード
								, LINE_NO								-- ライン番号
								, DATA_DATE								-- データ日時
								, SNAPSHOT_DATE							-- スナップショット日時
								, PLANNED_ORDER_UNKNOWN_NUM				-- 計画手配(未定)台数
								, PLANNED_ORDER_SHORTAGE_NUM			-- 計画手配(欠品)台数
								, PLANNED_ORDER_ZAIKAN_NUM				-- 計画手配(材完)台数
								, PRODUCTION_ORDER_ZAIKAN_NUM			-- 製造指図(欠品)台数
								, PRODUCTION_ORDER_SHORTAGE_NUM			-- 製造指図(材完)台数
								, ACTUAL_NUM							-- 実績台数
								, ORDER_DELAY_NUM						-- オーダー遅れ台数
								, STOCK_DELAY_NUM						-- 在庫遅れ台数
								, INS_PROG								-- 登録プログラム名
								, INS_TIM								-- 登録日時
								, INS_USER_SID							-- 登録ユーザSID
								, UPD_PROG								-- 更新プログラム名
								, UPD_TIM								-- 更新日時
								, UPD_USER_SID							-- 更新ユーザSID
							)
							VALUES
							(
								  l_plant_code							-- 工場コード
								, l_seizou_line_cd						-- 製造ラインコード
								, l_line_no								-- ライン番号
								, l_proc_start_time						-- データ日時
								, l_exec_datetime						-- スナップショット日時
								, l_planned_order_unknown_num			-- 計画手配(未定)台数
								, l_planned_order_shortage_num			-- 計画手配(欠品)台数
								, l_planned_order_zaikan_num			-- 計画手配(材完)台数
								, l_production_order_zaikan_num			-- 製造指図(欠品)台数
								, l_production_order_shortage_num		-- 製造指図(材完)台数
								, l_actual_num							-- 実績台数
								, l_order_delay_num						-- オーダー遅れ台数
								, l_stock_delay_num						-- 在庫遅れ台数
								, cst_MY_PRG							-- 登録プログラム
								, l_exec_datetime						-- 登録日時
								, i_user_sid							-- 登録ユーザSID
								, cst_MY_PRG							-- 更新プログラム
								, l_exec_datetime						-- 更新日時
								, i_user_sid							-- 更新ユーザSID
							);
						ELSE
							-- 未来生産負荷状況(日別)を更新
							l_err_pnt := RTRIM(cst_MY_PRG) || '_508';
							UPDATE TBL_PRELOAD_LEVEL_DAILY SET
								  PRODUCTION_ORDER_ZAIKAN_NUM	= l_production_order_zaikan_num		-- 製造指図(欠品)台数
								, PRODUCTION_ORDER_SHORTAGE_NUM	= l_production_order_shortage_num	-- 製造指図(材完)台数
								, UPD_PROG						= cst_MY_PRG						-- 更新プログラム
								, UPD_TIM						= l_exec_datetime					-- 更新日時
								, UPD_USER_SID					= i_user_sid						-- 更新ユーザSID
							WHERE CURRENT OF CUR_TBL_PRELOAD_LEVEL_DAILY;
						END IF;

					END LOOP	GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM_LOOP;

					------------------------------------
					-- 遅れ台数
					------------------------------------
					-- 未来生産負荷状況(日別)データ【遅れ(当日～)】取得を開いているならクローズ
					l_err_pnt := RTRIM(cst_MY_PRG) || '_601';
					IF OPENFLG_GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM = CST_TRUE THEN
						CLOSE CUR_GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM;
						OPENFLG_GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM := CST_FALSE;
					END IF;

					-- 未来生産負荷状況(日別)データ【遅れ(当日～)】取得をオープン
					l_err_pnt := RTRIM(cst_MY_PRG) || '_602';
					OPEN CUR_GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM;
					OPENFLG_GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM := CST_TRUE;

					<< GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM_LOOP >>
					LOOP
						-- 未来生産負荷状況(日別)データ【遅れ(当日～)】取得からフェッチ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_603';
						FETCH CUR_GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM INTO l_plant_code, l_seizou_line_cd, l_line_no, l_planned_order_unknown_num, l_planned_order_shortage_num, l_planned_order_zaikan_num, l_production_order_shortage_num, l_production_order_zaikan_num, l_actual_num, l_order_delay_num, l_stock_delay_num;
						IF FOUND = FALSE THEN
							-- 該当データがない場合
							EXIT GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM_LOOP;
						END IF;

						-- 未来生産負荷状況(日別)に既に集計データが存在するかを確認
						-- 未来生産負荷状況(日別)を開いているならクローズ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_604';
						IF OPENFLG_TBL_PRELOAD_LEVEL_DAILY = CST_TRUE THEN
							CLOSE CUR_TBL_PRELOAD_LEVEL_DAILY;
							OPENFLG_TBL_PRELOAD_LEVEL_DAILY := CST_FALSE;
						END IF;

						-- 未来生産負荷状況(日別)をオープン
						l_err_pnt := RTRIM(cst_MY_PRG) || '_605';
						OPEN CUR_TBL_PRELOAD_LEVEL_DAILY;
						OPENFLG_TBL_PRELOAD_LEVEL_DAILY := CST_TRUE;

						-- 未来生産負荷状況(日別)からフェッチ
						l_err_pnt := RTRIM(cst_MY_PRG) || '_606';
						FETCH CUR_TBL_PRELOAD_LEVEL_DAILY INTO REC_TBL_PRELOAD_LEVEL_DAILY;
						IF FOUND = FALSE THEN
							-- 未来生産負荷状況(日別)に格納
							l_err_pnt := RTRIM(cst_MY_PRG) || '_607';
							INSERT INTO TBL_PRELOAD_LEVEL_DAILY
							(
								  PLANT_CODE							-- 工場コード
								, SEIZOU_LINE_CD						-- 製造ラインコード
								, LINE_NO								-- ライン番号
								, DATA_DATE								-- データ日時
								, SNAPSHOT_DATE							-- スナップショット日時
								, PLANNED_ORDER_UNKNOWN_NUM				-- 計画手配(未定)台数
								, PLANNED_ORDER_SHORTAGE_NUM			-- 計画手配(欠品)台数
								, PLANNED_ORDER_ZAIKAN_NUM				-- 計画手配(材完)台数
								, PRODUCTION_ORDER_ZAIKAN_NUM			-- 製造指図(欠品)台数
								, PRODUCTION_ORDER_SHORTAGE_NUM			-- 製造指図(材完)台数
								, ACTUAL_NUM							-- 実績台数
								, ORDER_DELAY_NUM						-- オーダー遅れ台数
								, STOCK_DELAY_NUM						-- 在庫遅れ台数
								, INS_PROG								-- 登録プログラム名
								, INS_TIM								-- 登録日時
								, INS_USER_SID							-- 登録ユーザSID
								, UPD_PROG								-- 更新プログラム名
								, UPD_TIM								-- 更新日時
								, UPD_USER_SID							-- 更新ユーザSID
							)
							VALUES
							(
								  l_plant_code							-- 工場コード
								, l_seizou_line_cd						-- 製造ラインコード
								, l_line_no								-- ライン番号
								, l_proc_start_time						-- データ日時
								, l_exec_datetime						-- スナップショット日時
								, l_planned_order_unknown_num			-- 計画手配(未定)台数
								, l_planned_order_shortage_num			-- 計画手配(欠品)台数
								, l_planned_order_zaikan_num			-- 計画手配(材完)台数
								, l_production_order_zaikan_num			-- 製造指図(欠品)台数
								, l_production_order_shortage_num		-- 製造指図(材完)台数
								, l_actual_num							-- 実績台数
								, l_order_delay_num						-- オーダー遅れ台数
								, l_stock_delay_num						-- 在庫遅れ台数
								, cst_MY_PRG							-- 登録プログラム
								, l_exec_datetime						-- 登録日時
								, i_user_sid							-- 登録ユーザSID
								, cst_MY_PRG							-- 更新プログラム
								, l_exec_datetime						-- 更新日時
								, i_user_sid							-- 更新ユーザSID
							);
						ELSE
							-- 未来生産負荷状況(日別)を更新
							l_err_pnt := RTRIM(cst_MY_PRG) || '_608';
							UPDATE TBL_PRELOAD_LEVEL_DAILY SET
								  ORDER_DELAY_NUM				= l_order_delay_num					-- オーダー遅れ台数
								, STOCK_DELAY_NUM				= l_stock_delay_num					-- 在庫遅れ台数
								, UPD_PROG						= cst_MY_PRG						-- 更新プログラム
								, UPD_TIM						= l_exec_datetime					-- 更新日時
								, UPD_USER_SID					= i_user_sid						-- 更新ユーザSID
							WHERE CURRENT OF CUR_TBL_PRELOAD_LEVEL_DAILY;
						END IF;

					END LOOP	GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM_LOOP;
				END IF;

				-- 次の処理日時を設定
				l_proc_start_time	:= l_proc_start_time + interval '1 days';
				l_proc_end_time		:= l_proc_end_time + interval '1 days';

				-- 処理開始日時が処理終了日時(全体)を超えている場合は処理終了
				IF l_proc_end_time_all < l_proc_start_time THEN
					EXIT TIME_LOOP;
				END IF;

			END LOOP	TIME_LOOP;

		END LOOP	PLANT_LOOP;

		EXIT MAIN_LOOP;
	END LOOP	MAIN_LOOP;

	----------------------------------------------------------------------------
	--						終了処理
	----------------------------------------------------------------------------
	-- カーソルクローズ
	l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
	IF OPENFLG_MST_PLANT = CST_TRUE THEN
		CLOSE CUR_MST_PLANT;
		OPENFLG_MST_PLANT := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E002';
	IF OPENFLG_GET_UPD_DATE = CST_TRUE THEN
		CLOSE CUR_GET_UPD_DATE;
		OPENFLG_GET_UPD_DATE := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E003';
	IF OPENFLG_GET_PRELOAD_LEVEL_ACTUAL_NUM = CST_TRUE THEN
		CLOSE CUR_GET_PRELOAD_LEVEL_ACTUAL_NUM;
		OPENFLG_GET_PRELOAD_LEVEL_ACTUAL_NUM := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E004';
	IF OPENFLG_GET_PRELOAD_LEVEL_DELAY_PAST_NUM = CST_TRUE THEN
		CLOSE CUR_GET_PRELOAD_LEVEL_DELAY_PAST_NUM;
		OPENFLG_GET_PRELOAD_LEVEL_DELAY_PAST_NUM := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E005';
	IF OPENFLG_GET_PRELOAD_LEVEL_DELAY_YESTERDAY_NUM = CST_TRUE THEN
		CLOSE CUR_GET_PRELOAD_LEVEL_DELAY_YESTERDAY_NUM;
		OPENFLG_GET_PRELOAD_LEVEL_DELAY_YESTERDAY_NUM := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E006';
	IF OPENFLG_GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM = CST_TRUE THEN
		CLOSE CUR_GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM;
		OPENFLG_GET_PRELOAD_LEVEL_PRODUCTION_ORDER_NUM := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E007';
	IF OPENFLG_GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM = CST_TRUE THEN
		CLOSE CUR_GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM;
		OPENFLG_GET_PRELOAD_LEVEL_PLANNED_ORDER_NUM := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E008';
	IF OPENFLG_GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM = CST_TRUE THEN
		CLOSE CUR_GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM;
		OPENFLG_GET_PRELOAD_LEVEL_DELAY_FUTURE_NUM := CST_FALSE;
	END IF;

	l_err_pnt := RTRIM(cst_MY_PRG) || '_E009';
	IF OPENFLG_TBL_PRELOAD_LEVEL_DAILY = CST_TRUE THEN
		CLOSE CUR_TBL_PRELOAD_LEVEL_DAILY;
		OPENFLG_TBL_PRELOAD_LEVEL_DAILY := CST_FALSE;
	END IF;

	raise info 'End Function [%]', clock_timestamp()::timestamp;

EXCEPTION WHEN OTHERS THEN
	-- DB例外情報収集
	GET STACKED DIAGNOSTICS rtn_sql_no     = RETURNED_SQLSTATE,
							rtn_sql_msg    = MESSAGE_TEXT,
							rtn_sql_detail = PG_EXCEPTION_DETAIL,
							rtn_sql_hint   = PG_EXCEPTION_HINT,
							rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

	raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
	raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

	o_ret_cd := RET_NG;
	o_sqlerr := substr(rtn_sql_no, 1, 15);
	o_errmsg := substr(rtn_sql_msg, 1, 127);
	o_errpnt := l_err_pnt;

	raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;
