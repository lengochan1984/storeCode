CREATE or REPLACE FUNCTION func_sasizu_sinchoku_color_no(
    in	i_log_type				numeric,		-- ログ種別(開始、および　各バッチ処理の復帰値)
                                                -- (1:開始 2：正常終了 3：一部異常終了 4：異常終了)
    in	i_user_sid				numeric,		-- 登録ユーザSID
    in	i_plant_code			char(2),		-- 工場コード
    in	i_proc_start_time		timestamp,		-- 処理開始日
    in	i_proc_end_time			timestamp,		-- 処理終了日
    out	o_ret_cd				int,			-- 関数復帰値	RET_OK(= 0):正常終了
    out	o_sqlerr				varchar,		-- ＤＢ異常発生時のエラーコード
    out	o_errmsg				varchar,		-- 異常発生時のエラーメッセージ
    out	o_errpnt				varchar			-- 異常発生ポイント
)
AS
$BODY$
--******************************************************************************
--　プログラム名　　　　：　指図進捗情報用色番号設定サービス
--　ソースプログラム名　：　func_sasizu_sinchoku_color_no.sql
--　ＯＳ　　　　　　　　：　Linux (PostgreSQL 9.3.2)
--　言語　　　　　　　　：　plpgsql
--　著作権　　　　　　　：　YSK
--　処理概要　　　　　　：　製品生産計画実績(時間別)の計画台数を算出する
--
--　履歴
--  Ver.  作成日				作成者				COMMENT
--  1.0   2016/12/19	J.Ito					新規作成
--******************************************************************************
DECLARE
    ----------------------------------------------------------------------------
    --						標準定数定義
    ----------------------------------------------------------------------------
    -- 戻り値
    RET_OK		CONSTANT int := 0 ;						-- 正常終了コード
    RET_NG		CONSTANT int := -1 ;					-- 異常終了コード
    -- 真偽値
    CST_TRUE	CONSTANT int := 1 ;						-- 真
    CST_FALSE	CONSTANT int := 0 ;						-- 偽

    ----------------------------------------------------------------------------
    --						標準変数定義
    ----------------------------------------------------------------------------
    cst_MY_PRG	CONSTANT CHAR(32)	 := 'func_sasizu_sinchoku_color_no';
                                                        -- プログラム名
    cst_UPD_TIM	CHAR(17) ;								-- 更新時間
    l_err_pnt	CHAR(64) ;								-- エラー発生ポイント
    errbuff		varchar(256);							-- メッセージバッファ

    ----------------------------------------------------------------------------
    --						定数定義
    ----------------------------------------------------------------------------
    CST_ALL_LINE_NO		CONSTANT char(20)	:= '-1';	-- ライン番号

    ----------------------------------------------------------------------------
    --						変数定義
    ----------------------------------------------------------------------------
    -- 共通変数
    rtn_sql_no		text;			-- DBエラー情報(エラー番号)
    rtn_sql_msg		text;			-- DBエラー情報(エラーメッセージ)
    rtn_sql_detail	text;			-- DBエラー情報(エラー詳細)
    rtn_sql_hint	text;			-- DBエラー情報(エラーヒント)
    rtn_sql_stack	text;			-- DBエラー情報(エラー発生呼出しスタック)

    -- ローカル変数
    l_exec_datetime	timestamp;		-- 関数実行日時
    l_set_color_no	int;			-- 設定する色番号
    l_setting_color_no	int;		-- すでに設定された色番号
    l_min_color_no	int;			-- 指定日最小の色番号
    l_max_color_no	int;			-- 指定日最大の色番号
    l_sasizu_no		char(12);		-- 指図番号

    ----------------------------------------------------------------------------
    --						カーソル定義
    ----------------------------------------------------------------------------
    -- 指図追番単位計画
    CUR_TBL_SEIHIN_PLAN2	CURSOR FOR
        SELECT
            a.sasizu_no
        FROM
            tbl_seihin_plan		a
        WHERE
            a.plant_code	=	i_plant_code
        AND	a.end_date		>=	i_proc_start_time
        AND	a.end_date		<=	i_proc_end_time
        AND	a.invalid_flag		=		0
        GROUP BY
            a.sasizu_no,
            a.end_date
        ORDER BY
            a.end_date
    ;
    OPENFLG_TBL_SEIHIN_PLAN2	int;	-- カーソルオープン状態


BEGIN
    ----------------------------------------------------------------------------
    --						初期処理
    ----------------------------------------------------------------------------
    raise info 'Start Function [%]', clock_timestamp()::timestamp;

    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S001';
    -- 共通変数初期化

    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S002';
    -- 共通出力パラメータ初期化
    o_ret_cd	:= RET_OK;
    o_sqlerr	:= ' ';
    o_errmsg	:= ' ';
    o_errpnt	:= ' ';

    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S003';
    -- 出力パラメータ初期化
    -- なし

    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S004';
    -- ローカル変数初期化
    l_set_color_no	:=	0;
    l_min_color_no	:=	0;
    l_max_color_no	:=	0;
    l_sasizu_no		:=	'';

    l_err_pnt	:= RTRIM(cst_MY_PRG) || '_S005';
    -- 関数実行日時
    l_exec_datetime := clock_timestamp();


    ----------------------------------------------------------------------------
    -- メイン処理
    ----------------------------------------------------------------------------

    l_err_pnt := RTRIM(cst_MY_PRG) || '_101';
    -- 指定日に既に設定している色番号を取得
    SELECT INTO
        l_min_color_no,
        l_max_color_no

        MIN(color_no)	as min_color_no,
        MAX(color_no)	as max_color_no
    FROM
        tbl_sasizu_sinchoku_color_no
    WHERE
        plant_code	=	i_plant_code
    AND	data_date	=	i_proc_start_time
    ;

    l_err_pnt := RTRIM(cst_MY_PRG) || '_102';
    -- 既に設定している色番号がない場合、0を設定
    IF NOT FOUND OR l_max_color_no IS NULL THEN
        l_set_color_no	:= 	0;
    -- 既に設定している色番号がある場合、最大値＋１
    ELSE
        l_set_color_no	:= l_max_color_no + 1;
    END IF;

    l_err_pnt := RTRIM(cst_MY_PRG) || '_201';
    -- 指図追番単位計画を開いているならクローズ
    IF OPENFLG_TBL_SEIHIN_PLAN2 = CST_TRUE THEN
        CLOSE CUR_TBL_SEIHIN_PLAN2;
        OPENFLG_TBL_SEIHIN_PLAN2 := CST_FALSE;
    END IF;

    l_err_pnt := RTRIM(cst_MY_PRG) || '_202';
    -- 指図追番単位計画をオープン
    OPEN CUR_TBL_SEIHIN_PLAN2;
    OPENFLG_TBL_SEIHIN_PLAN2 := CST_TRUE;

    << SEIHIN_PLAN_LOOP >>
    LOOP
            l_err_pnt := RTRIM(cst_MY_PRG) || '_203';
            -- 指図追番単位計画からフェッチ
            FETCH CUR_TBL_SEIHIN_PLAN2 INTO l_sasizu_no;
            IF FOUND = FALSE THEN
                EXIT SEIHIN_PLAN_LOOP;
            END IF;

            l_err_pnt := RTRIM(cst_MY_PRG) || '_204';
            -- 既に設定している色番号がないかチェック
            SELECT INTO
                l_setting_color_no
                color_no
            FROM
                tbl_sasizu_sinchoku_color_no
            WHERE
                plant_code			=	i_plant_code
            AND sasizu_no		=	l_sasizu_no
            ;
            -- 既に設定している色番号がある場合、次指図番号へ
            IF FOUND THEN
                l_err_pnt := RTRIM(cst_MY_PRG) || '_205';
                CONTINUE SEIHIN_PLAN_LOOP;
            END IF;

             -- 指図進捗情報用色番号に追加
            l_err_pnt := RTRIM(cst_MY_PRG) || '_301';
            INSERT INTO TBL_SASIZU_SINCHOKU_COLOR_NO
            (
                  SASIZU_NO			--指図番号
                , PLANT_CODE		--工場コード
                , DATA_DATE			--データ日付
                , COLOR_NO			--表示色用の番号
                , INS_PROG			--登録プログラム名
                , INS_TIM			--登録日時
                , INS_USER_SID		--登録ユーザSID
                , UPD_PROG			--更新プログラム名
                , UPD_TIM			--更新日時
                , UPD_USER_SID		--更新ユーザSID
            )
            VALUES
            (
                  l_sasizu_no		-- 指図番号
                , i_plant_code		-- 工場コード
                , i_proc_start_time	-- データ日付
                , l_set_color_no	-- 表示色用の番号
                , cst_MY_PRG		-- 登録プログラム名
                , l_exec_datetime	-- 登録日時
                , i_user_sid		-- 登録ユーザSID
                , cst_MY_PRG		-- 更新プログラム名
                , l_exec_datetime	-- 更新日時
                , i_user_sid		-- 更新ユーザSID
            );

            l_err_pnt := RTRIM(cst_MY_PRG) || '_302';
            -- 設定する表示色用の番号をインクリメント
            l_set_color_no := l_set_color_no + 1;

     END LOOP SEIHIN_PLAN_LOOP;

    ----------------------------------------------------------------------------
    --						終了処理
    ----------------------------------------------------------------------------
    -- カーソルクローズ
    l_err_pnt := RTRIM(cst_MY_PRG) || '_E001';
    IF OPENFLG_TBL_SEIHIN_PLAN2 = CST_TRUE THEN
        CLOSE CUR_TBL_SEIHIN_PLAN2;
        OPENFLG_TBL_SEIHIN_PLAN2 := CST_FALSE;
    END IF;

    raise info 'End Function [%]', clock_timestamp()::timestamp;


EXCEPTION WHEN OTHERS THEN
    -- DB例外情報収集
    GET STACKED DIAGNOSTICS rtn_sql_no     = RETURNED_SQLSTATE,
                            rtn_sql_msg    = MESSAGE_TEXT,
                            rtn_sql_detail = PG_EXCEPTION_DETAIL,
                            rtn_sql_hint   = PG_EXCEPTION_HINT,
                            rtn_sql_stack  = PG_EXCEPTION_CONTEXT;

    raise info 'DB ExError : (%) : %', trim(rtn_sql_no), trim(rtn_sql_msg);
    raise info '             %, %, %', trim(rtn_sql_hint), trim(rtn_sql_hint), trim(rtn_sql_stack);

    o_ret_cd := RET_NG;
    o_sqlerr := substr(rtn_sql_no, 1, 15);
    o_errmsg := substr(rtn_sql_msg, 1, 127);
    o_errpnt := l_err_pnt;

    raise info 'End Function (Exception) [%]', clock_timestamp()::timestamp;
END;
$BODY$
LANGUAGE plpgsql;