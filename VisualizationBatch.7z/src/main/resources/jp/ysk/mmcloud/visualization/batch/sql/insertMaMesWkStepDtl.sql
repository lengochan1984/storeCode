WITH
	val AS (
		SELECT
			(	(
				/*createdOn*/,
				/*createdBy*/,
				/*modifiedOn*/,
				/*modifiedBy*/,
				/*invalidFlag*/,
				/*jobPtnId*/,
				/*jobNo*/,
				/*sagyoSeq*/,
				/*sagyoNo*/,
				/*stepNo*/,
				/*stId*/,
				/*machineStep*/,
				/*pgmNo*/,
				/*stdHourHigh*/,
				/*stdHourMiddle*/,
				/*stdHourLow*/,
				/*seqNo*/,
				/*optionStep*/,
				/*spareNum1*/,
				/*spareNum2*/,
				/*spareNum3*/,
				/*spareText1*/,
				/*spareText2*/,
				/*spareText3*/,
				'insert-MA_MES_WK_STEP_DTL',
				now(),
				0,
				'insert-MA_MES_WK_STEP_DTL',
				now(),
				0
				)::MA_MES_WK_STEP_DTL).*
	),

	upd AS (
		UPDATE
			MA_MES_WK_STEP_DTL
		SET
			modified_on			= CAST(/*modifiedOn*/ AS timestamp),
			modified_by			= /*modifiedBy*/,
			invalid_flag		= /*invalidFlag*/,
			job_no				= CAST(/*jobNo*/ AS numeric),
			sagyo_seq			= /*sagyoSeq*/,
			sagyo_no			= /*sagyoNo*/,
			st_id				= CAST(/*stId*/ AS numeric),
			machine_step		= /*machineStep*/,
			pgm_no				= /*pgmNo*/,
			std_hour_high		= CAST(/*stdHourHigh*/ AS numeric),
			std_hour_middle		= CAST(/*stdHourMiddle*/ AS numeric),
			std_hour_low		= CAST(/*stdHourLow*/ AS numeric),
			seq_no				= CAST(/*seqNo*/ AS numeric),
			option_step			= /*optionStep*/,
			spare_num1			= CAST(/*spareNum1*/ AS numeric),
			spare_num2			= CAST(/*spareNum2*/ AS numeric),
			spare_num3			= CAST(/*spareNum3*/ AS numeric),
			spare_text1			= /*spareText1*/,
			spare_text2			= /*spareText2*/,
			spare_text3			= /*spareText3*/,
			upd_prog			= 'update-MA_MES_WK_STEP_DTL',
			upd_tim 			= now(),
			upd_user_sid		= 0
		FROM
			val
		WHERE
			MA_MES_WK_STEP_DTL.job_ptn_id	= /*jobPtnId*/
		AND MA_MES_WK_STEP_DTL.step_no		= /*stepNo*/

		RETURNING
			MA_MES_WK_STEP_DTL.job_ptn_id,
			MA_MES_WK_STEP_DTL.step_no
	)

INSERT INTO
	MA_MES_WK_STEP_DTL
SELECT
	*
FROM
	val
WHERE
	(job_ptn_id, step_no)
		NOT IN (SELECT job_ptn_id, step_no FROM upd);
