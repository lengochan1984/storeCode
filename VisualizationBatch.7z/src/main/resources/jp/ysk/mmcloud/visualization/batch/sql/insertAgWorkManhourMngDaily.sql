WITH
    val AS (
        SELECT
            (   (
				/*sasizuNo*/,
				/*subNo*/,
				/*jobPtnId*/,
				/*stepNo*/,
				/*dataDate*/,
				/*seizouLnCd*/,
				/*seizouLnNm*/,
				/*processCd*/,
				/*processNm*/,
				/*lnNo*/,
				/*lnNm*/,
				/*jobPtnName*/,
				/*standardManhour*/,
				/*workManhourAverage*/,
				/*standardDeviation*/,
				/*parameter*/,
				/*insProg*/,
				/*insTim*/,
				/*insUserSid*/,
				/*updProg*/,
				/*updTim*/,
				/*updUserSid*/
                )::ag_work_manhour_mng_daily).*
    ),

    upd AS (
        UPDATE
            ag_work_manhour_mng_daily
        SET
			seizou_ln_cd		= /*seizouLnCd*/,
			seizou_ln_nm		= /*seizouLnNm*/,
			process_cd			= /*processCd*/,
			process_nm			= /*processNm*/,
			ln_no				= /*lnNo*/,
			ln_nm				= /*lnNm*/,
			job_ptn_name		= /*jobPtnName*/,
			standard_manhour	= CAST(/*standardManhour*/ AS integer),
			work_manhour_average	= CAST(/*workManhourAverage*/ AS numeric),
			standard_deviation	= CAST(/*standardDeviation*/ AS numeric),
			parameter			= CAST(/*parameter*/ AS integer),
			ins_prog			= /*insProg*/,
			ins_tim				= CAST(/*insTim*/ AS timestamp),
			ins_user_sid		= CAST(/*insUserSid*/ AS integer),
			upd_prog			= /*updProg*/,
			upd_tim				= CAST(/*updTim*/ AS timestamp),
			upd_user_sid		= CAST(/*updUserSid*/ AS integer)
        FROM
            val
        WHERE
            ag_work_manhour_mng_daily.sasizu_no		= /*sasizuNo*/
        AND ag_work_manhour_mng_daily.sub_no		= /*subNo*/
        AND ag_work_manhour_mng_daily.job_ptn_id	= /*jobPtnId*/
        AND ag_work_manhour_mng_daily.step_no		= /*stepNo*/
        AND ag_work_manhour_mng_daily.data_date		= /*dataDate*/

        RETURNING
            ag_work_manhour_mng_daily.sasizu_no,
            ag_work_manhour_mng_daily.sub_no,
            ag_work_manhour_mng_daily.job_ptn_id,
            ag_work_manhour_mng_daily.step_no,
            ag_work_manhour_mng_daily.data_date
    )

INSERT INTO
    ag_work_manhour_mng_daily
SELECT
    *
FROM
    val
WHERE
    (sasizu_no, sub_no, job_ptn_id, step_no, data_date)
        NOT IN (SELECT sasizu_no, sub_no, job_ptn_id, step_no, data_date FROM upd);
