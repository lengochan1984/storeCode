/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/28| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferStTmInfoDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferStTmInfoMesDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * ステーション間トレースログテーブル登録処理.<br>
 *<br>
 * 概要:<br>
 * ステーション間トレースログテーブルをMesデータから登録する処理
 *<br>
 */
public class TransferStTmInfoService extends TransferDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferStTmInfoMesDao> tlMesDao = new ThreadLocal<TransferStTmInfoMesDao>() {
        @Override
        protected TransferStTmInfoMesDao initialValue() {
            return new TransferStTmInfoMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferStTmInfoMesDao getTransferStTmInfoMesDao() {
        return tlMesDao.get();
    }

    /**
     * Dao.
     */
    private static ThreadLocal<TransferStTmInfoDao> tlDao = new ThreadLocal<TransferStTmInfoDao>() {
        @Override
        protected TransferStTmInfoDao initialValue() {
            return new TransferStTmInfoDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static TransferStTmInfoDao getTransferStTmInfoDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferStTmInfoService.getTransferStTmInfoMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferStTmInfoService.getTransferStTmInfoDao();
    }

    @Override
    protected String getSelectMesDataSqlFileName() {
        return "selectStTmInfo.sql";
    }

    @Override
    protected String getAddTableName() {
        return "tr_st_tm_info";
    }

    @Override
    protected String getInsertFileName() {
        return "insertStTmInfo.sql";
    }

    @Override
    protected boolean isInsertWorkTable() {
        return true;
    }

    @Override
    protected String getInsertWorkTableFileName() {
        return "insertStTmInfoWk.sql";
    }

}
