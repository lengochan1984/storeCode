/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/23| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 *  2017/09/19| <C1.02>　複数MES-DB接続対応                                          | C1.02  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.dao;

import java.util.List;

import org.seasar.extension.jdbc.where.SimpleWhere;
import org.seasar.framework.beans.util.BeanMap;

import jp.ysk.mmcloud.common.entity.customer.SysEnvEntity;
import jp.ysk.mmcloud.common.entity.customer.SysEnvEntityNames;
import jp.ysk.mmcloud.common.entity.root.SysDbConnectEntity;
import jp.ysk.mmcloud.visualization.batch.dto.ProcedureBaseParamDto;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseCustomerSchemaDao;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrTransferDatetimeEntity;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrTransferDatetimeEntityNames;

/**
 *
 * バッチ処理共通Dao.<br>
 *<br>
 * 概要:<br>
 *  バッチ処理共通Daoクラス
 *<br>
 */
public class BatchBaseDao extends CM_BaseCustomerSchemaDao {
    /**
     * 顧客ID(ログ用).
     */
    protected String companyId;

    /**
     * 実行プロセス名(ログ用).
     */
    protected String processName;

    /**
     * SQL共通ファイルパス.
     *
     */
    public static final String SQL_PATH_BATCH_COMM = "jp/ysk/mmcloud/visualization/batch/sql/";

    /**
     * コンストラクタ.
     *
     * @param _entity DB接続情報
     * @param _companyId 顧客ID
     * @param _processName プロセス名
     * @param _queryTimeout クエリタイムアウト値
     */
    public void init(final SysDbConnectEntity _entity, final String _companyId, final String _processName, final int _queryTimeout) {
        this.setCustomerDbInfo(_entity.connectString, _entity.userName, _entity.passwd, _queryTimeout);

        this.companyId = _companyId;
        this.processName = _processName;
    }

    /**
     *
     * ストアドプロシージャ実行.<br>
     *<br>
     * 概要:<br>
     * ストアドプロシージャ実行処理
     *<br>
     * @param _procedureName ストアドプロシージャの名前
     * @param _paramDto 引数情報
     */
    public void executeProcedure(final String _procedureName, final ProcedureBaseParamDto _paramDto) {

        // ストアドプロシージャ実行
        this.jdbcManager.call(_procedureName, _paramDto).execute();
    }

    /**
     *
     * 環境マスタ情報一覧取得.<br>
     *<br>
     * 概要:<br>
     * 環境コードを元に環境マスタ情報一覧を取得する
     *<br>
     * @param _envCd 環境CD
     * @return 環境マスタ情報一覧
     */
    public List<SysEnvEntity> selectSysEnvList(final String _envCd) {

        List<SysEnvEntity> ret = this.jdbcManager.from(SysEnvEntity.class).where(new SimpleWhere().eq(SysEnvEntityNames.envCd(), _envCd)).getResultList();

        return ret;
    }

    /**
     *
     * MES-DB連携結果取得.<br>
     *<br>
     * 概要:<br>
     * MES-DB連携結果取得処理
     *<br>
     * @param _addTableName テーブル名
     * @param _connectStr 接続文字列
     * @param _userId ユーザID
     * @return MES-DB連携結果
     */
    public TrTransferDatetimeEntity selectAddDatetime(final String _addTableName, final String _connectStr, final String _userId) {

        SimpleWhere where = new SimpleWhere();
        where.eq(TrTransferDatetimeEntityNames.connectionString(), _connectStr);
        where.eq(TrTransferDatetimeEntityNames.userId(), _userId);
        where.eq(TrTransferDatetimeEntityNames.tableName(), _addTableName);

        TrTransferDatetimeEntity ret = this.jdbcManager.from(TrTransferDatetimeEntity.class).where(where).getSingleResult();

        return ret;
    }

    /**
     *
     * MESデータ登録処理.<br>
     *<br>
     * 概要:<br>
     * MESデータ登録処理
     *<br>
     * @param _sqlFileName SQLファイル名
     * @param _mesData MESデータ
     * @return 登録件数
     */
    public long executeInsertMesData(final String _sqlFileName, final BeanMap _mesData) {

        long ret = this.jdbcManager.updateBySqlFile(SQL_PATH_BATCH_COMM + _sqlFileName, _mesData).execute();

        return ret;
    }

    /**
     *
     * 見える化DBデータ削除処理.<br>
     *<br>
     * 概要:<br>
     * 見える化DBデータ登録処理
     *<br>
     * @param _sqlFileName SQLファイル名
     * @return 削除件数
     */
    public long executeDeleteMierukaData(final String _sqlFileName) {

        long ret = this.jdbcManager.updateBySqlFile(SQL_PATH_BATCH_COMM + _sqlFileName, null).execute();

        return ret;
    }

    /**
     *
     * MES-DB連携結果登録・更新処理.<br>
     *<br>
     * 概要:<br>
     * MES-DB連携結果登録・更新処理
     *<br>
     * @param _entity MES-DB連携結果テーブルEntity
     * @return 更新件数
     */
    public long updateAddDatetime(final TrTransferDatetimeEntity _entity) {

        long ret = this.jdbcManager.update(_entity).execute();

        if (ret == 0) {
            // 更新件数が0の場合、登録処理実行
            ret = this.jdbcManager.insert(_entity).execute();
        }

        return ret;
    }

    /**
     * 工場マスタ（見える化専用）取得.
     * @param _param パラメータ
     * @return 工場マスタ（見える化専用）データリスト
     */
    public List<BeanMap> selectMaPlantMierukaList(final BeanMap _param) {

        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(
                BeanMap.class, SQL_PATH_BATCH_COMM + "selectMaPlantMieruka.sql", _param).getResultList();

        return ret;
    }
}
