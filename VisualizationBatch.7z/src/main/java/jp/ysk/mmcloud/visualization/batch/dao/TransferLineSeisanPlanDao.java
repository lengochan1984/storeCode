/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/09/06| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.dao;

import java.util.List;

import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

import org.seasar.framework.beans.util.BeanMap;

/**
 *
 * 生産計画テーブル登録スキーマDao.<br>
 *<br>
 * 概要:<br>
 *  生産計画テーブル登録MESスキーマクラス
 *<br>
 */
public class TransferLineSeisanPlanDao extends BatchBaseDao {
    /**
    *
    * Mierukaデータ取得.<br>
    *<br>
    * 概要:<br>
    * 登録するMierukaデータを取得する
    *<br>
    * @param _sqlFileName SQLファイル名
    * @param _param パラメータ
    * @return 登録するMierukaデータ
    */
    public List<BeanMap> selectMierukaData(final String _sqlFileName, final BeanMap _param) {

        List<BeanMap> ret = this.jdbcManager.selectBySqlFile(BeanMap.class, CM_BaseMesSchemaDao.SQL_PATH_COMM + _sqlFileName, _param).getResultList();

        return ret;
    }
}
