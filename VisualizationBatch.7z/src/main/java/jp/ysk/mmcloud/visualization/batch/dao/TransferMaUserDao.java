/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/09/12| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.dao;

import jp.ysk.mmcloud.common.CM_A04_Const;
import jp.ysk.mmcloud.common.entity.customer.MstMailAddressEntity;
import jp.ysk.mmcloud.common.entity.customer.MstRoleEntity;
import jp.ysk.mmcloud.common.entity.customer.MstRoleEntityNames;
import jp.ysk.mmcloud.common.entity.customer.MstUserEntity;
import jp.ysk.mmcloud.common.entity.customer.MstUserEntityNames;
import jp.ysk.mmcloud.common.entity.customer.RelUserGroupEntity;
import jp.ysk.mmcloud.common.entity.customer.RelUserRoleEntity;
import jp.ysk.mmcloud.common.entity.customer.SysNameEntity;
import jp.ysk.mmcloud.common.entity.customer.SysNameEntityNames;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;

import org.seasar.extension.jdbc.where.SimpleWhere;

/**
 *
 * 作業者マスタスキーマDao.<br>
 *<br>
 * 概要:<br>
 *  作業者マスタスキーマDaoクラス
 *<br>
 */
public class TransferMaUserDao extends BatchBaseDao {

    /**
     *
     * ユーザマスタ取得.<br>
     *<br>
     * 概要:<br>
     * ユーザマスタ取得処理
     *<br>
     * @param _userId ユーザID
     * @return ユーザマスタ
     */
    public MstUserEntity selectUserInfo(final String _userId) {

        SimpleWhere where = new SimpleWhere();
        where.eq(MstUserEntityNames.id(), _userId);

        MstUserEntity ret = this.jdbcManager.from(MstUserEntity.class).where(where).getSingleResult();

        return ret;
    }

    /**
     *
     * 名称マスタのデフォルト値取得.<br>
     *<br>
     * 概要:<br>
     *  名称マスタのデフォルト値取得
     *<br>
     * @param _nameType 名称種別
     * @param _langCd 言語コード
     * @return 名称マスタのデフォルト値
     */
    public SysNameEntity selectDefaultSysName(final String _nameType, final String _langCd) {
        SimpleWhere where = new SimpleWhere();
        where.eq(SysNameEntityNames.nameType(), _nameType);
        where.eq(SysNameEntityNames.langCd(), _langCd);
        where.eq(SysNameEntityNames.defaultFlag(), 1);

        SysNameEntity ret = this.jdbcManager.from(SysNameEntity.class).where(where).getSingleResult();

        return ret;
    }

    /**
     *
     * ユーザマスタ登録処理.<br>
     *<br>
     * 概要:<br>
     *  ユーザマスタ登録処理
     *<br>
     * @param _userEntity ユーザマスタ情報
     * @return 更新件数
     */
    public long insertMaUser(final MstUserEntity _userEntity) {
        // ユーザSIDがnullの場合、新規登録
        // SIDの生成
        _userEntity.sid = this.jdbcManager.selectBySql(Integer.class,
                CM_CommonUtil.getSeqSQL(CM_A04_Const.SEQ.USER)).getSingleResult();
        long ret = this.jdbcManager.insert(_userEntity).execute();

        return ret;
    }

    /**
     *
     * ユーザマスタ更新処理.<br>
     *<br>
     * 概要:<br>
     *  ユーザマスタ更新処理
     *<br>
     * @param _userEntity ユーザマスタ情報
     * @return 更新件数
     */
    public long updateMaUser(final MstUserEntity _userEntity) {

        long ret = this.jdbcManager.update(_userEntity).excludesNull().execute();
        return ret;
    }

    /**
     *
     * 役割のデフォルト値を取得.<br>
     *<br>
     * 概要:<br>
     * 役割のデフォルト値を取得
     *<br>
     * @return 役割のデフォルト値
     */
    public MstRoleEntity selectDefaultRoleEntity() {

        SimpleWhere where = new SimpleWhere();
        where.eq(MstRoleEntityNames.defaultFlag(), 1);

        MstRoleEntity ret = this.jdbcManager.from(MstRoleEntity.class).where(where).getSingleResult();

        return ret;
    }

    /**
     *
     * ユーザ役割関連データ登録.<br>
     *<br>
     * 概要:<br>
     *  ユーザ役割関連データ登録処理
     *<br>
     * @param _relUserRole ユーザ役割関連データ
     * @return 登録件数
     */
    public long insertRelUserRole(final RelUserRoleEntity _relUserRole) {
        long ret = this.jdbcManager.insert(_relUserRole).execute();

        return ret;
    }

    /**
     *
     * ユーザグループ関連データ登録.<br>
     *<br>
     * 概要:<br>
     *   ユーザグループ関連データ登録処理
     *<br>
     * @param _relUserGroup ユーザグループ関連データ
     * @return 登録件数
     */
    public long insertRelUserGroup(final RelUserGroupEntity _relUserGroup) {
        long ret = this.jdbcManager.insert(_relUserGroup).execute();

        return ret;
    }

    /**
     *
     * メールアドレスマスタ追加処理.<br>
     *<br>
     * 概要:<br>
     *  メールアドレスを追加する。
     *<br>
     * @param _mailAddress Entity情報
     * @return 登録件数
     */
    public long insertMailAddress(final MstMailAddressEntity _mailAddress) {

        // SIDの生成
        _mailAddress.sid = this.jdbcManager.selectBySql(Integer.class,
                CM_CommonUtil.getSeqSQL(CM_A04_Const.SEQ.MAIL_ADDRESS)).getSingleResult();

        // DB挿入処理
        long retCnt = this.jdbcManager.insert(_mailAddress).execute();

        return retCnt;
    }

    /**
    *
    * 作業者マスタ更新.<br>
    *<br>
    * 概要:<br>
    *   作業者マスタを更新
    *<br>
    * @param _userId ユーザID
    * @return 更新件数
    */
    public long updateMaUser(final String _userId) {

        long ret = this.jdbcManager.updateBySqlFile(SQL_PATH_BATCH_COMM + "updateMaUser.sql", _userId).execute();

        return ret;
    }
}
