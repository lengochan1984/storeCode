/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/23| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 *  2017/09/19| <C1.02>　複数MES-DB接続対応                                 | C1.02  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import javax.annotation.Resource;

import jp.ysk.fw.FW00_12_AppException;
import jp.ysk.mmcloud.common.dao.CM_ResourceUtilDao;
import jp.ysk.mmcloud.common.entity.root.MstCustomerEntity;
import jp.ysk.mmcloud.common.entity.root.SysDbConnectEntity;
import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.common.batch.util.CM_BatchLoggerUtil;


/**
 *
 * スレッドローカルデータクラス.<br>
 *<br>
 * 概要:<br>
 *  バッチ処理サービス共通クラスのスレッドローカルデータクラス
 *<br>
 */
class TLDataBatchBase {

    /**
     * 工場コード.
     */
    private String plantCode;

    /**
     * 工場コード取得.
     * @return 工場コード
     */
    public String getPlantCode() {
        return this.plantCode;
    }

    /**
     * 工場コード設定.
     * @param _plantCode 工場コード
     */
    public void setPlantCode(final String _plantCode) {
        this.plantCode = _plantCode;
    }
}

/**
 *
 * バッチ処理サービス共通クラス.<br>
 *<br>
 * 概要:<br>
 *  バッチ処理サービス共通クラス
 *<br>
 */
public abstract class BatchBaseService {

    /**
     * リソース関連処理Dao.
     */
    @Resource
    public CM_ResourceUtilDao cM_ResourceUtilDao;

    /**
     * DB接続Entity.
     */
    public SysDbConnectEntity sysDbConnectionEntity;

    /**
     * 顧客ID.
     */
    public String companyId;

    /**
     * 実行プロセス名.
     */
    public String processName;

    /**
     * PostgreSQLクエリタイムアウト値.
     */
    public int queryTimeout;

    /**
     * スレッドローカルデータ.
     */
    private static ThreadLocal<TLDataBatchBase> tl = new ThreadLocal<TLDataBatchBase>() {
        @Override
        protected TLDataBatchBase initialValue() {
            return new TLDataBatchBase();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return スレッドローカルデータ
     */
    private static TLDataBatchBase getTLDataBatchBase() {
        return tl.get();
    }

    /**
     * 工場コード取得.
     * @return 工場コード
     */
    public static String getPlantCode() {
        return getTLDataBatchBase().getPlantCode();
    }

    /**
     * 工場コード設定.
     * @param _plantCode 工場コード
     */
    public static void setPlantCode(final String _plantCode) {
        getTLDataBatchBase().setPlantCode(_plantCode);
    }

   /**
     *
     * 業務処理前処理.<br>
     *<br>
     * 概要:<br>
     *   業務処理前の処理を行う
     *<br>
     */
    public void beforeExecute() {
        this.connectCustomerDb();
    }

    /**
     *
     * 顧客DB接続.<br>
     *<br>
     * 概要:<br>
     * 顧客DB接続処理
     *<br>
     */
    public void connectCustomerDb() {

        // 顧客情報取得
        MstCustomerEntity customerEntity = this.cM_ResourceUtilDao.getCustomerEntity(this.companyId);
        if (customerEntity == null) {
            // 顧客IDが存在しない場合
            CM_BatchLoggerUtil.outputLog(this.companyId, this.processName,
                    "companyId=" + this.companyId + " is not exist.");

            // 例外を発生させて以降の処理をスキップする
            throw new FW00_12_AppException("Not exist companyId");
        }

        // 接続文字列、ユーザ名、パスワード
        this.sysDbConnectionEntity = this.cM_ResourceUtilDao.getDbConnectionEntity(customerEntity.sid);

        // 顧客スキーマ用のDaoを生成
        this.getBatchDao().init(this.sysDbConnectionEntity, this.companyId, this.processName, this.queryTimeout);
    }

    /**
     *
     * 業務処理.<br>
     *<br>
     * 概要:<br>
     *   業務処理を実行する
     *<br>
     */
    public abstract void execute();
    /**
     *
     * 終了処理.<br>
     *<br>
     * 概要:<br>
     *   業務処理の後処理を実行する
     *<br>
     */
    public void endProcess() {
        return;
    }

    /**
     *
     * Dao取得.<br>
     *<br>
     * 概要:<br>
     *   バッチ処理Dao
     *<br>
     * @return バッチ処理Dao
     */
    public abstract BatchBaseDao getBatchDao();

}
