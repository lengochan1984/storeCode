/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/28| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import java.math.BigDecimal;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferProductTrcDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferProductTrcMesDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * 製品トレースログテーブル登録処理.<br>
 *<br>
 * 概要:<br>
 * 製品トレースログテーブルをMesデータから登録する処理
 *<br>
 */
public class TransferProductTrcService extends TransferDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferProductTrcMesDao> tlMesDao = new ThreadLocal<TransferProductTrcMesDao>() {
        @Override
        protected TransferProductTrcMesDao initialValue() {
            return new TransferProductTrcMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferProductTrcMesDao getTransferProductTrcMesDao() {
        return tlMesDao.get();
    }

    /**
     * Dao.
     */
    private static ThreadLocal<TransferProductTrcDao> tlDao = new ThreadLocal<TransferProductTrcDao>() {
        @Override
        protected TransferProductTrcDao initialValue() {
            return new TransferProductTrcDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static TransferProductTrcDao getTransferProductTrcDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferProductTrcService.getTransferProductTrcMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferProductTrcService.getTransferProductTrcDao();
    }

    @Override
    protected String getSelectMesDataSqlFileName() {
        return "selectProductTrc.sql";
    }

    @Override
    protected String getAddTableName() {
        return "tr_product_trc";
    }

    @Override
    protected String getInsertFileName() {
        return "insertProductTrc.sql";
    }

    @Override
    protected boolean isInsertWorkTable() {
        return true;
    }

    @Override
    protected String getInsertWorkTableFileName() {
        return "insertProductTrcWk.sql";
    }

}
