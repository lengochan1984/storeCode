/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/09/06| <C1.01>　新規作成                                                    | C1.01  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferAgWorkManhourMngSDailyMesDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * 作業工数実績(シリーズ別)(日別)集計テーブル登録処理.<br>
 *<br>
 * 概要:<br>
 * 作業工数実績(シリーズ別)(日別)集計テーブルをMesデータから登録する処理
 *<br>
 */
public class TransferAgWorkManhourMngSDailyService extends TransferAgDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferAgWorkManhourMngSDailyMesDao> tlMesDao = new ThreadLocal<TransferAgWorkManhourMngSDailyMesDao>() {
        @Override
        protected TransferAgWorkManhourMngSDailyMesDao initialValue() {
            return new TransferAgWorkManhourMngSDailyMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferAgWorkManhourMngSDailyMesDao getTransferAgWorkManhourMngSDailyMesDao() {
        return tlMesDao.get();
    }

    /**
     * Dao.
     */
    private static ThreadLocal<BatchBaseDao> tlDao = new ThreadLocal<BatchBaseDao>() {
        @Override
        protected BatchBaseDao initialValue() {
            return new BatchBaseDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static BatchBaseDao getBatchBaseDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferAgWorkManhourMngSDailyService.getTransferAgWorkManhourMngSDailyMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferAgWorkManhourMngSDailyService.getBatchBaseDao();
    }

    @Override
    protected String getSelectMesDataSqlFileName() {
        return "selectAgWorkManhourMngSDaily.sql";
    }

    @Override
    protected String getAddTableName() {
        return "ag_work_manhour_mng_s_daily";
    }

    @Override
    protected String getInsertFileName() {
        return "insertAgWorkManhourMngSDaily.sql";
    }

}
