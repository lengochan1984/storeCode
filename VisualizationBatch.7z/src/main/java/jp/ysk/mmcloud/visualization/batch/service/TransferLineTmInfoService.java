/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/28| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferLineTmInfoMesDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * ライントレース間ログテーブル登録処理.<br>
 *<br>
 * 概要:<br>
 * ライントレース間ログテーブルをMesデータから登録する処理
 *<br>
 */
public class TransferLineTmInfoService extends TransferDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferLineTmInfoMesDao> tlMesDao = new ThreadLocal<TransferLineTmInfoMesDao>() {
        @Override
        protected TransferLineTmInfoMesDao initialValue() {
            return new TransferLineTmInfoMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferLineTmInfoMesDao getTransferLineTmInfoMesDao() {
        return tlMesDao.get();
    }

    /**
     * Dao.
     */
    private static ThreadLocal<BatchBaseDao> tlDao = new ThreadLocal<BatchBaseDao>() {
        @Override
        protected BatchBaseDao initialValue() {
            return new BatchBaseDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static BatchBaseDao getBatchBaseDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferLineTmInfoService.getTransferLineTmInfoMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferLineTmInfoService.getBatchBaseDao();
    }

    @Override
    protected String getSelectMesDataSqlFileName() {
        return "selectLineTmInfo.sql";
    }

    @Override
    protected String getAddTableName() {
        return "tr_line_tm_info";
    }

    @Override
    protected String getInsertFileName() {
        return "insertLineTmInfo.sql";
    }

    @Override
    protected boolean isInsertWorkTable() {
        return true;
    }

    @Override
    protected String getInsertWorkTableFileName() {
        return "insertLineTmInfoWk.sql";
    }

}
