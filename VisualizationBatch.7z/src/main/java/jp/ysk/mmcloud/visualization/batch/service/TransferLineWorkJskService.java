/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/28| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;


import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferLineWorkJskDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferLineWorkJskMesDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * ライントレースログテーブル登録処理.<br>
 *<br>
 * 概要:<br>
 * ライントレースログテーブルをMesデータから登録する処理
 *<br>
 */
public class TransferLineWorkJskService extends TransferDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferLineWorkJskMesDao> tlMesDao = new ThreadLocal<TransferLineWorkJskMesDao>() {
        @Override
        protected TransferLineWorkJskMesDao initialValue() {
            return new TransferLineWorkJskMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferLineWorkJskMesDao getTransferLineWorkJskMesDao() {
        return tlMesDao.get();
    }

    /**
     * Dao.
     */
    private static ThreadLocal<TransferLineWorkJskDao> tlDao = new ThreadLocal<TransferLineWorkJskDao>() {
        @Override
        protected TransferLineWorkJskDao initialValue() {
            return new TransferLineWorkJskDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static TransferLineWorkJskDao getTransferLineWorkJskDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferLineWorkJskService.getTransferLineWorkJskMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferLineWorkJskService.getTransferLineWorkJskDao();
    }

    @Override
    protected String getSelectMesDataSqlFileName() {
        return "selectLineWorkJsk.sql";
    }

    @Override
    protected String getAddTableName() {
        return "tr_line_work_jsk";
    }

    @Override
    protected String getInsertFileName() {
        return "insertLineWorkJsk.sql";
    }

    @Override
    protected boolean isInsertWorkTable() {
        return true;
    }

    @Override
    protected String getInsertWorkTableFileName() {
        return "insertLineWorkJskWk.sql";
    }

}
