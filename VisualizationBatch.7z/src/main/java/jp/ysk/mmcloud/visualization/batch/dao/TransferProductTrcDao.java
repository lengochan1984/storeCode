package jp.ysk.mmcloud.visualization.batch.dao;

/**
 *
 * 製品トレースログテーブル登録スキーマDao.<br>
 *<br>
 * 概要:<br>
 * 製品トレースログテーブル登録スキーマDaoクラス
 *<br>
 */
public class TransferProductTrcDao extends BatchBaseDao {

}
