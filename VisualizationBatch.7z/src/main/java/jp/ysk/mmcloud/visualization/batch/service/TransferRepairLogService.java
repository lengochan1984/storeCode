/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/11/17| <C1.01>　新規作成                                                    | C1.01  | H.Nakamura
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferRepairLogMesDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * リペアログテーブル登録処理.<br>
 *<br>
 * 概要:<br>
 * リペアログテーブルをMesデータから登録する処理
 *<br>
 */
public class TransferRepairLogService extends TransferDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferRepairLogMesDao> tlMesDao = new ThreadLocal<TransferRepairLogMesDao>() {
        @Override
        protected TransferRepairLogMesDao initialValue() {
            return new TransferRepairLogMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferRepairLogMesDao getTransferRepairLogMesDao() {
        return tlMesDao.get();
    }

    /**
     * Dao.
     */
    private static ThreadLocal<BatchBaseDao> tlDao = new ThreadLocal<BatchBaseDao>() {
        @Override
        protected BatchBaseDao initialValue() {
            return new BatchBaseDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static BatchBaseDao getBatchBaseDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferRepairLogService.getTransferRepairLogMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferRepairLogService.getBatchBaseDao();
    }

    @Override
    protected String getSelectMesDataSqlFileName() {
        return "selectRepairLog.sql";
    }

    @Override
    protected String getAddTableName() {
        return "tr_repair_log";
    }

    @Override
    protected String getInsertFileName() {
        return "insertRepairLog.sql";
    }

    @Override
    protected boolean isInsertWorkTable() {
        return true;
    }

    @Override
    protected String getInsertWorkTableFileName() {
        return "insertRepairLogWk.sql";
    }

}
