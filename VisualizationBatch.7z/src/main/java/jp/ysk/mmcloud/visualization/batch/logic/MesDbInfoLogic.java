/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/09/19| <C1.01>　新規作成（複数MES-DB接続対応）              | C1.01  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.logic;

import java.util.List;

import org.seasar.framework.beans.util.BeanMap;

import jp.ysk.mmcloud.visualization.batch.service.MesDbInfoService;

/**
 * MES-DB接続情報取得処理.<br>
 *<br>
 * 概要:<br>
 *  MES-DB接続情報取得処理
 *<br>
 */
public class MesDbInfoLogic {

    /**
     * 顧客ID.
     */
    private String companyId;

    /**
     * 処理プロセス名.
     */
    private String processName;

    /**
     * MES-DB接続情報取得処理サービスクラス.
     */
    public MesDbInfoService mesDbInfoService;

    /**
     * コンストラクタ.
     */
    public MesDbInfoLogic() {

    }

    /**
     * クエリタイムアウト(秒).
     * s2jdbc.diconのqueryTimeoutと設定をあわせること
     */
    private static final int QUERY_TIMEOUT = 600;

    /**
     *
     * 初期処理.<br>
     *<br>
     * 概要:<br>
     *   初期処理
     *<br>
     * @param _companyId 顧客ID
     * @param _processName 実行プロセス名
     */
    public void init(final String _companyId, final String _processName) {
        this.companyId = _companyId;
        this.processName = _processName;
    }

    /**
     * MES-DB接続情報取得.<br>
     * <br>
     * 概要:<br>
     *  工場マスタ（見える化専用）テーブルからデータを取得する.
     * @return 工場マスタ（見える化専用）テーブルデータリスト
     */
    public List<BeanMap> getMesDbInfo() {

        this.mesDbInfoService.companyId = this.companyId;
        this.mesDbInfoService.processName = this.processName;
        this.mesDbInfoService.queryTimeout = QUERY_TIMEOUT;

        // 顧客DB接続
        this.mesDbInfoService.connectCustomerDb();

        return this.mesDbInfoService.getMesDbInfo();
    }
}
