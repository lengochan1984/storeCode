/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/24| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;

/**
 *
 * 作業工数実績(品目別)プロシージャ起動処理Service.<br>
 *<br>
 * 概要:<br>
 * 作業工数実績(品目別)プロシージャ起動処理Serviceクラス
 *<br>
 */
public class WorkManhourMngHService extends ExecuteProcedureBaseService {

    /**
     * Dao.
     */
    public BatchBaseDao batchBaseDao;

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return this.batchBaseDao;
    }
}
