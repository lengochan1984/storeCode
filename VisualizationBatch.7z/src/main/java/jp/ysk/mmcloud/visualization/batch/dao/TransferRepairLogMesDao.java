/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/11/17| <C1.01>　新規作成                                                    | C1.01  | H.Nakamura
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.dao;

import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * リペアログテーブル登録MESスキーマDao.<br>
 *<br>
 * 概要:<br>
 * リペアログテーブル登録MESスキーマDaoクラス
 *<br>
 */
public class TransferRepairLogMesDao extends CM_BaseMesSchemaDao {

}
