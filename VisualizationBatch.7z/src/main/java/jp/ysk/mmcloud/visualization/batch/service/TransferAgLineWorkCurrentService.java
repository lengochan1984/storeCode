/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/09/06| <C1.01>　新規作成                                                    | C1.01  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferAgLineWorkCurrentMesDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * ライン予定/実績/計画(現状)集計テーブル登録処理.<br>
 *<br>
 * 概要:<br>
 * ライン予定/実績/計画(現状)集計テーブルをMesデータから登録する処理
 *<br>
 */
public class TransferAgLineWorkCurrentService extends TransferAgDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferAgLineWorkCurrentMesDao> tlMesDao = new ThreadLocal<TransferAgLineWorkCurrentMesDao>() {
        @Override
        protected TransferAgLineWorkCurrentMesDao initialValue() {
            return new TransferAgLineWorkCurrentMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferAgLineWorkCurrentMesDao getTransferAgLineWorkCurrentMesDao() {
        return tlMesDao.get();
    }

    /**
     * Dao.
     */
    private static ThreadLocal<BatchBaseDao> tlDao = new ThreadLocal<BatchBaseDao>() {
        @Override
        protected BatchBaseDao initialValue() {
            return new BatchBaseDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static BatchBaseDao getBatchBaseDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferAgLineWorkCurrentService.getTransferAgLineWorkCurrentMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferAgLineWorkCurrentService.getBatchBaseDao();
    }

    @Override
    protected String getSelectMesDataSqlFileName() {
        return "selectAgLineWorkCurrent.sql";
    }

    @Override
    protected String getAddTableName() {
        return "ag_line_work_current";
    }

    @Override
    protected String getInsertFileName() {
        return "insertAgLineWorkCurrent.sql";
    }

}
