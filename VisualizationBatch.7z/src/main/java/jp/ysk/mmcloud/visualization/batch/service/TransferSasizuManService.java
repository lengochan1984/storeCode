/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/08/29| <C1.01>　新規作成                                                    | C1.01  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferSasizuManMesDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * 指図作業手順割付テーブル登録処理.<br>
 *<br>
 * 概要:<br>
 * 指図作業手順割付テーブルをMesデータから登録する処理
 *<br>
 */
public class TransferSasizuManService extends TransferDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferSasizuManMesDao> tlMesDao = new ThreadLocal<TransferSasizuManMesDao>() {
        @Override
        protected TransferSasizuManMesDao initialValue() {
            return new TransferSasizuManMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferSasizuManMesDao getTransferSasizuManMesDao() {
        return tlMesDao.get();
    }

    /**
     * Dao.
     */
    private static ThreadLocal<BatchBaseDao> tlDao = new ThreadLocal<BatchBaseDao>() {
        @Override
        protected BatchBaseDao initialValue() {
            return new BatchBaseDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static BatchBaseDao getBatchBaseDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferSasizuManService.getTransferSasizuManMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferSasizuManService.getBatchBaseDao();
    }

    @Override
    protected String getSelectMesDataSqlFileName() {
        return "selectSasizuMan.sql";
    }

    @Override
    protected String getAddTableName() {
        return "tr_sasizu_man";
    }

    @Override
    protected String getInsertFileName() {
        return "insertSasizuMan.sql";
    }

}
