/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/02/23| <C1.01>　新規作成                                                    | C1.01  | H.Nakamura
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferMaLineMesDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * ラインマスタ登録処理.<br>
 *<br>
 * 概要:<br>
 * ラインマスタをMesデータから登録する処理
 *<br>
 */
public class TransferMaLineService extends TransferDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferMaLineMesDao> tlMesDao = new ThreadLocal<TransferMaLineMesDao>() {
        @Override
        protected TransferMaLineMesDao initialValue() {
            return new TransferMaLineMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferMaLineMesDao getTransferMaLineMesDao() {
        return tlMesDao.get();
    }

    /**
     * Dao.
     */
    private static ThreadLocal<BatchBaseDao> tlDao = new ThreadLocal<BatchBaseDao>() {
        @Override
        protected BatchBaseDao initialValue() {
            return new BatchBaseDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static BatchBaseDao getBatchBaseDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferMaLineService.getTransferMaLineMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferMaLineService.getBatchBaseDao();
    }

    @Override
    protected String getSelectMesDataSqlFileName() {
        return "selectMaLine.sql";
    }

    @Override
    protected String getAddTableName() {
        return "ma_line";
    }

    @Override
    protected String getInsertFileName() {
        return "insertMaLine.sql";
    }

}
