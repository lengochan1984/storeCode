/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/28| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.visualization.batch.dto.ProcedureBaseParamDto;
import jp.ysk.mmcloud.visualization.common.batch.CM_BatchConst;
import jp.ysk.mmcloud.visualization.common.batch.util.CM_BatchLoggerUtil;

/**
 *
 * プロシージャ実行BaseService.<br>
 *<br>
 * 概要:<br>
 *  プロシージャ実行共通Service
 *<br>
 */
public abstract class ExecuteProcedureBaseService extends BatchBaseService {

    /**
     * 実行プロシージャ名一覧.
     */
    private List<String> procedureNameList;

    /**
     *
     * 業務処理.<br>
     *<br>
     * 概要:<br>
     *   業務処理を実行する
     *<br>
     */
    @Override
    public void execute() {

        ProcedureBaseParamDto paramDto = new ProcedureBaseParamDto();
        try {
            this.getBatchDao().biginTransaction();
            // 共通パラメータ設定
            this.setCommonProcedureParam(paramDto);
            // 実行function共通パラメータ設定
            this.setProcedureParam(paramDto);
            boolean noError = true;

            for (String procedureName : this.getProcedureNameList()) {

                this.setProcessProcedureParam(paramDto, procedureName);

                // ファンクション実行
                this.getBatchDao().executeProcedure(procedureName, paramDto);

                if (CM_BatchConst.ResultCode.RET_NG == paramDto.getRetCd()) {
                    // 処理結果がNGの場合、エラーログを出力
                    CM_BatchLoggerUtil.outputErrorLog(this.companyId, this.processName, paramDto.getErrmsg());
                    this.getBatchDao().rollbackTransaction();
                    noError = false;
                    break;
                }
            }
            if (noError) {
                this.getBatchDao().commitTransaction();
            }
        } catch (Exception e) {
            this.getBatchDao().rollbackTransaction();
            CM_BatchLoggerUtil.outputErrorLog(this.companyId, this.processName, e);
        }
    }

    /**
     *
     * 共通プロシージャパラメータを設定.<br>
     *<br>
     * 概要:<br>
     * 共通プロシージャパラメータを設定
     *<br>
     * @param _paramDto 実行用引数情報
     */
    protected void setCommonProcedureParam(final ProcedureBaseParamDto _paramDto) {

        // バッチ処理名
        _paramDto.setBatchName(FW00_19_Const.EMPTY_STR);
        // ログ種別
        _paramDto.setLogType(CM_BatchConst.LogType.DEFAULT);
        // 登録ユーザSID
        _paramDto.setUserSid(CM_BatchConst.DEFAULT_USER_SID);
    }

    /**
     *
     * 実行共通プロシージャパラメータを設定.<br>
     *<br>
     * 概要:<br>
     * 同一トランザクション内で実行するプロシージャの共通パラメータ設定<br>
     * デフォルトで処理開始日時、処理終了日時に前日を設定<br>
     * 処理開始日時、処理終了日時に前日以外を設定する場合は、
     * 各Serviceでオーバーライドして実装すること
     *<br>
     * @param _paramDto 実行用引数情報
     */
    protected void setProcedureParam(final ProcedureBaseParamDto _paramDto) {
        // 前日を設定
        Calendar cal = Calendar.getInstance();
        // 現在日時設定
        cal.setTime(new Date());
        cal.add(Calendar.DAY_OF_MONTH, -1);
        Timestamp beforeDatetime = new Timestamp(cal.getTimeInMillis());

        // 開始日時設定
        _paramDto.setFromTime(beforeDatetime);

        // 終了日時設定
        _paramDto.setToTime(beforeDatetime);
    }

    /**
     *
     * 個別プロシージャパラメータを設定.<br>
     *<br>
     * 概要:<br>
     * 個別プロシージャパラメータを設定<br>
     * デフォルトで処理開始日時、処理終了日時に前日を設定<br>
     * 処理開始日時、処理終了日時に前日以外を設定する場合は、
     * 各Serviceでオーバーライドして実装すること
     *<br>
     * @param _paramDto 実行用引数情報
     * @param _procedureName プロシージャ名
     */
    protected void setProcessProcedureParam(final ProcedureBaseParamDto _paramDto, final String _procedureName) {

    }

    /**
     * 実行プロシージャ一覧を取得.
     *
     * @return 実行プロシージャ一覧
     */
    public List<String> getProcedureNameList() {
        return this.procedureNameList;
    }

    /**
     * 実行プロシージャ一覧を設定する.
     *
     * @param _procedureNameList 実行プロシージャ一覧
     */
    public void setProcedureNameList(final List<String> _procedureNameList) {
        this.procedureNameList = _procedureNameList;
    };

}
