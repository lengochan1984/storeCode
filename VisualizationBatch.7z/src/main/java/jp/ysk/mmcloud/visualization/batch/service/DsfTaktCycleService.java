/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/11/18| <C1.01>　新規作成                                                    | C1.01  | H.Nakamura
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dto.ProcedureBaseParamDto;

/**
 *
 * [サイネージ用]製造タクト/サイクルタイムプロシージャ起動処理Service.<br>
 *<br>
 * 概要:<br>
 * [サイネージ用]製造タクト/サイクルタイムプロシージャ起動処理Serviceクラス
 *<br>
 */
public class DsfTaktCycleService extends ExecuteProcedureBaseService {

    /**
     * Dao.
     */
    public BatchBaseDao batchBaseDao;

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return this.batchBaseDao;
    }

    @Override
    protected void setProcedureParam(final ProcedureBaseParamDto _paramDto) {
        Calendar cal = Calendar.getInstance();
        // 現在日時設定
        cal.setTime(new Date());
        // 終了日時設定
        _paramDto.setToTime(new Timestamp(cal.getTimeInMillis()));

        // 開始日時設定
        cal.add(Calendar.DAY_OF_MONTH, -1);
        _paramDto.setFromTime(new Timestamp(cal.getTimeInMillis()));
    }
}
