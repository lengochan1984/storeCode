/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/24| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import java.sql.Timestamp;
import java.util.Date;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dto.ProcedureBaseParamDto;

/**
 *
 * 製品生産計画実績(計画)プロシージャ起動処理Service.<br>
 *<br>
 * 概要:<br>
 * 製品生産計画実績(計画)プロシージャ起動処理Serviceクラス
 *<br>
 */
public class ProductMngPlanService extends ExecuteProcedureBaseService {

    /**
     * Dao.
     */
    public BatchBaseDao batchBaseDao;

    /*
     * (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#setProcedureParam(jp.ysk.mmcloud.visualization.batch.dto.ProcedureBaseParamDto)
     */
    @Override
    protected void setProcedureParam(final ProcedureBaseParamDto _paramDto) {
        // 当日を設定
        Date now = new Date();
        Timestamp nowDatetime = new Timestamp(now.getTime());

        // 開始日時設定
        _paramDto.setFromTime(nowDatetime);

        // 終了日時設定
        _paramDto.setToTime(nowDatetime);
    };

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return this.batchBaseDao;
    }
}
