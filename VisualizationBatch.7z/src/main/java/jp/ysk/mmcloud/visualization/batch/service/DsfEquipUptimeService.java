/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/24| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dto.ProcedureBaseParamDto;

/**
 *
 * [サイネージ用]設備稼働時間プロシージャ起動処理Service.<br>
 *<br>
 * 概要:<br>
 * [サイネージ用]設備稼働時間プロシージャ起動処理Serviceクラス
 *<br>
 */
public class DsfEquipUptimeService extends ExecuteProcedureBaseService {

    /**
     * プロセス分岐ケース.
     */
    public Map<String, String> processCaseMap;

    /**
     * 日別.
     */
    private static final String DAILY = "daily";

    /**
     * 月別.
     */
    private static final String MONTHLY = "monthly";

    /**
     * Dao.
     */
    public BatchBaseDao batchBaseDao;

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return this.batchBaseDao;
    }

    @Override
    protected void setProcedureParam(final ProcedureBaseParamDto _paramDto) {
        return;
    }

    @Override
    protected void setProcessProcedureParam(final ProcedureBaseParamDto _paramDto, final String _procedureName) {
        String processCase = this.processCaseMap.get(_procedureName);

        if (DAILY.equals(processCase)) {
            this.setDailyParam(_paramDto);
        } else if (MONTHLY.equals(processCase)) {
            this.setMonthlyParam(_paramDto);
        }
    }

    /**
     *
     * 日別処理パラメータ設定.<br>
     *<br>
     * 概要:<br>
     *  日別処理パラメータ設定処理
     *<br>
     * @param _paramDto 実行用引数情報
     */
    private void setDailyParam(final ProcedureBaseParamDto _paramDto) {
        // 前日を設定
        Calendar cal = Calendar.getInstance();
        // 現在日時設定
        cal.setTime(new Date());
        cal.add(Calendar.DAY_OF_MONTH, -1);
        Timestamp beforeDatetime = new Timestamp(cal.getTimeInMillis());

        // 開始日時設定
        _paramDto.setFromTime(beforeDatetime);

        // 終了日時設定
        _paramDto.setToTime(beforeDatetime);
    }

    /**
     *
     * 日別処理パラメータ設定.<br>
     *<br>
     * 概要:<br>
     *  日別処理パラメータ設定処理
     *<br>
     * @param _paramDto 実行用引数情報
     */
    private void setMonthlyParam(final ProcedureBaseParamDto _paramDto) {

        Calendar cal = Calendar.getInstance();
        // 現在日時設定
        cal.setTime(new Date());
        Timestamp nowDatetime = new Timestamp(cal.getTimeInMillis());
        // 終了日時設定
        _paramDto.setToTime(nowDatetime);

        // 前月
        cal.add(Calendar.MONTH, -1);
        Timestamp beforeManthDate = new Timestamp(cal.getTimeInMillis());
        // 開始日時設定
        _paramDto.setFromTime(beforeManthDate);

    }
}
