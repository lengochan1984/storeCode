/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/28| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 *  2017/09/19| <C1.02>　複数MES-DB接続対応                                 | C1.02  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import java.sql.Timestamp;
import java.util.List;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.entity.customer.SysEnvEntity;
import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.batch.util.CM_BatchLoggerUtil;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantMierukaEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrTransferDatetimeEntity;

import org.seasar.framework.beans.util.BeanMap;

/**
 * スレッドローカルデータ.<br>
 *<br>
 * 概要:<br>
 * Mesデータ登録共通サービスのスレッドローカルデータクラス
 *<br>
 */
class TLDataTransferDataBase {
    /**
     * MES-DB接続情報.
     */
    private String mesDbConnectInfo;

    /**
     * MES-DBユーザID.
     */
    private String mesDbUserId;

    /**
     * MES-DB接続情報取得.
     * @return MES-DB接続情報
     */
    public String getMesDbConnectInfo() {
        return this.mesDbConnectInfo;
    }

    /**
     * MES-DB接続情報設定.
     * @param _mesDbConnectInfo MES-DB接続情報
     */
    public void setMesDbConnectInfo(final String _mesDbConnectInfo) {
        this.mesDbConnectInfo = _mesDbConnectInfo;
    }

    /**
     * MES-DBユーザID取得.
     * @return MES-DBユーザID
     */
    public String getMesDbUserId() {
        return this.mesDbUserId;
    }

    /**
     * MES-DBユーザID設定.
     * @param _mesDbUserId MES-DBユーザID
     */
    public void setMesDbUserId(final String _mesDbUserId) {
        this.mesDbUserId = _mesDbUserId;
    }
}


/**
 * Mesデータ登録共通サービス.<br>
 *<br>
 * 概要:<br>
 * Mesデータ登録共通サービスクラス
 *<br>
 */
public abstract class TransferDataBaseService extends BatchBaseService {

    /**
     * 更新日時キー.
     */
    protected static final String KEY_UPD_DATE = "modifiedOn";

    /**
     * 登録・更新日時キー
     */
    protected static final String KEY_ADD_DATETIME = "addDatetime";

    /**
     * スレッドローカルデータ.
     */
    private static ThreadLocal<TLDataTransferDataBase> tl = new ThreadLocal<TLDataTransferDataBase>() {
        @Override
        protected TLDataTransferDataBase initialValue() {
            return new TLDataTransferDataBase();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return スレッドローカルデータ
     */
    private static TLDataTransferDataBase getTLDataTransferDataBase() {
        return tl.get();
    }

    /**
     * MES-DB接続情報取得.
     * @return MES-DB接続情報
     */
    public static String getMesDbConnectInfo() {
        return getTLDataTransferDataBase().getMesDbConnectInfo();
    }

    /**
     * MES-DB接続情報設定.
     * @param _mesDbConnectInfo MES-DB接続情報
     */
    public static void setMesDbConnectInfo(final String _mesDbConnectInfo) {
        getTLDataTransferDataBase().setMesDbConnectInfo(_mesDbConnectInfo);
    }

    /**
     * MES-DBユーザID取得.
     * @return MES-DBユーザID
     */
    public static String getMesDbUserId() {
        return getTLDataTransferDataBase().getMesDbUserId();
    }

    /**
     * MES-DBユーザID設定.
     * @param _mesDbUserId MES-DBユーザID
     */
    public static void setMesDbUserId(final String _mesDbUserId) {
        getTLDataTransferDataBase().setMesDbUserId(_mesDbUserId);
    }

    /**
     *
     * 業務処理前処理.<br>
     *<br>
     * 概要:<br>
     *   業務処理前の処理を行う
     *<br>
     */
    @Override
    public void beforeExecute() {
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "CustomerDb接続処理開始");
        // 顧客DB接続
        this.connectCustomerDb();
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "CustomerDb接続処理終了");

//        // mes接続情報取得
//        List<SysEnvEntity> sysDbList = this.getBatchDao().selectSysEnvList(CM_A04_Const.SYS_ENV_MST_ENV_CD.MES_DB_CONNECT);

        // mesDB接続
        String connectString = FW00_19_Const.EMPTY_STR;
        String userId = FW00_19_Const.EMPTY_STR;
        String password = FW00_19_Const.EMPTY_STR;

//        for (SysEnvEntity sysEnv : sysDbList) {
//            switch (sysEnv.itemCd) {
//                case CM_A04_Const.SYS_ENV_MST_ITEM_CD.CONNECTION_STRING:
//                    connectString = sysEnv.name;
//                    break;
//                case CM_A04_Const.SYS_ENV_MST_ITEM_CD.USER_ID:
//                    userId = sysEnv.name;
//                    break;
//                case CM_A04_Const.SYS_ENV_MST_ITEM_CD.PASSWORD:
//                    password = sysEnv.name;
//                    break;
//                default:
//                    break;
//            }
//        }

        // MesDB接続情報取得
        BeanMap param = new BeanMap();
        param.put(MaPlantMierukaEntityNames.plantCd().toString(), BatchBaseService.getPlantCode());
        List<BeanMap> mesInfoList = this.getBatchDao().selectMaPlantMierukaList(param);
        if (CM_CommonUtil.isNotNullOrEmpty(mesInfoList)) {
            BeanMap mesInfo = mesInfoList.get(0);
            connectString = mesInfo.get(MaPlantMierukaEntityNames.mesDbConnectInfo().toString()).toString();
            userId = mesInfo.get(MaPlantMierukaEntityNames.mesDbUserId().toString()).toString();
            password = mesInfo.get(MaPlantMierukaEntityNames.mesDbPassword().toString()).toString();
        }

        // MesDB接続
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MesDb接続開始");
        this.getMesSchemaDao().setMesDbInfo(connectString, userId, password);
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MesDb接続終了");

        // MesDB接続情報セット
        TransferDataBaseService.setMesDbConnectInfo(connectString);
        TransferDataBaseService.setMesDbUserId(userId);
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#execute()
     */
    @Override
    public void execute() {

        String addTableName = this.getAddTableName();
        String connectStr = TransferDataBaseService.getMesDbConnectInfo();
        String userId = TransferDataBaseService.getMesDbUserId();
        // 更新日時取得
        TrTransferDatetimeEntity datetimeEntity = this.getBatchDao().selectAddDatetime(addTableName, connectStr, userId);

        Timestamp addDatetime = null;
        if (CM_CommonUtil.isNotNullOrBlank(datetimeEntity)) {
            addDatetime = datetimeEntity.updDatetime;
        }
        // MESデータ取得SQLパラメータ設定
        BeanMap sqlParam = new BeanMap();
        sqlParam.put(KEY_ADD_DATETIME, addDatetime);
        this.setSelectMesDataParam(sqlParam);

        String sqlFileName = this.getSelectMesDataSqlFileName();

        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MESデータ取得開始");
        List<BeanMap> mesDataList = this.getMesSchemaDao().selectMesData(sqlFileName, sqlParam);
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MESデータ取得終了");
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MESデータ取得条件[" + addDatetime + "]");
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MESデータ取得件数[" + mesDataList.size() + "件]");

        String insertFilePath = this.getInsertFileName();
        String insertWorkTablePath = this.getInsertWorkTableFileName();
        long maxDatetime = 0;
        long totalNum = mesDataList.size();
        long currentNum = 0;

        if (mesDataList.size() > 0) {
            try {
                // トランザクション開始
                this.getBatchDao().biginTransaction();
    	        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "トランザクション開始");

		        // 前処理
    	        this.preparationInsert();

    	        for (BeanMap mesData : mesDataList) {

                    currentNum++;

                    // 登録前処理
                    this.beforeInsertData(mesData);

                    if (!this.checkInsertData(mesData)) {
		                // チェックがNGの場合、次の処理に進む
                        continue;
                    }

		            // Mesデータ登録
                    CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録処理開始[" + currentNum + "/" + totalNum + "]");
                    this.getBatchDao().executeInsertMesData(insertFilePath, mesData);
                    CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録処理終了[" + currentNum + "/" + totalNum + "]");

                    if (this.isInsertWorkTable()) {
	                    // ワークテーブル登録
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "ワークテーブル登録処理開始");
                        this.getBatchDao().executeInsertMesData(insertWorkTablePath, mesData);
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "ワークテーブル登録処理終了");
                    }

	                // 後処理
                    this.afterInsertData(mesData);

                    this.beforeUpdateAddDatetime(mesData);
                    Timestamp updateDate = (Timestamp) mesData.get(KEY_UPD_DATE);
                    if ((updateDate != null) && (updateDate.getTime() > maxDatetime)) {
	                    // 登録日時登録
                        datetimeEntity = new TrTransferDatetimeEntity();
                        datetimeEntity.tableName = addTableName;
                        datetimeEntity.updDatetime = updateDate;
                        datetimeEntity.connectionString = connectStr;
                        datetimeEntity.userId = userId;
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MES-DB接続情報[" + connectStr + "]");
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MES-DBユーザID[" + userId + "]");
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "更新日時[" + updateDate + "]");
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録日時登録処理開始");
                        this.getBatchDao().updateAddDatetime(datetimeEntity);
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録日時登録処理終了");
                        maxDatetime = updateDate.getTime();
                    }
                }

                // コミット
                this.getBatchDao().commitTransaction();
                CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "コミット");

            } catch (Exception e) {
                this.getBatchDao().rollbackTransaction();
                // エラーログ出力
                CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "ロールバック");
                CM_BatchLoggerUtil.outputErrorLog(this.companyId, this.processName, e);
            }
        }
    }

    /**
     *
     * MesDB接続Dao.<br>
     *<br>
     * 概要:<br>
     *  MesDB接続Daoクラス
     *<br>
     * @return mesスキーマDao
     */
    public abstract CM_BaseMesSchemaDao getMesSchemaDao();

    /**
     *
     * Mesデータ登録対象テーブル名取得.<br>
     *<br>
     * 概要:<br>
     * Mesデータを登録するテーブル名取得
     *<br>
     * @return Mesデータを登録するテーブル名
     */
    protected abstract String getAddTableName();

    /**
     *
     * Mesデータ取得SQLファイル名取得.<br>
     *<br>
     * 概要:<br>
     * Mesデータ取得SQLファイル名取得
     *<br>
     * @return Mesデータ取得SQLファイル名
     */
    protected abstract String getSelectMesDataSqlFileName();

    /**
     *
     * Mesデータ登録SQLファイル名取得.<br>
     *<br>
     * 概要:<br>
     * Mesデータを登録するSQLファイル名取得
     *<br>
     * @return Mesデータ登録SQLファイル名
     */
    protected abstract String getInsertFileName();

    /**
     *
     * ワークテーブル登録チェック.<br>
     *<br>
     * 概要:<br>
     * ワークテーブルに登録するかどうかを取得
     *<br>
     * @return ワークテーブルに保存するかどうか(true：保存する false：保存しない)
     */
    protected boolean isInsertWorkTable() {
        return false;
    }

    /**
     *
     * ワークテーブル登録SQLファイル名取得.<br>
     *<br>
     * 概要:<br>
     *  ワークテーブル登録SQLファイル名取得処理
     *<br>
     * @return ワークテーブル保存SQLファイル名
     */
    protected String getInsertWorkTableFileName() {
        return null;
    }

    /**
     *
     * MESデータ取得SQLパラメータ取得.<br>
     *<br>
     * 概要:<br>
     * MESデータ取得SQLパラメータ取得処理
     *<br>
     * @param _param MESデータ取得SQLパラメータ
     */
    protected void setSelectMesDataParam(final BeanMap _param) {
        return;
    }

    /**
     *
     * 登録準備処理.<br>
     *<br>
     * 概要:<br>
     * 登録準備処理
     *<br>
     */
    protected void preparationInsert() {
        return;
    }

    /**
     *
     * 登録前処理.<br>
     *<br>
     * 概要:<br>
     * 登録前にデータを変更する処理
     *<br>
     * @param _mesData 登録前データ
     */
    protected void beforeInsertData(final BeanMap _mesData) {
        return;
    }

    /**
     *
     * 登録チェック処理.<br>
     *<br>
     * 概要:<br>
     * 登録値のチェック処理
     *<br>
     * @param _mesData 登録データ
     * @return チェック結果
     */
    protected boolean checkInsertData(final BeanMap _mesData) {
        return true;
    }

    /**
     *
     * 登録後処理.<br>
     *<br>
     * 概要:<br>
     * 登録前にデータを変更する処理
     *<br>
     * @param _mesData 登録前データ
     */
    protected void afterInsertData(final BeanMap _mesData) {
        return;
    }

    /**
     *
     * 登録日時登録前処理.<br>
     *<br>
     * 概要:<br>
     * 登録日時登録前にデータを変更する処理
     *<br>
     * @param _mesData 登録日時データ
     */
    protected void beforeUpdateAddDatetime(final BeanMap _mesData) {
        return;
    }

}
