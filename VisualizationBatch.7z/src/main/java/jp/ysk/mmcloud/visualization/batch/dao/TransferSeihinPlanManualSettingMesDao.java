/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/09/27| <C1.01>　新規作成                                                    | C1.01  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.dao;

import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

import org.seasar.framework.beans.util.BeanMap;

/**
 *
 * 製品計画台数（手動設定）テーブル登録MESスキーマDao.<br>
 *<br>
 * 概要:<br>
 * 製品計画台数（手動設定）テーブル登録MESスキーマDaoクラス
 *<br>
 */
public class TransferSeihinPlanManualSettingMesDao extends CM_BaseMesSchemaDao {
    /**
    *
    * MESデータ登録処理.<br>
    *<br>
    * 概要:<br>
    * MESデータ登録処理
    *<br>
    * @param _sqlFileName SQLファイル名
    * @param _mesData MESデータ
    * @return 登録件数
    */
    public long executeInsertMierukaData(final String _sqlFileName, final BeanMap _mesData) {

        long ret = this.jdbcManager.updateBySqlFile(BatchBaseDao.SQL_PATH_BATCH_COMM + _sqlFileName, _mesData).execute();

        return ret;
    }

}
