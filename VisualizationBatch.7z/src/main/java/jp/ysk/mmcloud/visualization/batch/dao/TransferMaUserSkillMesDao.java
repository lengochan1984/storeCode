/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/02/27| <C1.01>　新規作成                                                    | C1.01  | T.Koyama
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.dao;

import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * 作業者レベルマスタ登録MESスキーマDao.<br>
 *<br>
 * 概要:<br>
 * 作業者レベルマスタ登録MESスキーマDaoクラス
 *<br>
 */
public class TransferMaUserSkillMesDao extends CM_BaseMesSchemaDao {

}
