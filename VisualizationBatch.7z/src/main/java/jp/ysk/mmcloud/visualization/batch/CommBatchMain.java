/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/23| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch;

import java.io.File;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.visualization.batch.logic.BatchLogic;
import jp.ysk.mmcloud.visualization.batch.logic.MesDbInfoLogic;
import jp.ysk.mmcloud.visualization.common.batch.CM_BatchConst;
import jp.ysk.mmcloud.visualization.common.batch.util.CM_BatchLoggerUtil;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantMierukaEntityNames;

import org.apache.log4j.PropertyConfigurator;
import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.S2ContainerFactory;

/**
 *
 * バッチ処理メインクラス.<br>
 *<br>
 * 概要:<br>
 *  バッチ処理のメインクラス
 *<br>
 */
public class CommBatchMain {

    /**
     * コンテナ.
     */
    private static S2Container container = null;

    /**
     * データ連携スレッド起動数管理クラス.
     */
    private ThreadPoolExecutor threadPoolExecutor;

    /**
     * 自身のプライベートインスタンス.
     */
    private static CommBatchMain inst;

    /**
     * 実行数上限到達時ウェイト時間.
     */
    protected int waitTime;

    /**
     * 通信プロセスホームディレクトリパス.
     */
    protected String pathHome;

    /**
     * 全停止ファイル名.
     */
    protected String fileAllStop;

    /**
     * 停止ファイル名.
     */
    protected String fileStop;

    /**
     * 実行待機時間(単位：ミリ秒).
     */
    protected int executionWaitTime;

    /**
     * データ連携スレッド起動上限値.
     */
    private int intMaxActiveThreadCnt;

    /**
     * 顧客ID.
     */
    protected static String companyId;

    /**
     * 処理名.
     */
    protected static String processName;

    /**
     * 実行周期(単位：秒).
     */
    protected static int executionCycle;

    /**
     * 実行時刻(HH24:MMのHH24部分).
     */
    protected static int executionTimeHour;

    /**
     * 実行時刻(HH24:MMのMM部分).
     */
    protected static int executionTimeMinute;

    /**
     * リトライ数.
     */
    private static final int RETRY_NUM = 5;

    /**
     * 引数の数.
     */
    private static final int ARGS_NUM = 5;

    /**
     * 引数インデックス：顧客ID.
     */
    private static final int ARG_INDEX_COMPANY_ID = 0;

    /**
     * 引数インデックス：処理プロセス名.
     */
    private static final int ARG_INDEX_PROCESS_NAME = 1;

    /**
     * 引数インデックス：起動周期.
     */
    private static final int ARG_INDEX_EXECUTION_CYCLE = 2;

    /**
     * 引数インデックス：対象フォルダ名.
     */
    private static final int ARG_INDEX_TARGET_DIR = 3;

    /**
     * 引数インデックス：スリープ時間.
     */
    private static final int ARG_INDEX_SLEEP_TIME = 4;

    /**
     *
     * メイン関数.<br>
     *<br>
     * 概要:<br>
     *   メインスレッドの処理
     *<br>
     * @param _args 顧客CD, 処理プロセス名, 起動周期, 対象フォルダ名(顧客CD_1など), スリープ時間[s]
     */
    public static void main(final String[] _args) {
        boolean errorFlg = false;
        boolean cycleFlg = true;
        Calendar nextStartCal = Calendar.getInstance();
        int executionCycleWk = 0;
        int executionTimeHourWk = 0;
        int executionTimeMinuteWk = 0;

        try {
            // ログ設定読込
            PropertyConfigurator.configure(CommBatchMain.class.getResource("/log4j.batch.properties"));
            CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "--------------------------------");
            CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "+++ main thread start ++++++++++");
            CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "--------------------------------");
            for (int i = 0; i < _args.length; i++) {
                CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "_args[" + i + "] = " + _args[i]);
            }
            CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "--------------------------------");
            if (_args.length != ARGS_NUM) {
                // 引数の数誤り
                errorFlg = true;
            } else {
                // 実行周期/実行時刻を引数から取り出す
                try {
                    executionCycleWk = Integer.parseInt(_args[ARG_INDEX_EXECUTION_CYCLE]);
                } catch (NumberFormatException e1) {
                    // 実行周期が数値変換できない場合は、時刻指定されたとして処理する
                    cycleFlg = false;
                    try {
                        String[] time = _args[ARG_INDEX_EXECUTION_CYCLE].split(":");
                        executionTimeHourWk = Integer.parseInt(time[0]);
                        executionTimeMinuteWk = Integer.parseInt(time[1]);
                    } catch (NumberFormatException e2) {
                        // 時刻指定でもない場合はエラー
                        errorFlg = true;
                    }
                }
            }

            if (errorFlg) {
                CM_BatchLoggerUtil.outputErrorLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME],
                        "set this parameter [ dirName threadNum sleepTime(ms) ]");
                CM_BatchLoggerUtil.outputErrorLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "  example [ ysk 10 10 ]");

                CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "--------------------------------");
                CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "+++ main thread end   ++++++++++");
                CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "--------------------------------");

                System.exit(1);
            }

            companyId = _args[ARG_INDEX_COMPANY_ID];
            processName = _args[ARG_INDEX_PROCESS_NAME];
            if (cycleFlg) {
                // 周期実行時
                executionCycle = executionCycleWk;
            } else {
                // 時刻指定実行時
                executionTimeHour = executionTimeHourWk;
                executionTimeMinute = executionTimeMinuteWk;
            }
            String targertDir = _args[ARG_INDEX_TARGET_DIR];

            // すでに実行済みの場合は実行しない
            File lockFile = new File(CommBatchMain.getFullPathLock(targertDir, processName));
            if (lockFile.exists()) {
                CM_BatchLoggerUtil.outputLog(companyId, processName, "--------------------------------");
                CM_BatchLoggerUtil.outputLog(companyId, processName, " already execute(lock file exist)");
                CM_BatchLoggerUtil.outputLog(companyId, processName, "--------------------------------");
                CM_BatchLoggerUtil.outputLog(companyId, processName, "+++ main thread end   ++++++++++");
                CM_BatchLoggerUtil.outputLog(companyId, processName, "--------------------------------");

                System.exit(1);

            } else {
                // すでに実行しているものがない場合はロックファイルを作成
                File dirPath = new File(CM_BatchConst.PATH_LOCK);
                if (!dirPath.exists()) {
                    // ディレクトリが無い場合は生成する。
                    dirPath.mkdirs();
                }

                lockFile.createNewFile();
            }

            // コンテナー初期化
            container = S2ContainerFactory.create("app_batch.dicon");
            container.init();

            // ソケット通信の共通制御クラスをDIコンテナより取得する。
            inst = (CommBatchMain) container.getComponent("main");

            // 起点日時取得
            long startDate = System.currentTimeMillis();
            if (cycleFlg) {
                // 周期実行時
                if (executionCycle > 0) {
                    startDate = startDate - executionCycle * FW00_19_Const.MILLI;
                }
            } else {
                // 時刻指定実行時
                nextStartCal.setTime(new Date(startDate));
                nextStartCal.set(Calendar.HOUR_OF_DAY, executionTimeHour);
                nextStartCal.set(Calendar.MINUTE, executionTimeMinute);
                nextStartCal.set(Calendar.SECOND, 0);
                nextStartCal.set(Calendar.MILLISECOND, 0);

                if (nextStartCal.getTimeInMillis() < startDate) {
                    // 本日の該当時刻が既に経過している場合は、翌日とする
                    nextStartCal.add(Calendar.DAY_OF_MONTH, 1);
                }
            }
            Date beforeStartDate = new Date(startDate);

            // スレッド起動数管理クラスを初期化する。
            int sleepTime = Integer.parseInt(_args[ARG_INDEX_SLEEP_TIME]);
            inst.threadPoolExecutor = new ThreadPoolExecutor(
                    //プール内に保持するスレッドの数
                    inst.intMaxActiveThreadCnt,
                    //プールで許可されるスレッドの最大数
                    inst.intMaxActiveThreadCnt,
                    0L, TimeUnit.MILLISECONDS,
                    new LinkedBlockingQueue<Runnable>());

            // 停止ファイルが存在するまでループする
            while (true) {
                // 停止ファイルの存在チェック
                if (inst.judgeEnd(targertDir, processName)) {
                    CM_BatchLoggerUtil.outputLog(companyId, processName, "stop file exist. thread end. target directory:" + targertDir);
                    break;
                }

                if (cycleFlg) {
                    // 周期実行時
                    if (executionCycle > 0) {
                        // 起点日時経過したかどうか
                        if (inst.judgeTimeToPass(beforeStartDate)) {
                            // 処理開始時間
                            long startTime = System.currentTimeMillis();
                            // 受信スレッド起動処理を実行する。
                            inst.start(sleepTime, _args[ARG_INDEX_TARGET_DIR], cycleFlg, beforeStartDate, nextStartCal);

                            // 処理終了時間
                            long endTime = System.currentTimeMillis();

                            // 起点日時再設定
                            beforeStartDate = inst.addExecutionCycle(beforeStartDate, startTime, endTime);

                        } else {
                            // スレッド待機
                            Thread.sleep(inst.getExecutionWaitTime());
                        }
                    } else {
                        // 受信スレッド起動処理を実行する。
                        inst.start(sleepTime, _args[ARG_INDEX_TARGET_DIR], cycleFlg, beforeStartDate, nextStartCal);
                        // 実行周期がマイナスの場合は1回で終了
                        break;
                    }
                } else {
                    // 時刻指定実行時
                    // 指定時刻を経過したかどうか
                    if (nextStartCal.getTimeInMillis() <= System.currentTimeMillis()) {
                        // 受信スレッド起動処理を実行する。
                        inst.start(sleepTime, _args[ARG_INDEX_TARGET_DIR], cycleFlg, beforeStartDate, nextStartCal);

                        // 次の実行日を翌日に設定
                        nextStartCal.add(Calendar.DAY_OF_MONTH, 1);

                    } else {
                        // スレッド待機
                        Thread.sleep(inst.getExecutionWaitTime());
                    }
                }
            }

            // 個別停止ファイル削除
            File endfile = new File(inst.getFullPathStopFile(targertDir, processName));
            if (endfile.exists()) {
                endfile.delete();
            }

            // ロックファイルを削除する
            if (lockFile.exists()) {
                lockFile.delete();
            }
            CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "--------------------------------");
            CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "+++ main thread end   ++++++++++");
            CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "--------------------------------");

            System.exit(0);
        } catch (OutOfMemoryError ofm) {
            CM_BatchLoggerUtil.outputErrorLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], ofm.getMessage());
            try {
                // ロックファイルを削除する
                File lockFile = new File(CommBatchMain.getFullPathLock(_args[ARG_INDEX_TARGET_DIR], _args[ARG_INDEX_PROCESS_NAME]));
                if (lockFile.exists()) {
                    lockFile.delete();
                }
            } catch (Exception ex) {
                CM_BatchLoggerUtil.outputErrorLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "lock file delete error!", ex);
            }

            CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "--------------------------------");
            CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "+++ main thread end   ++++++++++");
            CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "--------------------------------");

            System.exit(1);
        } catch (Exception e) {
            CM_BatchLoggerUtil.outputErrorLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "System error!", e);

            try {
                // ロックファイルを削除する
                File lockFile = new File(CommBatchMain.getFullPathLock(_args[ARG_INDEX_TARGET_DIR], _args[ARG_INDEX_PROCESS_NAME]));
                if (lockFile.exists()) {
                    lockFile.delete();
                }
            } catch (Exception ex) {
                CM_BatchLoggerUtil.outputErrorLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "lock file delete error!", ex);
            }

            CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "--------------------------------");
            CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "+++ main thread end   ++++++++++");
            CM_BatchLoggerUtil.outputLog(_args[ARG_INDEX_COMPANY_ID], _args[ARG_INDEX_PROCESS_NAME], "--------------------------------");

            System.exit(1);
        }

    }


    /**
     *
     * 受信スレッド起動処理.<br>
     *<br>
     * 概要:<br>
     *   受信スレッドを起動する
     *<br>
     * @param _sleepTime スレッド起動間隔
     * @param _targetDir 処理対象ディレクトリ
     * @param _cycleFlg 周期実行フラグ
     * @param _beforeStartDate 起点日時
     * @param _nextStartCal 時刻指定実行時起点日時
     * @throws Exception 例外
     */
    private void start(final int _sleepTime, final String _targetDir, final boolean _cycleFlg, final Date _beforeStartDate, final Calendar _nextStartCal) throws Exception {

        // 処理スタートログ
        CM_BatchLoggerUtil.outputLog(companyId, processName, "---------- targetDir:" + _targetDir + " start. [ CommBatchMain.start ] ---------");

        // プロセスIDを設定(＋"-"+フォルダ名)
        String processId = processName + FW00_19_Const.HYPHEN_STR + _targetDir;

        // データ連携処理の場合
        if (isTransferProc(processName)) {
            List<BeanMap> mesDbList = getMesDbInfo(companyId, processName);

            for (BeanMap mesDb: mesDbList) {
                String plantCode = mesDb.get(MaPlantMierukaEntityNames.plantCd()).toString();

                // コンテナーから取得
                BatchLogic execThread = (BatchLogic) container.getComponent("batchLogic");
                execThread.init(companyId, processName);
                execThread.setPlantCode(plantCode);
                execThread.setArgParam(_cycleFlg, executionCycle, _targetDir,  _beforeStartDate, _nextStartCal);
                execThread.setPathHome(this.getPathHome());
                execThread.setFileAllStop(this.getFileAllStop());
                execThread.setFileStop(this.getFileStop());
                execThread.setExecutionWaitTime(this.getExecutionWaitTime());
                CM_BatchLoggerUtil.outputLog(companyId, processName, "child thread start.(" + processId + ") [ CommBatchMain.start ]");
                runChild(execThread, 1);
                // 少し間をおいて次のファイルを処理
                Thread.sleep(_sleepTime);
            }

        } else {
            // コンテナーから取得
            BatchLogic execThread = (BatchLogic) container.getComponent("batchLogic");
            execThread.init(companyId, processName);
            execThread.setArgParam(_cycleFlg, executionCycle, _targetDir, _beforeStartDate, _nextStartCal);
            execThread.setPathHome(this.getPathHome());
            execThread.setFileAllStop(this.getFileAllStop());
            execThread.setFileStop(this.getFileStop());
            execThread.setExecutionWaitTime(this.getExecutionWaitTime());
            CM_BatchLoggerUtil.outputLog(companyId, processName, "child thread start.(" + processId + ") [ CommBatchMain.start ]");
            runChild(execThread, 1);
            // 少し間をおいて次のファイルを処理
            Thread.sleep(_sleepTime);
        }

        // 受信スレッドと、データ連携スレッドが未起動時以外は待機する。
        final int sleepTimeSec = 100;
        while (this.threadPoolExecutor.getActiveCount() != 0) {
            Thread.sleep(sleepTimeSec);
        }

        // 処理終了ログ
        CM_BatchLoggerUtil.outputLog(companyId, processName, "---------- targertDir:" + _targetDir + " end. [ CommBatchMain.start ] ---------");
    }

    /**
     * MES-DB接続情報取得.
     * @param _companyId 顧客ID
     * @param _processName 処理プロセス名
     * @return 工場マスタ（見える化専用）データリスト
     */
    private List<BeanMap> getMesDbInfo(final String _companyId, final String _processName) {

        MesDbInfoLogic mesDbInfoLogic = (MesDbInfoLogic) container.getComponent("mesDbInfoLogic");
        mesDbInfoLogic.init(_companyId, _processName);

        return mesDbInfoLogic.getMesDbInfo();
    }

    /**
     * データ連携処理かどうかを返す.
     * @param _processName 処理プロセス名
     * @return true:データ連携処理 false:データ連携処理以外
     */
    private boolean isTransferProc(final String _processName) {
        boolean ret = false;

        try {
            if ("transfer".equals(_processName.substring(0, 8))) {
                ret = true;
            }
        } catch (IndexOutOfBoundsException e) {
            ret = false;
        }

        return ret;
    }

    /**
     *
     * データ連携処理スレッド起動(内部メソッド：再帰処理).<br>
     *<br>
     * 概要:<br>
     *   データ連携処理(FW02_01_ChildSocket)をスレッド起動する。<br>
     *   スレッドプールが上限に達している場合は、一定時間待機した後、リトライする。
     *<br>
     * @param _execThread ソケット
     * @param _retryTimes リトライ時間
     * @throws InterruptedException 例外
     */
    private void runChild(final Thread _execThread, final long _retryTimes) throws InterruptedException {
        if (!runThread(_execThread)) {
            if (_retryTimes != 0 && _retryTimes % RETRY_NUM == 0) {
                CM_BatchLoggerUtil.outputLog(companyId, "main",
                        "Trying " + _retryTimes + " times now. Process was failed.[IP:]");
            }
            // 指定ミリ秒待機
            Thread.sleep(this.waitTime);
            // リトライ回数のカウントアップ
            this.runChild(_execThread, _retryTimes + 1);
        }
    }

    /**
     *
     * データ連携スレッド起動共通部品.<br>
     *<br>
     * 概要:<br>
     *   スレッドを起動する
     *<br>
     * @param _execThread ソケット
     * @return 成否
     */
    public static boolean runThread(final Thread _execThread) {
        synchronized (inst.threadPoolExecutor) {
            if (inst.threadPoolExecutor.getActiveCount() >= inst.intMaxActiveThreadCnt) {
                return false;
            } else {
                inst.threadPoolExecutor.execute(_execThread);
                return true;
            }
        }
    }

    /**
     *
     * DIコンテナ起動共通部品.<br>
     *<br>
     * 概要:<br>
     *   DIコンテナからオブジェクトを取得する
     *<br>
     * @param _key キー
     * @return オブジェクト
     */
    public static Object callContainer(final String _key) {
        synchronized (container) {
            return container.getComponent(_key);
        }
    }

    /**
     *
     * スレッド終了判定処理.<br>
     *<br>
     * 概要:<br>
     *   スレッドを終了するか判定する
     *<br>
     * @param _targetDir 処理対象ディレクトリ
     * @param _processName プロセス名
     * @return 成否
     */
    private boolean judgeEnd(final String _targetDir, final String _processName) {

        // 全スレッド終了ファイルがあった場合は即終了(例:/home/batch/stopAll.txt)
        File endFile = new File(getFullPathStopAllFile());
        if (endFile.exists()) {
            return true;
        }

        // 対象ディレクトリ指定終了ファイルがあった場合は終了(例:/home/batch/customerDir/stop.txt)
        endFile = new File(getFullPathStopFile(_targetDir));
        if (endFile.exists()) {
            return true;
        }

        // プロセス個別停止ファイルがあった場合は終了(例:)
        endFile = new File(getFullPathStopFile(_targetDir, _processName));
        if (endFile.exists()) {
            return true;
        }

        return false;
    }

    /**
     *
     * 現在時間が起点日時から実行周期時間過ぎたかどうか.<br>
     *<br>
     * 概要:<br>
     *   現在時間が起点日から実行周期時間過ぎたかどうか
     *<br>
     * @param _startDate 起点日時
     * @return true:経過済み false:未経過
     */
    private boolean judgeTimeToPass(final Date _startDate) {
        // 現在時間取得
        long now = System.currentTimeMillis();
        long longStartDate = _startDate.getTime();
        // 起点日時 + 実行周期（秒）
        long nextStartDate = longStartDate +  executionCycle * FW00_19_Const.MILLI;

        if (now - nextStartDate >= 0) {
            return true;
        }

        return false;
    }

    /**
     *
     * 起点日時の算出.<br>
     *<br>
     * 概要:<br>
     *   処理の経過時間から次の起点日時を算出する
     *<br>
     * @param _date 起点日時
     * @param _startDatetime 処理開始時間
     * @param _endDatetime 処理終了時間
     * @return 起点日時
     */
    private Date addExecutionCycle(final Date _date, final long _startDatetime, final long _endDatetime) {
        // 処理経過時間を算出
        long passTime = _endDatetime - _startDatetime;
        // 実行周期をミリ秒単位に変換
        long executionCycleMilli = executionCycle * FW00_19_Const.MILLI;

        // 処理経過時間から起点日時に加算する実行周期の経過時間を算出
        // 実行周期の経過時間 = （処理経過時間内に実行周期が発生した回数＋１）× 実行周期（ミリ秒）
        long passCycle = (passTime / executionCycleMilli + 1) * executionCycleMilli;

        // 起点日に実行周期の経過時間を加算
        long longStartDatetime = _date.getTime() + passCycle;

        return new Date(longStartDatetime);
    }


    /**
     *
     * 全停止ファイルフルパス取得.<br>
     *<br>
     * 概要:<br>
     *   全停止ファイルのフルパスを取得する
     *<br>
     * @return 全停止フルパス
     */
    private String getFullPathStopAllFile() {
        // 例:/home/batch/stopAll.txt
        return getPathHome() + getFileAllStop();
    }

    /**
     *
     * バッチ停止ファイルフルパス取得.<br>
     *<br>
     * 概要:<br>
     *   バッチ停止ファイルのフルパスを取得する
     *<br>
     * @param _targetDir 処理対象ディレクトリ
     * @return バッチ0停止フルパス
     */
    private String getFullPathStopFile(final String _targetDir) {
        // 例:/home/batch/customerDir/stop.txt
        return getPathHome() + _targetDir + FW00_19_Const.SLASH_STR  + getFileStop();
    }

    /**
     *
     * バッチ停止ファイルフルパス取得.<br>
     *<br>
     * 概要:<br>
     *   バッチ停止ファイルのフルパスを取得する
     *<br>
     * @param _targetDir 処理対象ディレクトリ
     * @param _processName プロセス名
     * @return バッチ0停止フルパス
     */
    private String getFullPathStopFile(final String _targetDir, final String _processName) {
        // 例:/home/batch/customerDir/processName-stop.txt
        return getPathHome() + _targetDir + FW00_19_Const.SLASH_STR + _processName + FW00_19_Const.HYPHEN_STR + getFileStop();
    }

    /**
     *
     * 実行ロックファイルフルパス取得.<br>
     *<br>
     * 概要:<br>
     *   実行ロックファイルのフルパスを取得する
     *<br>
     * @param _targetDir 処理対象ディレクトリ
     * @param _processName 実行プロセス名
     * @return 実行ロックファイルフルパス
     */
    private static String getFullPathLock(final String _targetDir, final String _processName) {

        // 例:/var/lock/mmcloud/batch/customerDir-processName-lock.txt
        String fullPath = CM_BatchConst.PATH_LOCK + _targetDir +  FW00_19_Const.HYPHEN_STR + _processName + CM_BatchConst.FILE_LOCK_TAIL;

        return fullPath;
    }

    /**
     * waitTimeを取得.
     *
     * @return waitTime
     */
    public int getWaitTime() {
        return this.waitTime;
    }

    /**
     * waitTimeを設定する.
     *
     * @param _waitTime waitTime
     */
    public void setWaitTime(final int _waitTime) {
        this.waitTime = _waitTime;
    }

    /**
     * pathHomeを取得.
     *
     * @return pathHome
     */
    public String getPathHome() {
        return this.pathHome;
    }

    /**
     * pathHomeを設定する.
     *
     * @param _pathHome pathHome
     */
    public void setPathHome(final String _pathHome) {
        this.pathHome = _pathHome;
    }

    /**
     * fileAllStopを取得.
     *
     * @return fileAllStop
     */
    public String getFileAllStop() {
        return this.fileAllStop;
    }

    /**
     * fileAllStopを設定する.
     *
     * @param _fileAllStop fileAllStop
     */
    public void setFileAllStop(final String _fileAllStop) {
        this.fileAllStop = _fileAllStop;
    }

    /**
     * fileStopを取得.
     *
     * @return fileStop
     */
    public String getFileStop() {
        return this.fileStop;
    }

    /**
     * fileStopを設定する.
     *
     * @param _fileStop fileStop
     */
    public void setFileStop(final String _fileStop) {
        this.fileStop = _fileStop;
    }

    /**
     * executionWaitTimeを取得.
     *
     * @return executionWaitTime
     */
    public int getExecutionWaitTime() {
        return this.executionWaitTime;
    }

    /**
     * executionWaitTimeを設定する.
     *
     * @param _executionWaitTime executionWaitTime
     */
    public void setExecutionWaitTime(final int _executionWaitTime) {
        this.executionWaitTime = _executionWaitTime;
    }

    /**
     * intMaxActiveThreadCntを取得.
     *
     * @return intMaxActiveThreadCnt
     */
    public int getIntMaxActiveThreadCnt() {
        return this.intMaxActiveThreadCnt;
    }

    /**
     * intMaxActiveThreadCntを設定する.
     *
     * @param _intMaxActiveThreadCnt intMaxActiveThreadCnt
     */
    public void setIntMaxActiveThreadCnt(final int _intMaxActiveThreadCnt) {
        this.intMaxActiveThreadCnt = _intMaxActiveThreadCnt;
    }
}
