/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/23| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 *  2017/09/19| <C1.02>　複数MES-DB接続対応                                          | C1.02  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.logic;

import java.io.File;
import java.util.Calendar;
import java.util.Date;

import org.seasar.framework.exception.SQLRuntimeException;

import jp.ysk.fw.FW00_12_AppException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.visualization.batch.CommBatchMain;
import jp.ysk.mmcloud.visualization.batch.service.BatchBaseService;
import jp.ysk.mmcloud.visualization.common.batch.util.CM_BatchLoggerUtil;

/**
 * プロシージャ起動処理.<br>
 *<br>
 * 概要:<br>
 *  プロシージャ起動処理
 *<br>
 */
public class BatchLogic extends Thread {

    /**
     * 顧客ID.
     */
    private String companyId;

    /**
     * 処理プロセス名.
     */
    private String processName;

    /**
     * バッチ処理サービスクラス.
     */
    public BatchBaseService batchService;

    /**
     * 工場コード.
     */
    private String plantCode;

    /**
     * 周期フラグ.
     */
    private boolean cycleFlg;

    /**
     * 実行周期(単位：秒).
     */
    private int executionCycle;

    /**
     * 処理対象ディレクトリ.
     */
    private String targetDir;

    /**
     * 起点日時.
     */
    private Date beforeStartDate;

    /**
     * 時刻指定実行時起点日時.
     */
    private Calendar nextStartCal;

    /**
     * 通信プロセスホームディレクトリパス.
     */
    private String pathHome;

    /**
     * 全停止ファイル名.
     */
    private String fileAllStop;

    /**
     * 停止ファイル名.
     */
    private String fileStop;

    /**
     * 実行待機時間(単位：ミリ秒).
     */
    private int executionWaitTime;

    /**
     * コンストラクタ.
     */
    public BatchLogic() {

    }

    /**
     * クエリタイムアウト(秒).
     * s2jdbc.diconのqueryTimeoutと設定をあわせること
     */
    private static final int QUERY_TIMEOUT = 600;

    /**
     *
     * 初期処理.<br>
     *<br>
     * 概要:<br>
     *   初期処理
     *<br>
     * @param _companyId 顧客ID
     * @param _processName 実行プロセス名
     */
    public void init(final String _companyId, final String _processName) {
        this.companyId = _companyId;
        this.processName = _processName;
    }

    /**
     * スレッド処理.
     */
    public void run() {
        try {
            Calendar nextStartCal = this.nextStartCal;
            Date beforeStartDate = new Date(this.beforeStartDate.getTime());

            // 停止ファイルが存在するまでループする
            while (true) {
                // 停止ファイルの存在チェック
                if (judgeEnd(this.targetDir, this.processName)) {
                    CM_BatchLoggerUtil.outputLog(this.companyId, this.processName, "stop file exist. thread end. target directory:" + this.targetDir);
                    break;
                }

                if (this.cycleFlg) {
                    // 周期実行時
                    if (this.executionCycle > 0) {
                        // 起点日時経過したかどうか
                        if (judgeTimeToPass(beforeStartDate)) {
                            // 処理開始時間
                            long startTime = System.currentTimeMillis();
                            // 受信スレッド起動処理を実行する。
                            runService();

                            // 処理終了時間
                            long endTime = System.currentTimeMillis();

                            // 起点日時再設定
                            beforeStartDate = addExecutionCycle(beforeStartDate, startTime, endTime);

                        } else {
                            // スレッド待機
                            Thread.sleep(getExecutionWaitTime());
                        }
                    } else {
                        // 受信スレッド起動処理を実行する。
                        runService();
                        // 実行周期がマイナスの場合は1回で終了
                        break;
                    }
                } else {
                    // 時刻指定実行時
                    // 指定時刻を経過したかどうか
                    if (nextStartCal.getTimeInMillis() <= System.currentTimeMillis()) {
                        // 受信スレッド起動処理を実行する。
                        runService();

                        // 次の実行日を翌日に設定
                        nextStartCal.add(Calendar.DAY_OF_MONTH, 1);

                    } else {
                        // スレッド待機
                        Thread.sleep(getExecutionWaitTime());
                    }
                }
            }

        } catch (Exception e) {
            CM_BatchLoggerUtil.outputErrorLog(this.companyId, this.processName, "Exception in [ BatchOperation.run ]", e);
        }

        CM_BatchLoggerUtil.outputLog(this.companyId, this.processName, "Thread end!! [ in BatchOperation.run ]");
    }

    /**
     * スレッド処理メイン.
     */
    private void runService() {

        CM_BatchLoggerUtil.outputLog(this.companyId, this.processName, "Thread start!! [ in BatchOperation.run ]");

        try {
            this.batchService = (BatchBaseService) CommBatchMain.callContainer(this.processName);
        } catch (Exception e) {
            this.batchService = null;
        }

        if (this.batchService == null) {
            CM_BatchLoggerUtil.outputLog(this.companyId, this.processName, "### Unknown processName=" + this.processName + " ###");

            throw new FW00_12_AppException("Unknown processName");
        }

        this.batchService.companyId = this.companyId;
        this.batchService.processName = this.processName;
        this.batchService.queryTimeout = QUERY_TIMEOUT;
        BatchBaseService.setPlantCode(this.plantCode);

        try {
            // 前処理
            CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "-----前処理開始---");
            this.batchService.beforeExecute();
            CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "-----前処理終了---");

            // 実行
            CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "-----実行処理開始---");
            this.batchService.execute();
            CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "-----実行処理終了---");

            // 後処理
            this.batchService.endProcess();

        } catch (SQLRuntimeException e) {
            CM_BatchLoggerUtil.outputErrorLog(this.companyId, this.processName, "Exception in [ BatchOperation.run ]", e);
        }
    }

    /**
     * 起動パラメータ設定.
     * @param _cycleFlg 周期フラグ
     * @param _executionCycle 実行周期(単位：秒)
     * @param _targetDir 処理対象ディレクトリ
     * @param _beforeStartDate 起点日時
     * @param _nextStartCal 時刻指定実行時起点日時
     */
    public void setArgParam(final boolean _cycleFlg
            , final int _executionCycle
            , final String _targetDir
            , final Date _beforeStartDate
            , final Calendar _nextStartCal) {
        this.cycleFlg = _cycleFlg;
        this.executionCycle = _executionCycle;
        this.targetDir = _targetDir;
        this.beforeStartDate = new Date(_beforeStartDate.getTime());
        this.nextStartCal = _nextStartCal;
    }

    /**
     * @return plantCode
     */
    public String getPlantCode() {
        return this.plantCode;
    }

    /**
     * @param _plantCode セットする plantCode
     */
    public void setPlantCode(final String _plantCode) {
        this.plantCode = _plantCode;
    }

    /**
     *
     * スレッド終了判定処理.<br>
     *<br>
     * 概要:<br>
     *   スレッドを終了するか判定する
     *<br>
     * @param _targetDir 処理対象ディレクトリ
     * @param _processName プロセス名
     * @return 成否
     */
    private boolean judgeEnd(final String _targetDir, final String _processName) {

        // 全スレッド終了ファイルがあった場合は即終了(例:/home/batch/stopAll.txt)
        File endFile = new File(getFullPathStopAllFile());
        if (endFile.exists()) {
            return true;
        }

        // 対象ディレクトリ指定終了ファイルがあった場合は終了(例:/home/batch/customerDir/stop.txt)
        endFile = new File(getFullPathStopFile(_targetDir));
        if (endFile.exists()) {
            return true;
        }

        // プロセス個別停止ファイルがあった場合は終了(例:)
        endFile = new File(getFullPathStopFile(_targetDir, _processName));
        if (endFile.exists()) {
            return true;
        }

        return false;
    }

    /**
     *
     * 現在時間が起点日時から実行周期時間過ぎたかどうか.<br>
     *<br>
     * 概要:<br>
     *   現在時間が起点日から実行周期時間過ぎたかどうか
     *<br>
     * @param _startDate 起点日時
     * @return true:経過済み false:未経過
     */
    private boolean judgeTimeToPass(final Date _startDate) {
        // 現在時間取得
        long now = System.currentTimeMillis();
        long longStartDate = _startDate.getTime();
        // 起点日時 + 実行周期（秒）
        long nextStartDate = longStartDate +  executionCycle * FW00_19_Const.MILLI;

        if (now - nextStartDate >= 0) {
            return true;
        }

        return false;
    }

    /**
     *
     * 起点日時の算出.<br>
     *<br>
     * 概要:<br>
     *   処理の経過時間から次の起点日時を算出する
     *<br>
     * @param _date 起点日時
     * @param _startDatetime 処理開始時間
     * @param _endDatetime 処理終了時間
     * @return 起点日時
     */
    private Date addExecutionCycle(final Date _date, final long _startDatetime, final long _endDatetime) {
        // 処理経過時間を算出
        long passTime = _endDatetime - _startDatetime;
        // 実行周期をミリ秒単位に変換
        long executionCycleMilli = executionCycle * FW00_19_Const.MILLI;

        // 処理経過時間から起点日時に加算する実行周期の経過時間を算出
        // 実行周期の経過時間 = （処理経過時間内に実行周期が発生した回数＋１）× 実行周期（ミリ秒）
        long passCycle = (passTime / executionCycleMilli + 1) * executionCycleMilli;

        // 起点日に実行周期の経過時間を加算
        long longStartDatetime = _date.getTime() + passCycle;

        return new Date(longStartDatetime);
    }


    /**
     *
     * 全停止ファイルフルパス取得.<br>
     *<br>
     * 概要:<br>
     *   全停止ファイルのフルパスを取得する
     *<br>
     * @return 全停止フルパス
     */
    private String getFullPathStopAllFile() {
        // 例:/home/batch/stopAll.txt
        return getPathHome() + getFileAllStop();
    }

    /**
     *
     * バッチ停止ファイルフルパス取得.<br>
     *<br>
     * 概要:<br>
     *   バッチ停止ファイルのフルパスを取得する
     *<br>
     * @param _targetDir 処理対象ディレクトリ
     * @return バッチ0停止フルパス
     */
    private String getFullPathStopFile(final String _targetDir) {
        // 例:/home/batch/customerDir/stop.txt
        return getPathHome() + _targetDir + FW00_19_Const.SLASH_STR  + getFileStop();
    }

    /**
     *
     * バッチ停止ファイルフルパス取得.<br>
     *<br>
     * 概要:<br>
     *   バッチ停止ファイルのフルパスを取得する
     *<br>
     * @param _targetDir 処理対象ディレクトリ
     * @param _processName プロセス名
     * @return バッチ0停止フルパス
     */
    private String getFullPathStopFile(final String _targetDir, final String _processName) {
        // 例:/home/batch/customerDir/processName-stop.txt
        return getPathHome() + _targetDir + FW00_19_Const.SLASH_STR + _processName + FW00_19_Const.HYPHEN_STR + getFileStop();
    }

    /**
     * pathHomeを取得.
     *
     * @return pathHome
     */
    public String getPathHome() {
        return this.pathHome;
    }

    /**
     * pathHomeを設定する.
     *
     * @param _pathHome pathHome
     */
    public void setPathHome(final String _pathHome) {
        this.pathHome = _pathHome;
    }

    /**
     * fileAllStopを取得.
     *
     * @return fileAllStop
     */
    public String getFileAllStop() {
        return this.fileAllStop;
    }

    /**
     * fileAllStopを設定する.
     *
     * @param _fileAllStop fileAllStop
     */
    public void setFileAllStop(final String _fileAllStop) {
        this.fileAllStop = _fileAllStop;
    }

    /**
     * fileStopを取得.
     *
     * @return fileStop
     */
    public String getFileStop() {
        return this.fileStop;
    }

    /**
     * fileStopを設定する.
     *
     * @param _fileStop fileStop
     */
    public void setFileStop(final String _fileStop) {
        this.fileStop = _fileStop;
    }

    /**
     * executionWaitTimeを取得.
     *
     * @return executionWaitTime
     */
    public int getExecutionWaitTime() {
        return this.executionWaitTime;
    }

    /**
     * executionWaitTimeを設定する.
     *
     * @param _executionWaitTime executionWaitTime
     */
    public void setExecutionWaitTime(final int _executionWaitTime) {
        this.executionWaitTime = _executionWaitTime;
    }

}
