/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/03/07| <C1.01>　新規作成                                                    | C1.01  | H.Nakamura
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dto.ProcedureBaseParamDto;

/**
 *
 * 前詰負荷平準プロシージャ起動処理Service.<br>
 *<br>
 * 概要:<br>
 *  前詰負荷平準プロシージャ起動処理Serviceクラス
 *<br>
 */
public class PreloadLevelService extends ExecuteProcedureBaseService {

    /**
     * Dao.
     */
    public BatchBaseDao batchBaseDao;

    /**
     * クエリタイムアウト(秒).
     */
    private static final int QUERY_TIMEOUT = 1800;

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#setProcedureParam(jp.ysk.mmcloud.visualization.batch.dto.ProcedureBaseParamDto)
     */
    @Override
    protected void setProcedureParam(final ProcedureBaseParamDto _paramDto) {
        Calendar cal = Calendar.getInstance();
        Calendar calWork = Calendar.getInstance();

        // 現在日時設定
        cal.setTime(new Date());

        // 開始日時設定
        calWork.setTime(cal.getTime());
        calWork.add(Calendar.MONTH, -1);
        _paramDto.setFromTime(new Timestamp(calWork.getTimeInMillis()));

        // 終了日時設定
        calWork.setTime(cal.getTime());
        calWork.add(Calendar.MONTH, 4);
        _paramDto.setToTime(new Timestamp(calWork.getTimeInMillis()));
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return this.batchBaseDao;
    }

    /**
    *
    * 業務処理前処理.<br>
    *<br>
    * 概要:<br>
    *   業務処理前の処理を行う
    *<br>
    */
    @Override
    public void beforeExecute() {
        // 処理に時間がかかるので、クエリタイムアウト時間を延ばす
        this.queryTimeout = QUERY_TIMEOUT;
        // DB接続
        this.connectCustomerDb();
    }
}
