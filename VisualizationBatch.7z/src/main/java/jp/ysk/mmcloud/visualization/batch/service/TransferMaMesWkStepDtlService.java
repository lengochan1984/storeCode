/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/08/28| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferMaMesWkStepDtlMesDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * MES作業STEP詳細登録処理.<br>
 *<br>
 * 概要:<br>
 * MES作業STEP詳細をMesデータから登録する処理
 *<br>
 */
public class TransferMaMesWkStepDtlService extends TransferDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferMaMesWkStepDtlMesDao> tlMesDao = new ThreadLocal<TransferMaMesWkStepDtlMesDao>() {
        @Override
        protected TransferMaMesWkStepDtlMesDao initialValue() {
            return new TransferMaMesWkStepDtlMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferMaMesWkStepDtlMesDao getTransferMaMesWkStepDtlMesDao() {
        return tlMesDao.get();
    }

    /**
     * Dao.
     */
    private static ThreadLocal<BatchBaseDao> tlDao = new ThreadLocal<BatchBaseDao>() {
        @Override
        protected BatchBaseDao initialValue() {
            return new BatchBaseDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static BatchBaseDao getBatchBaseDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferMaMesWkStepDtlService.getTransferMaMesWkStepDtlMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferMaMesWkStepDtlService.getBatchBaseDao();
    }

    @Override
    protected String getSelectMesDataSqlFileName() {
        return "selectMaMesWkStepDtl.sql";
    }

    @Override
    protected String getAddTableName() {
        return "ma_mes_wk_step_dtl";
    }

    @Override
    protected String getInsertFileName() {
        return "insertMaMesWkStepDtl.sql";
    }

}
