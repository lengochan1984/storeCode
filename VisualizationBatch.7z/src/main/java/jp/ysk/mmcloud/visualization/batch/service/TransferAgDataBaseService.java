/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/09/06| <C1.01>　新規作成                                                    | C1.01  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import java.sql.Timestamp;
import java.util.List;

import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.visualization.common.batch.util.CM_BatchLoggerUtil;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrTransferDatetimeEntity;
import org.seasar.framework.beans.util.BeanMap;


/**
 * Mesデータ登録共通サービス（集計テーブル用）.<br>
 *<br>
 * 概要:<br>
 * Mesデータ登録共通サービスクラス（集計テーブル用）
 *<br>
 */
public abstract class TransferAgDataBaseService extends TransferDataBaseService {

    /**
     * 更新日時キー.
     */
    protected static final String KEY_UPD_DATE = "updTim";


    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#execute()
     */
    @Override
    public void execute() {

        String addTableName = this.getAddTableName();
        String connectStr = TransferAgDataBaseService.getMesDbConnectInfo();
        String userId = TransferAgDataBaseService.getMesDbUserId();
        // 更新日時取得
        TrTransferDatetimeEntity datetimeEntity = this.getBatchDao().selectAddDatetime(addTableName, connectStr, userId);

        Timestamp addDatetime = null;
        if (CM_CommonUtil.isNotNullOrBlank(datetimeEntity)) {
            addDatetime = datetimeEntity.updDatetime;
        }
        // MESデータ取得SQLパラメータ設定
        BeanMap sqlParam = new BeanMap();
        sqlParam.put(KEY_ADD_DATETIME, addDatetime);
        this.setSelectMesDataParam(sqlParam);

        String sqlFileName = this.getSelectMesDataSqlFileName();

        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MESデータ取得開始");
        List<BeanMap> mesDataList = this.getMesSchemaDao().selectMesData(sqlFileName, sqlParam);
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MESデータ取得終了");
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MESデータ取得条件[" + addDatetime + "]");
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MESデータ取得件数[" + mesDataList.size() + "件]");

        String insertFilePath = this.getInsertFileName();
        String insertWorkTablePath = this.getInsertWorkTableFileName();
        long maxDatetime = 0;
        long totalNum = mesDataList.size();
        long currentNum = 0;

        if (mesDataList.size() > 0) {
            try {
                // トランザクション開始
                this.getBatchDao().biginTransaction();
    	        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "トランザクション開始");

		        // 前処理
    	        this.preparationInsert();

    	        for (BeanMap mesData : mesDataList) {

                    currentNum++;

                    // 登録前処理
                    this.beforeInsertData(mesData);

                    if (!this.checkInsertData(mesData)) {
		                // チェックがNGの場合、次の処理に進む
                        continue;
                    }

		            // Mesデータ登録
                    CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録処理開始[" + currentNum + "/" + totalNum + "]");
                    this.getBatchDao().executeInsertMesData(insertFilePath, mesData);
                    CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録処理終了[" + currentNum + "/" + totalNum + "]");

                    if (this.isInsertWorkTable()) {
	                    // ワークテーブル登録
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "ワークテーブル登録処理開始");
                        this.getBatchDao().executeInsertMesData(insertWorkTablePath, mesData);
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "ワークテーブル登録処理終了");
                    }

	                // 後処理
                    this.afterInsertData(mesData);

                    this.beforeUpdateAddDatetime(mesData);
                    Timestamp updateDate = (Timestamp) mesData.get(KEY_UPD_DATE);
                    if ((updateDate != null) && (updateDate.getTime() > maxDatetime)) {
	                    // 登録日時登録
                        datetimeEntity = new TrTransferDatetimeEntity();
                        datetimeEntity.tableName = addTableName;
                        datetimeEntity.updDatetime = updateDate;
                        datetimeEntity.connectionString = connectStr;
                        datetimeEntity.userId = userId;
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MES-DB接続情報[" + connectStr + "]");
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MES-DBユーザID[" + userId + "]");
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "更新日時[" + updateDate + "]");
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録日時登録処理開始");
                        this.getBatchDao().updateAddDatetime(datetimeEntity);
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録日時登録処理終了");
                        maxDatetime = updateDate.getTime();
                    }
                }

                // コミット
                this.getBatchDao().commitTransaction();
                CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "コミット");

            } catch (Exception e) {
                this.getBatchDao().rollbackTransaction();
                // エラーログ出力
                CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "ロールバック");
                CM_BatchLoggerUtil.outputErrorLog(this.companyId, this.processName, e);
            }
        }
    }


}
