/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/09/06| <C1.01>　新規作成                                                    | C1.01  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferAgProductMngHourlyMesDao;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * 製品生産計画実績(時間別)集計テーブル登録処理.<br>
 *<br>
 * 概要:<br>
 * 製品生産計画実績(時間別)集計テーブルをMesデータから登録する処理
 *<br>
 */
public class TransferAgProductMngHourlyService extends TransferAgDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferAgProductMngHourlyMesDao> tlMesDao = new ThreadLocal<TransferAgProductMngHourlyMesDao>() {
        @Override
        protected TransferAgProductMngHourlyMesDao initialValue() {
            return new TransferAgProductMngHourlyMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferAgProductMngHourlyMesDao getTransferAgProductMngHourlyMesDao() {
        return tlMesDao.get();
    }

    /**
     * Dao.
     */
    private static ThreadLocal<BatchBaseDao> tlDao = new ThreadLocal<BatchBaseDao>() {
        @Override
        protected BatchBaseDao initialValue() {
            return new BatchBaseDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static BatchBaseDao getBatchBaseDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferAgProductMngHourlyService.getTransferAgProductMngHourlyMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferAgProductMngHourlyService.getBatchBaseDao();
    }

    @Override
    protected String getSelectMesDataSqlFileName() {
        return "selectAgProductMngHourly.sql";
    }

    @Override
    protected String getAddTableName() {
        return "ag_product_mng_hourly";
    }

    @Override
    protected String getInsertFileName() {
        return "insertAgProductMngHourly.sql";
    }

}
