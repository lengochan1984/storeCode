/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/09/28| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import java.sql.Timestamp;
import java.util.List;

import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferSeihinPlanManualSettingDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferSeihinPlanManualSettingMesDao;
import jp.ysk.mmcloud.visualization.common.batch.util.CM_BatchLoggerUtil;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrSeihinPlanManualSettingEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrTransferDatetimeEntity;

import org.seasar.framework.beans.util.BeanMap;

/**
 *
 * 製品計画台数（手動設定）テーブル登録処理.<br>
 *<br>
 * 概要:<br>
 * 製品計画台数（手動設定）テーブルを見える化からMesデータへ登録する処理
 *<br>
 */
public class TransferSeihinPlanManualSettingService extends TransferDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferSeihinPlanManualSettingMesDao> tlMesDao = new ThreadLocal<TransferSeihinPlanManualSettingMesDao>() {
        @Override
        protected TransferSeihinPlanManualSettingMesDao initialValue() {
            return new TransferSeihinPlanManualSettingMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferSeihinPlanManualSettingMesDao getTransferSeihinPlanManualSettingMesDao() {
        return tlMesDao.get();
    }

    /**
     * MIERUKAスキーマDao.
     */
    private static ThreadLocal<TransferSeihinPlanManualSettingDao> tlDao = new ThreadLocal<TransferSeihinPlanManualSettingDao>() {
        @Override
        protected TransferSeihinPlanManualSettingDao initialValue() {
            return new TransferSeihinPlanManualSettingDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static TransferSeihinPlanManualSettingDao getTransferSeihinPlanManualSettingDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferSeihinPlanManualSettingService.getTransferSeihinPlanManualSettingMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferSeihinPlanManualSettingService.getTransferSeihinPlanManualSettingDao();
    }

    @Override
    protected String getSelectMesDataSqlFileName() {
        return "";
    }
    /**
     * 見える化データ取得用SQLファイル名.
     * @return SQLファイル名
     */
    private String getSelectMierukaDataSqlFileName() {
        return "selectSeihinPlanManualSetting.sql";
    }

    @Override
    protected String getAddTableName() {
        return "tr_seihin_plan_manual_setting";
    }

    @Override
    protected String getInsertFileName() {
        return "insertSeihinPlanManualSetting.sql";
    }
    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#execute()
     */
    @Override
    public void execute() {

        String addTableName = this.getAddTableName();
        String connectStr = TransferDataBaseService.getMesDbConnectInfo();
        String userId = TransferDataBaseService.getMesDbUserId();
        // 更新日時取得
        TrTransferDatetimeEntity datetimeEntity = this.getBatchDao().selectAddDatetime(addTableName, connectStr, userId);

        Timestamp addDatetime = null;
        if (CM_CommonUtil.isNotNullOrBlank(datetimeEntity)) {
            addDatetime = datetimeEntity.updDatetime;
        }
        // Mierukaデータ取得SQLパラメータ設定
        BeanMap sqlParam = new BeanMap();
        sqlParam.put(MaPlantEntityNames.plantCd().toString(), BatchBaseService.getPlantCode());
        sqlParam.put(KEY_ADD_DATETIME, addDatetime);

        // Mierukaデータ取得用SQLファイル名
        String sqlFileName = this.getSelectMierukaDataSqlFileName();

        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MIERUKAデータ取得開始");
        List<BeanMap> mierukaDataList = TransferSeihinPlanManualSettingService.getTransferSeihinPlanManualSettingDao().selectMierukaData(sqlFileName, sqlParam);
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MIERUKAデータ取得終了");
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MIERUKAデータ取得条件[" + addDatetime + "]");
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MIERUKAデータ取得件数[" + mierukaDataList.size() + "件]");

        if (mierukaDataList.size() == 0) {
            return;
        }

        String insertFilePath = this.getInsertFileName();
        long maxDatetime = 0;

        try {
            //トランザクション開始
            this.getMesSchemaDao().biginTransaction();

            for (BeanMap mierukaData : mierukaDataList) {
                // MESデータ登録
                CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録処理開始");
                TransferSeihinPlanManualSettingService.getTransferSeihinPlanManualSettingMesDao().executeInsertMierukaData(insertFilePath, mierukaData);
                CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録処理終了");

                Timestamp updateDate = (Timestamp) mierukaData.get(TrSeihinPlanManualSettingEntityNames.updTim().toString());
                if (updateDate.getTime() > maxDatetime) {
                    // 登録日時登録
                    datetimeEntity = new TrTransferDatetimeEntity();
                    datetimeEntity.tableName = addTableName;
                    datetimeEntity.updDatetime = updateDate;
                    datetimeEntity.connectionString = connectStr;
                    datetimeEntity.userId = userId;
                    CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MES-DB接続情報[" + connectStr + "]");
                    CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MES-DBユーザID[" + userId + "]");
                    CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "更新日時[" + updateDate + "]");
                    CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録日時登録処理開始");
                    this.getBatchDao().updateAddDatetime(datetimeEntity);
                    CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録日時登録処理終了");
                    maxDatetime = updateDate.getTime();
                }
            }
            //正常登録時はコミット
            this.getMesSchemaDao().commitTransaction();
        } catch (Exception e) {
            //ロールバック
            this.getMesSchemaDao().rollbackTransaction();
            // エラーログ出力
            CM_BatchLoggerUtil.outputErrorLog(this.companyId, this.processName, e);
        }
    }
}
