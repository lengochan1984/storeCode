/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/09/12| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.mmcloud.common.entity.customer.MstMailAddressEntity;
import jp.ysk.mmcloud.common.entity.customer.MstRoleEntity;
import jp.ysk.mmcloud.common.entity.customer.MstUserEntity;
import jp.ysk.mmcloud.common.entity.customer.RelUserGroupEntity;
import jp.ysk.mmcloud.common.entity.customer.RelUserRoleEntity;
import jp.ysk.mmcloud.common.entity.customer.SysNameEntity;
import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferMaUserDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferMaUserMesDao;
import jp.ysk.mmcloud.visualization.common.CM_A04_Const;
import jp.ysk.mmcloud.visualization.common.batch.CM_BatchConst;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaUserEntityNames;
import jp.ysk.mmcloud.visualization.common.util.CM_CommonUtil;

import org.seasar.framework.beans.util.BeanMap;

/**
 *
 * 作業者マスタ登録処理.<br>
 *<br>
 * 概要:<br>
 * 作業者マスタをMesデータから登録する処理
 *<br>
 */
public class TransferMaUserService extends TransferDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferMaUserMesDao> tlMesDao = new ThreadLocal<TransferMaUserMesDao>() {
        @Override
        protected TransferMaUserMesDao initialValue() {
            return new TransferMaUserMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferMaUserMesDao getTransferMaUserMesDao() {
        return tlMesDao.get();
    }

    /**
     * Dao.
     */
    private static ThreadLocal<TransferMaUserDao> tlDao = new ThreadLocal<TransferMaUserDao>() {
        @Override
        protected TransferMaUserDao initialValue() {
            return new TransferMaUserDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static TransferMaUserDao getTransferMaUserDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferMaUserService.getTransferMaUserMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getAddTableName()
     */
    @Override
    protected String getAddTableName() {
        return "ma_user";
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getSelectMesDataSqlFileName()
     */
    @Override
    protected String getSelectMesDataSqlFileName() {
        return "selectMaUser.sql";
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getInsertFileName()
     */
    @Override
    protected String getInsertFileName() {
        return "insertMaUser.sql";
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferMaUserService.getTransferMaUserDao();
    }

    @Override
    protected void afterInsertData(final BeanMap _mesData) {

        if (CM_CommonUtil.isNullOrBlank(_mesData.get(MaUserEntityNames.password().toString())) ||
        		CM_CommonUtil.isNullOrBlank(_mesData.get(MaUserEntityNames.password().toString()).toString().trim())) {
            // パスワードが未入力の場合登録しない
            return;
        }
        String userId = _mesData.get("userId").toString().trim();
        // ユーザ情報取得
        MstUserEntity userEntity = TransferMaUserService.getTransferMaUserDao().selectUserInfo(userId);

        if (CM_CommonUtil.isNullOrBlank(userEntity)) {
            // 登録処理
            this.insertUserInfo(_mesData, userId);
        } else {
            // 更新処理
            this.updateUserInfo(_mesData, userEntity, userId);
        }

        // 作業者マスタ更新
        TransferMaUserService.getTransferMaUserDao().updateMaUser(userId);
    }

    /**
     *
     * ユーザ情報登録処理.<br>
     *<br>
     * 概要:<br>
     *  ログインに必要なユーザ情報を登録する
     *<br>
     * @param _mesData MESデータ
     * @param _userId ユーザID
     */
    private void insertUserInfo(final BeanMap _mesData, final String _userId) {
        MstUserEntity userEntity = new MstUserEntity();

        this.setMaUserCommonData(_mesData, userEntity, _userId);
        userEntity.userAuthCd = CM_A04_Const.USER_AUTH_CD;
        userEntity.timezoneCd = FW00_19_Const.TZ_JPN;
        userEntity.langCd = CM_A04_Const.CST_LANG_CD_JPN;
        // テーマカラーのデフォルト取得
        SysNameEntity themaColor = TransferMaUserService.getTransferMaUserDao().selectDefaultSysName(
                CM_A04_Const.SYS_NAME_MST_NAME_TYPE.THEME_COLOR, CM_A04_Const.CST_LANG_CD_JPN);
        userEntity.themeColorCd = themaColor.itemCd;
        userEntity.clockDispFlag = "0";
        userEntity.charSize = CM_A04_Const.CHAR_SIZE;
        Calendar cal = Calendar.getInstance();
        final int year = 2100;
        cal.set(year, 0, 1);
        userEntity.expTim = new Timestamp(cal.getTimeInMillis());
        userEntity.deleteFlag = false;
        userEntity.insProg = "insert-mst_user";
        Timestamp now = new Timestamp(new Date().getTime());
        userEntity.insTim = now;
        userEntity.insUserSid = 0;
        userEntity.updProg = "insert-mst_user";
        userEntity.updTim = now;
        userEntity.updUserSid = 0;

        // ユーザマスタ登録
        TransferMaUserService.getTransferMaUserDao().insertMaUser(userEntity);

        // 役割登録
        MstRoleEntity roleEntity = TransferMaUserService.getTransferMaUserDao().selectDefaultRoleEntity();
        RelUserRoleEntity relUserRole = new RelUserRoleEntity();
        relUserRole.userSid = userEntity.sid;
        relUserRole.roleSid = roleEntity.sid;
        relUserRole.deleteFlag = false;
        relUserRole.insProg = userEntity.insProg;
        relUserRole.insTim = userEntity.insTim;
        relUserRole.insUserSid = userEntity.insUserSid;
        relUserRole.updProg = userEntity.updProg;
        relUserRole.updTim = userEntity.updTim;
        relUserRole.updUserSid = userEntity.updUserSid;

        TransferMaUserService.getTransferMaUserDao().insertRelUserRole(relUserRole);

        // グループ関連登録
        RelUserGroupEntity relUserGroup = new RelUserGroupEntity();
        relUserGroup.userSid = userEntity.sid;
        relUserGroup.groupId = CM_A04_Const.GROUP_ROOT;
        relUserGroup.deleteFlag = false;
        relUserGroup.insProg = userEntity.insProg;
        relUserGroup.insTim = userEntity.insTim;
        relUserGroup.insUserSid = userEntity.insUserSid;
        relUserGroup.updProg = userEntity.updProg;
        relUserGroup.updTim = userEntity.updTim;
        relUserGroup.updUserSid = userEntity.updUserSid;

        TransferMaUserService.getTransferMaUserDao().insertRelUserGroup(relUserGroup);

        // メールアドレス登録
        MstMailAddressEntity mailAddress = new MstMailAddressEntity();
        mailAddress.userSid = userEntity.sid;
        mailAddress.name = "MES-Visualization";
        mailAddress.mailAddress = "mes.visualization@ysknet.co.jp";
        mailAddress.passwordSendFlag = true;
        mailAddress.langCd = CM_A04_Const.CST_LANG_CD_JPN;
        mailAddress.deleteFlag = false;
        mailAddress.insProg = userEntity.insProg;
        mailAddress.insTim = userEntity.insTim;
        mailAddress.insUserSid = userEntity.insUserSid;
        mailAddress.updProg = userEntity.updProg;
        mailAddress.updTim = userEntity.updTim;
        mailAddress.updUserSid = userEntity.updUserSid;

        TransferMaUserService.getTransferMaUserDao().insertMailAddress(mailAddress);
    }

    /**
     *
     * ユーザ情報更新処理.<br>
     *<br>
     * 概要:<br>
     *  ログインに必要なユーザ情報を登録する
     *<br>
     * @param _mesData MESデータ
     * @param _userEntity ユーザマスタ情報
     * @param _userId ユーザID
     */
    private void updateUserInfo(final BeanMap _mesData, final MstUserEntity _userEntity, final String _userId) {
        this.setMaUserCommonData(_mesData, _userEntity, _userId);
        _userEntity.updProg = "update-mst_user";
        _userEntity.updTim = new Timestamp(new Date().getTime());
        _userEntity.updUserSid = 0;

        TransferMaUserService.getTransferMaUserDao().updateMaUser(_userEntity);
    }

    /**
     *
     * ユーザ情報共通設定.<br>
     *<br>
     * 概要:<br>
     *  ユーザ情報の登録と更新で共通の値を設定する
     *<br>
     * @param _mesData MESデータ
     * @param _userEntity ユーザマスタ情報
     * @param _userId ユーザID
     */
    private void setMaUserCommonData(final BeanMap _mesData, final MstUserEntity _userEntity, final String _userId) {
        _userEntity.id = _userId;
        String userName = _mesData.get(CM_BatchConst.COMMON_SQL_PARAM.USER_NAME).toString().trim();
        String lastName = userName;
        String firstName = FW00_19_Const.EMPTY_STR;
        if (userName.indexOf(FW00_19_Const.SPACE) != -1) {
            int spaceIndex = userName.indexOf(FW00_19_Const.SPACE);
            lastName = userName.substring(0, spaceIndex);
            firstName = userName.substring(spaceIndex  + 1);
        } else if (userName.indexOf("　") != -1) {
            int spaceIndex = userName.indexOf("　");
            lastName = userName.substring(0, spaceIndex);
            firstName = userName.substring(spaceIndex + 1);
        }
        _userEntity.userLastname = lastName;
        _userEntity.userFirstname = firstName;
// 2017/03/13 H.Nakamura mod start MES側で暗号化するようになったので、見える化での暗号化処理を削除する
//        _userEntity.passwd = CM_CommonUtil.getSha256(_mesData.get(MstWorkerEntityNames.password().toString()).toString().trim());
        _userEntity.passwd = _mesData.get(MaUserEntityNames.password().toString()).toString().trim();
// 2017/03/13 H.Nakamura mod end MES側で暗号化するようになったので、見える化での暗号化処理を削除する
        //MES側でのinvalidFlagがないので見える化側で「0」という既定値を指定する。
        _userEntity.invalidFlag = "0";
    }

}
