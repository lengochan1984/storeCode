package jp.ysk.mmcloud.visualization.batch.dto;

import java.sql.Timestamp;

import org.seasar.extension.jdbc.annotation.Out;

/**
 * プロシージャ実行用引数DTO.<br>
 *<br>
 * 概要:<br>
 *  プロシージャ実行用引数DTO
 *<br>
 */
public class ProcedureBaseParamDto {

    /**
     * バッチ処理名称.
     */
    private String batchName;

    /**
     * ログ種別.
     */
    private Integer logType;

    /**
     * 登録ユーザSID.
     */
    private Integer userSid;

    /**
     * 集計開始日.
     */
    private Timestamp fromTime;

    /**
     * 集計終了日.
     */
    private Timestamp toTime;

    /**
     * 処理結果コード.<br>
     * 0:正常終了 -1:以上終了
     */
    @Out
    private Integer retCd;

    /**
     * DBエラー情報(エラー番号).
     */
    @Out
    private String sqlerr;

    /**
     * DBエラー情報(エラーメッセージ).
     */
    @Out
    private String errmsg;

    /**
     * エラー発生ポイント.
     */
    @Out
    private String errpnt;

    /**
     * バッチ処理名称を取得.
     *
     * @return バッチ処理名称
     */
    public String getBatchName() {
        return this.batchName;
    }

    /**
     * バッチ処理名称を設定する.
     *
     * @param _batchName バッチ処理名称
     */
    public void setBatchName(final String _batchName) {
        this.batchName = _batchName;
    }

    /**
     * ログ種別を取得.
     *
     * @return ログ種別
     */
    public Integer getLogType() {
        return this.logType;
    }

    /**
     * ログ種別を設定する.
     *
     * @param _logType ログ種別
     */
    public void setLogType(final Integer _logType) {
        this.logType = _logType;
    }

    /**
     * 登録ユーザSIDを取得.
     *
     * @return 登録ユーザSID
     */
    public Integer getUserSid() {
        return this.userSid;
    }

    /**
     * 登録ユーザSIDを設定する.
     *
     * @param _userSid 登録ユーザSID
     */
    public void setUserSid(final Integer _userSid) {
        this.userSid = _userSid;
    }

    /**
     * 集計開始日を取得.
     *
     * @return 集計開始日
     */
    public Timestamp getFromTime() {
        return this.fromTime;
    }

    /**
     * 集計開始日を設定する.
     *
     * @param _fromTime 集計開始日
     */
    public void setFromTime(final Timestamp _fromTime) {
        this.fromTime = _fromTime;
    }

    /**
     * 集計終了日を取得.
     *
     * @return 集計終了日
     */
    public Timestamp getToTime() {
        return this.toTime;
    }

    /**
     * 集計終了日を設定する.
     *
     * @param _toTime 集計終了日
     */
    public void setToTime(final Timestamp _toTime) {
        this.toTime = _toTime;
    }

    /**
     * 処理結果コードを取得.
     *
     * @return 処理結果コード
     */
    public Integer getRetCd() {
        return this.retCd;
    }

    /**
     * 処理結果コードを設定する.
     *
     * @param _retCd 処理結果コード
     */
    public void setRetCd(final Integer _retCd) {
        this.retCd = _retCd;
    }

    /**
     * DBエラー情報(エラー番号)を取得.
     *
     * @return DBエラー情報(エラー番号)
     */
    public String getSqlerr() {
        return this.sqlerr;
    }

    /**
     * DBエラー情報(エラー番号)を設定する.
     *
     * @param _sqlerr DBエラー情報(エラー番号)
     */
    public void setSqlerr(final String _sqlerr) {
        this.sqlerr = _sqlerr;
    }

    /**
     * DBエラー情報(エラーメッセージ)を取得.
     *
     * @return DBエラー情報(エラーメッセージ)
     */
    public String getErrmsg() {
        return this.errmsg;
    }

    /**
     * DBエラー情報(エラーメッセージ)を設定する.
     *
     * @param _errmsg DBエラー情報(エラーメッセージ)
     */
    public void setErrmsg(final String _errmsg) {
        this.errmsg = _errmsg;
    }

    /**
     * エラー発生ポイントを取得.
     *
     * @return エラー発生ポイント
     */
    public String getErrpnt() {
        return this.errpnt;
    }

    /**
     * エラー発生ポイントを設定する.
     *
     * @param _errpnt エラー発生ポイント
     */
    public void setErrpnt(final String _errpnt) {
        this.errpnt = _errpnt;
    }

}
