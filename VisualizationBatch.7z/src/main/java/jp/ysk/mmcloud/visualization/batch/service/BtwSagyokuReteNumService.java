/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/10/17| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dto.ProcedureBaseParamDto;

/**
 *
 * 作業区間滞留数ログプロシージャ起動処理Service.<br>
 *<br>
 * 概要:<br>
 * 作業区間滞留数ログプロシージャ起動処理Serviceクラス
 *<br>
 */
public class BtwSagyokuReteNumService extends ExecuteProcedureBaseService {

    /**
     * Dao.
     */
    public BatchBaseDao batchBaseDao;

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#setProcedureParam(jp.ysk.mmcloud.visualization.batch.dto.ProcedureBaseParamDto)
     */
    @Override
    protected void setProcedureParam(final ProcedureBaseParamDto _paramDto) {
        Calendar cal = Calendar.getInstance();
        // 現在日時設定
        cal.setTime(new Date());
        // 終了日時設定
        _paramDto.setToTime(new Timestamp(cal.getTimeInMillis()));

        // 開始日時設定
        cal.add(Calendar.DAY_OF_MONTH, -1);
        _paramDto.setFromTime(new Timestamp(cal.getTimeInMillis()));
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return this.batchBaseDao;
    }
}
