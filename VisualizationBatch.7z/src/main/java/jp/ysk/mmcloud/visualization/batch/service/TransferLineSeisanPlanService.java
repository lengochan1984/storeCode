/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2016/09/28| <C1.01>　新規作成                                                    | C1.01  | (US)萩尾
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.ysk.mmcloud.common.util.CM_CommonUtil;
import jp.ysk.mmcloud.visualization.batch.dao.BatchBaseDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferLineSeisanPlanDao;
import jp.ysk.mmcloud.visualization.batch.dao.TransferLineSeisanPlanMesDao;
import jp.ysk.mmcloud.visualization.common.batch.util.CM_BatchLoggerUtil;
import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;
import jp.ysk.mmcloud.visualization.common.entity.customer.MaPlantEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrLineSeisanPlanEntityNames;
import jp.ysk.mmcloud.visualization.common.entity.customer.TrTransferDatetimeEntity;

import org.seasar.framework.beans.util.BeanMap;

/**
 *
 * 生産計画テーブル登録処理.<br>
 *<br>
 * 概要:<br>
 * 生産計画テーブルを見える化からMesデータへ登録する処理
 *<br>
 */
public class TransferLineSeisanPlanService extends TransferDataBaseService {

    /**
     * MESスキーマDao.
     */
    private static ThreadLocal<TransferLineSeisanPlanMesDao> tlMesDao = new ThreadLocal<TransferLineSeisanPlanMesDao>() {
        @Override
        protected TransferLineSeisanPlanMesDao initialValue() {
            return new TransferLineSeisanPlanMesDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MESスキーマDao
     */
    private static TransferLineSeisanPlanMesDao getTransferLineSeisanPlanMesDao() {
        return tlMesDao.get();
    }

    /**
     * MIERUKAスキーマDao.
     */
    private static ThreadLocal<TransferLineSeisanPlanDao> tlDao = new ThreadLocal<TransferLineSeisanPlanDao>() {
        @Override
        protected TransferLineSeisanPlanDao initialValue() {
            return new TransferLineSeisanPlanDao();
        }
    };

    /**
     * 現行スレッドの値を取得.
     * @return MierukaスキーマDao
     */
    private static TransferLineSeisanPlanDao getTransferLineSeisanPlanDao() {
        return tlDao.get();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.TransferDataBaseService#getMesSchemaDao()
     */
    @Override
    public CM_BaseMesSchemaDao getMesSchemaDao() {
        return TransferLineSeisanPlanService.getTransferLineSeisanPlanMesDao();
    }

    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#getBatchDao()
     */
    @Override
    public BatchBaseDao getBatchDao() {
        return TransferLineSeisanPlanService.getTransferLineSeisanPlanDao();
    }

    @Override
    protected String getSelectMesDataSqlFileName() {
        return "";
    }
    /**
     * 見える化データ取得用SQLファイル名.
     * @return SQLファイル名
     */
    private String getSelectMierukaDataSqlFileName() {
        return "selectLineSeisanPlan.sql";
    }

    @Override
    protected String getAddTableName() {
        return "tr_line_seisan_plan";
    }

    @Override
    protected String getInsertFileName() {
        return "insertLineSeisanPlan.sql";
    }
    /* (非 Javadoc)
     * @see jp.ysk.mmcloud.visualization.batch.service.BatchBaseService#execute()
     */
    @Override
    public void execute() {

        String addTableName = this.getAddTableName();
        String connectStr = TransferDataBaseService.getMesDbConnectInfo();
        String userId = TransferDataBaseService.getMesDbUserId();
        // 更新日時取得
        TrTransferDatetimeEntity datetimeEntity = this.getBatchDao().selectAddDatetime(addTableName, connectStr, userId);

        Timestamp addDatetime = null;
        if (CM_CommonUtil.isNotNullOrBlank(datetimeEntity)) {
            addDatetime = datetimeEntity.updDatetime;
        }
        // Mierukaデータ取得SQLパラメータ設定
        BeanMap sqlParam = new BeanMap();
        sqlParam.put(MaPlantEntityNames.plantCd().toString(), BatchBaseService.getPlantCode());
        sqlParam.put(KEY_ADD_DATETIME, addDatetime);

        // Mierukaデータ取得用SQLファイル名
        String sqlFileName = this.getSelectMierukaDataSqlFileName();

        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MIERUKAデータ取得開始");
        List<BeanMap> mierukaDataList = TransferLineSeisanPlanService.getTransferLineSeisanPlanDao().selectMierukaData(sqlFileName, sqlParam);
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MIERUKAデータ取得終了");
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MIERUKAデータ取得条件[" + addDatetime + "]");
        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MIERUKAデータ取得件数[" + mierukaDataList.size() + "件]");

        if (mierukaDataList.size() == 0) {
            return;
        }

        String insertFilePath = this.getInsertFileName();
        long maxDatetime = 0;

        Map<String, List<BeanMap>> dataMap = new HashMap<String,List<BeanMap>>();
        List<String> keyList = new ArrayList<String>();
        String keyDate = "";
        List<BeanMap> dataList = null;
        for (BeanMap fromData : mierukaDataList) {
            keyDate = fromData.get(TrLineSeisanPlanEntityNames.seisanBi()).toString();
            if (dataMap.containsKey(keyDate)) {
                dataList = dataMap.get(keyDate);
            } else {
                keyList.add(keyDate);
                dataList = new ArrayList<BeanMap>();
            }
            dataList.add(fromData);
            dataMap.put(keyDate, dataList);
        }
        List<BeanMap> registList = null;
        for (String key : keyList) {
            //日付毎の処理
            registList = dataMap.get(key);
            try {
                //トランザクション開始
                this.getMesSchemaDao().biginTransaction();
                //ライン毎のループ
                for (BeanMap mierukaData : registList) {
                    // MESデータ登録
                    CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録処理開始");
                    TransferLineSeisanPlanService.getTransferLineSeisanPlanMesDao().executeInsertMierukaData(insertFilePath, mierukaData);
                    CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録処理終了");

                    Timestamp updateDate = (Timestamp) mierukaData.get(TrLineSeisanPlanEntityNames.updTim().toString());
                    if (updateDate.getTime() > maxDatetime) {
                        // 登録日時登録
                        datetimeEntity = new TrTransferDatetimeEntity();
                        datetimeEntity.tableName = addTableName;
                        datetimeEntity.updDatetime = updateDate;
                        datetimeEntity.connectionString = connectStr;
                        datetimeEntity.userId = userId;
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MES-DB接続情報[" + connectStr + "]");
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "MES-DBユーザID[" + userId + "]");
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "更新日時[" + updateDate + "]");
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録日時登録処理開始");
                        this.getBatchDao().updateAddDatetime(datetimeEntity);
                        CM_BatchLoggerUtil.outputDebugLog(this.companyId, this.processName, "登録日時登録処理終了");
                        maxDatetime = updateDate.getTime();
                    }
                }
                //正常登録時はコミット
                this.getMesSchemaDao().commitTransaction();
            } catch (Exception e) {
                //ロールバック
                this.getMesSchemaDao().rollbackTransaction();
                // エラーログ出力
                CM_BatchLoggerUtil.outputErrorLog(this.companyId, this.processName, e);
            }
        }
    }
}
