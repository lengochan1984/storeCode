/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/09/19| <C1.01>　新規作成（複数MES-DB接続対応）              | C1.01  | (YSK)元満
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.service;

import java.util.List;

import javax.annotation.Resource;

import org.seasar.framework.beans.util.BeanMap;

import jp.ysk.fw.FW00_12_AppException;
import jp.ysk.mmcloud.common.dao.CM_ResourceUtilDao;
import jp.ysk.mmcloud.common.entity.root.MstCustomerEntity;
import jp.ysk.mmcloud.common.entity.root.SysDbConnectEntity;
import jp.ysk.mmcloud.visualization.batch.dao.MesDbInfoDao;
import jp.ysk.mmcloud.visualization.common.batch.util.CM_BatchLoggerUtil;

/**
 *
 * MES-DB接続情報取得処理サービスクラス.<br>
 *<br>
 * 概要:<br>
 *  MES-DB接続情報取得処理サービスクラス
 *<br>
 */
public class MesDbInfoService {

    /**
     * リソース関連処理Dao.
     */
    @Resource
    public CM_ResourceUtilDao cM_ResourceUtilDao;

    /**
     * DB接続Entity.
     */
    public SysDbConnectEntity sysDbConnectionEntity;

    /**
     * 顧客ID.
     */
    public String companyId;

    /**
     * 実行プロセス名.
     */
    public String processName;

    /**
     * PostgreSQLクエリタイムアウト値.
     */
    public int queryTimeout;

    /**
     * 工場マスタ（見える化専用）データ取得Dao.
     */
    @Resource
    public MesDbInfoDao mesDbInfoDao;

    /**
     *
     * 顧客DB接続.<br>
     *<br>
     * 概要:<br>
     * 顧客DB接続処理
     *<br>
     */
    public void connectCustomerDb() {

        // 顧客情報取得
        MstCustomerEntity customerEntity = this.cM_ResourceUtilDao.getCustomerEntity(this.companyId);
        if (customerEntity == null) {
            // 顧客IDが存在しない場合
            CM_BatchLoggerUtil.outputLog(this.companyId, this.processName,
                    "companyId=" + this.companyId + " is not exist.");

            // 例外を発生させて以降の処理をスキップする
            throw new FW00_12_AppException("Not exist companyId");
        }

        // 接続文字列、ユーザ名、パスワード
        this.sysDbConnectionEntity = this.cM_ResourceUtilDao.getDbConnectionEntity(customerEntity.sid);

        // 顧客スキーマ用のDaoを生成
        this.getBatchDao().init(this.sysDbConnectionEntity, this.companyId, this.processName, this.queryTimeout);
    }

    /**
     * 工場マスタ（見える化専用）データ取得処理.
     * @return 工場マスタ（見える化専用）データリスト
     */
    public List<BeanMap> getMesDbInfo() {

        return this.getBatchDao().selectMaPlantMierukaList(null);
    }

    /**
     *
     * Dao取得.<br>
     *<br>
     * 概要:<br>
     *   MES-DB接続情報取得処理Dao
     *<br>
     * @return MES-DB接続情報取得処理Dao
     */
    private MesDbInfoDao getBatchDao() {
        return this.mesDbInfoDao;
    }

}
