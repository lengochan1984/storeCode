/*
 * **********************************************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2017 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **********************************************************************************************************
 * ===========+======================================================================+========+==============
 *  DATE      | Comments                                                             | Rev    | SIGN
 * ===========+======================================================================+========+==============
 *  2017/02/28| <C1.01>　新規作成                                                    | C1.01  | T.Koyama
 * -----------+----------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.mmcloud.visualization.batch.dao;

import jp.ysk.mmcloud.visualization.common.dao.CM_BaseMesSchemaDao;

/**
 *
 * 製造ラインマスタ登録MESスキーマDao.<br>
 *<br>
 * 概要:<br>
 * 製造ラインマスタ登録MESスキーマDaoクラス
 *<br>
 */
public class TransferMaSeizouLineMesDao extends CM_BaseMesSchemaDao {

}
