/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2005 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/23| 新規作成                           | 1.0    | YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.test.telecom;

import java.sql.Connection;
import java.sql.DriverManager;

import org.dbunit.AbstractDatabaseTester;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.IDataSet;
import org.dbunit.ext.postgresql.PostgresqlDataTypeFactory;
import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

/**
 * DBアクセステスター.<br>
 *<br>
 * 概要:<br>
 *   DBアクセステストの初期化に使用するDBアクセスクラス
 *<br>
 */
public abstract class DbUnitTester extends AbstractDatabaseTester implements TestRule {

    /**
     * DB接続URL.
     */
    private final String connectionUrl;
    /**
     * DB接続用ユーザ名.
     */
    private final String username;
    /**
     * DB接続用パスワード.
     */
    private final String password;

    /**
     *
     * コンストラクタ.
     *
     * @param _driverClass JDBCドライバ名
     * @param _connectionUrl DB接続URL
     */
    public DbUnitTester(final String _driverClass, final String _connectionUrl) {
        this(_driverClass, _connectionUrl, null, null);
    }

    /**
     *
     * コンストラクタ.
     *
     * @param _driverClass JDBCドライバ名
     * @param _connectionUrl DB接続URL
     * @param _username DB接続用ユーザ名
     * @param _password DB接続用パスワード
     */
    public DbUnitTester(final String _driverClass, final String _connectionUrl,
            final String _username, final String _password) {
        this(_driverClass, _connectionUrl, _username, _password, null);
    }

    /**
     *
     * コンストラクタ.
     *
     * @param _driverClass JDBCドライバ名
     * @param _connectionUrl DB接続URL
     * @param _username DB接続用ユーザ名
     * @param _password DB接続用パスワード
     * @param _schema 接続先スキーマ名
     */
    public DbUnitTester(final String _driverClass, final String _connectionUrl,
            final String _username, final String _password, final String _schema) {
        super(_schema);
        this.connectionUrl = _connectionUrl;
        this.username = _username;
        this.password = _password;
        assertNotNullNorEmpty("driverClass", _driverClass);
        try {
            // JDBCドライバのロード
            Class.forName(_driverClass);
        } catch (ClassNotFoundException e) {
            throw new AssertionError(e);
        }
    }

    /* (非 Javadoc)
     * @see org.dbunit.IDatabaseTester#getConnection()
     */
    @Override
    public IDatabaseConnection getConnection() throws Exception {
        Connection conn = null;
        if (this.username == null && this.password == null) {
            conn = DriverManager.getConnection(this.connectionUrl);
        } else {
            conn = DriverManager.getConnection(this.connectionUrl, this.username, this.password);
        }

        DatabaseConnection dbConnection = new DatabaseConnection(conn, getSchema());

        DatabaseConfig config = dbConnection.getConfig();
        config.setProperty(DatabaseConfig.PROPERTY_DATATYPE_FACTORY, new PostgresqlDataTypeFactory());

        return dbConnection;
    }

    /**
     *
     * クエリー実行.<br>
     *<br>
     * 概要:<br>
     *   引数で渡されたSQL文を実行し、コミットする<br>
     *   オートコミットを解除
     *<br>
     * @param _sql SQL文文字列
     * @throws Exception 例外
     */
    protected void executeQuery(final String _sql) throws Exception {
        Connection conn = this.getConnection().getConnection();
        conn.setAutoCommit(false);
        java.sql.Statement state = conn.createStatement();
        state.execute(_sql);
        conn.commit();
        conn.close();
    }

    /**
     *
     * 前処理.<br>
     *<br>
     * 概要:<br>
     *   前処理を実行する
     *<br>
     * @throws Exception 例外
     */
    protected void before() throws Exception {

    }

    /**
     *
     * 後処理.<br>
     *<br>
     * 概要:<br>
     *   後処理を実行する
     *<br>
     * @throws Exception 例外
     */
    protected void after() throws Exception {

    }

    /**
     *
     * 初期値取得.<br>
     *<br>
     * 概要:<br>
     *   テスト実行前のDBに登録する初期値を取得する
     *<br>
     * @return データセット
     * @throws Exception 例外
     */
    protected abstract IDataSet createDataset() throws Exception;

    /* (非 Javadoc)
     * @see org.junit.rules.TestRule#apply(org.junit.runners.model.Statement, org.junit.runner.Description)
     */
    @Override
    public Statement apply(final Statement _base, final Description _description) {
        return new Statement() {

            @Override
            public void evaluate() throws Throwable {
                before();
                setDataSet(createDataset());
                onSetup();
                try {
                    _base.evaluate();
                } finally {
                    try {
                        after();
                    } finally {
                        onTearDown();
                    }
                }
            }

        };
    }

}
