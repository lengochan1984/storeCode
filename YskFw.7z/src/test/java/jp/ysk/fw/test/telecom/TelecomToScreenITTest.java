/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2005 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/05/27| 新規作成                           | 1.0    | YSK)大山
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.fw.test.telecom;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.junit.Rule;
import org.junit.Test;

/**
 * 通信プロセス IT用テストクラス.<br>
 *<br>
 * 概要:<br>
 *   通信プロセスのIT用テストクラス
 *<br>
 */
public class TelecomToScreenITTest {

    /**
     * 接続文字列.
     */
    private static final String CONNECT_STR = "//172.16.38.200:5432/mmcloud";

    /**
     * 接続ユーザ名.
     */
    private static final String CONNECT_USER = "nakata";

    /**
     * 接続パスワード.
     */
    private static final String CONNECT_PASSWORD = "nakata";

    /**
     * DBアクセステスター.
     */
    @Rule
    public DbUnitTester tester = new TelecomITDbUnitTester("fixtures_ITScreen.xml");

    /**
     * データファイル格納場所.
     */
    private static final String DATA_DIR = "C:\\MMCloud\\test\\testData\\";

    /**
     * ファイル名(ヘッダ).
     */
    private static final String FILE_HEADER = "testIT";

    /**
     * ファイル名(拡張子).
     */
    private static final String FILE_EXT = ".txt";


    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    @Test
    public void test_通信プロセス() {

        // テストデータ作成
        this.makeTestData();

        String ipAddr = "172.16.37.245";
        String port = "10000";

        TcpCommTool tool = new TcpCommTool();

        try {
            for (int i = 1; i <= 18; i++) {
                List<String> argList = new ArrayList<String>();
                argList.add(ipAddr);
                argList.add(port);
                argList.add(FILE_HEADER + i + FILE_EXT);

                tool.main((String[]) argList.toArray(new String[0]));

                Thread.sleep(15000);
            }

        } catch (Exception e) {

        }
    }

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    public void makeTestData() {

        int commandCd = 1501;
        int idx = 1;

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.HOUR, -1);

        for (int i = 0; i < 20; i++) {
            cal.add(Calendar.MINUTE, 2);
            String dataStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(cal.getTime());
            dataStr += ",";
            dataStr += (i*2+10);
            this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        }

        // 1
//        String dataStr = "2014-06-12 14:00:00,10"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:02:00,12"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:04:00,14"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:06:00,16"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:08:00,18"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:10:00,20"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:12:00,22"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:14:00,24"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:16:00,26"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:18:00,28"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:20:00,30"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:22:00,32"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:24:00,34"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:26:00,36"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:28:00,38"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:30:00,40"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:32:00,42"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:34:00,44"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:35:00,46"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:36:00,48"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
//        dataStr = "2014-06-12 14:40:00,50"; this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

    }

    private void outputFile(final String _filePath, final String _data, final String _commandCd) {
        this.outputFile(_filePath, _data, _commandCd, "UTF-8");
    }

    private void outputFile(final String _filePath, final String _data, final String _commandCd, final String _encode) {

        try {
            // ファイル出力
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print("01");
            // 顧客CD
            pw.print(this.formatStr("nakatacom", 10, "ASCII"));
            // 機器ID
            pw.print(this.formatStr("192.168.32.30", 20, "ASCII"));
            // コマンドコード
            pw.print(_commandCd);
            // データサイズ
            int length = _data.length();
            if (_data.getBytes(_encode).length > length) {
                length = _data.getBytes(_encode).length;
            }
            pw.print(String.format("%1$08X", length));
            // 予備
            pw.print("00000000000000000000000000");
            // データ
            pw.print(this.formatStr(_data, _data.length(), _encode));

            pw.close();

        } catch (Exception e) {

        }
    }

    private String formatStr(final String _dataStr, final int _length, final String _format) {

        String retStr = "";
        try {
            byte[] data = _dataStr.getBytes(_format);
            int length = _length;
            if (data.length > _length) {
                length = data.length;
            }
            for (int i = 0; i < length; i++) {
                if (i >= data.length) {
                    retStr += "00";
                } else {
                    retStr += String.format("%1$02X", data[i]);
                }
            }
        } catch (Exception e) {

        }

        return retStr;
    }

    /**
    *
    * IT DBアクセステスター.<br>
    *<br>
    * 概要:<br>
    *   テストデータ作成用のDBアクセステスター
    *<br>
    */
    static class TelecomITDbUnitTester extends DbUnitTester {
        /**
         * 初期値用データファイル.
         */
        private final String fixture;

        /**
         *
         * コンストラクタ.
         *
         * @param _fixture 初期値用データファイル名
         */
        public TelecomITDbUnitTester(final String _fixture) {
            super("org.postgresql.Driver",
                    "jdbc:postgresql:" + CONNECT_STR, CONNECT_USER, CONNECT_PASSWORD, CONNECT_USER);
            this.fixture = _fixture;
        }

        /* (非 Javadoc)
         * @see jp.ysk.mmcloud.DbUnitTester#before()
         */
        @Override
        protected void before() throws Exception {
//            // 初期化前のデータ削除処理
//            executeQuery("delete from mst_device");
//            executeQuery("delete from rel_device_group");
//            executeQuery("delete from mst_command");
//            executeQuery("delete from mst_data_point_position_xml");
//            executeQuery("delete from mst_data_point_position_csv");
//            executeQuery("delete from mst_data_point_position_fix");
//            executeQuery("delete from mst_datetime");
//            executeQuery("delete from mst_data_point_calc");
//            executeQuery("delete from mst_data_point");
        }

        /* (非 Javadoc)
         * @see jp.ysk.mmcloud.DbUnitTester#createDataset()
         */
        @Override
        protected IDataSet createDataset() throws Exception {
            // 初期化処理(データファイルから読み込む)
            return new FlatXmlDataSetBuilder().build(getClass().getResourceAsStream(this.fixture));
        }

    }

}
