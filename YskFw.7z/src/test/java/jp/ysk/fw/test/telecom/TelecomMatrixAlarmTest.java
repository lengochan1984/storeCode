/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2005 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/06/03| 新規作成                           | 1.0    | YSK)大山
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.fw.test.telecom;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.junit.Rule;
import org.junit.Test;

/**
 * 通信プロセス マトリクスPT用テストクラス(警報判定).<br>
 *<br>
 * 概要:<br>
 *   通信プロセスのマトリクスPT用テストクラス(警報判定)
 *<br>
 */
public class TelecomMatrixAlarmTest {

    /**
     * 接続文字列.
     */
    private static final String CONNECT_STR = "//172.16.38.200:5432/mmcloud";

    /**
     * 接続ユーザ名.
     */
    private static final String CONNECT_USER = "ohyama";

    /**
     * 接続パスワード.
     */
    private static final String CONNECT_PASSWORD = "ohyama";

    /**
     * DBアクセステスター.
     */
    @Rule
    public DbUnitTester tester = new TelecomMatrixAlarmDbUnitTester("fixtures_matrix_alarm.xml");

    /**
     * データファイル格納場所.
     */
    private static final String DATA_DIR = "C:\\MMCloud\\test\\testData\\";

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    @Test
    public void test_通信プロセス() {

        // テストデータ作成
        this.makeTestData();

        String ipAddr = "172.16.37.251";
        String port = "10000";

        TcpCommTool tool = new TcpCommTool();

        try {
            for (int i = 1; i <= 106; i++) {
                List<String> argList = new ArrayList<String>();
                argList.add(ipAddr);
                argList.add(port);
                argList.add("testData-alarm" + i + ".txt");

                tool.main((String[]) argList.toArray(new String[0]));

                Thread.sleep(300);
            }

        } catch (Exception e) {

        }
    }

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    public void makeTestData() {
        try {
            int idx = 0;
            int cmdIdx = 1100;

            // ファイル出力
            // 1
            String dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 2
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 3
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 4
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 5
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 6
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 7
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 8
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 9
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 10
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 11
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 12
            dataStr = "101";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 13
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 14
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 15
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 16
            dataStr = "101";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 17
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 18
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 19
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 20
            dataStr = "101";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 21
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 22
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 23
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 24
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 25
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 26
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 27
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 28
            dataStr = "101";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 29
            dataStr = "1001.0";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 30
            dataStr = "999.0";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 31
            dataStr = "50.0";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 32
            dataStr = "101.0";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 33
            dataStr = "1";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 34
            dataStr = "0";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 35
            dataStr = "0";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 36
            dataStr = "1";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 37
            dataStr = "alarm";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 38
            dataStr = "alarm1";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 39
            dataStr = "recover";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 40
            dataStr = "recover1";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 41
            dataStr = "10";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 42
            dataStr = "11";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 43
            dataStr = "12";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 44
            dataStr = "13";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 45
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 46
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 47
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 48
            dataStr = "101";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 49
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 50
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 51
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 52
            dataStr = "101";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 53
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 54
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 55
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 56
            dataStr = "101";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 57
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 58
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 59
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 60
            dataStr = "101";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 61
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 62
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 63
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 64
            dataStr = "101";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 65
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 66
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 67
            dataStr = "50";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 68
            dataStr = "101";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 69
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 70
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 71
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 72
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 73
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 74
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 75
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 76
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 77
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 78
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 79
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 80
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 81
            dataStr = "1001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 82
            dataStr = "999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 83
            dataStr = "1001,2001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 84
            dataStr = "1001,1999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 85
            dataStr = "99,199";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 86
            dataStr = "101,199";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 87
            dataStr = "1001,2001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 88
            dataStr = "1001,1999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 89
            dataStr = "99,199";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 90
            dataStr = "101,199";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 91
            dataStr = "1001,2001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 92
            dataStr = "1001,1999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 93
            dataStr = "99,199";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 94
            dataStr = "101,199";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 95
            dataStr = "1001,2001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 96
            dataStr = "1001,1999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 97
            dataStr = "99,199";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 98
            dataStr = "101,199";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 99
            dataStr = "1001,2001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 100
            dataStr = "1001,1999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 101
            dataStr = "99,199";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 102
            dataStr = "101,199";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 103
            dataStr = "1001,2001";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 104
            dataStr = "1001,1999";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 105
            dataStr = "99,199";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));
            // 106
            dataStr = "101,199";
            idx++;
            cmdIdx++;
            this.outputFile("testData-alarm" + String.valueOf(idx) + ".txt", dataStr, String.format("%1$03d", idx), String.valueOf(cmdIdx));

        } catch (Exception e) {

        }
    }

    private String formatStr(final String _dataStr, final int _length, final String _format) {

        String retStr = "";
        try {
            byte[] data = _dataStr.getBytes(_format);
            int length = _length;
            if (data.length > _length) {
                length = data.length;
            }
            for (int i = 0; i < length; i++) {
                if (i >= data.length) {
                    retStr += "00";
                } else {
                    retStr += String.format("%1$02X", data[i]);
                }
            }
        } catch (Exception e) {

        }

        return retStr;
    }

    private void outputFile(final String _filePath, final String _data, final String _deviceId, final String _comandCd) {

        try {
            // ファイル出力
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print("01");
            // 顧客CD
            pw.print(this.formatStr("company1", 10, "ASCII"));
            // 機器ID
            pw.print(this.formatStr(_deviceId, 20, "ASCII"));
            // コマンドコード
            pw.print(_comandCd);
            // データサイズ
            int length = _data.length();
            if (_data.getBytes("UTF-8").length > length) {
                length = _data.getBytes("UTF-8").length;
            }
            pw.print(String.format("%1$08X", length));
            // 予備
            pw.print("00000000000000000000000000");
            // データ
            pw.print(this.formatStr(_data, _data.length(), "UTF-8"));

            pw.close();

        } catch (Exception e) {

        }
    }


    /**
    *
    * マトリクス試験DBアクセステスター.<br>
    *<br>
    * 概要:<br>
    *   テストデータ作成用のDBアクセステスター
    *<br>
    */
    static class TelecomMatrixAlarmDbUnitTester extends DbUnitTester {
        /**
         * 初期値用データファイル.
         */
        private final String fixture;

        /**
         *
         * コンストラクタ.
         *
         * @param _fixture 初期値用データファイル名
         */
        public TelecomMatrixAlarmDbUnitTester(final String _fixture) {
            super("org.postgresql.Driver",
                    "jdbc:postgresql:" + CONNECT_STR, CONNECT_USER, CONNECT_PASSWORD, CONNECT_USER);
            this.fixture = _fixture;
        }

        /* (非 Javadoc)
         * @see jp.ysk.mmcloud.DbUnitTester#before()
         */
        @Override
        protected void before() throws Exception {
            // 初期化前のデータ削除処理
            executeQuery("delete from mst_device");
            executeQuery("delete from rel_device_group");
            executeQuery("delete from mst_command");
            executeQuery("delete from mst_data_point_position_xml");
            executeQuery("delete from mst_data_point_position_csv");
            executeQuery("delete from mst_data_point_position_fix");
            executeQuery("delete from mst_datetime");
            executeQuery("delete from mst_data_point");
            executeQuery("delete from mst_mail_address");
            executeQuery("delete from mst_mail_template");
            executeQuery("delete from mst_alarm");
            executeQuery("delete from mst_alarm_condition");
            executeQuery("delete from rel_device_alarm");
            executeQuery("delete from mst_alarm_send_address");
            executeQuery("delete from tbl_alarm_state_data");

        }

        /* (非 Javadoc)
         * @see jp.ysk.mmcloud.DbUnitTester#createDataset()
         */
        @Override
        protected IDataSet createDataset() throws Exception {
            // 初期化処理(データファイルから読み込む)
            return new FlatXmlDataSetBuilder().build(getClass().getResourceAsStream(this.fixture));
        }

    }
}
