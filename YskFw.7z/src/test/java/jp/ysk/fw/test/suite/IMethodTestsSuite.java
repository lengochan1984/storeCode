/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2005 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/23| 新規作成                           | 1.0    | YSK)植山
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.fw.test.suite;

import jp.ysk.fw.action.FW01_15_BaseAction;
import jp.ysk.fw.test.category.IMethodTestsCategory;

import org.junit.experimental.categories.Categories.IncludeCategory;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * 関数テストスイート.<br>
 *<br>
 * 概要:<br>
 *   全ての関数テストを実行するためのスイート
 *<br>
 */
@RunWith(Suite.class)
@IncludeCategory(IMethodTestsCategory.class)
@SuiteClasses({FW01_15_BaseAction.class })
public interface IMethodTestsSuite {
    // TODO アノテーションを定義中、後で見直すこと
}
