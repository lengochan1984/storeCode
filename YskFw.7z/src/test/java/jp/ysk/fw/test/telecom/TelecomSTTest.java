/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2005 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/06/06| 新規作成                           | 1.0    | YSK)大山
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.fw.test.telecom;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import jp.ysk.fw.test.telecom.TelecomMatrixTest.TelecomMatrixDbUnitTester;

import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.junit.Rule;
import org.junit.Test;

/**
 * {??クラス名??}.<br>
 *<br>
 * 概要:<br>
 *   {??クラス説明??}
 *<br>
 */
public class TelecomSTTest {

    /**
     * 接続文字列.
     */
    private static final String CONNECT_STR = "//172.16.38.200:5432/mmcloud";

    /**
     * 接続ユーザ名.
     */
    private static final String CONNECT_USER = "ohyama";

    /**
     * 接続パスワード.
     */
    private static final String CONNECT_PASSWORD = "ohyama";

    /**
     * 顧客CD.
     */
    private static final String CUSTOMER_CD = "ohyama";

    /**
     * DBアクセステスター.
     */
    @Rule
    public DbUnitTester tester = new TelecomMatrixDbUnitTester("fixtures_ST.xml");

    /**
     * データファイル格納場所.
     */
    private static final String DATA_DIR = "C:\\MMCloud\\test\\testData\\ST\\data\\1000\\";

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    @Test
    public void test_通信プロセス() {

        // テストデータ作成
        //this.makeTestDataContinus();
        this.makeTestData();

        String ipAddr = "133.162.240.49";
        String port = "10010";

        TcpCommTool tool = new TcpCommTool();

        try {
            for (int i = 1; i <= 1; i++) {
                List<String> argList = new ArrayList<String>();
                argList.add(ipAddr);
                argList.add(port);
                String deviceId = "device" + String.format("%1$03d", i);
                //argList.add("Continus-100-" + deviceId + ".txt");
                //argList.add("testData-csv-10000rec.txt");
                argList.add("testData-csv100KB-10000.txt");

                tool.main((String[]) argList.toArray(new String[0]));

                Thread.sleep(300);
            }

        } catch (Exception e) {

        }
    }

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    public void makeTestDataContinus() {

        // レコード数:1, 機器数:1000
        // レコード数
        String dataStr = "";
        for (int i = 0; i < 1; i++) {
            dataStr += "12345678\r\n";
        }
        // 機器数
        for (int i = 1; i <= 1000; i++) {
            String deviceId = "device" + String.format("%1$03d", i);
            //this.outputContinusFile("Continus-1-" + deviceId + ".txt", dataStr, "1102", deviceId);
            //this.outputFtpFile(deviceId, "1102", dataStr, "0001.csv");
        }

        // レコード数:10, 機器数:1000
        // レコード数
        dataStr = "";
        for (int i = 0; i < 10; i++) {
            dataStr += "12345678\r\n";
        }
        // 機器数
        for (int i = 1; i <= 1000; i++) {
            String deviceId = "device" + String.format("%1$03d", i);
            //this.outputContinusFile("Continus-10-" + deviceId + ".txt", dataStr, "1102", deviceId);
            //this.outputFtpFile(deviceId, "1102", dataStr, "0010.csv");
        }

        // レコード数:100, 機器数:1000
        // レコード数
        dataStr = "";
        for (int i = 0; i < 100; i++) {
            dataStr += "12345678\r\n";
        }
        // 機器数
        for (int i = 1; i <= 1000; i++) {
            String deviceId = "device" + String.format("%1$03d", i);
            //this.outputContinusFile("Continus-100-" + deviceId + ".txt", dataStr, "1102", deviceId);
            //this.outputFtpFile(deviceId, "1102", dataStr, "0100.csv");
        }

        // レコード数:1000, 機器数:1000
        // レコード数
        dataStr = "";
        for (int i = 0; i < 1000; i++) {
            dataStr += "12345678\r\n";
        }
        // 機器数
        for (int i = 1; i <= 1000; i++) {
            String deviceId = "device" + String.format("%1$03d", i);
            //this.outputContinusFile("Continus-1000-" + deviceId + ".txt", dataStr, "1102", deviceId);
            this.outputFtpFile(deviceId, "1102", dataStr, "1000.csv");
        }

    }

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    public void makePerformanceData() {

        // TCP/FTP(1レコード)
        String dataStr = "";
        for (int i = 0; i < 1; i++) {
            dataStr += "12345678\r\n";
        }
        this.outputFile("testData-csv-1rec.txt", dataStr, "1102");
        this.outputFtpFile("device001", "1102", dataStr, "1.csv");

        // TCP/FTP(10レコード)
        dataStr = "";
        for (int i = 0; i < 10; i++) {
            dataStr += "12345678\r\n";
        }
        this.outputFile("testData-csv-10rec.txt", dataStr, "1102");
        this.outputFtpFile("device001", "1102", dataStr, "10.csv");

        // TCP/FTP(100レコード)
        dataStr = "";
        for (int i = 0; i < 100; i++) {
            dataStr += "12345678\r\n";
        }
        this.outputFile("testData-csv-100rec.txt", dataStr, "1102");
        this.outputFtpFile("device001", "1102", dataStr, "100.csv");

        // TCP/FTP(1000レコード)
        dataStr = "";
        for (int i = 0; i < 1000; i++) {
            dataStr += "12345678\r\n";
        }
        this.outputFile("testData-csv-1000rec.txt", dataStr, "1102");
        this.outputFtpFile("device001", "1102", dataStr, "1000.csv");

        // TCP/FTP(10000レコード)
        dataStr = "";
        for (int i = 0; i < 10000; i++) {
            dataStr += "12345678\r\n";
        }
        this.outputFile("testData-csv-10000rec.txt", dataStr, "1102");
        this.outputFtpFile("device001", "1102", dataStr, "10000.csv");

    }

    private void outputContinusFile(final String _filePath, final String _data, final String _commandCd, final String _deviceId) {

        try {
            // ファイル出力
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print("01");
            // 顧客CD
            pw.print(this.formatStr("telecom001", 10, "ASCII"));
            // 機器ID
            pw.print(this.formatStr(_deviceId, 20, "ASCII"));
            // コマンドコード
            pw.print(_commandCd);
            // データサイズ
            int length = _data.length();
            if (_data.getBytes("UTF-8").length > length) {
                length = _data.getBytes("UTF-8").length;
            }
            pw.print(String.format("%1$08X", length));
            // 予備
            pw.print("00000000000000000000000000");
            // データ
            pw.print(this.formatStr(_data, _data.length(), "UTF-8"));

            pw.close();

        } catch (Exception e) {

        }
    }

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    public void makeTestData() {
        try {
            // TCP(30データポイント:CSV)
            // 1
            String dataStr = "2014-06-06 01:00:00";
            dataStr += ",2014-06-06 02:00:00";
            dataStr += ",2014-06-06 03:00:00";
            dataStr += ",2014-06-06 04:00:00";
            dataStr += ",2014-06-06 05:00:00";
            dataStr += ",2014-06-06 06:00:00";
            dataStr += ",2014-06-06 07:00:00";
            dataStr += ",2014-06-06 08:00:00";
            dataStr += ",2014-06-06 09:00:00";
            dataStr += ",2014-06-06 10:00:00";
            dataStr += ",2014-06-06 11:00:00";
            dataStr += ",2014-06-06 12:00:00";
            dataStr += ",2014-06-06 13:00:00";
            dataStr += ",2014-06-06 14:00:00";
            dataStr += ",2014-06-06 15:00:00";
            dataStr += ",1";
            dataStr += ",2";
            dataStr += ",3";
            dataStr += ",4";
            dataStr += ",5";
            dataStr += ",6";
            dataStr += ",7";
            dataStr += ",8";
            dataStr += ",9";
            dataStr += ",10";
            dataStr += ",11";
            dataStr += ",12";
            dataStr += ",13";
            dataStr += ",14";
            dataStr += ",15";
            this.outputFile("testData-ST1.txt", dataStr, "1101");
            this.outputFtpFile("device001", "1101", dataStr, "txt");

            // TCP(30データポイント:XML)
            String txt = "";
            txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<!-- comment -->";
            txt += "<group>";
            txt += "<remote>";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 01:00:00</time_str>";
            txt += "<value valid=\"true\">11</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>2</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 02:00:00</time_str>";
            txt += "<value valid=\"true\">12</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>3</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 03:00:00</time_str>";
            txt += "<value valid=\"true\">13</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>4</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 04:00:00</time_str>";
            txt += "<value valid=\"true\">14</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>5</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 05:00:00</time_str>";
            txt += "<value valid=\"true\">15</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>6</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 06:00:00</time_str>";
            txt += "<value valid=\"true\">16</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>7</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 07:00:00</time_str>";
            txt += "<value valid=\"true\">17</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>8</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 08:00:00</time_str>";
            txt += "<value valid=\"true\">18</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>9</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 09:00:00</time_str>";
            txt += "<value valid=\"true\">19</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>10</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 10:00:00</time_str>";
            txt += "<value valid=\"true\">20</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>11</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 11:00:00</time_str>";
            txt += "<value valid=\"true\">21</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>12</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 12:00:00</time_str>";
            txt += "<value valid=\"true\">22</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>13</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 13:00:00</time_str>";
            txt += "<value valid=\"true\">23</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>14</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 14:00:00</time_str>";
            txt += "<value valid=\"true\">24</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>15</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-06-05 15:00:00</time_str>";
            txt += "<value valid=\"true\">25</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-ST2.txt", txt, "1201");
            this.outputFtpFile("device001", "1201", txt, "xml");

            // TCP(30データポイント:FIX)
            byte[] data1 = {
                    7, -34, 6, 5, 10, 0, 0,
                    1,
                    7, -34, 6, 5, 10, 0, 0,
                    2,
                    7, -34, 6, 5, 10, 0, 0,
                    3,
                    7, -34, 6, 5, 10, 0, 0,
                    4, 5, 6};
            this.outputFileFix("testData-ST3.txt", data1, "1301");
            this.outputFtpFileFix("device001", "1301", data1);

//            // TCP/FTP(10000レコード 100KB:CSV)
            // 10B * 9990行 + 5B * 10行
            // 4
            dataStr = "";
            for (int i = 0; i < 10000; i++) {
                dataStr += "12345678\r\n";
            }
//            for (int i = 0; i < 10; i++) {
//                dataStr += "123\r\n";
//            }
            this.outputFile("testData-csv100KB-10000.txt", dataStr, "1102");
            int debug = 0;
//            this.outputFtpFile("device001", "1102", dataStr, "csv");

//            // TCP/FTP(10000レコード 100KB+10:CSV)
//            // 10B * 9990行 + 6B * 10行
//            // 4
//            dataStr = "";
//            for (int i = 0; i < 100010; i++) {
//                dataStr += "12345678\r\n";
//            }
////            for (int i = 0; i < 11; i++) {
////                dataStr += "1234\r\n";
////            }
//            this.outputFile("testData-csv100KB+10-10000.txt", dataStr, "1102");
//            this.outputFtpFile("device001", "1102", dataStr, "csv");

//            // TCP/FTP(10001レコード)
//            // 5B * 10001行
//            // 4
//            dataStr = "";
//            for (int i = 0; i < 10001; i++) {
//                dataStr += "12345\r\n";
//            }
//            this.outputFile("testData-csv10001.txt", dataStr, "1102");
//            this.outputFtpFile("device001", "1102", dataStr, "csv");

            // TCP/FTP(10000レコード 100KB:CSV)
            // 10B * 9990行 + 5B * 10行
            // 4
//            dataStr = "";
//            for (int i = 0; i < 1000; i++) {
//                dataStr += "12345678\r\n";
//            }
//            this.outputFile("testData-csv100KB-1000.txt", dataStr, "1102");
//            this.outputFtpFile("device001", "1102", dataStr, "csv");

//
//            // FTP(10000レコード:xml)
//            txt = "";
//            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
//            txt += "<file>";
//            for (int i = 0; i < 10000; i++) {
//                txt += "<record>";
//                txt += "<data>test1</data>";
//                txt += "</record>";
//            }
//            txt += "</file>";
//            this.outputFile("testData-xml10000.txt", txt, "1202");
//            this.outputFtpFile("device001", "1202", txt, "xml");

            // FTP(10000レコード:xml)
//            txt = "";
//            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
//            txt += "<file>";
//            for (int i = 0; i < 10001; i++) {
//                txt += "<record>";
//                txt += "<data>test1</data>";
//                txt += "</record>";
//            }
//            txt += "</file>";
//            this.outputFile("testData-xml10001.txt", txt, "1202");
//            this.outputFtpFile("device001", "1202", txt, "xml");
//
            // FTP(10000レコード:fix)
//            try {
//                // ファイル出力
//                FileOutputStream fos = new FileOutputStream(DATA_DIR + "device001" + "." + "1302.10000" + ".bin");
//                for (int i = 0; i < 10000; i++) {
//                    fos.write(100);
//                }
//                fos.close();
//
//            } catch (Exception e) {
//
//            }
//
//            try {
//                // ファイル出力
//                FileOutputStream fos = new FileOutputStream(DATA_DIR + "device001" + "." + "1302.10001" + ".bin");
//                for (int i = 0; i < 10001; i++) {
//                    fos.write(100);
//                }
//                fos.close();
//
//            } catch (Exception e) {
//
//            }
            //this.outputFileFixBigData("testData-ST4.txt", "1302", (byte) 100, 10000);



        } catch (Exception e) {

        }

    }

    private String formatStr(final String _dataStr, final int _length, final String _format) {

        String retStr = "";
        try {
            byte[] data = _dataStr.getBytes(_format);
            int length = _length;
            if (data.length > _length) {
                length = data.length;
            }
            for (int i = 0; i < length; i++) {
                if (i >= data.length) {
                    retStr += "00";
                } else {
                    retStr += String.format("%1$02X", data[i]);
                }
            }
        } catch (Exception e) {

        }

        return retStr;
    }

    private void outputFile(final String _filePath, final String _data, final String _commandCd) {

        try {
            // ファイル出力
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print("01");
            // 顧客CD
            pw.print(this.formatStr(CUSTOMER_CD, 10, "ASCII"));
            // 機器ID
            pw.print(this.formatStr("device001", 20, "ASCII"));
            // コマンドコード
            pw.print(_commandCd);
            // データサイズ
            int length = _data.length();
            if (_data.getBytes("UTF-8").length > length) {
                length = _data.getBytes("UTF-8").length;
            }
            pw.print(String.format("%1$08X", length));
            // 予備
            pw.print("00000000000000000000000000");
            // データ
            pw.print(this.formatStr(_data, _data.length(), "UTF-8"));

            pw.close();

        } catch (Exception e) {

        }
    }

    private void outputFtpFile(final String _deviceID, final String _commandCd, final String _data, final String _ext) {

        try {
            // ファイル出力
            File file = new File(DATA_DIR + _deviceID + "." + _commandCd + "." + _ext);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            // データ
            pw.print(_data);

            pw.close();

        } catch (Exception e) {

        }
    }

    private void outputFileFix(final String _filePath, final byte[] _data, final String _commandCd) {

        try {
            // ファイル出力(fix)
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print("01");
            // 顧客CD
            pw.print(this.formatStr(CUSTOMER_CD, 10, "ASCII"));
            // 機器ID
            pw.print(this.formatStr("device001", 20, "ASCII"));
            // コマンドコード
            pw.print(_commandCd);
            // データサイズ
            int length = _data.length;
            pw.print(String.format("%1$08X", length));
            // 予備
            pw.print("00000000000000000000000000");
            // データ
            for (int i = 0; i < length; i++) {
                pw.print(String.format("%1$02X", _data[i]));
            }

            pw.close();

        } catch (Exception e) {

        }
    }

    private void outputFileFixBigData(final String _filePath, final String _commandCd, final byte _data, final int _record) {

        try {
            // ファイル出力(fix)
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print("01");
            // 顧客CD
            pw.print(this.formatStr(CUSTOMER_CD, 10, "ASCII"));
            // 機器ID
            pw.print(this.formatStr("device001", 20, "ASCII"));
            // コマンドコード
            pw.print(_commandCd);
            // データサイズ
            int length = _record;
            pw.print(String.format("%1$08X", length));
            // 予備
            pw.print("00000000000000000000000000");
            // データ
            for (int i = 0; i < length; i++) {
                pw.print(String.format("%1$02X", _data));
            }

            pw.close();

        } catch (Exception e) {

        }
    }

    private void outputFtpFileFix(final String _deviceID, final String _commandCd, final byte[] _data) {

        try {
             // ファイル出力
            FileOutputStream fos = new FileOutputStream(DATA_DIR + _deviceID + "." + _commandCd + ".bin");
            fos.write(_data);
            fos.close();

        } catch (Exception e) {

        }
    }

    /**
    *
    * ST DBアクセステスター.<br>
    *<br>
    * 概要:<br>
    *   テストデータ作成用のDBアクセステスター
    *<br>
    */
    static class TelecomSTDbUnitTester extends DbUnitTester {
        /**
         * 初期値用データファイル.
         */
        private final String fixture;

        /**
         *
         * コンストラクタ.
         *
         * @param _fixture 初期値用データファイル名
         */
        public TelecomSTDbUnitTester(final String _fixture) {
            super("org.postgresql.Driver",
                    "jdbc:postgresql:" + CONNECT_STR, CONNECT_USER, CONNECT_PASSWORD, CONNECT_USER);
            this.fixture = _fixture;
        }

        /* (非 Javadoc)
         * @see jp.ysk.mmcloud.DbUnitTester#before()
         */
        @Override
        protected void before() throws Exception {
            // 初期化前のデータ削除処理
            executeQuery("delete from mst_device");
            executeQuery("delete from rel_device_group");
            executeQuery("delete from mst_command");
            executeQuery("delete from mst_data_point_position_xml");
            executeQuery("delete from mst_data_point_position_csv");
            executeQuery("delete from mst_data_point_position_fix");
            executeQuery("delete from mst_datetime");
            executeQuery("delete from mst_data_point_calc");
            executeQuery("delete from mst_data_point");
        }

        /* (非 Javadoc)
         * @see jp.ysk.mmcloud.DbUnitTester#createDataset()
         */
        @Override
        protected IDataSet createDataset() throws Exception {
            // 初期化処理(データファイルから読み込む)
            return new FlatXmlDataSetBuilder().build(getClass().getResourceAsStream(this.fixture));
        }

    }
}
