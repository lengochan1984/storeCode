/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2005 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/05/27| 新規作成                           | 1.0    | YSK)大山
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.fw.test.telecom;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/**
 * TCP通信テストツール.<br>
 *<br>
 * 概要:<br>
 *   TCP通信のテストを行うためのツール
 *<br>
 */
public class TcpCommTool {

    private static final String encode = "SJIS";

    private static final String zone = "UTC";

    private static final String date_format1 = "yyyyMMddHHmmss";

    private static final String date_format2 = "yyyy/MM/dd HH:mm:ss";

    private static final String stopFilePath = ".\\stop.txt";

    private static final String dataDir = "C:\\MMCloud\\test\\testData\\IT\\data\\";
    //private static final String dataDir = "C:\\MMCloud\\test\\testData\\ST\\data\\1000\\";

    /**
     * @param args
     */
    public void main(final String[] args) {

        System.out.println("Start AP");

        try {
            final List<List<String>> threadList = new ArrayList<List<String>>();
            final List<String> threadDefList = new ArrayList<String>();
            File file = new File(dataDir + args[2]);
            if (file.exists()){
                BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), encode));

                String str;
                List<String> strList = null;
                while((str = br.readLine()) != null){
                    System.out.println(str);

                    int tmp = str.indexOf("threadDef");
                    if (tmp != -1) {
                        // スレッド定義
                        if (strList != null) {
                            threadList.add(strList);
                        }
                        strList = new ArrayList<String>();
                        threadDefList.add(str);
                    } else {
                        strList.add(str);
                    }
                }
                threadList.add(strList);

                br.close();
            }else{
                System.out.println("ファイルが見つからないか開けません");
                return;
            }

            for (int i = 0; i < threadDefList.size(); i++) {
                final int index = i;


                try {
                    String[] tmp = threadDefList.get(index).split(",");

                    final int loopNum = Integer.valueOf(tmp[1]);
                    int startSleep = Integer.valueOf(tmp[2]);
                    final int sendSleep = Integer.valueOf(tmp[3]);

                    int threadNum = 1;
                    try {
                        threadNum = Integer.valueOf(tmp[4]);
                    } catch (Exception e) {
                        // 未定義の場合、スレッド数は1
                        // 未定義の場合、コメントになっているためNumberFormatExceptionが発生
                    }

                    for (int j = 0; j < threadNum; j++) {
                        Thread.sleep(startSleep);

                        new Thread(new Runnable() {

                            @Override
                            public void run() {
                                test(index, threadList.get(index), args, loopNum, sendSleep);
                            }
                        }).start();
                    }

                } catch (Exception e) {

                }

            }
        }
        catch( Exception e ) {
            System.out.println("Exception !!" + e.toString());
        }

        System.out.println("End AP");
    }



    private void test(int _index, List<String> _strList, String[] _args, int _loopNum, int _sendSleep) {

        boolean flag = true;
        int cnt = 1;

        while (flag) {

            try{
                Socket soc = new Socket(_args[0], Integer.valueOf(_args[1]));
                System.out.println("TCP connection ["+_index+"]");

                System.out.println(">>>>>>>>>> Send Command start");
                OutputStream oos = soc.getOutputStream();
                DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(oos));
                for(int i = 0; i < _strList.size(); i++) {
                    String[] strArray = _strList.get(i).split(",");
                    if (strArray[0].equals("dn")) {
                        // 数値の場合
                        String tmp = strArray[1].replace("0x", "");
                        System.out.println(">>>>>>>>>>   data:" + tmp);

                        // バイト配列の要素数分、処理を繰り返す
                        byte[] bytes = new byte[tmp.length() / 2];
                        for (int index = 0; index < bytes.length; index++) {
                            // 16進数文字列をバイトに変換して配列に格納
                            bytes[index] = (byte) Integer.parseInt(tmp.substring(index * 2, (index + 1) * 2), 16);
                        }

                        dos.write(bytes);

                    } else if(strArray[0].equals("ds")){
                        // 文字列の場合
                        dos.writeChars(strArray[1]);

                    } else if(strArray[0].equals("dt7")){
                        // 時間(7byte変換)の場合
                        SimpleDateFormat sdf = new SimpleDateFormat(date_format1);
                        sdf.setTimeZone(TimeZone.getTimeZone(zone));
                        Date date = sdf.parse(strArray[1]);
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(date);
                        int tmp = calendar.get(Calendar.YEAR);
                        dos.writeShort(tmp);
                        tmp = calendar.get(Calendar.MONTH);
                        dos.writeByte(tmp);
                        tmp = calendar.get(Calendar.DAY_OF_MONTH);
                        dos.writeByte(tmp);
                        tmp = calendar.get(Calendar.HOUR_OF_DAY);
                        dos.writeByte(tmp);
                        tmp = calendar.get(Calendar.MINUTE);
                        dos.writeByte(tmp);
                        tmp = calendar.get(Calendar.SECOND);
                        dos.writeByte(tmp);
                    } else if(strArray[0].equals("dt")){
                        // 時間の場合
                        SimpleDateFormat sdf = new SimpleDateFormat(date_format1);
                        sdf.setTimeZone(TimeZone.getTimeZone(zone));
                        Date date = sdf.parse(strArray[1]);
                        long dateTime = date.getTime();
                        System.out.println(">>>>>>>>>>   data[" + i + "] = "+ dateTime + ", " + (int) dateTime + ", " + sdf.format(date));
                        dateTime = dateTime / 1000;
                        date.setTime(dateTime * 1000);
                        System.out.println(">>>>>>>>>>   data[" + i + "] = "+ dateTime + ", " + (int) dateTime + ", " + sdf.format(date));
                        dos.writeInt((int) dateTime);
                    } else if(strArray[0].equals("df")){
                        // ファイルの場合
                        // TODO ファイルの読み込み
                        File file = new File(dataDir + strArray[1]);
                        if (file.exists()){
                            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), encode));

                            String str;
                            while((str = br.readLine()) != null){
                                System.out.println(str);
                                dos.writeChars(str);
                            }

                            br.close();
                        } else {
                            System.out.println("ファイルが存在しません。[" + file.getPath() + "]");
                        }

                    } else if(strArray[0].equals("s")){
                        long waitTime = Long.valueOf(strArray[1]);
                        Thread.sleep(waitTime);
                    }
                    dos.flush();
                }
                System.out.println("<<<<<<<<<< Send Command end");

                Thread.sleep(5000);

                System.out.println("<<<<<<<<<< Send Command end2");

                int idx = 0;
                InputStream is = soc.getInputStream();
                while(true) {
                    int size = is.available();
                    if (size > 0) {
                        System.out.println("=== receive data ====================");
                        DataInputStream dis = new DataInputStream(is);
                        String lineStr = "";
                        for (int i = 0; i < size; i++) {
                            byte readData = dis.readByte();
                            String readDataStr = Integer.toHexString(readData);
                            readDataStr = " " + readDataStr;

                            lineStr += readDataStr;
                            if ((i % 16) == 15) {
                                System.out.println(lineStr);
                                lineStr ="";
                            }

                        }
                        if (lineStr != null && !lineStr.equals("")) {
                            System.out.println(lineStr);
                        }
                        System.out.println("=====================================");
                        break;
                    }

                    // TODO 10秒でタイムアウト
                    if (idx > 20) {
                        break;
                    }
                    Thread.sleep(500);
                    idx++;
                }

//                int startCode = dis.readUnsignedShort();
//                System.out.println("=== header ====================");
//                System.out.println("  start    = " + startCode);
//                int blockNum = dis.readUnsignedShort();
//                System.out.println("  blockNum = " + blockNum);
//                System.out.println("=== block header ==============");
//                for (int j = 0; j < blockNum; j++) {
//                    int commandId = (int) dis.readUnsignedShort();
//                    System.out.println("  commandId = " + commandId);
//                    int dataNum = (int) dis.readUnsignedShort();
//                    System.out.println("  dataNum   = " + dataNum);
//                    long dateTime = dis.readInt();
//                    System.out.println("  date      = " + dateTime * 1000);
//                    Date date = new Date();
//                    date.setTime(dateTime * 1000);
//                    SimpleDateFormat sdf = new SimpleDateFormat(date_format2);
//                    sdf.setTimeZone(TimeZone.getTimeZone(zone));
//                    System.out.println("  date      = " + sdf.format(date));
//                }
//                System.out.println("===============================");

                System.out.println("Receive Command");

                if (soc != null) {
                    try {
                        soc.close();
                    } catch (Exception ex) {
                    }
                }
                System.out.println("TCP close ["+_index+"]");


            } catch (Exception e) {
                System.out.println("Exception !! ["+_index+"] " + e.toString());
                flag = false;
            }


            // 停止ファイルがあれば停止
            File file = new File(stopFilePath);
            if (file.exists()) {
                file.delete();
                flag = false;
            }

            // 規定回数実行したら停止（-1の場合は無限）
            if (_loopNum > 0 && cnt >= _loopNum) {
                flag = false;
            } else {
                cnt++;
            }

            try {
                Thread.sleep(_sendSleep);
            } catch (Exception e) {

            }

        }

    }
}

