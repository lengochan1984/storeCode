/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2005 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/05/27| 新規作成                           | 1.0    | YSK)大山
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.fw.test.telecom;

import static org.junit.Assert.fail;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.junit.Rule;
import org.junit.Test;

/**
 * 通信プロセス IT用テストクラス.<br>
 *<br>
 * 概要:<br>
 *   通信プロセスのIT用テストクラス
 *<br>
 */
public class TelecomITTest {

    /**
     * DB接続先.
     */
    //private static final String CONNECT_STR = "//192.168.131.12:5432/mmcloud";
    //private static final String CONNECT_STR = "//192.168.131.19:5432/mmcloud";
    //private static final String CONNECT_STR = "//172.16.38.200:5432/mmcloud";
    private static final String CONNECT_STR = "//192.168.222.218:5432/mmcloud";

    /**
     * 通信プロセス送信先(IPアドレス).
     */
    //private static final String PROCESS_IP = "133.162.253.112";
    //private static final String PROCESS_IP = "133.162.234.167";
    //private static final String PROCESS_IP = "172.16.38.191";
    private static final String PROCESS_IP = "192.168.222.85";

    /**
     * 通信プロセス送信先(ポート).
     */
    private static final String PROCESS_PORT = "10010";
    //private static final String PROCESS_PORT = "10910";

    /**
     * 接続ユーザ名.
     */
    //private static final String CONNECT_USER = "telecom";
    //private static final String CONNECT_USER = "v301itupte";
    //private static final String CONNECT_USER = "local00002";
    private static final String CONNECT_USER = "local00010";

    /**
     * 接続パスワード.
     */
    //private static final String CONNECT_PASSWORD = "OTqMXojFZxtFHmi3";
    //private static final String CONNECT_PASSWORD = "OTqMXojFZxtFHmi3";
    private static final String CONNECT_PASSWORD = "cHuf5fgu4yLOL5Jn";

    /**
     * 顧客CD.
     */
    //private static final String CUSTOMER_CD = "TELECOM";
    //private static final String CUSTOMER_CD = "V301ITUPTE";
    //private static final String CUSTOMER_CD = "LOCAL00002";
    private static final String CUSTOMER_CD = "LOCAL00010";

    /**
     * DBアクセステスター.
     */
    @Rule
    public DbUnitTester tester = new TelecomITDbUnitTester("fixtures_IT.xml");

    /**
     * データファイル格納場所.
     */
    private static final String DATA_DIR = "C:\\MMCloud\\test\\testData\\IT\\data\\";

    /**
     * データファイル格納場所.
     */
    private static final String FTP_DATA_DIR = "C:\\home\\telecom\\ftp\\LOCAL00010_1\\data\\";

    /**
     * ファイル名(ヘッダ).
     */
    private static final String FILE_HEADER = "testIT";

    /**
     * ファイル名(拡張子).
     */
    private static final String FILE_EXT = ".txt";


    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    @Test
    public void test_通信プロセス() {

        // テストデータ作成
        this.makeTestData();

        String ipAddr = PROCESS_IP;
        String port = PROCESS_PORT;

        TcpCommTool tool = new TcpCommTool();

        try {
            for (int i = 31; i <= 31; i++) {
                List<String> argList = new ArrayList<String>();
                argList.add(ipAddr);
                argList.add(port);
                argList.add(FILE_HEADER + i + FILE_EXT);

                tool.main((String[]) argList.toArray(new String[0]));

                Thread.sleep(1000);
            }

        } catch (Exception e) {

        }
    }

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    public void makeTestData() {

        int commandCd = 1501;
        int idx = 1;

        Calendar calender = Calendar.getInstance();
        String nowDateStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calender.getTime());

        calender.add(Calendar.HOUR, -1);
        String nowDateStr1hourBefore = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calender.getTime());


        // 1
        String dataStr = nowDateStr;
        dataStr += ",11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 2
        dataStr = "2014/05/23 10:00:00";
        dataStr += ",11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 3
        dataStr = "10,11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 4
        calender = Calendar.getInstance();
        calender.add(Calendar.DATE, -30);
        String nowStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calender.getTime());
        dataStr = nowStr + ",11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 5
        calender = Calendar.getInstance();
        calender.add(Calendar.HOUR, 1);
        nowStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calender.getTime());
        dataStr = nowStr + ",11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 6
        calender = Calendar.getInstance();
        calender.add(Calendar.DATE, -31);
        nowStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calender.getTime());
        dataStr = nowStr + ",11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 7
        calender = Calendar.getInstance();
        calender.add(Calendar.HOUR, 2);
        nowStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calender.getTime());
        dataStr = nowStr + ",11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 8
        int tmpCommandCd = commandCd++;
        dataStr = nowDateStr;
        dataStr += ",11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(tmpCommandCd));
        // 8のファイルを9の番号で作成
        dataStr = nowDateStr;
        dataStr += ",111";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(tmpCommandCd));
        commandCd++;
        // 9 テスト除外
//        dataStr = "";
//        dataStr += ",11";
//        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 10 テスト除外
        dataStr = nowDateStr;
        dataStr += ",11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 11
        dataStr = "123";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 12
        dataStr = nowDateStr1hourBefore + ",12\r\n" + nowDateStr + ",22";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 13
        dataStr = "11,12\r21,22\r\n31,32";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 14
        dataStr = "11,12\r21,22\r31,32";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 15
        dataStr = ",12\r\n21,";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 16
        dataStr = "Header1\r\nHeader2\r\n" + nowDateStr1hourBefore + ",12\r\n" + nowDateStr + ",21";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 17
        dataStr = "11,12\r\n21,22";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 18
        dataStr = "11,12";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 19
        dataStr = "#comment\r\n11,12";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 20
        dataStr = "11,12";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 21
        String txt = "";
        txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        txt += "<!-- comment -->";
        txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
        txt += "<group>";
        txt += "<remote>";
        txt += "<ch>";
        txt += "<num>1</num>";
        txt += "<scale_expr></scale_expr>";
        txt += "<name>ondo</name>";
        txt += "<current>";
        txt += "<unix_time>1381124461</unix_time>";
        txt += "<time_str>" + nowDateStr1hourBefore + "</time_str>";
        txt += "<value valid=\"true\">10</value>";
        txt += "<unit>C</unit>";
        txt += "<batt>-1</batt>";
        txt += "</current>";
        txt += "<record>";
        txt += "<type>13</type>";
        txt += "<unix_time>1381120921</unix_time>";
        txt += "<data_id>212</data_id>";
        txt += "<interval>60</interval>";
        txt += "<count>60</count>";
        txt += "<data>";
        txt += "8QTxB";
        txt += "</data>";
        txt += "</record>";
        txt += "</ch>";
        txt += "</remote>";
        txt += "</group>";
        txt += "</file>";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, txt, String.valueOf(commandCd++));
        // 22
        txt = "";
        txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        txt += "<!-- comment -->";
        txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
        txt += "<group>";
        txt += "<remote>";
        txt += "<ch>";
        txt += "<num>1</num>";
        txt += "<scale_expr></scale_expr>";
        txt += "<name>ondo</name>";
        txt += "<current>";
        txt += "<unix_time>1381124461</unix_time>";
        txt += "<time_str>" + nowDateStr1hourBefore + "</time_str>";
        txt += "<value valid1=\"true\">10</value>";
        txt += "<unit>C</unit>";
        txt += "<batt>-1</batt>";
        txt += "</current>";
        txt += "<record>";
        txt += "<type>13</type>";
        txt += "<unix_time>1381120921</unix_time>";
        txt += "<data_id>212</data_id>";
        txt += "<interval>60</interval>";
        txt += "<count>60</count>";
        txt += "<data>";
        txt += "8QTxB";
        txt += "</data>";
        txt += "</record>";
        txt += "</ch>";
        txt += "</remote>";
        txt += "</group>";
        txt += "</file>";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, txt, String.valueOf(commandCd++));
        // 23
        txt = "";
        txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        txt += "<!-- comment -->";
        txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
        txt += "<group>";
        txt += "<remote>";
        txt += "<ch>";
        txt += "<num>1</num>";
        txt += "<scale_expr></scale_expr>";
        txt += "<name>ondo</name>";
        txt += "<current>";
        txt += "<unix_time>1381124461</unix_time>";
        txt += "<time_str>" + nowDateStr1hourBefore + "</time_str>";
        txt += "<value valid=\"true\">10</value>";
        txt += "<unit>C</unit>";
        txt += "<batt>-1</batt>";
        txt += "</current>";
        txt += "<record>";
        txt += "<type>13</type>";
        txt += "<unix_time>1381120921</unix_time>";
        txt += "<data_id>212</data_id>";
        txt += "<interval>60</interval>";
        txt += "<count>60</count>";
        txt += "<data>";
        txt += "8QTxB";
        txt += "</data>";
        txt += "</record>";
        txt += "</ch>";
        txt += "</remote>";
        txt += "</group>";
        txt += "<group>";
        txt += "<remote>";
        txt += "<ch>";
        txt += "<num>1</num>";
        txt += "<scale_expr></scale_expr>";
        txt += "<name>ondo</name>";
        txt += "<current>";
        txt += "<unix_time>1381124461</unix_time>";
        txt += "<time_str>" + nowDateStr + "</time_str>";
        txt += "<value valid=\"true\">11</value>";
        txt += "<unit>C</unit>";
        txt += "<batt>-1</batt>";
        txt += "</current>";
        txt += "<record>";
        txt += "<type>13</type>";
        txt += "<unix_time>1381120921</unix_time>";
        txt += "<data_id>212</data_id>";
        txt += "<interval>60</interval>";
        txt += "<count>60</count>";
        txt += "<data>";
        txt += "8QTxB";
        txt += "</data>";
        txt += "</record>";
        txt += "</ch>";
        txt += "</remote>";
        txt += "</group>";
        txt += "</file>";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, txt, String.valueOf(commandCd++));
        // 24
        txt = "";
        txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        txt += "<!-- comment -->";
        txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
        // 存在しない繰り返し
        txt += "<group1>";
        txt += "<remote>";
        txt += "<ch>";
        txt += "<num>1</num>";
        txt += "<scale_expr></scale_expr>";
        txt += "<name>ondo</name>";
        txt += "<current>";
        txt += "<unix_time>1381124461</unix_time>";
        txt += "<time_str>" + nowDateStr1hourBefore + "</time_str>";
        txt += "<value valid=\"true\">10</value>";
        txt += "<unit>C</unit>";
        txt += "<batt>-1</batt>";
        txt += "</current>";
        txt += "<record>";
        txt += "<type>13</type>";
        txt += "<unix_time>1381120921</unix_time>";
        txt += "<data_id>212</data_id>";
        txt += "<interval>60</interval>";
        txt += "<count>60</count>";
        txt += "<data>";
        txt += "8QTxB";
        txt += "</data>";
        txt += "</record>";
        txt += "</ch>";
        txt += "</remote>";
        txt += "</group1>";
        txt += "<group1>";
        txt += "<remote>";
        txt += "<ch>";
        txt += "<num>1</num>";
        txt += "<scale_expr></scale_expr>";
        txt += "<name>ondo</name>";
        txt += "<current>";
        txt += "<unix_time>1381124461</unix_time>";
        txt += "<time_str>" + nowDateStr1hourBefore + "</time_str>";
        txt += "<value valid=\"true\">11</value>";
        txt += "<unit>C</unit>";
        txt += "<batt>-1</batt>";
        txt += "</current>";
        txt += "<record>";
        txt += "<type>13</type>";
        txt += "<unix_time>1381120921</unix_time>";
        txt += "<data_id>212</data_id>";
        txt += "<interval>60</interval>";
        txt += "<count>60</count>";
        txt += "<data>";
        txt += "8QTxB";
        txt += "</data>";
        txt += "</record>";
        txt += "</ch>";
        txt += "</remote>";
        txt += "</group1>";
        txt += "</file>";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, txt, String.valueOf(commandCd++));
        // 25
        txt = "";
        txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        txt += "<!-- comment -->";
        txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
        txt += "<group>";
        txt += "<remote>";
        txt += "<ch>";
        txt += "<num>1</num>";
        txt += "<scale_expr></scale_expr>";
        txt += "<name>ondo</name>";
        txt += "<current>";
        txt += "<unix_time>1381124461</unix_time>";
        txt += "<time_str>" + nowDateStr1hourBefore + "</time_str>";
        txt += "<value valid=\"true\">10</value>";
        txt += "<unit>C</unit>";
        txt += "<batt>-1</batt>";
        txt += "</current>";
        txt += "<record>";
        txt += "<type>13</type>";
        txt += "<unix_time>1381120921</unix_time>";
        txt += "<data_id>212</data_id>";
        txt += "<interval>60</interval>";
        txt += "<count>60</count>";
        txt += "<data>";
        txt += "8QTxB";
        txt += "</data>";
        txt += "</record>";
        txt += "</ch>";
        txt += "</remote>";
        txt += "</group>";
        txt += "</file>";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, txt, String.valueOf(commandCd++));
        // 26
        txt = "";
        txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        txt += "<!-- comment -->";
        txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
        txt += "<group>";
        txt += "<remote>";
        txt += "<ch>";
        txt += "<num>1</num>";
        txt += "<scale_expr></scale_expr>";
        txt += "<name>ondo</name>";
        txt += "<current>";
        txt += "<unix_time>1381124461</unix_time>";
        txt += "<time_str>" + nowDateStr1hourBefore + "</time_str>";
        // 禁則文字
        txt += "<value valid=\"true\">&</value>";
        txt += "<unit>C</unit>";
        txt += "<batt>-1</batt>";
        txt += "</current>";
        txt += "<record>";
        txt += "<type>13</type>";
        txt += "<unix_time>1381120921</unix_time>";
        txt += "<data_id>212</data_id>";
        txt += "<interval>60</interval>";
        txt += "<count>60</count>";
        txt += "<data>";
        txt += "8QTxB";
        txt += "</data>";
        txt += "</record>";
        txt += "</ch>";
        txt += "</remote>";
        txt += "</group>";
        txt += "</file>";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, txt, String.valueOf(commandCd++));
        // 27
        txt = "";
        txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        txt += "<!-- comment -->";
        txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
        txt += "<group>";
        txt += "<remote>";
        txt += "<ch>";
        txt += "<num>1</num>";
        txt += "<scale_expr></scale_expr>";
        txt += "<name>ondo</name>";
        txt += "<current>";
        txt += "<unix_time>1381124461</unix_time>";
        txt += "<time_str>" + nowDateStr1hourBefore + "</time_str>";
        // XPathが存在しない
        txt += "<value valid1=\"true\">10</value>";
        txt += "<unit>C</unit>";
        txt += "<batt>-1</batt>";
        txt += "</current>";
        txt += "<record>";
        txt += "<type>13</type>";
        txt += "<unix_time>1381120921</unix_time>";
        txt += "<data_id>212</data_id>";
        txt += "<interval>60</interval>";
        txt += "<count>60</count>";
        txt += "<data>";
        txt += "8QTxB";
        txt += "</data>";
        txt += "</record>";
        txt += "</ch>";
        txt += "</remote>";
        txt += "</group>";
        txt += "<group>";
        txt += "<remote>";
        txt += "<ch>";
        txt += "<num>1</num>";
        txt += "<scale_expr></scale_expr>";
        txt += "<name>ondo</name>";
        txt += "<current>";
        txt += "<unix_time>1381124461</unix_time>";
        txt += "<time_str>" + nowDateStr1hourBefore + "</time_str>";
        txt += "<value valid=\"true\">11</value>";
        txt += "<unit>C</unit>";
        txt += "<batt>-1</batt>";
        txt += "</current>";
        txt += "<record>";
        txt += "<type>13</type>";
        txt += "<unix_time>1381120921</unix_time>";
        txt += "<data_id>212</data_id>";
        txt += "<interval>60</interval>";
        txt += "<count>60</count>";
        txt += "<data>";
        txt += "8QTxB";
        txt += "</data>";
        txt += "</record>";
        txt += "</ch>";
        txt += "</remote>";
        txt += "</group>";
        txt += "</file>";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, txt, String.valueOf(commandCd++));

        // 28
        byte[] data1 = {11, 12};
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data1, String.valueOf(commandCd++));
        // 29
        byte[] data2 = {11, 12, 13};
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data2, String.valueOf(commandCd++));

        // 30
        dataStr = "filedatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledata";
        this.outputFTPFile("device001.2000.01.doc", dataStr);
        idx++;
        commandCd++;
        // 31
        dataStr = "filedatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledatafiledata";
        this.outputFileAddOneByte(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(2001), "UTF-8");
        commandCd++;

        // ************************** 削除予定　start *************************************************************
        // 32 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 33 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 34 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 35 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 36 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 37 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 38 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 39 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 40 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 41 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));

        // ************************** 削除予定　end *************************************************************

        // 30
        // 42
        dataStr = "2147483649";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 31
        // 43
        dataStr = "-2147483648";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 32
        // 44
        dataStr = "2147483647";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 33
        // 45
        dataStr = "2147483648";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 34
        // 46
        dataStr = "ABC";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 35
        // 47
        dataStr = "-9999999999.999996";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 36
        // 48
        dataStr = "-9999999999.999986";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 37
        // 49
        dataStr = "-10000000000.00000";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 38
        // 50
        dataStr = "-9999999999.99999";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 39
        // 51
        dataStr = "9999999999.999996";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 40
        // 52
        dataStr = "9999999999.999986";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 41
        // 53
        dataStr = "10000000000.00000";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 42
        // 54
        dataStr = "9999999999.99999";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));

        // ************************** 削除予定　start *************************************************************

        // 55
        dataStr = "2014/03/28 00:00:00.000";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 56
        dataStr = "Friday, 28, Mar, 14 2:48:13 PM";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));

        // ************************** 削除予定　end *************************************************************

        // 43
        // 57
        dataStr = "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあい";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++), "Shift-JIS");
        // 44
        // 58
        dataStr = "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいう";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++), "Shift-JIS");
        // 45
        // 59
        dataStr = "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあい";
//        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
//        dataStr += "あい";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 46
        // 60
        dataStr = "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえおあいうえお";
        dataStr += "あいう";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 47
        // 61
        dataStr = "-13.16358,-72.54586";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 48
        // 62
        dataStr = "-13.16358°,-72.54586";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 49
        // 63
        dataStr = "13.16358S,72.54586W";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 50
        // 64
        dataStr = "-13.16358,-72.54586";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 51
        // 65
        dataStr = "13.16358,S,72.54586,W";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 52
        // 66
        dataStr = "-13.16358,S,72.54586,W";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 53
        // 67
        dataStr = "1309.81522S,07232.75166W";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 54
        // 68
        dataStr = "-13.16358,-72.54586";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 55
        // 69
        dataStr = "1309.81522S,7232.75166W";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 56
        // 70
        dataStr = "1309.81522,S,07232.75166,W";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 57
        // 71
        dataStr = "1309.81522,S,-07232.75166,W";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 58
        // 72
        dataStr = "1309.81522,S,7232.75166,W";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 59
        // 73
        dataStr = "13,09,48.9126,S,72,32,45.0996,W";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 60
        // 74
        dataStr = "1309.81522,S,07232.75166,W";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 61
        // 75
        dataStr = "13,09,48.9126,S,72,32,45.0996,W";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 62
        // 76
        dataStr = "1309.81522,S,07232.75166,W";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 63
        // 77
        dataStr = "-13°09'48.9126\",-72°32'45.0996";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 64
        // 78
        dataStr = "13,09,48.9126,S,72,32,45.0996,W";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 65
        // 79
        dataStr = "0";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 66
        // 80
        dataStr = "1";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 67
        // 81
        dataStr = "-1";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 68
        // 82
        dataStr = "2";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));

        // ************************** 削除予定　start *************************************************************

        // 83 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 84 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 85 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 86 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 87 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 88 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 89 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 90 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 91 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));

        // ************************** 削除予定　end *************************************************************

        // 69
        // 92
        dataStr = "1234567890";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 70
        // 93
        dataStr = "ABCDEFGHIJ";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 71
        // 94
        dataStr = "1234567890A";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));
        // 81
        // 95
        dataStr = "12";
        this.outputFTPFile("device001.1595.xml", dataStr);
        commandCd++;
        // 82
        // 96
        dataStr = "12";
        this.outputFTPFile("device001.1596.2014-Mar-3-00001.xml", dataStr);
        commandCd++;
        // 83
        // 97
        dataStr = "12";
        this.outputFTPFile("device001.xml", dataStr);
        commandCd++;
        // **
        // 98
        dataStr = "12";
        this.outputFTPFile("device001.1598.2014.03.3.00001.xml", dataStr);
        commandCd++;
        // 84
        // 99
        dataStr = "12";
        this.outputFTPFile("Device001.1599.Capital.xml", dataStr);
        commandCd++;
        // 85
        // 100
        dataStr = "12";
        this.outputFTPFile("device001.9999.xml", dataStr);
        commandCd++;

        // ************************** 削除予定　start *************************************************************

        // 101
        dataStr = "12";
        this.outputFTPFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr);
        commandCd++;
        // 102
        dataStr = "12";
        this.outputFTPFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr);
        commandCd++;
        // 103
        dataStr = "12";
        this.outputFTPFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr);
        commandCd++;
        // 104 テスト除外
        dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));

        // ************************** 削除予定　end *************************************************************

        // 86
        // 105
        dataStr = "11,12.3,2014-05-27 11:00:00,test1,,1,event1,56,789,";
        dataStr += "21,22.4,2014-05-27 12:00:00,test2,,0,event2,57,790,";
        dataStr += "31,32.5,2014-05-27 13:00:00,test3,,1,event3,58,791,";
        dataStr += "41,42.6,2014-05-27 14:00:00,test4,,0,event4,59";
        this.outputFTPFile("device001.1605.csv", dataStr);
        // 87
        // 106
        dataStr = "11";
        this.outputFTPFile("device001.1606.xml", dataStr);
        // 88
        // 107
        txt = "";
        txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        txt += "<!-- comment -->";
        txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
        txt += "<group>";
        txt += "<remote>";
        txt += "<ch>";
        txt += "<num>1</num>";
        txt += "<scale_expr></scale_expr>";
        txt += "<name>ondo</name>";
        txt += "<current>";
        txt += "<unix_time>1381124461</unix_time>";
        txt += "<time_str>" + nowDateStr1hourBefore + "</time_str>";
        txt += "<value valid=\"true\">10</value>";
        txt += "<unit>C</unit>";
        txt += "<batt>-1</batt>";
        txt += "</current>";
        txt += "<record>";
        txt += "<type>13</type>";
        txt += "<unix_time>1381120921</unix_time>";
        txt += "<data_id>212</data_id>";
        txt += "<interval>60</interval>";
        txt += "<count>60</count>";
        txt += "<data>";
        txt += "8QTxB";
        txt += "</data>";
        txt += "</record>";
        txt += "</ch>";
        txt += "</remote>";
        txt += "</group>";
        txt += "<group>";
        txt += "<remote>";
        txt += "<ch>";
        txt += "<num>1</num>";
        txt += "<scale_expr></scale_expr>";
        txt += "<name>ondo</name>";
        txt += "<current>";
        txt += "<unix_time>1381124461</unix_time>";
        txt += "<time_str>" + nowDateStr + "</time_str>";
        txt += "<value valid=\"true\">11</value>";
        txt += "<unit>C</unit>";
        txt += "<batt>-1</batt>";
        txt += "</current>";
        txt += "<record>";
        txt += "<type>13</type>";
        txt += "<unix_time>1381120921</unix_time>";
        txt += "<data_id>212</data_id>";
        txt += "<interval>60</interval>";
        txt += "<count>60</count>";
        txt += "<data>";
        txt += "8QTxB";
        txt += "</data>";
        txt += "</record>";
        txt += "</ch>";
        txt += "</remote>";
        txt += "</group>";
        txt += "</file>";
        this.outputFTPFile("device001.1607.xml", txt);
        // 89
        // 108
        byte[] data108 = {11, 1, 12, 0};
        this.outputFTPFile("device001.1608.xml", data108);
        // 90
        // 109
        dataStr = "document";
        this.outputFTPFile("device001.2000.doc", dataStr);

        // ************************** 削除予定　start *************************************************************

        // 110(109-112)
        dataStr = "11,12";
        for (int i = 1; i <= 21; i++) {
            this.outputFTPFile("device001.1610" + String.format("%1$02d", i) + ".xml", dataStr);
        }

        // 113(113-114)
        dataStr = "11,12";
        this.outputFTPFile("device001.1613.01.xml", dataStr);

        // 115
        dataStr = "11,12\r\n21,22\r\n31,32";
        this.outputFTPFile("device001.1615.01.xml", dataStr);
        // 116
        dataStr = "11,12\r\n21\r\n31,32";
        this.outputFTPFile("device001.1616.01.xml", dataStr);

        // 118(117-120)
        dataStr = "";
        idx = 118;
        this.outputFile(FILE_HEADER + String.valueOf(idx) + FILE_EXT, dataStr, "0001");

        // ************************** 削除予定　end *************************************************************

        // 100-101
        // 121
        dataStr = "12";
        idx = 121;
        this.outputFileVariableHeader(
                FILE_HEADER + String.valueOf(idx) + FILE_EXT,
                dataStr,
                "01",
                CUSTOMER_CD,
                "32613C4EB605",
                "1621",
                "UTF-8");
        // 102
        // 122
        dataStr = "12";
        idx = 122;
        this.outputFileVariableHeader(
                FILE_HEADER + String.valueOf(idx) + FILE_EXT,
                dataStr,
                "01",
                CUSTOMER_CD,
                "1212345612345612",
                "1622",
                "UTF-8");

        // 103-104
        // 124(123-124)
        dataStr = "12";
        idx = 124;
        this.outputFileVariableHeader(
                FILE_HEADER + String.valueOf(idx) + FILE_EXT,
                dataStr,
                "01",
                CUSTOMER_CD,
                "MY-DEVICE-5793208453",
                "1624",
                "UTF-8");
        // 105
        // 125
        dataStr = "12";
        idx = 125;
        this.outputFileVariableHeader(
                FILE_HEADER + String.valueOf(idx) + FILE_EXT,
                dataStr,
                "03",
                CUSTOMER_CD,
                "MY-DEVICE-5793208453",
                "1625",
                "UTF-8");
        // 106
        // 126
        dataStr = "12";
        idx = 126;
        this.outputFileVariableHeader(
                FILE_HEADER + String.valueOf(idx) + FILE_EXT,
                dataStr,
                "01",
                "invalid1",
                "MY-DEVICE-5793208453",
                "1626",
                "UTF-8");
        // 107
        // 127
        dataStr = "12";
        idx = 127;
        this.outputFileVariableHeader(
                FILE_HEADER + String.valueOf(idx) + FILE_EXT,
                dataStr,
                "01",
                CUSTOMER_CD,
                "InvalidDevice001",
                "1627",
                "UTF-8");
        // 108
        // 128
        dataStr = "12";
        idx = 128;
        this.outputFileVariableHeader(
                FILE_HEADER + String.valueOf(idx) + FILE_EXT,
                dataStr,
                "01",
                CUSTOMER_CD,
                "MY-DEVICE-5793208453",
                "9999",
                "UTF-8");
        // 109
        // 129
        dataStr = "12";
        idx = 129;
        this.outputFileVariableHeader(
                FILE_HEADER + String.valueOf(idx) + FILE_EXT,
                dataStr,
                "01",
                CUSTOMER_CD,
                "MY-DEVICE-5793208453",
                "1621",
                "UTF-8",
                100);
        // 110
        // 130
        dataStr = "12";
        idx = 130;
        this.outputFileVariableHeader(
                FILE_HEADER + String.valueOf(idx) + FILE_EXT,
                dataStr,
                "02",
                "invalid1",
                "MY-DEVICE-5793208453",
                "1630",
                "UTF-8");
        // 111
        // 131
        dataStr = "12";
        idx = 131;
        this.outputFileVariableHeader(
                FILE_HEADER + String.valueOf(idx) + FILE_EXT,
                dataStr,
                "01",
                CUSTOMER_CD,
                "MY-DEVICE-5793208453",
                "9999",
                "UTF-8");
        // 112
        // 132
        dataStr = "12";
        idx = 132;
        this.outputFileVariableHeader(
                FILE_HEADER + String.valueOf(idx) + FILE_EXT,
                dataStr,
                "01",
                CUSTOMER_CD,
                "MY-DEVICE-5793208453",
                "1621",
                "UTF-8",
                100);

        // 113
        // 137
        idx = 137;
        dataStr = "<file>";
        dataStr += "<group>";
        dataStr += "<record>";
        dataStr += "<data1>";
        dataStr += "11";
        dataStr += "</data1>";
        dataStr += "<data2>";
        dataStr += "12.3";
        dataStr += "</data2>";
        dataStr += "<data3>";
        dataStr += "2014-05-27 11:00:00";
        dataStr += "</data3>";
        dataStr += "<data4>";
        dataStr += "test";
        dataStr += "</data4>";
        dataStr += "<data5>";
        dataStr += "-11.16358,-71.54586";
        dataStr += "</data5>";
        dataStr += "<data6>";
        dataStr += "1";
        dataStr += "</data6>";
        dataStr += "<data7>";
        dataStr += "10";
        dataStr += "</data7>";
        dataStr += "<data8>";
        dataStr += "event1";
        dataStr += "</data8>";
        dataStr += "<data9>";
        dataStr += "512";
        dataStr += "</data9>";
        dataStr += "<data10>";
        dataStr += "11";
        dataStr += "</data10>";
        dataStr += "<data11>";
        dataStr += "12.3";
        dataStr += "</data11>";
        dataStr += "<data12>";
        dataStr += "2014-05-27 11:00:00";
        dataStr += "</data12>";
        dataStr += "<data13>";
        dataStr += "test";
        dataStr += "</data13>";
        dataStr += "<data14>";
        dataStr += "-11.16358,-71.54586";
        dataStr += "</data14>";
        dataStr += "<data15>";
        dataStr += "1";
        dataStr += "</data15>";
        dataStr += "<data16>";
        dataStr += "10";
        dataStr += "</data16>";
        dataStr += "<data17>";
        dataStr += "event1";
        dataStr += "</data17>";
        dataStr += "<data18>";
        dataStr += "256";
        dataStr += "</data18>";
        dataStr += "<data19>";
        dataStr += "11";
        dataStr += "</data19>";
        dataStr += "<data20>";
        dataStr += "12.3";
        dataStr += "</data20>";
        dataStr += "<data21>";
        dataStr += "2014-05-27 11:00:00";
        dataStr += "</data21>";
        dataStr += "<data22>";
        dataStr += "test";
        dataStr += "</data22>";
        dataStr += "<data23>";
        dataStr += "-11.16358,-71.54586";
        dataStr += "</data23>";
        dataStr += "<data24>";
        dataStr += "1";
        dataStr += "</data24>";
        dataStr += "<data25>";
        dataStr += "10";
        dataStr += "</data25>";
        dataStr += "<data26>";
        dataStr += "event1";
        dataStr += "</data26>";
        dataStr += "<data27>";
        dataStr += "128";
        dataStr += "</data27>";
        dataStr += "<data28>";
        dataStr += "11";
        dataStr += "</data28>";
        dataStr += "<data29>";
        dataStr += "12.3";
        dataStr += "</data29>";
        dataStr += "<data30>";
        dataStr += "2014-05-27 11:00:00";
        dataStr += "</data30>";
        dataStr += "<data31>";
        dataStr += "test";
        dataStr += "</data31>";
        dataStr += "<data32>";
        dataStr += "-11.16358,-71.54586";
        dataStr += "</data32>";
        dataStr += "<data33>";
        dataStr += "1";
        dataStr += "</data33>";
        dataStr += "<data34>";
        dataStr += "10";
        dataStr += "</data34>";
        dataStr += "<data35>";
        dataStr += "event1";
        dataStr += "</data35>";
        dataStr += "<data36>";
        dataStr += "64";
        dataStr += "</data36>";
        dataStr += "<data37>";
        dataStr += "11";
        dataStr += "</data37>";
        dataStr += "<data38>";
        dataStr += "12.3";
        dataStr += "</data38>";
        dataStr += "<data39>";
        dataStr += "2014-05-27 11:00:00";
        dataStr += "</data39>";
        dataStr += "<data40>";
        dataStr += "test";
        dataStr += "</data40>";
        dataStr += "</record>";
        dataStr += "</group>";
        dataStr += "</file>";

//        dataStr = "11,12.3,2014-05-27 11:00:00,test,-11.16358, -71.54586,1,10,event1";
//        dataStr += "21,22.3,2014-05-27 12:00:00,test,-12.16358, -72.54586,0,11,event2";
//        dataStr += "31,32.3,2014-05-27 10:00:00,test,-13.16358, -73.54586,1,12,event3";
//        dataStr += "41,42.3,2014-05-27 10:00:00,test,-14.16358, -74.54586,0,13,event4";
//        dataStr += "51,52.3,2014-05-27 10:00:00,test,-15.16358, -75.54586,1,14,event5";
        this.outputFile(FILE_HEADER + "137" + FILE_EXT, dataStr, "1637");

        // 114-115
        // 139
        dataStr = "";
        this.outputFile(FILE_HEADER + "139" + FILE_EXT, dataStr, "0001");
        // 116
        // 140
        dataStr = "";
        this.outputFile(FILE_HEADER + "140" + FILE_EXT, dataStr, "0002");
        // 117
        // 141
        dataStr = "12";
        this.outputFile(FILE_HEADER + "141" + FILE_EXT, dataStr, "0999");

        // 118
        // 142
        dataStr = "12";
        this.outputFile(FILE_HEADER + "142" + FILE_EXT, dataStr, "1000");
        // 119
        // 143
        dataStr = "12";
        this.outputFile(FILE_HEADER + "143" + FILE_EXT, dataStr, "1FFF");
        // 144
        dataStr = "12";
        this.outputFile(FILE_HEADER + "144" + FILE_EXT, dataStr, "2000");

        // 72
        // 145
        dataStr = "1,2,3,4";
        this.outputFile(FILE_HEADER + "145" + FILE_EXT, dataStr, "1F72");
        // 73
        // 146
        dataStr = "1,2,0,4";
        this.outputFile(FILE_HEADER + "146" + FILE_EXT, dataStr, "1F73");
        // 74
        // 147
        dataStr = "4";
        this.outputFile(FILE_HEADER + "147" + FILE_EXT, dataStr, "1F74");
        // 75
        // 148
        dataStr = "4";
        this.outputFile(FILE_HEADER + "148" + FILE_EXT, dataStr, "1F75");

        // 90
        // 149
        dataStr = "4";
        this.outputFile(FILE_HEADER + "149" + FILE_EXT, dataStr, "1F76");
        // 150
        dataStr = "6";
        this.outputFile(FILE_HEADER + "150" + FILE_EXT, dataStr, "1F76");

        // 91
        // 151
        dataStr = "4";
        this.outputFile(FILE_HEADER + "151" + FILE_EXT, dataStr, "1F77");
        // 152
        dataStr = "6";
        this.outputFile(FILE_HEADER + "152" + FILE_EXT, dataStr, "1F77");

        // 92
        // 153
        dataStr = "4";
        this.outputFile(FILE_HEADER + "153" + FILE_EXT, dataStr, "1F78");
        // 154
        dataStr = "6";
        this.outputFile(FILE_HEADER + "154" + FILE_EXT, dataStr, "1F79");

        // 93
        // 155
        dataStr = "4";
        this.outputFile(FILE_HEADER + "155" + FILE_EXT, dataStr, "1F79");
        // 156
        dataStr = "6";
        this.outputFileVariableHeader(FILE_HEADER + "156" + FILE_EXT, dataStr, "01",CUSTOMER_CD,
                "device002", "1F79", "UTF-8");

        // 94
        // 157
        dataStr = "4";
        this.outputFile(FILE_HEADER + "157" + FILE_EXT, dataStr, "1F80");
        // 158
        dataStr = "6";
        this.outputFileVariableHeader(FILE_HEADER + "158" + FILE_EXT, dataStr, "01",CUSTOMER_CD,
                "device002", "1F81", "UTF-8");

        // 76
        // 159
        dataStr = "4294967296";
        this.outputFile(FILE_HEADER + "159" + FILE_EXT, dataStr, "1F82");

        // 77
        // 160
        dataStr = "4294967295";
        this.outputFile(FILE_HEADER + "160" + FILE_EXT, dataStr, "1F83");

        // 78
        // 161
        dataStr = "0";
        this.outputFile(FILE_HEADER + "161" + FILE_EXT, dataStr, "1F84");

        // 79
        // 162
        dataStr = "0";
        this.outputFileAddOneByte(FILE_HEADER + "162" + FILE_EXT, dataStr, "1F85", "UTF-8");

        // 80
        // 163
        dataStr = "ABC";
        this.outputFile(FILE_HEADER + "163" + FILE_EXT, dataStr, "1F86");

    }

    private void outputFile(final String _filePath, final String _data, final String _commandCd) {
        this.outputFile(_filePath, _data, _commandCd, "UTF-8");
    }

    private void outputFile(final String _filePath, final String _data, final String _commandCd, final String _encode) {

        try {
            // ファイル出力
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print("01");
            // 顧客CD
            pw.print(this.formatStr(CUSTOMER_CD, 10, "ASCII"));
            // 機器ID
            pw.print(this.formatStr("device001", 20, "ASCII"));
            // コマンドコード
            pw.print(_commandCd);
            // データサイズ
            int length = _data.length();
            if (_data.getBytes(_encode).length > length) {
                length = _data.getBytes(_encode).length;
            }
            pw.print(String.format("%1$08X", length));
            // 予備
            pw.print("00000000000000000000000000");
            // データ
            pw.print(this.formatStr(_data, _data.length(), _encode));

            pw.close();

        } catch (Exception e) {

        }
    }

    private void outputFileAddOneByte(final String _filePath, final String _data, final String _commandCd, final String _encode) {

        try {
            // ファイル出力
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print("01");
            // 顧客CD
            pw.print(this.formatStr(CUSTOMER_CD, 10, "ASCII"));
            // 機器ID
            pw.print(this.formatStr("device001", 20, "ASCII"));
            // コマンドコード
            pw.print(_commandCd);
            // データサイズ
            int length = _data.length();
            if (_data.getBytes(_encode).length > length) {
                length = _data.getBytes(_encode).length;
            }
            pw.print(String.format("%1$08X", length + 1));
            // 予備
            pw.print("00000000000000000000000000");
            // データ
            pw.print(this.formatStr(_data, _data.length(), _encode) + this.formatStr("00", "00".length(), _encode));

            pw.close();

        } catch (Exception e) {

        }
    }

    private void outputFileVariableHeader(
            final String _filePath,
            final String _data,
            final String _protocolVer,
            final String _companyID,
            final String _deviceID,
            final String _commandCd,
            final String _encode) {

        this.outputFileVariableHeader(
                _filePath,
                _data,
                _protocolVer,
                _companyID,
                _deviceID,
                _commandCd,
                _encode,
                0);

    }

    private void outputFileVariableHeader(
            final String _filePath,
            final String _data,
            final String _protocolVer,
            final String _companyID,
            final String _deviceID,
            final String _commandCd,
            final String _encode,
            final int _size) {

        try {
            // ファイル出力
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print(_protocolVer);
            // 顧客CD
            pw.print(this.formatStr(_companyID, 10, "ASCII"));

            if ("01".equals(_protocolVer)) {
                // プロトコルバージョン 1 の場合

                // 機器ID
                pw.print(this.formatStr(_deviceID, 20, "ASCII"));
                // コマンドコード
                pw.print(_commandCd);
                // データサイズ
                int length = 0;
                if (_size != 0) {
                    length = _size;
                } else {
                    length = _data.length();
                    if (_data.getBytes(_encode).length > length) {
                        length = _data.getBytes(_encode).length;
                    }
                }
                pw.print(String.format("%1$08X", length));
                // 予備
                pw.print("00000000000000000000000000");

            } else {
                // プロトコルバージョン 2 の場合

                // コマンドコード
                pw.print(_commandCd);
                // データサイズ
                int length = 0;
                if (_size != 0) {
                    length = _size;
                } else {
                    length = _data.length();
                    if (_data.getBytes(_encode).length > length) {
                        length = _data.getBytes(_encode).length;
                    }
                }
                pw.print(String.format("%1$013X", length));
                // 予備
                pw.print("00000000000000000000000000");
            }

            // データ
            pw.print(this.formatStr(_data, _data.length(), _encode));

            pw.close();

        } catch (Exception e) {

        }
    }

    private void outputFileFix(final String _filePath, final byte[] _data, final String _commandCd) {

        try {
            // ファイル出力(fix)
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print("01");
            // 顧客CD
            pw.print(this.formatStr(CUSTOMER_CD, 10, "ASCII"));
            // 機器ID
            pw.print(this.formatStr("device001", 20, "ASCII"));
            // コマンドコード
            pw.print(_commandCd);
            // データサイズ
            int length = _data.length;
            pw.print(String.format("%1$08X", length));
            // 予備
            pw.print("00000000000000000000000000");
            // データ
            for (int i = 0; i < length; i++) {
                pw.print(String.format("%1$02X", _data[i]));
            }

            pw.close();

        } catch (Exception e) {

        }
    }

    private String formatStr(final String _dataStr, final int _length, final String _format) {

        String retStr = "";
        try {
            byte[] data = _dataStr.getBytes(_format);
            int length = _length;
            if (data.length > _length) {
                length = data.length;
            }
            for (int i = 0; i < length; i++) {
                if (i >= data.length) {
                    retStr += "00";
                } else {
                    retStr += String.format("%1$02X", data[i]);
                }
            }
        } catch (Exception e) {

        }

        return retStr;
    }

    private void outputFTPFile(final String _filePath, final String _str) {
        try {
            this.outputFTPFile(_filePath, _str.getBytes("UTF-8"));

        } catch (Exception e) {
            fail("例外が発生しました。");
        }
    }

    private void outputFTPFile(final String _filePath, final byte[] _data) {

        try {
            // ファイル出力
            FileOutputStream fos = new FileOutputStream(_filePath);
            fos.write(_data);
            fos.close();

        } catch (Exception e) {
            fail("例外が発生しました。");
        }
    }

    /**
    *
    * IT DBアクセステスター.<br>
    *<br>
    * 概要:<br>
    *   テストデータ作成用のDBアクセステスター
    *<br>
    */
    static class TelecomITDbUnitTester extends DbUnitTester {
        /**
         * 初期値用データファイル.
         */
        private final String fixture;

        /**
         *
         * コンストラクタ.
         *
         * @param _fixture 初期値用データファイル名
         */
        public TelecomITDbUnitTester(final String _fixture) {
            super("org.postgresql.Driver",
                    "jdbc:postgresql:" + CONNECT_STR, CONNECT_USER, CONNECT_PASSWORD, CONNECT_USER);
            this.fixture = _fixture;
        }

        /* (非 Javadoc)
         * @see jp.ysk.mmcloud.DbUnitTester#before()
         */
        @Override
        protected void before() throws Exception {
            // 初期化前のデータ削除処理
            executeQuery("delete from mst_device");
            executeQuery("delete from rel_device_group");
            executeQuery("delete from mst_command");
            executeQuery("delete from mst_data_point_position_xml");
            executeQuery("delete from mst_data_point_position_csv");
            executeQuery("delete from mst_data_point_position_fix");
            executeQuery("delete from mst_datetime");
            executeQuery("delete from mst_data_point_calc");
            executeQuery("delete from mst_data_point");
            executeQuery("delete from tbl_data_point_data_bit");
            executeQuery("delete from tbl_data_point_data_date");
            executeQuery("delete from tbl_data_point_data_decimal");
            executeQuery("delete from tbl_data_point_data_event");
            executeQuery("delete from tbl_data_point_data_file");
            executeQuery("delete from tbl_data_point_data_point");
            executeQuery("delete from tbl_data_point_data_text");
            executeQuery("delete from tbl_data_point_data_uint");
            executeQuery("delete from tbl_data_point_data_word");
        }

        /* (非 Javadoc)
         * @see jp.ysk.mmcloud.DbUnitTester#createDataset()
         */
        @Override
        protected IDataSet createDataset() throws Exception {
            // 初期化処理(データファイルから読み込む)
            return new FlatXmlDataSetBuilder().build(getClass().getResourceAsStream(this.fixture));
        }

    }

}
