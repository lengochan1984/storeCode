/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2005 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/23| 新規作成                           | 1.0    | YSK)植山
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.fw.test.action;

import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * FW01_15_BaseActionテスト.<br>
 *<br>
 * 概要:<br>
 *   FW01_15_BaseActionのテストクラス
 *<br>
 */
public class FW01_15_BaseActionTest {

    /**
     * 前処理.<br>
     *<br>
     * 概要:<br>
     *   各テスト実行前に必ず実行される処理
     *<br>
     * @throws java.lang.Exception 例外
     */
    @Before
    public void setUp() throws Exception {
    }

    /**
     * 後処理.<br>
     *<br>
     * 概要:<br>
     *   各テスト実行後に必ず実行される処理
     *<br>
     * @throws java.lang.Exception 例外
     */
    @After
    public void tearDown() throws Exception {
    }

    /**
     *
     * テスト.<br>
     *<br>
     * 概要:<br>
     *   テストを実装
     *<br>
     */
    @Test
    public void test() {
        // TODO 未実装
        fail("まだ実装されていません");
    }

}
