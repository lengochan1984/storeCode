/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2005 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/05/14| 新規作成                           | 1.0    | YSK)大山
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.fw.test.telecom;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

/**
 * 通信プロセス マトリクスPT用テストクラス.<br>
 *<br>
 * 概要:<br>
 *   通信プロセスのマトリクスPT用テストクラス
 *<br>
 */
public class TelecomMatrixTest {

    /**
     * 接続文字列.
     */
    private static final String CONNECT_STR = "//172.16.38.200:5432/mmcloud";

    /**
     * 接続ユーザ名.
     */
    private static final String CONNECT_USER = "ohyama";

    /**
     * 接続パスワード.
     */
    private static final String CONNECT_PASSWORD = "ohyama";

    /**
     * DBアクセステスター.
     */
    @Rule
    public DbUnitTester tester = new TelecomMatrixDbUnitTester("fixtures_matrix.xml");

    /**
     * データファイル格納場所.
     */
    private static final String DATA_DIR = "C:\\MMCloud\\test\\testData\\";

    /**
     * 前処理.<br>
     *<br>
     * 概要:<br>
     *   前処理を実行します
     *<br>
     * @throws java.lang.Exception 例外
     */
    @Before
    public void setUp() throws Exception {
    }

    /**
     * 後処理.<br>
     *<br>
     * 概要:<br>
     *   後処理を実行します
     *<br>
     * @throws java.lang.Exception 例外
     */
    @After
    public void tearDown() throws Exception {
    }

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    @Test
    public void test_通信プロセス() {

        // テストデータ作成
        this.makeTestData();

        String ipAddr = "172.16.37.251";
        String port = "10000";

        TcpCommTool tool = new TcpCommTool();

        try {
            // 単一
            for (int i = 1; i <= 10; i++) {
                List<String> argList = new ArrayList<String>();
                argList.add(ipAddr);
                argList.add(port);
                argList.add("testData-mono" + i + ".txt");

                tool.main((String[]) argList.toArray(new String[0]));

                Thread.sleep(300);
            }

            // CSV
            for (int i = 1; i <= 16; i++) {
                List<String> argList = new ArrayList<String>();
                argList.add(ipAddr);
                argList.add(port);
                argList.add("testData-csv" + i + ".txt");

                tool.main((String[]) argList.toArray(new String[0]));

                Thread.sleep(300);
            }

            // XML
            for (int i = 1; i <= 13; i++) {
                List<String> argList = new ArrayList<String>();
                argList.add(ipAddr);
                argList.add(port);
                argList.add("testData-xml" + i + ".txt");

                tool.main((String[]) argList.toArray(new String[0]));

                Thread.sleep(300);
            }

            // FIX
            for (int i = 1; i <= 8; i++) {
                List<String> argList = new ArrayList<String>();
                argList.add(ipAddr);
                argList.add(port);
                argList.add("testData-fix" + i + ".txt");

                tool.main((String[]) argList.toArray(new String[0]));

                Thread.sleep(300);
            }
        } catch (Exception e) {

        }
    }

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    @Test
    public void test_通信プロセス1() {

        String test = "あいうえおかきく";
        test = test.substring(0, 5);

        // テストデータ作成
        String dataStr = "あいうえお";
        this.outputFile("AAAtestData1.txt", dataStr, "9001");

        dataStr = "あいうえお";
        this.outputFile("AAAtestData2.txt", dataStr, "9002");

        String txt = "";
        txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        txt += "<!-- comment -->";
        txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
        txt += "<group>";
        txt += "<remote>";
        txt += "<ch>";
        txt += "<num>1</num>";
        txt += "<scale_expr></scale_expr>";
        txt += "<name>ondo</name>";
        txt += "<current>";
        txt += "<unix_time>1381124461</unix_time>";
        txt += "<time_str>2014-05-23 09:00:00</time_str>";
        txt += "<value valid=\"true\">あいうえお</value>";
        txt += "<unit>C</unit>";
        txt += "<batt>-1</batt>";
        txt += "</current>";
        txt += "<record>";
        txt += "<type>13</type>";
        txt += "<unix_time>1381120921</unix_time>";
        txt += "<data_id>212</data_id>";
        txt += "<interval>60</interval>";
        txt += "<count>60</count>";
        txt += "<data>";
        txt += "8QTxB";
        txt += "</data>";
        txt += "</record>";
        txt += "</ch>";
        txt += "</remote>";
        txt += "</group>";
        txt += "</file>";
        this.outputFile("AAAtestData3.txt", txt, "9003");

        String ipAddr = "172.16.37.251";
        String port = "10000";

        TcpCommTool tool = new TcpCommTool();

        try {
            // 単一
            for (int i = 1; i <= 3; i++) {
                List<String> argList = new ArrayList<String>();
                argList.add(ipAddr);
                argList.add(port);
                argList.add("AAAtestData" + i + ".txt");

                tool.main((String[]) argList.toArray(new String[0]));

                Thread.sleep(300);
            }

        } catch (Exception e) {

        }
    }

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    @Test
    public void test_通信プロセス2() {

        String ipAddr = "172.16.37.251";
        String port = "10000";

        TcpCommTool tool = new TcpCommTool();

//        try {
//            for (int i = 1; i <= 10; i++) {
//
//                this.outputFile("testData-test1.txt", String.valueOf(i), "1101");
//
//                Thread.sleep(2000);
//
//                List<String> argList = new ArrayList<String>();
//                argList.add(ipAddr);
//                argList.add(port);
//                argList.add("testData-test1.txt");
//
//                tool.main((String[]) argList.toArray(new String[0]));
//
//            }
//
//        } catch (Exception e) {
//
//        }
    }

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    public void makeTestData() {
        try {
            // ファイル出力(単一)
            // 1
            String dataStr = "10";
            this.outputFile("testData-mono1.txt", dataStr, "1101");
            // 2
            dataStr = "test";
            this.outputFile("testData-mono2.txt", dataStr, "1102");
            // 3
            dataStr = "1";
            this.outputFile("testData-mono3.txt", dataStr, "1103");
            // 4
            dataStr = "13,09,48.9126,S,72,32,45.0996,W";
            this.outputFile("testData-mono4.txt", dataStr, "1104");
            // 5
            dataStr = "12.34";
            this.outputFile("testData-mono5.txt", dataStr, "1105");
            // 6
            dataStr = "10";
            this.outputFile("testData-mono6.txt", dataStr, "1106");
            // 7
            dataStr = "2014-05-25 13:01:02";
            this.outputFile("testData-mono7.txt", dataStr, "1107");
            // 8
            dataStr = "event";
            this.outputFile("testData-mono8.txt", dataStr, "1108");
            // 9
            dataStr = "10";
            this.outputFile("testData-mono9.txt", dataStr, "1109");
            // 10
            dataStr = "";
            this.outputFile("testData-mono10.txt", dataStr, "110A");

            // ファイル出力(csv)
            // 1
            dataStr = "#comment\r\n11";
            this.outputFile("testData-csv1.txt", dataStr, "1201");
            // 2
            dataStr = "Header\r\n#comment\r\n12";
            this.outputFile("testData-csv2.txt", dataStr, "1202");
            // 3
            dataStr = "#comment1\r\n#comment2\r\n13";
            this.outputFile("testData-csv3.txt", dataStr, "1203");
            // 4
            dataStr = "14";
            this.outputFile("testData-csv4.txt", dataStr, "1204");
            // 5
            dataStr = "#comment\r\n2014-05-25 10:11:12,15";
            this.outputFile("testData-csv5.txt", dataStr, "1205");
            // 6
            dataStr = "#comment\r\n";
            dataStr += "test1";
            dataStr += ",9";
            dataStr += ",10";
            dataStr += ",12.3";
            dataStr += ",2014-05-23 10:01:02";
            dataStr += ",1";
            dataStr += ",event";
            this.outputFile("testData-csv6.txt", dataStr, "1206");
            // 7
            dataStr = "#comment\r\n2014-05-25 10:01:02";
            dataStr += ",test1";
            dataStr += ",9";
            dataStr += ",10";
            dataStr += ",12.3";
            dataStr += ",2014-05-23 10:01:02";
            dataStr += ",1";
            dataStr += ",event";
            this.outputFile("testData-csv7.txt", dataStr, "1207");
            // 8
            dataStr = "#comment\r\n";
            dataStr += "2014-05-25 10:01:02";
            dataStr += ",2014-05-24 10:01:02";
            dataStr += ",2014-05-23 10:01:02";
            dataStr += ",2014-05-22 10:01:02";
            dataStr += ",2014-05-21 10:01:02";
            dataStr += ",2014-05-20 10:01:02";
            dataStr += ",2014-05-19 10:01:02";
            dataStr += ",test1";
            dataStr += ",9";
            dataStr += ",10";
            dataStr += ",12.3";
            dataStr += ",2014-05-23 10:01:02";
            dataStr += ",1";
            dataStr += ",event";
            this.outputFile("testData-csv8.txt", dataStr, "1208");
            // 9
            dataStr = "#comment\r\n";
            dataStr += "2014-05-25 10:01:02";
            dataStr += ",2014-05-24 10:01:02";
            dataStr += ",test1";
            dataStr += ",9";
            dataStr += ",10";
            dataStr += ",12.3";
            dataStr += ",2014-05-23 10:01:02";
            dataStr += ",1";
            dataStr += ",event";
            this.outputFile("testData-csv9.txt", dataStr, "1209");
            // 10
            dataStr = "#comment\r\n";
            dataStr += "test1";
            dataStr += ",9";
            dataStr += ",10";
            dataStr += ",";
            dataStr += ",";
            dataStr += ",1";
            dataStr += ",event";
            this.outputFile("testData-csv10.txt", dataStr, "120A");
            // 11
            dataStr = "#comment\r\n";
            dataStr += "test1";
            dataStr += ",";
            dataStr += ",10";
            dataStr += ",";
            dataStr += ",2014-05-23 10:01:02";
            dataStr += ",";
            dataStr += ",event";
            this.outputFile("testData-csv11.txt", dataStr, "120B");
            // 12
            dataStr = "#comment\r\n";
            dataStr += "2014-05-25 10:01:02";
            dataStr += ",2014-05-24 10:01:02";
            dataStr += ",test1";
            dataStr += ",9";
            dataStr += ",";
            dataStr += ",";
            dataStr += ",2014-05-23 10:01:02";
            dataStr += ",1";
            dataStr += ",event";
            this.outputFile("testData-csv12.txt", dataStr, "120C");
            // 13
            dataStr = "#comment\r\n";
            dataStr += "2014-05-25 10:01:02";
            dataStr += ",2014-05-24 10:01:02";
            dataStr += ",";
            dataStr += ",9";
            dataStr += ",";
            dataStr += ",12.3";
            dataStr += ",";
            dataStr += ",1";
            dataStr += ",event";
            this.outputFile("testData-csv13.txt", dataStr, "120D");
            // 14
            dataStr = "#comment\r\n";
            dataStr += "2014-05-25 10:01:02";
            dataStr += ",2014-05-24 10:01:02";
            dataStr += ",";
            dataStr += ",9";
            dataStr += ",";
            dataStr += ",12.3";
            dataStr += ",";
            dataStr += ",1";
            dataStr += ",event";
            this.outputFile("testData-csv14.txt", dataStr, "120E");
            // 15
            dataStr = "";
            this.outputFile("testData-csv15.txt", dataStr, "120F");

            // 16 (座標変換確認)
            dataStr = "#comment\r\n";
            dataStr += "-13.16358";
            dataStr += ",-72.54586";
            this.outputFile("testData-csv16.txt", dataStr, "12F0");

            // ファイル出力(xml)
            // 1
            String txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<!-- comment -->";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<group>";
            txt += "<remote>";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-23 09:00:00</time_str>";
            txt += "<value valid=\"true\">10</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-xml1.txt", txt, "1301");

            // 2
            txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<!-- comment -->";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<group>";
            txt += "<remote>";
            txt += "<!-- comment2 -->";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-23 09:00:00</time_str>";
            txt += "<value valid=\"true\">10</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-xml2.txt", txt, "1302");

            // 3
            txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<group>";
            txt += "<remote>";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-23 09:00:00</time_str>";
            txt += "<value valid=\"true\">10</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-xml3.txt", txt, "1303");

            // 4
            txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<!-- comment -->";
            txt += "<group>";
            txt += "<remote>";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-23 09:00:00</time_str>";
            txt += "<value valid=\"true\">10</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-xml4.txt", txt, "1304");

            // 5
            txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<!-- comment -->";
            txt += "<group>";
            txt += "<remote>";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-25 09:00:00</time_str>";
            txt += "<value valid=\"true\">9</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>2</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-24 09:00:00</time_str>";
            txt += "<value valid=\"true\">test1</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>3</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-23 09:00:00</time_str>";
            txt += "<value valid=\"true\">1</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>4</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-22 09:00:00</time_str>";
            txt += "<value valid=\"true\">13,09,48.9126,S,72,32,45.0996,W</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>5</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-21 09:00:00</time_str>";
            txt += "<value valid=\"true\">12.3</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>6</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-20 09:00:00</time_str>";
            txt += "<value valid=\"true\">10</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>7</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-19 09:00:00</time_str>";
            txt += "<value valid=\"true\">2014-05-25 10:00:00</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>8</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-18 09:00:00</time_str>";
            txt += "<value valid=\"true\">event</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-xml5.txt", txt, "1305");

            // 6
            txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<!-- comment -->";
            txt += "<group>";
            txt += "<remote>";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-25 09:00:00</time_str>";
            txt += "<value valid=\"true\">9</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>2</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-24 09:00:00</time_str>";
            txt += "<value valid=\"true\">test1</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>3</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-23 09:00:00</time_str>";
            txt += "<value valid=\"true\">1</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>4</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-22 09:00:00</time_str>";
            txt += "<value valid=\"true\">13,09,48.9126,S,72,32,45.0996,W</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>5</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-21 09:00:00</time_str>";
            txt += "<value valid=\"true\">12.3</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>6</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-20 09:00:00</time_str>";
            txt += "<value valid=\"true\">10</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>7</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-19 09:00:00</time_str>";
            txt += "<value valid=\"true\">2014-05-25 10:00:00</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>8</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-18 09:00:00</time_str>";
            txt += "<value valid=\"true\">event</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-xml6.txt", txt, "1306");

            // 7
            txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<!-- comment -->";
            txt += "<group>";
            txt += "<remote>";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-25 09:00:00</time_str>";
            txt += "<value valid=\"true\">9</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>2</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-24 09:00:00</time_str>";
            txt += "<value valid=\"true\">test1</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>3</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-23 09:00:00</time_str>";
            txt += "<value valid=\"true\">1</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>4</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-22 09:00:00</time_str>";
            txt += "<value valid=\"true\">13,09,48.9126,S,72,32,45.0996,W</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>5</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-21 09:00:00</time_str>";
            txt += "<value valid=\"true\">12.3</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>6</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-20 09:00:00</time_str>";
            txt += "<value valid=\"true\">10</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>7</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-19 09:00:00</time_str>";
            txt += "<value valid=\"true\">2014-05-25 10:00:00</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>8</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-18 09:00:00</time_str>";
            txt += "<value valid=\"true\">event</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-xml7.txt", txt, "1307");

            // 8
            txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<!-- comment -->";
            txt += "<group>";
            txt += "<remote>";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-25 09:00:00</time_str>";
            txt += "<value valid=\"true\">9</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>2</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-24 09:00:00</time_str>";
            txt += "<value valid=\"true\">test1</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>3</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-23 09:00:00</time_str>";
            txt += "<value valid=\"true\">1</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>4</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-22 09:00:00</time_str>";
            txt += "<value valid=\"true\">13,09,48.9126,S,72,32,45.0996,W</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>5</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-21 09:00:00</time_str>";
            txt += "<value valid=\"true\">12.3</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>6</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-20 09:00:00</time_str>";
            txt += "<value valid=\"true\">10</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>7</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-19 09:00:00</time_str>";
            txt += "<value valid=\"true\">2014-05-25 10:00:00</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>8</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-18 09:00:00</time_str>";
            txt += "<value valid=\"true\">event</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-xml8.txt", txt, "1308");

            // 9
            txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<!-- comment -->";
            txt += "<group>";
            txt += "<remote>";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-25 09:00:00</time_str>";
            txt += "<value valid=\"true\">9</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>2</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-24 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>3</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-23 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>4</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-22 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>5</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-21 09:00:00</time_str>";
            txt += "<value valid=\"true\">12.3</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>6</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-20 09:00:00</time_str>";
            txt += "<value valid=\"true\">10</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>7</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-19 09:00:00</time_str>";
            txt += "<value valid=\"true\">2014-05-25 10:00:00</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>8</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-18 09:00:00</time_str>";
            txt += "<value valid=\"true\">event</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-xml9.txt", txt, "1309");

            // 10
            txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<!-- comment -->";
            txt += "<group>";
            txt += "<remote>";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-25 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>2</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-24 09:00:00</time_str>";
            txt += "<value valid=\"true\">test1</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>3</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-23 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>4</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-22 09:00:00</time_str>";
            txt += "<value valid=\"true\">13,09,48.9126,S,72,32,45.0996,W</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>5</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-21 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>6</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-20 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>7</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-19 09:00:00</time_str>";
            txt += "<value valid=\"true\">2014-05-25 10:00:00</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>8</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-18 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-xml10.txt", txt, "130A");

            // 11
            txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<!-- comment -->";
            txt += "<group>";
            txt += "<remote>";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-25 09:00:00</time_str>";
            txt += "<value valid=\"true\">9</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>2</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-24 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>3</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-23 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>4</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-22 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>5</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-21 09:00:00</time_str>";
            txt += "<value valid=\"true\">12.3</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>6</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-20 09:00:00</time_str>";
            txt += "<value valid=\"true\">10</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>7</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-19 09:00:00</time_str>";
            txt += "<value valid=\"true\">2014-05-25 10:00:00</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>8</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-18 09:00:00</time_str>";
            txt += "<value valid=\"true\">event</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-xml11.txt", txt, "130B");

            // 12
            txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<!-- comment -->";
            txt += "<group>";
            txt += "<remote>";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-25 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>2</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-24 09:00:00</time_str>";
            txt += "<value valid=\"true\">test1</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>3</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-23 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>4</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-22 09:00:00</time_str>";
            txt += "<value valid=\"true\">13,09,48.9126,S,72,32,45.0996,W</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>5</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-21 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>6</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-20 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>7</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-19 09:00:00</time_str>";
            txt += "<value valid=\"true\">2014-05-25 10:00:00</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>8</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-18 09:00:00</time_str>";
            txt += "<value valid=\"true\"></value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-xml12.txt", txt, "130C");

            // 13
            txt = "";
            txt += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
            txt += "<file format=\"current_readings\" version=\"1.22\" name=\"TR-701NW_58700019_20131007-144119.xml\">";
            txt += "<!-- comment -->";
            txt += "<group>";
            txt += "<remote>";
            txt += "<ch>";
            txt += "<num>1</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-25 09:00:00</time_str>";
            txt += "<value valid=\"true\">9</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>2</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-24 09:00:00</time_str>";
            txt += "<value valid=\"true\">test1</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>3</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-23 09:00:00</time_str>";
            txt += "<value valid=\"true\">1</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>4</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-22 09:00:00</time_str>";
            txt += "<value valid=\"true\">13,09,48.9126,S,72,32,45.0996,W</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>5</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-21 09:00:00</time_str>";
            txt += "<value valid=\"true\">12.3</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>6</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-20 09:00:00</time_str>";
            txt += "<value valid=\"true\">10</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>7</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-19 09:00:00</time_str>";
            txt += "<value valid=\"true\">2014-05-25 10:00:00</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "<ch>";
            txt += "<num>8</num>";
            txt += "<scale_expr></scale_expr>";
            txt += "<name>ondo</name>";
            txt += "<current>";
            txt += "<unix_time>1381124461</unix_time>";
            txt += "<time_str>2014-05-18 09:00:00</time_str>";
            txt += "<value valid=\"true\">event</value>";
            txt += "<unit>C</unit>";
            txt += "<batt>-1</batt>";
            txt += "</current>";
            txt += "<record>";
            txt += "<type>13</type>";
            txt += "<unix_time>1381120921</unix_time>";
            txt += "<data_id>212</data_id>";
            txt += "<interval>60</interval>";
            txt += "<count>60</count>";
            txt += "<data>";
            txt += "8QTxB";
            txt += "</data>";
            txt += "</record>";
            txt += "</ch>";
            txt += "</remote>";
            txt += "</group>";
            txt += "</file>";
            this.outputFile("testData-xml13.txt", txt, "130D");

            // 14
            txt = "";
            this.outputFile("testData-xml14.txt", txt, "130E");

            // ファイル出力(fix)
            // 1
            byte[] data1 = {11};
            this.outputFileFix("testData-fix1.txt", data1, "1401");
            // 2
            byte[] data2 = {
                    7, -34, 5, 25, 10, 11, 12,
                    11};
            this.outputFileFix("testData-fix2.txt", data2, "1402");
            // 3
            byte[] data3 = {11, 0x54, 1, 10};
            this.outputFileFix("testData-fix3.txt", data3, "1403");
            // 4
            byte[] data4 = {
                    7, -34, 5, 25, 10, 11, 12,
                    11, 0x54, 1, 10};
            this.outputFileFix("testData-fix4.txt", data4, "1404");
            // 5
            byte[] data5 = {
                    7, -34, 5, 25, 10, 11, 12,
                    7, -34, 5, 25, 11, 11, 12,
                    7, -34, 5, 25, 12, 11, 12,
                    7, -34, 5, 25, 13, 11, 12,
                    11, 0x54, 1, 10};
            this.outputFileFix("testData-fix5.txt", data5, "1405");
            // 6
            byte[] data6 = {
                    7, -34, 5, 25, 10, 11, 12,
                    7, -34, 5, 25, 11, 11, 12,
                    11, 0x54, 1, 10};
            this.outputFileFix("testData-fix6.txt", data6, "1406");
            // 7
            byte[] data7 = {
                    7, -34, 5, 25, 10, 11, 12,
                    7, -34, 5, 25, 11, 11, 12,
                    11, 0x54, 1, 10};
            this.outputFileFix("testData-fix7.txt", data7, "1407");
            // 8
            byte[] data8 = {};
            this.outputFileFix("testData-fix8.txt", data8, "1408");


        } catch (Exception e) {

        }

    }

    private String formatStr(final String _dataStr, final int _length, final String _format) {

        String retStr = "";
        try {
            byte[] data = _dataStr.getBytes(_format);
            int length = _length;
            if (data.length > _length) {
                length = data.length;
            }
            for (int i = 0; i < length; i++) {
                if (i >= data.length) {
                    retStr += "00";
                } else {
                    retStr += String.format("%1$02X", data[i]);
                }
            }
        } catch (Exception e) {

        }

        return retStr;
    }

    private void outputFile(final String _filePath, final String _data, final String _commandCd) {

        try {
            // ファイル出力
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print("01");
            // 顧客CD
            pw.print(this.formatStr("company1", 10, "ASCII"));
            // 機器ID
            pw.print(this.formatStr("device001", 20, "ASCII"));
            // コマンドコード
            pw.print(_commandCd);
            // データサイズ
            int length = _data.length();
            if (_data.getBytes("UTF-8").length > length) {
                length = _data.getBytes("UTF-8").length;
            }
            pw.print(String.format("%1$08X", length));
            // 予備
            pw.print("00000000000000000000000000");
            // データ
            pw.print(this.formatStr(_data, _data.length(), "UTF-8"));

            pw.close();

        } catch (Exception e) {

        }
    }

    private void outputFileFix(final String _filePath, final byte[] _data, final String _commandCd) {

        try {
            // ファイル出力(fix)
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print("01");
            // 顧客CD
            pw.print(this.formatStr("company1", 10, "ASCII"));
            // 機器ID
            pw.print(this.formatStr("device001", 20, "ASCII"));
            // コマンドコード
            pw.print(_commandCd);
            // データサイズ
            int length = _data.length;
            pw.print(String.format("%1$08X", length));
            // 予備
            pw.print("00000000000000000000000000");
            // データ
            for (int i = 0; i < length; i++) {
                pw.print(String.format("%1$02X", _data[i]));
            }

            pw.close();

        } catch (Exception e) {

        }
    }

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    @Test
    public void test_テスト用() {

        try {
            BigDecimal decimalData = new BigDecimal("12.34");
            int arraySize = Double.SIZE / Byte.SIZE;
            ByteBuffer buffer = ByteBuffer.allocate(arraySize);
            byte[] test = buffer.putDouble(decimalData.doubleValue()).array();

            DataInputStream in = new DataInputStream(new ByteArrayInputStream(test));
            double value = in.readDouble();
            decimalData = new BigDecimal(value);

            arraySize = Integer.SIZE / Byte.SIZE;
            buffer = ByteBuffer.allocate(arraySize);
            test = buffer.putInt(1234).array();

            // 4バイト以下の場合のみ処理
            long longValue = 0;
            final int shift = 8;
            final int mask = 0xff;
            for (int i = 0; i < test.length; i++) {
                // 1バイトずつ格納
                longValue = (longValue << shift) + (test[i] & mask);
            }
            Long tmp = new Long(longValue);
            int valueInt = tmp.intValue();

            int debug = 0;
        } catch (Exception e) {

        }
    }

    /**
    *
    * マトリクス試験DBアクセステスター.<br>
    *<br>
    * 概要:<br>
    *   テストデータ作成用のDBアクセステスター
    *<br>
    */
    static class TelecomMatrixDbUnitTester extends DbUnitTester {
        /**
         * 初期値用データファイル.
         */
        private final String fixture;

        /**
         *
         * コンストラクタ.
         *
         * @param _fixture 初期値用データファイル名
         */
        public TelecomMatrixDbUnitTester(final String _fixture) {
            super("org.postgresql.Driver",
                    "jdbc:postgresql:" + CONNECT_STR, CONNECT_USER, CONNECT_PASSWORD, CONNECT_USER);
            this.fixture = _fixture;
        }

        /* (非 Javadoc)
         * @see jp.ysk.mmcloud.DbUnitTester#before()
         */
        @Override
        protected void before() throws Exception {
            // 初期化前のデータ削除処理
//            executeQuery("delete from sys_env");
//            executeQuery("delete from rel_device_alarm");
//            executeQuery("delete from mst_alarm");
//            executeQuery("delete from mst_alarm_condition");
//            executeQuery("delete from mst_data_point");
//            executeQuery("delete from tbl_alarm_state_data");
//            executeQuery("delete from tbl_data_point_data_bit");
//            executeQuery("delete from tbl_data_point_data_int");
//            executeQuery("delete from tbl_data_point_data_decimal");
//            executeQuery("delete from tbl_data_point_data_text");
//            executeQuery("delete from tbl_data_point_data_word");
//            executeQuery("delete from tbl_data_point_data_date");
//            executeQuery("delete from tbl_data_point_data_point");
//            executeQuery("delete from mst_mail_address");
//            executeQuery("delete from mst_alarm_send_address");
//            executeQuery("delete from mst_mail_template");
//            executeQuery("delete from tbl_telegram_data");
//            executeQuery("delete from tbl_telecom_log");
            executeQuery("delete from mst_device");
            executeQuery("delete from rel_device_group");
            executeQuery("delete from mst_command");
            executeQuery("delete from mst_data_point_position_xml");
            executeQuery("delete from mst_data_point_position_csv");
            executeQuery("delete from mst_data_point_position_fix");
            executeQuery("delete from mst_datetime");
            executeQuery("delete from mst_data_point");
        }

        /* (非 Javadoc)
         * @see jp.ysk.mmcloud.DbUnitTester#createDataset()
         */
        @Override
        protected IDataSet createDataset() throws Exception {
            // 初期化処理(データファイルから読み込む)
            return new FlatXmlDataSetBuilder().build(getClass().getResourceAsStream(this.fixture));
        }

    }

}
