/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2005 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/05/27| 新規作成                           | 1.0    | YSK)大山
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.fw.test.telecom;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.junit.Rule;
import org.junit.Test;

/**
 * 通信プロセス IT用テストクラス.<br>
 *<br>
 * 概要:<br>
 *   通信プロセスのIT用テストクラス
 *<br>
 */
public class TelecomIT2Test {

    /**
     * DB接続先.
     */
    //private static final String CONNECT_STR = "//172.16.38.200:5432/mmcloud";
    //private static final String CONNECT_STR = "//192.168.131.19:5432/mmcloud";
    private static final String CONNECT_STR = "//192.168.222.218:5432/mmcloud";

    /**
     * 通信プロセス送信先(IPアドレス).
     */
    //private static final String PROCESS_IP = "133.162.234.167";
    //private static final String PROCESS_IP = "172.16.38.191";
    private static final String PROCESS_IP = "192.168.222.85";

    /**
     * 通信プロセス送信先(ポート).
     */
    private static final String PROCESS_PORT = "10010";
    //private static final String PROCESS_PORT = "10000";

    /**
     * 接続ユーザ名.
     */
    //private static final String CONNECT_USER = "v301itupte";
    //private static final String CONNECT_USER = "local00002";
    private static final String CONNECT_USER = "local00010";

    /**
     * 接続パスワード.
     */
    //private static final String CONNECT_PASSWORD = "OTqMXojFZxtFHmi3";
    private static final String CONNECT_PASSWORD = "cHuf5fgu4yLOL5Jn";

    /**
     * 顧客CD.
     */
    //private static final String CUSTOMER_CD = "V301ITUPTE";
    //private static final String CUSTOMER_CD = "LOCAL00002";
    private static final String CUSTOMER_CD = "LOCAL00010";

    /**
     * DBアクセステスター.
     */
    @Rule
    public DbUnitTester tester = new TelecomITDbUnitTester("fixtures_IT2.xml");

    /**
     * データファイル格納場所.
     */
    private static final String DATA_DIR = "C:\\MMCloud\\test\\testData\\IT\\data\\";

    /**
     * ファイル名(ヘッダ).
     */
    private static final String FILE_HEADER = "testIT";

    /**
     * ファイル名(拡張子).
     */
    private static final String FILE_EXT = ".txt";


    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    @Test
    public void test_通信プロセス() {

        // テストデータ作成
        this.makeTestData();

        String ipAddr = PROCESS_IP;
        String port = PROCESS_PORT;

        TcpCommTool tool = new TcpCommTool();

        try {
            for (int i = 158; i <= 158; i++) {
                List<String> argList = new ArrayList<String>();
                argList.add(ipAddr);
                argList.add(port);
                argList.add(FILE_HEADER + i + FILE_EXT);

                tool.main((String[]) argList.toArray(new String[0]));

                Thread.sleep(3000);
            }

        } catch (Exception e) {

        }
    }

    /**
    *
    * .<br>
    *<br>
    * 初期データ　　：　なし<br>
    * 設定データ　　：　なし<br>
    * 検証内容　　　：　<br>
    *<br>
    */
    public void makeTestData() {

        int commandCd = 1604;
        int idx = 104;

        // 104
        String setStr = "2147483647";
        byte[] data1 = null;
        Integer intValue = new Integer(setStr);
        ByteBuffer buffer = ByteBuffer.allocate(4);
        data1 = buffer.putInt(intValue.intValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data1, String.valueOf(commandCd++));

        // 105
        setStr = "-2147483648";
        byte[] data2 = null;
        intValue = new Integer(setStr);
        buffer = ByteBuffer.allocate(4);
        data2 = buffer.putInt(intValue.intValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data2, String.valueOf(commandCd++));

        // 106
        setStr = "32767";
        byte[] data3 = null;
        Short shortValue = new Short(setStr);
        buffer = ByteBuffer.allocate(2);
        data3 = buffer.putShort(shortValue.shortValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data3, String.valueOf(commandCd++));

        // 107
        setStr = "-32768";
        byte[] data4 = null;
        shortValue = new Short(setStr);
        buffer = ByteBuffer.allocate(2);
        data4 = buffer.putShort(shortValue.shortValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data4, String.valueOf(commandCd++));

        // 108
        setStr = "127";
        Byte byteValue = new Byte(setStr);
        buffer = ByteBuffer.allocate(1);
        byte[] data5 = buffer.put(byteValue.byteValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data5, String.valueOf(commandCd++));

        // 109
        setStr = "-128";
        byteValue = new Byte(setStr);
        buffer = ByteBuffer.allocate(1);
        byte[] data6 = buffer.put(byteValue.byteValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data6, String.valueOf(commandCd++));

        // 110
        setStr = "2147483647";
        byte[] data7 = null;
        intValue = new Integer(setStr);
        buffer = ByteBuffer.allocate(5);
        data7 = buffer.putInt(intValue.intValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data7, String.valueOf(commandCd++));

        // 111
        setStr = "-2147483648";
        byte[] data8 = null;
        intValue = new Integer(setStr);
        buffer = ByteBuffer.allocate(5);
        data8 = buffer.putInt(intValue.intValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data8, String.valueOf(commandCd++));

        // 112
        setStr = "9999999999.99999";
        byte[] data9 = null;
        BigDecimal decimalData = new BigDecimal(setStr);
        buffer = ByteBuffer.allocate(8);
        data9 = buffer.putDouble(decimalData.doubleValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data9, String.valueOf(commandCd++));

        // 113
        setStr = "-9999999999.99999";
        byte[] data10 = null;
        decimalData = new BigDecimal(setStr);
        buffer = ByteBuffer.allocate(8);
        data10 = buffer.putDouble(decimalData.doubleValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data10, String.valueOf(commandCd++));

        // 114
        setStr = "99.9";
        byte[] data11 = null;
        Float floatData = new Float(setStr);
        buffer = ByteBuffer.allocate(4);
        data11 = buffer.putFloat(floatData.floatValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data11, String.valueOf(commandCd++));

        // 115
        setStr = "-99.9";
        byte[] data12 = null;
        decimalData = new BigDecimal(setStr);
        buffer = ByteBuffer.allocate(4);
        data12 = buffer.putFloat(decimalData.floatValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data12, String.valueOf(commandCd++));

        // 116
        setStr = "99.9";
        byte[] data13 = null;
        decimalData = new BigDecimal(setStr);
        buffer = ByteBuffer.allocate(5);
        data13 = buffer.putFloat(decimalData.floatValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data13, String.valueOf(commandCd++));

        // 117
        setStr = "-99.9";
        byte[] data14 = null;
        decimalData = new BigDecimal(setStr);
        buffer = ByteBuffer.allocate(5);
        data14 = buffer.putFloat(decimalData.floatValue()).array();
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, data14, String.valueOf(commandCd++));

        // 118 テスト保留
        String dataStr = "";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd++));

        Calendar calender = Calendar.getInstance();
        String nowDateStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calender.getTime());
        calender = Calendar.getInstance();
        calender.add(Calendar.SECOND, -1);
        String before1secStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calender.getTime());
        calender = Calendar.getInstance();
        calender.add(Calendar.SECOND, -2);
        String before2secStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calender.getTime());
        calender = Calendar.getInstance();
        calender.add(Calendar.SECOND, -3);
        String before3secStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calender.getTime());

        // 143
        // 119-120
        commandCd = 1619;
        dataStr = "60,11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = "60,11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 144
        // 121-122
        commandCd = 1620;
        dataStr = "60,70";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = "60,70";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 145
        // 123
        commandCd = 1621;
        dataStr = before1secStr + ",60,11\r\n";
        dataStr += nowDateStr + ",70,21";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 146
        // 124
        commandCd = 1622;
        dataStr = before1secStr + ",60,61\r\n";
        dataStr += nowDateStr + ",70,71";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 147
        // 125-128
        commandCd = 1623;
        dataStr = "60,11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = "10,11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = "61,11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = "11,11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 148
        // 129-132
        commandCd = 1624;
        dataStr = "60,70";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = "10,11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = "61,71";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = "12,13";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 149
        // 133
        commandCd = 1625;
        dataStr = before3secStr + ",60,11\r\n";
        dataStr += before2secStr + ",10,21\r\n";
        dataStr += before1secStr + ",61,21\r\n";
        dataStr += nowDateStr + ",11,21";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 150
        // 134
        commandCd = 1626;
        dataStr = before3secStr + ",60,71\r\n";
        dataStr += before2secStr + ",0,10\r\n";
        dataStr += before1secStr + ",61,71\r\n";
        dataStr += nowDateStr + ",1,11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 151
        // 135-137
        commandCd = 1627;
        dataStr = "60,11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = "61,11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = "11,11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 152
        // 138-140
        commandCd = 1628;
        dataStr = "60,70";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = "61,71";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = "12,13";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 153
        // 141
        commandCd = 1629;
        dataStr = before3secStr + ",60,11\r\n";
        dataStr += before1secStr + ",61,21\r\n";
        dataStr += nowDateStr + ",11,21";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 154
        // 142
        commandCd = 1630;
        dataStr = before3secStr + ",60,71\r\n";
        dataStr += before1secStr + ",61,71\r\n";
        dataStr += nowDateStr + ",1,11";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 155
        // 143-144
        commandCd = 1631;
        dataStr = before1secStr + ",60,70";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = nowDateStr + ",61,71";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 156
        // 145-146
        commandCd = 1632;
        dataStr = nowDateStr + ",60,70";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = nowDateStr + ",61,71";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 157
        // 147
        commandCd = 1633;
        dataStr = before1secStr + ",60,70\r\n";
        dataStr += nowDateStr + ",61,71";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 158
        // 148
        commandCd = 1634;
        dataStr = before1secStr + ",50,40\r\n";
        dataStr += nowDateStr + ",60,70\r\n";
        dataStr += nowDateStr + ",61,71";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 159
        // 149-150
        commandCd = 1635;
        dataStr = before1secStr + ",10,20\r\n";
        dataStr += nowDateStr + ",60,70\r\n";
        dataStr += nowDateStr + ",61,71";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr = before1secStr + ",11,21\r\n";
        dataStr += nowDateStr + ",62,72\r\n";
        dataStr += nowDateStr + ",63,73";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // 129
        // 151-152
        commandCd = 1636;
        dataStr = "";
        long now = System.currentTimeMillis();
        now = now - 1000000;
        for (int i=0; i<1000; i++) {
            String strDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(now);
            dataStr += strDate + "," + i + "\r\n";
            now += 1000;
        }
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));
        dataStr += nowDateStr + ",1001";
        this.outputFile(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, dataStr, String.valueOf(commandCd));

        // --------------------------------
        // 153 ～ 160 符号なし整数型テスト
        // --------------------------------
        // 153
        commandCd = 1637;

        byte uintByteValue = (byte) 0x00;
        byte[] bytes = paddingByteValue(uintByteValue, 4);
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, bytes, String.valueOf(commandCd++));

        // 154
        uintByteValue = (byte) 0xFF;
        bytes = paddingByteValue(uintByteValue, 4);
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, bytes, String.valueOf(commandCd++));

        // 155
        uintByteValue = (byte) 0x00;
        bytes = paddingByteValue(uintByteValue, 2);
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, bytes, String.valueOf(commandCd++));

        // 156
        uintByteValue = (byte) 0xFF;
        bytes = paddingByteValue(uintByteValue, 2);
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, bytes, String.valueOf(commandCd++));

        // 157
        uintByteValue = (byte) 0x00;
        bytes = paddingByteValue(uintByteValue, 1);
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, bytes, String.valueOf(commandCd++));

        // 158
        uintByteValue = (byte) 0xFF;
        bytes = paddingByteValue(uintByteValue, 1);
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, bytes, String.valueOf(commandCd++));

        // 159
        uintByteValue = (byte) 0x00;
        bytes = paddingByteValue(uintByteValue, 5);
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, bytes, String.valueOf(commandCd++));

        // 160
        uintByteValue = (byte) 0xFF;
        bytes = paddingByteValue(uintByteValue, 5);
        this.outputFileFix(FILE_HEADER + String.valueOf(idx++) + FILE_EXT, bytes, String.valueOf(commandCd++));
    }

    /**
     * バイト値を配列の数分埋める。
     * @param byteValue バイトの値
     * @param length 配列のサイズ
     */
    private byte[] paddingByteValue(final byte byteValue, final int length) {

        byte[] bytes = new byte[length];
        for (int i = 0 ; i < length; i++) {
            bytes[i] = byteValue;
        }

        return bytes;
    }

    private void outputFile(final String _filePath, final String _data, final String _commandCd) {
        this.outputFile(_filePath, _data, _commandCd, "UTF-8");
    }

    private void outputFile(final String _filePath, final String _data, final String _commandCd, final String _encode) {

        try {
            // ファイル出力
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print("01");
            // 顧客CD
            pw.print(this.formatStr(CUSTOMER_CD, 10, "ASCII"));
            // 機器ID
            pw.print(this.formatStr("device001", 20, "ASCII"));
            // コマンドコード
            pw.print(_commandCd);
            // データサイズ
            int length = _data.length();
            if (_data.getBytes(_encode).length > length) {
                length = _data.getBytes(_encode).length;
            }
            pw.print(String.format("%1$08X", length));
            // 予備
            pw.print("00000000000000000000000000");
            // データ
            pw.print(this.formatStr(_data, _data.length(), _encode));

            pw.close();

        } catch (Exception e) {

        }
    }

    private void outputFileFix(final String _filePath, final byte[] _data, final String _commandCd) {

        try {
            // ファイル出力(fix)
            File file = new File(DATA_DIR + _filePath);
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

            pw.println("threadDef,1,0,0");
            pw.print("dn,0x");
            // プロトコルバージョン
            pw.print("01");
            // 顧客CD
            pw.print(this.formatStr(CUSTOMER_CD, 10, "ASCII"));
            // 機器ID
            pw.print(this.formatStr("device001", 20, "ASCII"));
            // コマンドコード
            pw.print(_commandCd);
            // データサイズ
            int length = _data.length;
            pw.print(String.format("%1$08X", length));
            // 予備
            pw.print("00000000000000000000000000");
            // データ
            for (int i = 0; i < length; i++) {
                pw.print(String.format("%1$02X", _data[i]));
            }

            pw.close();

        } catch (Exception e) {

        }
    }

    private String formatStr(final String _dataStr, final int _length, final String _format) {

        String retStr = "";
        try {
            byte[] data = _dataStr.getBytes(_format);
            int length = _length;
            if (data.length > _length) {
                length = data.length;
            }
            for (int i = 0; i < length; i++) {
                if (i >= data.length) {
                    retStr += "00";
                } else {
                    retStr += String.format("%1$02X", data[i]);
                }
            }
        } catch (Exception e) {

        }

        return retStr;
    }

    /**
    *
    * IT DBアクセステスター.<br>
    *<br>
    * 概要:<br>
    *   テストデータ作成用のDBアクセステスター
    *<br>
    */
    static class TelecomITDbUnitTester extends DbUnitTester {
        /**
         * 初期値用データファイル.
         */
        private final String fixture;

        /**
         *
         * コンストラクタ.
         *
         * @param _fixture 初期値用データファイル名
         */
        public TelecomITDbUnitTester(final String _fixture) {
            super("org.postgresql.Driver",
                    "jdbc:postgresql:" + CONNECT_STR, CONNECT_USER, CONNECT_PASSWORD, CONNECT_USER);
            this.fixture = _fixture;
        }

        /* (非 Javadoc)
         * @see jp.ysk.mmcloud.DbUnitTester#before()
         */
        @Override
        protected void before() throws Exception {
            // 初期化前のデータ削除処理
            executeQuery("delete from mst_device");
            executeQuery("delete from rel_device_group");
            executeQuery("delete from mst_command");
            executeQuery("delete from mst_data_point_position_xml");
            executeQuery("delete from mst_data_point_position_csv");
            executeQuery("delete from mst_data_point_position_fix");
            executeQuery("delete from mst_datetime");
            executeQuery("delete from mst_data_point_calc");
            executeQuery("delete from mst_data_point");
        }

        /* (非 Javadoc)
         * @see jp.ysk.mmcloud.DbUnitTester#createDataset()
         */
        @Override
        protected IDataSet createDataset() throws Exception {
            // 初期化処理(データファイルから読み込む)
            return new FlatXmlDataSetBuilder().build(getClass().getResourceAsStream(this.fixture));
        }

    }

}
