/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/06/16| 新規作成                           | 1.00.00| YSK)大山
 *  2014/12/16| <20000-020> 変更仕様No.8           | 3.00.00| US)萩尾
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.csv;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * CSVフォーマット情報クラス.<br>
 *<br>
 * 概要:<br>
 *   CSVフォーマット情報用のクラス
 *<br>
 */
public class FW01_10_CSVFormat {

    /**
     * 出力エリアキー.
     */
    private List<String> areaKeyList;

    /**
     * 出力エリア別ヘッダ情報.
     */
    private Map<String, List<String[]>> headerInfo;

    /**
     * 出力エリア別データ情報.
     */
    private Map<String, List<Map<String, String>>> dataInfo;

    /**
     * コンストラクタ.
     * コレクションの初期化
     */
    public FW01_10_CSVFormat() {
        this.areaKeyList = new ArrayList<String>();
        this.headerInfo = new HashMap<String, List<String[]>>();
        this.dataInfo = new HashMap<String, List<Map<String, String>>>();
    }

    /**
     * リソース解放・初期化.
     */
    public void clear() {
        this.dataInfo = new HashMap<String, List<Map<String, String>>>();
    }

    /**
     * 出力エリアキー一覧取得.
     * @return 出力エリアキー一覧
     */
    public List<String> getAreaKeyList() {
        return this.areaKeyList;
    }

    /**
     * ヘッダー情報追加.
     * @param _areaKey エリアキー
     * @param _headerInfo ヘッダ情報
     */
    public void putHeadarInfo(final String _areaKey, final String _headerInfo) {
        this.areaKeyList.add(_areaKey);
        List<String[]> itemList = new ArrayList<String[]>();

        for (String itemInfo : _headerInfo.split("[,]")) {
            itemList.add(itemInfo.split("[:]"));
        }
        this.headerInfo.put(_areaKey, itemList);
    }

    /**
     * ヘッダーキー情報取得.
     * @param _areaKey エリアキー
     * @return ヘッダ情報
     */
    public String[] getHeadarKeyInfo(final String _areaKey) {
        List<String> headerName = new ArrayList<String>();

        for (String[] info : this.headerInfo.get(_areaKey)) {
            headerName.add(info[0]);
        }
        return headerName.toArray(new String[headerName.size()]);
    }

    /**
     * ヘッダー名配列取得.
     * @param _areaKey エリアキー
     * @return ヘッダ情報
     */
    public String[] getHeaderInfo(final String _areaKey) {
        List<String> headerName = new ArrayList<String>();

        for (String[] info : this.headerInfo.get(_areaKey)) {
            headerName.add(info[1]);
        }
        return headerName.toArray(new String[headerName.size()]);
    }

    /**
     * データ情報追加(1レコード).
     * @param _areaKey エリアキー
     * @param _record データ
     */
    public void putDataInfo(final String _areaKey, final Map<String, String> _record) {
        List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
        dataList.add(_record);
        this.dataInfo.put(_areaKey, dataList);
    }

    /**
     * データ情報追加(複数レコード).
     * @param _areaKey エリアキー
     * @param _list データリスト
     */
    public void putDataInfoList(final String _areaKey, final List<Map<String, String>> _list) {
        this.dataInfo.put(_areaKey, _list);
    }

    /**
     * データ一覧取得.
     * @param _areaKey エリアキー
     * @return データ一覧
     */
    public List<String[]> getDataInfo(final String _areaKey) {
        List<String[]> dataInfoList = new ArrayList<String[]>();
        List<String[]> headerList = this.headerInfo.get(_areaKey);
        List<Map<String, String>> dataList = this.dataInfo.get(_areaKey);

        for (Map<String, String> record : dataList) {
            List<String> line = new ArrayList<String>();

            for (String[] itemInfo : headerList) {
                line.add(record.get(itemInfo[0]));
            }
            dataInfoList.add(line.toArray(new String[line.size()]));
        }

        return dataInfoList;
    }

    /**
     * CSVヘッダ情報一覧を取得.
     *
     * @return ヘッダ情報
     */
    public List<String> getHeaderInfoList() {
        List<String> headerList = new ArrayList<String>();
        for (String areaKey : this.getAreaKeyList()) {
            headerList = Arrays.asList(this.getHeadarKeyInfo(areaKey));
        }
        return headerList;
    }

    /**
     * CSVヘッダ情報を取得.
     * @param _areaKey エリアキー
     * @return ヘッダ情報
     */
    public List<String[]> getHeader(final String _areaKey) {
        return this.headerInfo.get(_areaKey);
    }

    /**
     * CSVヘッダ情報を取得.
     * @param _areaKey エリアキー
     * @param _headerList ヘッダ情報
     */
    public void putHeader(final String _areaKey, final List<String[]> _headerList) {
        this.areaKeyList.add(_areaKey);
        this.headerInfo.put(_areaKey, _headerList);
    }

}
