/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/06/16| 新規作成                           | 1.00.00| YSK)大山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.csv;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.List;

import javax.servlet.ServletOutputStream;

import jp.ysk.fw.FW00_19_Const;
import au.com.bytecode.opencsv.CSVWriter;

/**
 *
 * CSV出力クラス.<br>
 *<br>
 * 概要:<br>
 *   CSV出力用のクラス
 *<br>
 */
public class FW01_10_CSVWriter extends CSVWriter {

    /**
     * 文字コード.
     */
    private static final String CHAR_SET = FW00_19_Const.FWCST_CD_CSV;

    /**
     * 改行コード.
     */
    private static final String LINE_END = "\r\n";

    /**
     *
     * コンストラクタ.
     *
     * @param _sos サーブレット出力ストリーム
     */
    public FW01_10_CSVWriter(final ServletOutputStream _sos) {
        super(new OutputStreamWriter(_sos, Charset.forName(CHAR_SET)),
                DEFAULT_SEPARATOR, DEFAULT_QUOTE_CHARACTER, LINE_END);
    }

    /**
     *
     * ヘッダ出力.<br>
     *<br>
     * 概要:<br>
     *   ヘッダ情報を書き込む
     *<br>
     * @param _headerInfo ヘッダ情報
     */
    public void writeHeader(final String[] _headerInfo) {
        super.writeNext(_headerInfo);
    }

    /**
     *
     * データ出力.<br>
     *<br>
     * 概要:<br>
     *   データ情報を書き込む
     *<br>
     * @param _dataList データ情報
     */
    public void writeData(final List<String[]> _dataList) {
        super.writeAll(_dataList);
    }

    /**
     * 閉じる.<br>
     *<br>
     * 概要:<br>
     *   閉じる
     *<br>
     * @exception IOException 例外
     */
    public void close() throws IOException {
        super.close();
    }
}
