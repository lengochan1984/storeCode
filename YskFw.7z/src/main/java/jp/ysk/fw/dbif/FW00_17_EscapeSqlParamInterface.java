
package jp.ysk.fw.dbif;

/**
 *
 * SQLパラメータエスケープ処理.<br>
 *<br>
 * 概要:<br>
 *   {??クラス説明??}
 *<br>
 */
public interface FW00_17_EscapeSqlParamInterface {

    /**
     *
     * 単パラメータエスケープ処理.<br>
     *<br>
     * 概要:<br>
     *   String型パラメータについて、SQLエスケープ処理を行う
     *<br>
     * @param _param パラメータ
     * @return パラメータ
     */
    Object escapeParam(Object _param);

}
