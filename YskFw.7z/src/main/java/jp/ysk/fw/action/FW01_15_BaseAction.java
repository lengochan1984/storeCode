/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+=======================================+========+==============
 *  DATE      | Comments                              | Rev    | SIGN
 * ===========+=======================================+========+==============
 *  2014/01/20| 新規作成                              | 1.00.00| YSK)植山
 *  2016/01/14| <40000-025> 変更仕様No.25             | 4.00.00| US)萩尾
 *  2016/01/26| <30101-002> 故障苦情No.30100-012      | 4.00.00| US)萩尾
 *  2016/03/12| <40000-028> Ver.4.00.00 変更仕様No.28 | 4.00.00| US)甲斐
 * -----------+---------------------------------------+--------+--------------
 */
package jp.ysk.fw.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.ysk.fw.FW00_12_AppException;
import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.dto.FW01_09_ErrSessionDto;
import jp.ysk.fw.form.FW01_17_BaseForm;
import jp.ysk.fw.util.FW00_06_MessageResourceUtil;
import jp.ysk.fw.util.FW00_11_UrlEncodeUtil;

import org.seasar.framework.beans.util.BeanMap;
import org.seasar.framework.exception.IORuntimeException;
import org.seasar.framework.util.StringUtil;
import org.seasar.struts.util.ResponseUtil;

/**
 *
 * アクション基底クラス.<br>
 *<br>
 * 概要:<br>
 *   アクションクラスの最上位の親クラスで、フレームワークの共通処理を実装します
 *<br>
 */
public abstract class FW01_15_BaseAction {

    /**
     * タイトル名.
     */
    public String fw0115Title = FW00_06_MessageResourceUtil.getMessage("M017");

    /**
     * FWエラー情報(権限、セッションエラー時、アプリケーションエラー時).
     */
    public FW01_09_ErrSessionDto fW01_09_ErrSessionDto;

    /**
     * フレーム別表示URL.
     */
    public Map<String, String> fw0115BodyURL;

    /**
     * 共通グループツリー情報.
     */
    public List<BeanMap> groupTreeInfo = null;

    /**
     * SQLエラーメッセージCD.
     */
    private String strSqlErrorMsgCd = "MMCMCM00000_303";

    /**
     * リクエスト.
     * Actionクラスは全てこのクラスの派生となるため、
     * 派生クラスでHttpServletRequestをResourceアノテーション付きで定義しないこと
     */
    @Resource
    public HttpServletRequest request;

    /**
     * レスポンス.
     * Actionクラスは全てこのクラスの派生となるため、
     * 派生クラスでHttpServletResponseをResourceアノテーション付きで定義しないこと
     */
    @Resource
    public HttpServletResponse response;

    /**
     * @return タイトル名
     */
    public String getFw0115Title() {
        return this.fw0115Title;
    }

    /**
     *
     * エラー通知.<br>
     *<br>
     * 概要:<br>
     *   チェック結果メッセージ、フォーカスを設定し、フォーワードする
     *<br>
     * @param _forward JSP名
     * @param _msg ダイアログ表示メッセージ
     * @param _ctlId フォーカスコントロールID
     * @return JSP名
     */
    protected String alertErrorInfo(final String _forward, final String _msg, final String _ctlId) {
        this.fW01_09_ErrSessionDto.ssn_strErrMsg = _msg;
        this.fW01_09_ErrSessionDto.ssn_strErrCtlId = _ctlId;
        return _forward;
    }

    /**
     *
     * エラー通知(非同期通信用).<br>
     *<br>
     * 概要:<br>
     *   チェック結果メッセージ、フォーカスを設定し、フォーワードする。(非同期通信用)
     *<br>
     * @param _msg ダイアログ表示メッセージ
     * @param _ctlId フォーカスコントロールID
     * @return JSP名
     */
    protected String alertErrorInfoForAjax(final String _msg, final String _ctlId) {
        this.fW01_09_ErrSessionDto.ssn_strErrMsg = _msg;
        this.fW01_09_ErrSessionDto.ssn_strErrCtlId = _ctlId;
        return "/FW01_20_ErrorAjax.jsp";
    }

    /**
     *
     * エラー通知(非同期通信用).<br>
     *<br>
     * 概要:<br>
     *   チェック結果メッセージ、フォーカスを設定し、フォーワードする。(非同期通信用)
     *<br>
     * @param _msg ダイアログ表示メッセージ
     * @param _ctlId フォーカスコントロールID
     * @param _loadFunctionFlg エラー後関数呼び出しフラグ
     * @return JSP名
     */
    protected String alertErrorInfoForAjax(final String _msg, final String _ctlId, final String _loadFunctionFlg) {
        this.fW01_09_ErrSessionDto.ssn_strErrMsg = _msg;
        this.fW01_09_ErrSessionDto.ssn_strErrCtlId = _ctlId;
        if (StringUtil.isNotBlank(_loadFunctionFlg)) {
            this.fW01_09_ErrSessionDto.ssn_strErrLoadFunctionFlg = _loadFunctionFlg;
        }
        return "/FW01_20_ErrorAjax.jsp";
    }

    /**
     *
     * エラー通知(非同期通信用).<br>
     *<br>
     * 概要:<br>
     *   チェック結果メッセージ、フォーカスを設定し、フォーワードする。(非同期通信用)
     *<br>
     * @param _msg ダイアログ表示メッセージ
     * @param _ctlId フォーカスコントロールID
     * @param _loadFunctionFlg エラー後関数呼び出しフラグ
     * @return JSP名
     */
    protected String alertErrorInfoForAjax(final String _msg, final String _ctlId, final Boolean _loadFunctionFlg) {
        return this.alertErrorInfoForAjax(_msg, _ctlId, _loadFunctionFlg.toString());
    }

    /**
     *
     * リダイレクト処理.<br>
     *<br>
     * 概要:<br>
     *   指定のActionクラスへリダイレクトする
     *<br>
     * @param _pageUrl リダイレクトURL
     * @param _parameter クエリパラメータ(KEY：次画面項目名、VALUE：遷移パラメータ)
     * @param _form 遷移元FORM情報
     * @return リダイレクトURL
     */
    protected String redirectPage(final String _pageUrl,
            final Map<String, String> _parameter, final FW01_17_BaseForm _form) {
        //リダイレクトURL格納バッファ
        StringBuffer sb = null;
        int urlLength = 0;

        sb = new StringBuffer(_pageUrl);
        sb.append("?");

        urlLength = sb.length();

        for (String key : _parameter.keySet()) {
            if (sb.length() != urlLength) {
                // 1件目以外のパラメータ時
                sb.append("&");
            }
            sb.append(FW00_11_UrlEncodeUtil.getUrlEncode(key));
            sb.append("=");
            sb.append(FW00_11_UrlEncodeUtil.getUrlEncode(_parameter.get(key)));
        }

        if (_parameter != null && !_parameter.isEmpty()) {
            sb.append("&");
        }
        // リクエスト区分の設定
        sb.append(FW00_11_UrlEncodeUtil.getUrlEncode(FW01_17_BaseForm.FW0117FORM_REQUESTKBN));
        sb.append("=");
        sb.append(FW00_11_UrlEncodeUtil.getUrlEncode(_form.fw0117RequestKbn));

        // 共通のヘッダ開閉状態をパラメータとして格納
        sb.append("&");
        sb.append(FW00_11_UrlEncodeUtil.getUrlEncode(FW01_17_BaseForm.CM_HDN_IS_HEADER_OPENED));
        sb.append("=");
        if (_form.hdnIsHeaderOpened == null) {
            sb.append(FW00_11_UrlEncodeUtil.getUrlEncode("1"));
        } else {
            sb.append(FW00_11_UrlEncodeUtil.getUrlEncode(_form.hdnIsHeaderOpened));
        }

        // リダイレクト時、次画面でメッセージを表示させるため、URLパラメータにエラーメッセージCDを付与する
        if (_form.hdnSqlErrorMsgCd != null || FW00_19_Const.EMPTY_STR.equals(_form.hdnSqlErrorMsgCd)) {
            sb.append("&");
            sb.append(FW00_11_UrlEncodeUtil.getUrlEncode(FW01_17_BaseForm.CM_HDN_SQL_ERROR_MSG_CD));
            sb.append("=");
            sb.append(FW00_11_UrlEncodeUtil.getUrlEncode(_form.hdnSqlErrorMsgCd));
        }

        // リダイレクトフラグ(SAStruts必須)の設定
        sb.append("&redirect=true");

        return sb.toString();
    }


    /**
     * ファイルダウンロード処理.
     * @param _filePath ダウンロード対象ファイルパス
     * @return null
     */
    protected String download(final String _filePath) {
        return this.download(null, _filePath);
    }

    /**
     * ファイルダウンロード処理.
     * @param _fileName ダウンロード時ファイル名
     * @param _filePath ダウンロード対象ファイルパス
     * @return null
     */
    protected String download(final String _fileName, final String _filePath) {
        FileInputStream in = null;
        File file = new File(_filePath);

        // キャッシュ制御（キャッシュをユーザ毎に共有させない）
        this.response.setHeader("Cache-Control", "private");
        this.response.setHeader("Pragma", "private");

        if (!file.exists()) {
            // ファイルが存在しない場合
            String strMes = "File not found. File Name [" + _filePath + "]";
            throw new FW00_12_BusinessException(strMes);
        }

        try {
            String encordName = FW00_11_UrlEncodeUtil.getUrlEncode(_fileName);
            in = new FileInputStream(file);
            ResponseUtil.download(encordName, in);
        } catch (IORuntimeException e) {
            throw new FW00_12_AppException(e);
        } catch (FileNotFoundException e) {
            throw new FW00_12_AppException(e);
        }

        return null;
    }

    /**
     * SQLエラーメッセージCD取得.
     *
     * @return strSqlErrorMsgCd
     */
    public String getStrSqlErrorMsgCd() {
        return this.strSqlErrorMsgCd;
    }

    /**
     * SQLエラーメッセージCD設定.
     *
     * @param _strSqlErrorMsgCd SQLエラーメッセージCD
     */
    public void setStrSqlErrorMsgCd(final String _strSqlErrorMsgCd) {
        this.strSqlErrorMsgCd = _strSqlErrorMsgCd;
    }

    /**
     * 各画面のフォームクラス取得.<br>
     *<br>
     * 概要:<br>
     * 各画面のフォームクラスを取得<br>
     * 各画面のアクションでオーバーライドし、フォームクラスを設定する
     *
     * @return 画面のフォームクラス
     */
    protected FW01_17_BaseForm getActionForm() {
        return null;
    };

}
