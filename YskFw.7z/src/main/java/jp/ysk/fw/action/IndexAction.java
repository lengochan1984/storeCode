/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.action;

import org.seasar.struts.annotation.Execute;

/**
 *
 * コンテキストルート用アクションクラス.<br>
 *<br>
 * 概要:<br>
 *   コンテキストルート用のアクションクラスです
 *<br>
 */
public class IndexAction extends FW01_15_BaseAction {

    /**
     * メインフレーム遷移先.
     */
    public String transition;

    /**
     *
     * 初期処理.<br>
     *<br>
     * 概要:<br>
     *   コンテキストルートの初期処理を行う
     *<br>
     * @return メインフレームJSP
     */
    @Execute(validator = false)
    public String index() {
        //        return "/FW01_35_MainFrame.jsp";
        return "/a000010Login/index";
    }

    /**
     *
     * 遷移先振分け処理.<br>
     *<br>
     * 概要:<br>
     *   メインフレームの振分けを行う
     *<br>
     * @return メインフレーム遷移先
     */
    @Execute(validator = false)
    public String trans() {
        return this.transition;
    }
}
