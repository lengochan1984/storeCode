/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/27| 新規作成                           | 1.00.00| YSK)森山
 *  2014/12/05| <20000-009> 変更仕様No.7           | 3.00.00| US)楢崎
 *  2016/01/14| <40000-025> 変更仕様No.25          | 4.00.00| US)萩尾
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.ysk.fw.form.FW01_14_ListForm;


/**
 *
 * 一覧画面アクション基底クラス.<br>
 *<br>
 * 概要:<br>
 *   一覧画面アクションクラスで、フレームワークの共通処理を実装します
 *<br>
 */
public abstract class FW01_10_ListAction extends FW01_15_BaseAction {

    /**
     * ページ数.
     */
    public static final String OFFSET_INFO_DISP_PAGE = "intDispPage";

    /**
     * 一覧総データ数.
     */
    public static final String OFFSET_INFO_LIST_CNT = "intListCnt";

    /**
     * 指定ページに表示するデータ数.
     */
    public static final String OFFSET_INFO_LIMIT_CNT = "intLimitCnt";

    /**
     * 一覧ヘッダ.
     */
    public List<Map<String, String>> fw0110ListHeader;

    /**
     * 検索結果表示上限.
     */
    public Long searchResultMax = null;

    /**
     *
     * オフセット情報取得.<br>
     *<br>
     * 概要:<br>
     *   {??メソッド説明??}
     *<br>
     * @param _form フォーム
     * @return オフセット情報
     */
    protected Map<String, Integer> getOffsetInfo(final FW01_14_ListForm _form) {
        Map<String, Integer> offsetInfo = new HashMap<String, Integer>();

        int intDispPage = Integer.parseInt(_form.fw0114PageNo);
        int intListSize = Integer.parseInt(_form.fw0114ListSize);

        offsetInfo.put(OFFSET_INFO_DISP_PAGE, new Integer(intDispPage));
        offsetInfo.put(OFFSET_INFO_LIST_CNT, new Integer(intListSize));

        // 表示可能な最大件数を超える場合、limitを設定する
        if (this.searchResultMax != null && intDispPage * intListSize > this.searchResultMax.longValue()) {
            // 表示件数 = 最大件数 - 前頁までの合計件数
            int intLimitCnt = (int) (this.searchResultMax.longValue() - (intDispPage - 1) * intListSize);
            offsetInfo.put(OFFSET_INFO_LIMIT_CNT, new Integer(intLimitCnt));
        }

        return offsetInfo;
    }

    /**
     *
     * ヘッダー情報格納.<br>
     *<br>
     * 概要:<br>
     *   ヘッダ情報を格納する
     *<br>
     * @param _iName 項目名
     * @param _dName 表示名
     * @param _width 列幅
     * @param _sort ソート有無
     * @param _vertical 表示/非表示
     */
    protected void putHdInf(final String _iName, final String _dName, final String _width,
            final boolean _sort, final String _vertical) {
        if (this.fw0110ListHeader == null) {
            this.fw0110ListHeader = new ArrayList<Map<String, String>>();
        }
        Map<String, String> headerInfo = new HashMap<String, String>();
        headerInfo.put("ItemCode", _iName);
        headerInfo.put("DispName", _dName);
        headerInfo.put("width", _width);
        headerInfo.put("sort", Boolean.toString(_sort));
        headerInfo.put("sortmd", _vertical);
        this.fw0110ListHeader.add(headerInfo);
    }

    /**
     * 各画面のフォームクラス取得.<br>
     *<br>
     * 概要:<br>
     * 各画面のフォームクラスを取得<br>
     *
     * @return 画面のフォームクラス
     */
    protected FW01_14_ListForm getActionForm() {
        return null;
    }

}
