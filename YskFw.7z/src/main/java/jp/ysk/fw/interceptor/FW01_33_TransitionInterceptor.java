/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+=======================================+========+==============
 *  DATE      | Comments                              | Rev    | SIGN
 * ===========+=======================================+========+==============
 *  2014/01/20| 新規作成                              | 1.00.00| YSK)植山
 *  2016/02/12| <40000-021> Ver.4.00.00 変更仕様No.21 | 4.00.00| US)甲斐
 * -----------+---------------------------------------+--------+--------------
 */
package jp.ysk.fw.interceptor;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.action.IndexAction;
import jp.ysk.fw.dto.FW01_12_SessionDto;
import jp.ysk.fw.dto.FW01_34_TransitionDto;
import jp.ysk.fw.form.FW01_17_BaseForm;

import org.aopalliance.intercept.MethodInvocation;
import org.seasar.framework.aop.interceptors.AbstractInterceptor;

/**
 *
 * 画面遷移管理.<br>
 *<br>
 * 概要:<br>
 *   画面遷移管理用のインターセプタークラスです
 *<br>
 */
public class FW01_33_TransitionInterceptor extends AbstractInterceptor {

    /**
     * シリアルID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * 画面遷移情報セッションDTO.
     */
    @Resource
    private FW01_34_TransitionDto transitionDto;

    /**
     * @return 画面遷移情報セッションDTO
     */
    public FW01_34_TransitionDto getTransitionDto() {
        return this.transitionDto;
    }

    /**
     * @param _transitionDto 画面遷移情報セッションDTO
     */
    public void setTransitionDto(final FW01_34_TransitionDto _transitionDto) {
        this.transitionDto = _transitionDto;
    }

    /**
     * 初期メインフレーム画面遷移先.
     */
    private String initTrans;

    /**
     * 初期以外メインフレーム画面遷移先.
     */
    private String notInitTrans;

    /**
     * 全初期化Action情報.
     */
    private Set<String> initAllAction;

    /**
     * フレームグループ情報.
     */
    private Map<String, String> frameGroupInfo;

    /**
     * デフォルト遷移アクション情報.
     */
    private Map<String, Map<String, String>> defaultAction;

    /**
     * 等価画面情報管理.
     */
    private Map<String, Map<String, Integer>> equivalenceInfo;

    /**
     * フレーム別初期化対象情報.
     */
    private Map<String, Set<String>> initAction;

    /**
     * レベル情報採番.
     */
    private int levelCnt = 0;

    /**
     * コンストラクタ.
     */
    public FW01_33_TransitionInterceptor() {
        this.initAllAction = new HashSet<String>();
        this.frameGroupInfo = new HashMap<String, String>();
        this.defaultAction = new HashMap<String, Map<String, String>>();
        this.equivalenceInfo = new HashMap<String, Map<String, Integer>>();
        this.initAction = new HashMap<String, Set<String>>();
    }

    /**
     *
     * 画面遷移管理処理.<br>
     *<br>
     * 概要:<br>
     *   画面遷移管理処理を実行する
     *<br>
     * @param _invocation メソッド
     * @return オブジェクト
     * @throws Throwable 例外
     */
    @Override
    public Object invoke(final MethodInvocation _invocation) throws Throwable {
        // アクションクラス
        Object action = null;
        // アクションフォーム
        FW01_17_BaseForm actionForm = null;
        // アクション名
        String actionName = null;
        // メソッド名
        String methodName = FW00_19_Const.EMPTY_STR;
        FW01_12_SessionDto sessionDto = null;
        // 設定取得キー
        String confKey = FW00_19_Const.EMPTY_STR;
        String frameGroup = FW00_19_Const.EMPTY_STR;

        action = _invocation.getThis();
        sessionDto = this.getSessionDto(action);

        if (action instanceof IndexAction) {
            // デフォルトアクションの場合

            // indexメソッド時
            if (this.transitionDto.isTimeoutFlg()) {
                this.initDto(sessionDto);
            }
            // transメソッド時
            IndexAction indexAction = (IndexAction) action;

            String trans = FW00_19_Const.EMPTY_STR;

            if (this.transitionDto.isEmpty()) {
                trans = this.initTrans;
            } else {
                trans = this.notInitTrans;
            }

            if (trans.endsWith(".jsp")) {
                indexAction.transition = trans;
            } else {
                indexAction.transition = trans + "?redirect=true";
            }

            //            if ("trans".equals(_invocation.getMethod().getName())) {
            //                // transメソッド時
            //                IndexAction indexAction = (IndexAction) action;
            //
            //                String trans = "";
            //
            //                if (this.transitionDto.isEmpty()) {
            //                    trans = this.initTrans;
            //                } else {
            //                    trans = this.notInitTrans;
            //                }
            //
            //                if (trans.endsWith(".jsp")) {
            //                    indexAction.transition = trans;
            //                } else {
            //                    indexAction.transition = trans + "?redirect=true";
            //                }
            //            } else {
            //                // indexメソッド時
            //                if (this.transitionDto.isTimeoutFlg()) {
            //                    this.initDto(sessionDto);
            //                }
            //            }
        } else {
            actionName = action.getClass().getSimpleName().split("[$]")[0];
            // Method名を取得
            methodName = _invocation.getMethod().getName();

            // 設定取得キーを生成
            confKey = actionName + "_" + methodName;

            frameGroup = this.frameGroupInfo.get(actionName);

            //スタック情報初期化処理
            if (this.initAllAction.contains(actionName)) {
                // 全初期化アクションの場合
                this.initDto(sessionDto);
            } else {
                for (String frameName : this.initAction.keySet()) {
                    if (this.initAction.get(frameName).contains(confKey)) {
                        // 初期化対象アクションの場合
                        this.initDto(frameName, sessionDto);
                    }
                }
            }

            if (frameGroup != null && !FW00_19_Const.EMPTY_STR.equals(frameGroup)) {
                for (Field field : action.getClass().getFields()) {
                    // セッション情報を検索
                    Object prop = field.get(action);

                    if (prop instanceof FW01_17_BaseForm) {
                        actionForm = (FW01_17_BaseForm) prop;
                    }

                    if (actionForm != null) {
                        break;
                    }
                }
                // 同期通信時のみ画面遷移情報管理を行う
                if (actionForm.fw0117RequestKbn == null || !("ajax".equals(actionForm.fw0117RequestKbn)
                        || "popup".equals(actionForm.fw0117RequestKbn))) {

                    if (!this.transitionDto.isEmptyFrame(frameGroup)) {
                        // スタック情報が空以外の場合
                        if (!this.transitionDto.isTopAction(frameGroup, actionName)) {
                            // スタック最上位のアクションと一致しない場合
                            if (this.transitionDto.isSecondAction(frameGroup, actionName)) {
                                // 一世代前のアクションと一致する場合
                                this.transitionDto.removeActions(frameGroup, 1);
                            } else {
                                // 一世代前のアクションと一致しない場合
                                String stackAction = this.transitionDto.getTopAction(frameGroup);

                                Map<String, Integer> levelInfo = this.equivalenceInfo.get(frameGroup);

                                if (levelInfo != null && levelInfo.containsKey(actionName)) {
                                    int thisLevel = levelInfo.get(actionName);
                                    int stackLevel = levelInfo.get(stackAction);

                                    if (thisLevel == stackLevel) {
                                        // 同一レベルのアクションの場合
                                        this.transitionDto.removeActions(frameGroup, 1);
                                        this.transitionDto.push(frameGroup, actionName);
                                    } else {
                                        this.transitionDto.push(frameGroup, actionName);
                                    }
                                } else {
                                    this.transitionDto.push(frameGroup, actionName);
                                }
                            }
                        }
                    } else {
                        // スタック情報が空の場合
                        this.transitionDto.push(frameGroup, actionName);
                    }
                }
            }
        }
        // 業務アクションに画面遷移情報プロパティがある場合、設定する。
        this.putTransitionDto(action);

        // 画面性処理前処理呼び出し
        if (!_invocation.getClass().getName().startsWith("jp.ysk.fw.action")) {
            // FWアクション以外に実行
            this.beforeTransition(action);
        }

        // Action開始
        Object ret = _invocation.proceed();

        if (!this.transitionDto.isTimeoutFlg()) {
            if (this.transitionDto.isEmpty() && sessionDto != null
                    && sessionDto.ssn_AuthorityCode != null && !FW00_19_Const.EMPTY_STR.equals(sessionDto.ssn_AuthorityCode)) {
                this.initDto(sessionDto);
            }
            if (!this.transitionDto.isEmpty()) {
                // 現在の画面遷移先情報をBaseActionへ格納する。
                Field fw0115BodyURL = action.getClass().getField("fw0115BodyURL");
                Map<String, String> urlMap = new HashMap<String, String>();

                if (frameGroup == null || FW00_19_Const.EMPTY_STR.equals(frameGroup)) {
                    for (String frameName : this.defaultAction.keySet()) {
                        urlMap.put(frameName, this.getRedirectString(this.transitionDto.getTopAction(frameName)));
                    }
                } else {
                    urlMap.put(frameGroup, this.getRedirectString(this.transitionDto.getTopAction(frameGroup)));
                }
                fw0115BodyURL.set(action, urlMap);
            }
        }
        return ret;
    }

    /**
     *
     * セッション存在時メインフレーム遷移先.<br>
     *<br>
     * 概要:<br>
     *   セッション存在時メインフレーム遷移先を設定する
     *<br>
     * @param _initTrans 初期メインフレーム画面遷移先
     */
    public void setInitTrans(final String _initTrans) {
        this.initTrans = _initTrans;
    }

    /**
     *
     * 初期以外メインフレーム遷移先.<br>
     *<br>
     * 概要:<br>
     *   初期以外メインフレーム遷移先を設定する
     *<br>
     * @param _notInitTrans 初期以外メインフレーム画面遷移先
     */
    public void setNotInitTrans(final String _notInitTrans) {
        this.notInitTrans = _notInitTrans;
    }

    /**
     *
     * 全初期化アクション情報設定.<br>
     *<br>
     * 概要:<br>
     *   スタック情報を全初期化するアクションを設定する。
     *<br>
     * @param _actionNames アクション名リスト
     */
    public void putInitAllAction(final String _actionNames) {
        for (String actionName : _actionNames.split(",")) {
            this.initAllAction.add(actionName);
        }
    }

    /**
     *
     * フレームグループ情報設定.<br>
     *<br>
     * 概要:<br>
     *   フレームグループを設定する
     *<br>
     * @param _frameName フレーム名
     * @param _actionNames アクション名リスト
     */
    public void putFrameGroupInfo(final String _frameName, final String _actionNames) {
        for (String actionName : _actionNames.split(",")) {
            this.frameGroupInfo.put(actionName, _frameName);
        }
    }

    /**
     *
     * デフォルトアクション情報設定.<br>
     *<br>
     * 概要:<br>
     *   フレーム別、権限別のデフォルトアクションを設定する。
     *<br>
     * @param _frameName フレーム名
     * @param _authCode 権限コード
     * @param _actionName アクション名
     */
    public void putDefaultAction(final String _frameName, final String _authCode , final String _actionName) {
        Map<String, String> frameDefaultInfo = null;
        if (this.defaultAction.containsKey(_frameName)) {
            frameDefaultInfo = this.defaultAction.get(_frameName);
        } else {
            frameDefaultInfo = new HashMap<String, String>();
        }
        frameDefaultInfo.put(_authCode, _actionName);
        this.defaultAction.put(_frameName, frameDefaultInfo);
    }

    /**
     *
     * デフォルトアクション取得.<br>
     *<br>
     * 概要:<br>
     *   フレーム、権限別のデフォルトアクションを取得する
     *<br>
     * @param _frameName フレーム名
     * @param _sessionDto セッション情報
     * @return アクション名
     */
    public String getDefaultAction(final String _frameName, final FW01_12_SessionDto _sessionDto) {
        Map<String, String> frameDefaultInfo = this.defaultAction.get(_frameName);

        /**
         * ログイン前のアクション時セッションNULL対応
         */
        if (_sessionDto == null
                || _sessionDto.ssn_AuthorityCode == null || FW00_19_Const.EMPTY_STR.equals(_sessionDto.ssn_AuthorityCode)) {
            //ログイン後にタイムアウトした場合は、先に実行される権限チェックに引っ掛かる
            return FW00_19_Const.EMPTY_STR;
        }

        if (frameDefaultInfo.containsKey(_sessionDto.ssn_AuthorityCode)) {
            return frameDefaultInfo.get(_sessionDto.ssn_AuthorityCode);
        } else {
            return frameDefaultInfo.get("*");
        }
    }

    /**
     *
     * 等価アクション情報設定.<br>
     *<br>
     * 概要:<br>
     *   フレーム別の等価アクション情報を設定する。
     *<br>
     * @param _frameName フレーム名
     * @param _actionNames アクション名リスト
     */
    public void putEquivalenceInfo(final String _frameName, final String _actionNames) {
        int levelKey = this.levelCnt++;
        Map<String, Integer> levelMap = null;
        if (this.equivalenceInfo.containsKey(_frameName)) {
            levelMap = this.equivalenceInfo.get(_frameName);
        } else {
            levelMap = new HashMap<String, Integer>();
        }
        for (String actionName : _actionNames.split(",")) {
            levelMap.put(actionName, levelKey);
        }
        this.equivalenceInfo.put(_frameName, levelMap);
    }

    /**
     *
     * スタック初期化情報設定.<br>
     *<br>
     * 概要:<br>
     *   フレーム別の初期化アクション情報を設定する。
     *<br>
     * @param _frameName フレーム名
     * @param _actionNames アクション名リスト
     */
    public void putInitAction(final String _frameName, final String _actionNames) {
        Set<String> eventSet = new HashSet<String>();
        for (String option : _actionNames.split(",")) {
            String actionName = option.replaceAll("[(].+[)]", FW00_19_Const.EMPTY_STR);
            String methodNames = option.substring(actionName.length()).replaceAll("[()]", FW00_19_Const.EMPTY_STR);

            for (String methodName : methodNames.split("[|]")) {

                String key = actionName + "_" + methodName;

                eventSet.add(key);
            }
        }
        this.initAction.put(_frameName, eventSet);
    }

    /**
     *
     * リダイレクト情報編集処理.<br>
     *<br>
     * 概要:<br>
     *   リダイレクト情報を編集する
     *<br>
     * @param _actionName アクション名
     * @return リダイレクション情報
     */
    private String getRedirectString(final String _actionName) {
        if (FW00_19_Const.EMPTY_STR.equals(_actionName)) {
            return FW00_19_Const.EMPTY_STR;
        }
        StringBuffer sb = new StringBuffer("/");
        String prefix = _actionName.substring(0, 1).toLowerCase();
        sb.append(prefix);
        sb.append(_actionName.substring(1, _actionName.lastIndexOf("Action")));
        return sb.toString();
    }

    /**
     *
     * セッション情報取得.<br>
     *<br>
     * 概要:<br>
     *   業務Actionからセッション情報を取得する
     *<br>
     * @param _action アクション名
     * @return セッション情報
     * @throws Throwable 例外
     */
    protected FW01_12_SessionDto getSessionDto(final Object _action) throws Throwable {
        for (Field field : _action.getClass().getFields()) {
            Object prop = field.get(_action);
            if (prop instanceof FW01_12_SessionDto) {
                return (FW01_12_SessionDto) prop;
            } else {
                continue;
            }
        }
        return null;
    }

    /**
     *
     * 画面遷移情報取得.<br>
     *<br>
     * 概要:<br>
     *   業務Actionに画面遷移情報を設定する
     *<br>
     * @param _action アクション名
     * @throws Throwable 例外
     */
    private void putTransitionDto(final Object _action) throws Throwable {
        for (Field field : _action.getClass().getFields()) {
            if (field.getType().getName().equals(this.transitionDto.getClass().getName())) {
                field.set(_action, this.transitionDto);
                break;
            } else {
                continue;
            }
        }
    }

    /**
     *
     * 画面遷移管理DTO初期化.<br>
     *<br>
     * 概要:<br>
     *   画面遷移管理DTOを初期化する
     *<br>
     * @param _sessionDto セッション情報
     */
    private void initDto(final FW01_12_SessionDto _sessionDto) {
        this.initDto(null, _sessionDto);
    }

    /**
     *
     * 画面遷移管理DTO初期化.<br>
     *<br>
     * 概要:<br>
     *   画面遷移管理DTOを初期化する
     *<br>
     * @param _frameName フレーム名
     * @param _sessionDto セッション情報
     */
    private void initDto(final String _frameName, final FW01_12_SessionDto _sessionDto) {

        // ログイン前のアクション時セッションNULL対応
        if (_sessionDto == null
                || _sessionDto.ssn_AuthorityCode == null || FW00_19_Const.EMPTY_STR.equals(_sessionDto.ssn_AuthorityCode)) {
            // ログイン後にタイムアウトした場合は、先に実行される権限チェックに引っ掛かる
            this.transitionDto = new FW01_34_TransitionDto(false);
        } else if (_frameName == null) {
            this.transitionDto = new FW01_34_TransitionDto(false);
            for (String frameName : this.defaultAction.keySet()) {
                this.transitionDto.push(frameName, this.getDefaultAction(frameName, _sessionDto));
            }
        } else {
            this.transitionDto.init(_frameName);
            // this.transitionDto.push(_frameName, this.getDefaultAction(_frameName, _sessionDto));
        }
    }

    /**
     *
     * 画面遷移前処理.<br>
     *<br>
     * 概要:<br>
     *   業務Action実行前の処理を行う
     *<br>
     * @param _action アクション名
     * @throws Throwable 例外
     */
    protected void beforeTransition(final Object _action) throws Throwable {
        return;
    }
}
