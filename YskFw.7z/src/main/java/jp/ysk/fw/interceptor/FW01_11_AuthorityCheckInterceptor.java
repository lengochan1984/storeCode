/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 *  2015/01/07| 変更仕様一覧No.14                  | 3.00.00| YSK)中田
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.interceptor;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.dto.FW01_09_ErrSessionDto;
import jp.ysk.fw.dto.FW01_12_SessionDto;
import jp.ysk.fw.form.FW01_17_BaseForm;

import org.aopalliance.intercept.MethodInvocation;
import org.seasar.framework.aop.interceptors.AbstractInterceptor;

/**
 * セッションチェック処理
 * <pre>
 * [変更履歴]
 * 1.0 2009/08/28  初版
 * </pre>
 * @version 1.0 2009/08/28
 * @author  YSK)西田　浩二
 */

/**
 *
 * セッションチェック処理.<br>
 *<br>
 * 概要:<br>
 *   セッションチェック用のインターセプタークラスです
 *<br>
 */
public class FW01_11_AuthorityCheckInterceptor extends AbstractInterceptor {

    /**
     * シリアルバージョン.
     */
    private static final long serialVersionUID = 1L;

    /**
     * セッションチェック対象外Actionセット.
     */
    private Map<String, Set<String>> ignoreMap;

    /**
     * 権限チェック情報.
     */
    private Map<String, Set<String>> authorityMap;

    /**
     * 権限エラー時遷移先.
     */
    private String strRedirectPage;

    /**
     *
     * Interceptor処理.<br>
     *<br>
     * 概要:<br>
     *   セッションDTO情報をチェックする。
     *<br>
     * @param _invocation メソッド
     * @return オブジェクト
     * @throws Throwable 例外
     */
    @Override
    public Object invoke(final MethodInvocation _invocation) throws Throwable {

        FW01_12_SessionDto sessionDto = null;
        FW01_09_ErrSessionDto errDto = null;
        FW01_17_BaseForm baseForm = null;

        // FWアクション以外に実行
        if (!_invocation.getClass().getName().startsWith("jp.ysk.fw.action")) {
            // Actionクラスを取得
            Object action = _invocation.getThis();

            // Actionクラス名を抽出
            String className = action.getClass().getSimpleName().split("[$]")[0];
            String methodName = _invocation.getMethod().getName();

            // チェック対象外確認
            if (!checkIgnore(className, methodName)) {
                // チェック対象の場合
                for (Field field : action.getClass().getFields()) {
                    // セッション情報を検索
                    Object prop = field.get(action);
                    if (prop instanceof FW01_12_SessionDto) {
                        sessionDto = (FW01_12_SessionDto) prop;
                    } else if (prop instanceof FW01_09_ErrSessionDto) {
                        errDto = (FW01_09_ErrSessionDto) prop;
                    } else if (prop instanceof FW01_17_BaseForm) {
                        baseForm = (FW01_17_BaseForm) prop;
                    }

                    if (sessionDto != null && errDto != null && baseForm != null) {
                        break;
                    }
                }
                // セッションチェック
                if (sessionDto == null || sessionDto.ssn_UserID == null || FW00_19_Const.EMPTY_STR.equals(sessionDto.ssn_UserID)) {
                    errDto.ssn_strErrRedirectPage = this.strRedirectPage;
                    //                    errDto.ssn_strErrMsg = FW00_06_MessageResourceUtil.getMessage("M031");

                    if (baseForm.fw0117RequestKbn != null && "ajax".equals(baseForm.fw0117RequestKbn)) {
                        return "/FW01_20_ErrorAjax.jsp";
                    } else {
                        if (baseForm.fw0117WinMode != null && "popwin".equals(baseForm.fw0117WinMode)) {
                            return "/FW01_20_ErrorPopwin.jsp";
                        } else {
                            return "/FW01_20_Error.jsp";
                        }
                    }
                }

                // 機能利用権限チェック
                if (!authCheck(className, sessionDto)) {
                    errDto.ssn_strErrRedirectPage = this.strRedirectPage;

                    if (baseForm.fw0117RequestKbn != null && "ajax".equals(baseForm.fw0117RequestKbn)) {
                        return "/FW01_20_ErrorAjax.jsp";
                    } else {
                        if (baseForm.fw0117WinMode != null && "popwin".equals(baseForm.fw0117WinMode)) {
                            return "/FW01_20_ErrorPopwin.jsp";
                        } else {
                            return "/FW01_20_Error_404.jsp";
                        }
                    }
                }
            }
        }
        return _invocation.proceed();
    }

    /**
     * 権限チェック処理.<br>
     *<br>
     * 概要:<br>
     * セッション情報をもとに権限をチェックする。
     * プロジェクト特有の権限チェックを行う場合は、本クラスを
     *<br>
     * @param _className Actionクラス名
     * @param _sessionDto セッション情報
     * @return チェック結果(true：OK、false：権限なし）
     */
    protected boolean authCheck(final String _className, final FW01_12_SessionDto _sessionDto) {
        return true;
    }

    /**
     *
     * セッションチェック除外情報格納.<br>
     *<br>
     * 概要:<br>
     *   セッションチェック除外情報を格納する
     *<br>
     * @param _ignoreConf セッションチェック除外情報
     */
    public void putIgnoreSet(final String _ignoreConf) {
        if (this.ignoreMap == null) {
            this.ignoreMap = new HashMap<String, Set<String>>();
        }
        for (String conf : _ignoreConf.split(",")) {
            String actionName = conf.replaceAll("[(].+[)]", FW00_19_Const.EMPTY_STR);
            String methodNames = conf.substring(actionName.length()).replaceAll("[()]", FW00_19_Const.EMPTY_STR);
            Set<String> methodSet = new HashSet<String>();
            if (!"*".equals(methodNames)) {
                for (String method : methodNames.split("[|]")) {
                    methodSet.add(method);
                }
            }
            this.ignoreMap.put(actionName, methodSet);
        }
    }

    /**
     * @param _strRedirectPage 権限エラー時遷移先
     */
    public void setStrRedirectPage(final String _strRedirectPage) {
        this.strRedirectPage = _strRedirectPage;
    }

    /**
     *
     * 権限別利用制限情報セット.<br>
     *<br>
     * 概要:<br>
     *   権限別利用制限情報を設定する
     *<br>
     * @param _authorityCode 権限コード
     * @param _possibleActions 利用可能アクション
     */
    public void putAuthorityInfo(final String _authorityCode, final String _possibleActions) {
        if (this.authorityMap == null) {
            this.authorityMap = new HashMap<String, Set<String>>();
        }
        Set<String> actions = new HashSet<String>();
        if (_possibleActions != null && !FW00_19_Const.EMPTY_STR.equals(_possibleActions)) {
            for (String actionName : _possibleActions.split(",")) {
                actions.add(actionName);
            }
        }
        this.authorityMap.put(_authorityCode, actions);
    }

    /**
     *
     * 除外イベント判定処理.<br>
     *<br>
     * 概要:<br>
     *   リクエストのアクション及びメソッドが、権限チェック除外対象かどうかを判定する
     *<br>
     * @param _action アクション
     * @param _method メソッド
     * @return 可否
     */
    private boolean checkIgnore(final String _action, final String _method) {
        if (!this.ignoreMap.containsKey(_action)) {
            // アクション名が除外設定に含まれていなければ、非除外
            return false;
        } else {
            Set<String> methodSet = this.ignoreMap.get(_action);

            if (methodSet.isEmpty()) {
                // 除外メソッド設定が空の場合は、全メソッド除外対象
                return true;
            } else {
                // メソッド名が除外メソッド設定に含まれていれば除外対象
                return methodSet.contains(_method);
            }
        }
    }
}
