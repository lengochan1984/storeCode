/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.interceptor;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.dto.FW01_27_FormSessionDto;
import jp.ysk.fw.form.FW01_17_BaseForm;
import jp.ysk.fw.util.FW00_23_LoggerUtil;

import org.aopalliance.intercept.MethodInvocation;
import org.seasar.framework.aop.interceptors.AbstractInterceptor;

/**
 *
 * フォーム情報セッション管理.<br>
 *<br>
 * 概要:<br>
 *   フォーム情報のセッション管理用のインターセプタークラスです
 *<br>
 */
public class FW01_26_FormManagementInterceptor extends AbstractInterceptor {

    /**
     * シリアル番号.
     */
    private static final long serialVersionUID = 1L;

    /**
     * フォーム情報セッション管理DTO.
     */
    @Resource
    public FW01_27_FormSessionDto formSessionDto;

    /**
     * フォーム格納設定情報Map.<br>
     * <br>
     * KEY：<Action名>_<メソッド名>
     * VALUE：Form名
     */
    public Map<String, String> putFormConfig;

    /**
     * フォーム取得設定情報Map.<br>
     * <br>
     * KEY：<Action名>_<メソッド名>
     * VALUE：Form名
     */
    public Map<String, String> getFormConfig;

    /**
     * フォーム削除設定情報Map.<br>
     * <br>
     * KEY：<Action名>_<メソッド名>
     * VALUE：Form名
     */
    public Map<String, String> delFormConfig;

    /**
     * フォーム情報全削除設定情報.<br>
     * <br>
     * <Action名>_<メソッド名>
     */
    public Set<String> removeFormsConfig;

    /**
     *
     * オプションタイプ列挙帯.<br>
     *<br>
     * 概要:<br>
     *   オプションタイプの列挙帯
     *<br>
     */
    private enum OPTION_TYPE {
        /**
         * PUT.
         */
        PUT,
        /**
         * GET.
         */
        GET,
        /**
         * DEL.
         */
        DEL,
        /**
         * NONE.
         */
        NONE
    }

    /**
     *
     * コンストラクタ.
     *
     */
    public FW01_26_FormManagementInterceptor() {
        this.putFormConfig = new HashMap<String, String>();
        this.getFormConfig = new HashMap<String, String>();
        this.delFormConfig = new HashMap<String, String>();
        this.removeFormsConfig = new HashSet<String>();
    }

    /**
     *
     * セッション管理処理.<br>
     *<br>
     * 概要:<br>
     *   セッション管理処理
     *<br>
     * @param _invocation メソッド
     * @return オブジェクト
     * @throws Throwable 例外
     */
    @Override
    public Object invoke(final MethodInvocation _invocation) throws Throwable {
        // セッション管理フォーム
        FW01_17_BaseForm sessionForm = null;
        // アクションオブジェクト
        Object action = null;
        // フォームオブジェクト
        FW01_17_BaseForm form = null;
        // フォームフィールドオブジェクト
        Field formField = null;
        // アクション名
        String actionName = FW00_19_Const.EMPTY_STR;
        // メソッド名
        String methodName = FW00_19_Const.EMPTY_STR;
        // 設定取得キー
        String confKey = FW00_19_Const.EMPTY_STR;

        // FWアクション以外に実行
        if (!_invocation.getClass().getName().startsWith("jp.ysk.fw.action")) {
            // フォーム情報セッション管理確認の為のデバッグログ
            boolean debug = true;
            if (debug) {
                StringBuffer debugMsg = new StringBuffer("管理中フォーム一覧[");
                debugMsg.append(this.formSessionDto.toString());
                debugMsg.append("]");
                FW00_23_LoggerUtil.debugLog.debug(debugMsg.toString());
            }

            // Actionクラス名を抽出
            action = _invocation.getThis();
            actionName = action.getClass().getSimpleName().split("[$]")[0];

            // Method名を取得
            methodName = _invocation.getMethod().getName();

            // 設定取得キーを生成
            confKey = actionName + "_" + methodName;

            for (Field field : action.getClass().getFields()) {
                // セッション情報を検索
                Object prop = field.get(action);

                if (prop instanceof FW01_17_BaseForm) {
                    form = (FW01_17_BaseForm) prop;
                    formField = field;
                }

                if (form != null) {
                    break;
                }
            }

            if (this.removeFormsConfig.contains(confKey)) {
                // セッションクリア
                this.formSessionDto = new FW01_27_FormSessionDto();
            } else {
                if (this.getFormConfig.containsKey(confKey)) {
                    // フォーム取得
                    sessionForm = this.formSessionDto.getForm(this.getFormConfig.get(confKey));

                    // セッションから取得したフォームを設定
                    if (sessionForm != null) {
                        // セッションに管理しているフォーム情報がある場合
                        for (Field field : form.getClass().getFields()) {
                            int mod = field.getModifiers();
                            if (!Modifier.isStatic(mod)) {
                                Field sessionField = sessionForm.getClass().getField(field.getName());
                                field.set(form, sessionField.get(sessionForm));
                            }
                        }

                        formField.set(action, form);
                    }
                }

                if (this.putFormConfig.containsKey(confKey)) {
                    // フォーム格納
                    this.formSessionDto.putForm(this.putFormConfig.get(confKey), form);
                }

                if (this.delFormConfig.containsKey(confKey)) {
                    // フォーム削除
                    this.formSessionDto.removeForm(this.delFormConfig.get(confKey));
                }
            }
        }

        return _invocation.proceed();
    }

    /**
     *
     * セッション管理情報追加処理.<br>
     *<br>
     * 概要:<br>
     *   セッション管理情報を追加します
     *<br>
     * @param _formName フォーム名
     * @param _options1 オプション1
     * @param _options2 オプション2
     * @param _options3 オプション3
     */
    public void setManagementInfo(
            final String _formName, final String _options1, final String _options2, final String _options3) {

        String[] optons = new String[]{_options1, _options2, _options3};

        for (String options : optons) {
            String[] splitOpt = options.split("[:]", -1);
            if (splitOpt[0].toUpperCase().equals(OPTION_TYPE.PUT.toString())) {
                // 格納オプション時
                this.parseInfo(_formName, splitOpt[1], OPTION_TYPE.PUT);
            } else if (splitOpt[0].toUpperCase().equals(OPTION_TYPE.GET.toString())) {
                // 取得オプション時
                this.parseInfo(_formName, splitOpt[1], OPTION_TYPE.GET);
            } else if (splitOpt[0].toUpperCase().equals(OPTION_TYPE.DEL.toString())) {
                // 削除オプション時
                this.parseInfo(_formName, splitOpt[1], OPTION_TYPE.DEL);
            }
        }
    }

    /**
     *
     * フォームセッション情報全削除設定.<br>
     *<br>
     * 概要:<br>
     *   フォームセッション情報を全て削除します
     *<br>
     * @param _options オプション文字列
     */
    public void setInitSessionInfo(final String _options) {
        for (String option : _options.split("[,]")) {
            String actionName = option.replaceAll("[(].+[)]", FW00_19_Const.EMPTY_STR);
            String methodNames = option.substring(actionName.length()).replaceAll("[()]", FW00_19_Const.EMPTY_STR);

            for (String methodName : methodNames.split("[|]")) {

                this.removeFormsConfig.add(actionName + "_" + methodName);

            }
        }
    }

    /**
     *
     * オプション情報解析.<br>
     *<br>
     * 概要:<br>
     *   オプション情報解析
     *<br>
     * @param _formName フォーム名
     * @param _options オプション情報
     * @param _optionType オプション種別(PUT:フォーム格納、GET:フォーム取得、DEL：フォーム削除)
     */
    private void parseInfo(final String _formName, final String _options, final OPTION_TYPE _optionType) {
        if (!FW00_19_Const.EMPTY_STR.equals(_options)) {
            for (String option : _options.split("[,]")) {
                String actionName = option.replaceAll("[(].+[)]", FW00_19_Const.EMPTY_STR);
                String methodNames = option.substring(actionName.length()).replaceAll("[()]", FW00_19_Const.EMPTY_STR);

                if (FW00_19_Const.EMPTY_STR.equals(actionName)) {
                    // Action名省略時
                    actionName = _formName.substring(0, _formName.indexOf("Form")) + "Action";
                }

                for (String methodName : methodNames.split("[|]")) {

                    String key = actionName + "_" + methodName;

                    switch (_optionType) {
                    // フォーム格納設定の場合
                        case PUT:
                            this.putFormConfig.put(key, _formName);
                            break;
                        case GET:
                            this.getFormConfig.put(key, _formName);
                            break;
                        case DEL:
                            this.delFormConfig.put(key, _formName);
                            break;
                        default:
                            break;
                    }
                }
            }
        }
    }
}
