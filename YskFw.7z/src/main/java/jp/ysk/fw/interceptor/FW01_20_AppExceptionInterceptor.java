/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.interceptor;

import java.lang.reflect.Field;

import jp.ysk.fw.FW00_12_AppException;
import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.dto.FW01_09_ErrSessionDto;
import jp.ysk.fw.form.FW01_17_BaseForm;
import jp.ysk.fw.util.FW00_06_MessageResourceUtil;
import jp.ysk.fw.util.FW00_23_LoggerUtil;

import org.aopalliance.intercept.MethodInvocation;
import org.seasar.framework.aop.interceptors.ThrowsInterceptor;

/**
 *
 * 共通例外処理.<br>
 *<br>
 * 概要:<br>
 *   共通例外処理用のインターセプタークラスです
 *<br>
 */
public class FW01_20_AppExceptionInterceptor extends ThrowsInterceptor {

    /**
     * シリアルID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * 権限エラー時遷移先.
     */
    private String strRedirectPage;

    /**
     *
     * アプリケーション共通例外処理.<br>
     *<br>
     * 概要:<br>
     *   アプリケーション共通の例外処理を実行する
     *<br>
     * @param _e 例外
     * @param _invocation メソッド
     * @return オブジェクト
     * @throws Throwable 例外
     */
    public Object handleThrowable(final Exception _e, final MethodInvocation _invocation) throws Throwable {
        FW01_09_ErrSessionDto errDto = null;
        FW01_17_BaseForm baseForm = null;

        // Actionクラスを取得
        Object action = _invocation.getThis();

        for (Field field : action.getClass().getFields()) {
            // セッション情報を検索
            Object prop = field.get(action);
            if (prop instanceof FW01_09_ErrSessionDto) {
                errDto = (FW01_09_ErrSessionDto) prop;
            } else if (prop instanceof FW01_17_BaseForm) {
                baseForm = (FW01_17_BaseForm) prop;
            }

            if (errDto != null && baseForm != null) {
                break;
            }
        }
        if (_e instanceof FW00_12_AppException) {

            FW00_12_AppException ex = (FW00_12_AppException) _e;

            if (ex instanceof FW00_12_BusinessException) {
                if (ex.getMsgKey() != null && !FW00_19_Const.EMPTY_STR.equals(ex.getMsgKey())) {
                    String[] msgArg = ((FW00_12_BusinessException) ex).getMsgArgs();
                    String errMsg = FW00_06_MessageResourceUtil.getMessage(ex.getMsgKey(), msgArg);
                    errDto.ssn_strErrMsg = errMsg;
                }
                if (((FW00_12_BusinessException) ex).getFocusCtlId() != null
                        && !FW00_19_Const.EMPTY_STR.equals(((FW00_12_BusinessException) ex).getFocusCtlId())) {
                    errDto.ssn_strErrCtlId = ((FW00_12_BusinessException) ex).getFocusCtlId();
                }

                if (baseForm.fw0117RequestKbn != null && "ajax".equals(baseForm.fw0117RequestKbn)) {
                    return "/FW01_20_ErrorAjax.jsp";
                } else {
                    return "/FW01_20_Error_501.jsp";
                }
            } else if (ex instanceof FW00_12_AppException) {
                FW00_23_LoggerUtil.debugLog.error("Occur App Error!! see debugLog.", _e);
                if (ex.getMsgKey() != null && !FW00_19_Const.EMPTY_STR.equals(ex.getMsgKey())) {
                    errDto.ssn_strErrMsg = FW00_06_MessageResourceUtil.getMessage(ex.getMsgKey());
                }
                errDto.ssn_strErrRedirectPage = this.strRedirectPage;

                if (baseForm.fw0117RequestKbn != null && "ajax".equals(baseForm.fw0117RequestKbn)) {
                    return "/FW01_20_ErrorAjax.jsp";
                } else {
                    return "/FW01_20_Error_501.jsp";
                }
            }
        } else {
            FW00_23_LoggerUtil.debugLog.error("Occur System Error!! see debugLog.", _e);

            //            errDto.ssn_strErrMsg = FW00_06_MessageResourceUtil.getMessage("M018");

            errDto.ssn_strErrRedirectPage = this.strRedirectPage;

            if (baseForm.fw0117RequestKbn != null && "ajax".equals(baseForm.fw0117RequestKbn)) {
                return "/FW01_20_ErrorAjax.jsp";
            } else {
                return "/FW01_20_Error_501.jsp";
            }
        }
        return null;
    }


    /**
     * @param _strRedirectPage 権限エラー時遷移先
     */
    public void setStrRedirectPage(final String _strRedirectPage) {
        this.strRedirectPage = _strRedirectPage;
    }
}
