/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.interceptor;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Properties;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.dto.FW01_12_SessionDto;
import jp.ysk.fw.util.FW00_23_LoggerUtil;

import org.aopalliance.intercept.MethodInvocation;
import org.seasar.framework.aop.interceptors.AbstractInterceptor;

/**
 *
 * アクセスログ出力.<br>
 *<br>
 * 概要:<br>
 *   アクセスログの出力用インターセプタークラス
 *<br>
 */
public class FW00_27_AccessLogInterceptor extends AbstractInterceptor {

    /**
     * シリアル番号.
     */
    private static final long serialVersionUID = 1L;

    /**
     * プロセス名一覧情報.
     */
    private static Properties processNames;

    /**
     *
     * プロセス名取得.<br>
     *<br>
     * 概要:<br>
     *   プロセス名を取得する
     *<br>
     * @param _processClass プロセスクラス名
     * @return プロセス名
     */
    private synchronized String getProcessName(final String _processClass) {
        String processName = FW00_19_Const.EMPTY_STR;

        try {
            if (processNames == null) {
                processNames = new Properties();
                processNames.load(FW00_27_AccessLogInterceptor.class.getResourceAsStream("/accessLog.properties"));
            }
            processName = processNames.getProperty(_processClass);

            if (processName == null) {
                processName = processNames.getProperty("FW00_27.notdefined") + _processClass;
            }

        } catch (IOException e) {
            FW00_23_LoggerUtil.errorLog.error(FW00_19_Const.EMPTY_STR, e);
        }
        return processName;
    }

    /**
     *
     * アクセスログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   アクセスログを出力する
     *<br>
     * @param _invocation メソッド
     * @return オブジェクト
     * @throws Throwable 例外
     */
    @Override
    public Object invoke(final MethodInvocation _invocation) throws Throwable {
        // プロセスクラス名
        String processClass = FW00_19_Const.EMPTY_STR;
        // プロセス名
        String processName = FW00_19_Const.EMPTY_STR;
        // メソッド名(Webのみ)
        String methodName = FW00_19_Const.EMPTY_STR;
        // ユーザID(Webのみ)
        String userId = FW00_19_Const.EMPTY_STR;
        // アクセスログ出力文字列
        StringBuffer accessLog = null;

        try {
            // FW以外に実行
            if (!_invocation.getClass().getName().startsWith("jp.ysk.fw")) {
                processClass = _invocation.getThis().getClass().getSimpleName().split("[$]")[0];

                processName = this.getProcessName(processClass);
                accessLog = new StringBuffer(processName);

                if (processClass.endsWith(FW00_23_LoggerUtil.ACTION_CLASS_FOOTER)) {
                    // Web処理の場合
                    FW01_12_SessionDto sessionDto = null;

                    methodName = _invocation.getMethod().getName();

                    accessLog.append(FW00_19_Const.SPACE);
                    accessLog.append(FW00_23_LoggerUtil.METHOD_NAME_HEADER);
                    accessLog.append(FW00_19_Const.COLON_STR);
                    accessLog.append(methodName);

                    for (Field field : _invocation.getThis().getClass().getFields()) {
                        // セッション情報を検索
                        Object prop = field.get(_invocation.getThis());
                        if (prop instanceof FW01_12_SessionDto) {
                            sessionDto = (FW01_12_SessionDto) prop;
                        }

                        if (sessionDto != null) {
                            break;
                        }
                    }


                    if (sessionDto != null) {
                        String ssn_CustomerCD = sessionDto.ssn_CustomerCD;
                        if (ssn_CustomerCD != null && !FW00_19_Const.EMPTY_STR.equals(ssn_CustomerCD)) {
                            accessLog.append(FW00_19_Const.COMMA_STR);
                            accessLog.append(FW00_23_LoggerUtil.CUSTOMER_ID_HEADER);
                            accessLog.append(FW00_19_Const.COLON_STR);
                            accessLog.append(ssn_CustomerCD);
                        }
                        String ssn_UserId = sessionDto.ssn_UserID;
                        if (ssn_UserId != null && !FW00_19_Const.EMPTY_STR.equals(ssn_UserId)) {
                            userId = ssn_UserId;
                            accessLog.append(FW00_19_Const.COMMA_STR);
                            accessLog.append(FW00_23_LoggerUtil.USER_ID_HEADER);
                            accessLog.append(FW00_19_Const.COLON_STR);
                            accessLog.append(userId);
                        }
                    }

                    FW00_23_LoggerUtil.accessLog.info(accessLog.toString());

                } else if (processClass.endsWith("Logic")) {
                    // データ連携処理の場合
                    FW00_23_LoggerUtil.accessLog.info(accessLog.toString());

                } else if (processClass.endsWith("Batch")) {
                    // バッチ処理の場合
                    FW00_23_LoggerUtil.accessLog.info(accessLog.toString());
                    //                } else if (processClass.endsWith("Service")) {
                    //                    // サービス処理の場合
                    //                    Method method = _invocation.getMethod();
                }
            }
        } catch (Exception e) {
            FW00_23_LoggerUtil.errorLog.error(FW00_19_Const.EMPTY_STR, e);
        }

        return _invocation.proceed();
    }

}
