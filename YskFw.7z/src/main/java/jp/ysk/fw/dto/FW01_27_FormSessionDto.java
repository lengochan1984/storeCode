/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import jp.ysk.fw.form.FW01_17_BaseForm;

import org.seasar.framework.container.annotation.tiger.Component;
import org.seasar.framework.container.annotation.tiger.InstanceType;

/**
 * フォーム情報セッションDTO
 * <pre>
 * [変更履歴]
 * 1.0 2009/09/07  初版
 * </pre>
 * @version 1.0 2009/09/07
 * @author  YSK)西田　浩二
 */

/**
 *
 * フォーム情報セッションDTO.<br>
 *<br>
 * 概要:<br>
 *   フォーム情報用のセッションDTOクラス
 *<br>
 */
@Component(instance = InstanceType.SESSION)
public class FW01_27_FormSessionDto implements Serializable {
    /**
     * シリアルID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * セッション管理Map.<br>
     * <br>
     * KEY：フォーム名<br>
     * VALUE：フォーム情報
     */
    private Map<String, FW01_17_BaseForm> formSessionInfo;

    /**
     *
     * コンストラクタ.
     *
     */
    public FW01_27_FormSessionDto() {
        this.formSessionInfo = new HashMap<String, FW01_17_BaseForm>();
    }

    /**
     *
     * フォーム情報セッション格納.<br>
     *<br>
     * 概要:<br>
     *   フォーム情報セッションを格納する
     *<br>
     * @param _formName フォーム名
     * @param _form フォーム情報
     */
    public void putForm(final String _formName, final FW01_17_BaseForm _form) {
        this.formSessionInfo.put(_formName, _form);
    }

    /**
     * 管理中のフォームID一式を返却する.
     *
     * @return フォールID文字列
     */
    public String toString() {
        StringBuffer sb = new StringBuffer();
        for (String formName:this.formSessionInfo.keySet()) {
            if (sb.length() != 0) {
                sb.append(",");
            }
            sb.append(formName);
        }
        return sb.toString();
    }

    /**
     * フォーム情報取得.
     * @param _formName フォーム名
     * @return フォーム情報
     */
    public FW01_17_BaseForm getForm(final String _formName) {
        return this.formSessionInfo.remove(_formName);
    }

    /**
     * フォーム情報削除.
     * @param _formName フォーム名
     */
    public void removeForm(final String _formName) {
        this.formSessionInfo.remove(_formName);
    }
}
