/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import org.seasar.framework.container.annotation.tiger.Component;
import org.seasar.framework.container.annotation.tiger.InstanceType;

/**
 * 画面遷移情報セッションDTO
 * <pre>
 * [変更履歴]
 * 1.0 2009/09/25  初版
 * </pre>
 * @version 1.0 2009/09/25
 * @author  YSK)西田　浩二
 */

/**
 *
 * 画面遷移情報セッションDTO.<br>
 *<br>
 * 概要:<br>
 *   画面遷移情報用のセッションDTOクラス
 *<br>
 */
@Component(instance = InstanceType.SESSION)
public class FW01_34_TransitionDto implements Serializable {

    /**
     * シリアルID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * 画面遷移情報スタックMap.
     */
    private Map<String, Stack<String>> transitionStackInfo;

    /**
     * セッションタイムアウトフラグ.
     */
    private boolean timeoutFlg = false;

    /**
     * コンストラクタ.
     */
    public FW01_34_TransitionDto() {
        this.transitionStackInfo = new HashMap<String, Stack<String>>();
        this.timeoutFlg = true;
    }

    /**
     * コンストラクタ.
     * @param _timeoutFlg タイムアウト有無
     */
    public FW01_34_TransitionDto(final boolean _timeoutFlg) {
        this.transitionStackInfo = new HashMap<String, Stack<String>>();
        this.timeoutFlg = _timeoutFlg;
    }

    /**
     *
     * 初期化処理.<br>
     *<br>
     * 概要:<br>
     *   特定フレームの管理情報を初期化する
     *<br>
     * @param _frameName フレーム名
     */
    public void init(final String _frameName) {
        this.transitionStackInfo.remove(_frameName);
    }

    /**
     *
     * アクション格納.<br>
     *<br>
     * 概要:<br>
     *   特定フレームのスタックの先頭にアクション名を追加する
     *<br>
     * @param _frameName フレーム名
     * @param _actionName アクション名
     */
    public void push(final String _frameName, final String _actionName) {

        if (!this.transitionStackInfo.containsKey(_frameName)) {
            this.transitionStackInfo.put(_frameName, new Stack<String>());
        }
        this.transitionStackInfo.get(_frameName).push(_actionName);
    }

    /**
     *
     * アクション判別処理(最新遷移比較).<br>
     *<br>
     * 概要:<br>
     *   最後に遷移したアクションと一致するかどうかを確認する
     *<br>
     * @param _frameName フレーム名
     * @param _actionName アクション名
     * @return 成否
     */
    public boolean isTopAction(final String _frameName, final String _actionName) {
        Stack<String> frameStack = this.transitionStackInfo.get(_frameName);

        if (frameStack != null && !frameStack.isEmpty()) {
            return _actionName.equals(frameStack.peek());
        } else {
            return false;
        }
    }

    /**
     *
     * アクション判別処理(一世代前遷移比較).<br>
     *<br>
     * 概要:<br>
     *   一世代前に画面遷移したアクションと一致するかどうかを確認する
     *<br>
     * @param _frameName フレーム名
     * @param _actionName アクション名
     * @return 成否
     */
    public boolean isSecondAction(final String _frameName, final String _actionName) {
        Stack<String> frameStack = this.transitionStackInfo.get(_frameName);

        if (frameStack != null && !frameStack.isEmpty() && frameStack.size() > 1) {
            String thisAction = frameStack.pop();
            boolean result = _actionName.equals(frameStack.peek());
            frameStack.push(thisAction);
            this.transitionStackInfo.put(_frameName, frameStack);
            return result;
        } else {
            return false;
        }
    }

    /**
     *
     * 空要素判別.<br>
     *<br>
     * 概要:<br>
     *   要素が無いかどうかを判別する
     *<br>
     * @return 判定結果
     */
    public boolean isEmpty() {
        return this.transitionStackInfo.isEmpty();
    }

    /**
     *
     * 空要素判別.<br>
     *<br>
     * 概要:<br>
     *   要素が無いかどうかを判別する
     *<br>
     * @param _frameName フレーム名
     * @return 判定結果
     */
    public boolean isEmptyFrame(final String _frameName) {
        if (this.transitionStackInfo.containsKey(_frameName)) {
            return this.transitionStackInfo.get(_frameName).empty();
        } else {
            return true;
        }
    }

    /**
     *
     * アクション取得処理(最新遷移).<br>
     *<br>
     * 概要:<br>
     *   最後に遷移したアクションを取得する
     *<br>
     * @param _frameName フレーム名
     * @return アクション名
     */
    public String getTopAction(final String _frameName) {
        Stack<String> frameStack = this.transitionStackInfo.get(_frameName);
        String actionName = frameStack.peek();
        return actionName;
    }

    /**
     *
     * アクション取得処理(一世代前遷移).<br>
     *<br>
     * 概要:<br>
     *   一世代前に遷移したアクションを取得する<br>
     *   取得したアクションより上位のスタック情報は削除する
     *<br>
     * @param _frameName フレーム名
     * @return アクション名
     */
    public String getSecondAction(final String _frameName) {
        Stack<String> frameStack = this.transitionStackInfo.get(_frameName);
        frameStack.pop();
        String actionName = frameStack.peek();
        this.transitionStackInfo.put(_frameName, frameStack);
        return actionName;
    }

    /**
     *
     * スタック削除.<br>
     *<br>
     * 概要:<br>
     *   パラメータ世代分のスタック情報を削除する
     *<br>
     * @param _frameName フレーム名
     * @param _generation 世代
     */
    public void removeActions(final String _frameName, final int _generation) {
        Stack<String> frameStack = this.transitionStackInfo.get(_frameName);
        for (int i = 0; i < _generation; i++) {
            frameStack.pop();
        }
        this.transitionStackInfo.put(_frameName, frameStack);
    }

    /**
     *
     * タイムアウトフラグ取得.<br>
     *<br>
     * 概要:<br>
     *   タイムアウトフラグを取得する
     *<br>
     * @return タイムアウトフラグ
     */
    public boolean isTimeoutFlg() {
        return this.timeoutFlg;
    }
}
