/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+=======================================+========+==============
 *  DATE      | Comments                              | Rev    | SIGN
 * ===========+=======================================+========+==============
 *  2014/01/20| 新規作成                              | 1.00.00| YSK)植山
 *  2016/03/12| <40000-028> Ver.4.00.00 変更仕様No.28 | 4.00.00| US)甲斐
 * -----------+---------------------------------------+--------+--------------
 */
package jp.ysk.fw.dto;

import java.io.Serializable;

import org.seasar.framework.container.annotation.tiger.Component;
import org.seasar.framework.container.annotation.tiger.InstanceType;

/**
 *
 * エラー情報セッションDTO.<br>
 *<br>
 * 概要:<br>
 *   エラー情報用のセッションDTOクラス
 *<br>
 */
@Component(instance = InstanceType.REQUEST)
public class FW01_09_ErrSessionDto implements Serializable {

    /**
     * シリアルバージョン.
     */
    private static final long serialVersionUID = 1L;

    /**
     * エラー時リダイレクトページ.
     */
    public String ssn_strErrRedirectPage;

    /**
     * エラー時表示メッセージ.
     */
    public String ssn_strErrMsg;

    /**
     * エラー時フォーカスコントロールID.
     */
    public String ssn_strErrCtlId;

    /**
     * エラー時関数実行フラグ.
     */
    public String ssn_strErrLoadFunctionFlg;

    /**
     *
     * 初期化処理.<br>
     *<br>
     * 概要:<br>
     *   初期化処理を実行する
     *<br>
     */
    public void initialize() {
        this.ssn_strErrRedirectPage = "";
        this.ssn_strErrMsg = "";
        this.ssn_strErrLoadFunctionFlg = "";
    }
}
