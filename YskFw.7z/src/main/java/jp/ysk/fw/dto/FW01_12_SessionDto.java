/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.dto;

import java.io.Serializable;

import org.seasar.framework.container.annotation.tiger.Component;
import org.seasar.framework.container.annotation.tiger.InstanceType;

/**
 * セッション情報DTO
 * <pre>
 * [変更履歴]
 * 1.0 2009/08/28  初版
 * </pre>
 * @version 1.0 2009/08/28
 * @author  YSK)西田　浩二
 */

/**
 *
 * セッション情報DTO.<br>
 *<br>
 * 概要:<br>
 *   セッション情報用のDTOクラス
 *<br>
 */
@Component(instance = InstanceType.SESSION)
public class FW01_12_SessionDto implements Serializable {

    /**
     * シリアルバージョン.
     */
    private static final long serialVersionUID = 1L;

    /**
     * 顧客CD定数.
     */
    public static final String SSN_CUSTOMER_CD = "ssn_CustomerCD";

    /**
     * ユーザID定数.
     */
    public static final String SSN_USERID = "ssn_UserID";

    /**
     * ユーザ名_姓定数.
     */
    public static final String SSN_USERNAMEFIRST = "ssn_UserNameFirst";

    /**
     * ユーザ名_名定数.
     */
    public static final String SSN_USERNAMELAST = "ssn_UserNameLast";

    /**
     * 権限コード定数.
     */
    public static final String SSN_AUTHORITYCODD = "ssn_AuthorityCode";

    /**
     * 顧客CD.
     */
    public String ssn_CustomerCD = null;

    /**
     * ユーザID.
     */
    public String ssn_UserID = null;

    /**
     * ユーザ名_姓.
     */
    public String ssn_UserNameFirst = null;

    /**
     * ユーザ名_名.
     */
    public String ssn_UserNameLast = null;

    /**
     * 権限コード.
     */
    public String ssn_AuthorityCode = null;

    /**
     *
     * 初期化処理.<br>
     *<br>
     * 概要:<br>
     *   初期化処理を実行する
     *<br>
     */
    public void initialize() {
        this.ssn_UserID = "";
        this.ssn_UserNameFirst = "";
        this.ssn_UserNameLast = "";
        this.ssn_AuthorityCode = "";
    }
}
