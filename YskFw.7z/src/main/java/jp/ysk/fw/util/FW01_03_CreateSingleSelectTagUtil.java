/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/27| 新規作成                           | 1.00.00| YSK)森山
 *  2014/12/21| <20000-026> 仕様変更No.9           | 3.00.00| YSK)中田
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.util;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.seasar.framework.beans.util.BeanMap;

/**
 *
 * 単一選択コントロール情報取得処理.<br>
 *<br>
 * 概要:<br>
 *   {??クラス説明??}
 *<br>
 */
public class FW01_03_CreateSingleSelectTagUtil {

    /**
     * 情報キー：オプションタグVALUE.
     */
    public static final String FW01_03_KEY_OPT_VALUE = "value";

    /**
     * 情報キー：オプションタグTEXT.
     */
    public static final String FW01_03_KEY_OPT_TEXT = "text";

    /**
     * 情報キー：選択フラグ.
     */
    public static final String FW01_03_KEY_OPT_SELECTED = "selected";

    /**
     *
     * 追加位置列挙体.<br>
     *<br>
     * 概要:<br>
     *   追加種別
     *<br>
     */
    public static enum ADD_TYPE {
        /**
         * 最初.
         */
        FIRST,
        /**
         * 最後.
         */
        LAST;
    }

    /**
     * 定数：SELECTED.
     */
    public static final String FLG_SELECTED = "1";

    /**
     * 定数：NOT SELECTED.
     */
    public static final String FLG_NOTSELECTED = "0";

    /**
     * 文字列定数：NULL.
     */
    public static final String STR_NULL = "NULL";

    /**
     * オプション一覧.
     */
    private List<Map<String, String>> options;

    /**
     * Map内のOPTIONタグVALUE属性設定キー.
     */
    private String key_optId;

    /**
     * Map内のOPTIONタグTEXT設定キー.
     */
    private String key_optName;

    /**
     * Map内のOPTIONタグSELECTED対象設定キー.
     */
    private String key_optSelFlg;

    /**
     * 表示項目最大文字長.
     */
    private int byteLength;

    /**
     * コンストラクタ(初期選択フラグ項目有時).
     * @param _key_optId ： OPTION値対象項目名
     * @param _key_optName : 表示値対象項目名
     * @param _key_optSelFlg ：初期選択フラグ対象項目名
     * @param _options ：オプション一覧情報
     * @param _byteLength ：表示項目最大文字長
     */
    public FW01_03_CreateSingleSelectTagUtil(
            final String _key_optId, final String _key_optName, final String _key_optSelFlg,
            final List<BeanMap> _options, final int _byteLength) {

        this.key_optId = _key_optId;
        this.key_optName = _key_optName;
        this.key_optSelFlg = _key_optSelFlg;
        this.byteLength = _byteLength;
        this.parseOptions(_options);
    }

    /**
     * コンストラクタ(初期選択フラグ項目無時).
     * @param _key_optId ：OPTION値対象項目名
     * @param _key_optName ：OPTION表示値対象項目名
     * @param _options ：オプション一覧情報
     * @param _byteLength ：表示項目最大文字長
     */
    public FW01_03_CreateSingleSelectTagUtil(
            final String _key_optId, final String _key_optName, final List<BeanMap> _options, final int _byteLength) {

        this.key_optId = _key_optId;
        this.key_optName = _key_optName;
        this.byteLength = _byteLength;
        this.parseOptions(_options);
    }

    /**
     * オプション追加.
     * @param _addType 追加位置
     * @param _optionId 追加オプションValue値
     * @param _selected 選択フラグ
     */
    public void addOption(
            final ADD_TYPE _addType, final String _optionId, final boolean _selected) {
        Map<String, String> option = new HashMap<String, String>();

        option.put(FW01_03_KEY_OPT_VALUE, _optionId);
        option.put(FW01_03_KEY_OPT_TEXT, "");
        //        option.put(FW01_03_KEY_OPT_TEXT,
        //            FW00_21_StringByteCutUtil.cutString(FW00_06_MessageResourceUtil.getMessage(_msgKey),
        //                this.byteLength, "ms932", "...", ' '));

        if (_selected) {
            option.put(FW01_03_KEY_OPT_SELECTED, FLG_SELECTED);
        }

        switch (_addType) {
            case FIRST:
                this.options.add(0, option);
                break;
            default:
                this.options.add(option);
                break;
        }
    }

    /**
     *
     * 項目情報取得.
     * @return オプション
     */
    public List<Map<String, String>> getItemList() {
        return this.options;
    }

    /**
     * パラメータ：オプション一覧情報解析.
     * @param _options オプション
     */
    private void parseOptions(final List<BeanMap> _options) {
        this.options = new ArrayList<Map<String, String>>();

        for (BeanMap beanMap : _options) {
            Map<String, String> option = new HashMap<String, String>();
            if (beanMap.get(this.key_optId) != null) {
                option.put(FW01_03_KEY_OPT_VALUE, beanMap.get(this.key_optId).toString());
            } else {
                option.put(FW01_03_KEY_OPT_VALUE, STR_NULL);
            }
            option.put(FW01_03_KEY_OPT_TEXT, FW00_21_StringByteCutUtil.cutString((String) beanMap.get(this.key_optName),
                    this.byteLength, "ms932", "...", ' '));
            if (this.key_optSelFlg != null && !this.key_optSelFlg.equals("")) {
                if (beanMap.get(this.key_optSelFlg) != null && beanMap.get(this.key_optSelFlg).equals(FLG_SELECTED)) {
                    option.put(FW01_03_KEY_OPT_SELECTED, FLG_SELECTED);
                }
            }
            this.options.add(option);
        }
    }
}
