/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/27| 新規作成                           | 1.00.00| YSK)森山
 *  2014/11/17| <15000-104> 故障苦情No.15000-010   | 2.00.00| YSK)中田
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.util;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;

import jp.ysk.fw.FW00_12_AppException;

/**
 *
 * 文字列バイトカット処理.<br>
 *<br>
 * 概要:<br>
 *   文字列をバイトカット用のユーティリティクラスです
 *<br>
 */
public class FW00_21_StringByteCutUtil {

    /**
     *
     * コンストラクタ.
     *
     */
    protected FW00_21_StringByteCutUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     *
     * バイトカット文字列編集処理.<br>
     *<br>
     * 概要:<br>
     *   対象文字列を指定した文字コードのバイト数でカットする。
     *<br>
     * @param _str 対象文字列
     * @param _cutByte カットバイト数
     * @param _chrCde 文字コード
     * @param _suffix 付加文字列
     * @param _addChr 不足埋め文字
     * @return バイトカット＋カット終端 文字列
     */
    public static String cutString(final String _str, final int _cutByte, final String _chrCde,
            final String _suffix, final char _addChr) {
        try {
            if (_cutByte != -1) {
                byte[] original = _str.getBytes(_chrCde);

                if (original.length == _cutByte) {
                    // 指定バイト数と同長の場合
                    return _str;
                } else if (original.length < _cutByte) {
                    // 指定バイト未満の場合、不足埋め文字で補てん
                    StringBuffer sb = new StringBuffer(_str);
                    int addByte = _cutByte - original.length;
                    int addCharByte = Character.toString(_addChr).getBytes(_chrCde).length;

                    for (int i = 0; i < addByte / addCharByte; i++) {
                        sb.append(_addChr);
                    }
                    return sb.toString();
                } else {
                    // 指定バイト超過の場合
                    byte[] cutAry = Arrays.copyOfRange(original, 0, _cutByte);
                    String cutStr = new String(cutAry, _chrCde);

                    StringBuffer sb = new StringBuffer();

                    for (int i = 0; i < cutStr.length(); i++) {
                        if (_str.charAt(i) == cutStr.charAt(i)) {
                            sb.append(cutStr.charAt(i));
                        } else {
                            break;
                        }
                    }
                    // カット終端文字列を付与
                    sb.append(_suffix);
                    return sb.toString();
                }
            } else {
                return _str;
            }
        } catch (UnsupportedEncodingException e) {
            throw new FW00_12_AppException(e);
        }
    }

    /**
     *
     * バイトカット文字列編集処理.<br>
     *<br>
     * 概要:<br>
     *   対象文字列を指定した文字コードのバイト数で前方をカットする。
     *<br>
     * @param _str 対象文字列
     * @param _cutByte カットバイト数
     * @param _chrCde 文字コード
     * @param _suffix 付加文字列
     * @param _addChr 不足埋め文字
     * @return バイトカット＋カット終端 文字列
     */
    public static String cutFrontString(final String _str, final int _cutByte, final String _chrCde,
            final String _suffix, final char _addChr) {
        try {
            if (_cutByte != -1) {
                byte[] original = _str.getBytes(_chrCde);

                if (original.length == _cutByte) {
                    // 指定バイト数と同長の場合
                    return _str;
                } else if (original.length < _cutByte) {
                    // 指定バイト未満の場合、不足埋め文字で補てん
                    StringBuffer sb = new StringBuffer();
                    int addByte = _cutByte - original.length;
                    int addCharByte = Character.toString(_addChr).getBytes(_chrCde).length;

                    for (int i = 0; i < addByte / addCharByte; i++) {
                        sb.append(_addChr);
                    }
                    sb.append(_str);
                    return sb.toString();
                } else {
                    // 終端からバイト数をチェックしていく
                    int addByte = 0;
                    char[] arrayChars = _str.toCharArray();
                    String cutStr = "";

                    for (int i = arrayChars.length - 1; i >= 0; i--) {

                        byte[] arrayBytes = String.valueOf(arrayChars[i]).getBytes(_chrCde);
                        addByte += arrayBytes.length;

                        // 文字列バイト長がカットバイト長を超えていないかを確認
                        if (addByte > _cutByte) {
                            // カットバイト長を超えているため、文字を格納せず終了
                            break;
                        } else if (addByte == _cutByte) {
                            // カットバイト長と同じサイズになったので、文字を格納して処理終了
                            cutStr =  String.valueOf(arrayChars[i]) + cutStr;
                            break;
                        } else {
                            // カットバイト長を超えていないため、処理継続
                            // ⇒no work
                            cutStr =  String.valueOf(arrayChars[i]) + cutStr;
                        }
                    }

                    // カット開始文字列を付与
                    StringBuffer sb = new StringBuffer(_suffix);
                    sb.append(cutStr);

                    return sb.toString();
                }
            } else {
                return _str;
            }
        } catch (UnsupportedEncodingException e) {
            throw new FW00_12_AppException(e);
        }
    }

    /**
     *
     * バイトカット処理.<br>
     *<br>
     * 概要:<br>
     *   対象文字列を指定した文字コードでカットバイト数になるようにカットする。
     *<br>
     * @param _str 対象文字列
     * @param _cutByte カットバイト数
     * @param _charCode 文字コード
     * @return カットした文字列
     */
    public static String cutString(final String _str, final int _cutByte, final String _charCode) {
        try {
            if (_cutByte != -1) {
                byte[] original = _str.getBytes(_charCode);

                if (original.length <= _cutByte) {
                    return _str;
                } else {
                    byte[] cutAry = Arrays.copyOfRange(original, 0, _cutByte);
                    String cutStr = new String(cutAry, _charCode);

                    StringBuffer sb = new StringBuffer();

                    for (int i = 0; i < cutStr.length(); i++) {
                        if (_str.charAt(i) == cutStr.charAt(i)) {
                            sb.append(cutStr.charAt(i));
                        } else {
                            break;
                        }
                    }
                    return sb.toString();
                }
            } else {
                return _str;
            }
        } catch (UnsupportedEncodingException e) {
            throw new FW00_12_AppException(e);
        }
    }
}
