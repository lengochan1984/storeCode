/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/02/23| 新規作成                           | 1.00.00| YSK)森山
 *  2014/12/05| <20000-009> 変更仕様No.7           | 3.00.00| US)楢崎
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.util;

import java.util.Map;

import jp.ysk.fw.action.FW01_10_ListAction;

import org.seasar.extension.jdbc.AutoSelect;
import org.seasar.extension.jdbc.SqlFileSelect;

/**
 *
 * 一覧データオフセット処理.<br>
 *<br>
 * 概要:<br>
 *   一覧データをオフセット
 *<br>
 * @param <E>
 */
public class FW00_22_DataListOffSetUtil<E> {

    /**
     * 件数絞込み付与(SQLファイル無し).
     * @param _sqlObject SQL情報
     * @param _offsetInfo オフセット情報
     * @return 検索結果
     */
    public AutoSelect<E> offsetDataList(
            final AutoSelect<E> _sqlObject, final Map<String, Integer> _offsetInfo) {
        // 一覧表示件数を取得
        long dispCnt = _offsetInfo.get(FW01_10_ListAction.OFFSET_INFO_LIST_CNT);
        // ページ数を取得
        long pageNo = _offsetInfo.get(FW01_10_ListAction.OFFSET_INFO_DISP_PAGE);

        // データ開始位置(START：0)
        long offset = (pageNo - 1) * dispCnt;

        // 取得件数(=表示件数)
        long limit = dispCnt;

        // limitが設定されている場合、取得・代入する
        if (_offsetInfo.containsKey(FW01_10_ListAction.OFFSET_INFO_LIMIT_CNT)) {
            limit = _offsetInfo.get(FW01_10_ListAction.OFFSET_INFO_LIMIT_CNT);
        }

        return _sqlObject.offset(new Long(offset).intValue()).limit(new Long(limit).intValue());
    }

    /**
     * 件数絞込み付与(SQLファイル).
     * @param _sqlObject SQL情報
     * @param _offsetInfo オフセット情報
     * @return 検索結果
     */
    public SqlFileSelect<E> offsetDataListBySqlFile(
            final SqlFileSelect<E> _sqlObject, final Map<String, Integer> _offsetInfo) {

        // 一覧表示件数を取得
        long dispCnt = _offsetInfo.get("intListCnt");
        // ページ数を取得
        long pageNo = _offsetInfo.get("intDispPage");

        // データ開始位置(START：0)
        long offset = (pageNo - 1) * dispCnt;

        // 取得件数(=表示件数)
        long limit = dispCnt;

        // limitが設定されている場合、取得・代入する
        if (_offsetInfo.containsKey(FW01_10_ListAction.OFFSET_INFO_LIMIT_CNT) && _offsetInfo.get(FW01_10_ListAction.OFFSET_INFO_LIMIT_CNT) != null) {
            limit = _offsetInfo.get(FW01_10_ListAction.OFFSET_INFO_LIMIT_CNT);
        }

        return _sqlObject.offset(new Long(offset).intValue()).limit(new Long(limit).intValue());
    }
}
