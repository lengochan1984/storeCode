/*
 * **************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **************************************************************************
 * ===========+======================================+========+==============
 *  DATE      | Comments                             | Rev    | SIGN
 * ===========+======================================+========+==============
 *  2014/04/16| 新規作成                             | 1.00.00| YSK)植山
 *  2014/07/17| <10000-152>リリース後障害対応(No.024)| 1.01.00| YSK)中田
 *  2016/03/08| <30101-004>故障苦情No.30100-015      | 4.00.00| US)萩尾
 * -----------+--------------------------------------+--------+--------------
 */

package jp.ysk.fw.util;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import jp.ysk.fw.FW00_19_Const;


/**
 *
 * メールSend処理.<br>
 *<br>
 * 概要:<br>
 *   メールを送信する処理
 *<br>
 */
public class FW00_08_SendMailUtil {

    /**
     * 文字コードを設定する.
     */
    private static final String CHAR_CODE = FW00_19_Const.FWCST_CD_MAIL_UTF_8;

    /**
     * ログメッセージに使用するキーを設定する.
     */
    private static final String LOG_KEY = "M024";

    /**
     * 宛先アドレス.
     */
    public static final String TO_ADDRESS = "toAddress";

    /**
     * IPアドレス.
     */
    public static final String IP_ADDRESS = "ipAddress";

    /**
     * 送信元アドレス.
     */
    public static final String FROM_ADDRESS = "fromAddress";

    /**
     * 送信元名称.
     */
    public static final String FROM_NAME = "fromName";

    /**
     * 内容.
     */
    public static final String TEXT = "text";

    /**
     * 題名.
     */
    public static final String SUBJECT = "subject";

    /**
     * メール情報.
     */
    private Map<String, Object> mailInfo;

    /**
     * セッション.
     */
    private Session session;

    /**
     * 転送.
     */
    private Transport transport;

    /**
     *
     * コンストラクタ.
     *
     * @param _mailInfo メール情報
     */
    public FW00_08_SendMailUtil(final Map<String, Object> _mailInfo) {
        this.mailInfo = _mailInfo;

        Properties prop = new Properties();
        prop.put("mail.smtp.host", _mailInfo.get(IP_ADDRESS));
        prop.put("mail.smtp.connectiontimeout", "5000");
        prop.put("mail.smtp.timeout", "5000");
        //        prop.put("mail.smtp.quitwait", "true");

        this.session = Session.getInstance(prop, null);

        try {
            this.transport = this.session.getTransport("smtp");
        } catch (NoSuchProviderException e) {
            FW00_23_LoggerUtil.errorLog.error("stmp connection error.", e);
        }
    }

    /**
     *
     * 接続.<br>
     *<br>
     * 概要:<br>
     *   接続する
     *<br>
     * @return 成否
     */
    private boolean connect() {
        try {
            FW00_23_LoggerUtil.debugLog.debug("stmp connection open.");
            this.transport.connect();
            return true;
        } catch (MessagingException e) {
            FW00_23_LoggerUtil.errorLog.error("stmp connection error.", e);
            return false;
        }
    }

    /**
     *
     * 閉じる.<br>
     *<br>
     * 概要:<br>
     *   閉じる
     *<br>
     */
    private void close() {
        try {
            if (this.transport != null && this.transport.isConnected()) {
                this.transport.close();
                FW00_23_LoggerUtil.debugLog.debug("stmp connection close.");
            }
        } catch (MessagingException e) {
            FW00_23_LoggerUtil.errorLog.error("stmp close error.", e);
        }
    }

    /**
     *
     * メール送信.<br>
     *<br>
     * 概要:<br>
     *   メールを送信する
     *<br>
     * @param _toArray TO送信アドレスリスト
     * @param _ccArray CC送信アドレスリスト
     * @param _bccArray BCC送信アドレスリスト
     */
    public void sendMail(final InternetAddress[] _toArray, final InternetAddress[] _ccArray, final InternetAddress[] _bccArray) {
        this.send(_toArray, _ccArray, _bccArray);
    }

    /**
     *
     * メール送信.<br>
     *<br>
     * 概要:<br>
     *   メールを送信する
     *<br>
     * @param _toAddresList 送信アドレスリスト
     */
    public void sendMail(final Map<InternetAddress, String> _toAddresList) {
        InternetAddress[] addressList = new InternetAddress[_toAddresList.size()];
        int i = 0;
        for (InternetAddress toAddr : _toAddresList.keySet()) {
            addressList[i++] = toAddr;
        }
        this.send(addressList);
    }

    /**
     *
     * メール送信.<br>
     *<br>
     * 概要:<br>
     *   メールを送信する
     *<br>
     * @param _toAddress 送信アドレス
     */
    public void sendMail(final InternetAddress _toAddress) {
        InternetAddress[] addressList = new InternetAddress[] {_toAddress};
        this.send(addressList);
    }

    /**
     *
     * 送信.<br>
     *<br>
     * 概要:<br>
     *   送信する
     *<br>
     * @param _toAddressList 送信アドレスリスト
     */
    private void send(final InternetAddress[] _toAddressList) {
        if (this.connect()) {
            int idx = 0;
            try {
                MimeMessage mm = new MimeMessage(this.session);
                mm.setFrom(new InternetAddress((String) this.mailInfo.get(FROM_ADDRESS), (String) this.mailInfo.get(FROM_NAME), CHAR_CODE));
                mm.setSubject((String) this.mailInfo.get(SUBJECT), CHAR_CODE);
                mm.setText((String) this.mailInfo.get(TEXT), CHAR_CODE);
                mm.setHeader("Content-Type", "text/plain; charset=\"" + CHAR_CODE + "\"");
                // PHS,携帯用文字化け対策
                mm.setHeader("Content-Transfer-Encoding", "7bit");
                mm.setSentDate(new Date());

                for (InternetAddress address : _toAddressList) {
                    mm.setRecipient(Message.RecipientType.TO, address);
                    this.transport.sendMessage(mm, mm.getAllRecipients());
                    idx++;
                }
            } catch (MessagingException e) {
                FW00_23_LoggerUtil.errorLog.error(this.makeLog(_toAddressList[idx]), e);
            } catch (UnsupportedEncodingException e) {
                FW00_23_LoggerUtil.errorLog.error(this.makeLog(_toAddressList[idx]), e);
            } catch (NullPointerException e) {
                FW00_23_LoggerUtil.errorLog.error(this.makeLog(_toAddressList[idx]), e);
            } finally {
                this.close();
            }
        }
    }

    /**
     *
     * 送信.<br>
     *<br>
     * 概要:<br>
     *   送信する
     *<br>
     * @param _toArray TO送信アドレスリスト
     * @param _ccArray CC送信アドレスリスト
     * @param _bccArray BCC送信アドレスリスト
     */
    private void send(final InternetAddress[] _toArray, final InternetAddress[] _ccArray, final InternetAddress[] _bccArray) {
        if (this.connect()) {
            try {
                MimeMessage mm = new MimeMessage(this.session);
                mm.setFrom(new InternetAddress((String) this.mailInfo.get(FROM_ADDRESS), "", CHAR_CODE));
                mm.setSubject((String) this.mailInfo.get(SUBJECT), CHAR_CODE);
                mm.setText((String) this.mailInfo.get(TEXT), CHAR_CODE);
                mm.setHeader("Content-Type", "text/plain; charset=\"" + CHAR_CODE + "\"");
                // PHS,携帯用文字化け対策
                mm.setHeader("Content-Transfer-Encoding", "7bit");
                mm.setSentDate(new Date());

                mm.setRecipients(Message.RecipientType.TO, _toArray);
                mm.setRecipients(Message.RecipientType.CC, _ccArray);
                mm.setRecipients(Message.RecipientType.BCC, _bccArray);
                this.transport.sendMessage(mm, mm.getAllRecipients());

            } catch (MessagingException e) {
                FW00_23_LoggerUtil.errorLog.error(this.makeLog(_toArray, _ccArray, _bccArray), e);
            } catch (UnsupportedEncodingException e) {
                FW00_23_LoggerUtil.errorLog.error(this.makeLog(_toArray, _ccArray, _bccArray), e);
            } catch (NullPointerException e) {
                FW00_23_LoggerUtil.errorLog.error(this.makeLog(_toArray, _ccArray, _bccArray), e);
            } finally {
                this.close();
            }
        }
    }

    /**
     *
     * ログメッセージ作成.<br>
     *<br>
     * 概要:<br>
     *   ログメッセージを作成する
     *<br>
     * @param _toArray TO送信アドレスリスト
     * @param _ccArray CC送信アドレスリスト
     * @param _bccArray BCC送信アドレスリスト
     * @return ログメッセージ
     */
    private String makeLog(final InternetAddress[] _toArray, final InternetAddress[] _ccArray, final InternetAddress[] _bccArray) {

        String work = "";
        for (InternetAddress address : _toArray) {
            work += address + ";";
        }
        for (InternetAddress address : _ccArray) {
            work += address + ";";
        }
        for (InternetAddress address : _bccArray) {
            work += address + ";";
        }

        String[] strMessages = new String[] {work, (String) this.mailInfo.get(FROM_ADDRESS)};

        return FW00_06_MessageResourceUtil.getMessage(LOG_KEY, strMessages);
    }

    /**
     *
     * ログメッセージ作成.<br>
     *<br>
     * 概要:<br>
     *   ログメッセージを作成する
     *<br>
     * @param _toAddress 送信アドレス
     * @return ログメッセージ
     */
    private String makeLog(final InternetAddress _toAddress) {
        String[] strMessages = new String[] {_toAddress.toString(), (String) this.mailInfo.get(FROM_ADDRESS)};

        return FW00_06_MessageResourceUtil.getMessage(LOG_KEY, strMessages);
    }
}
