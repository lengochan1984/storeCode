/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/02/10| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * ID自動採番処理.<br>
 *<br>
 * 概要:<br>
 *   システム内で必要なID(システムで一意)を自動採番する。<br>
 *   YYYYMMDDHH24mmss+連番3桁の情報を用いて11桁のIDを作成する。
 *<br>
 */
public class FW00_01_IDMakerUtil {

    /**
     * 日付を取得する型.
     */
    private static final String DATETYPE = "yyyyMMdd";
    /**
     * 時刻を取得する型.
     */
    private static final String TIMETYPE = "HHmmss";
    /**
     * カウンタ.
     */
    private static int intCount = 0;

    /**
     *
     * コンストラクタ.
     *
     */
    protected FW00_01_IDMakerUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     *
     * システム内部IDを自動採番.<br>
     *<br>
     * 概要:<br>
     *   システム内部IDを自動採番する。
     *<br>
     * @param _prefix プレフィックス(先頭の1バイト目)
     * @return 自動採番システム内部ID
     */
    public static synchronized String getSystemId(final String _prefix) {
        String strStr = "";
        FW00_01_IDMakerUtil imu = new FW00_01_IDMakerUtil();
        StringBuffer sb = new StringBuffer();
        sb.append(_prefix);
        strStr = imu.getTotalDays().concat(imu.getLPAD(imu.getTotalTime(), 8));
        strStr = imu.getAlphabetCode(Long.parseLong(strStr));
        sb.append(strStr);
        return sb.toString();
    }

    /**
     *
     * 日数取得(26進数文字列).<br>
     *<br>
     * 概要:<br>
     *   YYYYMMDD型の文字列からトータル日数から取得した26進数文字列を返却する<br>
     *   このメソッドの目的は一意となるファイル名を取得することなので<br>
     *   厳密に正確な日数を取得する事はしない
     *<br>
     * @return トータル日数(26進数文字列)
     */
    private String getTotalDays() {
        String strDate = this.getDate(FW00_01_IDMakerUtil.DATETYPE);

        int days = (Integer.parseInt(strDate.substring(0, 4))) * 365
                + Integer.parseInt(strDate.substring(4, 6)) * 31
                + Integer.parseInt(strDate.substring(6));

        return Integer.toString(days);
    }

    /**
     *
     * 時数取得(26進数文字列).<br>
     *<br>
     * 概要:<br>
     *   HH24mmssSS型の文字列からトータル時刻にカウンタ数値を加算して<br>
     *   26進数文字列を返却する
     *<br>
     * @return トータル時刻(26進数文字列)
     */
    private String getTotalTime() {
        String time = this.getDate(FW00_01_IDMakerUtil.TIMETYPE);

        int times = Integer.parseInt(time.substring(0, 2)) * 1000 * 60 * 60
                + Integer.parseInt(time.substring(2, 4)) * 1000 * 60
                + Integer.parseInt(time.substring(4, 6)) * 1000;
        times += intCount;
        intCount++;
        if (intCount == 1000) {
            intCount = 0;
        }

        return Integer.toString(times);
    }

    /**
     *
     * 日付文字列取得.<br>
     *<br>
     * 概要:<br>
     *   YYYYMMdd型の日付を取得し返却する
     *<br>
     * @param _type 種別
     * @return 日付文字列
     */
    private String getDate(final String _type) {
        SimpleDateFormat sdf = (SimpleDateFormat) DateFormat.getDateTimeInstance();
        sdf.applyPattern(_type);
        return sdf.format(new Date());
    }

    /**
     *
     * 26進数文字列変換.<br>
     *<br>
     * 概要:<br>
     *   引数で受け取った数値を26進数の文字列にして返却する
     *<br>
     * @param _num 数値
     * @return 26進数文字列
     */
    private String getAlphabetCode(final long _num) {
        StringBuffer sb = new StringBuffer();
        long work = _num;
        while (work > 0) {
            sb.insert(0, (char) ('A' + work % 26));
            work /= 26;
        }
        return sb.toString();
    }

    /**
     *
     * ゼロ埋め.<br>
     *<br>
     * 概要:<br>
     *   引数で受け取った文字列を、引数で受け取った数値の桁になるまで"0"を左に挿入する。
     *<br>
     * @param _str 文字列
     * @param _num 数値
     * @return ゼロ埋め後の文字列
     */
    private String getLPAD(String _str, final int _num) {
        int a = _str.length();
        for (int i = 0; i < _num - a; i++) {
            _str = "0".concat(_str);
        }

        return _str;
    }
}
