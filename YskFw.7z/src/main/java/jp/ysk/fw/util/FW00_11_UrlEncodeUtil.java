/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/27| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.fw.util;

import org.seasar.struts.util.URLEncoderUtil;

/**
 * URL変換ユーティリティ.<br>
 *<br>
 * 概要:<br>
 *   パラメータで渡された文字列をURLエンコード変換する
 *<br>
 */
public class FW00_11_UrlEncodeUtil {

    /**
     * コンストラクタ.
     *
     */
    protected FW00_11_UrlEncodeUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     *
     * URLエンコード変換.<br>
     *<br>
     * 概要:<br>
     *   URLエンコードに変換された文字列を返却する
     *<br>
     * @param _strParam 変換する文字列
     * @return URLエンコードに変換された文字列
     */
    public static String getUrlEncode(final String _strParam) {
        if (_strParam != null) {
            return URLEncoderUtil.encode(_strParam).replace("+", "%20");
        } else {
            return null;
        }
    }

}
