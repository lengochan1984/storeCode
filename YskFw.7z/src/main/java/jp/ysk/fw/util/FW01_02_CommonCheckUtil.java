/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/06/09| 新規作成                           | 1.00.00| YSK)植山
 *  2014/07/17| <10000-158> IT不具合修正（No.026)  | 1.01.00| YSK)中田
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;

/**
 *
 * 共通チェック処理.<br>
 *<br>
 * 概要:<br>
 *   共通チェック処理
 *<br>
 */
public class FW01_02_CommonCheckUtil {

    /**
     * プロパティファイルの変数(禁則文字用).
     */
    private static Properties props;

    /**
     * 禁則チェックの種類.
     * TOKUSHU_KANJI:特殊漢字群
     * MAIL_ADRESS  :メールアドレス
     * HIRAGANA     :ひらがな（旧字等を指定する）
     * バリエーションが増えれば、定義を追加する。
     */
    public static enum NGCHAR_TYPE {
        SPECIAL_KANJI,
        MAIL_ADRESS,
        HIRAGANA
    }

    /**
     * 属性区分列挙体.
     * NUMBER：数値
     * NUM_STR：数字
     * KANA：ひらがなう
     * ALPHABET：半角英数字
     * DATE：日付
     * TELEPHONE：電話番号
     * IP_ADDRESS：IPアドレス
     * MAIL_ADDRESS：メールアドレス
     * ONE_BYTE：1バイトチェック
     * KATAKANA:カタカナ
     */
    public static enum ATTR_KBN {
        NUMBER,
        NUM_STR,
        KANA,
        ALPHABET,
        DATE,
        DATETIME,
        TELEPHONE,
        IP_ADDRESS,
        MAIL_ADDRESS,
        ONE_BYTE,
        PASSWORD,
        KATAKANA,
        NUMBER_SIGN
    }

    /**
     *
     * コンストラクタ.
     *
     */
    protected FW01_02_CommonCheckUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     *
     * 必須チェック.<br>
     *<br>
     * 概要:<br>
     *   必須チェック
     *<br>
     * @param _data チェック文字列
     * @return 判定結果
     */
    public static boolean checkNecessary(final String _data) {
        return !(_data == null || "".equals(_data));
    }

    /**
     *
     * 属性チェック.<br>
     *<br>
     * 概要:<br>
     *   属性チェック
     *<br>
     * @param _data チェック文字列
     * @param _attrKb 属性区分
     * @return 判定結果
     */
    public static boolean checkAttr(final String _data, final ATTR_KBN _attrKb) {
        if (_data == null) {
            return true;
        } else {
            return checkAttr(new String[]{_data}, _attrKb);
        }
    }

    /**
     *
     * 属性チェック.<br>
     *<br>
     * 概要:<br>
     *   属性チェック
     *<br>
     * @param _data チェック文字列配列
     * @param _attrKb 属性区分
     * @return 判定結果
     */
    public static boolean checkAttr(final String[] _data, final ATTR_KBN _attrKb) {
        boolean bolAttr = false;

        switch (_attrKb) {
            //数値チェック
            case NUMBER:
                bolAttr = _data[0].matches("^[+-]?\\d*[.]?\\d*$");
                break;
                //数字チェック
            case NUM_STR:
                bolAttr = _data[0].matches("^\\d*$");
                break;
                //ひらがなチェック
            case KANA:
                bolAttr = _data[0].matches("^[ぁ-ゞ　ー\\s]*$");
                break;
                //半角英数字チェック
            case ALPHABET:
                bolAttr = _data[0].matches("^[A-Za-z0-9]*$");
                break;
                // 半角英数記号チェック
            case NUMBER_SIGN:
                bolAttr = _data[0].matches("^[\\x20-\\x7F]+$");
                break;
                //日付(年月日)妥当性チェック
            case DATE:
                if (_data.length != 3) {
                    bolAttr = false;
                } else {
                    bolAttr = checkDateFormat(_data);
                }
                break;
                //日付(年月日時刻)妥当性チェック
            case DATETIME:
                if (_data.length != 5) {
                    bolAttr = false;
                } else {
                    bolAttr = checkDateFormat(_data);
                }
                break;
                //電話番号妥当性チェック
            case TELEPHONE:
                if (_data.length != 3) {
                    bolAttr = false;
                } else {
                    List<String> date = new ArrayList<String>();

                    for (String item : _data) {
                        if (item != null && item.matches("^\\d+$")) {
                            date.add(item);
                        } else {
                            break;
                        }
                    }

                    if (date.size() == 3) {
                        bolAttr = ((date.get(0).length() + date.get(1).length() + date.get(2).length()) <= 11);
                    } else {
                        bolAttr = false;
                    }
                }
                break;
                //IPアドレス妥当性チェック
            case IP_ADDRESS:
                if (_data.length != 4) {
                    bolAttr = false;
                } else {
                    List<String> date = new ArrayList<String>();

                    for (String item : _data) {
                        if (item != null && item.matches("^\\d+$")) {
                            date.add(item);
                        } else {
                            break;
                        }
                    }

                    bolAttr = (date.size() == 4);
                }
                break;
                //メールアドレスチェック
            case MAIL_ADDRESS:
                bolAttr = _data[0].matches("^[0-9A-Za-z._-]+@[0-9A-Za-z._-]+$");
                break;
            case ONE_BYTE:
                bolAttr = _data[0].matches("^[!-~]*$");
                break;
            case PASSWORD:

                bolAttr = _data[0].matches("^[A-Za-z0-9]*$");
                if (bolAttr) {
                    bolAttr = _data[0].matches("^[0-9]*$");
                    if (bolAttr) {
                        //数字のみのためエラー
                        bolAttr = false;
                    }

                    bolAttr = _data[0].matches("^[A-Za-z]*$");
                    if (bolAttr) {
                        //半角英字のみのためエラー
                        bolAttr = false;
                    }

                    //半角英字のみ、数字のみでない場合は適正とする
                    bolAttr = true;

                }
                break;
            case KATAKANA:
                bolAttr = _data[0].matches("^[ァ-ヿ ]*$");
                break;
                //列挙帯で振り分けている為、デフォルトに来る事は無い
            default:
                break;
        }

        return bolAttr;
    }

    /**
     *
     * 桁数チェック（上限）.<br>
     *<br>
     * 概要:<br>
     *   桁数チェック（上限）
     *<br>
     * @param _data チェック文字列
     * @param _size 指定桁数
     * @return 判定結果
     */
    public static boolean checkLengthUpper(final String _data, final int _size) {
        boolean bolLength = false;
        bolLength = _data.length() <= _size;
        return bolLength;
    }

    /**
     *
     * 桁数チェック（下限）.<br>
     *<br>
     * 概要:<br>
     *   {??メソッド説明??}
     *<br>
     * @param _data チェック文字列
     * @param _size 指定桁数
     * @return 判定結果
     */
    public static boolean checkLengthLower(final String _data, final int _size) {
        boolean bolLength = false;
        bolLength = _data.length() >= _size;
        return bolLength;
    }

    /**
     *
     * 禁則文字チェック.<br>
     *<br>
     * 概要:<br>
     *   禁則文字チェック
     *<br>
     * @param _data チェック文字列
     * @param _kinsokuType 禁則チェックタイプ(特殊文字、メールアドレス、ひらがな)
     * @return 判定結果
     */
    public static boolean checkNgChar(final String _data, final NGCHAR_TYPE _kinsokuType) {

        // 正規表現のオブジェクトを作成
        Pattern pattern = null;

        // 結果を返す変数
        boolean bolRet = false;

        String strKinsokuKey = "";

        if (_data == null || "".equals(_data)) {
            return true;
        }

        switch (_kinsokuType) {
            case SPECIAL_KANJI:
                strKinsokuKey = "NGCHAR_SPECIAL_KANJI";
                break;

            case MAIL_ADRESS:
                strKinsokuKey = "NGCHAR_MAIL_ADRESS";
                break;

            case HIRAGANA:
                strKinsokuKey = "NGCHAR_HIRAGANA";
                break;
            default:
                break;
        }

        // 禁則文字をクラス変数より取得
        String strPattern =  getNgCharPtrn(strKinsokuKey);
        // 正規表現にする。
        strPattern = "[^" + strPattern + "]*";
        // 正規表現を設定
        pattern = Pattern.compile(strPattern, Pattern.CASE_INSENSITIVE);
        // 正規表現エンジンを作成し比較を行う。
        bolRet = (pattern.matcher(_data)).matches();

        return bolRet;
    }

    /**
     *
     * 日付チェック(内部共通関数).<br>
     *<br>
     * 概要:<br>
     *   日付チェック(内部共通関数)
     *<br>
     * @param _date チェック対象項目群
     * @return 判定結果
     */
    private static boolean checkDateFormat(final String[] _date) {
        boolean bolResult = true;

        if (_date.length > 6) {
            return false;
        }
        List<Integer> lstCheck = new ArrayList<Integer>();

        int intIndex = 0;

        for (String d : _date) {

            if(intIndex == 0){
                if (!d.matches("^\\d{4}$")) {
                    bolResult = false;
                    break;
                }
            }

            if (d.matches("^\\d+$")) {
                lstCheck.add(Integer.parseInt(d));

                if (lstCheck.size() > 1 && lstCheck.get(lstCheck.size() - 2) == null) {
                    bolResult = false;
                }
            } else if (d == null || !d.equals("")) {
                lstCheck.add(null);
            } else {
                bolResult = false;
            }
            intIndex++;
        }

        if (bolResult) {
            int[] aryDate = new int[]{1900,1,1,0,0,0};

            for (int i = 0;i < aryDate.length;i++) {
                if (i < lstCheck.size()) {
                    if (lstCheck.get(i) != null) {
                        aryDate[i] = lstCheck.get(i);
                    }
                }
            }
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.YEAR,aryDate[0]);
            cal.set(Calendar.MONTH,aryDate[1] - 1);
            cal.set(Calendar.DATE,aryDate[2]);
            cal.set(Calendar.HOUR,aryDate[3]);
            cal.set(Calendar.MINUTE,aryDate[4]);
            cal.set(Calendar.SECOND,aryDate[5]);

            bolResult = (aryDate[0] == cal.get(Calendar.YEAR))
                    && (aryDate[1] == cal.get(Calendar.MONTH) + 1)
                    && (aryDate[2] == cal.get(Calendar.DATE))
                    && (aryDate[3] == cal.get(Calendar.HOUR))
                    && (aryDate[4] == cal.get(Calendar.MINUTE))
                    && (aryDate[5] == cal.get(Calendar.SECOND));
        }
        return bolResult;
    }

    /**
     *
     * 禁則文字用パターン取得.<br>
     *<br>
     * 概要:<br>
     *   禁則文字用パターン取得
     *<br>
     * @param _key キー
     * @return 取得文字列
     */
    private static String getNgCharPtrn(final String _key) {
        String ret = "";
        if (props == null) {
            try {
                String filename = "ngchar.properties";
                props = new Properties();
                // プロパティファイルを読み込む
                props.load(
                        FW01_02_CommonCheckUtil.class.getResourceAsStream("/" + filename));

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (props != null) {
            ret = props.getProperty(_key);
        }
        return ret;
    }

}
