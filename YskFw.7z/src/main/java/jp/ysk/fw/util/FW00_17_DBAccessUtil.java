/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/27| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.util;

import static org.seasar.framework.util.StringUtil.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import jp.ysk.fw.FW00_12_AppException;
import jp.ysk.fw.dbif.FW00_17_EscapeSqlParamInterface;

import org.seasar.framework.beans.util.BeanMap;

/**
 * DBアクセス部品ユーティリティ.
 * <pre>
 * [変更履歴]
 * 1.0 2009/09/09  初版
 * </pre>
 * @version 1.0 2009/09/09
 * @author  YSK)西田　浩二
 */
public class FW00_17_DBAccessUtil {

    /**
     * SQLパラメータエスケープ処理IF.
     */
    @Resource
    public FW00_17_EscapeSqlParamInterface fW00_17_EscapeSqlParamInterface;

    /**
     *
     * メソッド名：MapList変換.
     * 概要:
     *    MapList(DB抽出結果一覧)をMapへ変換する
     *
     * 作成    2010/02/22    YSK)西田　浩二
     * @param <T>
     * @param _valueType : Value値クラス型
     * @param _mapList : MapList
     * @param _keyName : Key値Mapキー
     * @param _valName : Val値Mapキー
     * @return
     */
    public static <T> Map<String,T> convertMap(Class<T> _valueType, List<BeanMap> _mapList, String _keyName, String _valName) {
        Map<String,T> convMap = new HashMap<String, T>();

        for (BeanMap map : _mapList) {
            if (!map.containsKey(_keyName) || map.get(_keyName) == null) {
                throw new FW00_12_AppException("key:[" + _keyName + "] was not exist!");
            } else {
                String key = (String)map.get(_keyName);
                Object val = map.get(_valName);

                if (val == null) {
                    convMap.put(key, null);
                } else {
                    convMap.put(key, _valueType.cast(val));
                }
            }
        }

        return convMap;
    }

    /**
     *
     * メソッド名：SQLパラメータトリミング処理
     * 概要:
     *    パラメータの内、文字列型の前後トリミングを行う(lTrim,rTrimのみ)
     *
     * 作成    2010/02/19    YSK)西田　浩二
     * @param _params
     * @return
     */
    public Map<String, Object> trimParams(Map<String, Object> _params) {
        if (_params != null && !_params.isEmpty()) {
            for (String key : _params.keySet()) {
                Object obj = _params.get(key);

                if (obj instanceof String) {
                    _params.put(key, trimParam((String)obj));
                }
            }
        }
        return _params;
    }

    /**
     *
     * メソッド名：トリミング処理
     * 概要:
     *    文字列型の前後トリミングを行う(lTrim,rTrimのみ)
     *
     * 作成    2010/02/19    YSK)西田　浩二
     * @param _param
     * @return
     */
    public String trimParam(String _param) {
        if (isNotEmpty(_param)) {
            return rtrim(ltrim(_param));
        } else {
            return _param;
        }
    }

    /**
     *
     * メソッド名：Mapパラメータエスケープ処理
     * 概要:
     *    Map型のパラメータの一式について、SQLエスケープ処理を行う。
     *
     * 作成    2009/09/09    YSK)西田　浩二
     * @param params
     * @return
     */
    public Map<String,Object> escapeParams(Map<String,Object> _params) {
        Map<String,Object> convertParams = new HashMap<String, Object>();

        for (String key : _params.keySet()) {
            convertParams.put(key, escapeParam(_params.get(key)));
        }

        return convertParams;
    }

    /**
     * メソッド名：単パラメータエスケープ処理
     * 概要:
     *    String型パラメータについて、SQLエスケープ処理を行う
     *
     * 作成    2009/09/09    YSK)西田　浩二
     * @param param
     * @return
     */
    public Object escapeParam(Object _param) {

        return this.fW00_17_EscapeSqlParamInterface.escapeParam(_param);
    }
}
