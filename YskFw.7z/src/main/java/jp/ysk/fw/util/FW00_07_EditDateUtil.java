/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.fw.FW00_19_Const;

/**
 *
 * 日付編集処理.<br>
 *<br>
 * 概要:<br>
 *   日付編集用のユーティリティ
 *<br>
 */
public class FW00_07_EditDateUtil {

    /**
     * コンストラクタ.
     */
    protected FW00_07_EditDateUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     *
     * 変換モード.<br>
     *<br>
     * 概要:<br>
     *   変換モードの列挙帯
     *<br>
     */
    public static enum CHANGE_MODE {
        /**
         * JPモード.
         */
        MODE_DT_JP,
        /**
         * EN1モード.
         */
        MODE_DT_EN1,
        /**
         * EN2モード.
         */
        MODE_DT_EN2,
        /**
         * JP2モード.
         */
        MODE_DT_JP2,
        /**
         * EN3モード.
         */
        MODE_DT_EN3,
        /**
         * EN4モード.
         */
        MODE_DT_EN4
    }

    /**
     *
     * 日数間隔算出モード.<br>
     *<br>
     * 概要:<br>
     *   日数間隔算出モードの列挙帯
     *<br>
     */
    public static enum UNIT_MODE {
        /**
         * 時間間隔(H).
         */
        MODE_H,
        /**
         * 時間間隔(M).
         */
        MODE_M,
        /**
         * 時間間隔(S).
         */
        MODE_S,
        /**
         * 時間間隔(MS).
         */
        MODE_MS
    }

    /**
     *
     * 言語タイプ.<br>
     *<br>
     * 概要:<br>
     *   言語タイプの列挙帯
     *<br>
     */
    private static enum LANG_TYPE {
        /**
         * JPタイプ.
         */
        LANG_JP {
            /**
             * フォーマット.
             *
             * @return フォーマット
             */
            protected String getFormat() {
                return "(E)";
            }
            /**
             * ロケール.
             *
             * @return ロケール
             */
            protected Locale getLocal() {
                return Locale.JAPAN;
            }
        },
        /**
         * ENタイプ.
         */
        LANG_EN {
            /**
             * フォーマット.
             *
             * @return フォーマット
             */
            protected String getFormat() {
                return "(EEE)";
            }
            /**
             * ロケール.
             *
             * @return ロケール
             */
            protected Locale getLocal() {
                return Locale.US;
            }
        };

        /**
         *
         * フォーマット取得.<br>
         *<br>
         * 概要:<br>
         *   フォーマットを取得する
         *<br>
         * @return フォーマット
         */
        protected abstract String getFormat();
        /**
         *
         * ロケール取得.<br>
         *<br>
         * 概要:<br>
         *   ロケールを取得する
         *<br>
         * @return ロケール
         */
        protected abstract Locale getLocal();
    }

    /**
     * 日付フォーマット(DJ).
     */
    private static final String FORMAT_DJ = "yyyy年MM月dd日{0} HH:mm:ss";
    /**
     * 日付フォーマット(DJ).
     */
    private static final String FORMAT_DJ1 = "yyyy年MM月dd日{0}";
    /**
     * 日付フォーマット(DE).
     */
    private static final String FORMAT_DE = "yyyy/MM/dd{0}";
    /**
     * 日付フォーマット(DE1).
     */
    private static final String FORMAT_DE1 = "yyyy/MM/dd{0} HH:mm:ss";
    /**
     * 日付フォーマット(DE2).
     */
    private static final String FORMAT_DE2 = "yy/MM/dd{0} HH:mm";
    /**
     * 日付フォーマット(D).
     */
    private static final String FORMAT_D = "yyyyMMdd";
    /**
     * 日付フォーマット(DT).
     */
    private static final String FORMAT_DT = "yyyyMMddHHmmss";
    /**
     * 日付フォーマット(DE4).
     */
    private static final String FORMAT_DE4 = "yyyy.MM.dd{0}";

    /**
     *
     * フォーマット変換.<br>
     *<br>
     * 概要:<br>
     *   受け取った日時を変換モードによってフォーマットを変換する
     *<br>
     * @param _strBaseDay DBから取得した日付
     * @param _changeMode 変換モード
     * @param _boolDay 曜日表示か非表示か
     * @return 変換した日付
     */
    public static String changeDateFormat(
            final String _strBaseDay, final CHANGE_MODE _changeMode, final boolean _boolDay) {

        Date dateDate = null;

        try {
            if (FW00_19_Const.EMPTY_STR.equals(_strBaseDay)) {
                return FW00_19_Const.EMPTY_STR;
            }
            //ゼロ埋めする
            String strAlterDay = _strBaseDay + "000000";

            dateDate = new SimpleDateFormat(FORMAT_DT).parse(strAlterDay.substring(0, 14));

            SimpleDateFormat sdfFormat = null;
            String format = null;
            LANG_TYPE type = null;

            switch (_changeMode) {
                case MODE_DT_JP:
                    format = FORMAT_DJ;
                    type = LANG_TYPE.LANG_JP;
                    break;
                case MODE_DT_EN1:
                    format = FORMAT_DE1;
                    type = LANG_TYPE.LANG_EN;
                    break;
                case MODE_DT_EN2:
                    format = FORMAT_DE2;
                    type = LANG_TYPE.LANG_EN;
                    break;
                case MODE_DT_JP2:
                    format = FORMAT_DJ1;
                    type = LANG_TYPE.LANG_JP;
                    break;
                case MODE_DT_EN3:
                    format = FORMAT_DE;
                    type = LANG_TYPE.LANG_EN;
                    break;
                case MODE_DT_EN4:
                    format = FORMAT_DE4;
                    type = LANG_TYPE.LANG_EN;
                    break;
                default:
                    //enumで指定の為、defaultの処理は到達不可
                    break;
            }

            if (!_boolDay) {
                format = format.replaceAll("[{][0][}]", "");
            } else {
                format = format.replaceAll("[{][0][}]", type.getFormat());
            }

            sdfFormat = new SimpleDateFormat(format, type.getLocal());

            return sdfFormat.format(dateDate);
        } catch (ParseException e) {
            throw new FW00_12_BusinessException(e);
        }
    }

    /**
     *
     * 日付変換処理.<br>
     *<br>
     * 概要:<br>
     *   Date型の日付を指定したフォーマットの文字列に変換する
     *<br>
     * @param _date 変換日付
     * @param _format フォーマット
     * @return String型に変換した日付
     */
    public static String changeDatetoString(final Date _date, final String _format) {
        /**
         * 変数宣言
         */
        SimpleDateFormat sdf = new SimpleDateFormat(_format);

        /**
         * 処理開始
         */
        return sdf.format(_date);

    }

    /**
     *
     * 現在日付取得.<br>
     *<br>
     * 概要:<br>
     *   現在日付を取得する
     *<br>
     * @return 日付YYYYMMDD
     */
    public static String getNowDay() {

        //SimpleDateFormatオブジェクト生成
        SimpleDateFormat sdfFormat = new SimpleDateFormat(FORMAT_D);

        //Dateオブジェクト生成
        Date dateDate = new Date();

        //Stringの戻り値をリターン
        return sdfFormat.format(dateDate);
    }

    /**
     *
     * 指定日時算出.<br>
     *<br>
     * 概要:<br>
     *   指定された相対値と相対項目から、基準日時からの相対日時を算出した日付を取得する。
     *<br>
     * @param _relativeVal 相対値
     * @param _relativeItem 相対項目
     * @param _basicDate 基準日時(YYYYMMDD or YYYYMMDDHHMMSS)
     * @return 指定日時
     */
    public static String getRelativeDate(final int _relativeVal, final int _relativeItem, final String _basicDate) {

        try {

            SimpleDateFormat sdf = null;
            Date basicDate = null;
            Date relativeDate = null;

            // フォーマットチェック
            if (_basicDate.length() == 8) {
                // 年月日の場合
                sdf = new SimpleDateFormat(FORMAT_D);
            } else if (_basicDate.length() == 14) {
                // 年月日時分秒の場合
                sdf = new SimpleDateFormat(FORMAT_DT);
            } else {
                // その他(フォーマットエラー)
                return null;
            }

            basicDate = sdf.parse(_basicDate);

            Calendar cal = Calendar.getInstance();
            cal.setTime(basicDate);

            cal.add(_relativeItem, _relativeVal);

            relativeDate = cal.getTime();

            return sdf.format(relativeDate);
        } catch (ParseException e) {
            throw new FW00_12_BusinessException(e);
        }
    }

    /**
     *
     * 指定日時算出.<br>
     *<br>
     * 概要:<br>
     *   指定された相対値と相対項目から、現在日時からの相対日時を算出した日付を取得する。
     *<br>
     * @param _relativeVal 相対値
     * @param _relativeItem 相対項目
     * @return 指定日時
     */
    public static String getRelativeCurrentDate(final int _relativeVal, final int _relativeItem) {
        String currentDate = getNowDate();
        return getRelativeDate(_relativeVal, _relativeItem, currentDate);
    }

    /**
     *
     * 現在日時取得.<br>
     *<br>
     * 概要:<br>
     *   現在日時を取得する
     *<br>
     * @return 現在日時YYYYMMDDhhmmss
     */
    public static String getNowDate() {

        //SimpleDateFormatをオブジェクト生成する
        SimpleDateFormat sdfFormat = new SimpleDateFormat(FORMAT_DT);

        //Dateオブジェクトを生成する
        Date dateDate = new Date();

        //Stringの戻り値をリターンする
        return sdfFormat.format(dateDate);
    }

    /**
     *
     * 日付ゼロ詰め.<br>
     *<br>
     * 概要:<br>
     *   日付をゼロ詰めする
     *<br>
     * @param _strYear 年
     * @param _strMonth 月
     * @param _strDay 日
     * @return ゼロ埋めした日付YYYYMMDD
     */
    public static String changeDateZeroCover(final String _strYear, final String _strMonth, final String _strDay) {

        return changeZeroCover(_strYear, _strMonth, _strDay, null, null, null);

    }

    /**
     *
     * 日付ゼロ詰め.<br>
     *<br>
     * 概要:<br>
     *   日付をゼロ詰めする
     *<br>
     * @param _strYear 年
     * @param _strMonth 月
     * @param _strDay 日
     * @param _strHour 時
     * @param _strMinute 分
     * @return ゼロ埋めした日付YYYYMMDDhhmm
     */
    public static String changeDateTimeZeroCover(
            final String _strYear, final String _strMonth, final String _strDay,
            final String _strHour, final String _strMinute) {

        return changeZeroCover(_strYear, _strMonth, _strDay, _strHour, _strMinute, null);

    }

    /**
     *
     * 時間ゼロ詰め.<br>
     *<br>
     * 概要:<br>
     *   時間をゼロ詰めする
     *<br>
     * @param _strHour 時
     * @param _strMinute 分
     * @return ゼロ埋めした時間hhmm
     */
    public static String changeTimeZeroCover(final String _strHour, final String _strMinute) {

        return changeZeroCover(null, null, null, _strHour, _strMinute, null);

    }

    /**
     *
     * 日数間隔取得.<br>
     *<br>
     * 概要:<br>
     *   FROMからTOの日数を取得する
     *<br>
     * @param _fromDate 開始日
     * @param _toDate 終了日
     * @return 日数
     */
    public static int getIntervalDay(final String _fromDate, final String _toDate) {
        long interval = 0L;


        interval = FW00_07_EditDateUtil.getIntervalTime(_fromDate, _toDate, UNIT_MODE.MODE_H);
        double intervalDay = Math.ceil(interval / FW00_19_Const.HOUR);

        return (int) intervalDay + 1;
    }

    /**
     *
     * 時間間隔取得.<br>
     *<br>
     * 概要:<br>
     *   FromからToの時間間隔を取得する
     *<br>
     * @param _fromDate 開始日時
     * @param _toDate 終了日時
     * @param _mode モード
     *  MODE_D：日
     *  MODE_H：時間
     *  MODE_M：分
     *  MODE_S：秒
     *  MODE_MS：ミリ秒
     * @return 時間間隔
     */
    public static long getIntervalTime(final String _fromDate, final String _toDate, final UNIT_MODE _mode) {

        /**
         * 変数宣言
         */
        //日付フォーマット
        SimpleDateFormat sdf = null;
        //From日付
        Date from = null;
        //To日付
        Date to = null;
        //時間間隔
        long interval = 0L;
        //算出結果
        long result = 0L;

        /**
         * 処理開始
         */
        try {
            if (_fromDate.length() <= 8) {
                sdf = new SimpleDateFormat(FORMAT_D);
            } else {
                sdf = new SimpleDateFormat(FORMAT_DT);
            }
            from  = sdf.parse(_fromDate);
            to = sdf.parse(_toDate);

            interval = to.getTime() - from.getTime();

            switch(_mode) {
                case MODE_H:
                    //時間で算出
                    result = interval / FW00_19_Const.MILLI / FW00_19_Const.SECOND / FW00_19_Const.MINUTE;
                    break;
                case MODE_M:
                    //分で算出
                    result = interval / FW00_19_Const.MILLI / FW00_19_Const.SECOND;
                    break;
                case MODE_S:
                    //秒で算出
                    result = interval / FW00_19_Const.MILLI;
                    break;
                case MODE_MS:
                    //ミリ秒で算出
                    result = interval;
                    break;
                default:
                    break;
            }

            return result;

        } catch (ParseException e) {
            throw new FW00_12_BusinessException(e);
        }
    }

    /**
     *
     * ゼロ詰め.<br>
     *<br>
     * 概要:<br>
     *   ゼロ詰めする
     *<br>
     * @param _strYear 年
     * @param _strMonth 月
     * @param _strDay 日
     * @param _strHour 時
     * @param _strMinute 分
     * @param _strSecond 秒
     * @return ゼロ埋め
     */
    private static String changeZeroCover(final String _strYear, final String _strMonth, final String _strDay,
            final String _strHour, final String _strMinute, final String _strSecond) {

        //Calendarオブジェクトを生成する
        Calendar cal = Calendar.getInstance();

        //StringBufferオブジェクトを生成する
        StringBuffer sbFormat = new StringBuffer();

        if (_strYear != null && !FW00_19_Const.EMPTY_STR.equals(_strYear)) {

            //"yyyy"を追加
            sbFormat.append("yyyy");

            //引数の年をint型に変換する
            int intYear = Integer.parseInt(_strYear);

            //もし3桁以下の場合は2000年に合わせる
            if (intYear < 1000) {
                intYear += 2000;
            }

            //Calendarにセットする
            cal.set(Calendar.YEAR, intYear);

        }

        if (_strMonth != null && !FW00_19_Const.EMPTY_STR.equals(_strMonth)) {

            //"MM"を追加
            sbFormat.append("MM");

            //引数の月をint型に変換する
            int intMonth = Integer.parseInt(_strMonth) - 1;

            //Calendarにセットする
            cal.set(Calendar.MONTH, intMonth);

        }

        if (_strDay != null && !FW00_19_Const.EMPTY_STR.equals(_strDay)) {

            //"dd"を追加
            sbFormat.append("dd");

            //引数の日をint型に変換する
            int intDay = Integer.parseInt(_strDay);

            //Calendarにセットする
            cal.set(Calendar.DATE, intDay);

        }

        if (_strHour != null && !FW00_19_Const.EMPTY_STR.equals(_strHour)) {

            //"HH"を追加
            sbFormat.append("HH");

            //引数の時をint型に変換する
            int intHour = Integer.parseInt(_strHour);

            //Calendarにセットする
            cal.set(Calendar.HOUR_OF_DAY, intHour);
        }

        if (_strMinute != null && !FW00_19_Const.EMPTY_STR.equals(_strMinute)) {

            //"mm"を追加
            sbFormat.append("mm");

            //引数の時をint型に変換する
            int intMinute = Integer.parseInt(_strMinute);

            //Calendarにセットする
            cal.set(Calendar.MINUTE, intMinute);
        }

        if (_strSecond != null && !FW00_19_Const.EMPTY_STR.equals(_strSecond)) {

            //"ss"を追加
            sbFormat.append("ss");

            //引数の時をint型に変換する
            int intSecond = Integer.parseInt(_strSecond);

            //Calendarにセットする
            cal.set(Calendar.SECOND, intSecond);
        }

        //Dateオブジェクトを生成する
        Date dateDate = cal.getTime();

        //SimpleDateFormatオブジェクトをStringBufferオブジェクトを使用して生成する
        SimpleDateFormat sdfFormat = new SimpleDateFormat(sbFormat.toString());

        return sdfFormat.format(dateDate);

    }
}
