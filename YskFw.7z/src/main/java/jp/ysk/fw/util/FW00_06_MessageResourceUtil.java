/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.util;

import java.util.Properties;

/**
 *
 * メッセージ取得処理.<br>
 *<br>
 * 概要:<br>
 *   メッセージ取得用のユーティリティクラス
 *<br>
 */
public class FW00_06_MessageResourceUtil {

    /**
     *
     * コンストラクタ.
     *
     */
    protected FW00_06_MessageResourceUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     * メッセージプロパティ.
     */
    private static Properties props = null;

    /**
     * ロックオブジェクト.
     */
    private static final Object LOCK_OBJECT = new Object();

    /**
     *
     * 初期化処理.<br>
     *<br>
     * 概要:<br>
     *   初期化処理を実行する
     *<br>
     */
    private static void init() {
        String filename = "messagelist.properties";
        try {
            props = new Properties();
            props.load(FW00_06_MessageResourceUtil.class.getResourceAsStream("/" + filename));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * メッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   メッセージリソースより文字列を取得する
     *<br>
     * @param _key キー
     * @param _args 変換文字列
     * @return 取得文字列
     */
    public static String getMessage(final String _key, final String[] _args) {
        String ret = "";

        synchronized (LOCK_OBJECT) {
            if (props == null) {
                init();
            }
        }

        ret = props.getProperty(_key);

        if (ret == null) {
            FW00_23_LoggerUtil.errorLog.error("message not found key:[" + _key + "]");
        } else {
            //先頭2バイトは、エラーメッセージ種別なので除く
            ret = ret.substring(2);

            if (_args != null) {
                for (int i = 0; i < _args.length; i++) {
                    ret = ret.replaceAll("\\{" + i + "\\}", _args[i]);
                }
            }
        }
        return ret;
    }

    /**
     *
     * メッセージ取得.<br>
     *<br>
     * 概要:<br>
     *   メッセージリソースより文字列を取得する
     *<br>
     * @param _key キー
     * @return 取得文字列
     */
    public static String getMessage(final String _key) {
        return getMessage(_key, null);
    }

    /**
     *
     * パラメータ取得.<br>
     *<br>
     * 概要:<br>
     *   カンマ区切りの置換パラメータを分割する
     *<br>
     * @param _params パラメータリスト
     * @return パラメータ配列
     */
    public static String[] getParams(final String _params) {
        return _params.split("[,]");
    }
}
