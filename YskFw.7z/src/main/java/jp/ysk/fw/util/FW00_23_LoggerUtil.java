/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.util;

import org.apache.log4j.Logger;

/**
 *
 * ログ出力クラス.<br>
 *<br>
 * 概要:<br>
 *   ログ出力用のユーティリティークラスです
 *<br>
 */
public class FW00_23_LoggerUtil {

    /**
     * アクション入力.
     */
    public static final String ACTION_INPUT = "【ActionInput】";

    /**
     * アクション出力.
     */
    public static final String ACTION_OUTPUT = "【ActionOutput】";

    /**
     * Dao入力.
     */
    public static final String DAO_INPUT = "【DaoInput】";

    /**
     * Dao出力.
     */
    public static final String DAO_OUTPUT = "【DaoOutput】";

    /**
     * アクションクラスフッター.
     */
    public static final String ACTION_CLASS_FOOTER = "Action";

    /**
     * Daoクラスフッター.
     */
    public static final String DAO_CLASS_FOOTER = "Dao";

    /**
     * クラス名ヘッダー.
     */
    public static final String CLASS_NAME_HEADER = "クラス名";

    /**
     * メソッド名ヘッダー.
     */
    public static final String METHOD_NAME_HEADER = "メソッド名";

    /**
     * 顧客IDヘッダー.
     */
    public static final String CUSTOMER_ID_HEADER = "顧客ID";

    /**
     * ユーザIDヘッダー.
     */
    public static final String USER_ID_HEADER = "ユーザID";

    /**
     * メッセージヘッダー.
     */
    public static final String MESSAGE_HEADER = "メッセージ";

    /**
     * パスワードヘッダー.
     */
    public static final String PASSWD_HEADER = "パスワード";

    /**
     * クライアントIPアドレスヘッダー.
     */
    public static final String CLIENT_AI_ADRESS_HEADER = "IPアドレス";

    /**
     * ブラウザ種別ヘッダー.
     */
    public static final String BROWSER_KIND_HEADER = "ブラウザ種別";

    /**
     * 出力ヘッダー.
     */
    public static final String OUTPUT_HEADER = "出力";

    /**
     * 出力なし.
     */
    public static final String OUTPUT_NOTHING = "Null";

    /**
     * 件数ヘッダー.
     */
    public static final String COUNT_HEADER = "件数";

    /**
     *
     * コンストラクタ.
     *
     */
    protected FW00_23_LoggerUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     * アクセスログ.
     */
    public static Logger accessLog = Logger.getLogger("access");

    /**
     * エラーログ.
     */
    public static Logger errorLog = Logger.getLogger("error");

    /**
     * 通信ログ.
     */
    public static Logger communityLog = Logger.getLogger("community");

    /**
     * アプリケーションログ.
     */
    public static Logger applicationLog = Logger.getLogger("application");

    /**
     * デバッグログ.
     */
    public static Logger debugLog = Logger.getLogger("debug");

    /**
     * ログイン失敗ログ.
     */
    public static Logger loginerrorLog = Logger.getLogger("loginerror");
}
