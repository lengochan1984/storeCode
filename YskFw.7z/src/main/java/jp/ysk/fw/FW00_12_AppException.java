/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/20| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw;

/**
 *
 * アプリケーション共通例外クラス.<br>
 *<br>
 * 概要:<br>
 *   アプリケーションで共通して使用する例外を定義
 *<br>
 */
public class FW00_12_AppException extends RuntimeException {

    /**
     * シリアル番号.
     */
    private static final long serialVersionUID = 1L;

    /**
     * メッセージキー.
     */
    private String msgKey;

    /**
     *
     * コンストラクタ.
     *
     * @param _msgKey 例外メッセージコード
     */
    public FW00_12_AppException(final String _msgKey) {
        this.msgKey = _msgKey;
    }

    /**
     * コンストラクタ.
     * @param _e 例外クラス
     */
    public FW00_12_AppException(final Throwable _e) {
        super(_e);
    }

    /**
     * コンストラクタ.
     */
    public FW00_12_AppException() {
        super();
    }

    /**
     *
     * 例外メッセージキーを取得.<br>
     *<br>
     * 概要:<br>
     *   例外メッセージキーを取得する
     *<br>
     * @return 例外メッセージキー
     */
    public String getMsgKey() {
        return this.msgKey;
    }
}
