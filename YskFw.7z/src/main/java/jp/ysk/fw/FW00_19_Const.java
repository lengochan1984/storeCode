/*
 * **************************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * **************************************************************************
 * ===========+============================================================================+========+==============
 *  DATE      | Comments                                                                   | Rev    | SIGN
 * ===========+============================================================================+========+==============
 *  2014/01/27| 新規作成                                                                   | 1.00.00| YSK)森山
 *  2014/07/17| <10000-152>リリース後障害対応(No.024)                                      | 1.01.00| YSK)中田
 *  2015/07/10| <30003-036> 変更仕様No.12                                                  | 3.01.00| US)萩尾
 *  2015/08/31| <30003-067> 故障苦情No.30003-078                                           | 3.01.00| US)萩尾
 *  2016/01/15| <40000-007> 変更仕様No.7(故障苦情No.30003-067･故障苦情No.30003-081)        | 4.00.00| US)萩尾
 *  2016/02/12| <40000-021> Ver.4.00.00 変更仕様No.21                                      | 4.00.00| US)甲斐
 * -----------+----------------------------------------------------------------------------+--------+--------------
 */
package jp.ysk.fw;


/**
 *
 * FW定数一覧.<br>
 *<br>
 * 概要:<br>
 *   FW定数一覧
 *<br>
 */
public class FW00_19_Const {

    /**
     *
     * コンストラクタ.
     *
     */
    protected FW00_19_Const() {
        throw new UnsupportedOperationException();
    }

    /**
     * メール送信用文字コード.
     **/
    public static final String FWCST_CD_MAIL_ISO2022JP = "iso-2022-jp";

    /**
     * メール送信用文字コード（UTF-8）.
     **/
    public static final String FWCST_CD_MAIL_UTF_8 = "utf-8";

    /**
     * コマンド実行用文字コード（US-ASCII）.
     **/
    public static final String FWCST_CD_COMMAND_ASCII = "US-ASCII";

    //**************************************
    // CSV用定義
    //**************************************
    /**
     * CSV用文字コード.
     **/
    public static final String FWCST_CD_CSV = "Windows-31J";

    //**************************************
    // ソートリンクの表示位置
    //**************************************
    /**
     * ソートリンクの表示位置(縦表示).
     */
    public static final String FWCST_SORTLINKDISP_VERTICAL  = "v";

    /**
     * ソートリンク位置表示（横表示）.
     */
    public static final String FWCST_SORTLINKDISP_HORIZONTAL = "h";

    /**
     * ソートリンク位置表示（指定なし）.
     */
    public static final String FWCST_SORTLINKDISP_NOSORT = "";

    //**************************************
    // 一般的な値
    //**************************************
    /**
     * 空文字.
     */
    public static final String EMPTY_STR = "";
    /**
     * カンマ.
     */
    public static final String COMMA_STR = ",";
    /**
     * 全角カンマ.
     */
    public static final String COMMA_FULL_STR = "、";
    /**
     * 半角スペース.
     */
    public static final String SPACE = " ";
    /**
     * 半角コロン.
     */
    public static final String COLON_STR = ":";
    /**
     * 半角セミコロン.
     */
    public static final String SEMICOLON_STR = ";";
    /**
     * 半角スラッシュ.
     */
    public static final String SLASH_STR = "/";
    /**
     * 半角バックスラッシュ.
     */
    public static final String BACK_SLASH_STR = "\\";
    /**
     * 半角アンダーバー.
     */
    public static final String UNDER_BAR_STR = "_";
    /**
     * 半角パーセント.
     */
    public static final String PERCENT_STR = "%";
    /**
     * 半角ハイフン.
     */
    public static final String HYPHEN_STR = "-";
    /**
     * 半角イコール.
     */
    public static final String EQUAL_STR = "=";
    /**
     * 半角クエッション.
     */
    public static final String QUESTION_STR = "?";
    /**
     * 半角小カッコ開始.
     */
    public static final String PARENTHESIS_START_STR = "(";
    /**
     * 半角小カッコ終了.
     */
    public static final String PARENTHESIS_END_STR = ")";
    /**
     * 半角中カッコ開始.
     */
    public static final String CURLY_BRACKET_START_STR = "{";
    /**
     * 半角中カッコ終了.
     */
    public static final String CURLY_BRACKET_END_STR = "}";
    /**
     * 半角カギカッコ開始.
     */
    public static final String BRACKET_START_STR = "[";
    /**
     * 半角カギカッコ終了.
     */
    public static final String BRACKET_END_STR = "]";
    /**
     * 半角小なり.
     */
    public static final String LEFT_ANGLE_BRACKET_STR = "<";
    /**
     * 半角大なり.
     */
    public static final String RIGHT_ANGLE_BRACKET_STR = ">";
    /**
     * 半角アスタリスク.
     */
    public static final String ASTERISK_STR = "*";
    /**
     * 半角縦線.
     */
    public static final String VERTICAL_BAR_STR = "|";
    /**
     * ダブルクォーテーション.
     */
    public static final String DOUBLE_QUOTATION_STR = "\"";
    /**
     * シングルクォーテーション.
     */
    public static final String SINGLE_QUOTATION_STR = "'";
    /**
     * アンパサンド.
     */
    public static final String AMPERSAND_STR = "&";
    /**
     * アットマーク.
     */
    public static final String AT_MARK_STR = "@";
    /**
     * ドット.
     */
    public static final String DOT_STR = ".";
    /**
     * 文字ドット.
     */
    public static final String ENDOT_STR = "\\.";
    /**
     * 文字/.
     */
    public static final String ENSLASH_STR = "\\/";

    /**
     * +.
     */
    public static final String PLUS = "+";

    /**
     * ^.
     */
    public static final String CARET = "^";

    /**
     * $.
     */
    public static final String DOLLAR = "$";

    /**
     * 1秒間のミリ秒数.
     */
    public static final int MILLI = 1000;
    /**
     * 1分間の秒数.
     */
    public static final int SECOND = 60;
    /**
     * 1時間の分数.
     */
    public static final int MINUTE = 60;
    /**
     * 1日の自数.
     */
    public static final int HOUR = 24;
    /**
     * 1ヶ月の日数.
     */
    public static final int DAY = 31;

    /**
     * キロバイトのバイト数.
     */
    public static final int KILO_BYTES = 1024;

    /**
     * メガバイトのバイト数.
     */
    public static final int MEGA_BYTES = 1048576;

    /**
     * 標準時のタイムゾーンID.
     */
    public static final String TZ_GMT = "GMT";

    /**
     * 日本時のタイムゾーンID.
     */
    public static final String TZ_JPN = "Asia/Tokyo";

    //**************************************
    // 通信系
    //**************************************
    /**
     * エンコード.
     */
    public static enum STR_CODE {
        /**
         * UTF-8(BOMなし).
         */
        UTF8("UTF-8"),
        /**
         * SJIS.
         */
        SJIS("SJIS"),
        /**
         * UNICODE.
         */
        UNICODE("UNICODE");

        /**
         *
         * コンストラクタ.
         *
         * @param _charsetName 文字コード指定文字列
         */
        private STR_CODE(final String _charsetName) {
            this.charsetName = _charsetName;
        }

        /**
         * 文字コード指定文字列.
         */
        private String charsetName;

        /**
         *
         * 文字コード指定文字列取得.<br>
         *<br>
         * 概要:<br>
         *   文字コード指定文字列を取得する
         *<br>
         * @return 文字コード指定文字列
         */
        public String getCharsetName() { return this.charsetName; }
    }

    /**
     * 改行コード.
     */
    public static enum CHANGE_LINE_CODE {
        /**
         * CR+LF.
         */
        CRLF("CR+LF", new byte[]{0x0D, 0x0A}),
        /**
         * CR.
         */
        CR("CR", new byte[]{0x0D}),
        /**
         * LF.
         */
        LF("LF", new byte[]{0x0A});

        /**
         *
         * コンストラクタ.
         *
         * @param _dspStr 表示文字列
         * @param _code ASCII文字コード
         */
        private CHANGE_LINE_CODE(final String _dspStr, final byte[] _code) {
            this.dspStr = _dspStr;
            this.code = _code.clone();
        }

        /**
         * 表示文字列.
         */
        private String dspStr;

        /**
         *
         * 表示文字列取得.<br>
         *<br>
         * 概要:<br>
         *   表示文字列を取得する
         *<br>
         * @return 表示文字列
         */
        public String getDspStr() { return this.dspStr; }

        /**
         * 改行コード.
         */
        private byte[] code;

        /**
         *
         * 改行コード取得.<br>
         *<br>
         * 概要:<br>
         *   改行コードを取得する
         *<br>
         * @return 改行コード
         */
        public byte[] getCode() { return this.code; }

        /**
         *
         * 表示文字列から改行コード取得.<br>
         *<br>
         * 概要:<br>
         *   表示文字列から改行コードを取得する
         *<br>
         * @param _dspStr 表示文字列
         * @return 改行コード
         */
        public static byte[] getCodeFromDspStr(final String _dspStr) {
            byte[] ret = {0};
            CHANGE_LINE_CODE[] changeLineCodeArray = CHANGE_LINE_CODE.values();
            for (CHANGE_LINE_CODE changeLineCode : changeLineCodeArray) {
                if (changeLineCode.getDspStr().equals(_dspStr)) {
                    ret = changeLineCode.getCode();
                    break;
                }
            }

            return ret;
        }
    }

    /**
     * エスケープ対象文字.
     */
    public static final String[] SPLIT_REPLACE_CHARA = {BACK_SLASH_STR, ASTERISK_STR, QUESTION_STR,
        VERTICAL_BAR_STR, PLUS, DOT_STR, CURLY_BRACKET_START_STR, CURLY_BRACKET_END_STR, PARENTHESIS_START_STR, PARENTHESIS_END_STR,
        BRACKET_START_STR, BRACKET_END_STR, CARET, DOLLAR};

    /**
     *
     * 内部処理通信パラメータ.<br>
     *<br>
     * 概要:<br>
     *   内部処理通信パラメータ
     *<br>
     */
    public abstract class InternalToolsParameterName {

        /**
         * 顧客CD.
         */
        public static final String CUSTOMER_CD = "ccd";

        /**
         * 機器ID.
         */
        public static final String DEVICE_SID = "dsid";

        /**
         * ファイル名.
         */
        public static final String FILE_NAME = "fn";

        /**
         * プロトコルID.
         */
        public static final String PROTCOL_ID = "pid";
    }
}
