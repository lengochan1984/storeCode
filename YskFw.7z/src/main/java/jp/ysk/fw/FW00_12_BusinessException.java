/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+=======================================+========+==============
 *  DATE      | Comments                              | Rev    | SIGN
 * ===========+=======================================+========+==============
 *  2014/01/20| 新規作成                              | 1.00.00| YSK)植山
 *  2016/03/12| <40000-028> Ver.4.00.00 変更仕様No.28 | 4.00.00| US)甲斐
 * -----------+---------------------------------------+--------+--------------
 */
package jp.ysk.fw;

/**
 *
 * 業務例外クラス.<br>
 *<br>
 * 概要:<br>
 *   業務で共通して使用する例外を定義
 *<br>
 */
public class FW00_12_BusinessException extends FW00_12_AppException {
    /**
     * シリアル番号.
     */
    private static final long serialVersionUID = 1L;

    /**
     * フォーカスID.
     */
    private String focusCtlId;

    /**
     * 置換パラメータ.
     */
    private String[] msgArgs;

    /**
     * エラー時関数実行フラグ.
     */
    private String errLoadFunctionFlg;

    /**
     *
     * コンストラクタ.
     *
     * @param _msgKey メッセージキー
     * @param _focusCtlId フォーカスID
     */
    public FW00_12_BusinessException(final String _msgKey, final String _focusCtlId) {
        super(_msgKey);
        this.focusCtlId = _focusCtlId;
    }

    /**
     *
     * コンストラクタ.
     *
     * @param _msgKey メッセージキー
     * @param _focusCtlId フォーカスID
     * @param _loadFunctionFlg エラー後関数呼び出しフラグ
     */
    public FW00_12_BusinessException(final String _msgKey, final String _focusCtlId, final String _loadFunctionFlg) {
        super(_msgKey);
        this.focusCtlId = _focusCtlId;
        this.errLoadFunctionFlg = _loadFunctionFlg;
    }

    /**
     *
     * コンストラクタ.
     *
     * @param _msgKey メッセージキー
     * @param _focusCtlId フォーカスID
     * @param _loadFunctionFlg エラー後関数呼び出しフラグ
     */
    public FW00_12_BusinessException(final String _msgKey, final String _focusCtlId, final Boolean _loadFunctionFlg) {
        super(_msgKey);
        this.focusCtlId = _focusCtlId;
        this.errLoadFunctionFlg = _loadFunctionFlg.toString();
    }

    /**
     *
     * コンストラクタ.
     *
     * @param _msgKey メッセージキー
     * @param _msgArgs メッセージ置換文字列
     * @param _focusCtlId フォーカス設定コントロール名
     */
    public FW00_12_BusinessException(final String _msgKey, final String[] _msgArgs, final String _focusCtlId) {
        super(_msgKey);
        this.msgArgs = _msgArgs;
        this.focusCtlId = _focusCtlId;
    }

    /**
     *
     * コンストラクタ.
     *
     * @param _msgKey メッセージキー
     */
    public FW00_12_BusinessException(final String _msgKey) {
        super(_msgKey);
    }

    /**
     *
     * コンストラクタ.
     *
     * @param _msgKey メッセージキー
     * @param _msgArgs メッセージ置換文字列
     */
    public FW00_12_BusinessException(final String _msgKey, final String[] _msgArgs) {
        super(_msgKey);
        this.msgArgs = _msgArgs;
    }

    /**
     *
     * コンストラクタ.
     *
     * @param _e 例外クラス
     */
    public FW00_12_BusinessException(final Throwable _e) {
        super(_e);
    }

    /**
     *
     * 例外メッセージキーを取得.<br>
     *<br>
     * 概要:<br>
     *   例外メッセージキーを取得する
     *<br>
     * @return 例外メッセージキー
     */
    @Override
    public String getMsgKey() {
        return super.getMsgKey();
    }

    /**
     *
     * 置換パラメータ取得.<br>
     *<br>
     * 概要:<br>
     *   置換パラメータを取得する
     *<br>
     * @return 置換パラメータ
     */
    public String[] getMsgArgs() {
        return this.msgArgs;
    }

    /**
     *
     * フォーカスコントロールID取得.<br>
     *<br>
     * 概要:<br>
     *   フォーカスコントロールIDを取得する
     *<br>
     * @return フォーカスコントロールID
     */
    public String getFocusCtlId() {
        return this.focusCtlId;
    }

    /**
     *
     * 関数呼び出しフラグ取得.<br>
     *<br>
     * 概要:<br>
     *   関数呼び出しフラグを取得する
     *<br>
     * @return 関数呼び出しフラグ
     */
    public String getErrLoadFunctionFlg() {
        return errLoadFunctionFlg;
    }
}
