/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/05/21| 新規作成                           | 1.00.00| YSK)大山
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.fw.telecom.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * データポイント切り出しデータDto.<br>
 *<br>
 * 概要:<br>
 *   データポイントごとに切り出した結果を格納するDTO
 *<br>
 */
public class CM_DataPointSplitDto {

    /**
     * 切り出しデータMapリスト.
     */
    public List<Map<String, byte[]>> dataMapList;

    /**
     * エラー情報マップ.
     */
    public Map<Integer, List<String>> errorMap;

    /**
     * 処理結果マップ.
     */
    public Map<Integer, Integer> resultMap;

    /**
     * 電文SID.
     */
    public Long telecomSid;

    /**
     * コンストラクタ.
     *
     */
    public CM_DataPointSplitDto() {

        this.dataMapList = new ArrayList<Map<String, byte[]>>();
        this.errorMap = new HashMap<Integer, List<String>>();
        this.resultMap = new HashMap<Integer, Integer>();
        this.telecomSid = new Long(0);
    }
}
