/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/02/10| 新規作成                           | 1.00.00| YSK)植山
 *  2015/03/10| ST2障害対応(No.44)                 | 3.00.01| YSK)植山
 *  2015/06/23| <30003-033> 変更仕様No.12          | 3.01.00| US)萩尾
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.telecom.socket;

import java.util.Date;

import jp.ysk.fw.telecom.socket.bean.FW02_01_DenbunInfoBean;

/**
 *
 * 通信用業務ロジックIF.<br>
 *<br>
 * 概要:<br>
 *   通信用の業務ロジックのインターフェイスクラス
 *<br>
 */
public interface FW02_01_TelecomLogicInterface {

    /**
     *
     * 業務処理前処理.<br>
     *<br>
     * 概要:<br>
     *   業務処理前の処理を行う
     *<br>
     * @param _processId プロセスID
     * @param _companyId 顧客ID
     * @param _protocolVer プロトコルバージョン
     * @param _deviceId 機器ID
     * @param _commandCode コマンドCD
     * @param _reserve 予約
     * @param _telecomDate 通信日時
     * @param _portNum ポート番号
     * @param _dataSize データサイズ
     * @param _pathReceiveFile 受信ファイル作成ディレクトリパス
     * @return 通信ログSID
     */
    Long beforeExecute(
            String _processId,
            String _companyId,
            Long _protocolVer,
            String _deviceId,
            Long _commandCode,
            String _reserve,
            Date _telecomDate,
            int _portNum,
            long _dataSize,
            String _pathReceiveFile);

    /**
     *
     * データ編集.<br>
     *<br>
     * 概要:<br>
     *   電文情報を編集する
     *<br>
     * @param _denbunData 電文情報
     * @return 電文情報
     */
    FW02_01_DenbunInfoBean editDto(FW02_01_DenbunInfoBean _denbunData);

    /**
     *
     * 処理前レスポンス取得.<br>
     *<br>
     * 概要:<br>
     *   電文の処理前の受信した時点でレスポンスを返す場合にbyte配列を取得できる
     *<br>
     * @param _denbunData 電文情報
     * @return レスポンスbyte配列
     */
    byte[] getBeforeResponse(FW02_01_DenbunInfoBean _denbunData);

    /**
     *
     * 業務処理.<br>
     *<br>
     * 概要:<br>
     *   業務処理を実行する
     *<br>
     * @param _denbunData 電文情報
     * @return 文字列
     * @throws Exception 例外
     */
    byte[] execute(FW02_01_DenbunInfoBean _denbunData) throws Exception;

    /**
     *
     * 終了処理.<br>
     *<br>
     * 概要:<br>
     *   業務処理の後処理を実行する
     *<br>
     * @param _sendData 送信文字列
     * @param _sid 通信ログSID
     */
    void endProcess(byte[] _sendData, Long _sid);
}
