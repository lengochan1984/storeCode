/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/02/10| 新規作成                           | 1.00.00| YSK)植山
 *  2015/08/04| <30003-047> 故障苦情No.30003-062   | 3.01.00| US)萩尾
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.telecom.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.ysk.fw.FW00_12_AppException;
import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.fw.FW00_12_TelecomException;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.telecom.socket.bean.FW02_01_DenbunInfoBean;

import org.seasar.framework.util.OutputStreamUtil;

/**
 *
 * 分割ユーティリティ.<br>
 *<br>
 * 概要:<br>
 *   電文を分割するためのユーティリティ
 *<br>
 */
public class FW02_01_SplitByteUtil {

    /**
     * プレフィックス格納用共通キー.
     */
    public static final String KEY_PREFIX = "FW02_01_PREFIX";

    /**
     * ファイル受信タイプの電文時の受信ファイルサイズ設定共通キー.
     */
    public static final String KEY_FILE_SIZE = "FW02_01_FILE_SIZE";

    /**
     * ファイル受信タイプの電文時の受信ファイル格納先パス設定共通キー.
     */
    public static final String KEY_SAVE_FILE_PATH = "FW02_01_SAVE_FILE_PATH";

    /**
     * クライアントIPアドレス設定共通キー.
     */
    public static final String KEY_IP_ADDRESS = "FW02_01_CLIENT_IP";

    /**
     * プロトコルバージョン設定共通キー.
     */
    public static final String KEY_PROTOCOL_VERSION = "FW02_01_PROTOCOL_VERSION";

    /**
     * 顧客IDキー.
     */
    public static final String KEY_COMPANY_ID = "cid";
    /**
     * 機器IDキー.
     */
    public static final String KEY_DEVICE_ID = "did";
    /**
     * コマンドキー.
     */
    public static final String KEY_COMMAND = "cmd";
    /**
     * サイズキー.
     */
    public static final String KEY_SIZE = "size";
    /**
     * 予約キー.
     */
    public static final String KEY_RESERVE = "rsv";

    /**
     * Longのバイト数.
     */
    public static final int LONG_BYTE_NUM = 8;

    /**
     * データ電文ソケット入力ストリーム(FW内処理のみ使用).
     */
    private InputStream in;

    /**
     * 読込バイト情報を保持する為のクラス.<br>
     * ※クラスはストリームだが、実態は、バイト配列を管理するのみ
     */
    private ByteArrayOutputStream byteAry;

    /**
     * ヘッダ部分割情報.
     */
    private Map<String, String[]> headerConf;

    /**
     * 固定長電文用(データ部分割情報).
     */
    private Map<String, String[]> fixedDataConf;

    /**
     * 可変長電文用(分割バイト).
     */
    private byte spliter = -1;

    /**
     * 可変長電文用(データ部開始位置).
     */
    private int valiableStart = -1;

    /**
     * 終端判別バイト.
     */
    private byte endPoint;

    /**
     * 終端判別有無.
     */
    private boolean endPointFlag;


    /**
     * 電文文字コード.
     */
    private String encoding;

    /**
     * 解析結果格納先.
     */
    private FW02_01_DenbunInfoBean bean;

    /**
     * コンストラクタ.
     */
    public FW02_01_SplitByteUtil() {
        this.headerConf = new HashMap<String, String[]>();
    }

    /**
     *
     * 入力ストリーム設定.<br>
     *<br>
     * 概要:<br>
     *   読込対象の電文(ストリーム)を設定する(終端判別バイト有)
     *<br>
     * @param _input 入力ストリーム
     * @param _endPoint エンドポイント
     */
    public void setData(final InputStream _input, final String _endPoint) {
        this.in = _input;
        this.byteAry = new ByteArrayOutputStream();

        if (!"".equals(_endPoint)) {
            this.endPoint = Byte.decode(_endPoint);
            this.endPointFlag = true;
        } else {
            this.endPointFlag = false;
        }
    }

    /**
     *
     * 入力ストリーム設定.<br>
     *<br>
     * 概要:<br>
     *   読込対象の電文(ストリーム)を設定する(終端判別バイト無)
     *<br>
     * @param _input 入力ストリーム
     */
    public void setData(final InputStream _input) {
        this.setData(_input, null);
    }

    /**
     *
     * 入力文字列設定.<br>
     *<br>
     * 概要:<br>
     *   読込対象の電文(文字列)を設定する
     *<br>
     * @param _input 入力文字列
     * @throws IOException 例外
     */
    public void setData(final String _input) throws IOException {
        this.byteAry = new ByteArrayOutputStream();
        this.byteAry.write(_input.getBytes());
    }

    /**
     *
     * プレフィックス設定情報設定.<br>
     *<br>
     * 概要:<br>
     *   プレフィックス設定情報をヘッダ設定に追加する
     *<br>
     * @param _conf プレフィックス設定情報
     */
    public void addPrefixConf(final String _conf) {
        this.headerConf.put(KEY_PREFIX, this.splitOffset(_conf));
    }

    /**
     *
     * 文字コード設定.<br>
     *<br>
     * 概要:<br>
     *   電文の文字コードを設定する
     *<br>
     * @param _encoding 文字コード
     */
    public void setEncoding(final String _encoding) {
        this.encoding = _encoding;
    }

    /**
     *
     * ヘッダ設定情報設定.<br>
     *<br>
     * 概要:<br>
     *   ヘッダ設定情報をヘッダ設定に追加する
     *<br>
     * @param _conf ヘッダ設定情報
     * @param _idx インデックス
     */
    public void addHeaderConf(final String _conf, final Long _idx) {
        int index = _idx.intValue() - 1;
        if (!"".equals(_conf)) {
            String[] itemConfList = _conf.split("/");
            for (String itemConf : itemConfList[index].split(",")) {
                String[] item = itemConf.split(":");
                this.headerConf.put(item[0], this.splitOffset(item[1]));
            }
        }
    }

    /**
     *
     * 固定長電文用データ設定情報設定.<br>
     *<br>
     * 概要:<br>
     *   固定長電文用のデータ設定情報を設定する
     *<br>
     * @param _conf データ設定情報
     */
    public void addDataConfForFixed(final String _conf) {
        this.fixedDataConf = new HashMap<String, String[]>();
        for (String itemConf : _conf.split(",")) {
            String[] item = itemConf.split(":");
            this.fixedDataConf.put(item[0], this.splitOffset(item[1]));
        }
    }

    /**
     *
     * 可変長電文用データ設定情報設定.<br>
     *<br>
     * 概要:<br>
     *   可変長電文用のデータ設定情報を設定する
     *<br>
     * @param _spliter 分割判別バイト(16進数表記)
     * @param _start データ部開始位置
     */
    public void addDataConfForVariable(final String _spliter, final int _start) {
        this.spliter = Byte.decode(_spliter);
        this.valiableStart = _start;
    }

    /**
     *
     * プレフィックス値取得.<br>
     *<br>
     * 概要:<br>
     *   プレフィックス値を取得する
     *<br>
     * @return プレフィックス値
     */
    public Long getPrefix() {

        if (this.in == null && this.byteAry == null) {
            //インプット情報が未設定時
            throw new RuntimeException("input data is not setting!");
        } else if (!this.headerConf.containsKey(KEY_PREFIX)) {
            //プレフィックス情報が未設定時
            throw new RuntimeException("prefixConf is not setting!");
        } else if (this.in != null) {
            //ストリーム設定時
            //プレフィックスの終端までストリームを読み込む
            int maxOffset = this.getMaxOffset(this.headerConf);
            this.setByteArray(maxOffset);
        }

        return this.getHeaderValue(KEY_PREFIX);
    }

    /**
     *
     * ヘッダ情報取得.<br>
     *<br>
     * 概要:<br>
     *   読み込んだ受信データから指定したキーのヘッダ情報を取得する
     *<br>
     * @param _key ヘッダキー
     * @return ヘッダ情報
     */
    public String getHeaderString(final String _key) {

        String[] prefixConf = this.headerConf.get(_key);
        int start = Integer.parseInt(prefixConf[0]);
        int end = Integer.parseInt(prefixConf[1]);

        return this.getString(start, start + end);
    }

    /**
     *
     * ヘッダ情報取得.<br>
     *<br>
     * 概要:<br>
     *   読み込んだ受信データから指定したキーのヘッダ情報を取得する
     *<br>
     * @param _key ヘッダキー
     * @return ヘッダ情報
     */
    public Long getHeaderValue(final String _key) {
        Long ret = null;

        try {
            String[] prefixConf = this.headerConf.get(_key);
            int start = Integer.parseInt(prefixConf[0]);
            int end = Integer.parseInt(prefixConf[1]);

            if (end <= LONG_BYTE_NUM) {
                byte[] byteArray = this.getBytes(start, start + end);
                long retVal = 0;
                final int shift = 8;
                final int mask = 0xff;
                int length = byteArray.length;
                if (length > shift) {
                    length = shift;
                }
                for (int i = 0; i < length; i++) {
                    retVal = (retVal << shift) + (byteArray[i] & mask);
                }
                ret = new Long(retVal);
                //ByteArrayInputStream bis = new ByteArrayInputStream(this.getBytes(start, start + end));
                //DataInputStream dis = new DataInputStream(bis);
                //ret = new Long(dis.readLong());
                //dis.close();
                //bis.close();
            }
        } catch (Exception e) {
            ret = null;
        }

        return ret;
    }

    /**
     *
     * 電文解析処理.<br>
     *<br>
     * 概要:<br>
     *   電文を解析する
     *<br>
     * @param _ipAddr IPアドレス
     * @param _version プロトコルバージョン
     */
    public void parseData(final String _ipAddr, final Long _version) {

        this.bean = new FW02_01_DenbunInfoBean();

        try {
            int headerOffset = 0;
            // プロトコルバージョンを設定
            this.bean.putHeaderInfo(KEY_PROTOCOL_VERSION, _version);
            this.bean.putHeaderInfoStr(KEY_PROTOCOL_VERSION, String.valueOf(_version));

            // ヘッダ情報解析
            if (this.headerConf != null && !this.headerConf.isEmpty()) {
                headerOffset = this.getMaxOffset(this.headerConf);
                this.setByteArray(headerOffset);

                for (String key : this.headerConf.keySet()) {
                    this.bean.putHeaderInfo(key, this.getHeaderValue(key));
                    this.bean.putHeaderInfoStr(key, this.getHeaderString(key));
                }

                // ヘッダ部バイト配列を保持(レスポンス用)
                this.bean.setHeaderByteArray(this.getBytes(0, headerOffset));
            }
            // IPアドレスを設定(Long用はなし)
            this.bean.putHeaderInfo(KEY_IP_ADDRESS, null);
            this.bean.putHeaderInfoStr(KEY_IP_ADDRESS, _ipAddr);

            if (this.fixedDataConf != null && !this.fixedDataConf.isEmpty()) {
                // 固定長データ情報解析
                int maxOffset = this.getMaxOffset(this.fixedDataConf);
                this.setByteArray(maxOffset);

                boolean fileFl = false;
                for (String key : this.fixedDataConf.keySet()) {
                    this.setItem(key, this.fixedDataConf.get(key)[0], this.fixedDataConf.get(key)[1]);
                    if (KEY_FILE_SIZE.equals(key)) {
                        fileFl = true;
                    }
                }

                // ファイル送信以外、かつ、未だ終端まで読み込んでいない場合は、終了判別バイト判定を行う
                if (!fileFl && (maxOffset != -1)) {
                    byte[] readBytes = this.readPacket(1);
                    if ((readBytes.length == 0) || (this.endPointFlag && readBytes[0] != this.endPoint)) {
                        // 読み込んだ最後尾が終了判別バイトで無い場合
                        throw new FW00_12_TelecomException("E01",
                                "Format error.[end point does not exist in packet data.]");
                    }
                }

            } else if (this.spliter != -1 && this.valiableStart != -1) {
                // 可変長データ情報解析
                this.setByteArray(-1);

                List<String> dataList = this.getSplitList(this.valiableStart);
                this.bean.setVariableDataInfo(dataList);
            } else {
                // 設定なしの場合
                this.setByteArray(-1);
                byte[] byteArray = this.byteAry.toByteArray();
                int dataLen = byteArray.length - headerOffset;
                //this.bean.setDataInfo(Arrays.copyOf(byteArray, dataLen));
                this.bean.setDataInfo(Arrays.copyOfRange(byteArray, headerOffset, headerOffset + dataLen));
                this.bean.setOriginalDataInfo(byteArray);
                //                if (this.byteAry.toByteArray().length != headerOffset) {
                //                    // データ部が存在する場合エラー
                //                    throw new FW00_12_TelecomException("E01",
                //                            "Format error.[packet data length more than " + headerOffset + "]");
                //                }
            }
        } catch (FW00_12_TelecomException e) {
            throw e;
        } finally {
            // 読み込んだバイトデータは確実に設定する。
            this.bean.setReceiveData(this.getString(0, -1));
        }
    }

    /**
     *
     * ファイルダウンロード処理.<br>
     *<br>
     * 概要:<br>
     *   ファイルをダウンロードする
     *<br>
     * @param _start ファイルバイナリ開始位置
     * @param _outputPath ファイル出力先
     */
    @SuppressWarnings("resource")
    public void downloadFile(final int _start, final String _outputPath) {

        if (this.in == null) {
            // Inputストリーム未設定時
            throw new RuntimeException("input data is not setting.");
        } else if (this.fixedDataConf == null || this.fixedDataConf.isEmpty()) {
            // 固定長電文で無い場合
            throw new RuntimeException("The file download function can use only the fixed length cable.");
        } else if (!this.fixedDataConf.containsKey(KEY_FILE_SIZE)) {
            // ファイルサイズ設定情報未設定時
            throw new RuntimeException("File size is not setting.");
        } else if (this.byteAry.size() > _start) {
            // ファイルバイナリデータの開始位置が、既に読込済みの場合(項目値としてファイルバイナリデータが使用されている為、不正とする)
            throw new RuntimeException("File start index error.");
        }

        // ファイルバイナリ開始位置迄、ストリーム位置を進める
        this.setByteArray(_start);

        File outFile = new File(_outputPath);
        FileOutputStream out = null;

        try {
            long fileSize = Long.parseLong(this.bean.getFixedDataItem(KEY_FILE_SIZE));
            long remainSize = fileSize;
            final int parSize = FW00_19_Const.KILO_BYTES;

            out = new FileOutputStream(outFile);

            if (fileSize != 0L) {
                byte[] data = new byte[parSize];

                do {
                    int readCnt = this.read(data);

                    if (readCnt > 0) {
                        // バイトを読み込んだ場合書き込む
                        out.write(data, 0, readCnt);
                    }

                    if (readCnt == parSize) {
                        // 1024バイト読み込んだ場合
                        remainSize -= parSize;
                    } else if (readCnt > 0 && readCnt < parSize) {
                        remainSize -= readCnt;
                        if (remainSize != 0) {
                            int readByte = this.checkNext();
                            if (readByte != -1) {
                                out.write(readByte);
                                remainSize--;
                            } else {
                                throw new FW00_12_TelecomException("E01",
                                        "File size error.[remain:" + remainSize + "/" + fileSize + "byte]");
                            }
                        }
                    } else {
                        throw new FW00_12_TelecomException("E01",
                                "File size error.[remain:" + remainSize + "/" + fileSize + "byte]");
                    }
                } while (remainSize > 0);
            }

            OutputStreamUtil.flush(out);
            this.bean.putFixedDataInfo(KEY_SAVE_FILE_PATH, _outputPath);
        } catch (IOException e) {
            throw new FW00_12_AppException(e);
        } finally {
            OutputStreamUtil.close(out);
        }
    }

    /**
     *
     * 解析結果取得.<br>
     *<br>
     * 概要:<br>
     *   解析結果を取得する
     *<br>
     * @return 解析結果(ヘッダ情報、データ情報)
     */
    public FW02_01_DenbunInfoBean getParseData() {
        return this.bean;
    }

    /**
     *
     * 読込済みバイト変数設定.<br>
     *<br>
     * 概要:<br>
     *   読込済みのバイト長以上のデータを取り込む為に、読込済みバイト変数を再設定する。
     *<br>
     * @param _length バイト長
     */
    private void setByteArray(final int _length) {
        // 読込済みのデータ長
        int readedLength = this.byteAry.size();

        try {
            if (readedLength < _length) {
                // 読込済みのデータ長よりもセット位置が深い場合
                int readLength = _length - readedLength;
                byte[] readBytes = this.readPacket(readLength);

                if (readBytes.length < readLength
                        || (this.endPointFlag && readBytes[readBytes.length - 1] == this.endPoint)) {
                    // 指定の終端オフセットまで到達出来ないか、オフセット位置のバイトが終端バイトの場合エラー
                    if (readBytes.length > 0) {
                        // エラーログ用に読み込んだバイトデータをセット
                        this.byteAry.write(readBytes, 0, readBytes.length);
                    }
                    throw new FW00_12_TelecomException("E01",
                            "Format error.[packet data length less than " + _length + "]");
                }

                this.byteAry.write(readBytes);

            } else if (_length == -1) {
                // 終端まで読み込む場合
                int readLength = 0;

                boolean condition = true;

                while (condition) {
                    //byte[] readBytes = this.readPacket(FW00_19_Const.KILO_BYTES);

                    // データ部分を読み込む
                    Long dataSize = this.getDataSize();
                    byte[] readBytes = this.readPacket(dataSize.intValue());
                    readLength = readBytes.length;

                    if (readLength == 0) {
                        if (this.endPointFlag) {
                            // 終了判別バイト無しで終端に到達時
                            throw new FW00_12_TelecomException("E01",
                                    "Format error.[end point does not exist in packet data.]");
                        } else {
                            condition = false;
                        }
                    } else if (readLength == FW00_19_Const.KILO_BYTES && readBytes[readLength - 1] != this.endPoint) {

                        if (this.endPointFlag) {
                            if (readBytes[readLength - 1] != this.endPoint) {
                                //1024バイト全て読込、且つ配列最後尾が終了判別バイトでない場合
                                this.byteAry.write(readBytes);
                            } else {
                                //1024バイト全て読込、且つ配列最後尾が終了判別バイトの場合
                                this.byteAry.write(readBytes, 0, readLength - 1);
                                condition = false;
                            }
                        } else {
                            //1024バイト全て読込、且つ終了判別なし場合
                            this.byteAry.write(readBytes, 0, readLength);
                            condition = false;
                        }
                    } else {
                        //読み込んだバイト長が1024に満たない場合
                        if (this.endPointFlag) {
                            if (readBytes[readLength - 1] != this.endPoint) {
                                // 読み込んだ最後尾が終了判別バイトで無い場合
                                if (readLength > 0) {
                                    // エラーログ用に読み込んだバイトデータをセット
                                    this.byteAry.write(readBytes, 0, readLength);
                                }
                                throw new FW00_12_TelecomException("E01",
                                        "Format error.[end point does not exist in packet data.]");
                            } else {
                                this.byteAry.write(readBytes, 0, readLength - 1);
                                condition = false;
                            }
                        } else {
                            //this.byteAry.write(readBytes, 0, readLength - 1);
                            this.byteAry.write(readBytes, 0, readLength);
                            condition = false;
                        }
                    }
                }
            }
        } catch (IOException e) {
            throw new FW00_12_AppException(e);
        }
    }

    /**
     *
     * パケット読込(内部メソッド).<br>
     *<br>
     * 概要:<br>
     *   指定サイズ分パケットを読み込む
     *<br>
     * @param _readSize サイズ
     * @return パケットのバイト配列
     */
    private byte[] readPacket(final int _readSize) {
        return this.readPacket(_readSize, new ByteArrayOutputStream()).toByteArray();
    }

    /**
     *
     * パケット読込(内部メソッド).<br>
     *<br>
     * 概要:<br>
     *   指定サイズ分パケットを読み込む
     *<br>
     * @param _readSize サイズ
     * @param _readBytes 出力ストリーム
     * @return 出力ストリーム
     */
    private ByteArrayOutputStream readPacket(final int _readSize, final ByteArrayOutputStream _readBytes) {
        byte[] readByte = new byte[_readSize];

        try {
            int readSize = this.read(readByte);

            if (readSize == -1) {
                return _readBytes;
            } else if (readSize == _readSize) {
                _readBytes.write(readByte);
                return _readBytes;
            } else {
                int remainSize = _readSize - readSize;
                _readBytes.write(readByte, 0, readSize);
                int checkByte = this.checkNext();
                if (checkByte != -1) {
                    _readBytes.write(checkByte);
                    if (--remainSize != 0) {
                        return this.readPacket(remainSize, _readBytes);
                    } else {
                        return _readBytes;
                    }
                } else {
                    return _readBytes;
                }
            }
        } catch (IOException e) {
            throw new FW00_12_AppException(e);
        }
    }

    /**
     *
     * データ部項目値設定.<br>
     *<br>
     * 概要:<br>
     *   データ部の項目値を設定する
     *<br>
     * @param _key 項目設定キー
     * @param _start 項目開始位置
     * @param _info 項目設定情報
     */
    private void setItem(final String _key, final String _start, final String _info) {
        try {
            if (_info.matches("^[0-9]+[n]$")) {
                // 繰り返し項目の場合
                this.bean.putFixedDataInfo(_key, this.getListItem(Integer.parseInt(_start), _info));
            } else if (_info.matches("^[*]$")) {
                // アスタリスク指定の場合
                this.bean.putFixedDataInfo(_key, this.getString(Integer.parseInt(_start), -1));
            } else {
                this.bean.putFixedDataInfo(_key, this.getString(Integer.parseInt(_start),
                        Integer.parseInt(_start) + Integer.parseInt(_info)));
            }
        } catch (IOException e) {
            throw new FW00_12_TelecomException("E01",
                    "Format error.[item(" + _key + ") does not match (offset:" + _start + ",pattern:" + _info + ")]");
        }
    }

    /**
     *
     * 繰り返し項目読込.<br>
     *<br>
     * 概要:<br>
     *   繰り返し項目を読み込む
     *<br>
     * @param _start 項目開始位置
     * @param _info 項目設定情報
     * @return 繰り返し項目
     * @throws IOException 例外
     */
    private List<String> getListItem(final int _start, final String _info) throws IOException {
        List<String> list = new ArrayList<String>();
        // 開始位置から終端までを取得
        byte[] items = this.getBytes(_start, -1);

        // 単項目のバイト長を取得
        int itemLength = Integer.parseInt(_info.replaceAll("[n]", ""));

        if (items.length % itemLength != 0) {
            //単項目バイト長の等倍にならない場合エラーとする。
            throw new IOException();
        }

        for (int i = 0; i < items.length; i += itemLength) {
            String item = new String(Arrays.copyOfRange(items, i, i + itemLength));
            list.add(item);
        }
        return list;
    }

    /**
     *
     * 対象項目文字列取得.<br>
     *<br>
     * 概要:<br>
     *   蓄積したバイト配列から、対象項目の文字列を取得する
     *<br>
     * @param _start 開始位置
     * @param _end 終了位置
     * @return 対象項目文字列
     */
    private String getString(final int _start, final int _end) {
        try {
            if (this.encoding != null && !this.encoding.equals("")) {
                return new String(this.getBytesString(_start, _end), this.encoding);
            } else {
                return new String(this.getBytesString(_start, _end));
            }
        } catch (UnsupportedEncodingException e) {
            throw new FW00_12_BusinessException(e);
        }
    }

    /**
     *
     * 対象項目バイト配列取得.<br>
     *<br>
     * 概要:<br>
     *   蓄積したバイト配列から、対象項目のバイト配列を取得する
     *<br>
     * @param _start 開始位置
     * @param _end 終了位置
     * @return 対象項目バイト配列
     */
    private byte[] getBytes(final int _start, final int _end) {

        if (_end != -1) {
            return Arrays.copyOfRange(this.byteAry.toByteArray(), _start, _end);
        } else {
            return Arrays.copyOfRange(this.byteAry.toByteArray(), _start, this.byteAry.size());
        }
    }

    /**
     *
     * 対象項目バイト配列取得.<br>
     *<br>
     * 概要:<br>
     *   蓄積したバイト配列から、対象項目のバイト配列を取得する(終端文字列を除く)
     *<br>
     * @param _start 開始位置
     * @param _end 終了位置
     * @return 対象項目バイト配列
     */
    private byte[] getBytesString(final int _start, final int _end) {

        // 終端コード
        byte endCode = 0x00;

        int end = _end;
        byte[] byteArrayTmp = this.byteAry.toByteArray();
        if (_end == -1) {
            end = byteArrayTmp.length;
        }

        int endCodePoint = _end;
        for (int i = _start; i <= end; i++) {
            if (byteArrayTmp[i] == endCode) {
                endCodePoint = i;
                if (i == _start) {
                    endCodePoint = _start;
                }
                break;
            }
        }

        return Arrays.copyOfRange(this.byteAry.toByteArray(), _start, endCodePoint);
    }

    /**
     *
     * 可変長電文データ分割.<br>
     *<br>
     * 概要:<br>
     *   可変長電文のデータを分割する
     *<br>
     * @param _start データ部開始位置
     * @return 項目値一覧
     */
    private List<String> getSplitList(final int _start) {
        byte[] item = Arrays.copyOfRange(this.byteAry.toByteArray(), _start, this.byteAry.size());
        return this.getSplitList(item, new ArrayList<String>());
    }

    /**
     *
     * 可変長電文データ分割再帰処理.<br>
     *<br>
     * 概要:<br>
     *   可変長電文のデータを再帰的に分割する
     *<br>
     * @param _item データ部
     * @param _list 項目値一覧
     * @return 項目値一覧
     */
    private List<String> getSplitList(final byte[] _item, final List<String> _list) {

        for (int i = 0; i < _item.length; i++) {
            if (_item[i] == this.spliter) {
                _list.add(new String(Arrays.copyOfRange(_item, 0, i)));
                return this.getSplitList(Arrays.copyOfRange(_item, i + 1, _item.length), _list);
            } else {
                continue;
            }
        }
        _list.add(new String(Arrays.copyOfRange(_item, 0, _item.length)));
        return _list;
    }

    /**
     *
     * オフセット位置最大値取得.<br>
     *<br>
     * 概要:<br>
     *   オフセット位置の最大値を取得する
     *<br>
     * @param _info 情報
     * @return 最大オフセット位置
     */
    private int getMaxOffset(final Map<String, String[]> _info) {
        int result = 0;

        for (String[] itemInfo : _info.values()) {
            if (itemInfo[1].matches("^[0-9]+$")) {
                int offset = Integer.parseInt(itemInfo[0]) + Integer.parseInt(itemInfo[1]);

                if (result < offset) {
                    result = offset;
                }
            } else {
                return -1;
            }
        }
        return result;
    }

    /**
     *
     * 項目分割位置情報編集.<br>
     *<br>
     * 概要:<br>
     *   項目分割位置情報を編集する
     *<br>
     * @param _data 項目分割位置情報
     * @return 項目分割位置情報リスト
     */
    private String[] splitOffset(final String _data) {
        String[] conf = _data.split("[-]");

        if (!conf[0].matches("^[0-9]+$")) {
            // 開始位置に数値以外が設定されている
            throw new RuntimeException("item setting format error.");
        } else if (!conf[1].matches("^[0-9]+$")) {
            // 開始位置に数値以外が設定されている
            throw new RuntimeException("item setting format error.");
        }

        //        // フォーマットチェック
        //        if (!"n".equals(conf[0]) && !"s".equals(conf[0])) {
        //            // 型にn,s以外が設定されている
        //            throw new RuntimeException("item setting format error.");
        //        } else if (!conf[1].matches("^[0-9]+$")) {
        //            // 開始位置に数値以外が設定されている
        //            throw new RuntimeException("item setting format error.");
        //        } else if (!conf[2].matches("^[*]$") && !conf[2].matches("^[0-9]+[n]*$")) {
        //            // 項目バイト長設定が、「*」か「(数値)n」、「(数値)」でない
        //            throw new RuntimeException("item setting format error.");
        //        }
        return conf;
    }

    /**
     *
     * ストリーム読込.<br>
     *<br>
     * 概要:<br>
     *   ソケットのINPUT情報を指定バイト分読み込む
     *<br>
     * @param _byte 格納用バイト配列
     * @return 読み込んだバイト数
     */
    private int read(final byte[] _byte) {
        try {
            return this.in.read(_byte);
        } catch (SocketTimeoutException e) {
            return -1;
        } catch (SocketException e) {
            return -1;
        } catch (IOException e) {
            throw new FW00_12_AppException(e);
        }
    }

    /**
     *
     * 入力ストリームチェック.<br>
     *<br>
     * 概要:<br>
     *   次のバイト情報があるかチェックする。
     *<br>
     * @return バイト数
     */
    private int checkNext() {
        try {
            int readByte = this.in.read();
            return readByte;
        } catch (SocketTimeoutException e) {
            return -1;
        } catch (SocketException e) {
            return -1;
        } catch (IOException e) {
            throw new FW00_12_AppException(e);
        }
    }

    /**
     *
     * 読込みバイト情報取得.<br>
     *<br>
     * 概要:<br>
     *   読込済みの電文情報を文字列で返却する。
     *<br>
     * @return バイト文字列
     */
    public String getByteAry() {
        if (this.byteAry == null) {
            return null;
        } else {
            return this.byteAry.toString();
        }
    }

    /**
     *
     * データ部分サイズ取得.<br>
     *<br>
     * 概要:<br>
     *   ヘッダ情報からデータサイズを取得して返却する。
     *<br>
     * @return データサイズ
     */
    public Long getDataSize() {

        // ヘッダ情報を取得する
        Map<String, Long> headerInfoMap = this.bean.getHeaderInfo();

        return headerInfoMap.get(KEY_SIZE);
    }
}
