/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+==========================================================+========+==============
 *  DATE      | Comments                                                 | Rev    | SIGN
 * ===========+==========================================================+========+==============
 *  2014/02/10| 新規作成                                                 | 1.00.00| YSK)植山
 *  2014/06/24| <10000-074>機器IDのIPアドレス対応                        | 1.01.00| YSK)大山
 *  2014/06/24| <10000-075>ファイル出力処理修正                          | 1.01.00| YSK)大山
 *  2014/07/07| <10000-079>通信禁止時間調整                              | 1.01.00| YSK)大山
 *  2014/07/17| <10000-157>通信禁止時間調整                              | 1.01.00| YSK)大山
 *  2014/08/26| <10101-005> ログ追加                                     | 1.02.00| YSK)植山
 *  2014/09/02| <10101-011> リリース後不具合対応                         | 1.02.00| YSK)大山
 *  2015/01/23| <20000-012> ステータス通知                               | 3.00.00| YSK)植山
 *  2015/03/10| ST2障害対応(No.44)                                       | 3.00.01| YSK)植山
 *  2015/06/23| <30003-033> 変更仕様No.12                                | 3.01.00| US)萩尾
 *  2015/07/02| <30003-036> 変更仕様No.26                                | 3.01.00| US)萩尾
 *  2015/08/04| <30003-048> 故障苦情No.30003-063                         | 3.01.00| US)萩尾
 *  2016/01/11| <40000-020> 変更仕様No.20                                | 4.00.00| US)萩尾
 *  2016/01/16| <40000-031> 変更仕様No.31(故障苦情No.30100-006)          | 4.00.00| US)萩尾
 *  2016/01/18| <40000-028> 変更仕様No.28                                | 4.00.00| US)萩尾
 *  2016/05/11| <40000-044> 不具合対応                                   | 4.01.00| YSK)植山
 *  2016/05/31| <40000-042> 機能改造 コマンド実行                        | 4.01.00| YSK)三村
 * -----------+----------------------------------------------------------+--------+--------------
 */
package jp.ysk.fw.telecom.socket;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import jp.ysk.fw.FW00_12_AppException;
import jp.ysk.fw.FW00_12_BusinessException;
import jp.ysk.fw.FW00_12_TelecomException;
import jp.ysk.fw.FW00_12_TelecomException.RESPONSE_TYPE;
import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.telecom.FW02_01_CommSocketMain;
import jp.ysk.fw.telecom.FW02_01_TelecomConst;
import jp.ysk.fw.telecom.dto.CM_ReceiveInvalidDto;
import jp.ysk.fw.telecom.socket.bean.FW02_01_CommunicationInfoBean;
import jp.ysk.fw.telecom.socket.bean.FW02_01_CommunicationInfoBean.COMMUNICATION_TYPE;
import jp.ysk.fw.telecom.socket.bean.FW02_01_DenbunInfoBean;
import jp.ysk.fw.telecom.util.FW02_01_SplitByteUtil;
import jp.ysk.fw.util.FW00_01_IDMakerUtil;
import jp.ysk.fw.util.FW00_06_MessageResourceUtil;
import jp.ysk.fw.util.FW00_23_LoggerUtil;

/**
 *
 * 子スレッド処理.<br>
 *<br>
 * 概要:<br>
 *   電文を解析し、業務ロジックを呼出す
 *<br>
 */
public class FW02_01_ChildSocket extends Thread {


    /**
     * TCP受信ソケット(SSLの場合も共用).
     */
    private Socket tcpSocket;

    /**
     * UDP受信ソケット.
     */
    private DatagramSocket udpSocket;

    /**
     * UDP受信パケット.
     */
    private DatagramPacket udpPacket;

    /**
     * 受信ストリーム(共通).
     */
    private InputStream in;

    /**
     * 通信種別列挙帯定義.
     */
    private enum TELEGRAPHIC_TYPE {
        /**
         * TCP.
         */
        TCP,
        /**
         * UDP.
         */
        UDP
    }

    /**
     * 電文タイプ.
     */
    private TELEGRAPHIC_TYPE type;

    /**
     * 電文ヘッダ部文字コード.
     */
    private String encoding;

    /**
     * 電文ヘッダ種別識別情報.
     */
    private String headerPrefix;

    /**
     * 識別子文字列.
     */
    private String prefixStr;

    /**
     * 電文ヘッダ情報格納コレクション.
     */
    private String headerConf;

    /**
     * 終端バイト.
     */
    private String endPoint;

    /**
     * プロセスID.
     */
    public String processId;

    /**
     * ポート番号.
     */
    public int portNum;

    /**
     * 失敗ディレクトリパス.
     */
    private String pathFail;

    /**
     * 受信ファイル受信ディレクトリパス.
     */
    private String pathReceiveFile;

    /**
     * 顧客ID(起動引数).
     */
    private String companyIdExec;

    /**
     * コンストラクタ.<br>
     * @param _encoding 電文ヘッダ部文字コード
     * @param _headerPrefix 電文ヘッダ種別識別情報
     * @param _prefixStr 識別子文字列
     * @param _headerConf 電文ヘッダ情報
     * @param _endPoint 終端バイト
     */
    public FW02_01_ChildSocket(
            final String _encoding, final String _headerPrefix,
            final String _prefixStr, final String _headerConf, final String _endPoint) {
        this.encoding = _encoding;
        this.headerPrefix = _headerPrefix;
        this.prefixStr = _prefixStr;
        this.headerConf = _headerConf;
        this.endPoint = _endPoint;
    }

    /**
     *
     * ソケットセッター(TCPプロトコル向け).<br>
     *<br>
     * 概要:<br>
     *   ソケットを設定する(TCPプロトコル向け)
     *<br>
     * @param _tcpSocket TCPソケット
     */
    public void setSocket(final Socket _tcpSocket) {
        this.tcpSocket = _tcpSocket;
        this.type = TELEGRAPHIC_TYPE.TCP;
    }

    /**
     *
     * ソケットセッター(UDPプロトコル向け).<br>
     *<br>
     * 概要:<br>
     *   ソケットを設定する(UDPプロトコル向け)
     *<br>
     * @param _udpSocket UDPソケット
     * @param _updPacket UDPパケット
     */
    public void setSocket(final DatagramSocket _udpSocket, final DatagramPacket _updPacket) {
        this.udpSocket = _udpSocket;
        this.udpPacket = _updPacket;
        this.type = TELEGRAPHIC_TYPE.UDP;
    }

    /**
     *
     * プロセスIDセッター.<br>
     *<br>
     * 概要:<br>
     *   プロセスIDを設定する
     *<br>
     * @param _processId プロセスID
     */
    public void setProcessID(final String _processId) {
        this.processId = _processId;
    }

    /**
     *
     * ポート番号セッター.<br>
     *<br>
     * 概要:<br>
     *   ポート番号を設定する
     *<br>
     * @param _portNum ポート番号
     */
    public void setPortNum(final int _portNum) {
        this.portNum = _portNum;
    }

    /**
     *
     * 顧客IDセッター.<br>
     *<br>
     * 概要:<br>
     *   顧客IDを設定する
     *<br>
     * @param _companyId 顧客ID
     */
    public void setCompanyID(final String _companyId) {
        this.companyIdExec = _companyId;
    }

    /**
     * 失敗ディレクトリパス(顧客別ディレクトリ内)セッター.<br>
     *<br>
     * 概要:<br>
     * 　失敗ディレクトリパスを設定する
     * @param _pathFail 失敗ディレクトリパス
     */
    public void setPathFail(final String _pathFail) {
        this.pathFail = _pathFail;
    }

    /**
     * 受信ファイル作成ディレクトリパス(顧客別ディレクトリ内)セッター.<br>
     *<br>
     * 概要:<br>
     * 　受信ファイル作成ディレクトリパスを設定する
     * @param _pathReceiveFile 受信ファイル作成ディレクトリパス
     */
    public void setPathReceiveFile(final String _pathReceiveFile) {
        this.pathReceiveFile = _pathReceiveFile;
    }

    /**
     *
     * クライアントソケットIPアドレス取得.<br>
     *<br>
     * 概要:<br>
     *   クライアントのIPアドレスを取得する。
     *<br>
     * @return IPアドレス(xxx.xxx.xxx.xxx)
     */
    public String getSocketIP() {
        switch (this.type) {
            case TCP:
                return this.tcpSocket.getInetAddress().getHostAddress();
            case UDP:
                return this.udpPacket.getAddress().getHostAddress();
            default:
                return null;
        }
    }

    /**
     * スレッド処理.
     */
    public void run() {

        // 電文フォーマット情報
        FW02_01_CommunicationInfoBean bean = null;
        // 電文解析情報
        FW02_01_DenbunInfoBean parseBean = null;
        // 電文解析ユーティリティ
        FW02_01_SplitByteUtil util = null;
        // データ連携業務ロジック
        FW02_01_TelecomLogicInterface business = null;
        // 送信文字列
        byte[] send = null;
        // デバッグログ詳細情報
        String debugDetail = "";
        // 通信禁止期間内フラグ
        boolean invalidFlag = false;
        // 顧客ID
        String companyId = null;
        // 機器ID
        String deviceId = null;
        // コマンドCD
        Long commandCode = null;
        // 通信相手のIPアドレス
        String ipAddr = "nothing";
        // 通信日時を取得
        Date now = new Date();

        Long telecomLogSid = null;
        try {
            ipAddr = this.getSocketIP();
            this.outputAccessLog(null, "********** Thread Start [" + ipAddr + "] **********");

            // INPUTストリームの設定
            switch (this.type) {
                case TCP:
                    this.in = this.tcpSocket.getInputStream();
                    break;
                case UDP:
                    byte[] receivePacket = this.udpPacket.getData();
                    int dataLength = this.udpPacket.getLength();
                    this.in = new ByteArrayInputStream(receivePacket, 0, dataLength);
                    break;
                default:
                    break;
            }
            util = new FW02_01_SplitByteUtil();
            util.setData(this.in, this.endPoint);
            util.addPrefixConf(this.headerPrefix);
            // 電文ヘッダ部の文字コードを設定
            util.setEncoding(this.encoding);

            // プロトコルバージョン
            Long version = util.getPrefix();
            boolean flag = false;
            for (Long protocolVersion : FW02_01_TelecomConst.ACCEPT_PROTOCOL_VERSION) {
                if (protocolVersion.equals(version)) {
                    flag = true;
                    break;
                }
            }
            if (!flag) {
                // プロトコルバージョン不正
                this.outputAccessLog(null, "### Undefined protocol version=" + version + " [" + FW02_01_TelecomConst.ERRCODE.TER101 + "] ###");

                throw new FW00_12_TelecomException("E01", "Undefined protocol version");
            }

            // ヘッダ情報を設定されている場合
            util.addHeaderConf(this.headerConf, version);

            // 電文解析処理
            util.parseData(ipAddr, version);
            String headerByteArrayStr = "";
            for (byte headerByte : util.getParseData().getHeaderByteArray()) {
                headerByteArrayStr += String.format("%02X ", headerByte);
            }
            this.outputAccessLog(null, "header byteArray=" + headerByteArrayStr);

            // 1000より大きい場合は、最上位桁以外を0に変換(0001⇒0001, 1001⇒1000, 2001⇒2000)
            Long commandCd = util.getHeaderValue(this.prefixStr);
            long commandCdWork = commandCd.longValue();
            String commandCdStr = String.format("%1$04d", commandCdWork);
            if (commandCdWork >= FW02_01_TelecomConst.COMMAND_FILE_DATA_NUM) {
                commandCdStr = FW02_01_TelecomConst.COMMAND_FILE_DATA_STR;

            } else if (commandCdWork >= FW02_01_TelecomConst.COMMAND_DATA_NUM) {
                commandCdStr = FW02_01_TelecomConst.COMMAND_DATA_STR;
            }

            //キーの決定、反映
            bean = (FW02_01_CommunicationInfoBean) FW02_01_CommSocketMain.callContainer(commandCdStr);
            if (bean == null) {
                this.outputAccessLog(null, "### Unknown commandCd=" + commandCdStr + " ###");

                throw new FW00_12_TelecomException("E01", "Unknown commandCd");
            }
            // 業務ロジックの初期化
            String componentName = bean.getComponentName();
            business = (FW02_01_TelecomLogicInterface) FW02_01_CommSocketMain.callContainer(componentName);

            if ("file".equals(bean.getDataType())) {
                //ファイル名生成用のプレフィックス定義をID採番部品に追加する
                String fileName = FW00_01_IDMakerUtil.getSystemId("9");
                util.downloadFile(bean.getFileStart(), bean.getSaveDirPath() + File.separator + fileName);
            }

            parseBean = util.getParseData();

            parseBean = business.editDto(parseBean);

            // ソケットクローズ処理
            if (bean.getComunicationType().equals(COMMUNICATION_TYPE.RECEIVE_NOWAIT)) {
                this.close();
            }

            // ヘッダ情報を取得する
            Map<String, Long> headerInfoMap = parseBean.getHeaderInfo();

            // ヘッダ情報(文字列)を取得する
            Map<String, String> headerInfoStrMap = parseBean.getHeaderInfoStr();

            // 顧客IDを取得
            companyId = headerInfoStrMap.get(FW02_01_SplitByteUtil.KEY_COMPANY_ID);
            if (!companyId.equals(this.companyIdExec)) {
                // 起動時の顧客IDと異なる場合
                this.outputAccessLog(null, "### Unknown companyId=" + companyId + " [" + FW02_01_TelecomConst.ERRCODE.TER200 + "] ###");

                throw new FW00_12_TelecomException("E01", "Unknown companyId");
            }

            // データサイズをチェック
            Long size = parseBean.getHeaderInfo().get(FW02_01_SplitByteUtil.KEY_SIZE);
            if (size.longValue() > FW02_01_TelecomConst.MAX_RECEIVE_SIZE) {
                // 最大受信サイズを超えた場合は終了
                this.outputAccessLog(null, "### Telegram length over.(" + size + " > " + FW02_01_TelecomConst.MAX_RECEIVE_SIZE + "(max)) ["
                        + FW02_01_TelecomConst.ERRCODE.TER105 + "] ###");

                throw new FW00_12_TelecomException("E01", "Telegram length over");
            }

            // 機器IDを取得
            if (version.longValue() == 2) {
                deviceId = headerInfoStrMap.get(FW02_01_SplitByteUtil.KEY_IP_ADDRESS);
                deviceId = this.convertIPAddress(deviceId);
            } else {
                deviceId = headerInfoStrMap.get(FW02_01_SplitByteUtil.KEY_DEVICE_ID);
            }
            // コマンドCDを取得
            commandCode = headerInfoMap.get(FW02_01_SplitByteUtil.KEY_COMMAND);
            // 予約を取得
            String reserve = headerInfoStrMap.get(FW02_01_SplitByteUtil.KEY_RESERVE);

            // ログ出力
            this.outputAccessLog(deviceId, "protocolVer:" + version + ", commandCode:" + String.format("%1$04X", commandCode));

            // 通信禁止時間内に通信があったかどうかを判定(コマンドコードが1000以降のみチェック対象)
            if (commandCd.longValue() >= FW02_01_TelecomConst.COMMAND_DATA_NUM) {
                invalidFlag = this.isInvalidTimeData(deviceId, commandCode, now);
                if (!invalidFlag) {
                    // 通信禁止期間を過ぎていた場合は、前回の通信状態を確認
                    invalidFlag = this.isInvalidStatus(deviceId, commandCode);
                }
            }

            if (!invalidFlag) {
                // 業務処理前処理実行
                telecomLogSid = business.beforeExecute(
                        this.processId,
                        companyId,
                        version,
                        deviceId,
                        commandCode,
                        reserve,
                        now,
                        this.portNum,
                        size,
                        this.pathReceiveFile);

                // 受信したIPアドレスを電文解析情報にセット
                parseBean.setIpAddress(ipAddr);

                if (telecomLogSid != null) {
                    if (COMMUNICATION_TYPE.valueOf(bean.getComunicationType()).equals(COMMUNICATION_TYPE.SEND_BEFORE)) {
                        byte[] beforeSend = business.getBeforeResponse(parseBean);
                        if (beforeSend != null) {
                            // 業務処理前にレスポンス送信
                            this.sendData(beforeSend);

                            // 業務処理を実行
                            business.execute(parseBean);
                        }
                    } else {
                        // 業務処理を実行
                        send = business.execute(parseBean);
                    }
                }
            }

        } catch (FW00_12_TelecomException e) {
            if (util != null && util.getParseData() != null && util.getParseData().getReceiveData() != null) {
                // 解析途中に例外が発生した場合
                this.outputErrorLog(deviceId, "receive data=" + util.getParseData().getReceiveData(), e);

                // バックアップファイル出力
                this.outputBackupFile(companyId, deviceId, commandCode, now, parseBean);
            } else {
                // 解析前に例外が発生した場合
                if ((util != null) && (util.getByteAry() != null)) {
                    this.outputErrorLog(deviceId, "reading data=" + util.getByteAry(), e);
                } else {
                    this.outputErrorLog(deviceId, "data get error", e);
                }
            }
            send = this.editErrorSendData(e.getType(), bean);
        } catch (FW00_12_BusinessException e) {
            this.outputErrorLog(deviceId, FW00_06_MessageResourceUtil.getMessage(e.getMsgKey(), e.getMsgArgs()), e);
            send = this.editErrorSendData(RESPONSE_TYPE.DEFAULT, bean);
        } catch (FW00_12_AppException e) {
            this.outputErrorLog(deviceId, "appException", e);
            send =  this.editErrorSendData(RESPONSE_TYPE.DEFAULT, bean);
        }  catch (Exception e) {
            if (util != null && util.getParseData() != null && util.getParseData().getReceiveData() != null) {
                // 解析途中に例外が発生した場合
                this.outputErrorLog(deviceId, "receive data=" + util.getParseData().getReceiveData(), e);

                // バックアップファイル出力
                this.outputBackupFile(companyId, deviceId, commandCode, now, parseBean);
            } else {
                // 解析前に例外が発生した場合
                if ((util != null) && (util.getByteAry() != null)) {
                    this.outputErrorLog(deviceId, "reading data=" + util.getByteAry(), e);
                } else {
                    this.outputErrorLog(deviceId, "data get error", e);
                }
            }
            send =  this.editErrorSendData(RESPONSE_TYPE.DEFAULT, bean);
        } finally {
            try {
                if (business != null) {

                    if (!invalidFlag) {
                        // 通信状態を"終了"に設定
                        FW02_01_AbstractSocketBase.setTelecomStatus(deviceId, commandCode, CM_ReceiveInvalidDto.END);
                        if (telecomLogSid != null) {
                            business.endProcess(send, telecomLogSid);
                        }
                    }
                }

                // クライアント送信処理
                if (bean == null) {
                    this.close();

                } else {
                    COMMUNICATION_TYPE commType = COMMUNICATION_TYPE.valueOf(bean.getComunicationType());
                    if (!"".equals(send)) {
                        // 送信電文有時(例外時の応答含む)に従う場合
                        switch (commType) {
                            case SEND_BEFORE:
                            case SEND_NOWAIT:
                                this.sendData(send);
                                this.close();
                                break;
                            case SEND:
                                this.sendData(send);
                                break;
                            case RECEIVE:
                                this.sendData(send);
                                break;
                            default:
                                break;
                        }
                    } else {
                        // 送信電文無し時(例外時強制非応答含む)
                        if (bean == null
                                || COMMUNICATION_TYPE.SEND_BEFORE.equals(commType)
                                || COMMUNICATION_TYPE.SEND_NOWAIT.equals(commType)) {
                            this.close();
                        }
                    }
                }

                this.outputDebugLog(deviceId, "サーバ処理が終了しました。" + debugDetail);

                boolean closeResult = this.waitClose();

                if (this.type.equals(TELEGRAPHIC_TYPE.UDP)) {
                    this.outputDebugLog(deviceId, "UDP受信処理を終了します。" + debugDetail);
                } else if (closeResult) {
                    // クライアントから切断された場合
                    this.outputDebugLog(deviceId, "クライアント処理によりソケットが切断しました。" + debugDetail);
                } else {
                    // タイムアウトによる切断処理
                    this.outputDebugLog(deviceId, "タイムアウトの為、ソケットを切断します。" + debugDetail);
                }

                if (bean != null && bean.getComunicationType() != null) {
                    switch (COMMUNICATION_TYPE.valueOf(bean.getComunicationType())) {
                        case RECEIVE:
                            this.close();
                            break;
                        case SEND:
                            this.close();
                            break;
                        default:
                            break;
                    }
                } else {
                    this.close();
                }

            } catch (Exception e) {
                this.outputErrorLog(deviceId, "exception in finally", e);
            }

            this.outputAccessLog(null, "********** Thread End [" + ipAddr + "] **********");
        }

    }

    /**
     *
     * 通信禁止時間内判定処理.<br>
     *<br>
     * 概要:<br>
     *   通信禁止時間内の通信かどうかを判定する。
     *<br>
     * @param _deviceId 機器ID
     * @param _telecomDate 通信日時
     * @return 判定結果(true:通信禁止期間内, false:通信禁止期間経過後)
     */
    private boolean isInvalidTimeData(final String _deviceId, final Long _commandCd, final Date _telecomDate) {

        boolean invalidFlag = false;
        Date preTelecomDate = FW02_01_AbstractSocketBase.getTelecomDate(_deviceId, _commandCd);
        if (preTelecomDate == null) {
            FW02_01_AbstractSocketBase.setTelecomDate(_deviceId, _commandCd, _telecomDate);
        } else {

            // 前回通信時間からの経過時間
            long span = _telecomDate.getTime() - preTelecomDate.getTime();
            if (span <= FW02_01_TelecomConst.TELECOM_INVALID_SPAN) {
                // 通信禁止時間内の場合はデータ取り込みを行わない
                invalidFlag = true;

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                this.outputAccessLog(_deviceId, "### Invalid time data. preTelecomDate=" + sdf.format(preTelecomDate)
                        + " [" + FW02_01_TelecomConst.ERRCODE.TER104 + "] ###");

            } else {
                // 通信禁止時間を過ぎていた場合は現在の通信日時を保持
                FW02_01_AbstractSocketBase.setTelecomDate(_deviceId, _commandCd, _telecomDate);
            }
        }
        return invalidFlag;
    }

    /**
    *
    * 前回終了判定処理.<br>
    *<br>
    * 概要:<br>
    *   同一機器の前回の通信が終了したかどうかを判定する。
    *<br>
    * @param _deviceId 機器ID
    * @return 判定結果(true:前回の通信が終了していない, false:前回の通信が終了している)
    */
    private boolean isInvalidStatus(final String _deviceId, final Long _commandCd) {

        boolean invalidFlag = false;
        String preStatus = FW02_01_AbstractSocketBase.getTelecomStatus(_deviceId, _commandCd);
        if (preStatus == null) {
            FW02_01_AbstractSocketBase.setTelecomStatus(_deviceId, _commandCd, CM_ReceiveInvalidDto.END);
        } else {

            if (CM_ReceiveInvalidDto.PROCESSING.equals(preStatus)) {
                // 前回の通信がまだ処理中の場合
                invalidFlag = true;
                this.outputAccessLog(_deviceId, "### Invalid status processing. [" + FW02_01_TelecomConst.ERRCODE.TER104 + "] ###");

            } else {
                // 前回の通信が終了している場合は"処理中"に変更
                FW02_01_AbstractSocketBase.setTelecomStatus(_deviceId, _commandCd, CM_ReceiveInvalidDto.PROCESSING);
            }
        }
        return invalidFlag;
    }

    /**
     *
     * 戻り電文送信処理.<br>
     *<br>
     * 概要:<br>
     *   戻り電文をクライアントへ送信する。
     *<br>
     * @param _send 送信文字列
     * @throws Exception 例外
     */
    private void sendData(final byte[] _send) throws Exception {
        if (_send != null) {
            switch (this.type) {
                case TCP:
                    //                    PrintStream ps = new PrintStream(this.tcpSocket.getOutputStream());
                    //                    ps.print(_send);
                    //                    ps.flush();
                    BufferedOutputStream bos = new BufferedOutputStream(this.tcpSocket.getOutputStream());
                    DataOutputStream dos = new DataOutputStream(bos);
                    dos.write(_send);
                    dos.flush();
                    break;
                case UDP:
                    //                    DatagramPacket sendPacket = new DatagramPacket(_send.getBytes(), _send.getBytes().length,
                    DatagramPacket sendPacket = new DatagramPacket(_send, _send.length,
                            this.udpPacket.getAddress(), this.udpPacket.getPort());
                    this.udpSocket.send(sendPacket);
                    break;
                default:
                    break;
            }
        }
    }

    /**
     *
     * ソケットクローズ処理待機処理.<br>
     *<br>
     * 概要:<br>
     *   ソケットクローズ処理の待機をする
     *<br>
     * @return 成否
     * @throws Exception 例外
     */
    private boolean waitClose() throws Exception {
        boolean result = false;

        switch (this.type) {
            case TCP:
                try {
                    this.tcpSocket.setSoTimeout(FW02_01_CommSocketMain.getSocketCloseTimeout() * FW00_19_Const.MILLI);
                    result = this.in.read() == -1;
                } catch (SocketTimeoutException e) {
                    result = false;
                } catch (SocketException e) {
                    // 既にクローズされている場合
                    result = true;
                }
                break;
            case UDP:
                result = true;
                break;
            default:
                result = false;
                break;
        }
        return result;
    }

    /**
     *
     * 受信ソケットクローズ内部関数.<br>
     *<br>
     * 概要:<br>
     *   ソケットをクローズします。
     *<br>
     * @throws Exception 例外
     */
    private void close() throws Exception {
        switch (this.type) {
            case TCP:
                if (this.tcpSocket != null && !this.tcpSocket.isClosed()) {
                    this.tcpSocket.close();
                }
                break;
            case UDP:
                if (this.udpSocket != null && this.udpSocket.isConnected() && !this.udpSocket.isClosed()) {
                    this.udpSocket.close();
                }
                break;
            default:
                break;
        }
    }

    /**
     *
     * エラー時応答電文編集処理(内部関数).<br>
     *<br>
     * 概要:<br>
     *   エラー時の応答電文を編集する
     *<br>
     * @param _resType 応答種別
     * @param _bean 通信情報
     * @return 送信文字列
     */
    private byte[] editErrorSendData(final RESPONSE_TYPE _resType, final FW02_01_CommunicationInfoBean _bean) {
        //        if (_resType.equals(RESPONSE_TYPE.FORCE_RETURN)
        //                || (_bean != null && (_bean.getComunicationType().equals(COMMUNICATION_TYPE.SEND.name())
        //                || _bean.getComunicationType().equals(COMMUNICATION_TYPE.SEND_NOWAIT.name())))) {
        //            StringBuffer send = new StringBuffer();
        //            if (!"".equals(_bean.getSendHeaderForError())) {
        //                send.append(_bean.getSendHeaderForError());
        //            } else {
        //                send.append(_bean.getComponentName());
        //            }
        //            if (!"".equals(this.endPoint)) {
        //                send.append((char) Integer.decode(this.endPoint).intValue());
        //            }
        //            return send.toString();
        //        } else {
        //            return null;
        //        }
        return null;
    }

    /**
     *
     * IPアドレス変換処理.<br>
     *<br>
     * 概要:<br>
     *   IPアドレスをドットなし0埋め文字列に変換する
     *<br>
     * @param _ipAddr IPアドレス
     * @return 変換後IPアドレス
     */
    private String convertIPAddress(final String _ipAddr) {
        String retStr = FW00_19_Const.EMPTY_STR;

        // ドットで分割する
        String[] ipAddrArray = _ipAddr.split(FW00_19_Const.ENDOT_STR);
        for (String splitAddr : ipAddrArray) {
            Integer addr = Integer.valueOf(splitAddr);
            retStr += String.format("%1$03d", addr.intValue());
        }

        return retStr;
    }

    /**
     *
     * バックアップファイル出力処理.<br>
     *<br>
     * 概要:<br>
     *   バックアップファイル出力処理
     *<br>
     * @param _companyId 顧客ID
     * @param _deviceId 機器ID
     * @param _commandCode コマンドコード
     * @param _telecomDate 通信日時
     * @param _data 出力データ
     */
    private void outputBackupFile(
            final String _companyId,
            final String _deviceId,
            final Long _commandCode,
            final Date _telecomDate,
            final FW02_01_DenbunInfoBean _data) {

        try {
            if ((_companyId == null) || (_deviceId == null) || (_commandCode == null)) {
                return;
            }

            // ファイル名作成
            String fileName =
                    _deviceId + "."
                            + String.format("%1$04X", _commandCode) + "."
                            + _companyId + "."
                            + new SimpleDateFormat(FW02_01_TelecomConst.DATE_FORMAT_FILE).format(_telecomDate);

            byte[] data = _data.getDataInfo();

            // ファイル出力先(ポート番号を挿入)
            String dirPath = this.pathFail + fileName;

            // ファイル出力
            FileOutputStream fos = new FileOutputStream(dirPath);
            fos.write(data);
            fos.close();

            // 権限を変更(ファイルを転送するため)
            File createFile = new File(dirPath);
            createFile.setReadable(true, false);
            createFile.setWritable(true, false);

        } catch (Exception e) {
            this.outputErrorLog(_deviceId, "BackupFile output error. header=" + _data.getHeaderByteArray() + ", data=" + _data.getDataInfo(), e);
        }
    }

    /**
     *
     * ログ出力メッセージ作成処理.<br>
     *<br>
     * 概要:<br>
     *   ログ出力をメッセージを作成する
     *<br>
     * @param _deviceId 機器ID
     * @param _strMsg メッセージ
     * @return ログ出力メッセージ
     */
    private StringBuffer createLogMsg(final String _deviceId, final String _strMsg) {
        StringBuffer sbMsg = new StringBuffer();

        // 顧客IDをセット
        sbMsg.append("CompanyId:");
        sbMsg.append(this.companyIdExec);

        // 機器IDをセット
        String deviceId = "undefined";
        if (_deviceId != null) {
            deviceId = _deviceId;
        }
        sbMsg.append(" DeviceId:");
        sbMsg.append(deviceId);

        // メッセージがあれば、メッセージをセット
        if (_strMsg != null && !"".equals(_strMsg)) {
            sbMsg.append(" Message:");
            sbMsg.append(_strMsg);
        }

        return sbMsg;
    }

    /**
     *
     * ログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   ログを出力する
     *<br>
     * @param _deviceId 機器ID
     * @param _strMsg メッセージ
     */
    private void outputAccessLog(final String _deviceId, final String _strMsg) {
        StringBuffer sbMsg = this.createLogMsg(_deviceId, _strMsg);
        FW00_23_LoggerUtil.accessLog.info(sbMsg.toString());
    }

    /**
     *
     * ログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   ログを出力する
     *<br>
     * @param _deviceId 機器ID
     * @param _strMsg メッセージ
     */
    private void outputDebugLog(final String _deviceId, final String _strMsg) {
        StringBuffer sbMsg = this.createLogMsg(_deviceId, _strMsg);
        FW00_23_LoggerUtil.debugLog.info(sbMsg.toString());
    }

    /**
     *
     * ログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   ログを出力する
     *<br>
     * @param _deviceId 機器ID
     * @param _strMsg メッセージ
     * @param _e 例外情報
     */
    private void outputErrorLog(final String _deviceId, final String _strMsg, final Exception _e) {
        StringBuffer sbMsg = this.createLogMsg(_deviceId, _strMsg);
        FW00_23_LoggerUtil.errorLog.error(sbMsg.toString(), _e);
    }

}
