/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/02/10| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.telecom.socket.bean;

/**
 *
 * ソケット通信電文フォーマット情報クラス.<br>
 *<br>
 * 概要:<br>
 *   ソケット通信の電文フォーマット情報クラス
 *<br>
 */
public class FW02_01_CommunicationInfoBean {

    /**
     *
     * 通信タイプ.<br>
     *<br>
     * 概要:<br>
     *   通信タイプの列挙帯
     *<br>
     */
    public static enum COMMUNICATION_TYPE {
        /**
         * 受信(待ちなし).
         */
        RECEIVE_NOWAIT,
        /**
         * 受信.
         */
        RECEIVE,
        /**
         * 送信(処理前にレスポンス送信).
         */
        SEND_BEFORE,
        /**
         * 送信(待ちなし).
         */
        SEND_NOWAIT,
        /**
         * 送信.
         */
        SEND
    }

    /**
     * 固有ヘッダ分割情報(任意).
     */
    private String ownHeaderInfo;

    /**
     * データタイプ(data:通常電文、file:ファイル含).
     */
    private String dataType;

    /**
     * 固定長電文データ部分割情報.
     */
    private String fixedDataInfo;

    /**
     * 可変長電文データ部分割バイト(16進数表記).
     */
    private String spliter;

    /**
     * 可変長電文データ部開始位置.
     */
    private int variableStart;

    /**
     * 受信ファイルバイナリデータ開始位置.
     */
    private int fileStart;

    /**
     * 受信ファイル格納先DIRパス(dataType=file時必須).
     */
    private String saveDirPath;

    /**
     * 業務ロジックコンポーネント名.
     */
    private String componentName;

    /**
     * 電文データ文字コード.
     */
    private String encording;

    /**
     * 通信タイプ(receive:受信、send:送受信).
     */
    private String comunicationType;

    /**
     * エラー時応答ヘッダ.
     */
    private String sendHeaderForError;

    /**
     * @param _ownHeaderInfo the ownHeaderInfo to set
     */
    public void setOwnHeaderInfo(final String _ownHeaderInfo) {
        this.ownHeaderInfo = _ownHeaderInfo;
    }

    /**
     * @return the ownHeaderInfo
     */
    public String getOwnHeaderInfo() {
        return this.ownHeaderInfo;
    }

    /**
     * @param _dataType the dataType to set
     */
    public void setDataType(final String _dataType) {
        this.dataType = _dataType;
    }

    /**
     * @return the dataType
     */
    public String getDataType() {
        return this.dataType;
    }

    /**
     * @return the fixedDataInfo
     */
    public String getFixedDataInfo() {
        return this.fixedDataInfo;
    }

    /**
     * @param _fixedDataInfo the fixedDataInfo to set
     */
    public void setFixedDataInfo(final String _fixedDataInfo) {
        this.fixedDataInfo = _fixedDataInfo;
    }

    /**
     * @return the spliter
     */
    public String getSpliter() {
        return this.spliter;
    }

    /**
     * @param _spliter the spliter to set
     */
    public void setSpliter(final String _spliter) {
        this.spliter = _spliter;
    }

    /**
     * @return the variableStart
     */
    public int getVariableStart() {
        return this.variableStart;
    }

    /**
     * @param _variableStart the variableStart to set
     */
    public void setVariableStart(final int _variableStart) {
        this.variableStart = _variableStart;
    }

    /**
     * @param _saveDirPath the saveDirPath to set
     */
    public void setSaveDirPath(final String _saveDirPath) {
        this.saveDirPath = _saveDirPath;
    }

    /**
     * @return the fileStart
     */
    public int getFileStart() {
        return this.fileStart;
    }

    /**
     * @param _fileStart the fileStart to set
     */
    public void setFileStart(final int _fileStart) {
        this.fileStart = _fileStart;
    }

    /**
     * @return the saveDirPath
     */
    public String getSaveDirPath() {
        return this.saveDirPath;
    }

    /**
     * @return the componentName
     */
    public String getComponentName() {
        return this.componentName;
    }

    /**
     * @param _componentName the componentName to set
     */
    public void setComponentName(final String _componentName) {
        this.componentName = _componentName;
    }

    /**
     * @return the comunicationType
     */
    public String getComunicationType() {
        return this.comunicationType;
    }

    /**
     * @param _comunicationType the comunicationType to set
     */
    public void setComunicationType(final String _comunicationType) {
        this.comunicationType = _comunicationType;
    }

    /**
     * @param _encording the encording to set
     */
    public void setEncording(final String _encording) {
        this.encording = _encording;
    }

    /**
     * @return the encording
     */
    public String getEncording() {
        return this.encording;
    }

    /**
     * @return the sendHeaderForError
     */
    public String getSendHeaderForError() {
        return this.sendHeaderForError;
    }

    /**
     * @param _sendHeaderForError the sendHeaderForError to set
     */
    public void setSendHeaderForError(final String _sendHeaderForError) {
        this.sendHeaderForError = _sendHeaderForError;
    }
}
