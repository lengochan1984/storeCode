/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/02/10| 新規作成                           | 1.00.00| YSK)植山
 *  2014/08/26| <10101-005> ログ追加               | 1.02.00| YSK)植山
 *  2014/09/02| <10101-011> リリース後不具合対応   | 1.02.00| YSK)大山
 *  2015/07/02| <30003-036> 変更仕様No.26          | 3.01.00| US)萩尾
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.telecom.socket;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.telecom.FW02_01_CommSocketMain;
import jp.ysk.fw.telecom.dto.CM_ReceiveInvalidDto;
import jp.ysk.fw.util.FW00_23_LoggerUtil;

/**
 *
 * ソケット通信受信スレッドクラス.<br>
 *<br>
 * 概要:<br>
 *   ソケット通信の受信スレッドクラス
 *<br>
 */
public abstract class FW02_01_AbstractSocketBase implements Runnable {

    /**
     * 受信ポート.
     */
    protected int port;

    /**
     * プロセスID.
     */
    public String processId;

    /**
     * 顧客ID.
     */
    protected String companyId;

    /**
     * 失敗ディレクトリパス(顧客別ディレクトリ内).
     */
    protected String pathFail;

    /**
     * 受信ファイル作成ディレクトリパス(顧客別ディレクトリ内).
     */
    protected String pathReceiveFile;

    /**
     * 待ち受けタイムアウト(ms).
     */
    protected int acceptTimeout;

    /**
     * 実行数上限到達時ウェイト時間.
     */
    protected int waitTime;

    /**
     * ソケット受信共通関数コンポーネント名.
     */
    protected String logicClassName;

    /**
     * 通信日時管理Map.
     */
    private static Map<String, CM_ReceiveInvalidDto> telecomInvalidMap = new HashMap<String, CM_ReceiveInvalidDto>();

    /**
     * リトライ数.
     */
    private static final int RETRY_NUM = 5;

    /**
     * 受信スレッド処理.
     */
    public void run() {
        try {
            // 初期化処理を呼出
            this.init();
            this.outputAccessLog("Socketを初期化しました。ポート番号:" + this.port);

            while (true) {
                this.accept();

                if (this.judgeEnd()) {
                    this.outputAccessLog("終了通知を検知しました。監視を終了します。ポート番号:" + this.port);
                    break;
                }
            }

        } catch (Exception e) {
            this.outputErrorLog("Exception !!", e);
        } finally {
            this.outputAccessLog("Socketをクローズします。ポート番号:" + this.port);
        }
    }

    /**
     *
     * データ連携処理スレッド起動.<br>
     *<br>
     * 概要:<br>
     *   データ連携処理(FW02_01_ChildSocket)をスレッド起動する。<br>
     *   スレッドプールが上限に達している場合は、一定時間待機した後、リトライする。
     *<br>
     * @param _socket ソケット
     * @throws InterruptedException 例外
     */
    protected void runChild(final FW02_01_ChildSocket _socket) throws InterruptedException {
        this.runChild(_socket, 1);
    }

    /**
     *
     * データ連携処理スレッド起動(内部メソッド：再帰処理).<br>
     *<br>
     * 概要:<br>
     *   データ連携処理(FW02_01_ChildSocket)をスレッド起動する。<br>
     *   スレッドプールが上限に達している場合は、一定時間待機した後、リトライする。
     *<br>
     * @param _socket ソケット
     * @param _retryTimes リトライ時間
     * @throws InterruptedException 例外
     */
    private void runChild(final FW02_01_ChildSocket _socket, final long _retryTimes) throws InterruptedException {
        if (!FW02_01_CommSocketMain.runThread(_socket)) {
            if (_retryTimes != 0 && _retryTimes % RETRY_NUM == 0) {
                this.outputAccessLog("Trying " + _retryTimes + " times now. Process was failed.[IP:" + _socket.getSocketIP() + "]");
            }
            // 指定ミリ秒待機
            Thread.sleep(this.waitTime);
            // リトライ回数のカウントアップ
            this.runChild(_socket, _retryTimes + 1);
        }
    }

    /**
     *
     * 顧客IDセッター.<br>
     *<br>
     * 概要:<br>
     *   顧客IDを設定
     *<br>
     * @param _companyId 顧客ID
     */
    public void setCompanyId(final String _companyId) {
        this.companyId = _companyId;
    }

    /**
     * 失敗ディレクトリパス(顧客別ディレクトリ内)セッター.<br>
     *<br>
     * 概要:<br>
     * 　失敗ディレクトリパスを設定する
     * @param _pathFail 失敗ディレクトリパス
     */
    public void setPathFail(final String _pathFail) {
        this.pathFail = _pathFail;
    }

    /**
     * 受信ファイル作成ディレクトリパス(顧客別ディレクトリ内)セッター.<br>
     *<br>
     * 概要:<br>
     * 　受信ファイル作成ディレクトリパスを設定する
     * @param _pathReceiveFile 受信ファイル作成ディレクトリパス
     */
    public void setPathReceiveFile(final String _pathReceiveFile) {
        this.pathReceiveFile = _pathReceiveFile;
    }

    /**
     *
     * 受信ポートセッター(DIコンテナにて使用する為、定義).<br>
     *<br>
     * 概要:<br>
     *   受信ポートのポート番号を設定
     *<br>
     * @param _port ポート番号
     */
    public void setPort(final int _port) {
        this.port = _port;
    }

    /**
     *
     * 待ち受けタイムアウトセッター(DIコンテナにて使用する為、定義).<br>
     *<br>
     * 概要:<br>
     *   タイムアウト時間を設定
     *<br>
     * @param _acceptTimeout タイムアウト時間
     */
    public void setAcceptTimeout(final int _acceptTimeout) {
        this.acceptTimeout = _acceptTimeout;
    }

    /**
     *
     * ソケット受信共通関数コンポーネント名セッター(DIコンテナにて使用する為、定義).<br>
     *<br>
     * 概要:<br>
     *   業務ロジッククラス名の設定
     *<br>
     * @param _logicClassName 業務ロジッククラス名
     */
    public void setLogicClassName(final String _logicClassName) {
        this.logicClassName = _logicClassName;
    }

    /**
     *
     * 実行数上限到達時ウェイト時間セッター(DIコンテナにて使用する為、定義).<br>
     *<br>
     * 概要:<br>
     *   ウェイト時間を設定
     *<br>
     * @param _waitTime ウェイト時間
     */
    public void setWaitTime(final int _waitTime) {
        this.waitTime = _waitTime;
    }

    /**
     *
     * プロセスIDセッター.<br>
     *<br>
     * 概要:<br>
     *   プロセスIDを設定
     *<br>
     * @param _processId プロセスID
     */
    public void setProcessId(final String _processId) {
        this.processId = _processId;
    }

    /**
     *
     * 通信日時セッター.<br>
     *<br>
     * 概要:<br>
     *   機器・コマンドごとの通信日時を設定する
     *<br>
     * @param _deviceId 機器ID
     * @param _commandCd コマンドコード
     * @param _telecomDate 通信日時
     */
    public static synchronized void setTelecomDate(final String _deviceId, final Long _commandCd, final Date _telecomDate) {
        CM_ReceiveInvalidDto invalidDto = telecomInvalidMap.get(createTelecomInvalidMapKey(_deviceId, _commandCd));
        if (null == invalidDto) {
            invalidDto = new CM_ReceiveInvalidDto();
        }
        invalidDto.telecomDate = _telecomDate;

        telecomInvalidMap.put(createTelecomInvalidMapKey(_deviceId, _commandCd), invalidDto);
    }

    /**
     *
     * 通信日時ゲッター.<br>
     *<br>
     * 概要:<br>
     *   機器・コマンドごとの通信日時を取得する
     *<br>
     * @param _deviceId 機器ID
     * @param _commandCd コマンドコード
     * @return 通信日時
     */
    public static synchronized Date getTelecomDate(final String _deviceId, final Long _commandCd) {
        Date retVal = null;
        CM_ReceiveInvalidDto invalidDto = telecomInvalidMap.get(createTelecomInvalidMapKey(_deviceId, _commandCd));
        if (null != invalidDto) {
            retVal = invalidDto.telecomDate;
        }
        return retVal;
    }

    /**
    *
    * ステータスセッター.<br>
    *<br>
    * 概要:<br>
    *   機器・コマンドごとのステータスを設定する
    *<br>
    * @param _deviceId 機器ID
    * @param _commandCd コマンドコード
    * @param _status ステータス
    */
    public static synchronized void setTelecomStatus(final String _deviceId, final Long _commandCd, final String _status) {
        CM_ReceiveInvalidDto invalidDto = telecomInvalidMap.get(createTelecomInvalidMapKey(_deviceId, _commandCd));
        if (null == invalidDto) {
            invalidDto = new CM_ReceiveInvalidDto();
        }
        invalidDto.status = _status;

        telecomInvalidMap.put(createTelecomInvalidMapKey(_deviceId, _commandCd), invalidDto);
    }

   /**
    *
    * ステータスゲッター.<br>
    *<br>
    * 概要:<br>
    *   機器・コマンドごとのステータスを取得する
    *<br>
    * @param _deviceId 機器ID
    * @param _commandCd コマンドコード
    * @return ステータス
    */
    public static synchronized String getTelecomStatus(final String _deviceId, final Long _commandCd) {
        String retVal = null;
        CM_ReceiveInvalidDto invalidDto = telecomInvalidMap.get(createTelecomInvalidMapKey(_deviceId, _commandCd));
        if (null != invalidDto) {
            retVal = invalidDto.status;
        }
        return retVal;
    }

    /**
     *
     * スレッド終了判定処理.<br>
     *<br>
     * 概要:<br>
     *   スレッドを終了するか判定する
     *<br>
     * @return 成否
     */
    private boolean judgeEnd() {

        // 全スレッド終了ファイルがあった場合は即終了(例:/home/telecom/tcp/stopAll.txt)
        File endFile = new File(FW02_01_CommSocketMain.getFullPathStopAll());
        if (endFile.exists()) {
            return true;
        }

        // ポート指定終了ファイルがあった場合は終了(例:/home/telecom/tcp/10000/stop.txt)
        endFile = new File(FW02_01_CommSocketMain.getFullPathStopPort(this.port));
        if (endFile.exists()) {
            return true;
        }

        return false;
    }

    /**
     * 初期化処理.
     *
     * @throws IOException 例外
     */
    protected abstract void init() throws IOException;

    /**
     * 待ち受け処理.
     *
     * @throws Exception 例外
     */
    protected abstract void accept() throws Exception;

    /**
     *
     * ログ出力メッセージ作成処理.<br>
     *<br>
     * 概要:<br>
     *   ログ出力をメッセージを作成する
     *<br>
     * @param _strMsg メッセージ
     * @return ログ出力メッセージ
     */
    protected StringBuffer createLogMsg(final String _strMsg) {
        StringBuffer sbMsg = new StringBuffer();

        // 顧客IDをセット
        sbMsg.append("CompanyId:");
        sbMsg.append(this.companyId);

        // 機器IDをセット
        String deviceId = "undefined";
        sbMsg.append(" DeviceId:");
        sbMsg.append(deviceId);

        // メッセージがあれば、メッセージをセット
        if (_strMsg != null && !"".equals(_strMsg)) {
            sbMsg.append(" Message:");
            sbMsg.append(_strMsg);
        }

        return sbMsg;
    }

    /**
     *
     * ログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   ログを出力する
     *<br>
     * @param _strMsg メッセージ
     */
    protected void outputAccessLog(final String _strMsg) {
        StringBuffer sbMsg = this.createLogMsg(_strMsg);
        FW00_23_LoggerUtil.accessLog.info(sbMsg.toString());
    }

    /**
     *
     * ログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   ログを出力する
     *<br>
     * @param _strMsg メッセージ
     * @param _e 例外情報
     */
    protected void outputErrorLog(final String _strMsg, final Exception _e) {
        StringBuffer sbMsg = this.createLogMsg(_strMsg);
        FW00_23_LoggerUtil.errorLog.error(sbMsg.toString(), _e);
    }

    /**
     *
     * 通信日時管理Map用キーを生成.<br>
     *<br>
     * 概要:<br>
     *   機器IDとコマンドコードから通信日時管理Mapキーを生成
     *<br>
     * @param _deviceId 機器ID
     * @param _commandCd コマンドコード
     * @return 通信日時管理Map用キー
     */
    private static String createTelecomInvalidMapKey(final String _deviceId, final Long _commandCd) {
        return _deviceId + FW00_19_Const.UNDER_BAR_STR + _commandCd;
    }

}
