/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/02/10| 新規作成                           | 1.00.00| YSK)植山
 *  2014/08/26| <10101-005> ログ追加               | 1.02.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.telecom;

import java.io.File;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import jp.ysk.fw.FW00_19_Const;
import jp.ysk.fw.telecom.socket.FW02_01_AbstractSocketBase;
import jp.ysk.fw.telecom.socket.FW02_01_ChildSocket;
import jp.ysk.fw.util.FW00_23_LoggerUtil;

import org.apache.log4j.PropertyConfigurator;
import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.S2ContainerFactory;

/**
 *
 * ソケット通信共通制御クラス.<br>
 *<br>
 * 概要:<br>
 *   ソケット通信の共通制御クラス
 *<br>
 */
public class FW02_01_CommSocketMain {

    /**
     * TCP/MMLP種別(tcp/mmlp).
     */
    public static final String TCP_MMLP_KIND = "tcp";
//    public static final String TCP_MMLP_KIND = "mmlp";

    /**
     * ホームディレクトリパス.
     */
    public static final String PATH_HOME_DIR = "/home/telecom/";

    /**
     * 通信プロセスホームディレクトリパス.
     */
    protected String pathHome;

    /**
     * プロトコル通信プロセスホームディレクトリパス.
     */
    protected String pathProtocolHome;

    /**
     * 失敗ディレクトリパス(顧客別ディレクトリ内).
     */
    protected String pathFail;

    /**
     * 受信ファイル作成ディレクトリパス(顧客別ディレクトリ内).
     */
    protected String pathReceiveFile;

    /**
     * 全停止ファイル名.
     */
    public static final String FILE_ALL_STOP = "stopAll.txt";

    /**
     * ポート別停止ファイル名.
     */
    public static final String FILE_STOP = "stop.txt";

    /**
     * コンテナ.
     */
    private static S2Container container = null;

    /**
     * データ連携スレッド起動上限値.
     */
    private int intMaxActiveThreadCnt;

    /**
     * ソケットクローズタイムアウト時間(s).
     */
    private int intSocketCloseTimeout;

    /**
     * 終了制御ファイルパス.
     */
    private String pathEndFile;

    /**
     * データ連携スレッド起動数管理クラス.
     */
    private ThreadPoolExecutor threadPoolExecutor;

    /**
     * 自身のプライベートインスタンス.
     */
    private static FW02_01_CommSocketMain inst;

    /**
     * 引数インデックス：顧客ID.
     */
    private static final int ARG_INDEX_COMPANY_ID = 0;
    /**
     * 引数インデックス：ポート番号.
     */
    private static final int ARG_INDEX_PORT_NUM = 1;

    /**
     * 顧客ID(第一引数).
     */
    private static String companyId = "";
    /**
     * ポート番号(第二引数).
     */
    private static String portNum = "";

    /**
     * 起動するソケットタイプのキー[TCP,UDP,SSL]：TCP.
     */
    private static final String SOCKET_TYPE_TCP = "TCP";

    /**
     *
     * メイン関数.<br>
     *<br>
     * 概要:<br>
     *   メインスレッドの処理
     *<br>
     * @param _args 顧客ID, ポート番号
     */
    public static void main(final String[] _args) {

        final int argsNum = 2;

        try {
            // ログ設定読込
            PropertyConfigurator.configure(FW02_01_CommSocketMain.class.getResource("/log4j.telecom.properties"));
            outputAccessLog("--------------------------------");
            for (int i = 0; i < _args.length; i++) {
                outputAccessLog("_args[" + i + "] = " + _args[i]);
            }
            outputAccessLog("--------------------------------");
            if (_args.length != argsNum) {
                outputAccessLog("set this parameter [ companyId portNum ]");
                outputAccessLog("  example [ company01 10000 ]");

                outputAccessLog("--------------------------------");
                outputAccessLog("+++ main thread end   ++++++++++");
                outputAccessLog("--------------------------------");

                System.exit(1);
            }

            companyId = _args[ARG_INDEX_COMPANY_ID];
            portNum = _args[ARG_INDEX_PORT_NUM];

            // すでに実行済みの場合は実行しない
            File endfile = new File(FW02_01_CommSocketMain.getFullPathLock(Integer.parseInt(portNum)));
            if (endfile.exists()) {
                outputAccessLog("--------------------------------");
                outputAccessLog(" already execute(lock file exist)");
                outputAccessLog("--------------------------------");
                outputAccessLog("+++ main thread end   ++++++++++");
                outputAccessLog("--------------------------------");

                System.exit(1);

            } else {
                // すでに実行しているものがない場合はロックファイルを作成
                endfile.createNewFile();
            }

            outputAccessLog("--------------------------------");
            outputAccessLog("+++ main thread start ++++++++++");
            outputAccessLog("--------------------------------");

            // コンテナー初期化
            container = S2ContainerFactory.create("app_telecom.dicon");
            container.init();

            // ソケット通信の共通制御クラスをDIコンテナより取得する。
            inst = (FW02_01_CommSocketMain) container.getComponent("main");

            // スレッド起動数管理クラスを初期化する。
            inst.threadPoolExecutor = new ThreadPoolExecutor(
                    //プール内に保持するスレッドの数
                    inst.intMaxActiveThreadCnt,
                    //プールで許可されるスレッドの最大数
                    inst.intMaxActiveThreadCnt,
                    0L, TimeUnit.MILLISECONDS,
                    new LinkedBlockingQueue<Runnable>());

            // 受信スレッド起動処理を実行する。
            inst.start();

            outputAccessLog("--------------------------------");
            outputAccessLog("+++ main thread end   ++++++++++");
            outputAccessLog("--------------------------------");

            System.exit(0);
        } catch (Exception e) {
            outputErrorLog("System error!", e);
            outputAccessLog("--------------------------------");
            outputAccessLog("+++ main thread end   ++++++++++");
            outputAccessLog("--------------------------------");

            System.exit(1);
        }

    }

    /**
     *
     * 受信スレッド起動処理.<br>
     *<br>
     * 概要:<br>
     *   受信スレッドを起動する
     *<br>
     * @throws Exception 例外
     */
    private void start() throws Exception {
        // 受信スレッドのグループを生成
        ThreadGroup tGroup = new ThreadGroup(SOCKET_TYPE_TCP + portNum);

        // 作成したグループで受信スレッドを１つ起動する
        FW02_01_AbstractSocketBase child = (FW02_01_AbstractSocketBase) container.getComponent(SOCKET_TYPE_TCP);
        // 引数からポート番号を指定
        child.setPort(Integer.parseInt(portNum));
        // 引数から顧客IDを指定
        child.setCompanyId(companyId);
        // プロセスIDを設定(機能ID＋ポート番号)
        child.setProcessId(FW02_01_TelecomConst.FUNCTION_ID_TCP + FW00_19_Const.HYPHEN_STR + portNum);
        child.setPathFail(getPathProtocolHome() + portNum + getPathFail());
        child.setPathReceiveFile(getPathProtocolHome() + portNum + getPathReceiveFile());
        Thread thread = new Thread(tGroup, child);
        thread.start();

        // 受信スレッドと、データ連携スレッドが未起動時以外は待機する。
        while (!(tGroup.activeCount() == 0 && this.threadPoolExecutor.getActiveCount() == 0)) {
            outputAccessLog("sleep 60 seconds in main");
            Thread.sleep(FW00_19_Const.SECOND * FW00_19_Const.MILLI);
        }

        // エンドファイルが存在する場合、削除する。
        File endfile = new File(FW02_01_CommSocketMain.getFullPathStopPort(Integer.parseInt(portNum)));
        if (endfile.exists()) {
            endfile.delete();
        }

        // ロックファイルを削除する
        File lockFile = new File(FW02_01_CommSocketMain.getFullPathLock(Integer.parseInt(portNum)));
        if (lockFile.exists()) {
            lockFile.delete();
        }
    }

    /**
     *
     * データ連携スレッド起動共通部品.<br>
     *<br>
     * 概要:<br>
     *   スレッドを起動する
     *<br>
     * @param _socket ソケット
     * @return 成否
     */
    public static boolean runThread(final FW02_01_ChildSocket _socket) {
        synchronized (inst.threadPoolExecutor) {

            outputAccessLog("runThread ThreadCount:" + inst.threadPoolExecutor.getActiveCount());

            if (inst.threadPoolExecutor.getActiveCount() >= inst.intMaxActiveThreadCnt) {
                return false;
            } else {
                inst.threadPoolExecutor.execute(_socket);
                return true;
            }
        }
    }

    /**
     *
     * DIコンテナ起動共通部品.<br>
     *<br>
     * 概要:<br>
     *   DIコンテナからオブジェクトを取得する
     *<br>
     * @param _key キー
     * @return オブジェクト
     */
    public static Object callContainer(final String _key) {
        synchronized (container) {
            return container.getComponent(_key);
        }
    }

    /**
     *
     * スレッド数上限値セッター(DIコンテナにて使用する為、定義).<br>
     *<br>
     * 概要:<br>
     *   スレッド数上限値を設定する
     *<br>
     * @param _intMaxActiveThreadCnt スレッド数上限値
     */
    public void setIntMaxActiveThreadCnt(final int _intMaxActiveThreadCnt) {
        this.intMaxActiveThreadCnt = _intMaxActiveThreadCnt;
    }

    /**
     *
     * エンドファイルパスセッター(DIコンテナにて使用する為、定義).<br>
     *<br>
     * 概要:<br>
     *   エンドファイルパスを設定する
     *<br>
     * @param _pathEndFile エンドファイルパス
     */
    public void setPathEndFile(final String _pathEndFile) {
        this.pathEndFile = _pathEndFile;
    }

    /**
     *
     * エンドファイルパスゲッター.<br>
     *<br>
     * 概要:<br>
     *   エンドファイルパスを取得する
     *<br>
     * @return エンドファイルパス
     */
    public static String getPathEndFile() {
        return inst.pathEndFile;
    }

    /**
     *
     * ソケットクローズ処理タイムアウト時間セッター.<br>
     *<br>
     * 概要:<br>
     *   ソケットクローズ処理のタイムアウト時間を設定する
     *<br>
     * @param _intSocketCloseTimeout ソケットクローズ処理タイムアウト時間
     */
    public void setIntSocketCloseTimeout(final int _intSocketCloseTimeout) {
        this.intSocketCloseTimeout = _intSocketCloseTimeout;
    }

    /**
     *
     * ソケットクローズ処理タイムアウト時間取得.<br>
     *<br>
     * 概要:<br>
     *   ソケットクローズ処理のタイムアウト時間を取得する
     *<br>
     * @return ソケットクローズ処理タイムアウト時間
     */
    public static int getSocketCloseTimeout() {
        return inst.intSocketCloseTimeout;
    }

    /**
     *
     * 全停止ファイルフルパス取得.<br>
     *<br>
     * 概要:<br>
     *   全停止ファイルのフルパスを取得する
     *<br>
     * @return 全停止フルパス
     */
    public static String getFullPathStopAll() {

        // 例:/home/telecom/tcp/stopAll.txt
        String fullPath = PATH_HOME_DIR + TCP_MMLP_KIND + "/" + FILE_ALL_STOP;

        return fullPath;
    }

    /**
     *
     * 個別停止ファイルフルパス取得.<br>
     *<br>
     * 概要:<br>
     *   個別停止ファイルのフルパスを取得する
     *<br>
     * @param _portNum ポート番号
     * @return 個別停止フルパス
     */
    public static String getFullPathStopPort(final int _portNum) {

        // 例:/home/telecom/tcp/10000/stop.txt
        String fullPath = PATH_HOME_DIR + TCP_MMLP_KIND + "/" + _portNum + "/" + FILE_STOP;

        return fullPath;
    }

    /**
     *
     * 実行ロックファイルフルパス取得.<br>
     *<br>
     * 概要:<br>
     *   実行ロックファイルのフルパスを取得する
     *<br>
     * @param _portNum ポート番号
     * @return 実行ロックファイルフルパス
     */
    public static String getFullPathLock(final int _portNum) {

        // 例:/var/lock/mmcloud/telecom/tcp-10000-lock.txt
        String fullPath = FW02_01_TelecomConst.PATH_LOCK + TCP_MMLP_KIND + "-" + _portNum + FW02_01_TelecomConst.FILE_LOCK_TAIL;

        return fullPath;
    }

    /**
     *
     * ログ出力メッセージ作成処理.<br>
     *<br>
     * 概要:<br>
     *   ログ出力をメッセージを作成する
     *<br>
     * @param _strMsg メッセージ
     * @return ログ出力メッセージ
     */
    private static StringBuffer createLogMsg(final String _strMsg) {
        StringBuffer sbMsg = new StringBuffer();

        // 顧客IDをセット
        sbMsg.append("CompanyId:");
        sbMsg.append(companyId);

        // 機器IDをセット
        String deviceId = "main";
        sbMsg.append(" DeviceId:");
        sbMsg.append(deviceId);

        // メッセージがあれば、メッセージをセット
        if (_strMsg != null && !"".equals(_strMsg)) {
            sbMsg.append(" Message:");
            sbMsg.append(_strMsg);
        }

        return sbMsg;
    }

    /**
     *
     * ログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   ログを出力する
     *<br>
     * @param _strMsg メッセージ
     */
    private static void outputAccessLog(final String _strMsg) {
        StringBuffer sbMsg = createLogMsg(_strMsg);
        FW00_23_LoggerUtil.accessLog.info(sbMsg.toString());
    }

    /**
     *
     * ログ出力処理.<br>
     *<br>
     * 概要:<br>
     *   ログを出力する
     *<br>
     * @param _strMsg メッセージ
     * @param _e 例外情報
     */
    private static void outputErrorLog(final String _strMsg, final Exception _e) {
        StringBuffer sbMsg = createLogMsg(_strMsg);
        FW00_23_LoggerUtil.errorLog.error(sbMsg.toString(), _e);
    }

    /**
     * @return pathHome
     */
    public String getPathHome() {
        return pathHome;
    }

    /**
     * @param _pathHome セットする _pathHome
     */
    public void setPathHome(final String _pathHome) {
        this.pathHome = _pathHome;
    }

    /**
     *
     * @return pathProtocolHome
     */
    public String getPathProtocolHome() {
        return this.pathProtocolHome;
    }

    /**
     * @param _pathProtocolHome セットする _pathProtocolHome
     */
    public void setPathProtocolHome(final String _pathProtocolHome) {
        this.pathProtocolHome = _pathProtocolHome;
    }

    /**
     * @return pathFail
     */
    public String getPathFail() {
        return this.pathFail;
    }

    /**
     * @param _pathFail セットする _pathFail
     */
    public void setPathFail(final String _pathFail) {
        this.pathFail = _pathFail;
    }

    /**
     * @return pathReceiveFile
     */
    public String getPathReceiveFile() {
        return this.pathReceiveFile;
    }

    /**
     * @param _pathReceiveFile セットする _pathReceiveFile
     */
    public void setPathReceiveFile(final String _pathReceiveFile) {
        this.pathReceiveFile = _pathReceiveFile;
    }
}
