/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/02/10| 新規作成                           | 1.00.00| YSK)植山
 *  2014/08/26| <10101-005> ログ追加               | 1.02.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.telecom.socket.impl;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

import jp.ysk.fw.telecom.FW02_01_CommSocketMain;
import jp.ysk.fw.telecom.socket.FW02_01_AbstractSocketBase;
import jp.ysk.fw.telecom.socket.FW02_01_ChildSocket;

/**
 *
 * ソケット受信(TCP用)クラス.<br>
 *<br>
 * 概要:<br>
 *   TCP用のソケット受信クラス
 *<br>
 */
public class FW02_01_ReceiveSocketTCP extends FW02_01_AbstractSocketBase {

    /**
     * 受信ソケット.
     */
    private ServerSocket socket;

    /**
     * 初期化処理.
     *
     * @throws IOException 例外
     */
    @Override
    protected void init() throws IOException {
        this.socket = new ServerSocket(super.port);
        this.socket.setSoTimeout(super.acceptTimeout);
    }

    /**
     * 受信待機処理.
     */
    @Override
    protected void accept() {
        try {
            Socket conSocket = this.socket.accept();
            conSocket.setSoTimeout(super.acceptTimeout);
            //アプリ共通のサブスレッドを取得する。
            FW02_01_ChildSocket childThread =
                    (FW02_01_ChildSocket) FW02_01_CommSocketMain.callContainer(super.logicClassName);
            childThread.setSocket(conSocket);
            childThread.setProcessID(this.processId);
            childThread.setPortNum(this.port);
            childThread.setCompanyID(this.companyId);
            childThread.setPathFail(this.pathFail);
            childThread.setPathReceiveFile(this.pathReceiveFile);

            super.runChild(childThread);

        } catch (SocketTimeoutException timeout) {

        } catch (Exception e) {
            this.outputErrorLog("Exception !!", e);
        }
    }
}
