/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/02/10| 新規作成                           | 1.00.00| YSK)植山
 *  2016/05/31| <40000-042> 機能改造 コマンド実行  | 4.01.00| YSK)三村
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.telecom.socket.bean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * ソケット通信電文情報クラス.<br>
 *<br>
 * 概要:<br>
 *   ソケット通信の電文情報クラス
 *<br>
 */
public class FW02_01_DenbunInfoBean {

    /**
     * ヘッダ情報(文字列).
     */
    private Map<String, String> headerInfoStr;

    /**
     * ヘッダ情報(数値).
     */
    private Map<String, Long> headerInfo;

    /**
     * ヘッダ部バイト配列.
     */
    private byte[] headerByteArray;

    /**
     * データ情報(固定長).
     */
    private Map<String, String> fixedDataInfo;

    /**
     * データ情報(固定長).
     */
    private Map<String, List<String>> fixedDataListInfo;

    /**
     * データ情報(可変長).
     */
    private List<String> variableDataInfo;

    /**
     * データ部(データ部設定情報無し時).
     */
    private byte[] dataInfo;

    /**
     * データ情報(データ部設定情報無し時).
     */
    private byte[] originalDataInfo;

    /**
     * データ情報(受信電文).
     */
    private String receiveData;

    /**
     * IPアドレス.
     */
    private String ipAddress;

    /**
     * コンストラクタ.
     */
    public FW02_01_DenbunInfoBean() {
        this.headerInfoStr = new HashMap<String, String>();
        this.headerInfo = new HashMap<String, Long>();
        this.fixedDataInfo = new HashMap<String, String>();
        this.fixedDataListInfo = new HashMap<String, List<String>>();
    }

    /**
     *
     * ヘッダ情報(文字列)設定.<br>
     *<br>
     * 概要:<br>
     *   ヘッダ項目データを設定する
     *<br>
     * @param _key キー
     * @param _value 値
     */
    public void putHeaderInfoStr(final String _key, final String _value) {
        this.headerInfoStr.put(_key, _value);
    }

    /**
     *
     * ヘッダ情報(文字列)取得.<br>
     *<br>
     * 概要:<br>
     *   ヘッダ情報を取得する。
     *<br>
     * @return ヘッダ情報
     */
    public Map<String, String> getHeaderInfoStr() {
        return this.headerInfoStr;
    }

    /**
     *
     * ヘッダ情報設定.<br>
     *<br>
     * 概要:<br>
     *   ヘッダ項目データを設定する
     *<br>
     * @param _key キー
     * @param _value 値
     */
    public void putHeaderInfo(final String _key, final Long _value) {
        this.headerInfo.put(_key, _value);
    }

    /**
     *
     * ヘッダ情報取得.<br>
     *<br>
     * 概要:<br>
     *   ヘッダ情報を取得する。
     *<br>
     * @return ヘッダ情報
     */
    public Map<String, Long> getHeaderInfo() {
        return this.headerInfo;
    }

    /**
     *
     * 固定長データ設定.<br>
     *<br>
     * 概要:<br>
     *   項目キーに該当する単データ格納する
     *<br>
     * @param _key キー
     * @param _value 値
     */
    public void putFixedDataInfo(final String _key, final String _value) {

        this.fixedDataInfo.put(_key, _value);
    }

    /**
     *
     * 固定長データ設定.<br>
     *<br>
     * 概要:<br>
     *   項目キーに該当する一覧データを格納する
     *<br>
     * @param _key キー
     * @param _value 値
     */
    public void putFixedDataInfo(final String _key, final List<String> _value) {

        this.fixedDataListInfo.put(_key, _value);
    }

    /**
     *
     * 単項目データ取得.<br>
     *<br>
     * 概要:<br>
     *   項目キーに該当する単データを取得する。
     *<br>
     * @param _key キー
     * @return 値
     */
    public String getFixedDataItem(final String _key) {
        return this.fixedDataInfo.get(_key);
    }

    /**
     *
     * 単項目データMap取得.<br>
     *<br>
     * 概要:<br>
     *   単データMapを取得する。
     *<br>
     * @return 単項目データMap
     */
    public Map<String, String> getFixedDataItemMap() {
        return this.fixedDataInfo;
    }

    /**
     *
     * 一覧項目データ取得.<br>
     *<br>
     * 概要:<br>
     *   項目キーに該当する一覧データを取得する。
     *<br>
     * @param _key 項目キー
     * @return 一覧項目データ
     */
    public List<String> getFixedDataListItem(final String _key) {
        return this.fixedDataListInfo.get(_key);

    }

    /**
     *
     * 一覧項目データMap取得.<br>
     *<br>
     * 概要:<br>
     *   一覧データMapを取得する。
     *<br>
     * @return 一覧項目データMap
     */
    public Map<String, List<String>> getFixedDataListItemMap() {
        return this.fixedDataListInfo;

    }

    /**
     *
     * 可変長データ取得.<br>
     *<br>
     * 概要:<br>
     *   可変長データ一覧を取得する
     *<br>
     * @return 可変長データ
     */
    public List<String> getVariableDataInfo() {
        return this.variableDataInfo;
    }

    /**
     *
     * 可変長データ設定.<br>
     *<br>
     * 概要:<br>
     *   可変長データ一覧を設定する
     *<br>
     * @param _variableDataInfo 可変長データ
     */
    public void setVariableDataInfo(final List<String> _variableDataInfo) {
        this.variableDataInfo = _variableDataInfo;
    }

    /**
     *
     * 電文設定.<br>
     *<br>
     * 概要:<br>
     *   受信したバイト配列を取得する。
     *<br>
     * @return 受信バイト配列
     */
    public byte[] getOriginalDataInfo() {
        return this.originalDataInfo;
    }

    /**
     *
     * 電文取得.<br>
     *<br>
     * 概要:<br>
     *   受信したバイト配列を設定する
     *<br>
     * @param _originalDataInfo 受信バイト配列
     */
    public void setOriginalDataInfo(final byte[] _originalDataInfo) {
        this.originalDataInfo = _originalDataInfo;
    }

    /**
     *
     * 電文データ部設定.<br>
     *<br>
     * 概要:<br>
     *   受信したバイト配列のデータ部を取得する。
     *<br>
     * @return 受信バイト配列
     */
    public byte[] getDataInfo() {
        return this.dataInfo;
    }

    /**
     *
     * 電文データ部取得.<br>
     *<br>
     * 概要:<br>
     *   受信したバイト配列のデータ部を設定する
     *<br>
     * @param _dataInfo 受信データ部バイト配列
     */
    public void setDataInfo(final byte[] _dataInfo) {
        this.dataInfo = _dataInfo;
    }

    /**
     *
     * 電文設定.<br>
     *<br>
     * 概要:<br>
     *   ファイルデータを除く受信電文を取得する。
     *<br>
     * @return 受信電文
     */
    public String getReceiveData() {
        return this.receiveData;
    }

    /**
     *
     * 電文取得.<br>
     *<br>
     * 概要:<br>
     *   ファイルデータを除く受信電文を設定する
     *<br>
     * @param _receiveData 受信電文
     */
    public void setReceiveData(final String _receiveData) {
        this.receiveData = _receiveData;
    }

    /**
    *
    * IPアドレス取得.<br>
    *<br>
    * 概要:<br>
    *   IPアドレスを取得する。
    *<br>
    * @return IPアドレス
    */
   public String getIpAddress() {
       return this.ipAddress;
   }

   /**
    *
    * IPアドレス設定.<br>
    *<br>
    * 概要:<br>
    *   IPアドレスを設定する
    *<br>
    * @param _ipAddress IPアドレス
    */
   public void setIpAddress(final String _ipAddress) {
       this.ipAddress = _ipAddress;
   }

    /**
     *
     * ヘッダ部バイト配列設定.<br>
     *<br>
     * 概要:<br>
     *   受信したヘッダ部のバイト配列を取得する。
     *<br>
     * @return ヘッダ部バイト配列
     */
    public byte[] getHeaderByteArray() {
        return this.headerByteArray;
    }

    /**
     *
     * ヘッダ部バイト配列取得.<br>
     *<br>
     * 概要:<br>
     *   受信したヘッダ部のバイト配列を設定する
     *<br>
     * @param _headerByteArray ヘッダ部バイト配列
     */
    public void setHeaderByteArray(final byte[] _headerByteArray) {
        this.headerByteArray = _headerByteArray;
    }

}
