/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/02/10| 新規作成                           | 1.00.00| YSK)植山
 *  2014/08/26| <10101-005> ログ追加               | 1.02.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.telecom.socket.impl;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketTimeoutException;

import jp.ysk.fw.telecom.FW02_01_CommSocketMain;
import jp.ysk.fw.telecom.socket.FW02_01_AbstractSocketBase;
import jp.ysk.fw.telecom.socket.FW02_01_ChildSocket;

/**
 * ソケット受信(UDP用)クラス
 * <pre>
 * [変更履歴]
 * 1.0 2009/08/17  初版
 * </pre>
 * @version 1.0 2009/08/17
 * @author  YSK)西田　浩二
 */

/**
 *
 * ソケット受信(UDP用)クラス.<br>
 *<br>
 * 概要:<br>
 *   UDP用のソケット受信クラス
 *<br>
 */
public class FW02_01_ReceiveSocketUDP extends FW02_01_AbstractSocketBase {

    /**
     * 受信ソケット.
     */
    private DatagramSocket socket;

    /**
     * 受信バッファサイズ.
     */
    private int updBuffSize = 1024;

    /**
     * 初期化処理.
     *
     * @throws IOException 例外
     */
    @Override
    protected void init() throws IOException {
        this.socket = new DatagramSocket(super.port);
        this.socket.setSoTimeout(super.acceptTimeout);
    }

    /**
     * 受信待機処理.
     *
     * @throws Exception 例外
     */
    @Override
    protected void accept() throws Exception {
        try {
            byte[] receiveBuff = new byte[this.updBuffSize];
            DatagramPacket packet = new DatagramPacket(receiveBuff, this.updBuffSize);
            this.socket.receive(packet);
            //アプリ共通のサブスレッドを取得する。
            FW02_01_ChildSocket childThread =
                    (FW02_01_ChildSocket) FW02_01_CommSocketMain.callContainer(super.logicClassName);
            childThread.setSocket(this.socket, packet);

            super.runChild(childThread);

        } catch (SocketTimeoutException timeout) {

        } catch (Exception e) {
            this.outputErrorLog("Exception !!", e);
        }
    }
}
