/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/04/09| 新規作成                           | 1.00.00| YSK)大山
 *  2014/08/26| <10101-005> ログ追加               | 1.02.00| YSK)植山
 *  2014/10/01| <10101-018> IT不具合対応(No.19)    | 1.02.00| YSK)大山
 *  2014/12/12| <20000-014> 最終通信日時対応       | 3.00.00| YSK)植山
 *  2015/07/10| <30003-036> 変更仕様No.12          | 3.01.00| US)萩尾
 *  2016/01/11| <40000-020> 変更仕様No.20          | 4.00.00| US)萩尾
 *  2016/01/18| <40000-028> 変更仕様No.28          | 4.00.00| US)萩尾
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.fw.telecom;

import java.text.DecimalFormat;

/**
 * 通信プロセス共通定数.<br>
 *<br>
 * 概要:<br>
 *   通信プロセス用の共通の定数クラスです
 *<br>
 */
public abstract class FW02_01_TelecomConst {

    /**
     * 計測データコマンド.
     */
    public static final int COMMAND_DATA_NUM = 0x1000;

    /**
     * ファイルデータコマンド.
     */
    public static final int COMMAND_FILE_DATA_NUM = 0x2000;

    /**
     * 計測データコマンド(文字列).
     */
    public static final String COMMAND_DATA_STR = "1000";

    /**
     * ファイルデータコマンド.
     */
    public static final String COMMAND_FILE_DATA_STR = "2000";

    /**
     * 連続通信破棄時間(ミリ秒).
     */
    public static final int TELECOM_INVALID_SPAN = 500;

    /**
     * 最大レコード数.
     */
    public static final int MAX_RECORD_NUM = 10000;
    /**
     * 最大受信データサイズ.
     */
    public static final int MAX_RECEIVE_SIZE = 10485760;
    /**
     * 機能ID：FTP通信.
     */
    public static final String FUNCTION_ID_FTP = "B01-0010";
    /**
     * 機能ID：TCP通信.
     */
    public static final String FUNCTION_ID_TCP = "B01-0020";
    /**
     * 機能ID：MMLP(MMLinkプロトコル)通信.
     */
    public static final String FUNCTION_ID_MMLP = "B01-0030";

    /**
     * プロトコルバージョン.
     */
    public static final Long[] ACCEPT_PROTOCOL_VERSION = {new Long(1), new Long(2)};

    /**
     * 日時フォーマット.
     */
    public static final String DATE_FORMAT_FILE = "yyyy-MM-dd_HH-mm-ss";

    /**
     * 実行ロックファイルパス.
     */
    public static final String PATH_LOCK = "/var/lock/mmcloud/telecom/";

    /**
     * 実行ロックファイル名.
     */
    public static final String FILE_LOCK_TAIL = "-lock.txt";

    /**
     *
     * エラーコードクラス.<br>
     *<br>
     * 概要:<br>
     *   エラーコードのクラスです
     *<br>
     */
    public abstract class ERRCODE {
        /**
         * エラー000. Invalid file name
         */
        public static final String TER000 = "TER000";
        /**
         * エラー001. File number limit over
         */
        public static final String TER001 = "TER001";
        /**
         * エラー002. File size limit over
         */
        public static final String TER002 = "TER002";
        /**
         * エラー003. FTP directory access error
         */
        public static final String TER003 = "TER003";
        /**
         * エラー004. File read error
         */
        public static final String TER004 = "TER004";
        /**
         * エラー100. Invalid header format
         */
        public static final String TER100 = "TER100";
        /**
         * エラー101. Undefined protocol version
         */
        public static final String TER101 = "TER101";
        /**
         * エラー102. Telegram length mismatch
         */
        public static final String TER102 = "TER102";
        /**
         * エラー103. Unexpected receive error
         */
        public static final String TER103 = "TER103";
        /**
         * エラー104. Invalid time data
         */
        public static final String TER104 = "TER104";
        /**
         * エラー105. Telegram length over
         */
        public static final String TER105 = "TER105";
        /**
         * エラー200. Unknown Customer ID
         */
        public static final String TER200 = "TER200";
        /**
         * エラー201. Unknown device ID
         */
        public static final String TER201 = "TER201";
        /**
         * エラー202. Unknown Command Code
         */
        public static final String TER202 = "TER202";
        /**
         * エラー203. Raw data DB registration failure
         */
        public static final String TER203 = "TER203";
        /**
         * エラー204. Unexpected command error
         */
        public static final String TER204 = "TER204";
        /**
         * エラー205. Invalid Telecom Span error
         */
        public static final String TER205 = "TER205";
        /**
         * エラー206. Over capacity error
         */
        public static final String TER206 = "TER206";
        /**
         * エラー300. No DataPoint defined
         */
        public static final String TER300 = "TER300";
        /**
         * エラー301. Invalid column number
         */
        public static final String TER301 = "TER301";
        /**
         * エラー302. Invalid Record length
         */
        public static final String TER302 = "TER302";
        /**
         * エラー303. Unexpected format error
         */
        public static final String TER303 = "TER303";
        /**
         * エラー304. Invalid Record Number
         */
        public static final String TER304 = "TER304";
        /**
         * エラー305. Repeat XPATH is not found
         */
        public static final String TER305 = "TER305";
        /**
         * エラー306. file create error
         */
        public static final String TER306 = "TER306";
        /**
         * エラー400. Data type mismatch
         */
        public static final String TER400 = "TER400";
        /**
         * エラー401. Value range mismatch
         */
        public static final String TER401 = "TER401";
        /**
         * エラー402. DataPoint DB resigtration failure
         */
        public static final String TER402 = "TER402";
        /**
         * エラー403. Unexpected dataPoint error
         */
        public static final String TER403 = "TER403";
        /**
         * エラー404. DataPoint calculate error
         */
        public static final String TER404 = "TER404";
        /**
         * エラー405. range out
         */
        public static final String TER405 = "TER405";
        /**
         * エラー406. length over
         */
        public static final String TER406 = "TER406";
        /**
         * エラー407. encode error
         */
        public static final String TER407 = "TER407";
        /**
         * エラー408. date format error
         */
        public static final String TER408 = "TER408";
        /**
         * エラー409. value is invalid
         */
        public static final String TER409 = "TER409";
        /**
         * エラー410. exclude duplicate received data
         */
        public static final String TER410 = "TER410";
        /**
         * エラー411. Remove data out of receive span
         */
        public static final String TER411 = "TER411";
        /**
         * エラー412. Remove data in dead time
         */
        public static final String TER412 = "TER412";
        /**
         * エラー413. coordinate data format error
         */
        public static final String TER413 = "TER413";

    }

    /**
     *
     * メモリ使用量取得.<br>
     *<br>
     * 概要:<br>
     *   メモリ使用量文字列を取得する
     *<br>
     * @return メモリ使用量文字列
     */
    public static String getMemoryInfo() {

        DecimalFormat f1 = new DecimalFormat("#,###KB");
        DecimalFormat f2 = new DecimalFormat("##.#");
        long free = Runtime.getRuntime().freeMemory() / 1024;
        long total = Runtime.getRuntime().totalMemory() / 1024;
        long max = Runtime.getRuntime().maxMemory() / 1024;
        long used = total - free;
        double ratio = (used * 100 / (double) total);
        String info =
                "メモリ情報 : 合計=" + f1.format(total) + "、" +
                        "使用量=" + f1.format(used) + " (" + f2.format(ratio) + "%)、" +
                        "使用可能最大=" + f1.format(max);

        return info;
    }
}
