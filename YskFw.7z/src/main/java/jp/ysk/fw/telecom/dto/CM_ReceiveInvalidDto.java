/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/09/02| 新規作成                           | 1.02.00| YSK)大山
 * -----------+------------------------------------+--------+--------------
 */

package jp.ysk.fw.telecom.dto;

import java.util.Date;

/**
 * 通信禁止期間管理Dto.<br>
 *<br>
 * 概要:<br>
 *   通信禁止期間を管理するDTO
 *<br>
 */
public class CM_ReceiveInvalidDto {

    /**
     * 前回通信日時.
     */
    public Date telecomDate;

    /**
     * ステータス.
     */
    public String status;

    /**
     * ステータス：処理中.
     */
    public static final String PROCESSING = "0";
    /**
     * ステータス：終了.
     */
    public static final String END = "1";

    /**
     * コンストラクタ.
     *
     */
    public CM_ReceiveInvalidDto() {
        this.status = END;
    }
}
