/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+=======================================+========+==============
 *  DATE      | Comments                              | Rev    | SIGN
 * ===========+=======================================+========+==============
 *  2014/01/20| 新規作成                              | 1.00.00| YSK)植山
 *  2016/01/11| <40000-016> Ver.4.00.00 変更仕様No.16 | 4.00.00| US)甲斐
 *  2016/01/26| <30101-002> 故障苦情No.30100-012      | 4.00.00| US)萩尾
 * -----------+---------------------------------------+--------+--------------
 */
package jp.ysk.fw.form;

import java.util.Map;

/**
 *
 * フォーム規定クラス.<br>
 *<br>
 * 概要:<br>
 *   フォームクラスの最上位の親クラスで、フレームワークの共通処理を実装します
 *<br>
 */
public class FW01_17_BaseForm {

    /**
     * 通信区分定数.
     */
    public static final String FW0117FORM_REQUESTKBN = "fw0117RequestKbn";

    /**
     * Window区分定数.
     */
    public static final String FW0117FORM_WINMODE = "fw0117WinMode";

    /**
     * 初期表示フラグ定数.
     */
    public static final String FW0117FORM_INITFLG = "fw0117InitFlg";

    /**
     * 画面戻り先ID定数.
     */
    public static final String FW0117FORM_BACKSCREENID = "fw0117BackScreenId";

    /**
     * 共通詳細検索の検索条件値定義.
     */
    public static final String CM_HDN_COM_DETAIL_SEARCH_COND = "hdnComDetailSearchCond";

    /**
     * 共通詳細検索の検索条件値定義.
     */
    public static final String CM_HDN_COM_DETAIL_SEARCH_COND_FOR_SORT = "hdnComDetailSearchCondForSort";

    /**
     * 共通詳細検索の条件復帰用情報定義.
     */
    public static final String CM_DETAIL_SEARCH_COND_VALUE = "detailSearchCondValue";

    /**
     * 共通ヘッダーメニューリンク先情報定義.
     */
    public static final String CM_HDN_COM_HEADER_MENU_LINK = "hdnComHeaderMenuLink";

    /**
     * 共通ヘッダー開閉状態情報定義.
     */
    public static final String CM_HDN_IS_HEADER_OPENED = "hdnIsHeaderOpened";

    /**
     * 共通地図アクセスカウント数.
     */
    public static final String CM_HDN_MAPACCESS_COUNT_NUM = "hdnMapAccessCountNum";

    /**
     * 逐次検索の検索条件値.
     */
    public static final String CM_HDN_COM_INCREMENTAL_SEARCH_COND = "hdnComIncrementalSearchCond";

    /**
     * SQLRuntimeエラーメッセージCD.
     */
    public static final String CM_HDN_SQL_ERROR_MSG_CD = "hdnSqlErrorMsgCd";

    /**
     * 通信区分("ajax"⇒AJAX通信、その他⇒同期通信).
     */
    public String fw0117RequestKbn;

    /**
     * Window区分("popwin"⇒Window.openで開いたポップアップWindw、その他⇒親画面).
     */
    public String fw0117WinMode;

    /**
     * 初期表示フラグ(画面表示初回か否かのフラグ).
     *
     */
    public String fw0117InitFlg;

    /**
     * 画面戻り先ID.
     */
    public String fw0117BackScreenId;

    /**
     * 共通詳細検索の検索条件値.
     */
    public String hdnComDetailSearchCond;

    /**
     * 共通詳細検索の検索条件値.
     */
    public String hdnComDetailSearchCondForSort;

    /**
     * 共通詳細検索の検索条件値.
     */
    public Map<String, Object> detailSearchCondValue;

    /**
     * 共通ヘッダ押下メニューリンク先情報.
     */
    public String hdnComHeaderMenuLink;

    /**
     * 共通ヘッダ押下パンくずINDEX情報.
     */
    public String hdnComHeaderBreadCrumbIndex;

    /**
     * 共通ヘッダ開閉状態情報.
     */
    public String hdnIsHeaderOpened;

    /**
     * 共通地図アクセスカウント数.
     */
    public String hdnMapAccessCountNum;

    /**
     * 逐次検索の検索条件値.
     */
    public String hdnComIncrementalSearchCond;
    
    /**
     * SQLRuntimeエラーメッセージCD(SQLRuntimeエラー時のメッセージCD）.
     */
    public String hdnSqlErrorMsgCd;
}
