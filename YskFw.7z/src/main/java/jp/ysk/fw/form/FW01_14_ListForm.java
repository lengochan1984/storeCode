/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/01/27| 新規作成                           | 1.00.00| YSK)森山
 *  2016/01/14| <40000-025> 変更仕様No.25          | 4.00.00| US)萩尾
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw.form;

import org.apache.struts.upload.FormFile;

/**
 *
 * 一覧画面基底Action.<br>
 *<br>
 * 概要:<br>
 *  Listフォームクラスの最上位の親クラスで、フレームワークの共通処理を実装します
 *<br>
 */
public class FW01_14_ListForm extends FW01_17_BaseForm {

    //*********************************************
    //プロパティ名Const
    //*********************************************
    /**
     * 表示件数.
     */
    public static final String FW0114FORM_LISTSIZE = "fw0114ListSize";

    /**
     * 現在ページ数.
     */
    public static final String FW0114FORM_PAGENO = "fw0114PageNo";

    /**
     * ソートキー.
     */
    public static final String FW0114FORM_SORTKEY = "fw0114SortKey";

    /**
     * ソート順.
     * A:ASC    D:DESC
     */
    public static final String FW0114FORM_SORTORDER = "fw0114SortOrder";

    /**
     * 型番SID：modelSid.<BR>
     * ※アラームアイコン取得用
     */
    public static final String FW0114FORM_MODELSID = "fw0114ModelSid";

    /**
     * アイコンタイプ：iconType.<BR>
     * ※アラームアイコン取得用
     */
    public static final String FW0114FORM_ICONTYPE = "fw0114IconType";

    //*********************************************
    //プロパティ名宣言
    //*********************************************
    /**
     * 表示件数.
     */
    public String fw0114ListSize;

    /**
     * 現在ページ数.
     */
    public String fw0114PageNo;

    /**
     * ソートキー.
     */
    public String fw0114SortKey;

    /**
     * ソート順.
     * A:ASC    D:DESC
     */
    public String fw0114SortOrder;

    /**
     * アップロードファイル.
     */
    public FormFile uploadCsvFile;

    /**
     * 型番SID.<BR>
     * ※アラームアイコン取得用
     */
    public String fw0114ModelSid;

    /**
     * アイコンタイプ.<BR>
     * ※アラームアイコン取得用
     */
    public String fw0114IconType;

}
