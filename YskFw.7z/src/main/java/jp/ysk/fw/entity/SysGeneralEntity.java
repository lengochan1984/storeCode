package jp.ysk.fw.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 汎用マスタ
 *
 */
@Entity
@Table(name = "sys_general")
@Generated(value = {"S2JDBC-Gen 2.4.41", "org.seasar.extension.jdbc.gen.internal.model.EntityModelFactoryImpl"}, date = "2014/02/28 13:50:37")
public class SysGeneralEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 汎用CD */
    @Id
    @Column(length = 20, nullable = false, unique = false)
    public String genCd;

    /** 項目CD */
    @Id
    @Column(length = 10, nullable = false, unique = false)
    public static String itemCd;

    /** 名称 */
    @Column(length = 128, nullable = true, unique = false)
    public static String name;

    /** 略称 */
    @Column(length = 64, nullable = true, unique = false)
    public String abbName;

    /** 名称項目CD : 多国語対応が必要な項目には名称マスタの項目CDが入る */
    @Column(length = 10, nullable = true, unique = false)
    public String nameItemCd;

    /** デフォルトフラグ : 1:デフォルト
0:デフォルトでない
※1以外はデフォルトでないとみなす。 */
    @Column(length = 1, nullable = false, unique = false)
    public static String defaultFlg;

    /** 表示順 : 使用しない場合は0を設定 */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer displayOrder;

    /** 備考 */
    @Column(length = 300, nullable = true, unique = false)
    public String remark;

    /** 削除フラグ : true：有効、false：無効 */
    @Column(length = 1, nullable = false, unique = false)
    public Boolean deleteFlag;

    /** 登録プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String insProg;

    /** 登録日時 */
    @Column(nullable = false, unique = false)
    public Timestamp insTim;

    /** 登録ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer insUserSid;

    /** 更新プログラム名 */
    @Column(length = 32, nullable = false, unique = false)
    public String updProg;

    /** 更新日時 */
    @Column(nullable = false, unique = false)
    public Timestamp updTim;

    /** 更新ユーザSID */
    @Column(precision = 10, nullable = false, unique = false)
    public Integer updUserSid;

    /**
     * @return genCd
     */
    public String getGenCd() {
        return this.genCd;
    }

    /**
     * @param genCd セットする genCd
     */
    public void setGenCd(String genCd) {
        this.genCd = genCd;
    }

    /**
     * @return itemCd
     */
    public String getItemCd() {
        return this.itemCd;
    }

    /**
     * @param itemCd セットする itemCd
     */
    public void setItemCd(String itemCd) {
        this.itemCd = itemCd;
    }

    /**
     * @return name
     */
    public String getName() {
        return this.name;
    }

    /**
     * @param name セットする name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return abbName
     */
    public String getAbbName() {
        return this.abbName;
    }

    /**
     * @param abbName セットする abbName
     */
    public void setAbbName(String abbName) {
        this.abbName = abbName;
    }

    /**
     * @return nameItemCd
     */
    public String getNameItemCd() {
        return this.nameItemCd;
    }

    /**
     * @param nameItemCd セットする nameItemCd
     */
    public void setNameItemCd(String nameItemCd) {
        this.nameItemCd = nameItemCd;
    }

    /**
     * @return defaultFlg
     */
    public String getDefaultFlg() {
        return SysGeneralEntity.defaultFlg;
    }

    /**
     * @param _defaultFlg セットする defaultFlg
     */
    public void setDefaultFlg(final String _defaultFlg) {
        SysGeneralEntity.defaultFlg = _defaultFlg;
    }

    /**
     * @return displayOrder
     */
    public Integer getDisplayOrder() {
        return this.displayOrder;
    }

    /**
     * @param displayOrder セットする displayOrder
     */
    public void setDisplayOrder(Integer displayOrder) {
        this.displayOrder = displayOrder;
    }

    /**
     * @return remark
     */
    public String getRemark() {
        return this.remark;
    }

    /**
     * @param remark セットする remark
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

    /**
     * @return deleteFlag
     */
    public Boolean getDeleteFlag() {
        return this.deleteFlag;
    }

    /**
     * @param deleteFlag セットする deleteFlag
     */
    public void setDeleteFlag(Boolean deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    /**
     * @return insProg
     */
    public String getInsProg() {
        return this.insProg;
    }

    /**
     * @param insProg セットする insProg
     */
    public void setInsProg(String insProg) {
        this.insProg = insProg;
    }

    /**
     * @return insTim
     */
    public Timestamp getInsTim() {
        return this.insTim;
    }

    /**
     * @param insTim セットする insTim
     */
    public void setInsTim(Timestamp insTim) {
        this.insTim = insTim;
    }

    /**
     * @return insUserSid
     */
    public Integer getInsUserSid() {
        return this.insUserSid;
    }

    /**
     * @param insUserSid セットする insUserSid
     */
    public void setInsUserSid(Integer insUserSid) {
        this.insUserSid = insUserSid;
    }

    /**
     * @return updProg
     */
    public String getUpdProg() {
        return this.updProg;
    }

    /**
     * @param updProg セットする updProg
     */
    public void setUpdProg(String updProg) {
        this.updProg = updProg;
    }

    /**
     * @return updTim
     */
    public Timestamp getUpdTim() {
        return this.updTim;
    }

    /**
     * @param updTim セットする updTim
     */
    public void setUpdTim(Timestamp updTim) {
        this.updTim = updTim;
    }

    /**
     * @return updUserSid
     */
    public Integer getUpdUserSid() {
        return this.updUserSid;
    }

    /**
     * @param updUserSid セットする updUserSid
     */
    public void setUpdUserSid(Integer updUserSid) {
        this.updUserSid = updUserSid;
    }
}