/*
 * ***********************************************************************
 *
 *   [Product Name] : MMCloud
 *
 *   Copyright (C) 2014 YASKAWA INFORMATION SYSTEMS Corporation
 *                                                   All Rights Reserved.
 *
 * ***********************************************************************
 * ===========+====================================+========+==============
 *  DATE      | Comments                           | Rev    | SIGN
 * ===========+====================================+========+==============
 *  2014/02/10| 新規作成                           | 1.00.00| YSK)植山
 * -----------+------------------------------------+--------+--------------
 */
package jp.ysk.fw;

/**
 *
 * 通信例外クラス.<br>
 *<br>
 * 概要:<br>
 *   通信プロセスの例外クラス
 *<br>
 */
public class FW00_12_TelecomException extends FW00_12_AppException {

    /**
     * シリアルバージョン.
     */
    private static final long serialVersionUID = 1L;

    /**
     *
     * 列挙体：応答タイプ.
     * <pre>
     * [変更履歴]
     * 1.0 2009/11/19  初版
     * </pre>
     * @version 1.0 2009/11/19
     * @author  YSK)西田　浩二
     */

    /**
     *
     * 応答種別.<br>
     *<br>
     * 概要:<br>
     *   応答種別の列挙体
     *<br>
     */
    public static enum RESPONSE_TYPE {
        /**
         * デフォルト(データ連携の定義に従う).
         */
        DEFAULT,
        /**
         * 強制応答.
         */
        FORCE_RETURN,
        /**
         * 強制非応答.
         */
        FORCE_NOT_RETURN
    }

    /**
     * 応答種別.
     */
    private RESPONSE_TYPE type;

    /**
     * エラーコード.
     */
    private String errCode;

    /**
     * エラー詳細.
     */
    private String errDetail;

    /**
     * コンストラクタ.
     * @param _type 種別
     * @param _errorCode エラーコード
     * @param _errorDetail エラー詳細
     */
    public FW00_12_TelecomException(final RESPONSE_TYPE _type, final String _errorCode, final String _errorDetail) {
        this.type = _type;
        this.errCode = _errorCode;
        this.errDetail = _errorDetail;
    }

    /**
     * コンストラクタ.
     * @param _errorCode エラーコード
     * @param _errorDetail エラー詳細
     */
    public FW00_12_TelecomException(final String _errorCode, final String _errorDetail) {
        this(RESPONSE_TYPE.DEFAULT, _errorCode, _errorDetail);
    }

    /**
     * コンストラクタ.
     * @param _type 種別
     * @param _errorCode エラーコード
     */
    public FW00_12_TelecomException(final RESPONSE_TYPE _type, final String _errorCode) {
        this(_type, _errorCode, "");
    }

    /**
     * コンストラクタ.
     * @param _errorCode エラーコード
     */
    public FW00_12_TelecomException(final String _errorCode) {
        this(RESPONSE_TYPE.DEFAULT, _errorCode, "");
    }

    /**
     *
     * 応答種別取得.<br>
     *<br>
     * 概要:<br>
     *   応答種別を取得する
     *<br>
     * @return 応答種別
     */
    public RESPONSE_TYPE getType() {
        return this.type;
    }

    /**
     *
     * エラーコード取得.<br>
     *<br>
     * 概要:<br>
     *   エラーコードを取得する
     *<br>
     * @return エラーコード
     */
    public String getErrCode() {
        return this.errCode;
    }

    /**
     *
     * エラー詳細取得.<br>
     *<br>
     * 概要:<br>
     *   エラー詳細を取得する
     *<br>
     * @return エラー詳細
     */
    public String getErrDetail() {
        return this.errDetail;
    }
}
