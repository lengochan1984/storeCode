SELECT
    new_alarm_info.alarm_state_data_sid AS alarm_state_data_sid,
    new_alarm_info.device_sid AS device_sid,
    (new_alarm_info.alarm_count - new_alarm_info.alarm_recover_count) AS alarm_count,
    new_alarm_info.alarm_recover_count AS alarm_recover_count,
    new_alarm_info.alarm_date,
    new_alarm_info.alarm_on_datetime,
    new_alarm_info.alarm_off_datetime,
    new_alarm_info.alarm_judge_datetime,
    new_alarm_info.alarm_name AS alarm_name,
    new_alarm_info.alarm_level,
    tbl_alarm_judge_data.phenomenon_text AS phenomenon_text,
    tbl_alarm_judge_data.alarm_condition_text AS alarm_condition_text,
    tbl_alarm_judge_data.status AS status
FROM (
    SELECT
        ROW_NUMBER()
            OVER (
                PARTITION BY
                    alarm_state_data.alarm_date
                ORDER BY
                    alarm_state_data.select_flg ASC,
                    alarm_state_data.alarm_level DESC,
                    alarm_state_data.alarm_state_data_sid DESC
            ) AS row_num,
        COUNT(alarm_state_data.alarm_state_data_sid)
            OVER (
                PARTITION BY
                    alarm_state_data.alarm_date
            ) AS alarm_count,
        COUNT(alarm_state_data.alarm_off_datetime)
            OVER (
                PARTITION BY
                    alarm_state_data.alarm_date
            ) AS alarm_recover_count,
        alarm_state_data.alarm_state_data_sid,
        alarm_state_data.device_sid,
        alarm_state_data.alarm_date,
        alarm_state_data.alarm_on_datetime,
        alarm_state_data.alarm_off_datetime,
        alarm_state_data.alarm_judge_datetime,
        alarm_state_data.alarm_name,
        alarm_state_data.alarm_level
    FROM
        (
            (
                SELECT
                    search_alarm_state_data.sid AS alarm_state_data_sid,
                    search_alarm_state_data.device_sid,
                    /*IF summaryUnit == 13*/
                    to_char(date_trunc('second', search_alarm_state_data.search_alarm_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS alarm_date,
                    /*END*/
                    /*IF summaryUnit == 12*/
                    to_char(date_trunc('minute', search_alarm_state_data.search_alarm_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS alarm_date,
                    /*END*/
                    /*IF summaryUnit == 11*/
                    to_char(date_trunc('hour', search_alarm_state_data.search_alarm_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS alarm_date,
                    /*END*/
                    /*IF summaryUnit == 5*/
                    to_char(date_trunc('day', search_alarm_state_data.search_alarm_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS alarm_date,
                    /*END*/
                    /*IF summaryUnit == 2*/
                    to_char(date_trunc('month', search_alarm_state_data.search_alarm_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS alarm_date,
                    /*END*/
                    search_alarm_state_data.alarm_on_datetime,
                    NULL AS alarm_off_datetime,
                    search_alarm_state_data.alarm_judge_datetime,
                    mst_alarm.alarm_name,
                    mst_alarm.alarm_level,
                    /*IF alarmStateDataSid != null*/
                    (CASE search_alarm_state_data.sid WHEN /*alarmStateDataSid*/ THEN 1 else 2 END) as select_flg
                    /*END*/
                    /*IF alarmStateDataSid == null*/
                    NULL as select_flg
                    /*END*/
                FROM
                    (
                        SELECT
                            sid,
                            device_sid,
                            alarm_sid,
                            alarm_status,
                            alarm_judge_datetime,
                            alarm_on_datetime,
                            alarm_off_datetime,
                            alarm_off_user_sid,
                            confirm_on_datetime,
                            confirm_on_user_sid,
                            confirm_off_datetime,
                            confirm_off_user_sid,
                            complete_datetime,
                            complete_user_sid,
                            last_upd_prog,
                            last_upd_tim,
                            /*IF zoneOffset != null*/
                            (alarm_on_datetime + cast(/*zoneOffset*/ as interval) - cast(/*searchDateShiftTime*/ as interval)) AS search_alarm_date
                            /*END*/
                            /*IF zoneOffset == null*/
                            (alarm_on_datetime - cast(/*searchDateShiftTime*/ as interval)) AS search_alarm_date
                            /*END*/
                        FROM
                            tbl_alarm_state_data
                        WHERE
                            tbl_alarm_state_data.device_sid = /*deviceSid*/
                    ) search_alarm_state_data
                INNER JOIN
                    mst_alarm
                    ON search_alarm_state_data.alarm_sid = mst_alarm.sid
                WHERE
                    search_alarm_state_data.search_alarm_date >= /*txtSearchDateTimeFrom*/
                    AND search_alarm_state_data.search_alarm_date <= /*txtSearchDateTimeTo*/
            )
            UNION ALL
            (
                SELECT
                    search_alarm_state_data.sid AS alarm_state_data_sid,
                    search_alarm_state_data.device_sid,
                    /*IF summaryUnit == 13*/
                    to_char(date_trunc('second', search_alarm_state_data.search_alarm_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS alarm_date,
                    /*END*/
                    /*IF summaryUnit == 12*/
                    to_char(date_trunc('minute', search_alarm_state_data.search_alarm_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS alarm_date,
                    /*END*/
                    /*IF summaryUnit == 11*/
                    to_char(date_trunc('hour', search_alarm_state_data.search_alarm_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS alarm_date,
                    /*END*/
                    /*IF summaryUnit == 5*/
                    to_char(date_trunc('day', search_alarm_state_data.search_alarm_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS alarm_date,
                    /*END*/
                    /*IF summaryUnit == 2*/
                    to_char(date_trunc('month', search_alarm_state_data.search_alarm_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS alarm_date,
                    /*END*/
                    search_alarm_state_data.alarm_on_datetime,
                    search_alarm_state_data.alarm_off_datetime,
                    search_alarm_state_data.alarm_judge_datetime,
                    mst_alarm.alarm_name,
                    mst_alarm.alarm_level,
                    /*IF alarmStateDataSid != null*/
                    (CASE search_alarm_state_data.sid WHEN /*alarmStateDataSid*/ THEN 1 else 2 END) as select_flg
                    /*END*/
                    /*IF alarmStateDataSid == null*/
                    NULL as select_flg
                    /*END*/
                FROM
                    (
                        SELECT
                            sid,
                            device_sid,
                            alarm_sid,
                            alarm_status,
                            alarm_judge_datetime,
                            alarm_on_datetime,
                            alarm_off_datetime,
                            alarm_off_user_sid,
                            confirm_on_datetime,
                            confirm_on_user_sid,
                            confirm_off_datetime,
                            confirm_off_user_sid,
                            complete_datetime,
                            complete_user_sid,
                            last_upd_prog,
                            last_upd_tim,
                            /*IF zoneOffset != null*/
                            (alarm_off_datetime + cast(/*zoneOffset*/ as interval) - cast(/*searchDateShiftTime*/ as interval)) AS search_alarm_date
                            /*END*/
                            /*IF zoneOffset == null*/
                            (alarm_off_datetime - cast(/*searchDateShiftTime*/ as interval)) AS search_alarm_date
                            /*END*/
                        FROM
                            tbl_alarm_state_data
                        WHERE
                            tbl_alarm_state_data.device_sid = /*deviceSid*/
                    ) search_alarm_state_data
                INNER JOIN
                    mst_alarm
                    ON search_alarm_state_data.alarm_sid = mst_alarm.sid
                WHERE
                    search_alarm_state_data.search_alarm_date >= /*txtSearchDateTimeFrom*/
                    AND search_alarm_state_data.search_alarm_date <= /*txtSearchDateTimeTo*/
            )
        ) alarm_state_data
) new_alarm_info
LEFT JOIN
    tbl_alarm_judge_data
    ON new_alarm_info.alarm_state_data_sid = tbl_alarm_judge_data.alarm_state_data_sid
WHERE
    new_alarm_info.row_num = 1

ORDER BY
    alarm_date DESC
