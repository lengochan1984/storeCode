select
    mst_customer.sid,
    mst_customer.customer_cd,
    mst_customer.name,
    mst_customer.is_use_map,
    mst_customer.max_device_number,
    mst_customer.max_user_number,
    mst_customer.contact_mail1,
    mst_customer.contact_mail2,
    sys_db_connect.connect_string,
    sys_db_connect.user_name,
    sys_db_connect.passwd
from
    mst_customer
inner join
    sys_db_connect
on
    mst_customer.sid = sys_db_connect.customer_sid and
    sys_db_connect.delete_flag = false
where
    mst_customer.customer_cd = /*customer_cd*/'a' and
    mst_customer.delete_flag = false
