select
    user_sid
from
    tbl_user_login_info
where
    user_sid = /*user_sid*/1
