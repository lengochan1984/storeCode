SELECT
    measure_datetime,
    data_point_value
FROM
    /*IF dataType == "01"*/
    tbl_data_point_data_word
    /*END*/
    /*IF dataType == "02"*/
    tbl_data_point_data_int
    /*END*/
    /*IF dataType == "03"*/
    tbl_data_point_data_decimal
    /*END*/
    /*IF dataType == "04"*/
    tbl_data_point_data_date
    /*END*/
    /*IF dataType == "05"*/
    tbl_data_point_data_point
    /*END*/
    /*IF dataType == "06"*/
    tbl_data_point_data_bit
    /*END*/
    /*IF dataType == "07"*/
    tbl_data_point_data_text
    /*END*/
    /*IF dataType == "08"*/
    tbl_data_point_data_event
    /*END*/
WHERE
    device_sid = /*deviceSid*/
    AND
    data_point_sid = /*sid*/
    AND
    measure_datetime > /*txtSearchDateTimeFrom*/
    AND
    measure_datetime < /*txtSearchDateTimeTo*/
ORDER BY
    data_point_sid ASC, measure_datetime ASC
