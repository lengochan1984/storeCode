SELECT
    COUNT(tbl_telegram_data.sid) AS data_count
FROM
    tbl_telegram_data
WHERE
    tbl_telegram_data.device_sid = /*deviceSid*/
AND
    DATE_TRUNC('day', tbl_telegram_data.communication_datetime) = /*communicationDate*/
