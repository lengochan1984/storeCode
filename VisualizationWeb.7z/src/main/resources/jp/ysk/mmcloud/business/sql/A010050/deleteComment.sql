DELETE
FROM
    tbl_comment
WHERE
    tbl_comment.mainte_status_sid = /*mainteStatusSid*/
