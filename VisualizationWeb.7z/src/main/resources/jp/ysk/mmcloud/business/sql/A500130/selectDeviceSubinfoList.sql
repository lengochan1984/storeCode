SELECT
    mst_model_subinfo.subinfo_cd,
    mst_model_subinfo.sid AS model_subinfo_sid,
    mst_device_subinfo.subinfo_value
FROM
    mst_device

INNER JOIN
    mst_model ON mst_device.model_sid = mst_model.sid

INNER JOIN
    mst_model_subinfo ON mst_model_subinfo.model_sid = mst_model.sid

LEFT JOIN
    mst_device_subinfo ON mst_device_subinfo.model_subinfo_sid = mst_model_subinfo.sid
    AND mst_device_subinfo.device_sid = mst_device.sid

WHERE
    mst_device.sid = /*deviceSid*/

ORDER BY
    mst_model_subinfo.display_order ASC
