SELECT
    COALESCE(SUM(count_num), 0)
FROM
    tbl_map_access_count_data
WHERE
    substring(count_date,0,7) = /*countDate*/'a'
