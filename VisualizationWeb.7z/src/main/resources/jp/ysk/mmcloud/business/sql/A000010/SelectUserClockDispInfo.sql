select
    mst_user_clock_disp.timezone_cd,
    sys_env.name,
    sys_env.abb_name,
    sys_env.remark
from
    mst_user_clock_disp
inner join
    sys_env
on
    sys_env.item_cd = mst_user_clock_disp.timezone_cd and
    sys_env.env_cd = 'timezone' and
    sys_env.delete_flag = false
where
    mst_user_clock_disp.user_sid = /*user_sid*/1 and
    mst_user_clock_disp.delete_flag = false
order by
    mst_user_clock_disp.disp_index
