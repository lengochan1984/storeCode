SELECT
    mst_data_point.sid,
    mst_data_point.data_type,
    mst_data_point.unit_cd,
    mst_data_point.name_item_cd,
    mst_data_point.delete_flag,
    rel_view_dp.graph_disp,
    rel_view_dp.count_method,
    rel_view_dp.axis,
    rel_view_dp.disp_range_strat,
    rel_view_dp.disp_range_stop,
    rel_view_dp.graph_kind,
    rel_view_dp.disp_order
FROM
    mst_device
INNER JOIN
    mst_command ON mst_device.communication_profile_sid = mst_command.profile_sid
INNER JOIN
    mst_data_point ON mst_command.sid = mst_data_point.command_sid
INNER JOIN
    mst_trend_view ON mst_trend_view.profile_sid = mst_device.communication_profile_sid
INNER JOIN rel_view_dp ON
    rel_view_dp.trend_view_sid = mst_trend_view.sid AND
    mst_data_point.sid = rel_view_dp.data_point_sid
WHERE
    mst_device.sid = /*deviceSid*/
    AND
     mst_trend_view.sid = /*trendViewSid*/
    AND
    mst_data_point.save_kind = '1'

ORDER BY
    rel_view_dp.disp_order ASC ,mst_data_point.delete_flag ASC, mst_data_point.sid ASC, mst_data_point.data_point_cd ASC
