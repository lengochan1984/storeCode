SELECT
    mst_device_status.management_type
FROM
    mst_device_status
WHERE
    mst_device_status.profile_sid = /*profileSid*/
