DELETE FROM
    mst_mainte_status
WHERE
    mst_mainte_status.device_sid = /*deviceSid*/
