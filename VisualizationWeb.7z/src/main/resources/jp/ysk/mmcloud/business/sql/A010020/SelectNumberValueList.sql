/*IF summaryUnit == 13*/
SELECT
    aa.data_point_value AS data_point_value,
    /*IF zoneOffset != null*/
    to_char(measure_datetime + cast(/*zoneOffset*/ as interval) ,'yyyy/mm/dd hh24:mi:ss') AS format_date,
    /*END*/
    /*IF zoneOffset == null*/
    to_char(measure_datetime,'yyyy/mm/dd hh24:mi:ss') AS format_date,
    /*END*/
    1 AS data_count,
    NULL AS doc_name
FROM
    /*IF dataType == "02"*/
    tbl_data_point_data_int AS aa
    /*END*/
    /*IF dataType == "03"*/
    tbl_data_point_data_decimal AS aa
    /*END*/
    /*IF dataType == "06"*/
    tbl_data_point_data_bit AS aa
    /*END*/
    /*IF dataType == "09"*/
    tbl_data_point_data_uint AS aa
    /*END*/
WHERE
    aa.device_sid = /*deviceSid*/
    AND
    aa.data_point_sid = /*sid*/
    AND
    aa.measure_datetime >= /*txtSearchDateTimeFrom*/
    AND
    aa.measure_datetime <= /*txtSearchDateTimeTo*/
/*END*/
/*IF summaryUnit != 13*/
/*IF summaryMode != "new"*/
SELECT
    /*IF summaryMode == "avg"*/
    sum(aa.data_point_value) AS data_point_value,
    /*END*/
    /*IF summaryMode == "max"*/
    max(aa.data_point_value) AS data_point_value,
    /*END*/
    /*IF summaryMode == "min"*/
    min(aa.data_point_value) AS data_point_value,
    /*END*/
    /*IF summaryMode == "sum"*/
    sum(aa.data_point_value) AS data_point_value,
    /*END*/
    aa.format_date AS format_date,
    count(aa.format_date) AS data_count,
    NULL AS doc_name
FROM
    (
        SELECT
            data_point_value,
            /*IF summaryUnit == 12*/
            to_char(date_trunc('minute', search_data.search_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS format_date
            /*END*/
            /*IF summaryUnit == 11*/
            to_char(date_trunc('hour', search_data.search_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS format_date
            /*END*/
            /*IF summaryUnit == 5*/
            to_char(date_trunc('day', search_data.search_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS format_date
            /*END*/
            /*IF summaryUnit == 2*/
            to_char(date_trunc('month', search_data.search_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS format_date
            /*END*/
        FROM
            (
                SELECT
                    telegram_sid,
                    data_point_sid,
                    measure_datetime,
                    data_point_value,
                    device_sid,
                    /*IF zoneOffset != null*/
                    (measure_datetime + cast(/*zoneOffset*/ as interval) - cast(/*searchDateShiftTime*/ as interval)) AS search_date
                    /*END*/
                    /*IF zoneOffset == null*/
                    (measure_datetime - cast(/*searchDateShiftTime*/ as interval)) AS search_date
                    /*END*/
                FROM
                    /*IF dataType == "02"*/
                    tbl_data_point_data_int
                    /*END*/
                    /*IF dataType == "03"*/
                    tbl_data_point_data_decimal
                    /*END*/
                    /*IF dataType == "06"*/
                    tbl_data_point_data_bit
                    /*END*/
                    /*IF dataType == "09"*/
                    tbl_data_point_data_uint
                    /*END*/
                WHERE
                    device_sid = /*deviceSid*/
                    AND
                    data_point_sid = /*sid*/
            ) search_data
        WHERE
            search_data.search_date >= /*txtSearchDateTimeFrom*/
            AND
            search_data.search_date <= /*txtSearchDateTimeTo*/
    ) aa
GROUP BY
    aa.format_date
/*END*/
/*IF summaryMode == "new"*/
SELECT
    aa.data_point_value AS data_point_value,
    bb.format_date AS format_date,
    1 AS data_count,
    NULL AS doc_name
FROM
    /*IF dataType == "02"*/
    tbl_data_point_data_int AS aa
    /*END*/
    /*IF dataType == "03"*/
    tbl_data_point_data_decimal AS aa
    /*END*/
    /*IF dataType == "06"*/
    tbl_data_point_data_bit AS aa
    /*END*/
    /*IF dataType == "09"*/
    tbl_data_point_data_uint AS aa
    /*END*/
INNER JOIN
    (
     SELECT
        cc.device_sid,
        cc.data_point_sid,
        max(cc.measure_datetime) AS max_measure_date,
        cc.format_date
        FROM
            (
                SELECT
                    search_data.device_sid,
                    search_data.data_point_sid,
                    search_data.data_point_value,
                    search_data.measure_datetime,
                    /*IF summaryUnit == 12*/
                    to_char(date_trunc('minute', search_data.search_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS format_date
                    /*END*/
                    /*IF summaryUnit == 11*/
                    to_char(date_trunc('hour', search_data.search_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS format_date
                    /*END*/
                    /*IF summaryUnit == 5*/
                    to_char(date_trunc('day', search_data.search_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS format_date
                    /*END*/
                    /*IF summaryUnit == 2*/
                    to_char(date_trunc('month', search_data.search_date) + cast(/*searchDateShiftTime*/ as interval),'yyyy/mm/dd hh24:mi:ss') AS format_date
                    /*END*/
                FROM
                    (
                        SELECT
                            telegram_sid,
                            data_point_sid,
                            measure_datetime,
                            data_point_value,
                            device_sid,
                            /*IF zoneOffset != null*/
                            (measure_datetime + cast(/*zoneOffset*/ as interval) - cast(/*searchDateShiftTime*/ as interval)) AS search_date
                            /*END*/
                            /*IF zoneOffset == null*/
                            (measure_datetime - cast(/*searchDateShiftTime*/ as interval)) AS search_date
                            /*END*/
                        FROM
                            /*IF dataType == "02"*/
                            tbl_data_point_data_int
                            /*END*/
                            /*IF dataType == "03"*/
                            tbl_data_point_data_decimal
                            /*END*/
                            /*IF dataType == "06"*/
                            tbl_data_point_data_bit
                            /*END*/
                            /*IF dataType == "09"*/
                            tbl_data_point_data_uint
                            /*END*/
                        WHERE
                            device_sid = /*deviceSid*/
                            AND
                            data_point_sid = /*sid*/
                    ) search_data
                WHERE
                    search_data.search_date >= /*txtSearchDateTimeFrom*/
                    AND
                    search_data.search_date <= /*txtSearchDateTimeTo*/
            ) cc
        WHERE
            cc.data_point_value IS NOT NULL
        GROUP BY
            cc.device_sid, cc.data_point_sid, cc.format_date
    ) bb
ON aa.device_sid = bb.device_sid and aa.data_point_sid = bb.data_point_sid and aa.measure_datetime = bb.max_measure_date
/*END*/
/*END*/
ORDER BY
    format_date DESC
