
SELECT
    mst_device.sid,
    mst_device.device_id,
    mst_device.name,
    mst_device.version_no,
    mst_device.serial_no,
    mst_device.model_sid,
    mst_device.terminal_sid,
    mst_device.position_get_class,
    mst_device.position_info,
    COALESCE(mst_device.address,'') AS address,
    mst_device.timezone_cd,
    mst_device.operation_status,
    mst_device.ip_address,
    mst_device.port_number,
    mst_device.sim_type,
    mst_device.delete_flag,
    mst_model.name AS model_name,
    mst_model.default_profile_sid AS communication_profile_sid,
    mst_profile.profile_name AS profile_name,
    mst_group.group_id AS group_id,
    get_group_tree_path_name(mst_group.group_id) AS group_name,
    COALESCE(mst_com_terminal.terminal_name,'') AS terminal_name

FROM
    mst_device

INNER JOIN
    mst_model ON mst_device.model_sid = mst_model.sid

INNER JOIN
    mst_profile ON mst_model.default_profile_sid = mst_profile.sid

INNER JOIN
    rel_device_group ON rel_device_group.device_sid = mst_device.sid

INNER JOIN
    mst_group ON rel_device_group.group_id = mst_group.group_id

LEFT JOIN
    mst_com_terminal ON mst_device.terminal_sid = mst_com_terminal.sid

/*BEGIN*/
WHERE
/*IF sid != null */
    AND mst_device.sid = /*sid*/
/*END*/
/*END*/

