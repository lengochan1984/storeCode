SELECT
    mst_group.group_id,
    mst_group.group_name,
    mst_group.tree_path,
    get_group_tree_path_name(mst_group.group_id ) AS tree_path_name,
    '0' AS is_link
FROM
    mst_group
WHERE
    group_id IN /*group_id*/('1', '2')
    AND mst_group.group_id NOT LIKE 'SYS%'
    AND mst_group.delete_flag = false
ORDER BY
    mst_group.tree_path
