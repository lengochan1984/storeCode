SELECT
    mst_device.sid
FROM
    mst_device
INNER JOIN
    rel_device_group
ON
    mst_device.sid = rel_device_group.device_sid
INNER JOIN
    mst_group mst_group_tree
ON
    rel_device_group.group_id = mst_group_tree.group_id AND
    mst_group_tree.delete_flag = false
INNER JOIN
    mst_group mst_group_main
ON
    mst_group_tree.tree_path <@ mst_group_main.tree_path AND
    mst_group_main.delete_flag = false
INNER JOIN
    rel_user_group
ON
    rel_user_group.group_id = mst_group_main.group_id AND
    rel_user_group.user_sid = /*userSid*/1 AND
    rel_user_group.delete_flag = false
WHERE
    mst_device.sid = /*deviceSid*/1 AND
    mst_device.delete_flag = false
