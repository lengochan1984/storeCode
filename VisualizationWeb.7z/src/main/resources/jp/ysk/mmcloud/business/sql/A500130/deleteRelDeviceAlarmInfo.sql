DELETE
FROM
    rel_device_alarm
WHERE
    rel_device_alarm.device_sid = /*deviceSid*/
    AND rel_device_alarm.send_group_num_seq = /*sendGroupNumSeq*/
