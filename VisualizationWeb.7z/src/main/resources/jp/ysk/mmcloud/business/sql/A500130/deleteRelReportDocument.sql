DELETE FROM
    rel_report_document
WHERE
    rel_report_document.report_sid
    IN
    (SELECT
        mst_mainte_status.sid
    FROM
        mst_mainte_status
    WHERE
        mst_mainte_status.device_sid = /*deviceSid*/
    )
