
SELECT
    mst_alarm_send_address.sid,
    mst_alarm_send_address.device_sid,
    mst_alarm_send_address.alarm_sid,
    mst_alarm_send_address.send_group_num_seq,
    mst_alarm_send_address.mail_address_sid,
    mst_alarm_send_address.address_kind,
    mst_mail_address.mail_address,
    mst_mail_address.name

FROM
    mst_alarm_send_address

INNER JOIN
    mst_mail_address ON mst_mail_address.sid = mst_alarm_send_address.mail_address_sid

WHERE
    mst_alarm_send_address.device_sid = /*deviceSid*/
    AND mst_alarm_send_address.alarm_sid = /*alarmSid*/
    AND mst_alarm_send_address.send_group_num_seq = /*sendGroupNumSeq*/
    AND mst_alarm_send_address.delete_flag = /*deleteFlag*/

ORDER BY
    mst_alarm_send_address.address_kind ASC
