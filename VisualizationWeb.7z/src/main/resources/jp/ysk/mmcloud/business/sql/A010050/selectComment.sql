
SELECT
    tbl_comment.sid,
    tbl_comment.comment_user_sid,
    tbl_comment.mainte_status_sid,
    tbl_comment.comment_type,
    tbl_comment.comment_user_sid,
    tbl_comment.comment_datetime,
    tbl_comment.comment_data,
    tbl_comment.last_upd_tim,
    mst_user.user_lastname,
    mst_user.user_firstname,
    mst_user.timezone_cd,
    mst_user.lang_cd,
    sys_env.abb_name AS country_cd

FROM
    tbl_comment

INNER JOIN
    mst_user ON tbl_comment.comment_user_sid = mst_user.sid

LEFT OUTER JOIN
    sys_env
ON
    sys_env.env_cd = 'timezone' AND
    sys_env.item_cd = mst_user.timezone_cd

WHERE
    tbl_comment.mainte_status_sid = /*mainteStatusSid*/
    AND tbl_comment.comment_type = /*commentType*/
ORDER BY
    tbl_comment.last_upd_tim DESC
