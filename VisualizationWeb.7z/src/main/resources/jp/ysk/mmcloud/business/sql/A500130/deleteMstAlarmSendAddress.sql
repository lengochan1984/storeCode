DELETE FROM
    mst_alarm_send_address
WHERE
    mst_alarm_send_address.device_sid = /*deviceSid*/
