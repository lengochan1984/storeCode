SELECT
    count(mst_mainte_status.sid)
FROM
    mst_mainte_status

LEFT OUTER JOIN
    (
    SELECT
        rel_device_group.device_sid
    FROM
        rel_device_group
        INNER JOIN
            mst_group ON rel_device_group.group_id = mst_group.group_id AND
            mst_group.tree_path <@
                (SELECT
                    mst_group.tree_path
                FROM
                    mst_group

                INNER JOIN
                    rel_user_group ON mst_group.group_id = rel_user_group.group_id
                WHERE
                    rel_user_group.user_sid = /*LoginUserSid*/)
    ) dev
    ON (dev.device_sid = mst_mainte_status.device_sid)

WHERE
    mst_mainte_status.sid = /*sid*/

/*IF isAdmin == false */
    AND (dev.device_sid IS NOT NULL)
/*END*/

