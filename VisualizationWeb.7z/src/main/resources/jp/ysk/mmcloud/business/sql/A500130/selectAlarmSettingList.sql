
SELECT
    rel_device_alarm.device_sid,
    rel_device_alarm.alarm_sid,
    rel_device_alarm.send_group_num_seq,
    rel_device_alarm.mail_send_flag_off,
    rel_device_alarm.mail_send_flag_on,
    rel_device_alarm.mail_template_type_off,
    rel_device_alarm.mail_template_type_on,
    mst_alarm.alarm_name

FROM
    rel_device_alarm

INNER JOIN
    mst_alarm ON mst_alarm.sid = rel_device_alarm.alarm_sid

WHERE
    rel_device_alarm.device_sid = /*deviceSid*/
    AND rel_device_alarm.delete_flag = /*deleteFlag*/


