select
    mst_user.sid,
    mst_user.user_lastname,
    mst_user.user_firstname,
    mst_user.user_auth_cd,
    mst_user.passwd,
    mst_user.timezone_cd,
    sys_env.name as timezone_name,
    sys_env.abb_name as timezone_abb_name,
    sys_env.remark as timezone_remark,
    mst_user.lang_cd,
    mst_user.theme_color_cd,
    mst_user.clock_disp_flag,
    mst_user.exp_tim,
    tbl_user_login_info.passwd_miss_count,
    mst_role_setting.function_cd,
    mst_role_setting.page_id,
    mst_role_setting.auth_setting
from
    mst_user
left outer join
    tbl_user_login_info
on
    mst_user.sid = tbl_user_login_info.user_sid
inner join
    rel_user_role
on
    mst_user.sid = rel_user_role.user_sid and
    rel_user_role.delete_flag = false
inner join
    mst_role_setting
on
    rel_user_role.role_sid = mst_role_setting.role_sid and
    rel_user_role.role_sid = mst_role_setting.role_sid and
    mst_role_setting.delete_flag = false
inner join
    sys_env
on
    mst_user.timezone_cd = sys_env.item_cd and
    sys_env.env_cd = 'timezone' and
    sys_env.delete_flag = false
where
    mst_user.id = /*user_id*/'a' and
    mst_user.delete_flag = false and
    mst_user.invalid_flag = '0'
order by
    mst_role_setting.function_cd asc,
    mst_role_setting.page_id asc
