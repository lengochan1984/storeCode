DELETE
FROM
    rel_device_group
WHERE
    rel_device_group.device_sid = /*deviceSid*/
