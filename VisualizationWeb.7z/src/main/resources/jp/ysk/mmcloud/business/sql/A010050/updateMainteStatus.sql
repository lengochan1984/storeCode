UPDATE
    mst_mainte_status

SET
    device_sid = /*deviceSid*/,
    type = /*type*/,
    name = /*name*/,
    mainte_datetime = /*mainteDatetime*/,
    mainte_timezone_cd = /*mainteTimezoneCd*/,
    mainte_user = /*mainteUser*/,
    /*IF mainteOutline != null */
        mainte_outline = /*mainteOutline*/,
    /*END*/
    /*IF mainteResult != null */
        mainte_result = /*mainteResult*/,
    /*END*/
    /*IF failureOutline != null */
        failure_outline = /*failureOutline*/,
    /*END*/
    /*IF actionOutline != null */
        action_outline = /*actionOutline*/,
    /*END*/
    /*IF couseOutline != null */
        couse_outline = /*couseOutline*/,
    /*END*/
    /*IF appendix != null */
        appendix = /*appendix*/,
    /*END*/
    upd_prog = /*updProg*/,
    upd_tim = /*updTim*/,
    upd_user_sid = /*updUserSid*/

WHERE
    sid = /*sid*/
    AND delete_flag = false




