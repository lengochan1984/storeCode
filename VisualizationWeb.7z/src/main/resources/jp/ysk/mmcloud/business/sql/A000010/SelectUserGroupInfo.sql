select
    rel_user_group.group_id,
    mst_group.group_name,
    get_group_tree_path_name(rel_user_group.group_id) as group_full_name
from
    rel_user_group
inner join
    mst_group
on
    rel_user_group.group_id = mst_group.group_id and
    mst_group.delete_flag = false
where
    rel_user_group.user_sid = /*user_sid*/1 and
    rel_user_group.delete_flag = false
