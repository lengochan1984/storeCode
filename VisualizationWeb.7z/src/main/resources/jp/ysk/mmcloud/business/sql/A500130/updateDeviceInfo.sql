
UPDATE
    mst_device

SET
/*IF deviceId != null */
    device_id = /*deviceId*/,
/*END*/
    name = /*name*/,
    version_no = /*versionNo*/,
    serial_no = /*serialNo*/,
    model_sid = /*modelSid*/,
    communication_profile_sid = /*communicationProfileSid*/,
/*IF terminalSid != null */
    terminalSid = /*terminalSid*/,
/*END*/
    position_get_class = /*positionGetClass*/,
/*IF positionInfo != null */
    position_info = /*positionInfo*/,
/*END*/
/*IF address != null */
    address = /*address*/,
/*END*/
    timezone_cd = /*timezoneCd*/,
    operation_status = /*operationStatus*/,
/*IF subInfomation != null */
    sub_infomation = /*subInfomation*/,
/*END*/
    upd_prog = /*updProg*/,
    upd_tim = /*updTim*/,
    upd_user_sid = /*updUserSid*/

WHERE
    sid = /*sid*/
    AND delete_flag = false




