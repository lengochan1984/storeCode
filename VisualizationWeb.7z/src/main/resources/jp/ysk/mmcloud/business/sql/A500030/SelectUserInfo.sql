select
    mst_user.sid,
    mst_user.id,
    mst_user.user_lastname,
    mst_user.user_firstname,
    mst_user.user_lastname_kana,
    mst_user.user_firstname_kana,
    mst_user.user_auth_cd,
    mst_user.passwd,
    mst_user.timezone_cd,
    mst_user.lang_cd,
    mst_user.theme_color_cd,
    mst_user.clock_disp_flag,
    mst_user.char_size,
    mst_user.invalid_flag,
    mst_user.exp_tim,
    mst_user.delete_flag,
    mst_mail_address.mail_address,
    mst_mail_address.name
from
    mst_user
left outer join
    mst_mail_address
on
    mst_user.sid = mst_mail_address.user_sid
where
    mst_user.sid = ?

