SELECT
    mst_device.name,
    mst_device.timezone_cd,
    mst_device.position_info,
    mst_model.name as model_name,
    get_group_tree_path_name(rel_device_group.group_id) AS tree_path_name
FROM
    mst_device
LEFT OUTER JOIN
    mst_model ON mst_device.model_sid = mst_model.sid
INNER JOIN
    rel_device_group ON mst_device.sid = rel_device_group.device_sid
WHERE
    mst_device.sid = /*deviceSid*/
