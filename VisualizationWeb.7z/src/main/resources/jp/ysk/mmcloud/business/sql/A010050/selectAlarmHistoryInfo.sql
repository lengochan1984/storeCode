SELECT
    tbl_alarm_state_data.alarm_sid,
    tbl_alarm_state_data.alarm_on_datetime,
    mst_alarm.alarm_name,
    mst_alarm.alarm_level,
    mst_alarm.alarm_kind,
    mst_device.timezone_cd

FROM
    rel_alarm_mainte

    INNER JOIN
        tbl_alarm_state_data ON (tbl_alarm_state_data.sid = rel_alarm_mainte.alarm_state_data_sid)

    LEFT OUTER JOIN
        mst_alarm ON (mst_alarm.sid = tbl_alarm_state_data.alarm_sid)

    LEFT OUTER JOIN
        mst_device ON (mst_device.sid = tbl_alarm_state_data.device_sid)

WHERE

    rel_alarm_mainte.mainte_status_sid = /*mainteStatusSid*/

ORDER BY
    tbl_alarm_state_data.sid ASC

