update
    tbl_map_access_count_data
set
    count_num = count_num + /*countNum*/1,
    last_upd_prog = /*lastUpdProg*/'a',
    last_upd_tim = /*lastUpdTim*/
where
    count_date = /*countDate*/'a'
