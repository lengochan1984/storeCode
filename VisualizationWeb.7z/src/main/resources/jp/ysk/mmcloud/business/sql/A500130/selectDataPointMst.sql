SELECT
    aa.name as name_item_cd,
    coalesce(bb.name,'') as unit_cd,
    mst_data_point.data_point_cd,
    mst_data_point.sid,
    mst_data_point.data_type
FROM
    mst_data_point

LEFT OUTER JOIN
    (
    SELECT
        mst_name.name,
        mst_name.item_cd
    FROM
        mst_name
    WHERE
        mst_name.name_type = /*nameType1*/
        AND
        mst_name.lang_cd = /*langCd*/
    ) aa
    ON mst_data_point.name_item_cd = aa.item_cd
LEFT OUTER JOIN
    (
    SELECT
        mst_name.name,
        mst_name.item_cd
    FROM
        mst_name
    WHERE
        mst_name.name_type = /*nameType2*/
        AND
        mst_name.lang_cd = /*langCd*/
    ) bb
    ON mst_data_point.unit_cd = bb.item_cd

WHERE
    mst_data_point.save_kind = '1'
/*IF sid != null*/
    AND mst_data_point.sid = /*sid*/
/*END*/
