update
    tbl_disp_access_count_data
set
    count_num = count_num + 1,
    last_upd_prog = /*lastUpdProg*/'a',
    last_upd_tim = /*lastUpdTim*/
where
    access_datetime = /*accessDatetime*/'a' and
    page_id = /*pageId*/'a'
