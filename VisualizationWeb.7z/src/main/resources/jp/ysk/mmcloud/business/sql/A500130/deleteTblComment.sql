DELETE FROM
    tbl_comment
WHERE
    tbl_comment.mainte_status_sid
    IN
    (SELECT
        mst_mainte_status.sid
    FROM
        mst_mainte_status
    WHERE
        mst_mainte_status.device_sid = /*deviceSid*/
    )
