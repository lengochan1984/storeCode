SELECT
    hoursum.sum_count,
    hoursum.value,
    hoursum.measure_datetime
FROM
    /*IF dataType == '01'*/
    tbl_hour_sum_data_word AS hoursum
    /*END*/
    /*IF dataType == '02'*/
    tbl_hour_sum_data_int AS hoursum
    /*END*/
    /*IF dataType == '03'*/
    tbl_hour_sum_data_decimal AS hoursum
    /*END*/
    /*IF dataType == '04'*/
    tbl_hour_sum_data_date AS hoursum
    /*END*/
    /*IF dataType == '05'*/
    tbl_hour_sum_data_point AS hoursum
    /*END*/
    /*IF dataType == '06'*/
    tbl_hour_sum_data_bit AS hoursum
    /*END*/
    /*IF dataType == '07'*/
    tbl_hour_sum_data_text AS hoursum
    /*END*/
    /*IF dataType == '08'*/
    tbl_hour_sum_data_event AS hoursum
    /*END*/
    /*IF dataType == '09'*/
    tbl_hour_sum_data_uint AS hoursum
    /*END*/


WHERE
    hoursum.device_sid = /*deviceSid*/
    AND hoursum.data_point_sid = /*dataPointSid*/
    AND hoursum.measure_datetime =

        (SELECT
            MAX(maxsum.measure_datetime)
         FROM
             /*IF dataType == '01'*/
             tbl_hour_sum_data_word AS maxsum
             /*END*/
             /*IF dataType == '02'*/
             tbl_hour_sum_data_int AS maxsum
             /*END*/
             /*IF dataType == '03'*/
             tbl_hour_sum_data_decimal AS maxsum
             /*END*/
             /*IF dataType == '04'*/
             tbl_hour_sum_data_date AS maxsum
             /*END*/
             /*IF dataType == '05'*/
             tbl_hour_sum_data_point AS maxsum
             /*END*/
             /*IF dataType == '06'*/
             tbl_hour_sum_data_bit AS maxsum
             /*END*/
             /*IF dataType == '07'*/
             tbl_hour_sum_data_text AS maxsum
             /*END*/
             /*IF dataType == '08'*/
             tbl_hour_sum_data_event AS maxsum
             /*END*/
             /*IF dataType == '09'*/
             tbl_hour_sum_data_uint AS maxsum
             /*END*/


         WHERE
             maxsum.device_sid = /*deviceSid*/
             AND maxsum.data_point_sid = /*dataPointSid*/
        )

