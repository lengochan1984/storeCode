INSERT INTO
  /*IF dataType == '01'*/
  tbl_hour_sum_data_word
  /*END*/
  /*IF dataType == '02'*/
  tbl_hour_sum_data_int
  /*END*/
  /*IF dataType == '03'*/
  tbl_hour_sum_data_decimal
  /*END*/
  /*IF dataType == '04'*/
  tbl_hour_sum_data_date
  /*END*/
  /*IF dataType == '05'*/
  tbl_hour_sum_data_point
  /*END*/
  /*IF dataType == '06'*/
  tbl_hour_sum_data_bit
  /*END*/
  /*IF dataType == '07'*/
  tbl_hour_sum_data_text
  /*END*/
  /*IF dataType == '08'*/
  tbl_hour_sum_data_event
  /*END*/
  /*IF dataType == '09'*/
  tbl_hour_sum_data_uint
  /*END*/

  (device_sid,
   data_point_sid,
   measure_datetime,
   /*IF dataType == '02' || dataType == '03' || dataType == '09'*/
   sum_count,
   value
     -- ELSE
        sum_count
  /*END*/
  ) VALUES (
  /*deviceSid*/,
  /*dataPointSid*/,
  /*measureDatetime*/,
  /*IF dataType == '02' || dataType == '03' || dataType == '09'*/
  /*sumCount*/,
  /*IF value != null*/
  /*value*/
    -- ELSE
      null
  /*END*/
    -- ELSE
       /*sumCount*/
  /*END*/
  )

