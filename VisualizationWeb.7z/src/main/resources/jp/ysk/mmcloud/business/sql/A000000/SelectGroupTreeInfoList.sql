SELECT
    mst_group_tree.group_id,
    mst_group_tree.group_name,
    mst_group_tree.tree_path,
    get_group_tree_path_name(mst_group_tree.group_id ) AS tree_path_name,
    '1' AS is_link
FROM
    rel_user_group
INNER JOIN
    mst_group mst_group_main
ON
    rel_user_group.group_id = mst_group_main.group_id
    AND mst_group_main.delete_flag = false
INNER JOIN
    mst_group mst_group_tree
ON
    mst_group_tree.tree_path <@ mst_group_main.tree_path
    AND mst_group_tree.group_id NOT LIKE 'SYS%'
    AND mst_group_tree.delete_flag = false
WHERE
    user_sid = /*user_sid*/1
    AND rel_user_group.delete_flag = false
ORDER BY
    mst_group_tree.tree_path
