SELECT
    rel_report_document.report_sid,
    rel_report_document.document_sid,
    mst_document.doc_name

FROM
    rel_report_document

INNER JOIN
    mst_document ON rel_report_document.document_sid = mst_document.sid

WHERE
    rel_report_document.report_sid = /*reportSid*/

ORDER BY
    rel_report_document.report_sid