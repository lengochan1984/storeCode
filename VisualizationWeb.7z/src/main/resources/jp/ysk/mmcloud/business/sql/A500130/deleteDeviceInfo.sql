
UPDATE
    mst_device

SET
    upd_prog = /*updProg*/,
    upd_tim = /*updTim*/,
    upd_user_sid = /*updUserSid*/,
    delete_flag = true
WHERE
    sid = /*sid*/
    AND delete_flag = false




