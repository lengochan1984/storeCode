SELECT
        mst_trend_view.trend_view_name
        ,mst_trend_view.sid || '' sid
/*IF alarmStateDataSid != null*/
        ,(SELECT COUNT(DISTINCT mst_alarm_condition.alarm_sid)
            FROM rel_view_dp
            INNER JOIN mst_alarm_condition
                ON mst_alarm_condition.data_point_sid = rel_view_dp.data_point_sid
            INNER JOIN tbl_alarm_state_data
                ON tbl_alarm_state_data.alarm_sid = mst_alarm_condition.alarm_sid
            WHERE
                rel_view_dp.trend_view_sid = mst_trend_view.sid
                AND tbl_alarm_state_data.sid = /*alarmStateDataSid*/
            ) AS data_point_count
/*END*/
/*IF alarmStateDataSid == null*/
        ,0 AS data_point_count
/*END*/
    FROM
        mst_trend_view
        INNER JOIN rel_role_view
            ON rel_role_view.trend_view_sid = mst_trend_view.sid
        INNER JOIN rel_user_role
            ON rel_user_role.role_sid = rel_role_view.role_sid
        INNER JOIN mst_device ON
            mst_device.communication_profile_sid = mst_trend_view.profile_sid AND
            mst_device.sid = /*sid*/
WHERE
    mst_trend_view.delete_flag = false
    AND rel_user_role.user_sid = /*userSid*/
ORDER BY
    mst_trend_view.display_order ASC
    ,mst_trend_view.trend_view_name ASC
    ,mst_trend_view.sid ASC;
