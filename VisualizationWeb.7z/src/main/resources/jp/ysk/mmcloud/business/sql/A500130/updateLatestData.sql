UPDATE
    /*IF dataType == '01'*/
    tbl_latest_data_word
    /*END*/
    /*IF dataType == '02'*/
    tbl_latest_data_int
    /*END*/
    /*IF dataType == '03'*/
    tbl_latest_data_decimal
    /*END*/
    /*IF dataType == '04'*/
    tbl_latest_data_date
    /*END*/
    /*IF dataType == '05'*/
    tbl_latest_data_point
    /*END*/
    /*IF dataType == '06'*/
    tbl_latest_data_bit
    /*END*/
    /*IF dataType == '07'*/
    tbl_latest_data_text
    /*END*/
    /*IF dataType == '08'*/
    tbl_latest_data_event
    /*END*/
    /*IF dataType == '09'*/
    tbl_latest_data_uint
    /*END*/


SET
/*IF dataType == '02' || dataType == '03' || dataType == '09'*/
    forever_sum_count = /*foreverSumCount*/,
    /*IF foreverSumValue != null*/
    forever_sum_value = /*foreverSumValue*/
      -- ELSE
        forever_sum_value = null
    /*END*/
      -- ELSE
         forever_sum_count = /*foreverSumCount*/
/*END*/

WHERE
    device_sid = /*deviceSid*/
    AND data_point_sid = /*dataPointSid*/

