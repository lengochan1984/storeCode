DELETE
FROM
    rel_report_document
WHERE
/*IF reportSid != null*/
    report_sid = /*reportSid*/
/*END*/
/*IF documentSid != null*/
    AND document_sid = /*documentSid*/
/*END*/

