DELETE FROM
    mst_device_subinfo
WHERE
    mst_device_subinfo.device_sid = /*deviceSid*/
