SELECT
    tbl_alarm_state_data.alarm_on_datetime,
    tbl_alarm_state_data.alarm_off_datetime
FROM
    tbl_alarm_state_data
WHERE
    tbl_alarm_state_data.SID = /*alarmStateSid*/
