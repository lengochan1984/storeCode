SELECT
    rel_alarm_mainte.mainte_status_sid

FROM
    mst_mainte_status

    INNER JOIN
        tbl_alarm_state_data on (tbl_alarm_state_data.device_sid = mst_mainte_status.device_sid)

    INNER JOIN
        rel_alarm_mainte on (
            rel_alarm_mainte.alarm_state_data_sid = tbl_alarm_state_data.sid
        AND rel_alarm_mainte.mainte_status_sid = /*sid*/
        )

WHERE
    mst_mainte_status.sid = /*sid*/
