
SELECT
    mst_mail_address.sid,
    mst_mail_address.user_sid,
    mst_mail_address.mail_address,
    mst_mail_address.name,
    aaa.user_mail_group_id,
    bbb.not_user_mail_group_id

FROM
    mst_mail_address

LEFT OUTER JOIN
    (
    SELECT
        mst_user.sid,
        mst_group.group_id AS user_mail_group_id
    FROM
        mst_user
    INNER JOIN
        rel_user_group ON mst_user.sid = rel_user_group.user_sid
    INNER JOIN
        mst_group ON rel_user_group.group_id = mst_group.group_id AND
        mst_group.tree_path <@
            (SELECT
                mst_group.tree_path
            FROM
                mst_group

            INNER JOIN
                rel_user_group ON mst_group.group_id = rel_user_group.group_id
            WHERE
                rel_user_group.user_sid = /*LoginUserSid*/1)
    )aaa ON aaa.sid = mst_mail_address.user_sid

LEFT OUTER JOIN
    (
    SELECT
        rel_group_mail_address.mail_address_sid,
        rel_group_mail_address.group_id AS not_user_mail_group_id
    FROM
        rel_group_mail_address
    INNER JOIN
        mst_group ON rel_group_mail_address.group_id = mst_group.group_id AND
        mst_group.tree_path <@
            (
            SELECT
                mst_group.tree_path
            FROM
                mst_group
           INNER JOIN
                rel_user_group ON mst_group.group_id = rel_user_group.group_id
            WHERE
                rel_user_group.user_sid = /*LoginUserSid*/1)
    )bbb ON bbb.mail_address_sid = mst_mail_address.sid

WHERE
    mst_mail_address.delete_flag = false
    AND (not_user_mail_group_id IS NOT NULL OR user_mail_group_id IS NOT NULL)

ORDER BY
    mst_mail_address.name ASC
