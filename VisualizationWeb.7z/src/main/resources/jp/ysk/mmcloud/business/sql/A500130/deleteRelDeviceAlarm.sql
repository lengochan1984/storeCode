DELETE FROM
    rel_device_alarm
WHERE
    rel_device_alarm.device_sid = /*deviceSid*/
