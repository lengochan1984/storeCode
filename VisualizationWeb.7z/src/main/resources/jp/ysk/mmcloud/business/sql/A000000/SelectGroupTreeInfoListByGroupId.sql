SELECT
    mst_group.group_id,
    mst_group.group_name,
    mst_group.tree_path,
    get_group_tree_path_name(mst_group.group_id ) AS tree_path_name,
    '1' AS is_link
FROM
    mst_group
WHERE
    mst_group.delete_flag = false
    AND mst_group.group_id NOT LIKE 'SYS%'
    AND mst_group.tree_path <@
            (SELECT
                mst_group.tree_path
            FROM
                mst_group
            INNER JOIN
                rel_user_group ON mst_group.group_id = rel_user_group.group_id
            WHERE
                rel_user_group.user_sid = /*LoginUserSid*/1)
    AND mst_group.tree_path <@
            (SELECT
                mst_group.tree_path
            FROM
                mst_group
            WHERE
                mst_group.group_id = /*groupId*/)

ORDER BY
    mst_group.tree_path
