SELECT
       mst_user.sid,
       mst_user.id,
       mst_user.user_lastname,
       mst_user.user_firstname,
       COALESCE(mst_user.user_lastname_kana,'') AS user_lastname_kana,
       COALESCE(mst_user.user_firstname_kana,'') AS user_firstname_kana,
       mst_user.user_auth_cd,
       mst_role.role_name,
       mst_group.group_id,
       mst_group.group_name,
       mst_user.timezone_cd,
       mst_user.invalid_flag,
       mst_user.delete_flag,
       get_group_tree_path_name(rel_user_group.group_id) AS tree_path_name
FROM
    mst_user

INNER JOIN
    rel_user_role ON mst_user.sid = rel_user_role.user_sid

INNER JOIN
    mst_role ON mst_role.sid = rel_user_role.role_sid

INNER JOIN
    rel_user_group ON mst_user.sid = rel_user_group.user_sid

INNER JOIN
    mst_group ON rel_user_group.group_id = mst_group.group_id AND
    mst_group.tree_path <@
        (SELECT
            mst_group.tree_path
        FROM
            mst_group

        INNER JOIN
            rel_user_group ON mst_group.group_id = rel_user_group.group_id
        WHERE
            rel_user_group.user_sid = /*LoginUserSid*/1)
/*IF groupPath != null*/
    AND mst_group.tree_path <@ text2ltree(/*groupPath*/)
/*END*/


/*BEGIN*/
WHERE
/*IF txtUserId != null*/
   AND mst_user.id LIKE /*txtUserId*/'S'
/*END*/
/*IF txtUserName != null*/
   AND COALESCE(mst_user.user_lastname,'') || ' ' || COALESCE(mst_user.user_firstname,'') LIKE /*txtUserName*/'S'
/*END*/
/*IF cond_UserNameKana != null*/
   AND COALESCE(mst_user.user_lastname_kana,'') || ' ' || COALESCE(mst_user.user_firstname_kana,'') LIKE /*cond_UserNameKana*/'S'
/*END*/
/*IF cond_UserAuth != null*/
   AND mst_user.user_auth_cd = /*cond_UserAuth*/'S'
/*END*/
/*IF cond_Role != null*/
   AND mst_role.sid = /*cond_Role*/1
/*END*/
/*IF cond_Timezone != null*/
   AND mst_user.timezone_cd = /*cond_Timezone*/'S'
/*END*/
/*IF cond_InvalidFlag != null*/
   AND mst_user.invalid_flag = /*cond_InvalidFlag*/'S'
/*END*/
/*END*/

ORDER BY
/*IF fw0114SortKey == null*/
    mst_user.delete_flag ASC, id ASC
/*END*/
/*IF  fw0114SortKey == "id"*/
    /*IF fw0114SortOrder == "asc"*/
    id ASC, mst_user.delete_flag ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    id DESC, mst_user.delete_flag ASC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "userLastname"*/
    /*IF fw0114SortOrder == "asc"*/
    user_lastname ASC, user_firstname ASC, mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    user_lastname DESC, user_firstname DESC, mst_user.delete_flag ASC, id ASC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "userLastnameKana"*/
    /*IF fw0114SortOrder == "asc"*/
    user_lastname_kana ASC, user_firstname_kana ASC, mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    user_lastname_kana DESC, user_firstname_kana DESC, mst_user.delete_flag ASC, id ASC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "userAuthCd"*/
    /*IF fw0114SortOrder == "asc"*/
    mst_user.user_auth_cd ASC, mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    mst_user.user_auth_cd DESC, mst_user.delete_flag ASC, id ASC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "roleName"*/
    /*IF fw0114SortOrder == "asc"*/
    mst_role.sid ASC, mst_role.display_order ASC, mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    mst_role.sid DESC, mst_role.display_order DESC, mst_user.delete_flag ASC, id ASC
    /*END*/
/*END*/

/*IF  fw0114SortKey == "treePath"*/
    /*IF fw0114SortOrder == "asc"*/
    tree_path_name ASC, mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    tree_path_name DESC, mst_user.delete_flag ASC, id ASC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "timezoneCd"*/
    /*IF fw0114SortOrder == "asc"*/
    timezone_cd ASC, mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    timezone_cd DESC, mst_user.delete_flag ASC, id ASC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "invalidFlag"*/
    /*IF fw0114SortOrder == "asc"*/
    invalid_flag ASC, mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    invalid_flag DESC, mst_user.delete_flag ASC, id ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == "deleteFlag"*/
    /*IF fw0114SortOrder == "asc"*/
        mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
        mst_user.delete_flag DESC, id ASC
    /*END*/
/*END*/