DELETE FROM
    rel_alarm_mainte
WHERE
    rel_alarm_mainte.mainte_status_sid
    IN
    (SELECT
        mst_mainte_status.sid
    FROM
        mst_mainte_status
    WHERE
        mst_mainte_status.device_sid = /*deviceSid*/
    )
