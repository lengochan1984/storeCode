DELETE FROM
    tbl_distribute_status
WHERE
    tbl_distribute_status.device_sid = /*deviceSid*/
