INSERT INTO
  /*IF dataType == '01'*/
  tbl_latest_data_word
  /*END*/
  /*IF dataType == '02'*/
  tbl_latest_data_int
  /*END*/
  /*IF dataType == '03'*/
  tbl_latest_data_decimal
  /*END*/
  /*IF dataType == '04'*/
  tbl_latest_data_date
  /*END*/
  /*IF dataType == '05'*/
  tbl_latest_data_point
  /*END*/
  /*IF dataType == '06'*/
  tbl_latest_data_bit
  /*END*/
  /*IF dataType == '07'*/
  tbl_latest_data_text
  /*END*/
  /*IF dataType == '08'*/
  tbl_latest_data_event
  /*END*/
  /*IF dataType == '09'*/
  tbl_latest_data_uint
  /*END*/

  (device_sid,
   data_point_sid,
   measure_datetime,
   /*IF dataType == '02' || dataType == '03' || dataType == '09'*/
   forever_sum_count,
   forever_sum_value
     -- ELSE
        forever_sum_count
  /*END*/
  ) VALUES (
  /*deviceSid*/,
  /*dataPointSid*/,
  /*measureDatetime*/,
  /*IF dataType == '02' || dataType == '03' || dataType == '09'*/
  /*foreverSumCount*/,
  /*IF foreverSumValue != null*/
  /*foreverSumValue*/
    -- ELSE
      null
  /*END*/
    -- ELSE
       /*foreverSumCount*/
  /*END*/
  )

