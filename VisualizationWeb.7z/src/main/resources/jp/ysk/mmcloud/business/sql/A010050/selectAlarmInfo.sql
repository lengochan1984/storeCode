SELECT
    tbl_alarm_state_data.alarm_sid,
    tbl_alarm_state_data.alarm_on_datetime,
    mst_alarm.alarm_name,
    mst_alarm.alarm_level,
    mst_alarm.alarm_kind,
    mst_device.timezone_cd

FROM
    tbl_alarm_state_data

    LEFT OUTER JOIN
        mst_alarm ON (mst_alarm.sid = tbl_alarm_state_data.alarm_sid)

    LEFT OUTER JOIN
        mst_device ON (mst_device.sid = tbl_alarm_state_data.device_sid)

WHERE

    tbl_alarm_state_data.sid = /*sid*/

ORDER BY
    tbl_alarm_state_data.sid ASC
