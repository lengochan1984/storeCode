SELECT
    msl.plant_cd,
    ml.ln_no,
    ml.ln_id,
    COALESCE(ml.ln_nm, ml.ln_no) as line_name,
    tlw.ln_start_time,
    tlw.ln_finish_time
FROM
    ma_seizou_line msl
INNER JOIN ma_plant mpl
    ON mpl.plant_cd = msl.plant_cd
INNER JOIN ma_plant_mieruka mpl_mieruka
    ON mpl_mieruka.plant_cd = mpl.plant_cd
INNER JOIN ma_process mpr
    ON mpr.seizou_ln_id = msl.seizou_ln_id
INNER JOIN ma_line ml
    ON ml.process_id = mpr.process_id
INNER JOIN tr_line_work tlw
    ON tlw.ln_id = ml.ln_id
WHERE
    msl.plant_cd = /*comPlantCode*/'T1'
AND	 msl.seizou_ln_id = /*comSeizouLnId*/1
AND msl.invalid_flag = 0
AND mpl.invalid_flag = 0
AND mpl_mieruka.invalid_flag = 0
AND mpr.invalid_flag = 0
AND ml.invalid_flag = 0
AND tlw.ln_start_time > NOW() - interval '1 day'
AND tlw.ln_finish_time < NOW() + interval '1 day'
ORDER BY ml.ln_no