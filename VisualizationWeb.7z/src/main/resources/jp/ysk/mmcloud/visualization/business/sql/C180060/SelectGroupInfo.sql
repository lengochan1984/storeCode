select
    mst_group.group_id,
    mst_group.name_item_cd,
    get_group_tree_path_name(mst_group.group_id ) AS tree_path_name
from
    rel_user_group
inner join
    mst_group
on
    rel_user_group.group_id = mst_group.group_id and
    mst_group.delete_flag = false
where
    rel_user_group.user_sid = /*user_sid*/1 and
    rel_user_group.delete_flag = false
