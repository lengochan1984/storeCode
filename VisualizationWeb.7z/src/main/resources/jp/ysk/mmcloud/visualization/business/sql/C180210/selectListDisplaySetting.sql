SELECT
    mli.item_id,
    mli.item_label,
    mli.disp_type,
    mli.disp_order,
    mli.page_id
FROM
    ma_list_item mli
INNER JOIN
    ma_plant mp
ON
    mli.plant_cd = mp.plant_cd
WHERE
    mli.plant_cd = /*comPlantCode*/'T1'
ORDER BY
    mli.disp_order