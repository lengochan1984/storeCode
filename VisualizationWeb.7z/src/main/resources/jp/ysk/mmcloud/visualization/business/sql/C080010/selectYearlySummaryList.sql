-- 年別比率の項目を取得
-- ※工場コード、製品グループ名はJSONデータ生成時の比較処理で必要
-- ※キー項目を取得する際、スペースはトリムする
SELECT
  tbl_date.plant_code
  ,tbl_date.model_group_code
  ,tbl_date.date_series
  ,tbl_sum.sum_plan_num
  ,tbl_sum.sum_actual_num
FROM
  (
    -- 日付を取得
    -- ※日付以外は、結合時の条件及びソートキーとして使用
    SELECT
      tbl_date_temp.plant_code
      ,disp_order_p.display_order AS plant_display_order
      ,m.model_group_code
      ,disp_order_g.display_order AS model_group_display_order
      ,tbl_date_temp.summary_start_date
      ,tbl_date_temp.summary_end_date
      ,tbl_date_temp.date_series
    FROM
      (
        -- 品目マスタから工場コード、製品グループ名を取得
        -- ※製品グループ名をサイネージマスタの設定値で切替可能（将来の要望）
        SELECT
          COALESCE(RTRIM(ds_product_mng_yearly.plant_cd), '') AS plant_code
          -- サイネージ表示順序（シリーズ別）から取得
          /*IF groupSummaryKind == "01"*/
          ,COALESCE(RTRIM(ds_product_mng_yearly.vtext_info2), '') AS model_group_code
          /*END*/
          -- サイネージ表示順序（機種群別）から取得
          /*IF groupSummaryKind == "02"*/
          ,COALESCE(RTRIM(ds_product_mng_yearly.vtext_info1), '') AS model_group_code
          /*END*/
        FROM
          ds_product_mng_yearly
        GROUP BY
          plant_code
          ,model_group_code
      ) AS m
      INNER JOIN
        (
          -- 工場コード別に指定期間の日付を取得
          SELECT
            date_term.plant_code
            ,date_term.summary_start_date
            ,date_term.summary_end_date
            ,gs.date_series
          FROM
            (
              -- 当月度の開始日時と終了日時を現在日時を元に算出して、取得
              -- ※月度の開始日や当日の開始時間は、工場マスタの稼働開始日時から取得
              SELECT
                ma_plant_mieruka.plant_cd
                ,(
                  -- 現在日時から稼働開始日時の月数を減算した日付から、月日時分秒を切り捨て
                  date_trunc(
                    'years',
                    CAST('0001-01-01 00:00:00' AS TIMESTAMP WITHOUT time zone) + (CAST(current_timestamp AS TIMESTAMP WITHOUT time zone) - ma_plant.running_start_datetime)
                  )
                  -- 上記の日付に、指定年数を減算して、稼働開始日時の月日時分秒＋１年を加算する
                  -- ※日のみ1減算しているのは、0開始ではないため。
                  - CAST(/*yearlyProductNumPeriod*/'5' || ' years' AS INTERVAL) + CAST('1 years' AS INTERVAL)
                  + CAST(date_part('month', ma_plant.running_start_datetime) - 1 || ' months' AS INTERVAL)
                  + CAST(date_part('day', ma_plant.running_start_datetime) - 1 || ' days' AS INTERVAL)
                  + CAST(date_part('hour', ma_plant.running_start_datetime) || ' hours' AS INTERVAL)
                  + CAST(date_part('minute', ma_plant.running_start_datetime) || ' minutes' AS INTERVAL)
                  + CAST(date_part('second', ma_plant.running_start_datetime) || ' seconds' AS INTERVAL)
                ) AS summary_start_date
                -- 終了日時
                ,(
                  -- 現在日時から稼働開始日時の月数を減算した日付から、月日時分秒を切り捨て
                  date_trunc(
                    'years',
                    CAST('0001-01-01 00:00:00' AS TIMESTAMP WITHOUT time zone) + (CAST(current_timestamp AS TIMESTAMP WITHOUT time zone) - ma_plant.running_start_datetime)
                  )
                  -- 上記の日付に、稼働開始日時の日時分秒を加算
                  -- ※日のみ1減算しているのは、0開始ではないため。
                  + CAST(date_part('month', ma_plant.running_start_datetime) - 1 || ' months' AS INTERVAL)
                  + CAST(date_part('day', ma_plant.running_start_datetime) - 1 || ' days' AS INTERVAL)
                  + CAST(date_part('hour', ma_plant.running_start_datetime) || ' hours' AS INTERVAL)
                  + CAST(date_part('minute', ma_plant.running_start_datetime) || ' minutes' AS INTERVAL)
                  + CAST(date_part('second', ma_plant.running_start_datetime) || ' seconds' AS INTERVAL)
                  -- 上記の開始日時より1年加算
                  + CAST('1 years' AS INTERVAL)
                  -- 上記の日時(翌月度の開始日時)より1秒減算し、終了日時を算出
                  - CAST('1 seconds' AS interval)
                ) AS summary_end_date
              FROM
                ma_plant_mieruka
              INNER JOIN
                ma_plant
              ON
                    ma_plant.invalid_flag = 0
                AND ma_plant.plant_cd = ma_plant_mieruka.plant_cd
              WHERE
                    ma_plant_mieruka.invalid_flag = 0
                AND ma_plant_mieruka.plant_cd <> '  '
                AND ma_plant_mieruka.plant_cd IS NOT NULL
            ) AS date_term,
            -- date_termより算出した開始日時、終了日時の期間の日付を1年間隔で生成
            generate_series(
              date_term.summary_start_date,
              date_term.summary_end_date,
              '1 years'
            ) as gs(date_series)
          ) AS tbl_date_temp
        ON
          tbl_date_temp.plant_code = m.plant_code
      INNER JOIN
        (
          -- 表示データの表示順序を取得(サイネージID、製品グループ名が空白以外)
          SELECT
            *
          FROM
            (
              -- 表示データの表示順序を取得(全データ出力)
              -- ※取得するマスタをサイネージマスタの設定値で切替可能（将来の要望に対する対応）
              -- ※製品グループ名の項目名を"model_group_code"にするためにここでセレクトする
              SELECT
                -- サイネージ表示順序（シリーズ別）から取得
                /*IF groupSummaryKind == "01"*/
                COALESCE(RTRIM(ma_sig_disp_order_model_series.signage_id), '') AS signage_id
                ,COALESCE(RTRIM(ma_sig_disp_order_model_series.vtext_info2), '') AS model_group_code
                ,ma_sig_disp_order_model_series.display_order
                /*END*/
                -- サイネージ表示順序（機種群別）から取得
                /*IF groupSummaryKind == "02"*/
                COALESCE(RTRIM(mst_sig_disp_order_model_group.signage_id), '') AS signage_id
                ,COALESCE(RTRIM(mst_sig_disp_order_model_group.vtext_info1), '') AS model_group_code
                ,mst_sig_disp_order_model_group.display_order
                /*END*/
              FROM
                -- サイネージ表示順序（シリーズ別）から取得
                /*IF groupSummaryKind == "01"*/
                ma_sig_disp_order_model_series
                /*END*/
                -- サイネージ表示順序（機種群別）から取得
                /*IF groupSummaryKind == "02"*/
                mst_sig_disp_order_model_group
                /*END*/
            ) AS dog
          WHERE
            dog.signage_id <> ''
            AND
            dog.model_group_code <> ''
        ) AS disp_order_g
        ON
          m.model_group_code = disp_order_g.model_group_code
          AND
          disp_order_g.signage_id = /*signage_id*/''
      INNER JOIN
        (
          SELECT
            COALESCE(RTRIM(signage_id), '') AS signage_id
            ,COALESCE(RTRIM(plant_cd), '') AS plant_code
            ,display_order
          FROM
            ma_sig_disp_order_plant
        ) AS disp_order_p
        ON
          tbl_date_temp.plant_code = disp_order_p.plant_code
          AND
          disp_order_g.signage_id = disp_order_p.signage_id
    ) as tbl_date
    -- 指定期間の日付と結合(工場コード、製品グループ名、データ日付が一致)
    -- ※指定期間の日付とデータ日付が一致しない場合、nullで渡す必要があるため、外部結合とする
    LEFT JOIN
    (
      -- [サイネージ用]製品生産計画実績(日別)から計画(当日)台数、実績(当日)台数の集計値を取得
      -- 工場コード、製品グループ名、データ日付でサマリーして、台数を集計
      -- ※計画(当日)台数、実績(当日)台数以外は、結合時の条件として使用
      SELECT
        m.plant_code AS plant_code
        ,m.model_group_code AS model_group_code
        ,m.data_date AS data_date
        ,sum(m.plan_num) AS sum_plan_num
        ,sum(m.actual_num) AS sum_actual_num
      FROM
          (
            SELECT
              COALESCE(RTRIM(ds_product_mng_yearly.plant_cd), '') AS plant_code
              /*IF groupSummaryKind == "01"*/
              ,COALESCE(RTRIM(ds_product_mng_yearly.vtext_info2), '') AS model_group_code
              /*END*/
              /*IF groupSummaryKind == "02"*/
              ,COALESCE(RTRIM(ds_product_mng_yearly.vtext_info1), '') AS model_group_code
              /*END*/
              ,data_date
              ,plan_num
              ,actual_num
            FROM
              ds_product_mng_yearly
          ) AS m
      WHERE
        m.plant_code <> ''
      GROUP BY
        m.plant_code
        ,m.model_group_code
        ,m.data_date
    ) as tbl_sum
  ON
    tbl_date.plant_code = tbl_sum.plant_code
    AND
    tbl_date.model_group_code = tbl_sum.model_group_code
    AND
    tbl_date.date_series = tbl_sum.data_date
ORDER BY
  tbl_date.plant_display_order
  ,tbl_date.model_group_display_order
  ,tbl_date.date_series
