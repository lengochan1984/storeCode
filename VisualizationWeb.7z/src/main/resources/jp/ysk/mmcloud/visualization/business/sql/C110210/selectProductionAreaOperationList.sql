        SELECT
            line_status_data.plant_cd,
            line_status_data.plant_nm AS plant_name,
            line_status_data.seizou_ln_cd,
            line_status_data.seizou_ln_nm AS seizou_line_name,
            line_status_data.ln_no,
            line_status_data.ln_id,
            line_status_data.sum_actual_num,
            line_status_data.sum_schedule_num,
            line_status_data.sum_plan_num,
            line_status_data.difference_actual_schedule,
            line_status_data.signal_icon
        FROM
        (
            SELECT
                master_data.plant_cd,                                                                            /** 工場 */
                master_data.plant_nm,                                                                            /** 工場名 */
                master_data.seizou_ln_cd,                                                                        /** 生産エリア名 */
                master_data.seizou_ln_nm,                                                                        /** 生産エリア */
                master_data.ln_no,
                master_data.ln_id,
                SUM(ag_line_work_current.actual_num) sum_actual_num,                                             /** 実績数 */
                SUM(ag_line_work_current.schedule_num) sum_schedule_num,                                         /** 予定数 */
                SUM(ag_line_work_current.plan_num) sum_plan_num,                                                 /** 計画数 */
            CASE WHEN
                    SUM(ag_line_work_current.actual_num) > -1 AND SUM(ag_line_work_current.schedule_num) > -1
                THEN
                    SUM(ag_line_work_current.actual_num) - SUM(ag_line_work_current.schedule_num)
                ELSE
                    NULL
                END AS difference_actual_schedule,                                                                 /** 差分 */
            CASE WHEN SUM(ag_line_work_current.schedule_num) <> 0
                THEN SUM(ag_line_work_current.actual_num) / SUM(ag_line_work_current.schedule_num) * 100
                ELSE
                     '0'
                END AS signal_icon /** 信号アイコン */
            FROM
            (
                SELECT
                    line_info.plant_cd,
                    ma_plant.plant_nm,
                    line_info.seizou_ln_cd,
                    line_info.seizou_ln_nm,
                    line_info.ln_no,
                    line_info.ln_id
                FROM
                (
                    SELECT
                        ma_seizou_line.plant_cd,
                        ma_seizou_line.seizou_ln_cd,
                        ma_seizou_line.seizou_ln_nm,
                        ma_line.ln_no,
                        ma_line.ln_id
                    FROM
                        ma_line                                              /** ラインマスタ */
                    INNER JOIN ma_process                                    /** 工程マスタ */
                        ON ma_line.process_id = ma_process.process_id
                    INNER JOIN
                        ma_seizou_line                                       /** 製造ラインマスタ */
                        ON ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id
                    WHERE
                           ma_seizou_line.plant_cd = /*comPlantCode*/
                        AND
                        ma_line.invalid_flag = 0
                        AND	(ma_line.ln_id) in
                                (
                                SELECT
                                    ln_id
                                FROM
                                    ma_station                               /** ステーションマスタ */
                        )
                ) line_info
                INNER JOIN
                    ma_plant                                                 /** プラントマスタ */
                    ON  ma_plant.invalid_flag = 0
                    AND	ma_plant.plant_cd = line_info.plant_cd
                INNER JOIN
                    ma_plant_mieruka                                         /** プラントマスタ(見える化専用) */
                    ON  ma_plant_mieruka.invalid_flag = 0
                    AND ma_plant_mieruka.plant_cd = ma_plant.plant_cd
            ) master_data
            LEFT OUTER JOIN
                ag_line_work_current                                         /** ライン予定/実績/計画(現状) */
                ON master_data.ln_id = ag_line_work_current.ln_id
            GROUP BY master_data.plant_cd, master_data.plant_nm, master_data.seizou_ln_cd, master_data.seizou_ln_nm, master_data.ln_no, master_data.ln_id
        ) line_status_data
ORDER BY
        /*IF fw0114SortKey == null*/
            line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC
        /*END*/
        /*IF fw0114SortKey == "plantName"*/
            /*IF fw0114SortOrder == "asc"*/
            line_status_data.plant_nm ASC,  line_status_data.seizou_ln_cd ASC
            /*END*/
            /*IF fw0114SortOrder == "desc"*/
            line_status_data.plant_nm DESC,  line_status_data.seizou_ln_cd ASC
            /*END*/
        /*END*/
        /*IF fw0114SortKey == "seizouLineName"*/
            /*IF fw0114SortOrder == "asc"*/
            line_status_data.seizou_ln_nm ASC, line_status_data.plant_cd ASC
            /*END*/
            /*IF fw0114SortOrder == "desc"*/
            line_status_data.seizou_ln_nm DESC, line_status_data.plant_cd ASC
            /*END*/
        /*END*/
        /*IF fw0114SortKey == "sumActualNum"*/
            /*IF fw0114SortOrder == "asc"*/
            line_status_data.sum_actual_num ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC
            /*END*/
            /*IF fw0114SortOrder == "desc"*/
            line_status_data.sum_actual_num DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC
            /*END*/
        /*END*/
        /*IF fw0114SortKey == "sumScheduleNum"*/
            /*IF fw0114SortOrder == "asc"*/
            line_status_data.sum_schedule_num ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC
            /*END*/
            /*IF fw0114SortOrder == "desc"*/
            line_status_data.sum_schedule_num DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC
            /*END*/
        /*END*/
        /*IF fw0114SortKey == "sumPlanNum"*/
            /*IF fw0114SortOrder == "asc"*/
            line_status_data.sum_plan_num ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC
            /*END*/
            /*IF fw0114SortOrder == "desc"*/
            line_status_data.sum_plan_num DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC
            /*END*/
        /*END*/
        /*IF fw0114SortKey == "differenceActualSchedule"*/
            /*IF fw0114SortOrder == "asc"*/
            line_status_data.difference_actual_schedule ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC
            /*END*/
            /*IF fw0114SortOrder == "desc"*/
            line_status_data.difference_actual_schedule DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC
            /*END*/
        /*END*/