select
    mst_user.sid,
    mst_user.id,
    mst_user.user_lastname,
    mst_user.user_firstname,
    ma_user.expiration_date,
    ma_user.belong_name,
    ma_user.plant_cd,
    mst_user.timezone_cd,
    mst_user.lang_cd,
    ma_user.role_cd,
    ma_role.role_nm
from
    mst_user
left outer join
    ma_user
on
    mst_user.sid = ma_user.user_sid
INNER JOIN
    ma_role ON ma_role.role_cd = ma_user.role_cd
where
    mst_user.sid = ?

