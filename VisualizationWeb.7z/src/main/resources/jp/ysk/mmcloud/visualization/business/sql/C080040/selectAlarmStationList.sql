SELECT
  ma_station.plant_cd as plant_code,
  ma_station.ln_no as line_no,
  RTRIM(ma_station.st_no) as station_no,
  ma_equip_cd.equip_cd_nm as station_name_jp,
  ma_equip_cd.equip_cd_nm as station_name_en,
  ma_equip_cd.equip_cd_nm as station_name_zh,
  ma_equip_alm_cd.alm_msg as alarm_mode,
  CASE tr_equip_sts.sts_cd
    WHEN 1   THEN 'S101'
    WHEN 2   THEN 'S102'
    WHEN 31  THEN 'S201'
    WHEN 20  THEN 'S202'
    WHEN 51  THEN 'S203'
    WHEN 52  THEN 'S204'
    WHEN 32  THEN 'S205'
    ELSE 'S999'
  END station_status
FROM
  ma_station
INNER JOIN
  ma_equip
ON
  ma_equip.plant_cd = ma_station.plant_cd
AND
  ma_equip.st_id = ma_station.st_id
INNER JOIN
  tr_equip_sts
ON
  tr_equip_sts.plant_cd = ma_equip.plant_cd
AND
  tr_equip_sts.main_res_no = ma_equip.main_res_no
INNER JOIN
  ma_equip_cd
ON
  ma_equip_cd.equip_cd = ma_equip.equip_cd
LEFT OUTER JOIN
  ma_equip_alm_cd
ON
  ma_equip_alm_cd.alm_cd = tr_equip_sts.alm_cd
AND
  ma_equip_alm_cd.equip_cd = ma_equip.equip_cd
WHERE
  ma_station.plant_cd = /*plantCode*/''
AND
  ma_station.ln_no = /*lineNo*/''
AND
  tr_equip_sts.sts_cd in (20,51)
ORDER BY station_no asc