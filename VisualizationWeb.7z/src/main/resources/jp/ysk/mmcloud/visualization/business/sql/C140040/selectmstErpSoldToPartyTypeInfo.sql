select jcskbn_name,
        jcskbn
from    mst_erp_sold_to_party_type
 where  invalid_flag = 0
    and jcskbn <> 'X '
 order by jcskbn
