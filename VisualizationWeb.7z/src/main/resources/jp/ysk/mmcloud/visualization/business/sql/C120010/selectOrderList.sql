SELECT
    ssz.sasizu_no,
    ssz.sub_no,
    ssz.katasiki,
    ssz.order_no,
    ssz.status,
    CAST(to_timestamp(ssz.sagyo_sta_bi, 'YYYYMMDD') AS timestamp) AS sagyo_sta_bi,
    CAST(to_timestamp(ssz.kan_yotei_bi, 'YYYYMMDD') AS timestamp) AS kan_yotei_bi,
-- ManHC Update begin
    MIN(tsp.start_date) AS plan_start_date,
    MAX(tsp.end_date) AS plan_end_date,
-- ManHC Update end
    ssz.start_date AS actual_start_date,
    ssz.end_date AS actual_end_date,
    ssz.ln_nm,
    ssz.sagyo_seq,
    ssz.seisan_jyotai,
    ssz.line_jyotai,
    ssz.line_status,
    ssz.start_time,
    ssz.end_time,
-- ManHC Add begin
    CASE
        WHEN ssz.start_date IS NOT null AND ssz.end_date IS NOT null THEN '完了'
        WHEN tsp.station_no IS null THEN null
        WHEN (NOW() > MIN(tsp.start_date)) OR (NOW() > MAX(tsp.end_date)) THEN '遅延'
        ELSE '計画通り'
    END as shindo
-- ManHC Add end
FROM
(
    SELECT
        tsi.sasizu_no,
        tllmin.sub_no,
        tsi.katasiki,
        tsi.order_no,
        sn.name1 AS status,
        tsi.sagyo_sta_bi,
        tsi.kan_yotei_bi,
        tpl.start_date,
        tpl.end_date,
-- ManHC Add begin
        tsi.werks as plan_cd,
        ml.ln_no,
-- ManHC Add end
        ml.ln_nm,
        get_sagyo_seq_name(tllmax.sagyo_seq, /*loginUserLangCd*/'') AS sagyo_seq,
        tpl.seisan_jyotai,
        sn2.name1 AS line_status,
        tllmax.sagyo_keka AS line_jyotai,
        tllmin.start_time,
        tllmax.end_time
    FROM
        tr_sasizu_info tsi

    INNER JOIN
        tr_sasizu_jsk tsj
    ON
        tsi.sasizu_no = tsj.sasizu_no

    INNER JOIN
    --ライントレース MIN
    (
        SELECT
            sub0.*
        FROM
            tr_line_work_jsk sub0
        WHERE
            EXISTS(
                SELECT
                    1
                FROM
                    tr_line_work_jsk sub1
                WHERE
                        sub0.sasizu_no  = sub1.sasizu_no
                    AND sub0.sub_no     = sub1.sub_no
                    AND sub0.sagyo_seq  = sub1.sagyo_seq
                    AND sub0.ln_id      = sub1.ln_id
                GROUP BY
                    sub1.sasizu_no,
                    sub1.sub_no,
                    sub1.sagyo_seq,
                    sub1.ln_id
                HAVING
                    MIN(sub1.repair_kaisu) = sub0.repair_kaisu
            )
    ) tllmin
    ON
            tsi.sasizu_no   = tllmin.sasizu_no
        AND tsi.werks       = /*comPlantCode*/''

    --ライントレース MAX
    INNER JOIN
    (
        SELECT
            sub0.*
        FROM
            tr_line_work_jsk sub0
        WHERE
            EXISTS(
                SELECT
                    1
                FROM
                    tr_line_work_jsk sub1
                WHERE
                        sub0.sasizu_no  = sub1.sasizu_no
                    AND sub0.sub_no     = sub1.sub_no
                    AND sub0.sagyo_seq  = sub1.sagyo_seq
                    AND sub0.ln_id      = sub1.ln_id
                GROUP BY
                    sub1.sasizu_no,
                    sub1.sub_no,
                    sub1.sagyo_seq,
                    sub1.ln_id
                HAVING
                    MAX(sub1.repair_kaisu) = sub0.repair_kaisu
            )
    ) tllmax
    ON
            tllmax.sasizu_no    = tllmin.sasizu_no
        AND tllmax.sub_no       = tllmin.sub_no
        AND tllmax.sagyo_seq    = tllmin.sagyo_seq
        AND tllmax.ln_id        = tllmin.ln_id

    INNER JOIN
        ma_line ml
    ON
        tllmax.ln_id    = ml.ln_id

    INNER JOIN
        ma_process mp
    ON
        ml.process_id   = mp.process_id

    LEFT OUTER JOIN
        tr_product_trc tpl
    ON
            tllmax.sasizu_no    = tpl.sasizu_no
        AND tllmax.sub_no       = tpl.sub_no
        AND tllmax.sagyo_seq    = tpl.sagyo_seq

    LEFT OUTER JOIN
        sys_name sn
    ON
            sn.name_type = /*nameType*/''
        AND sn.item_cd = to_char(tpl.seisan_jyotai, 'FM999')
        AND sn.lang_cd = /*loginUserLangCd*/''

    LEFT OUTER JOIN
        sys_name sn2
    ON
            sn2.name_type = /*nameType*/''
        AND sn2.item_cd = to_char(tllmax.sagyo_keka, 'FM999')
        AND sn2.lang_cd = /*loginUserLangCd*/''

    WHERE
            tllmax.plant_cd     = /*comPlantCode*/''
        AND mp.seizou_ln_id     = /*comSeizouLnId*/0
        /*IF comProcessId != null*/
        AND mp.process_id       = /*comProcessId*/
        /*END*/
        /*IF comLnId != null*/
        AND tllmax.ln_id        = /*comLnId*/
        /*END*/
        AND (
                (       tllmax.end_time >= /*comDataDateFrom*/
                    AND tllmax.end_time <= /*comDataDateTo*/
                )
            OR  (       tllmax.end_time IS NULL
                    AND tsj.seisan_jyotai   >=  0
                    AND tsj.seisan_jyotai   <   90
                )
        )
        /*IF comSearchWord != null*/
        AND (
                tllmax.sasizu_no LIKE /*comSearchWord*/''
            OR  to_char(tllmax.sub_no, 'FM999') LIKE /*comSearchWord*/''
            OR  tsi.katasiki LIKE /*comSearchWord*/''
            OR  tsi.order_no LIKE /*comSearchWord*/''
        )
        /*END*/

    UNION ALL

    SELECT
        tsi.sasizu_no,
        tbtlmin.sub_no,
        tsi.katasiki,
        tsi.order_no,
        sn.name1 AS status,
        tsi.sagyo_sta_bi,
        tsi.kan_yotei_bi,
        tpl.start_date,
        tpl.end_date,
-- ManHC Add begin
        tsi.werks as plan_cd,
        ml2.ln_no,
-- ManHC Add end
        ml1.ln_nm || '～' || ml2.ln_nm AS ln_nm,
        get_sagyo_seq_name(tbtlmax.n_sagyo_seq, /*loginUserLangCd*/'') AS sagyo_seq,
        tpl.seisan_jyotai,
        sn2.name1 AS line_status,
        tbtlmax.sagyo_keka AS line_jyotai,
        tbtlmin.end_time AS start_time,
        tbtlmax.start_time AS end_time
    FROM
        tr_sasizu_info tsi

    INNER JOIN
        tr_sasizu_jsk tsj
    ON
        tsi.sasizu_no = tsj.sasizu_no

    INNER JOIN
    --ライン間トレース MIN
    (
        SELECT
            sub0.*
        FROM
            tr_line_tm_info sub0
        WHERE
            EXISTS(
                SELECT
                    1
                FROM
                    tr_line_tm_info sub1
                WHERE
                        sub0.sasizu_no  = sub1.sasizu_no
                    AND sub0.sub_no     = sub1.sub_no
                    AND sub0.sagyo_seq  = sub1.sagyo_seq
                    AND sub0.ln_id      = sub1.ln_id
                GROUP BY
                    sub1.sasizu_no,
                    sub1.sub_no,
                    sub1.sagyo_seq,
                    sub1.ln_id
                HAVING
                    MIN(sub1.repair_kaisu) = sub0.repair_kaisu
            )
    ) tbtlmin
    ON
            tsi.sasizu_no   = tbtlmin.sasizu_no
        AND tsi.werks       = /*comPlantCode*/''

    --ライン間トレース MAX
    INNER JOIN
    (
        SELECT
            sub0.*
        FROM
            tr_line_tm_info sub0
        WHERE
            EXISTS(
                SELECT
                    1
                FROM
                    tr_line_tm_info sub1
                WHERE
                        sub0.sasizu_no  = sub1.sasizu_no
                    AND sub0.sub_no     = sub1.sub_no
                    AND sub0.sagyo_seq  = sub1.sagyo_seq
                    AND sub0.ln_id      = sub1.ln_id
                GROUP BY
                    sub1.sasizu_no,
                    sub1.sub_no,
                    sub1.sagyo_seq,
                    sub1.ln_id
                HAVING
                    MAX(sub1.repair_kaisu) = sub0.repair_kaisu
            )
    ) tbtlmax
    ON
            tbtlmax.sasizu_no   = tbtlmin.sasizu_no
        AND tbtlmax.sub_no      = tbtlmin.sub_no
        AND tbtlmax.sagyo_seq   = tbtlmin.sagyo_seq
        AND tbtlmax.ln_id       = tbtlmin.ln_id

    INNER JOIN
        ma_line ml1
    ON
        tbtlmax.ln_id   = ml1.ln_id

    INNER JOIN
        ma_line ml2
    ON
        tbtlmax.n_ln_id = ml2.ln_id

    INNER JOIN
        ma_process mp2
    ON
        ml2.process_id  = mp2.process_id

    INNER JOIN
        ma_seizou_line ms2
    ON
        mp2.seizou_ln_id    = ms2.seizou_ln_id

    LEFT OUTER JOIN
        tr_product_trc tpl
    ON
            tbtlmax.sasizu_no   = tpl.sasizu_no
        AND tbtlmax.sub_no      = tpl.sub_no
        AND tbtlmax.sagyo_seq   = tpl.sagyo_seq

    LEFT OUTER JOIN
        sys_name sn
    ON
            sn.name_type = /*nameType*/''
        AND sn.item_cd = to_char(tpl.seisan_jyotai, 'FM999')
        AND sn.lang_cd = /*loginUserLangCd*/''

    LEFT OUTER JOIN
        sys_name sn2
    ON
            sn2.name_type = /*nameType*/''
        AND sn2.item_cd = to_char(tbtlmax.sagyo_keka, 'FM999')
        AND sn2.lang_cd = /*loginUserLangCd*/''

    WHERE
            tbtlmax.plant_cd    = /*comPlantCode*/''
        AND ms2.seizou_ln_id    = /*comSeizouLnId*/0
        /*IF comProcessId != null*/
        AND mp2.process_id      = /*comProcessId*/
        /*END*/
        /*IF comLnId != null*/
        AND tbtlmax.n_ln_id     = /*comLnId*/
        /*END*/
        AND tbtlmax.start_time  IS NULL
        AND tsj.seisan_jyotai   >=  0
        AND tsj.seisan_jyotai   <   90
        AND (
                tbtlmax.sagyo_seq is null
            OR  tbtlmax.sagyo_seq = '0'
        )
         /*IF comSearchWord != null*/
        AND (
                tbtlmax.sasizu_no LIKE /*comSearchWord*/''
            OR  to_char(tbtlmax.sub_no, 'FM999') LIKE /*comSearchWord*/''
            OR  tsi.katasiki LIKE /*comSearchWord*/''
            OR  tsi.order_no LIKE /*comSearchWord*/''
        )
        /*END*/
) AS ssz
-- ManHC Add begin
LEFT OUTER JOIN
    tbl_seihin_plan tsp
ON
        tsp.sasizu_no = ssz.sasizu_no
    AND tsp.sub_no = ssz.sub_no
    AND tsp.plant_code = ssz.plan_cd
    AND tsp.line_no = ssz.ln_no
-- ManHC Add end
GROUP BY
    ssz.sasizu_no,
    ssz.sub_no,
    ssz.katasiki,
    ssz.order_no,
    ssz.status,
    ssz.sagyo_sta_bi,
    ssz.kan_yotei_bi,
    ssz.start_date,
    ssz.end_date,
    ssz.ln_nm,
    ssz.sagyo_seq,
    ssz.seisan_jyotai,
    ssz.line_jyotai,
    ssz.line_status,
    ssz.start_time,
    ssz.end_time,
-- ManHC Add begin
    tsp.station_no
-- ManHC Add end
ORDER BY
/*IF fw0114SortKey == null*/
    ssz.start_date DESC
/*END*/

/*IF fw0114SortKey == 'sasizuNo'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.sasizu_no ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.sasizu_no DESC, ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'subNo'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.sub_no ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.sub_no DESC, ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'katasiki'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.katasiki ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.katasiki DESC, ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'orderNo'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.order_no ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.order_no DESC, ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'status'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.seisan_jyotai ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.seisan_jyotai DESC, ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'sagyoStaBi'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.sagyo_sta_bi ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.sagyo_sta_bi DESC, ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'kanYoteiBi'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.kan_yotei_bi ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.kan_yotei_bi DESC, ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'actualStartDate'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.start_date ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'planStartDate'*/
    /*IF fw0114SortOrder == "asc"*/
    plan_start_date ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    plan_start_date DESC, ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'planEndDate'*/
    /*IF fw0114SortOrder == "asc"*/
    plan_end_date ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    plan_end_date DESC, ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'planTime'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.start_date DESC
    /*END*/
/*END*/


/*IF fw0114SortKey == 'actualTime'*/
    /*IF fw0114SortOrder == "asc"*/
    (ssz.end_date - ssz.start_date) ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    (ssz.end_date - ssz.start_date) DESC, ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'lineName'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.ln_nm ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.ln_nm DESC, ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'sagyoSeq'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.sagyo_seq ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.sagyo_seq DESC, ssz.start_date DESC
    /*END*/
/*END*/
-- ManHC add begin
/*IF fw0114SortKey == 'shindo'*/
    /*IF fw0114SortOrder == "asc"*/
    shindo ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    shindo DESC, ssz.start_date DESC
    /*END*/
/*END*/
-- ManHC add end
/*IF fw0114SortKey == 'lineStatus'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.line_jyotai ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.line_jyotai DESC, ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'actualEndDate'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.end_date ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.end_date DESC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'startTime'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.start_time ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.start_time DESC, ssz.start_date DESC
    /*END*/
/*END*/
/*IF fw0114SortKey == 'endTime'*/
    /*IF fw0114SortOrder == "asc"*/
    ssz.end_time ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ssz.end_time DESC, ssz.start_date DESC
    /*END*/
/*END*/
/*IF fw0114SortKey == 'lineActualTime'*/
    /*IF fw0114SortOrder == "asc"*/
    (ssz.start_time - ssz.end_time) ASC, ssz.start_date DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    (ssz.start_time - ssz.end_time) DESC, ssz.start_date DESC
    /*END*/
/*END*/

/*IF fw0114CsvMaxSize != null*/
LIMIT /*fw0114CsvMaxSize*/
/*END*/
