SELECT
    tlsl.event_date,
    tlsl.ln_status,
    sn.name2 as status_color
FROM
    tr_line_sts_log tlsl
LEFT JOIN sys_name sn
    ON sn.name_type = /*namType*/'line_status'
    AND CAST(sn.item_cd AS NUMERIC) = tlsl.ln_status
    AND sn.lang_cd = /*langCD*/'JPN'
WHERE
    tlsl.ln_id = /*lineId*/1
AND tlsl.event_date BETWEEN /*lineStartTime*/ AND /*lineFinishTime*/
ORDER BY
    tlsl.event_date ASC