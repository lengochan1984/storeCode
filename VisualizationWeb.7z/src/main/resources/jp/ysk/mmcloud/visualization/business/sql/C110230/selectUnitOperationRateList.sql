SELECT
    msl.plant_cd,
    ms.st_no,
    ms.st_id,
    COALESCE(ms.st_nm, ms.st_no) as unit_name,
    tuw.st_start_time,
    tuw.st_finish_time
FROM
    ma_station ms

INNER JOIN ma_equip me
    ON me.st_id = ms.st_id

INNER JOIN ma_line ml
    ON ml.ln_id = ms.ln_id

INNER JOIN ma_process mpr
    ON mpr.process_id = ml.process_id

INNER JOIN ma_seizou_line msl
    ON msl.seizou_ln_id = mpr.seizou_ln_id


INNER JOIN tr_unit_work tuw
    ON tuw.st_id = ms.st_id
WHERE
    msl.plant_cd = /*comPlantCode*/'D0'
AND	msl.seizou_ln_id = /*comSeizouLnId*/1
AND	mpr.process_id = /*comProcessId*/1
AND	ms.ln_id = /*comLnId*/1

AND ms.invalid_flag = 0
AND me.invalid_flag = 0
AND ml.invalid_flag = 0
AND mpr.invalid_flag = 0
AND msl.invalid_flag = 0
AND tuw.st_start_time > NOW() - interval '1 day'
AND tuw.st_finish_time < NOW() + interval '1 day'
ORDER BY ms.st_no