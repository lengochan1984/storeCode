SELECT
    ma_plant.plant_s_nm AS plant_s_name,
	ma_line.ln_nm AS ln_nm,
    to_char(tr_seihin_plan_manual_setting.data_date,'YYYY/MM/DD') AS data_date,
    tr_seihin_plan_manual_setting.plan_num AS plan_num,
    tr_seihin_plan_manual_setting.last_line_flag AS last_line_flag,
    tr_seihin_plan_manual_setting.vtext_info1 AS vtext_info1,
    ma_line.ln_id AS ln_id,
    tr_seihin_plan_manual_setting.sid AS sid,
    to_char(tr_seihin_plan_manual_setting.upd_tim,'YYYY/MM/DD') AS upd_tim,
    ma_user.user_id AS upd_user_lastname,
    ma_user.user_name AS upd_user_firstname,
    tr_seihin_plan_manual_setting.display_order AS display_order
FROM
    tr_seihin_plan_manual_setting
INNER JOIN
    ma_line
ON
    ma_line.ln_id = tr_seihin_plan_manual_setting.ln_id
INNER JOIN ma_process
	ON ma_line.process_id = ma_process.process_id
INNER JOIN ma_seizou_line
	ON ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id
INNER JOIN
    ma_plant
ON
    ma_plant.plant_cd = ma_seizou_line.plant_cd
LEFT JOIN
    ma_user
ON
    ma_user.user_sid = tr_seihin_plan_manual_setting.upd_user_sid
WHERE
    ma_plant.plant_cd = /*plantCd*/
AND
    tr_seihin_plan_manual_setting.data_date = /*dataDate*/
	/*IF seizouLnId != null*/
AND
    ma_seizou_line.seizou_ln_id = cast(/*seizouLnId*/ as numeric)
	/*END*/
/*IF lineIdList != null*/
AND
    cast(tr_seihin_plan_manual_setting.ln_id as character) in /*lineIdList*/('123')
/*END*/
/*IF lnId != null*/
AND
    cast(ma_line.ln_id as varchar) = /*lnId*/
/*END*/
ORDER BY
                    ma_plant.plant_cd,
                    ma_seizou_line.seizou_ln_id,
                    tr_seihin_plan_manual_setting.display_order,
                    tr_seihin_plan_manual_setting.vtext_info1 ASC
