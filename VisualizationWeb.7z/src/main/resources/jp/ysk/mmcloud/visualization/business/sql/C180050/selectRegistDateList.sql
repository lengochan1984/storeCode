SELECT
    DISTINCT data_date
FROM
    tr_seihin_plan_manual_setting
WHERE
    tr_seihin_plan_manual_setting.ln_id = cast(/*lnId*/ as numeric)
ORDER BY
    data_date DESC
