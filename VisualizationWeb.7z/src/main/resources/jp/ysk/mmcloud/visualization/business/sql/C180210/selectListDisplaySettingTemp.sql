SELECT
    ma_seizou_line.plant_cd,
    ma_plant.plant_s_nm,
    ma_seizou_line.seizou_ln_id,
    ma_seizou_line.seizou_ln_nm,
    ma_seizou_line.planning_system
FROM
    mmsf.ma_seizou_line
INNER JOIN
    mmsf.ma_plant
ON
    ma_seizou_line.plant_cd = ma_plant.plant_cd
WHERE
    ma_seizou_line.plant_cd = /*comPlantCode*/'a'
ORDER BY
    ma_seizou_line.seizou_ln_nm
