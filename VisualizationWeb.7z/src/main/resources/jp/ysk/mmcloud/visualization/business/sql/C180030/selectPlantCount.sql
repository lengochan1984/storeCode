SELECT COUNT (*)
FROM ma_plant_mieruka
WHERE ma_plant_mieruka.invalid_flag = 0
