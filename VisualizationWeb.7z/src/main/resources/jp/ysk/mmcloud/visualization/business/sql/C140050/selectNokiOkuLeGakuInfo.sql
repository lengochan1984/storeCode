
select
   nengetu,
   youkyu_late,
   todokebi_late,
   hyoujyun_late
from
(
select   max(erp.nengetu) as nengetu,
          sum(erp.youkyu_late) as youkyu_late,
          sum(erp.todokebi_late) as todokebi_late,
          sum(erp.hyoujyun_late) as hyoujyun_late

   from tbl_erp_due_date_rating_monthly erp

   where erp.plant_code = /*comPlantCode*/

      /*IF categoryOne != null*/
      AND erp.kishu_ctgr01 = /*categoryOne*/
      /*END*/

      /*IF categoryTwo != null*/
      AND erp.kishu_ctgr02 = /*categoryTwo*/
      /*END*/

      /*IF searchOrderClient != null*/
      AND erp.jcskbn = /*searchOrderClient*/
      /*END*/

      AND TO_CHAR(erp.nengetu, 'yyyymm') BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/

      group by TO_CHAR(erp.nengetu, 'yyyymm')
 ) tem
   order by tem.nengetu asc