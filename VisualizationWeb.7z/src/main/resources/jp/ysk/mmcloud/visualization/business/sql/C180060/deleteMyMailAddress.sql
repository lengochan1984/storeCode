delete
from rel_device_alarm
LEFT JOIN mst_alarm_send_address
ON mst_alarm_send_address.alarm_sid = rel_device_alarm.alarm_sid
and mst_alarm_send_address.device_sid = rel_device_alarm.device_sid
WHERE mail_address_sid = /*userSid*/