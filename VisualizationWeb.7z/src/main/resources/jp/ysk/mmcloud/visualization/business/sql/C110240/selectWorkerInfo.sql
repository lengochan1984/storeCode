SELECT
    t0.syain_no,
    t0.work_sta_time,
    t0.work_end_time,
    t0.hantei,
    t0.sagyo_jyotai,
    t3.user_name
FROM
    tr_st_work_jsk  t0
INNER JOIN
    tr_sasizu_jsk   t1
ON
    t0.sasizu_no    = t1.sasizu_no
INNER JOIN
    ma_station   t2
ON
    t2.st_id = t0.st_id
    AND t2.invalid_flag = 0
INNER JOIN
    ma_user t3
ON
    t0.plant_cd = t3.plant_cd
    AND t0.syain_no = t3.syain_no
    AND t3.invalid_flag = 0
WHERE
        t0.created_on >= /*weekDatetime*/''
    /*IF comStId != null*/
    AND t0.st_id = /*comStId*/
    /*END*/
    /*IF comSeizouLnId != null*/
    AND EXISTS(
            SELECT
                ma_seizou_line.plant_cd,
                ma_line.ln_id,
                ma_seizou_line.seizou_ln_id
            FROM
                ma_line
            INNER JOIN
                ma_process
            ON
                ma_line.process_id = ma_process.process_id
            INNER JOIN
                ma_seizou_line
            ON
                ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id
            WHERE
                    ma_seizou_line.seizou_ln_id = /*comSeizouLnId*/
                /*IF comLnId != null*/
                AND ma_line.ln_id               = /*comLnId*/
                /*END*/
                /*IF comProcessId != null*/
                AND ma_process.process_id       = /*comProcessId*/
                /*END*/
                AND ma_seizou_line.plant_cd     = t0.plant_cd
                AND ma_line.ln_id               = t2.ln_id
    )
     /*END*/
    /*IF comStId != null*/
    AND EXISTS(
            SELECT
                ms.st_no
            FROM
                ma_station ms
            WHERE
                    ms.ln_id        = /*comLnId*/
                AND ms.st_id        = /*comStId*/
                AND ms.st_id        = t0.st_id
    )
    /*END*/
    AND (
            (
                    t0.work_end_time IS NULL
                AND t1.seisan_jyotai >= 0
                AND t1.seisan_jyotai <  90
            )
    )

ORDER BY

/*IF fw0114SortKey == null*/
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
/*END*/

/*IF fw0114SortKey == 'syainNo'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.syain_no ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.syain_no DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'workStaTime'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.work_sta_time ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.work_sta_time DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'workEndTime'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.work_end_time ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.work_end_time DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'hantei'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.hantei ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.hantei DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'sagyoJyotai'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.sagyo_jyotai ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.sagyo_jyotai DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'userName'*/
    /*IF fw0114SortOrder == "asc"*/
    t3.user_name ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.sagyoku_last_st DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/