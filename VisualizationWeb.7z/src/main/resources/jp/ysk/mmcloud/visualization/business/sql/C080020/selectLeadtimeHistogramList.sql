SELECT
  tbl_date.plant_code
  ,tbl_date.model_group_code
  ,tbl_date.date_series
  ,tbl_sum.lead_time AS actual_num
FROM
  (
    SELECT
      tbl_date_temp.plant_code
      ,disp_order_p.display_order AS plant_display_order
      ,h.model_group_code
      ,disp_order_g.display_order AS model_group_display_order
      ,tbl_date_temp.leadtime_start_date
      ,tbl_date_temp.leadtime_end_date
      ,tbl_date_temp.date_series
    FROM
      (
        SELECT
          COALESCE(RTRIM(ma_hinmoku.werks), '') AS plant_code
          ,COALESCE(RTRIM(ma_hinmoku.vtext_info2), '') AS model_group_code
        FROM
          ma_hinmoku
        GROUP BY
          plant_code
          ,model_group_code
      ) AS h
      INNER JOIN
        (
          SELECT
            date_term.plant_code
            ,date_term.leadtime_start_date
            ,date_term.leadtime_end_date
            ,gs.date_series
          FROM
            (
              SELECT
                COALESCE(RTRIM(ma_plant.plant_cd), '') AS plant_code
                ,(
                  date_trunc(
                    'days',
                    CAST(current_timestamp AS TIMESTAMP WITHOUT time zone) - CAST('1 months' AS INTERVAL) + CAST('1 days' AS INTERVAL)
                  )
                ) AS leadtime_start_date
                ,(
                  date_trunc(
                    'days',
                    CAST(current_timestamp AS TIMESTAMP WITHOUT time zone)
                  )
                ) AS leadtime_end_date
              FROM
                ma_plant
              INNER JOIN
                ma_plant_mieruka
              ON
                    ma_plant_mieruka.invalid_flag = 0
                AND ma_plant_mieruka.plant_cd = ma_plant.plant_cd
              WHERE
                    ma_plant.invalid_flag = 0
                AND ma_plant.plant_cd <> ''
            ) AS date_term,
            generate_series(
              date_term.leadtime_start_date,
              date_term.leadtime_end_date,
              '1 days'
            ) as gs(date_series)
          ) AS tbl_date_temp
        ON
          tbl_date_temp.plant_code = h.plant_code
      INNER JOIN
        (
          SELECT
            *
          FROM
            (
              SELECT
                COALESCE(RTRIM(ma_sig_disp_order_model_series.signage_id), '') AS signage_id
                ,COALESCE(RTRIM(ma_sig_disp_order_model_series.vtext_info2), '') AS model_group_code
                ,ma_sig_disp_order_model_series.display_order
              FROM
                ma_sig_disp_order_model_series
            ) AS dog
          WHERE
            dog.signage_id <> ''
            AND
            dog.model_group_code <> ''
        ) AS disp_order_g
        ON
          h.model_group_code = disp_order_g.model_group_code
          AND
          disp_order_g.signage_id = /*signage_id*/''
      INNER JOIN
        (
          SELECT
            COALESCE(RTRIM(signage_id), '') AS signage_id
            ,COALESCE(RTRIM(plant_cd), '') AS plant_code
            ,display_order
          FROM
            ma_sig_disp_order_plant
        ) AS disp_order_p
        ON
          tbl_date_temp.plant_code = disp_order_p.plant_code
          AND
          disp_order_g.signage_id = disp_order_p.signage_id
  ) as tbl_date
  LEFT JOIN
    (
      SELECT
        m.plant_code AS plant_code
        ,h.model_group_code AS model_group_code
        ,m.data_date AS data_date
        ,sum(m.lead_time) AS lead_time
      FROM
        (
          SELECT
            COALESCE(RTRIM(plant_cd), '') AS plant_code
            ,COALESCE(RTRIM(hinmoku_code), '') AS hinmoku_code
            ,data_date
            ,lead_time
          FROM
          ds_lead_time_hinmoku_daily
        ) AS m
        LEFT JOIN
          (
            SELECT
              COALESCE(RTRIM(ma_hinmoku.plant_cd), '') AS plant_code
              ,COALESCE(RTRIM(ma_hinmoku.hinmoku_code), '') AS hinmoku_code
              ,COALESCE(RTRIM(ma_hinmoku.vtext_info2), '') AS model_group_code
            FROM
              ma_hinmoku
          ) AS h
          ON
            m.plant_code = h.plant_code
            AND
            m.hinmoku_code = h.hinmoku_code
      WHERE
        m.plant_code <> ''
        AND
        h.model_group_code <> ''
      GROUP BY
        m.plant_code
        ,h.model_group_code
        ,m.data_date
    ) as tbl_sum
    ON
      tbl_date.plant_code = tbl_sum.plant_code
      AND
      tbl_date.model_group_code = tbl_sum.model_group_code
      AND
      tbl_date.date_series = tbl_sum.data_date
ORDER BY
  tbl_date.plant_display_order
  ,tbl_date.model_group_display_order
  ,tbl_date.date_series
