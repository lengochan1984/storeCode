DELETE
FROM
    ma_map_item
WHERE
    ma_map_item.plant_cd = /*plantCd*/
    AND ma_map_item.map_cd = /*mapCd*/