/*---------------------　ラインプルダウン未選択時 --------*/
WITH keyTable AS (
    SELECT
        tblA.werks AS plant_cd,			  	--工場コード
        tblA.sasizu_no,				--指図番号
        tblA.sub_no,				--副番号
        tblA.end_date	--製品の生産終了実績日時
    FROM
    (
        SELECT
            A0.werks,			--工場コード
            A1.sasizu_no,			--指図番号
            A1.sub_no,				--副番号
            A1.end_date	--製品の生産終了実績日時
        FROM
            tr_sasizu_info A0
        INNER JOIN
            tr_product_trc A1
        ON
                A0.sasizu_no = A1.sasizu_no
            AND	A0.werks = /*comPlantCode*/
        INNER JOIN
            ma_hinmoku H
        ON
                A1.buhin_cd = H.matnr
            AND	A0.werks = H.werks
            /*IF buhin_cd != null*/
            AND	H.matnr = /*buhin_cd*/
            /*END*/
            /*IF kishugun_name != null*/
            AND	H.vtext_info1 = /*kishugun_name*/	--製品プルダウンで機種群名を選択時
            /*END*/
            /*IF series_name != null*/
            AND	H.vtext_info2 = /*series_name*/	--製品プルダウンでシリーズ名を選択時
            /*END*/
        WHERE
                A1.end_date >= /*comDataDateFrom*/
            AND	A1.end_date <= /*comDataDateTo*/
            AND	A1.end_date is not null
            AND	A1.seisan_jyotai = '90'	--生産状態
            AND	A1.hantei = 1			--合否判定
    ) tblA
)
--ヒストグラム
SELECT
    histo.lead_time,
    count(histo.sasizu)
FROM
(
    SELECT
        CASE
            WHEN sasizuLead.lead_time > 10 THEN 11
            WHEN sasizuLead.lead_time = 0 THEN 1
            ELSE sasizuLead.lead_time
        END AS lead_time,
        sasizuLead.sasizu
    FROM
    (
        SELECT
            lt.sasizu,	 --指図番号
            (TRUNC(sum(lt.lead_time) / 86400000)) + CASE WHEN sum(lt.lead_time) % 86400000 > 0 THEN 1 ELSE 0 END AS lead_time
        FROM
        (
            SELECT
                lt1.sasizu_no || to_char(lt1.sub_no,'0000000000') AS sasizu,	--指図番号+副番号
                lt1.lead_time				  --リードタイム
            FROM
                /*IF comDateType == 'jikanbetu'*/
                ag_line_lead_time_hourly lt1	--時間別テーブルは存在しないので、エラーとなる
                /*END*/
                /*IF comDateType == 'nitiji'*/
                ag_line_lead_time_daily lt1
                /*END*/
                /*IF comDateType == 'getuji'*/
                ag_line_lead_time_monthly lt1
                /*END*/
            INNER JOIN
                ma_line l1
            ON
                lt1.ln_no = l1.ln_no
                AND	l1.invalid_flag = 0
            INNER JOIN
                ma_process pc1
            ON
                l1.process_id = pc1.process_id
                AND	pc1.invalid_flag = 0

            INNER JOIN ma_seizou_line zl1
                ON zl1.seizou_ln_id = pc1.seizou_ln_id
                AND lt1.plant_cd = zl1.plant_cd
            ,keyTable key1
            WHERE
                    lt1.plant_cd = key1.plant_cd
                AND	lt1.sasizu_no = key1.sasizu_no
                AND	lt1.sub_no = key1.sub_no
                AND	zl1.seizou_ln_id = cast(/*comSeizouLnId*/ as numeric)
                AND	lt1.lead_time > -1
                /*IF comProcessId != null */
                AND	pc1.process_id = cast(/*comProcessId*/ as numeric)
                /*END*/
                /*IF comLnId != null */
                AND	lt1.ln_id = cast(/*comLnId*/ as numeric)
                /*END*/
            UNION
            --工程間リードタイム
            SELECT
                lt2.sasizu_no || to_char(lt2.sub_no,'0000000000') AS sasizu,	 --指図番号+副番号
                lt2.lead_time 	   --リードタイム
            FROM
                /*IF comDateType == 'jikanbetu'*/
                ag_line_tm_lead_time_hourly lt2	--時間別テーブルは存在しないので、エラーとなる
                /*END*/
                /*IF comDateType == 'nitiji'*/
                ag_line_tm_lead_time_daily lt2
                /*END*/
                /*IF comDateType == 'getuji'*/
                ag_line_tm_lead_time_monthly lt2
                /*END*/
            INNER JOIN
                ma_line l2
            ON
                lt2.ln_id = l2.ln_id
                AND	l2.invalid_flag = 0
            INNER JOIN
                ma_process pc2
            ON
                l2.process_id = pc2.process_id
                AND	pc2.invalid_flag = 0

            INNER JOIN ma_seizou_line zl2
                ON zl2.seizou_ln_id = pc2.seizou_ln_id
                AND lt2.plant_cd = zl2.plant_cd

            INNER JOIN
                ma_line l3
            ON
                lt2.n_ln_id = l3.ln_id
                AND	l3.invalid_flag = 0
            INNER JOIN
                ma_process pc3
            ON
                l3.process_id = pc3.process_id
                AND	pc3.invalid_flag = 0

            INNER JOIN ma_seizou_line zl3
                ON zl3.seizou_ln_id = pc3.seizou_ln_id
                AND lt2.plant_cd = zl3.plant_cd
            ,keyTable key2
            WHERE
                    lt2.plant_cd = key2.plant_cd
                AND	lt2.sasizu_no = key2.sasizu_no
                AND	lt2.sub_no = key2.sub_no
                AND	zl3.seizou_ln_id = cast(/*comSeizouLnId*/ as numeric)
                AND	lt2.lead_time > -1
                /*IF comProcessId != null */
                AND	pc3.process_id = cast(/*comProcessId*/ as numeric)
                /*END*/
                /*IF comLnId != null */
                AND	lt2.n_ln_id = cast(/*comLnId*/ as numeric)
                /*END*/
        ) lt
        GROUP BY
            lt.sasizu	--指図番号+副番号
    ) sasizuLead
) histo
GROUP BY
    histo.lead_time
ORDER BY
    histo.lead_time
