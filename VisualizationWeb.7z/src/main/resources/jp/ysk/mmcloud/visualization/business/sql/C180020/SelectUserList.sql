SELECT
    mst_user.sid,
    mst_user.id,
    mst_user.user_lastname,
    mst_user.user_firstname,
    COALESCE(mst_user.user_lastname_kana,'') AS user_lastname_kana,
    COALESCE(mst_user.user_firstname_kana,'') AS user_firstname_kana,
    ma_user.role_cd,
    ma_role.role_nm,
    ma_user.belong_name,
    ma_user.plant_cd,
    mst_user.timezone_cd,
    mst_user.lang_cd
FROM
    mst_user

INNER JOIN
    ma_user ON mst_user.sid = ma_user.user_sid

INNER JOIN
    ma_role ON ma_role.role_cd = ma_user.role_cd

/*BEGIN*/
WHERE
/*IF txtUserId != null*/
    AND mst_user.id LIKE /*txtUserId*/'S'
/*END*/
/*IF txtUserName != null*/
    AND COALESCE(mst_user.user_lastname,'') || ' ' || COALESCE(mst_user.user_firstname,'') LIKE /*txtUserName*/'S'
/*END*/
/*IF cond_UserAuth != null*/
    AND ma_user.expiration_date = /*cond_UserAuth*/'S'
/*END*/
/*IF cond_Belong != null*/
    AND ma_user.belong_name = /*cond_Belong*/
/*END*/
/*IF comPlantCode != null*/
    AND (
            ma_user.plant_cd = /*comPlantCode*/
        OR	ma_user.plant_cd = '##'
    )
/*END*/
/*IF cond_Timezone != null*/
    AND mst_user.timezone_cd = /*cond_Timezone*/'S'
/*END*/
/*IF cond_Lang != null*/
    AND mst_user.lang_cd = /*cond_Lang*/'S'
/*END*/
/*END*/

ORDER BY
/*IF fw0114SortKey == null*/
    mst_user.delete_flag ASC, id ASC
/*END*/
/*IF  fw0114SortKey == "id"*/
    /*IF fw0114SortOrder == "asc"*/
    id ASC, mst_user.delete_flag ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    id DESC, mst_user.delete_flag ASC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "userLastname"*/
    /*IF fw0114SortOrder == "asc"*/
    user_lastname ASC, user_firstname ASC, mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    user_lastname DESC, user_firstname DESC, mst_user.delete_flag ASC, id ASC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "userAuthCd"*/
    /*IF fw0114SortOrder == "asc"*/
    ma_user.expiration_date ASC, mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ma_user.expiration_date DESC, mst_user.delete_flag ASC, id ASC
    /*END*/
/*END*/

/*IF  fw0114SortKey == "belongName"*/
    /*IF fw0114SortOrder == "asc"*/
    ma_user.belong_name ASC, mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ma_user.belong_name DESC, mst_user.delete_flag ASC, id ASC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "plantCd"*/
    /*IF fw0114SortOrder == "asc"*/
    ma_user.plant_cd ASC, mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ma_user.plant_cd DESC, mst_user.delete_flag ASC, id ASC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "timezoneCd"*/
    /*IF fw0114SortOrder == "asc"*/
    timezone_cd ASC, mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    timezone_cd DESC, mst_user.delete_flag ASC, id ASC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "langCd"*/
    /*IF fw0114SortOrder == "asc"*/
    mst_user.lang_cd ASC, mst_user.delete_flag ASC, id ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    mst_user.lang_cd DESC, mst_user.delete_flag ASC, id ASC
    /*END*/
/*END*/
/*IF fw0114CsvMaxSize != null*/
LIMIT /*fw0114CsvMaxSize*/
/*END*/