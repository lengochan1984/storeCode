SELECT
    M0.st_no					AS station_no,
    T1.sts_cd 				AS equip_sts,
    T1.alm_cd 					AS error_cd,
    T1.mainte_skd_cnt			AS regular_maintenance_num,
    T1.mainte_cnt				AS maintenance_num,
    T1.uptime					AS total_running_time,
    T1.online_flg				AS online_flg,
    M2.alm_msg					AS error_name,
    M3.equip_cd_nm				AS e_kind_name,
    M3.equip_kind				AS equipment_kind,
    M1.equip_cd					AS equipment_code,
    M4.user_id 					AS worker_id,
    M4.user_name				AS worker_name,
    B.last_occurrence			AS fuguai_time,
    B.occurrence				AS fuguai_Count,
    J.pre_retention_num			AS pre_retention_num,
    M0.stay_num_before		AS st_retention_before,
    CASE WHEN J.pre_retention_num - M0.stay_num_before >= 0 THEN true ELSE false END AS over_pre_retention,

    J.retention_num				AS retention_num,
    M0.stay_num_inside		AS st_retention_inside,
    CASE WHEN J.retention_num - M0.stay_num_inside >= 0 THEN true ELSE false END AS over_retention,
    get_line_name(/*comPlantCode*/'',ma_line.ln_no)			  AS ln_nm,
    J.actual_num,
    J.schedule_num,
    J.plan_num
FROM
    ma_station M0
INNER JOIN
    ma_equip M1
ON
--    M1.plant_cd = M0.plant_cd
    M1.st_id = M0.st_id
LEFT OUTER JOIN
    tr_equip_sts T1
ON
     M1.plant_cd = T1.plant_cd
 AND     M1.main_res_no = T1.main_res_no
--    M1.st_id = T1.st_id
LEFT OUTER JOIN
    ma_equip_alm_cd M2
ON
     M1.equip_cd = M2.equip_cd
    AND	T1.alm_cd = M2.alm_cd
LEFT OUTER JOIN
      ma_equip_cd M3
ON
    M1.equip_cd = M3.equip_cd
LEFT OUTER JOIN
    tr_station_sts
ON tr_station_sts.st_id = M1.st_id
LEFT OUTER JOIN
    ma_user M4
ON
       M4.plant_cd = T1.plant_cd
  AND  M4.user_id = tr_station_sts.user_id
    AND	(
            M4.plant_cd = M1.plant_cd
        OR	M4.plant_cd = '##'
    )
LEFT OUTER JOIN
(
    SELECT
        plant_cd,
        ln_no,
        st_id,
        st_no,
        to_char(MAX(occured_on), 'YYYY/MM/DD HH24:MI:SS') AS last_occurrence,
        COUNT(occured_on) AS occurrence
    FROM
        tr_equip_alm_jsk
    WHERE
        plant_cd = /*comPlantCode*/'D0'
    GROUP BY
        plant_cd,
        ln_no,st_id,st_no
) B
ON
        B.plant_cd = M1.plant_cd
--    AND	ma_line.ln_no = ma_line.ln_no
--	AND	B.st_no = M0.st_no
    AND	B.st_id = M0.st_id
INNER JOIN
    ma_line
ON
    ma_line.ln_id = M0.ln_id

INNER JOIN ma_process
    ON ma_line.process_id = ma_process.process_id

INNER JOIN ma_seizou_line
    ON ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id

LEFT OUTER JOIN
    ag_st_work_current	J
ON
    M0.st_id = J.st_id
WHERE
        ma_seizou_line.plant_cd = /*comPlantCode*/'D0'
    AND	ma_seizou_line.seizou_ln_id = /*comSeizouLnId*/1
    AND	ma_process.process_id = /*comProcessId*/1
    AND	ma_line.ln_id = /*comLnId*/1
    AND	M0.st_no <> 'ST00'
ORDER BY
/*IF fw0114SortKey == null*/
    M1.plant_cd ASC, ma_line.ln_no ASC, M0.st_no ASC
/*END*/
/*IF fw0114SortKey == "stationNo"*/
    /*IF fw0114SortOrder == "asc"*/
    M0.st_no ASC, M1.plant_cd ASC, ma_line.ln_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    M0.st_no DESC, M1.plant_cd ASC, ma_line.ln_no ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == "stationName"*/
    /*IF fw0114SortOrder == "asc"*/
    e_kind_name ASC, M3.equip_cd ASC, M1.plant_cd ASC, ma_line.ln_no ASC, M0.st_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    e_kind_name DESC, M3.equip_cd DESC, M1.plant_cd ASC, ma_line.ln_no ASC, M0.st_no ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "stationStatus"*/
    /*IF fw0114SortOrder == "asc"*/
    T1.online_flg ASC, M1.plant_cd ASC, ma_line.ln_no ASC, M0.st_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    T1.online_flg DESC, M1.plant_cd ASC, ma_line.ln_no ASC, M0.st_no ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == "preRetention"*/
    /*IF fw0114SortOrder == "asc"*/
    J.pre_retention_num ASC, M1.plant_cd ASC, ma_line.ln_no ASC, M0.st_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    J.pre_retention_num DESC, M1.plant_cd ASC, ma_line.ln_no ASC, M0.st_no ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == "insideRetention"*/
    /*IF fw0114SortOrder == "asc"*/
    J.retention_num ASC, M1.plant_cd ASC, ma_line.ln_no ASC, M0.st_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    J.retention_num DESC, M1.plant_cd ASC, ma_line.ln_no ASC, M0.st_no ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == "workerName"*/
    /*IF fw0114SortOrder == "asc"*/
    M4.user_name ASC, M1.plant_cd ASC, ma_line.ln_no ASC, M0.st_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    M4.user_name DESC, M1.plant_cd ASC, ma_line.ln_no ASC, M0.st_no ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "lnNm"*/
    /*IF fw0114SortOrder == "asc"*/
    ln_nm ASC, M1.plant_cd ASC, M0.st_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ln_nm DESC, M1.plant_cd ASC, M0.st_no ASC
    /*END*/
/*END*/
