SELECT
    data_date,
    snapshot_date,
    CASE planned_order_unknown_num WHEN -1 THEN NULL ELSE planned_order_unknown_num END planned_order_unknown_num,
    CASE planned_order_shortage_num WHEN -1 THEN NULL ELSE planned_order_shortage_num END planned_order_shortage_num,
    CASE planned_order_zaikan_num WHEN -1 THEN NULL ELSE planned_order_zaikan_num END planned_order_zaikan_num,
    CASE production_order_shortage_num WHEN -1 THEN NULL ELSE production_order_shortage_num END production_order_shortage_num,
    CASE production_order_zaikan_num WHEN -1 THEN NULL ELSE production_order_zaikan_num END production_order_zaikan_num,
    CASE actual_num WHEN -1 THEN NULL ELSE actual_num END actual_num,
    CASE order_delay_num WHEN -1 THEN NULL ELSE order_delay_num END order_delay_num,
    CASE stock_delay_num WHEN -1 THEN NULL ELSE stock_delay_num END stock_delay_num
FROM (
    SELECT
        to_char(date_trunc('day', tpld.data_date + cast(/*zoneOffset*/ as interval) - cast(/*searchDateShiftTime*/ as interval)),'yyyy/mm/dd') as data_date,
        snapshot_date,
        tpld.planned_order_unknown_num,
        tpld.planned_order_shortage_num,
        tpld.planned_order_zaikan_num,
        tpld.production_order_shortage_num,
        tpld.production_order_zaikan_num,
        tpld.actual_num,
        tpld.order_delay_num,
        tpld.stock_delay_num
    FROM
        tbl_preload_level_daily tpld

    /*IF comLineNo != null*/
    INNER JOIN ma_line ml
    ON (
        ml.line_no = tpld.ln_no
    )
	INNER JOIN ma_process
		ON ml.process_id = ma_process.process_id
    /*END*/

    WHERE tpld.plant_code = /*comPlantCode*/
      AND tpld.seizou_line_cd = /*comSeizouLineCd*/

      /*IF comProcessCode != null*/
      AND ma_process.process_cd = /*comProcessCode*/
      /*END*/

      /*IF comLineNo != null*/
      AND tpld.line_no = /*comLineNo*/
      /*END*/

      /*IF comLineNo == null*/
      AND tpld.line_no = '-1'
      /*END*/

        AND TO_CHAR(tpld.data_date, 'yyyy/mm/dd') BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/

        AND TO_CHAR(tpld.data_date, 'HH24:MI') = /*startTime*/

        AND snapshot_date = (
            SELECT
                max(snapshot_date)
            FROM
                tbl_preload_level_daily
        )

) T
ORDER BY
    T.data_date, T.snapshot_date;
