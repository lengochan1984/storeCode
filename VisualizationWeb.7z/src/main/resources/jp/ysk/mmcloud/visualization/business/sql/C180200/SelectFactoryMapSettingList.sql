SELECT
    ma_map.plant_cd
    , ma_map.map_cd
    , ma_map.map_nm
    , ma_map.disp_order
FROM
    ma_map
    INNER JOIN ma_plant
    ON ma_map.plant_cd = ma_plant.plant_cd
WHERE
    ma_map.plant_cd = /*comPlantCode*/
    AND ma_map.invalid_flag = '0'
ORDER BY
    /*IF fw0114SortKey == null*/
    ma_map.disp_order ASC, ma_map.map_nm ASC
    /*END*/

    /*IF  fw0114SortKey == "dispOrder"*/
    /*IF fw0114SortOrder == "asc"*/
    ma_map.disp_order ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ma_map.disp_order DESC
    /*END*/
    /*END*/

    /*IF  fw0114SortKey == "mapNm"*/
    /*IF fw0114SortOrder == "asc"*/
    ma_map.map_nm ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    ma_map.map_nm DESC
    /*END*/
    /*END*/
