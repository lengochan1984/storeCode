SELECT
    MAX(A.ln_sts_frame) AS status
--    , MAX(A.line_upd_datetime) AS add_date
    , MAX(A.modified_on) AS add_date
FROM
    tr_line_sts A
    INNER JOIN ma_line B
    ON (
        B.invalid_flag = 0
        AND
        A.ln_id = B.ln_id
    )
    INNER JOIN ma_process
                ON B.process_id = ma_process.process_id
    INNER JOIN ma_seizou_line
                ON ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id
WHERE
    ma_seizou_line.plant_cd = /*comPlantCode*/'S'
/*IF comLnId != null*/
    AND B.ln_id = /*comLnId*/1
/*END*/
