SELECT
    date_trunc('month', nengetu) as data_date,
    COALESCE(round(todokebi_gaku / NULLIF(shuka_gaku,0) * 100.0, 3),0.00) as todokebi_percent,
    COALESCE(round(hyoujyun_gaku / NULLIF(shuka_gaku,0) * 100.0, 3),0.00) as hyoujyun_percent,
    COALESCE(round(youkyu_gaku / NULLIF(shuka_gaku,0) * 100.0, 3),0.00) as youkyu_percent
FROM (
    SELECT max(erp.nengetu) as nengetu,
        SUM(COALESCE(erp.todokebi_gaku,0)) as todokebi_gaku,
        SUM(COALESCE(erp.hyoujyun_gaku,0)) as hyoujyun_gaku,
        SUM(COALESCE(erp.youkyu_gaku,0)) as youkyu_gaku,
        COALESCE(SUM(COALESCE(erp.shuka_gaku, 0)),1) as shuka_gaku
    FROM tbl_erp_due_date_rating_monthly erp
    where erp.plant_code = /*comPlantCode*/

        /*IF categoryOne != null*/
        AND erp.kishu_ctgr01 = /*categoryOne*/
        /*END*/

        /*IF categoryTwo != null*/
        AND erp.kishu_ctgr02 = /*categoryTwo*/
        /*END*/

        /*IF searchOrderClient != null*/
        AND erp.jcskbn = /*searchOrderClient*/
        /*END*/

    AND TO_CHAR(erp.nengetu, 'yyyymm') BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/

    group by TO_CHAR(erp.nengetu, 'yyyymm')

) tem order by tem.nengetu asc
