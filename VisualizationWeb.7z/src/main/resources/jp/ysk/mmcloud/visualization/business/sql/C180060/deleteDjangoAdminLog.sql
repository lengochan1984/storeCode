DELETE
FROM
    django_admin_log
WHERE
    django_admin_log.user_id = /*userSid*/
