SELECT
    tusl.event_date,
    tusl.sts_cd,
    sn.name2 as status_color
FROM
    tr_unit_sts_log tusl
LEFT JOIN sys_name sn
    ON sn.name_type = /*namType*/'station_status'
    AND sn.item_cd = tusl.sts_cd
    AND sn.lang_cd = /*langCD*/'JPN'
WHERE
    tusl.st_id = /*stId*/5
AND tusl.event_date BETWEEN /*stStartTime*/ AND /*stFinishTime*/
ORDER BY
    tusl.event_date ASC