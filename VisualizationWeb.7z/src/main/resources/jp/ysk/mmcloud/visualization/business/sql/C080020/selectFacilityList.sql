SELECT
  plant.plant_code
  ,plant.plant_name AS name
  ,plant.invalid_flag
  ,disp_order_p.display_order
FROM
  (
    SELECT
      COALESCE(RTRIM(ma_plant.plant_cd), '') AS plant_code
      ,ma_plant.invalid_flag
      ,ma_plant.plant_nm
    FROM
      ma_plant
    INNER JOIN
      ma_plant_mieruka
    ON
          ma_plant_mieruka.invalid_flag = 0
      AND ma_plant_mieruka.plant_cd = ma_plant.plant_cd
    WHERE
      ma_plant.plant_cd <> ''
  ) AS plant
  INNER JOIN
    (
      SELECT
        COALESCE(RTRIM(signage_id), '') AS signage_id
        ,COALESCE(RTRIM(plant_cd), '') AS plant_code
        ,display_order
      FROM
        ma_sig_disp_order_plant
    ) AS disp_order_p
    ON
      disp_order_p.plant_code = plant.plant_code
WHERE
  disp_order_p.signage_id = /*signage_id*/''
  AND
  plant.plant_code = disp_order_p.plant_code
ORDER BY
  display_order
