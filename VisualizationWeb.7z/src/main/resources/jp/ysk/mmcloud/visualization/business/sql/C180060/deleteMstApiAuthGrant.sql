DELETE
FROM mst_api_auth_grant
WHERE
     mst_api_auth_grant.user_id = /*userSid*/
