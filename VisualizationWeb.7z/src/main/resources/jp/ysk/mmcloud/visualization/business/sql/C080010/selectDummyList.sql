SELECT
  ma_plant.plant_cd,
  ma_plant.plant_nm,
  /*signage_id*/'signage'
FROM
  ma_plant
