DELETE
FROM
    mst_mail_address
WHERE
    user_sid = /*userSid*/
