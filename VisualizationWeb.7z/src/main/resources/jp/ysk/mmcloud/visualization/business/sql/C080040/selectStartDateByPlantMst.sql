SELECT
  to_char(ma_plant.running_start_datetime, 'HH24') as start_hour,
  to_char(ma_plant.running_start_datetime, 'MI')   as start_minute
FROM
  ma_plant_mieruka
INNER JOIN
  ma_plant
ON
      ma_plant.invalid_flag = 0
  AND ma_plant.plant_cd = ma_plant_mieruka.plant_cd
WHERE
      ma_plant_mieruka.invalid_flag = 0
  AND ma_plant_mieruka.plant_cd = /*plantCode*/''
