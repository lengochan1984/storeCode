SELECT
    date_trunc('month', nengetu) AS nengetu,
    b_kepin_gaku AS b_kepin_gaku,
    h_kepin_gaku AS h_kepin_gaku
FROM
    tbl_erp_shortage_info_monthly
WHERE
        plant_code = /*comPlantCode*/
        /*IF categoryOne != null*/
        AND kishu_ctgr01 = /*categoryOne*/
        /*END*/

        /*IF categoryTwo != null*/
        AND kishu_ctgr02 = /*categoryTwo*/
        /*END*/

        /*IF categoryOne == null*/
        /*IF categoryTwo == null*/
        AND kishu_ctgr01 = ''
        AND kishu_ctgr02 = ''
        /*END*/
        /*END*/

    AND TO_CHAR(nengetu, 'yyyymm') BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/
ORDER BY nengetu ASC
