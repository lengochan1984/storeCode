SELECT
    ma_seizou_line.seizou_ln_nm
    , ma_map_item.disp_order
    , ma_map_item.vert_frame_pos
    , ma_map_item.hori_frame_pos
    , ma_map_item.item_cd
    , ag_line_work_current.schedule_num
    , ag_line_work_current.actual_num
    , ag_line_work_current.plan_num

FROM
    ma_map_item INNER JOIN ma_map
    ON ma_map_item.map_cd = ma_map.map_cd
    INNER JOIN ma_plant
    ON ma_map.plant_cd = ma_plant.plant_cd
    INNER JOIN ma_seizou_line
    ON ma_seizou_line.plant_cd = ma_map_item.plant_cd
    INNER JOIN ma_process
    ON ma_process.seizou_ln_id = ma_seizou_line.seizou_ln_id
    INNER JOIN ma_line
    ON ma_line.process_id = ma_process.process_id
    INNER JOIN ag_line_work_current
    ON ma_line.ln_id = ag_line_work_current.ln_id
WHERE
    ma_map_item.invalid_flag = '0'
    AND ma_seizou_line.plant_cd = /*comPlantCdType*/'T1'
    AND ma_map_item.map_cd = /*mapCd*/'M1'
ORDER BY
    ma_map_item.disp_order ASC