SELECT
  RTRIM(ma_station.st_no) as station_no
FROM
  ma_station
WHERE
  ma_station.plant_cd = /*plantCode*/
AND
  ma_station.ln_no = /*lineNo*/
ORDER BY station_no asc
