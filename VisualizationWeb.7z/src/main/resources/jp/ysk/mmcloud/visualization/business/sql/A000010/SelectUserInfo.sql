select
    mst_user.sid,
    mst_user.user_lastname,
    mst_user.user_firstname,
    mst_user.user_auth_cd,
    mst_user.passwd,
    mst_user.timezone_cd,
    sys_env.name as timezone_name,
    sys_env.abb_name as timezone_abb_name,
    sys_env.remark as timezone_remark,
    mst_user.lang_cd,
    mst_user.theme_color_cd,
    mst_user.clock_disp_flag,
    mst_user.exp_tim,
    tbl_user_login_info.passwd_miss_count,
    ma_user.auth_cd
from
    mst_user
left outer join
    tbl_user_login_info
on
    mst_user.sid = tbl_user_login_info.user_sid

inner join
    sys_env
on
    mst_user.timezone_cd = sys_env.item_cd and
    sys_env.env_cd = 'timezone' and
    sys_env.delete_flag = false

inner join
    ma_user
on
    mst_user.sid = ma_user.user_sid

where
    mst_user.id = /*user_id*/'a' and
    mst_user.delete_flag = false and
    mst_user.invalid_flag = '0'

