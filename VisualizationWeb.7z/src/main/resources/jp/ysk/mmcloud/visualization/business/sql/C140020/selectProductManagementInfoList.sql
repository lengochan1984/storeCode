SELECT
    MAX(DT.data_date) as data_date,
    /*IF taisuChecked == 'true'*/
        SUM(DT.plan_the_day_num) as plan_num,
        SUM(DT.actual_the_day_num) as actual_num
    --ELSE
        SUM(DT.plan_the_day_value) as plan_num,
        SUM(DT.actual_the_day_value) as actual_num
    /*END*/
FROM (
SELECT
    tpm.data_date AS data_date,
    CASE tpm.plan_the_day_num WHEN -1 THEN NULL ELSE tpm.plan_the_day_num END as plan_the_day_num,
    CASE tpm.actual_the_day_num  WHEN -1  THEN NULL ELSE tpm.actual_the_day_num END as actual_the_day_num,
    CASE tpm.plan_the_day_value WHEN -1 THEN NULL ELSE tpm.plan_the_day_value END as plan_the_day_value,
    CASE tpm.actual_the_day_value WHEN -1  THEN NULL ELSE tpm.actual_the_day_value END as actual_the_day_value
FROM
    /*IF comDateType == 'jikanbetu'*/
    ag_product_mng_hourly tpm
    /*END*/
    /*IF comDateType == 'nitiji'*/
    ag_product_mng_daily tpm
    /*END*/
    /*IF comDateType == 'getuji'*/
    ag_product_mng_monthly tpm
    /*END*/
    /*IF comLnId != null && comProcessId != null*/
    INNER JOIN
        ma_line mlg
    ON (
            tpm.ln_id = mlg.ln_id
        AND	tpm.ln_no = mlg.ln_no
    )
    /*END*/
WHERE
    /*IF comLnId != null && comProcessId != null*/
        mlg.ln_id = /*comLnId*/
    --ELSE
        tpm.ln_id = -1
    /*END*/
    AND	tpm.st_id = -1
    /*IF buhin_cd != null*/
    AND	tpm.buhin_cd = /*buhin_cd*/
    /*END*/
    /*IF kishugun_name != null*/
    AND	tpm.vtext_info1 = /*kishugun_name*/
    /*END*/
    /*IF series_name != null*/
    AND	tpm.vtext_info2 = /*series_name*/
    /*END*/
    AND	tpm.data_date BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/
    AND	tpm.plant_cd = /*comPlantCode*/
) DT
GROUP BY
    DT.data_date
ORDER BY
    DT.data_date
