
    SELECT max(erp.upd_date) as upd_date

    from tbl_erp_zaikan_rating_details erp

    where erp.plant_code = /*comPlantCode*/

    /*IF ctgrKubun == "01"*/
        AND	 kishu_ctgr01 = /*kisyuCtgr*/
        /*END*/
    /*IF ctgrKubun == "02"*/
        AND kishu_ctgr02 = /*kisyuCtgr*/
        /*END*/
    /*IF ctgrKubun == "00"*/
        AND (kishu_ctgr01 = '' AND kishu_ctgr02 = '')
        /*END*/
        AND erp.syori_date BETWEEN /*searchDateFrom*/ AND /*searchDateTo*/

