DELETE
FROM
    rel_user_group
WHERE
    user_sid = /*userSid*/
