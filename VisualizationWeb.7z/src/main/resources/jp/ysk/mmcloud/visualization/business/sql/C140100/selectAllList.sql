SELECT
    joined_station.ln_id,
    joined_station.ln_nm,
    joined_station.line_start_datetime,
    joined_station.line_end_datetime,
    joined_station.line_hantei,
    joined_station.line_repair_kaisu,
    joined_station.st_id,
    joined_station.st_nm,
    joined_station.st_start_datetime,
    joined_station.st_end_datetime,
    joined_station.st_hantei,
    joined_station.st_repair_kaisu,
    joined_worker.step_no,
    joined_worker.user_name AS worker_name,
    joined_worker.sg_start_datetime,
    joined_worker.sg_end_datetime
FROM
    (
    SELECT
        tr_work_step_jsk.step_no,
        ma_user.user_name,
        tr_work_step_jsk.start_time as sg_start_datetime,
        tr_work_step_jsk.end_time as sg_end_datetime,
        ma_station.ln_id,
        tr_work_step_jsk.st_id,
        tr_work_step_jsk.sasizu_no,
        tr_work_step_jsk.sub_no
    FROM
            tr_work_step_jsk

        INNER JOIN
            ma_station
        ON
            ma_station.st_id = tr_work_step_jsk.st_id

        INNER JOIN
            ma_user
        ON
            ma_user.user_id = tr_work_step_jsk.user_id
    ) AS joined_worker
RIGHT OUTER JOIN
    (
    SELECT
        joined_line.ln_id,
        joined_line.ln_nm,
        joined_line.start_datetime as line_start_datetime,
        joined_line.end_datetime as line_end_datetime,
        joined_line.hantei as line_hantei,
        joined_line.repair_kaisu as line_repair_kaisu,
        tr_st_work_jsk.st_id,
        tr_st_work_jsk.st_nm,
        tr_st_work_jsk.work_sta_time as st_start_datetime,
        tr_st_work_jsk.work_end_time as st_end_datetime,
        tr_st_work_jsk.hantei as st_hantei,
        tr_st_work_jsk.repair_kaisu as st_repair_kaisu,
        tr_product_trc.sasizu_no,
        tr_product_trc.sub_no
    FROM
            tr_product_trc
        INNER JOIN
            tr_st_work_jsk
        ON
            tr_product_trc.sasizu_no = tr_st_work_jsk.sasizu_no
        AND
            tr_product_trc.sub_no = tr_st_work_jsk.sub_no
        AND
            tr_product_trc.seihin_sn = /*serialNumberCSV*/''

        INNER JOIN
            ma_station
        ON
            ma_station.st_id = tr_st_work_jsk.st_id

        INNER JOIN
            (
            SELECT
                tr_line_work_jsk.ln_id,
                tr_line_work_jsk.ln_nm,
                tr_line_work_jsk.start_time AS start_datetime,
                tr_line_work_jsk.end_time AS end_datetime,
                tr_line_work_jsk.hantei,
                tr_line_work_jsk.repair_kaisu,
                tr_line_work_jsk.sasizu_no,
                tr_line_work_jsk.sub_no
            FROM
                tr_product_trc
            INNER JOIN
                tr_line_work_jsk
            ON
                tr_product_trc.sasizu_no = tr_line_work_jsk.sasizu_no
            AND
                tr_product_trc.sub_no = tr_line_work_jsk.sub_no
            WHERE
                tr_line_work_jsk.plant_cd = /*comPlantCodeCSV*/''
            AND
                tr_product_trc.seihin_sn = /*serialNumberCSV*/''
            ) AS joined_line
    ON
        ma_station.ln_id = joined_line.ln_id
    )AS joined_station
ON
    joined_worker.st_id = joined_station.st_id
AND
    joined_worker.ln_id = joined_station.ln_id
AND
    joined_worker.sasizu_no = joined_station.sasizu_no
AND
    joined_worker.sub_no = joined_station.sub_no
ORDER BY
    joined_station.ln_nm ASC,
    joined_station.line_start_datetime ASC,
    joined_station.line_end_datetime ASC,
    joined_station.line_hantei ASC,
    joined_station.line_repair_kaisu ASC,
    joined_station.st_nm ASC,
    joined_station.st_start_datetime ASC,
    joined_station.st_end_datetime ASC,
    joined_station.st_hantei ASC,
    joined_station.st_repair_kaisu ASC,
    joined_worker.step_no ASC,
    joined_worker.user_name ASC,
    joined_worker.sg_start_datetime ASC,
    joined_worker.sg_end_datetime ASC
