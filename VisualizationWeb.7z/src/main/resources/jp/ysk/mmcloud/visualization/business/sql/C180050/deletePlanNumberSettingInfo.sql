DELETE FROM
    tr_seihin_plan_manual_setting
WHERE
    tr_seihin_plan_manual_setting.sid IN /*sid*/('123')
