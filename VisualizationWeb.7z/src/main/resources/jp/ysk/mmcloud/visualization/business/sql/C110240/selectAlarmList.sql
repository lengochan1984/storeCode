SELECT
    tr_equip_alm_jsk.occured_on AS occurrence_datetime_gmt,
    EXTRACT(DAY FROM tr_equip_alm_jsk.occured_on) AS day_of_month,
    tr_equip_alm_jsk.alm_cd AS abnormality_id,
    CAST(TRUNC(EXTRACT(EPOCH FROM
        (CASE WHEN tr_equip_alm_jsk.recovered_on IS NULL
            THEN /*currentDatetime*/ - tr_equip_alm_jsk.occured_on
            ELSE tr_equip_alm_jsk.recovered_on - tr_equip_alm_jsk.occured_on
         END)
    )) AS INTEGER) AS restoration_time,
    ma_equip_alm_cd.alm_msg AS abnormality_content,
    (CASE WHEN tr_equip_alm_jsk.recovered_on IS NULL
        THEN 1
        ELSE 0 END) AS work_status
FROM
    tr_equip_alm_jsk

LEFT OUTER JOIN
    ma_equip
ON
        ma_equip.plant_cd = tr_equip_alm_jsk.plant_cd
    AND ma_equip.st_id = tr_equip_alm_jsk.st_id
    AND ma_equip.invalid_flag = 0
LEFT OUTER JOIN
    ma_equip_alm_cd
ON
        ma_equip_alm_cd.alm_cd = tr_equip_alm_jsk.alm_cd
    AND ma_equip_alm_cd.equip_cd = ma_equip.equip_cd
    AND ma_equip_alm_cd.invalid_flag = 0
LEFT OUTER JOIN
    ma_sagyoku
ON
    ma_sagyoku.plant_cd = tr_equip_alm_jsk.plant_cd
    AND ma_sagyoku.sagyoku = tr_equip_alm_jsk.sagyoku
    AND ma_sagyoku.invalid_flag = 0

INNER JOIN
    ma_plant
ON
    ma_plant.invalid_flag = 0
    AND ma_plant.plant_cd = tr_equip_alm_jsk.plant_cd
    AND ma_plant.invalid_flag = 0
INNER JOIN
    ma_plant_mieruka
ON
    ma_plant_mieruka.invalid_flag = 0
    AND ma_plant_mieruka.plant_cd = ma_plant.plant_cd
INNER JOIN
    ma_seizou_line
ON
    ma_seizou_line.plant_cd = tr_equip_alm_jsk.plant_cd
    AND ma_seizou_line.plant_cd = ma_plant_mieruka.plant_cd
    AND ma_seizou_line.invalid_flag = 0
INNER JOIN
    ma_process
ON
    ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id
    AND ma_process.invalid_flag = 0
INNER JOIN
    ma_line
ON
    ma_process.process_id = ma_line.process_id
    AND ma_line.invalid_flag = 0

WHERE
    tr_equip_alm_jsk.created_on >= /*weekDatetime*/
    /*IF comSeizouLnId != null */
    AND ma_seizou_line.seizou_ln_id = /*comSeizouLnId*/
    /*END*/
    /*IF comProcessId != null */
    AND ma_process.process_id = /*comProcessId*/
    /*END*/
    /*IF comLnId != null */
    AND ma_line.ln_id = /*comLnId*/
    /*END*/
    /*IF comStId != null */
    AND tr_equip_alm_jsk.st_id = /*comStId*/
    /*END*/
    /*IF workStatus == false*/
    AND  tr_equip_alm_jsk.recovered_on IS NULL
    /*END*/

ORDER BY
/*IF fw0114SortKey == null || fw0114SortKey == ""*/
    work_status DESC
    ,occurrence_datetime_gmt DESC
/*END*/
/*IF  fw0114SortKey == "occurrenceDatetime"*/
    /*IF fw0114SortOrder == "asc"*/
    occurrence_datetime_gmt ASC
    ,work_status ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    occurrence_datetime_gmt DESC
    ,work_status ASC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "abnormalityId"*/
    /*IF fw0114SortOrder == "asc"*/
    abnormality_id ASC
    ,work_status ASC
    ,occurrence_datetime_gmt DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    abnormality_id DESC
    ,work_status ASC
    ,occurrence_datetime_gmt DESC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "status"*/
    /*IF fw0114SortOrder == "asc"*/
    work_status ASC
    ,occurrence_datetime_gmt DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    work_status DESC
    ,occurrence_datetime_gmt DESC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "restorationTime"*/
    /*IF fw0114SortOrder == "asc"*/
    restoration_time ASC
    ,work_status ASC
    ,occurrence_datetime_gmt DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    restoration_time DESC
    ,work_status ASC
    ,occurrence_datetime_gmt DESC
    /*END*/
/*END*/
/*IF  fw0114SortKey == "abnormalityContent"*/
    /*IF fw0114SortOrder == "asc"*/
    abnormality_content ASC
    ,work_status ASC
    ,occurrence_datetime_gmt DESC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    abnormality_content DESC
    ,work_status ASC
    ,occurrence_datetime_gmt DESC
    /*END*/
/*END*/