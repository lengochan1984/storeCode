SELECT
  CASE tbl_ds_equip_uptime_monthly.equipment_status
    WHEN 1   THEN 'S101'
    WHEN 2   THEN 'S102'
    WHEN 31  THEN 'S201'
    WHEN 20  THEN 'S202'
    WHEN 51  THEN 'S203'
    WHEN 52  THEN 'S204'
    WHEN 32  THEN 'S205'
    ELSE 'S999'
  END station_status,
  round(CAST(tbl_ds_equip_uptime_monthly.uptime AS NUMERIC) / 60 / 60 / 1000) as date_time
FROM
  tbl_ds_equip_uptime_monthly
WHERE
  plant_code = /*plantCode*/''
AND
  line_no    = /*lineNo*/''
AND
  station_no = /*stationNo*/''
AND
  equipment_status = /*status*/0
ORDER BY tbl_ds_equip_uptime_monthly.data_date desc
LIMIT 1
