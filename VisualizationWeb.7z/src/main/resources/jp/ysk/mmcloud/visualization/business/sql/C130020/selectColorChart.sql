select name
from mmsf.sys_env
where env_cd like 'v_color_C130020'
order by item_cd asc