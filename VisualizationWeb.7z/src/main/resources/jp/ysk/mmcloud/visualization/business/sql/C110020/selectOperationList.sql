SELECT
    line_status_data.plant_cd,
    line_status_data.seizou_ln_nm AS seizou_line_name,
    get_line_name(line_status_data.plant_cd,line_status_data.ln_no) AS line_no,
    line_status_data.stay_before_th AS line_retention_before,
    line_status_data.stay_inside_th AS line_retention_inside,
    line_status_data.stay_after_th AS line_retention_after,
    line_status_data.plant_nm AS plant_name,
    line_status_data.ln_id,
    line_status_data.process_nm AS process_name,
    line_status_data.pre_retention_num,
    line_status_data.retention_num,
    line_status_data.after_retention_num,
    line_status_data.actual_num,
    line_status_data.schedule_num,
    line_status_data.plan_num,
    line_status_data.difference,
    line_status_data.status
FROM
(
    SELECT
        master_data.plant_cd,
        master_data.seizou_ln_cd,
        master_data.seizou_ln_nm,
        master_data.ln_no,
        master_data.ln_id,
        master_data.stay_before_th,
        master_data.stay_inside_th,
        master_data.stay_after_th,
        master_data.plant_nm,
        master_data.process_cd,
        master_data.process_nm,
--		master_data.process_no,
        ag_line_work_current.pre_retention_num,
        ag_line_work_current.retention_num,
        ag_line_work_current.after_retention_num,
        ag_line_work_current.actual_num,
        ag_line_work_current.schedule_num,
        ag_line_work_current.plan_num,
        CASE WHEN
            ag_line_work_current.actual_num > -1 AND ag_line_work_current.schedule_num > -1
        THEN
            ag_line_work_current.actual_num - ag_line_work_current.schedule_num
        ELSE
            NULL
        END AS difference,
        to_char(tr_line_sts.ln_sts_frame, 'FM999999')	AS status
    FROM
    (
        SELECT
            line_info.plant_cd,
            line_info.seizou_ln_cd,
            line_info.seizou_ln_nm,
            line_info.ln_no,
            line_info.ln_id,
            line_info.stay_before_th,
            line_info.stay_inside_th,
            line_info.stay_after_th,
            ma_plant.plant_nm,
            line_info.process_cd,
            process_info.process_nm
--			process_info.process_no
        FROM
        (
            SELECT
                ma_seizou_line.plant_cd,
                ma_seizou_line.seizou_ln_cd,
                ma_seizou_line.seizou_ln_nm,
                ma_line.ln_no,
                ma_line.ln_id,
                ma_process.process_cd,
                ma_line.stay_before_th,
                ma_line.stay_inside_th,
                ma_line.stay_after_th
            FROM
                ma_line

            INNER JOIN ma_process
                ON ma_line.process_id = ma_process.process_id

            INNER JOIN
                ma_seizou_line
            ON
                ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id
            WHERE
                    ma_seizou_line.plant_cd = /*comPlantCode*/'D0'
                AND	ma_seizou_line.seizou_ln_id = /*comSeizouLnId*/1
                AND	ma_line.invalid_flag = 0
                AND	(ma_line.ln_id) in (
                        SELECT
                            ln_id
                        FROM
                            ma_station
                )
        ) line_info
        INNER JOIN
            ma_plant
        ON
                ma_plant.invalid_flag = 0
            AND	ma_plant.plant_cd = line_info.plant_cd
        INNER JOIN
            ma_plant_mieruka
        ON
                ma_plant_mieruka.invalid_flag = 0
            AND ma_plant_mieruka.plant_cd = ma_plant.plant_cd
        INNER JOIN
        (
            SELECT
                ma_process.process_cd,
                ma_process.process_nm
--				ma_process.process_no
            FROM
                ma_process
        ) process_info
        ON
            line_info.process_cd = process_info.process_cd) master_data
    LEFT OUTER JOIN
        ag_line_work_current
    ON
            master_data.ln_id = ag_line_work_current.ln_id
    LEFT OUTER JOIN
        tr_line_sts
    ON
            master_data.ln_id = tr_line_sts.ln_id) line_status_data
ORDER BY
/*IF fw0114SortKey == null*/
    line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
/*END*/
/*IF fw0114SortKey == "plantName"*/
    /*IF fw0114SortOrder == "asc"*/
    line_status_data.plant_nm ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    line_status_data.plant_nm DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "seizouLineName"*/
    /*IF fw0114SortOrder == "asc"*/
    line_status_data.seizou_ln_nm ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    line_status_data.seizou_ln_nm DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "processName"*/
    /*IF fw0114SortOrder == "asc"*/
    line_status_data.process_nm ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    line_status_data.process_nm DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "lineNo"*/
    /*IF fw0114SortOrder == "asc"*/
    line_no ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    line_no DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "status"*/
    /*IF fw0114SortOrder == "asc"*/
    line_status_data.status ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    line_status_data.status DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "preRetention"*/
    /*IF fw0114SortOrder == "asc"*/
    line_status_data.pre_retention_num ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    line_status_data.pre_retention_num DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "retention"*/
    /*IF fw0114SortOrder == "asc"*/
    line_status_data.retention_num ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    line_status_data.retention_num DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "afterRetention"*/
    /*IF fw0114SortOrder == "asc"*/
    line_status_data.after_retention_num ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    line_status_data.after_retention_num DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "actualNum"*/
    /*IF fw0114SortOrder == "asc"*/
    line_status_data.actual_num ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    line_status_data.actual_num DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "scheduleNum"*/
    /*IF fw0114SortOrder == "asc"*/
    line_status_data.schedule_num ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    line_status_data.schedule_num DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "scheduleDiffNum"*/
    /*IF fw0114SortOrder == "asc"*/
    line_status_data.difference ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    line_status_data.difference DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "planNum"*/
    /*IF fw0114SortOrder == "asc"*/
    line_status_data.plan_num ASC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    line_status_data.plan_num DESC, line_status_data.plant_cd ASC, line_status_data.seizou_ln_cd ASC,  line_status_data.process_cd ASC, line_status_data.ln_no ASC
    /*END*/
/*END*/
