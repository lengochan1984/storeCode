
UPDATE rel_user_role

SET
    ROLE_SID = /*roleSid*/,
    UPD_PROG = /*updProg*/,
    UPD_TIM = /*updTim*/,
    UPD_USER_SID = /*updUserSid*/

WHERE
    USER_SID = /*userSid*/
