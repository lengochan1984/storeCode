DELETE
FROM
    rel_user_role
WHERE
    user_sid = /*userSid*/
