select
  MAX(snapshot_date)
from (
    select tpld.snapshot_date,
            row_number() over(partition by to_char(tpld.data_date, 'yyyy/mm/dd') order by snapshot_date desc) as rank_number
    from tbl_preload_level_daily tpld

     /*IF comLineNo != null*/
    INNER JOIN ma_line ml
    ON (
        ml.ln_no = tpld.line_no
    )
	INNER JOIN ma_process
				ON ml.process_id = ma_process.process_id
    /*END*/

    WHERE tpld.plant_code = /*comPlantCode*/
      AND tpld.seizou_line_cd = /*comSeizouLineCd*/

      /*IF comProcessCode != null*/
      AND ma_process.process_cd = /*comProcessCode*/
      /*END*/

      /*IF comLineNo != null*/
      AND tpld.line_no = /*comLineNo*/
      /*END*/

      /*IF comLineNo == null*/
      AND tpld.line_no = '-1'
      /*END*/

      AND TO_CHAR(tpld.data_date, 'yyyy/MM/dd') BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/
      AND TO_CHAR(tpld.data_date, 'HH24:MI') = /*startTime*/
) T where T.rank_number = 1

