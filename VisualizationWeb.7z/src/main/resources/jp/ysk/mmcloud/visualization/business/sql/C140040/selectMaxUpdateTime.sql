
    SELECT max(erp.upd_date) as upd_date

    from tbl_erp_due_date_rating_monthly erp

    where erp.plant_code = /*comPlantCode*/

        /*IF categoryOne != null*/
        AND erp.kishu_ctgr01 = /*categoryOne*/
        /*END*/

        /*IF categoryTwo != null*/
        AND erp.kishu_ctgr02 = /*categoryTwo*/
        /*END*/

        /*IF searchOrderClient != null*/
        AND erp.jcskbn = /*searchOrderClient*/
        /*END*/

        AND TO_CHAR(erp.nengetu, 'yyyymm') BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/

