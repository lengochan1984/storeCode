SELECT
  tbl_ds_work_manhour_mng_monthly.data_date           as month,
  round(CAST(tbl_ds_work_manhour_mng_monthly.plan_work_manhour AS NUMERIC) / 60 / 60 / 1000) as plan_manhour,
  round(CAST(tbl_ds_work_manhour_mng_monthly.actual_work_manhour AS NUMERIC) / 60 / 60 / 1000) as actual_manhour,
  TRIM(to_char(date_part('year',tbl_ds_work_manhour_mng_monthly.data_date),'9999')) as now_year,
  TRIM(to_char(date_part('month',tbl_ds_work_manhour_mng_monthly.data_date),'99')) as now_month,
  TRIM(to_char(date_part('day',tbl_ds_work_manhour_mng_monthly.data_date),'99')) as now_day
FROM
  tbl_ds_work_manhour_mng_monthly
WHERE
  tbl_ds_work_manhour_mng_monthly.plant_code = /*plantCode*/''
AND
  tbl_ds_work_manhour_mng_monthly.line_no = /*lineNo*/''
ORDER BY month desc
LIMIT 12
