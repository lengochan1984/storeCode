
UPDATE rel_user_group

SET
    GROUP_ID = /*groupId*/,
    UPD_PROG = /*updProg*/,
    UPD_TIM = /*updTim*/,
    UPD_USER_SID = /*updUserSid*/

WHERE
    USER_SID = /*userSid*/