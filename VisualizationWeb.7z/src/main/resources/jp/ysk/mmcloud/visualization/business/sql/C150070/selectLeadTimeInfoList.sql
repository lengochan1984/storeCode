WITH keyTable AS (
    SELECT
        tblA.werks AS plant_cd,		--工場コード
        tblA.sasizu_no,				--指図番号
        tblA.sub_no,				--副番号
        tblA.end_date	--製品の生産終了実績日時
    FROM
    (
        SELECT
            A0.werks,				--工場コード
            A1.sasizu_no,			--指図番号
            A1.sub_no,				--副番号
            A1.end_date				--製品の生産終了実績日時
        FROM
            tr_sasizu_info A0
        INNER JOIN
            tr_product_trc A1
        ON
                A0.sasizu_no = A1.sasizu_no
            AND	A0.werks = /*comPlantCode*/
        INNER JOIN
            ma_hinmoku H
        ON
                A1.buhin_cd = H.matnr
            AND	A0.werks = H.werks
            /*IF buhin_cd != null*/
            AND	H.matnr = /*buhin_cd*/
            /*END*/
            /*IF kishugun_name != null*/
            AND	H.vtext_info1 = /*kishugun_name*/	--製品プルダウンで機種群名を選択時
            /*END*/
            /*IF series_name != null*/
            AND	H.vtext_info2 = /*series_name*/	--製品プルダウンでシリーズ名を選択時
            /*END*/
        WHERE
                A1.end_date >= /*comDataDateFrom*/
            AND	A1.end_date <= /*comDataDateTo*/
            AND	A1.end_date is not null
            AND	A1.seisan_jyotai = '90'	--生産状態
            AND	A1.hantei = 1			--合否判定
    ) tblA
)
--工程リードタイム
SELECT
    lt.process_nm AS process_name,		--工程名
    lt.process_no AS process_no,		--工程順序
    lt.process_id AS process_id,		--工程コード
    avg(lt.lead_time) AS av_lead_time,	--リードタイム平均
    max(lt.lead_time) AS mx_lead_time,	--リードタイム最大
    min(lt.lead_time) AS mi_lead_time,	--リードタイム最小
    lt.actual_end_datetime
FROM
(
    SELECT
        lt1.sasizu_no,		--指図番号
        lt1.sub_no,			--副番号
        cast(pc1.process_id AS text) AS process_id,		--工程ID
        lt1.lead_time,		--リードタイム
        pc1.process_nm,	--工程名称
        pc1.process_seq AS process_no,		--工程順序
        /*IF comDateType == 'jikanbetu'*/
        date_trunc('hour', key1.end_date + cast(/*zoneOffset*/ AS interval)) AS actual_end_datetime
        /*END*/
        /*IF comDateType == 'nitiji'*/
        date_trunc('day', key1.end_date + cast(/*zoneOffset*/ AS interval) - cast(/*searchDateShiftTime*/ AS interval)) AS actual_end_datetime
        /*END*/
        /*IF comDateType == 'getuji'*/
        date_trunc('month', key1.end_date + cast(/*zoneOffset*/ AS interval) - cast(/*searchDateShiftTime*/ AS interval) + interval '15 days') AS actual_end_datetime
        /*END*/
    FROM
        /*IF comDateType == 'jikanbetu'*/
        ag_line_lead_time_hourly lt1	--時間別テーブルは存在しないので、エラーとなる
        /*END*/
        /*IF comDateType == 'nitiji'*/
        ag_line_lead_time_daily lt1
        /*END*/
        /*IF comDateType == 'getuji'*/
        ag_line_lead_time_monthly lt1
        /*END*/
    INNER JOIN
        ma_line l1
    ON
        lt1.ln_id = l1.ln_id
        AND	l1.invalid_flag = 0
    INNER JOIN ma_process pc1
                ON l1.process_id = pc1.process_id

    INNER JOIN ma_seizou_line zl1
                ON zl1.seizou_ln_id = pc1.seizou_ln_id
                AND lt1.plant_cd = zl1.plant_cd
                AND	pc1.invalid_flag = 0
    ,keyTable key1
    WHERE
            lt1.plant_cd = key1.plant_cd
        AND	lt1.sasizu_no = key1.sasizu_no
        AND	lt1.sub_no = key1.sub_no
        AND	zl1.seizou_ln_id = cast(/*comSeizouLnId*/ as numeric)
        /*IF comProcessId != null */
        AND	pc1.process_id = cast(/*comProcessId*/ as numeric)
        /*END*/
    UNION
    --工程間リードタイム
    SELECT
        lt2.sasizu_no,															--指図番号
        lt2.sub_no,																--副番号
        pc2.process_id || '-' || pc3.process_id AS process_id,					--工程ID(前後)
        lt2.lead_time,															--リードタイム
        pc2.process_nm || '～' || pc3.process_nm AS process_nm,					--工程名称
        pc2.process_seq AS process_no,											--工程順序
        /*IF comDateType == 'jikanbetu'*/
        date_trunc('hour', key2.end_date + cast(/*zoneOffset*/ AS interval)) AS actual_end_datetime
        /*END*/
        /*IF comDateType == 'nitiji'*/
        date_trunc('day', key2.end_date + cast(/*zoneOffset*/ AS interval) - cast(/*searchDateShiftTime*/ AS interval)) AS actual_end_datetime
        /*END*/
        /*IF comDateType == 'getuji'*/
        date_trunc('month', key2.end_date + cast(/*zoneOffset*/ AS interval) - cast(/*searchDateShiftTime*/ AS interval) + interval '15 days') AS actual_end_datetime
        /*END*/
    FROM
        /*IF comDateType == 'jikanbetu'*/
        ag_line_tm_lead_time_hourly lt2	--時間別テーブルは存在しないので、エラーとなる
        /*END*/
        /*IF comDateType == 'nitiji'*/
        ag_line_tm_lead_time_daily lt2
        /*END*/
        /*IF comDateType == 'getuji'*/
        ag_line_tm_lead_time_monthly lt2
        /*END*/
    INNER JOIN
        ma_line l2
    ON
        lt2.ln_id = l2.ln_id
        AND	l2.invalid_flag = 0
    INNER JOIN
        ma_process pc2
    ON
        l2.process_id = pc2.process_id
        AND	pc2.invalid_flag = 0
    INNER JOIN ma_seizou_line sl2
    ON
        sl2.seizou_ln_id = pc2.seizou_ln_id
        AND lt2.plant_cd = sl2.plant_cd
    INNER JOIN
        ma_line l3
    ON
        lt2.n_ln_id = l3.ln_id
        AND	l3.invalid_flag = 0
    INNER JOIN
        ma_process pc3
    ON
        l3.process_id = pc3.process_id
        AND	pc3.invalid_flag = 0
    INNER JOIN ma_seizou_line sl3
    ON
        sl3.seizou_ln_id = pc3.seizou_ln_id
        AND lt2.plant_cd = sl3.plant_cd
    ,keyTable key2
    WHERE
            lt2.plant_cd = key2.plant_cd
        AND	lt2.sasizu_no = key2.sasizu_no
        AND	lt2.sub_no = key2.sub_no
        AND	pc2.seizou_ln_id = cast(/*comSeizouLnId*/ as numeric)
        /*IF comProcessId != null */
        AND	pc3.process_id = cast(/*comProcessId*/ as numeric)
        /*END*/
) lt
GROUP BY
    lt.process_nm,			--工程名称
    lt.process_no,			--工程順序
    lt.process_id,			--工程ID
    lt.actual_end_datetime	--完成日
ORDER BY
    lt.actual_end_datetime,
    lt.process_no,			--工程順序
    lt.process_nm
