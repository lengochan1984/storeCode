SELECT
    A.data_date,
    A.name,
    SUM(CASE A.data_value
            WHEN -1 THEN null
            ELSE A.data_value
        END ) AS data_value
FROM
(
    SELECT
        /*IF comDateType != 'jikanbetu'*/
        DATE_TRUNC('DAY', A.data_date + cast(/*zoneOffset*/ as interval) - cast(/*searchDateShiftTime*/ as interval)) AS data_date,
        --ELSE
        A.data_date AS data_date,
        /*END*/
        ma_line.ln_nm AS name,
--		CASE WHEN S.display_order IS NULL THEN 999 ELSE S.display_order END AS sort_order,
        /*IF condIsCategoryNum == true*/
        A.retention_num AS data_value
        --ELSE
        A.cost_price AS data_value
        /*END*/
    FROM
        ag_line_retention_num_10min A
        -- INNER JOIN
        -- mst_line_group LG
    -- ON
            -- A.line_no = LG.line_no
        -- AND	LG.single_line_flag = '1'
        -- AND	A.plant_code = LG.plant_code
    -- INNER JOIN
        -- tbl_line_group_pulldown S
    -- ON
            -- S.line_group_no = LG.line_group_no
        -- AND	S.plant_code = LG.plant_code
    INNER JOIN
        ma_line
    ON
        A.ln_id = ma_line.ln_id
    INNER JOIN ma_process
         ON ma_line.process_id = ma_process.process_id
    INNER JOIN ma_seizou_line
                ON ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id
                AND A.plant_cd = ma_seizou_line.plant_cd
    WHERE
            A.plant_cd = /*comPlantCode*/
        AND	ma_process.seizou_ln_id = /*comSeizouLnId*/
        /*IF comProcessId != null*/
        AND	ma_process.process_id = /*comProcessId*/
        /*END*/
        /*IF comLnId != null*/
        AND	A.ln_id = /*comLnId*/
        /*END*/
        AND	A.data_date BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/
        /*IF comDateType != 'jikanbetu'*/
        AND	TO_CHAR(A.data_date, 'HH24:MI') = /*condTimePoint*/
        /*END*/

    UNION ALL

    SELECT
        /*IF comDateType != 'jikanbetu'*/
        DATE_TRUNC('DAY', B.data_date + cast(/*zoneOffset*/ as interval) - cast(/*searchDateShiftTime*/ as interval)) AS data_date,
        --ELSE
        B.data_date AS data_time,
        /*END*/
        ma_line_1.ln_nm || '~' || ma_line_2.ln_nm AS name,
--		CASE WHEN S.display_order IS NULL THEN 999 ELSE S.display_order END AS sort_order,
        /*IF condIsCategoryNum == true*/
        B.retention_num AS data_value
        --ELSE
        B.cost_price AS data_value
        /*END*/
    FROM
        ag_line_tm_retention_num_10min B
        -- INNER JOIN
        -- mst_line_group LG
    -- ON
            -- B.next_line_no = LG.line_no
        -- AND	LG.single_line_flag = '1'
        -- AND	B.plant_code = LG.plant_code
    -- INNER JOIN
        -- tbl_line_group_pulldown S
    -- ON
            -- S.line_group_no = LG.line_group_no
        -- AND	S.plant_code = LG.plant_code
    INNER JOIN
        ma_line AS ma_line_1
    ON
        B.ln_id = ma_line_1.ln_id

    INNER JOIN ma_process AS ma_process_1
         ON ma_line_1.process_id = ma_process_1.process_id

    INNER JOIN
        ma_line AS ma_line_2
    ON
        B.n_ln_id = ma_line_2.ln_id

    INNER JOIN ma_process AS ma_process_2
         ON ma_line_2.process_id = ma_process_2.process_id
    INNER JOIN ma_seizou_line
                ON ma_seizou_line.seizou_ln_id = ma_process_2.seizou_ln_id
                AND B.plant_cd = ma_seizou_line.plant_cd

    WHERE
            B.plant_cd = /*comPlantCode*/
        AND	ma_process_1.seizou_ln_id = /*comSeizouLnId*/
        /*IF comProcessId != null*/
        AND	ma_process_2.process_id = /*comProcessId*/
        /*END*/
        /*IF comLnId != null*/
        AND	B.n_ln_id = /*comLnId*/
        /*END*/
        AND	B.data_date BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/
        /*IF comDateType != 'jikanbetu'*/
        AND	TO_CHAR(B.data_date, 'HH24:MI') = /*condTimePoint*/
        /*END*/
) A
GROUP BY
    A.data_date,
--	A.sort_order,
    A.name
ORDER BY
--	A.sort_order,
    A.name,
    A.data_date
