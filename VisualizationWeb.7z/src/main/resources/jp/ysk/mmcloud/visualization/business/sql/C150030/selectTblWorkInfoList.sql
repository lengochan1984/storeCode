SELECT
    T.step_no                                                                               AS step_no,
    COALESCE((SUM(T.standard_manhour * T.parameter) / SUM(T.parameter)), 0)                 AS standard_manhour,
    COALESCE((SUM(T.work_manhour_average * T.parameter) / SUM(T.parameter)), 0)             AS work_manhour_average,
    COALESCE(SQRT(SUM(POW(T.standard_deviation, 2) * T.parameter) / SUM(T.parameter)), 0)   AS standard_deviation
FROM
(
    SELECT
        t0.step_no,
        t0.sagyo_no,
        t1.standard_manhour,
        t1.work_manhour_average,
        t1.standard_deviation,
        t1.parameter
    FROM
    (
        SELECT
            sub0.job_ptn_id,
            sub0.step_no,
            sub0.sagyo_no,
            sub1.ln_id,
            sub3.vtext_info1,
            sub3.vtext_info2
        FROM
            ma_mes_wk_step_dtl  sub0
        INNER JOIN
            ma_mes_work_step    sub1
        ON
            sub0.job_ptn_id = sub1.job_ptn_id
        INNER JOIN
            ma_mes_proc_man     sub2
        ON
            sub1.proc_man_id    = sub2.proc_man_id
        INNER JOIN
            ma_hinmoku          sub3
        ON
                sub2.buhin_cd   = sub3.matnr
            AND sub2.plant_cd   = sub3.werks
        INNER JOIN
            ma_line             sub4
        ON
            sub1.ln_id  = sub4.ln_id
        INNER JOIN
            ma_process          sub5
        ON
            sub4.process_id = sub5.process_id
        WHERE
                sub3.werks          = /*comPlantCode*/
            AND sub5.seizou_ln_id   = /*comSeizouLnId*/
            /*IF kishugun_name != null*/
            AND sub3.vtext_info1    = /*kishugun_name*/ --製品プルダウンで機種群名を選択時
            /*END*/
            /*IF series_name != null*/
            AND sub3.vtext_info2    = /*series_name*/   --製品プルダウンでシリーズ名を選択時
            /*END*/
        GROUP BY
            sub0.job_ptn_id,
            sub0.step_no,
            sub0.sagyo_no,
            sub1.ln_id,
            sub3.vtext_info1,
            sub3.vtext_info2
    ) t0
    LEFT OUTER JOIN
    (
        SELECT
            job_ptn_id,
            step_no,
            standard_manhour,
            work_manhour_average,
            standard_deviation,
            parameter
        FROM
            /*IF passedLine == null*/
            /*IF comDateType == 'jikanbetu'*/
            /*IF kishugun_name != null*/
            ag_work_manhour_mng_g_daily X
            /*END*/
            /*IF series_name != null*/
            ag_work_manhour_mng_s_daily X
            /*END*/
            /*END*/
            /*IF comDateType == 'nitiji'*/
            /*IF kishugun_name != null*/
            ag_work_manhour_mng_g_monthly   X
            /*END*/
            /*IF series_name != null*/
            ag_work_manhour_mng_s_monthly   X
            /*END*/
            /*END*/
            /*IF comDateType == 'getuji'*/
            /*IF kishugun_name != null*/
            ag_work_manhour_mng_g_yearly    X   --年別テーブルは存在しないので、エラーとなる
            /*END*/
            /*IF series_name != null*/
            ag_work_manhour_mng_s_yearly    X   --年別テーブルは存在しないので、エラーとなる
            /*END*/
            /*END*/
            /*END*/

            /*IF passedLine != null*/
            /*IF comDateType == 'jikanbetu'*/
            ag_work_manhour_mng_daily   X
            /*END*/
            /*IF comDateType == 'nitiji'*/
            ag_work_manhour_mng_monthly X
            /*END*/
            /*IF comDateType == 'getuji'*/
            ag_work_manhour_mng_yearly  X   --年別テーブルは存在しないので、エラーとなる
            /*END*/
            /*END*/

        WHERE
                X.data_date     >= /*comDataDateFrom*/
            AND X.data_date     <= /*comDataDateTo*/
            AND X.parameter     >  0
            /*IF passedLine == null*/
            /*IF kishugun_name != null*/
            AND X.vtext_info1   = /*kishugun_name*/ --製品プルダウンで機種群名を選択時
            /*END*/
            /*IF series_name != null*/
            AND X.vtext_info2   = /*series_name*/   --製品プルダウンでシリーズ名を選択時
            /*END*/
            /*END*/
            /*IF passedLine != null*/
            AND EXISTS(
                SELECT
                    *
                FROM
                    tr_line_work_jsk    A
                INNER JOIN
                    tr_sasizu_info  B
                ON
                    A.sasizu_no = B.sasizu_no
                INNER JOIN
                    ma_hinmoku  C
                ON
                        B.werks     = C.werks
                    AND B.buhin_cd  = C.matnr
                    /*IF kishugun_name != null*/
                    AND C.vtext_info1   = /*kishugun_name*/ --製品プルダウンで機種群名を選択時
                    /*END*/
                    /*IF series_name != null*/
                    AND C.vtext_info2   = /*series_name*/   --製品プルダウンでシリーズ名を選択時
                    /*END*/
                WHERE
                        A.sasizu_no = X.sasizu_no
                    AND A.sub_no    = X.sub_no
                    AND A.ln_id     = /*passedLine*/
            )
            /*END*/
    ) t1
    ON
            t0.job_ptn_id   = t1.job_ptn_id
        AND t0.step_no      = t1.step_no
) T
GROUP BY
    T.step_no
ORDER BY
    min(T.sagyo_no),
    T.step_no
