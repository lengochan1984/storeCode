SELECT
  signage_id,
  facility_summary_kind,
  group_summary_kind,
  leadtime_period_unit,
  leadtime_period,
  leadtime_hist_unit,
  leadtime_hist_max_num,
  leadtime_hist_min_num,
  daily_ope_time_period,
  yearly_product_num_period
FROM
  mst_signage
WHERE
  signage_id = /*signage_id*/''
