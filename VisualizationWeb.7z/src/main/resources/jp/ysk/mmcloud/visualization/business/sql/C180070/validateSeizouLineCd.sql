select
    *
from
    mst_user
inner join
    ma_user
on
    ma_user.user_sid = mst_user.sid
inner join
    ma_seizou_line
on
    ma_user.plant_cd = '##'
    or ma_seizou_line.plant_cd = ma_user.plant_cd
where
    mst_user.id = /*ssn_UserID*/''
    and ma_seizou_line.plant_cd = /*comPlantCode*/''
    and ma_seizou_line.seizou_ln_id = /*comSeizouLnId*/1
