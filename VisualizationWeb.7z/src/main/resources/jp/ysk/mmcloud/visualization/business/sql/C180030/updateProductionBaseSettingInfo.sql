UPDATE
    ma_plant_mieruka

SET
    mes_db_connect_info = /*mesDbConnectInfo*/,
    mes_db_user_id = /*mesDbUserId*/,
    mes_db_password = /*mesDbPassword*/,
    upd_prog = /*updProg*/,
    upd_tim = /*updTim*/,
    upd_user_sid = /*updUserSid*/

WHERE
    plant_cd = /*plantCd*/
