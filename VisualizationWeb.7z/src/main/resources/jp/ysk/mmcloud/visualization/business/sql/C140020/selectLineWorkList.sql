SELECT
    A.data_date AS data_date,
    SUM(CASE A.plan_num
            WHEN -1 THEN null
            ELSE A.plan_num
        END) AS plan_num,
    SUM(CASE A.actual_num
            WHEN -1 THEN null
            ELSE A.actual_num
        END) AS actual_num
FROM
    /*IF comDateType == 'jikanbetu'*/
    ag_line_work_hourly A
    /*END*/
    /*IF comDateType == 'nitiji'*/
    ag_line_work_daily A
    /*END*/
    /*IF comDateType == 'getuji'*/
    ag_line_work_monthly A
    /*END*/
    /*IF comLnId != null && comProcessId != null*/
    INNER JOIN
        ma_line B
    ON (
            B.invalid_flag = 0
        AND	A.ln_id = B.ln_id
    )
    INNER JOIN
        ma_process D
                ON B.process_id = D.process_id
    INNER JOIN ma_seizou_line E
                ON E.seizou_ln_id = D.seizou_ln_id
                AND	A.plant_cd = E.plant_cd
                AND	A.seizou_ln_cd = E.seizou_ln_cd
    /*END*/
WHERE
        A.plant_cd = /*comPlantCode*/'T1'
    AND	A.seizou_ln_id = /*comSeizouLnId*/
    /*IF comLnId == null && comProcessId == null*/
    AND	A.ln_id = '-1'
    --ELSE
    AND	A.ln_id = /*comLnId*/
    /*END*/
    AND	A.data_date BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/
GROUP BY
    A.data_date
ORDER BY
    A.data_date
