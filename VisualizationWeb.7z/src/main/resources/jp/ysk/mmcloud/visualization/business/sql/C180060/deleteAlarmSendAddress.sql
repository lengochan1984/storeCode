DELETE
FROM
    mst_alarm_send_address
WHERE
	mail_address_sid in
(
select 
	mst_mail_address.sid
from  
	mst_alarm_send_address
inner join 
	mst_mail_address
on
    mst_alarm_send_address.mail_address_sid = mst_mail_address.sid
and
    mst_mail_address.user_sid = /*userSid*/
)
