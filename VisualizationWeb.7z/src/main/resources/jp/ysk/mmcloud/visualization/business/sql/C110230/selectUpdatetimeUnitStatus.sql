SELECT
    MAX(tusl.modified_on)
FROM
    ma_station ms

INNER JOIN ma_equip me
    ON me.st_id = ms.st_id

INNER JOIN ma_line ml
    ON ml.ln_id = ms.ln_id

INNER JOIN ma_process mpr
    ON mpr.process_id = ml.process_id

INNER JOIN ma_seizou_line msl
    ON msl.seizou_ln_id = mpr.seizou_ln_id

INNER JOIN  tr_unit_sts_log tusl
    ON tusl.st_id = ms.st_id
WHERE
    msl.plant_cd = /*comPlantCode*/'D0'
AND	msl.seizou_ln_id = /*comSeizouLnId*/1
AND	mpr.process_id = /*comProcessId*/1
AND	ms.ln_id = /*comLnId*/1
