SELECT
	t0.occur_time,
	t0.plant_cd,
	ma_plant.plant_nm,
	t0.seizou_ln_cd,
	t0.seizou_ln_nm,
	t0.ln_no,
	t0.ln_nm,
	t0.st_no,
	t0.step_no,
	t0.sasizu_no,
	t0.sub_no,
	t0.alm_cd,
	t0.repair_kaisu,
	COALESCE(t2.user_name, COALESCE('ID:' || t0.user_id, '')) as worker_name,
	COALESCE(REGEXP_REPLACE(t0.repair_comment, E'(\\r\\n|\\r|\\n|\\t)', ' ', 'g'), '') as repair_comment
FROM
	tr_repair_log t0
INNER JOIN
	ma_line t1
ON
--	t0.ln_no = t1.ln_no
--AND t0.ln_nm = t1.ln_nm
	t0.ln_id = t1.ln_id
LEFT OUTER JOIN
	ma_user t2
ON
		t0.user_id = t2.user_id
	AND	(
			t0.plant_cd = t2.plant_cd
		OR	t2.plant_cd = '##'
	)
INNER JOIN
	ma_plant
ON
		ma_plant.invalid_flag = 0
	AND	ma_plant.plant_cd = t0.plant_cd
INNER JOIN
	ma_plant_mieruka
ON
		ma_plant_mieruka.invalid_flag = 0
	AND ma_plant_mieruka.plant_cd = ma_plant.plant_cd
INNER JOIN
	ma_seizou_line
ON
		ma_seizou_line.plant_cd = t0.plant_cd
INNER JOIN
	ma_process
ON
	ma_process.seizou_ln_id = ma_seizou_line.seizou_ln_id
INNER JOIN
	ma_station
ON
	ma_station.ln_id = t1.ln_id
WHERE
		t0.plant_cd = /*comPlantCode*/''
	AND	ma_seizou_line.seizou_ln_id = /*comSeizouLnId*/''
	/*IF comProcessId != null*/
	AND	ma_process.process_id = /*comProcessId*/
	/*END*/
	/*IF comLnId != null*/
	AND	t1.ln_id = /*comLnId*/
	/*END*/
	/*IF comStId != null*/
	AND	ma_station.st_id = /*comStId*/
	/*END*/
	AND	t0.occur_time BETWEEN /*comDataDateFrom*/'' AND /*comDataDateTo*/''
	/*IF comSearchWord != null*/
	AND	(
			t0.sasizu_no LIKE /*comSearchWord*/''
		OR	to_char(t0.sub_no, 'FM999') LIKE /*comSearchWord*/''
		OR	t0.alm_cd LIKE /*comSearchWord*/''
	)
	/*END*/

ORDER BY
/*IF fw0114SortKey == null*/
	t0.occur_time DESC
/*END*/
/*IF fw0114SortKey == "hasseiDatetime"*/
	/*IF fw0114SortOrder == "asc"*/
	t0.occur_time ASC
	/*END*/
	/*IF fw0114SortOrder == "desc"*/
	t0.occur_time DESC
	/*END*/
/*END*/
/*IF fw0114SortKey == "plantCode"*/
	/*IF fw0114SortOrder == "asc"*/
	t0.plant_cd ASC
	,t0.occur_time DESC
	/*END*/
	/*IF fw0114SortOrder == "desc"*/
	t0.plant_cd ASC
	,t0.occur_time DESC
	/*END*/
/*END*/
/*IF fw0114SortKey == "seizouLineCd"*/
	/*IF fw0114SortOrder == "asc"*/
	t0.seizou_ln_cd ASC
	,t0.occur_time DESC
	/*END*/
	/*IF fw0114SortOrder == "desc"*/
	t0.seizou_ln_cd DESC
	,t0.occur_time DESC
	/*END*/
/*END*/
/*IF fw0114SortKey == "lineNo"*/
	/*IF fw0114SortOrder == "asc"*/
	t0.ln_no ASC
	,t0.occur_time DESC
	/*END*/
	/*IF fw0114SortOrder == "desc"*/
	t0.ln_no DESC
	,t0.occur_time DESC
	/*END*/
/*END*/
/*IF fw0114SortKey == "stationNo"*/
	/*IF fw0114SortOrder == "asc"*/
	t0.st_no ASC
	,t0.occur_time DESC
	/*END*/
	/*IF fw0114SortOrder == "desc"*/
	t0.st_no DESC
	,t0.occur_time DESC
	/*END*/
/*END*/
/*IF fw0114SortKey == "stepNo"*/
	/*IF fw0114SortOrder == "asc"*/
	t0.step_no ASC
	,t0.occur_time DESC
	/*END*/
	/*IF fw0114SortOrder == "desc"*/
	t0.step_no DESC
	,t0.occur_time DESC
	/*END*/
/*END*/
/*IF fw0114SortKey == "sasizuNo"*/
	/*IF fw0114SortOrder == "asc"*/
	t0.sasizu_no ASC
	,t0.occur_time DESC
	/*END*/
	/*IF fw0114SortOrder == "desc"*/
	t0.sasizu_no DESC
	,t0.occur_time DESC
	/*END*/
/*END*/
/*IF fw0114SortKey == "subNo"*/
	/*IF fw0114SortOrder == "asc"*/
	t0.sub_no ASC
	,t0.occur_time DESC
	/*END*/
	/*IF fw0114SortOrder == "desc"*/
	t0.sub_no DESC
	,t0.occur_time DESC
	/*END*/
/*END*/
/*IF fw0114SortKey == "alarmMode"*/
	/*IF fw0114SortOrder == "asc"*/
	t0.alm_cd ASC
	,t0.occur_time DESC
	/*END*/
	/*IF fw0114SortOrder == "desc"*/
	t0.alm_cd DESC
	,t0.occur_time DESC
	/*END*/
/*END*/
/*IF fw0114SortKey == "repairKaisu"*/
	/*IF fw0114SortOrder == "asc"*/
	t0.repair_kaisu ASC
	,t0.occur_time DESC
	/*END*/
	/*IF fw0114SortOrder == "desc"*/
	t0.repair_kaisu DESC
	,t0.occur_time DESC
	/*END*/
/*END*/
/*IF fw0114SortKey == "workerName"*/
	/*IF fw0114SortOrder == "asc"*/
	worker_name ASC
	,t0.occur_time DESC
	/*END*/
	/*IF fw0114SortOrder == "desc"*/
	worker_name DESC
	,t0.occur_time DESC
	/*END*/
/*END*/
/*IF fw0114SortKey == "repairComment"*/
	/*IF fw0114SortOrder == "asc"*/
	repair_comment ASC
	,t0.occur_time DESC
	/*END*/
	/*IF fw0114SortOrder == "desc"*/
	repair_comment DESC
	,t0.occur_time DESC
	/*END*/
/*END*/
/*IF fw0114CsvMaxSize != null*/
LIMIT /*fw0114CsvMaxSize*/
/*END*/
