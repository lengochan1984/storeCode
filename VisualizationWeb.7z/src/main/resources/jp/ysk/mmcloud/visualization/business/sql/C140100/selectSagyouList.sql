SELECT
    tr_work_step_jsk.step_no,
    ma_user.user_name AS worker_name,
    tr_work_step_jsk.start_time AS start_date_time,
    tr_work_step_jsk.end_time AS end_date_time
FROM
    tr_product_trc
INNER JOIN
    tr_work_step_jsk
ON
    tr_product_trc.sasizu_no = tr_work_step_jsk.sasizu_no
AND
    tr_product_trc.sub_no = tr_work_step_jsk.sub_no
AND
    tr_product_trc.sagyo_seq = tr_work_step_jsk.sagyo_seq

INNER JOIN
    ma_station
ON
    ma_station.st_id = tr_work_step_jsk.st_id

INNER JOIN
    ma_user
ON
    tr_work_step_jsk.user_id = ma_user.user_id

WHERE
    tr_work_step_jsk.plant_cd = /*comPlantCode*/''
AND
    tr_product_trc.seihin_sn = /*serialNumber*/''
AND
    ma_station.ln_id = /*lnId*/
AND
    tr_work_step_jsk.st_id = /*stId*/
ORDER BY
    tr_work_step_jsk.step_no ASC,
    ma_user.user_name ASC,
    tr_work_step_jsk.start_time ASC,
    tr_work_step_jsk.end_time ASC
