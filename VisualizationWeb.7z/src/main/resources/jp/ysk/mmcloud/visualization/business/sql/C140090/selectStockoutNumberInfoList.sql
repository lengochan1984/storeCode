SELECT
    nengetu,
    b_kepin_hinmoku,
    h_kepin_hinmoku
FROM
    tbl_erp_shortage_info_monthly
WHERE
        plant_code = /*comPlantCode*/
/*IF ctgrKubun == "01"*/
    AND	 kishu_ctgr01 = /*kisyuCtgr*/
/*END*/
/*IF ctgrKubun == "02"*/
    AND kishu_ctgr02 = /*kisyuCtgr*/
/*END*/
/*IF ctgrKubun == "00"*/
    AND (kishu_ctgr01 = '' AND kishu_ctgr02 = '')
/*END*/
    AND TO_CHAR(nengetu, 'yyyymm') BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/
