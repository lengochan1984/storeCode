DELETE
FROM tbl_api_auth_refreshtoken
WHERE
     tbl_api_auth_refreshtoken.user_id = /*userSid*/
