SELECT
  TRIM(to_char(date_part('day',ma_plant.running_start_datetime),'99')) as running_start_datetime,
  TRIM(to_char(date_part('year',now()),'9999')) as now_year,
  TRIM(to_char(date_part('month',now()),'99')) as now_month,
  TRIM(to_char(date_part('day',now()),'99')) as now_day
FROM
  ma_plant_mieruka
INNER JOIN
  ma_plant
ON
      ma_plant.invalid_flag = 0
  AND ma_plant.plant_cd = ma_plant_mieruka.plant_cd
WHERE
      ma_plant_mieruka.invalid_flag = 0
  AND ma_plant_mieruka.plant_cd = /*plantCode*/''
