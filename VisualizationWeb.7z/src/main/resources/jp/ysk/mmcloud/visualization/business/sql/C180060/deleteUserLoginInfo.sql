DELETE
FROM
    tbl_user_login_info
WHERE
    user_sid = /*userSid*/
