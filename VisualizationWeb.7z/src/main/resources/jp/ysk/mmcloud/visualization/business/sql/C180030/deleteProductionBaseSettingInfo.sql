DELETE
FROM
    ma_plant_mieruka
WHERE
    ma_plant_mieruka.plant_cd = /*plantCd*/
