SELECT
    date_trunc('month', nengetu) as data_date,
    COALESCE(round(todokebi_su / NULLIF(shuka_su,0) * 100.0, 3),0.00) as todokebi_percent,
    COALESCE(round(hyoujyun_su / NULLIF(shuka_su,0) * 100.0, 3),0.00) as hyoujyun_percent,
    COALESCE(round(youkyu_su / NULLIF(shuka_su,0) * 100.0, 3),0.00) as youkyu_percent
FROM (
    SELECT max(erp.nengetu) as nengetu,
        SUM(COALESCE(erp.todokebi_su,0)) as todokebi_su,
        SUM(COALESCE(erp.hyoujyun_su,0)) as hyoujyun_su,
        SUM(COALESCE(erp.youkyu_su,0)) as youkyu_su,
        COALESCE(SUM(COALESCE(erp.shuka_su,0)), 1) as shuka_su
    FROM tbl_erp_due_date_rating_monthly erp

    where erp.plant_code = /*comPlantCode*/

        /*IF categoryOne != null*/
        AND erp.kishu_ctgr01 = /*categoryOne*/
        /*END*/

        /*IF categoryTwo != null*/
        AND erp.kishu_ctgr02 = /*categoryTwo*/
        /*END*/

        /*IF searchOrderClient != null*/
        AND erp.jcskbn = /*searchOrderClient*/
        /*END*/

        AND TO_CHAR(erp.nengetu, 'yyyymm') BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/

        group by TO_CHAR(erp.nengetu, 'yyyymm')

) tem order by tem.nengetu asc
