SELECT
    t0.created_on,
    t0.created_by,
    t0.modified_on,
    t0.modified_by,
    t0.plant_cd,
    t0.ln_no,
    t0.ln_nm,
    get_sagyo_seq_name(t0.sagyo_seq, /*loginUserLangCd*/'') as sagyo_seq,
    t0.sasizu_no,
    t0.sub_no,
    t0.st_no,
    t0.st_nm,
    t0.equip_cd,
    t0.syain_no,
    t0.work_sta_time,
    t0.work_end_time,
    t0.hantei,
    t0.alm_cd,
    t0.sagyo_jyotai,
    t0.sagyoku_last_st,
    t0.repair_kaisu,
    t0.work_sta_step,
    t0.sagyoku,
    t0.process_cd,
    t0.work_time,
    t0.sousin_flag,
    t0.sousin_date,
    t0.ins_prog,
    t0.ins_tim,
    t0.ins_user_sid,
    t0.upd_prog,
    t0.upd_tim,
    t0.upd_user_sid
FROM
    tr_st_work_jsk  t0
INNER JOIN
    tr_sasizu_jsk   t1
ON
    t0.sasizu_no    = t1.sasizu_no
INNER JOIN
    ma_station   t2
ON
    t2.st_id = t0.st_id
WHERE
        t0.plant_cd = /*comPlantCode*/''
    /*IF comStId != null*/
    AND t0.st_id = /*comStId*/
    /*END*/
    AND EXISTS(
            SELECT
                ma_seizou_line.plant_cd,
                ma_line.ln_id,
                ma_seizou_line.seizou_ln_id
            FROM
                ma_line
            INNER JOIN
                ma_process
            ON
                ma_line.process_id = ma_process.process_id
            INNER JOIN
                ma_seizou_line
            ON
                ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id
            WHERE
                    ma_seizou_line.plant_cd     = /*comPlantCode*/''
                AND ma_seizou_line.seizou_ln_id = /*comSeizouLnId*/
                /*IF comLnId != null*/
                AND ma_line.ln_id               = /*comLnId*/
                /*END*/
                /*IF comProcessId != null*/
                AND ma_process.process_id       = /*comProcessId*/
                /*END*/
                AND ma_seizou_line.plant_cd     = t0.plant_cd
                AND ma_line.ln_id               = t2.ln_id
    )
    /*IF comStId != null*/
    AND EXISTS(
            SELECT
                ms.st_no
            FROM
                ma_station ms
            WHERE
                    t0.plant_cd     = /*comPlantCode*/''
                AND ms.ln_id        = /*comLnId*/
                AND ms.st_id        = /*comStId*/
                AND ms.st_id        = t0.st_id
    )
    /*END*/
    AND (
            (
                    t0.work_end_time >= /*comDataDateFrom*/
                AND t0.work_end_time <= /*comDataDateTo*/
            )
        OR  (
                    t0.work_end_time IS NULL
                AND t1.seisan_jyotai >= 0
                AND t1.seisan_jyotai <  90
            )
    )
     /*IF comSearchWord != null*/
    AND(
            t0.sasizu_no LIKE /*comSearchWord*/''
        OR  to_char(t0.sub_no, 'FM999') LIKE /*comSearchWord*/''
    )
    /*END*/
ORDER BY

/*IF fw0114SortKey == null*/
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
/*END*/

/*IF fw0114SortKey == 'createdOn'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.created_on ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.created_on DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'createdBy'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.created_by ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.created_by DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'modifiedOn'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.modified_on ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.modified_on DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'modifiedBy'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.modified_by ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.modified_by DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'plantCd'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.plant_cd ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.plant_cd DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'lnNm'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.ln_no ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.ln_no DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == 'sagyoSeq'*/
    /*IF fw0114SortOrder == "asc"*/
    sagyo_seq ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    sagyo_seq DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'sasizuNo'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.sasizu_no DESC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'subNo'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.sub_no DESC,
    t0.sasizu_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'stNm'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.st_nm ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.st_nm DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'equipCd'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.equip_cd ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.equip_cd DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'syainNo'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.syain_no ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.syain_no DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'workStaTime'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.work_sta_time ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.work_sta_time DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'workEndTime'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.work_end_time ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.work_end_time DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'hantei'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.hantei ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.hantei DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'almCd'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.alm_cd ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.alm_cd DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'sagyoJyotai'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.sagyo_jyotai ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.sagyo_jyotai DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'sagyokuLastSt'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.sagyoku_last_st ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.sagyoku_last_st DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'repairKaisu'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.repair_kaisu ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.repair_kaisu DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'workStaStep'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.work_sta_step ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.work_sta_step DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'sagyoku'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.sagyoku ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.sagyoku DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'processCd'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.process_cd ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.process_cd DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'workTime'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.work_time ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.work_time DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'sousinFlag'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.sousin_flag ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.sousin_flag DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/

/*IF fw0114SortKey == 'sousinDate'*/
    /*IF fw0114SortOrder == "asc"*/
    t0.sousin_date ASC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    t0.sousin_date DESC,
    t0.sasizu_no ASC,
    t0.sub_no ASC,
    t0.st_nm ASC,
    t0.modified_on ASC
    /*END*/
/*END*/
/*IF fw0114CsvMaxSize != null*/
LIMIT /*fw0114CsvMaxSize*/
/*END*/
