SELECT pie.error_cd ,pie.error_message, sum(pie.occurrence)
from(
SELECT
    alarm_analysis_data.mainResourceNo								AS equipment,
    alarm_analysis_data.errorCd										AS error_cd,
    alarm_analysis_data.errorMessage								AS error_message,
    alarm_analysis_data.occurCount									AS occurrence,
    alarm_analysis_data.recoveryTime								AS recovery_time,
    alarm_analysis_data.lastOccurDatetime							AS last_occurrence,
    alarm_analysis_data.plantName									AS plant_name,
    alarm_analysis_data.seizouLineName								AS seizou_line_name,
    alarm_analysis_data.processName									AS process_name,
    alarm_analysis_data.lineName									AS line_no,
    alarm_analysis_data.stNm										AS st_nm,
    alarm_analysis_data.sagyoku										AS sagyoku

FROM
(
    SELECT
        t0.plant_cd						AS plantCode,
        ma_plant.plant_nm				AS plantName,
        ma_seizou_line.seizou_ln_id		AS seizouLineId,
        ma_seizou_line.seizou_ln_nm		AS seizouLineName,
        /*IF comProcessId != null*/
        ma_process.process_id			AS processId,
        ma_process.process_nm			AS processName,
        --ELSE
        text '-'							AS processId,
        text '-'							AS processName,
        /*END*/
        /*IF comLnId != null*/
        t0.ln_nm							AS lineName,
        --ELSE
        text '-'							AS lineName,
        /*END*/
        /*IF comStId != null*/
        t0.st_nm							AS stNm,
        --ELSE
        text '-'							AS stNm,
        /*END*/
        /*IF unitErrorCd*/
        t0.alm_cd							AS errorCd,
        ma_equip_alm_cd.alm_msg	AS errorMessage,
        --ELSE
        text '-'							AS errorCd,
        text '-'							AS errorMessage,
        /*END*/
        /*IF unitEquipment*/
        t0.main_res_no						AS mainResourceNo,
        --ELSE
        text '-'							AS mainResourceNo,
        /*END*/
        SUM(t0.occur_count)					AS occurCount,
        TO_CHAR(MAX(t0.last_occur_datetime), 'YYYY/MM/DD HH24:MI:SS')	AS lastOccurDatetime,
        SUM(t0.recovery_time)				AS recoveryTime,
        t0.sagyoku							AS sagyoku

    FROM
        /*IF comDateType == 'jikanbetu'*/
        ag_alarm_analize_daily t0
        /*END*/
        /*IF comDateType == 'nitiji'*/
        ag_alarm_analize_monthly t0
        /*END*/
        /*IF comDateType == 'getuji'*/
        ag_alarm_analize_yearly t0	--年別テーブルは存在しないので、エラーとなる
        /*END*/

    INNER JOIN
        ma_plant
    ON
            ma_plant.invalid_flag = 0
        AND	ma_plant.plant_cd = t0.plant_cd

    INNER JOIN
        ma_plant_mieruka
    ON
            ma_plant_mieruka.invalid_flag = 0
        AND ma_plant_mieruka.plant_cd = ma_plant.plant_cd

    INNER JOIN
        ma_station
    ON
        ma_station.st_id = t0.st_id

    INNER JOIN
        ma_line
    ON
        ma_line.ln_id = ma_station.ln_id

    INNER JOIN
        ma_process
    ON
        ma_process.process_id = ma_line.process_id

    INNER JOIN
        ma_seizou_line
    ON
        ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id

    LEFT JOIN
        ma_equip
    ON
            ma_equip.plant_cd = t0.plant_cd
        --AND ma_equip.ln_no = t0.ln_no
        AND ma_equip.st_id = t0.st_id

    LEFT JOIN
        ma_equip_alm_cd
    ON
            ma_equip_alm_cd.alm_cd = t0.alm_cd
        AND	ma_equip_alm_cd.equip_cd = ma_equip.equip_cd

    WHERE
            t0.plant_cd = /*comPlantCode*/'D0'
        AND	ma_seizou_line.seizou_ln_id = /*comSeizouLnId*/1
        /*IF comProcessId != null*/
        AND	ma_process.process_id = /*comProcessId*/1
        /*END*/
        /*IF comLnId != null*/
        AND	ma_line.ln_id = /*comLnId*/1
        /*END*/
        /*IF comStId != null*/
        AND	t0.st_id = /*comStId*/1
        /*END*/
        AND	t0.data_date BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/
        /*IF comSearchWord != null*/
        AND (
                t0.alm_cd LIKE /*comSearchWord*/''
            OR	ma_equip_alm_cd.alm_msg LIKE /*comSearchWord*/''
        )
        /*END*/

    GROUP BY
        plantCode,
        plantName,
        seizouLineId,
        seizouLineName,
        /*IF comprocessId != null*/
        processId,
        processName,
        /*END*/
        /*IF comLnId != null*/
        lineName,
        /*END*/
        /*IF comStId != null*/
        stNm,
        /*END*/
        /*IF unitErrorCd*/
        errorCd,
        errorMessage,
        /*END*/
        /*IF unitEquipment*/
        mainResourceNo,
        /*END*/
        sagyoku

) alarm_analysis_data

ORDER BY
/*IF fw0114SortKey == null*/
    alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
/*END*/
/*IF fw0114SortKey == "equipment"*/
    /*IF fw0114SortOrder == "asc"*/
    alarm_analysis_data.mainResourceNo ASC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    alarm_analysis_data.mainResourceNo DESC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "errorCd"*/
    /*IF fw0114SortOrder == "asc"*/
    alarm_analysis_data.errorCd ASC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    alarm_analysis_data.errorCd DESC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "errorMessage"*/
    /*IF fw0114SortOrder == "asc"*/
    alarm_analysis_data.errorMessage ASC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    alarm_analysis_data.errorMessage DESC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "occurrence"*/
    /*IF fw0114SortOrder == "asc"*/
    alarm_analysis_data.occurCount ASC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    alarm_analysis_data.occurCount DESC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "recoveryTime"*/
    /*IF fw0114SortOrder == "asc"*/
    alarm_analysis_data.recoveryTime ASC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    alarm_analysis_data.recoveryTime DESC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "lastOccurrence"*/
    /*IF fw0114SortOrder == "asc"*/
    alarm_analysis_data.lastOccurDatetime ASC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    alarm_analysis_data.lastOccurDatetime DESC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "plantName"*/
    /*IF fw0114SortOrder == "asc"*/
    alarm_analysis_data.plantName ASC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    alarm_analysis_data.plantName DESC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "seizouLineName"*/
    /*IF fw0114SortOrder == "asc"*/
    alarm_analysis_data.seizouLineName ASC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    alarm_analysis_data.seizouLineName DESC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "processName"*/
    /*IF fw0114SortOrder == "asc"*/
    alarm_analysis_data.processName ASC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    alarm_analysis_data.processName DESC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "lineNo"*/
    /*IF fw0114SortOrder == "asc"*/
    alarm_analysis_data.lineName ASC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.stNm ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    alarm_analysis_data.lineName DESC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.stNm ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "stNm"*/
    /*IF fw0114SortOrder == "asc"*/
    alarm_analysis_data.stNm ASC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    alarm_analysis_data.stNm DESC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC
    /*END*/
/*END*/
/*IF fw0114SortKey == "sagyoku"*/
    /*IF fw0114SortOrder == "asc"*/
    alarm_analysis_data.sagyoku ASC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    alarm_analysis_data.sagyoku DESC, alarm_analysis_data.plantCode ASC, alarm_analysis_data.seizouLineId ASC, alarm_analysis_data.processId ASC, alarm_analysis_data.lineName ASC, alarm_analysis_data.stNm ASC
    /*END*/
/*END*/
/*IF unitEquipment*/
    , alarm_analysis_data.mainResourceNo ASC
/*END*/
/*IF unitErrorCd*/
    , alarm_analysis_data.errorCd ASC
/*END*/
/*IF fw0114CsvMaxSize != null*/
LIMIT /*fw0114CsvMaxSize*/
/*END*/
)pie
group by pie.error_cd, pie.error_message
order by sum(pie.occurrence) DESC