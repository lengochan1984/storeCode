SELECT
  h.plant_cd
  ,h.model_group_code
  ,ma_hinmoku.invalid_flag
  ,model_group.name_jp
  ,model_group.name_en
  ,model_group.name_zh
  ,model_group.display_order
  ,m.daily_plan_num
  ,m.daily_actual_num
  ,m.monthly_plan_num
  ,m.monthly_actual_num
FROM
  (
    SELECT
      COALESCE(RTRIM(ma_hinmoku.werks), '') AS plant_cd
      ,COALESCE(RTRIM(ma_hinmoku.vtext_info1), '') AS model_group_code
      ,COALESCE(RTRIM(ma_hinmoku.vtext_info2), '') AS model_group_name_key
    FROM
      ma_hinmoku
  ) AS h
  INNER JOIN
    (
      SELECT
        disp_order.signage_id
        ,disp_order.model_group_name_key
        ,disp_order.display_order
        ,multilang.name_jp
        ,multilang.name_en
        ,multilang.name_zh
      FROM
        (
          SELECT
            COALESCE(RTRIM(ma_sig_disp_order_model_series.signage_id), '') AS signage_id
            ,COALESCE(RTRIM(ma_sig_disp_order_model_series.vtext_info2), '') AS model_group_name_key
            ,ma_sig_disp_order_model_series.display_order
          FROM
            ma_sig_disp_order_model_series
        ) AS disp_order
        LEFT JOIN
          (
            SELECT
              COALESCE(RTRIM(ma_sig_multilang_model_series.signage_id), '') AS signage_id
              ,COALESCE(RTRIM(ma_sig_multilang_model_series.vtext_info2), '') AS model_group_name_key
              ,COALESCE(RTRIM(ma_sig_multilang_model_series.vtext_info2_jp), '') AS name_jp
              ,COALESCE(RTRIM(ma_sig_multilang_model_series.vtext_info2_en), '') AS name_en
              ,COALESCE(RTRIM(ma_sig_multilang_model_series.vtext_info2_zh), '') AS name_zh
            FROM
              ma_sig_multilang_model_series
          ) AS multilang
          ON
            multilang.signage_id = disp_order.signage_id
            AND
            multilang.model_group_name_key = disp_order.model_group_name_key
      WHERE
        disp_order.signage_id = /*signage_id*/''
        AND
        disp_order.model_group_name_key <> ''
    ) AS model_group
    ON
      model_group.model_group_name_key = h.model_group_name_key
  LEFT JOIN
    (
      SELECT
        COALESCE(RTRIM(signage_id), '') AS signage_id
        ,COALESCE(RTRIM(plant_cd), '') AS plant_cd
        ,display_order
      FROM
        ma_sig_disp_order_plant
    ) AS plant
    ON
      plant.signage_id = model_group.signage_id
      AND
      plant.plant_cd = h.plant_cd
  LEFT JOIN
    (
      SELECT
        h.plant_cd
        ,h.model_group_name_key
        ,sum(md.plan_num) AS daily_plan_num
        ,sum(md.actual_num) AS daily_actual_num
        ,sum(mm.plan_num) AS monthly_plan_num
        ,sum(mm.actual_num) AS monthly_actual_num
      FROM
        (
          SELECT
            *
          FROM
            (
              SELECT
                COALESCE(RTRIM(ma_hinmoku.werks), '') AS plant_cd
                ,COALESCE(RTRIM(ma_hinmoku.matnr), '') AS hinmoku_code
                ,COALESCE(RTRIM(ma_hinmoku.vtext_info2), '') AS model_group_name_key
              FROM
                ma_hinmoku
            ) AS htmp
          WHERE
            htmp.plant_cd <> ''
            AND
            htmp.hinmoku_code <> ''
            AND
            htmp.model_group_name_key <> ''
        ) AS h
        INNER JOIN
          (
            SELECT
              COALESCE(RTRIM(ma_plant_mieruka.plant_cd), '') AS plant_cd
              ,(
                date_trunc(
                  'days',
                  CAST(current_timestamp AS TIMESTAMP WITHOUT time zone)
                )
                + CAST(date_part('hour', ma_plant.running_start_datetime) || ' hours' AS INTERVAL)
                + CAST(date_part('minute', ma_plant.running_start_datetime) || ' minutes' AS INTERVAL)
                + CAST(date_part('second', ma_plant.running_start_datetime) || ' seconds' AS INTERVAL)
                    ) AS current_date_daily
                    ,(
                date_trunc(
                  'months',
                  CAST(current_timestamp AS TIMESTAMP WITHOUT time zone) - CAST(date_part('day', ma_plant.running_start_datetime) || ' days' AS INTERVAL)
                )
                + CAST(date_part('day', ma_plant.running_start_datetime) - 1 || ' days' AS INTERVAL)
                + CAST(date_part('hour', ma_plant.running_start_datetime) || ' hours' AS INTERVAL)
                + CAST(date_part('minute', ma_plant.running_start_datetime) || ' minutes' AS INTERVAL)
                + CAST(date_part('second', ma_plant.running_start_datetime) || ' seconds' AS INTERVAL)
              ) AS current_date_monthly
            FROM
              ma_plant_mieruka
            INNER JOIN
              ma_plant
            ON
                  ma_plant.invalid_flag = 0
              AND ma_plant.plant_cd = ma_plant_mieruka.plant_cd
            WHERE
              ma_plant_mieruka.invalid_flag = 0
          ) AS date_term
          ON
            date_term.plant_cd = h.plant_cd
        LEFT JOIN
          (
            SELECT
              COALESCE(RTRIM(plant_cd), '') AS plant_cd
              ,COALESCE(RTRIM(buhin_cd), '') AS hinmoku_code
              ,data_date
              ,plan_num
              ,actual_num
            FROM
              ds_product_mng_daily
          ) AS md
          ON
            md.plant_cd = h.plant_cd
            AND
            md.hinmoku_code = h.hinmoku_code
            AND
            md.data_date = date_term.current_date_daily
        LEFT JOIN
          (
            SELECT
              COALESCE(RTRIM(plant_cd), '') AS plant_cd
              ,COALESCE(RTRIM(buhin_cd), '') AS hinmoku_code
              ,data_date
              ,plan_num
              ,actual_num
            FROM
              ds_product_mng_monthly
          ) AS mm
          ON
            mm.plant_cd = h.plant_cd
            AND
            mm.hinmoku_code = h.hinmoku_code
            AND
            mm.data_date = date_term.current_date_monthly
      GROUP BY
        h.plant_cd
        ,h.model_group_name_key
    ) AS m
    ON
      m.plant_cd = h.plant_cd
      AND
      m.model_group_name_key = h.model_group_name_key
WHERE
  h.plant_cd = plant.plant_cd
  AND
  h.model_group_name_key = model_group.model_group_name_key
GROUP BY
  h.plant_cd
  ,h.model_group_code
  ,h.model_group_name_key
  ,ma_hinmoku.invalid_flag
  ,plant.display_order
  ,model_group.display_order
  ,model_group.name_jp
  ,model_group.name_en
  ,model_group.name_zh
  ,m.daily_plan_num
  ,m.daily_actual_num
  ,m.monthly_plan_num
  ,m.monthly_actual_num
ORDER BY
  plant.display_order
  ,model_group.display_order
