select
    ma_line.ln_id,
    vert_page_pos,
    hori_page_pos,
    vert_frame_pos,
    hori_frame_pos,
    disp_allow1_enable,
    disp_allow2_enable,
    disp_allow3_enable,
    layout_id
from
    tr_line_layout
inner join
    ma_line
on
    ma_line.ln_id = tr_line_layout.ln_id
inner join
    ma_process
on
    ma_process.process_id = ma_line.process_id
inner join
    ma_seizou_line
on
    ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id
where
    ma_seizou_line.plant_cd = /*comPlantCode*/'S'
    and ma_seizou_line.seizou_ln_id = /*comSeizouLnId*/1
order by
    hori_page_pos asc, vert_page_pos asc, hori_frame_pos asc, vert_frame_pos asc
