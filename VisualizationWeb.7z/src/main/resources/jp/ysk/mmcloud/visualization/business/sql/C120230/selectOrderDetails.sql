select
    tr_sasizu_info.sasizu_no, --指図番号
    tr_product_trc.sub_no, -- 副番
    tr_sasizu_info.katasiki, --型式
    tr_product_trc.seisan_jyotai, --状況
    tr_sasizu_info.order_no, --オーダー番号
    tr_sasizu_info.sagyo_sta_bi, -- 開始日
    tr_sasizu_info.kan_yotei_bi, --終了日
    -- 予定開始日時 plan_start_date
    -- 予定終了日時 plan_end_date
    '2017/12/02' AS plan_start_date,
    '2017/12/03' AS plan_end_date,
    tr_product_trc.start_date as actual_start_date, -- 実績開始日時
    tr_product_trc.end_date as actual_end_date, -- 実績終了日時
    -- ライン
    tr_line_work_jsk.ln_no as line_no,
    -- ユニット
    tr_st_work_jsk.st_no,
    --tr_st_tm_info.st_no || '～' || tr_st_tm_info.n_ln_no AS n_ln_no,
    -- 指図平行区分
    tr_st_work_jsk.sagyo_seq as sagyo_seq,
    --tr_st_tm_info.sagyo_seq as sagyo_seq2,
    -- 進度
    '遅延' as status,
    --Others
    tr_st_tm_info.sagyo_keka
from
    tr_sasizu_info
INNER JOIN
    tr_product_trc
ON
    tr_product_trc.sasizu_no = tr_sasizu_info.sasizu_no
inner join
    tr_st_work_jsk
on
    tr_st_work_jsk.sasizu_no = tr_product_trc.sasizu_no
    AND tr_st_work_jsk.sub_no = tr_product_trc.sub_no
    AND tr_st_work_jsk.sagyo_seq = tr_product_trc.sagyo_seq
inner join
    tr_st_tm_info
on
    tr_st_tm_info.sasizu_no = tr_product_trc.sasizu_no
    AND tr_st_tm_info.sub_no = tr_product_trc.sub_no
    AND tr_st_tm_info.sagyo_seq = tr_product_trc.sagyo_seq
inner join
    tr_line_work_jsk
on
    tr_line_work_jsk.sasizu_no = tr_product_trc.sasizu_no
    AND tr_line_work_jsk.sub_no = tr_product_trc.sub_no
    AND tr_line_work_jsk.sagyo_seq = tr_product_trc.sagyo_seq
inner join
    ma_line
on
    ma_line.ln_id = tr_line_work_jsk.ln_id
where
    tr_sasizu_info.sasizu_no='001234500001'