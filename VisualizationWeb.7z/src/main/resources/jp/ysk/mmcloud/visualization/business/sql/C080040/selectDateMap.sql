SELECT
  to_char(now() - mst_signage.daily_ope_time_period * interval '1 days','yyyy/MM/dd') as daily_start_date,
  to_char(now() - interval '1 days','yyyy/MM/dd') as daily_end_date
FROM mst_signage
WHERE mst_signage.signage_id = /*signageId*/''
