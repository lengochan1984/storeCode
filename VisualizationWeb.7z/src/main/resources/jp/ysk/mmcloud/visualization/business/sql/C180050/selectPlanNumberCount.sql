SELECT
    tr_seihin_plan_manual_setting.plan_num
FROM
    tr_seihin_plan_manual_setting
INNER JOIN
	ma_line
ON
	tr_seihin_plan_manual_setting.ln_id = ma_line.ln_id
INNER JOIN
	ma_process
ON
	ma_line.process_id = ma_process.process_id
INNER JOIN
	ma_seizou_line
ON
	ma_process.seizou_ln_id = ma_seizou_line.seizou_ln_id
INNER JOIN
	ma_plant
ON
	ma_seizou_line.plant_cd = ma_plant.plant_cd
WHERE
    ma_plant.plant_cd = /*plantCd*/
AND
    tr_seihin_plan_manual_setting.data_date = /*dataDate*/
	/*IF seizouLnId != null*/
AND
    ma_seizou_line.seizou_ln_id = cast(/*seizouLnId*/ as numeric)
	/*END*/
/*IF lineIdList != null*/
AND
    cast(tr_seihin_plan_manual_setting.ln_id as character) in /*lineIdList*/('123')
/*END*/

/*IF lnId != null*/
AND 
	cast(tr_seihin_plan_manual_setting.ln_id as varchar) = /*lnId*/
/*END*/