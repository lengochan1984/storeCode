DELETE
FROM
    mst_mail_address
WHERE
    sid = /*sid*/
