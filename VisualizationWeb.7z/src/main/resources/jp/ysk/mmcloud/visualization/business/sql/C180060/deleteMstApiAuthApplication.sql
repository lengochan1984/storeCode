DELETE
FROM mst_api_auth_application
WHERE
     mst_api_auth_application.user_id = /*userSid*/
