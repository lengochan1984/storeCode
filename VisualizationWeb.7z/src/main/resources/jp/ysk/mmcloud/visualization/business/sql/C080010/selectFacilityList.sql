-- 拠点情報(表示データ以外)の項目を取得
SELECT
  plant.plant_code
  ,plant.invalid_flag
  ,plant.plant_nm AS name_jp
  ,plant.latitude
  ,plant.longitude
  ,disp_order_p.display_order
FROM
  (
    -- 工場マスタから表示順序以外の項目を取得
    SELECT
      COALESCE(RTRIM(ma_plant.plant_cd), '') AS plant_code
      ,ma_plant.invalid_flag
      ,ma_plant.plant_nm
      ,ma_plant.latitude
      ,ma_plant.longitude
    FROM
      ma_plant
    INNER JOIN
      ma_plant_mieruka
    ON
          ma_plant_mieruka.invalid_flag = 0
      AND ma_plant_mieruka.plant_cd = ma_plant.plant_cd
    WHERE
      -- 空白の工場コード以外を取得
      ma_plant.plant_cd <> ''
  ) AS plant
  -- 工場マスタと結合(工場コードが一致)
  INNER JOIN
    (
      -- サイネージ表示順序（工場別）
      -- 拠点情報(工場)の表示順序を取得
      SELECT
        COALESCE(RTRIM(signage_id), '') AS signage_id
        ,COALESCE(RTRIM(plant_cd), '') AS plant_code
        ,display_order
      FROM
        ma_sig_disp_order_plant
    ) AS disp_order_p
    ON
      disp_order_p.plant_code = plant.plant_code
WHERE
  disp_order_p.signage_id = /*signage_id*/''
  AND
  plant.plant_code = disp_order_p.plant_code
-- 拠点情報の表示順序で昇順にソート
-- ※JSONデータ生成時に必要
ORDER BY
  display_order
