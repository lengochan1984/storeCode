-- 表示データ（日別・月別・年別実績以外）の項目を取得
-- ※工場コードはJSONデータ生成時の比較処理で必要
-- ※キー項目を取得する際、スペースはトリムする
SELECT
  h.plant_code
  ,h.model_group_code
  ,model_group.name_jp
  ,model_group.name_en
  ,model_group.name_zh
  ,model_group.display_order
FROM
  (
    -- 品目マスタから工場コード、製品グループ名を取得
    -- ※製品グループ名をサイネージマスタの設定値で切替可能（将来の要望）
    SELECT
      COALESCE(RTRIM(mst_hinmoku.plant_code), '') AS plant_code
      -- 製品グループ名にシリーズ名を設定
      /*IF groupSummaryKind == "01"*/
      ,COALESCE(RTRIM(mst_hinmoku.vtext_info2), '') AS model_group_code
      /*END*/
      -- 製品グループ名に機種群名を設定
      /*IF groupSummaryKind == "02"*/
      ,COALESCE(RTRIM(mst_hinmoku.vtext_info1), '') AS model_group_code
      /*END*/
    FROM
      mst_hinmoku
  ) AS h
  -- 品目マスタと結合（製品グループ名と一致）
  INNER JOIN
    (
      -- サイネージ表示順序、サイネージ多言語表示から、製品グループの表示順序・各国語の名称を取得
      -- ※取得するマスタをサイネージマスタの設定値で切替可能（将来の要望に対する対応）
      SELECT
        disp_order.signage_id
        ,disp_order.model_group_code
        ,disp_order.display_order
        ,multilang.name_jp
        ,multilang.name_en
        ,multilang.name_zh
      FROM
        (
          -- 表示データの表示順序を取得
          SELECT
            -- サイネージ表示順序（シリーズ別）から取得
            /*IF groupSummaryKind == "01"*/
            COALESCE(RTRIM(mst_sig_disp_order_model_series.signage_id), '') AS signage_id
            ,COALESCE(RTRIM(mst_sig_disp_order_model_series.model_series_name), '') AS model_group_code
            ,mst_sig_disp_order_model_series.display_order
            /*END*/
            -- サイネージ表示順序（機種群別）から取得
            /*IF groupSummaryKind == "02"*/
            COALESCE(RTRIM(mst_sig_disp_order_model_group.signage_id), '') AS signage_id
            ,COALESCE(RTRIM(mst_sig_disp_order_model_group.model_group_name), '') AS model_group_code
            ,mst_sig_disp_order_model_group.display_order
            /*END*/
          FROM
            -- サイネージ表示順序（シリーズ別）から取得
            /*IF groupSummaryKind == "01"*/
            mst_sig_disp_order_model_series
            /*END*/
            -- サイネージ表示順序（機種群別）から取得
            /*IF groupSummaryKind == "02"*/
            mst_sig_disp_order_model_group
            /*END*/
        ) AS disp_order
        -- サイネージ表示順序と結合(サイネージIDと工場コードが一致）
        LEFT JOIN
          (
            -- 表示データの各国語名称を取得
            SELECT
            -- サイネージ多言語表示（シリーズ別）から取得
              /*IF groupSummaryKind == "01"*/
              COALESCE(RTRIM(mst_sig_multilang_model_series.signage_id), '') AS signage_id
              ,COALESCE(RTRIM(mst_sig_multilang_model_series.model_series_name), '') AS model_group_code
              ,COALESCE(RTRIM(mst_sig_multilang_model_series.model_series_name_jp), '') AS name_jp
              ,COALESCE(RTRIM(mst_sig_multilang_model_series.model_series_name_en), '') AS name_en
              ,COALESCE(RTRIM(mst_sig_multilang_model_series.model_series_name_zh), '') AS name_zh
              /*END*/
              -- サイネージ多言語表示（機種群別）から取得
              /*IF groupSummaryKind == "02"*/
              COALESCE(RTRIM(mst_sig_multilang_model_group.signage_id), '') AS signage_id
              ,COALESCE(RTRIM(mst_sig_multilang_model_group.model_group_name), '') AS model_group_code
              ,COALESCE(RTRIM(mst_sig_multilang_model_group.model_group_name_jp), '') AS name_jp
              ,COALESCE(RTRIM(mst_sig_multilang_model_group.model_group_name_en), '') AS name_en
              ,COALESCE(RTRIM(mst_sig_multilang_model_group.model_group_name_zh), '') AS name_zh
              /*END*/
            FROM
            -- サイネージ多言語表示（シリーズ別）から取得
              /*IF groupSummaryKind == "01"*/
              mst_sig_multilang_model_series
              /*END*/
              -- サイネージ多言語表示（機種群別）から取得
              /*IF groupSummaryKind == "02"*/
              mst_sig_multilang_model_group
              /*END*/
          ) AS multilang
          ON
            multilang.signage_id = disp_order.signage_id
            AND
            multilang.model_group_code = disp_order.model_group_code
      WHERE
        disp_order.signage_id = /*signage_id*/''
        AND
        disp_order.model_group_code <> ''
    ) AS model_group
    ON
      model_group.model_group_code = h.model_group_code
  -- 表示データ(品目マスタ他)と結合（サイネージIDと工場コードが一致）
  LEFT JOIN
    (
      -- 拠点情報(工場)の表示順序を取得
      -- ※ソートで使用
      SELECT
        COALESCE(RTRIM(signage_id), '') AS signage_id
        ,COALESCE(RTRIM(plant_code), '') AS plant_code
        ,display_order
      FROM
        mst_sig_disp_order_plant
    ) AS plant
    ON
      plant.signage_id = model_group.signage_id
      AND
      plant.plant_code = h.plant_code
WHERE
  h.plant_code = plant.plant_code
  AND
  h.model_group_code = model_group.model_group_code
-- 品目マスタを元にしているため、同じ製品グループのデータが複数件出力されるので、サマリする
GROUP BY
  h.plant_code
  ,h.model_group_code
  ,plant.display_order
  ,model_group.display_order
  ,model_group.name_jp
  ,model_group.name_en
  ,model_group.name_zh
-- 拠点情報の表示順序、表示データの表示順序の昇順でソート
-- ※JSONデータ生成時の比較処理で必要
ORDER BY
  plant.display_order
  ,model_group.display_order
