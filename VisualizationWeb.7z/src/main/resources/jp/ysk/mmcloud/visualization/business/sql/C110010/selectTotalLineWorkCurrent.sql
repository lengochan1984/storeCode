SELECT
    SUM(plant_work_current.schedule_num) schedule_num,
    SUM(plant_work_current.actual_num) actual_num,
    SUM(plant_work_current.plan_num) plan_num
FROM
    (
    SELECT
        ag_line_work_current.ln_id,
        CASE ag_line_work_current.schedule_num
            WHEN -1 THEN NULL ELSE ag_line_work_current.schedule_num END schedule_num,
        CASE ag_line_work_current.actual_num
            WHEN -1 THEN NULL ELSE ag_line_work_current.actual_num END actual_num,
        CASE ag_line_work_current.plan_num
            WHEN -1 THEN NULL ELSE ag_line_work_current.plan_num END plan_num
    FROM
        ag_line_work_current ag_line_work_current
    INNER JOIN ma_line
    ON ag_line_work_current.ln_id = ma_line.ln_id
    INNER JOIN
        ma_process
    ON
        ma_process.process_id = ma_line.process_id
   WHERE
       ma_process.seizou_ln_id = /*comSeizouLnId*/1
    ) plant_work_current
