select
    a.sasizu_no,
    a.keikaku_num,
    a.yobi1 as jisseki_num,
    a.first_end_date,
    a.last_end_date,
    (select x.name from sys_env x where env_cd = 'v_element_color' and x.item_cd = to_char((b.color_no%10)+1, 'FM99')) as sasizuColor,
    a.first_end_jisseki_date,
    a.last_end_jisseki_date

from
    tbl_sasizu_sinchoku_data	a
left outer join
    mst_line							a1
on
    a1.plant_code			=		a.plant_code
and	a1.seizou_line_cd	=		a.seizou_line_cd
and	a1.line_no				=		a.line_no
,
tbl_sasizu_sinchoku_color_no	b

where
        a.plant_code			=		/*plantCode*/''
and	a1.process_code	=		/*processCode*/''
and	a.line_no				=		/*lineNo*/''
and	a.last_end_date		>=	/*progressDateFrom*/''::timestamp
and	a.first_end_date		<=	/*progressDateTo*/''::timestamp
and	a.plant_code			=		b.plant_code
and	a.sasizu_no			= 		b.sasizu_no

order by
    first_end_date

