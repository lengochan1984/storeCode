UPDATE
    tr_seihin_plan_manual_setting
SET
    ln_id = /*lnId*/,
    vtext_info1 = /*vtextInfo1*/,
    upd_prog = /*updProg*/,
    upd_user_sid = /*updUserSid*/,
    upd_tim = /*updTim*/,
    plan_num = /*planNum*/,
    last_line_flag = /*lastLineFlag*/
WHERE
    sid = /*sid*/
