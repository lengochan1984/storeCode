SELECT
  *
  ,(
    date_trunc(
      'days',
      CAST(current_timestamp AS TIMESTAMP WITHOUT time zone) - CAST('1 months' AS INTERVAL) + CAST('1 days' AS INTERVAL)
    )
  ) AS leadtime_start_date
  ,(
    date_trunc(
      'days',
      CAST(current_timestamp AS TIMESTAMP WITHOUT time zone)
    )
  ) AS leadtime_end_date
FROM
  mst_signage
WHERE
  signage_id = /*signage_id*/''
