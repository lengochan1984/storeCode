SELECT
    name
FROM
    sys_env

WHERE
    env_cd = /*envCd*/
ORDER BY
    display_order