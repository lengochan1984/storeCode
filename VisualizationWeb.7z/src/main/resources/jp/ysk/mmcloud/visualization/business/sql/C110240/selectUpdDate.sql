SELECT
    MAX(ma_station.modified_on) AS add_date
FROM
    ma_station
INNER JOIN ma_line ON
    ma_station.ln_id = ma_line.ln_id
INNER JOIN ma_process ON
    ma_line.process_id = ma_process.process_id
INNER JOIN ma_seizou_line ON
    ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id

WHERE
/*IF comSeizouLnId != null*/
    ma_seizou_line.seizou_ln_id = /*comSeizouLnId*/1
/*END*/
/*IF comProcessId != null*/
    AND
    ma_process.process_id = /*comProcessId*/1
/*END*/
/*IF comLnId != null*/
    AND
    ma_line.ln_id = /*comLnId*/1
/*END*/
/*IF comStId != null*/
    AND
    ma_station.st_id = /*comStId*/1
/*END*/