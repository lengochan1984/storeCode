SELECT
	tr_equip_alm_jsk.st_no,
	tr_equip_alm_jsk.occured_on,
	tr_equip_alm_jsk.recovered_on,
--	tr_equip_alm_jsk.sagyo_sts,
	(CASE WHEN tr_equip_alm_jsk.recovered_on IS NULL
		THEN 1
		ELSE 0 END) AS sagyo_sts,
	tr_equip_alm_jsk.alm_cd,
	ma_equip_alm_cd.alm_msg
FROM
	tr_equip_alm_jsk
INNER JOIN
	ma_equip_alm_cd
ON
	ma_equip_alm_cd.alm_cd = tr_equip_alm_jsk.alm_cd
WHERE
	tr_equip_alm_jsk.plant_cd = /*comPlantCode*/
/*IF comStId != null*/
AND
	tr_equip_alm_jsk.st_id = /*comStId*/
/*END*/
AND
	tr_equip_alm_jsk.occured_on >= /*comDataDateFrom*/
AND
	tr_equip_alm_jsk.occured_on <= /*comDataDateTo*/
ORDER BY
	tr_equip_alm_jsk.st_no,
	tr_equip_alm_jsk.occured_on
