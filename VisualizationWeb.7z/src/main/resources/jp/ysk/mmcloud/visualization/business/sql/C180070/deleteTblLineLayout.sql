delete from
    tr_line_layout
using
    ma_line,
    ma_process
where
    ma_line.ln_id = tr_line_layout.ln_id
    and ma_process.process_id = ma_line.process_id
    and ma_process.seizou_ln_id = /*comSeizouLnId*/1
/*IF hdnPageExchangeFlag != "1"*/
        and tr_line_layout.hori_page_pos = /*matrixPageX*/1
        and tr_line_layout.vert_page_pos = /*matrixPageY*/1
/*END*/
