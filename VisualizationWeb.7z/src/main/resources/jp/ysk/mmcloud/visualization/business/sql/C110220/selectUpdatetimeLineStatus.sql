SELECT
    MAX(tlsl.modified_on)
FROM
    tr_line_sts_log tlsl
INNER JOIN ma_line ml
    ON tlsl.ln_id = ml.ln_id
INNER JOIN ma_process mp
    ON mp.process_id = ml.process_id
INNER JOIN ma_seizou_line msl
    ON msl.seizou_ln_id = mp.seizou_ln_id
WHERE
        msl.plant_cd = /*comPlantCode*/
AND msl.seizou_ln_id = /*comSeizouLnId*/