select
    mst_role.name_item_cd,
    mst_name.name,
    mst_role.sid
from
    rel_user_role
inner join
    mst_role
on
    rel_user_role.role_sid = mst_role.sid and
    mst_role.delete_flag = false
left outer join
    mst_name
on
    mst_name.name_type = 'role_name' and
    mst_role.name_item_cd = mst_name.item_cd and
    mst_name.lang_cd = /*lang_cd*/'cd' and
    mst_name.delete_flag = false
where
/*IF user_sid != -1*/
    rel_user_role.user_sid = /*user_sid*/1 and
/*END*/
    rel_user_role.delete_flag = false
order by mst_role.display_order asc, mst_role.role_name asc