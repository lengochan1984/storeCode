SELECT
    item_id,
    item_label
FROM
     ma_list_item
 WHERE
     page_id= /*pageId*/
 AND
     plant_cd=/*comPlantCode*/
 AND
     disp_type=1
 ORDER BY
    disp_order