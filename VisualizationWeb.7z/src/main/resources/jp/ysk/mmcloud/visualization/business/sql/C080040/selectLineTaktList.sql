SELECT
  round(CAST(tbl_ds_takt_cycle.takt_time as NUMERIC) / 60 / 1000,1) as takt_time,
  round(CAST(tbl_ds_takt_cycle.cycle_time as NUMERIC) /60 / 1000,1) as cycle_time
FROM
  tbl_ds_takt_cycle
WHERE
  tbl_ds_takt_cycle.plant_code = /*plantCode*/
AND
  tbl_ds_takt_cycle.line_no = /*lineNo*/
AND
  tbl_ds_takt_cycle.end_datetime between (to_timestamp(/*startDate*/,'YYYY-MM-DD HH24:MI:SS.MS')) and (to_timestamp(/*endDate*/,'YYYY-MM-DD HH24:MI:SS.MS'))
ORDER BY tbl_ds_takt_cycle.end_datetime desc
LIMIT 40
