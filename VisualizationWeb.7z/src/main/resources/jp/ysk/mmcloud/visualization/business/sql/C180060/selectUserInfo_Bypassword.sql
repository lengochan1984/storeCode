select
    mst_user.sid,
    mst_user.id,
    mst_user.user_lastname,
    mst_user.user_firstname,
    mst_user.user_lastname_kana,
    mst_user.user_firstname_kana,
    mst_user.user_auth_cd,
    mst_user.passwd,
    mst_user.timezone_cd,
    mst_user.lang_cd,
    mst_user.theme_color_cd,
    mst_user.clock_disp_flag,
    mst_user.char_size,
    mst_user.invalid_flag,
    mst_user.exp_tim
from
    mst_user
where
    mst_user.id = /*user_id*/
and mst_user.passwd = /*password*/
