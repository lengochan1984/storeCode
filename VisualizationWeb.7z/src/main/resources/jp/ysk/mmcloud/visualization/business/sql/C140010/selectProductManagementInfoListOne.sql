SELECT
    MAX(DT.data_date) as data_date,
    SUM(DT.plan_the_day_num) as plan_the_day_num,
    SUM(DT.plan_before_the_day_num) as plan_before_the_day_num,
    SUM(DT.plan_before_two_days_num) as plan_before_two_days_num,
    SUM(DT.actual_the_day_num) as actual_the_day_num,
    SUM(DT.plan_monthly_num) as plan_monthly_num,
    --SUM(DT.plan_zaikan_num) as plan_zaikan_num,
    --SUM(DT.plan_stockout_num) as plan_stockout_num,
    SUM(DT.actual_the_day_num) as actual_num
FROM (
SELECT
    tpm.data_date AS data_date,
    CASE tpm.plan_the_day_num WHEN -1 THEN NULL ELSE tpm.plan_the_day_num END as plan_the_day_num,
    CASE tpm.plan_before_the_day_num WHEN -1  THEN NULL ELSE tpm.plan_before_the_day_num END as plan_before_the_day_num,
    CASE tpm.plan_before_two_days_num WHEN -1  THEN NULL ELSE tpm.plan_before_two_days_num END as plan_before_two_days_num,
    CASE tpm.actual_the_day_num  WHEN -1  THEN NULL ELSE tpm.actual_the_day_num END as actual_the_day_num,
    (CASE WHEN tpm.plan_the_day_num = -1 AND tpm.plan_before_the_day_num = -1 AND tpm.plan_before_two_days_num = -1 THEN NULL ELSE
     (CASE tpm.plan_the_day_num WHEN -1 THEN 0 ELSE tpm.plan_the_day_num END +
      CASE tpm.plan_before_the_day_num WHEN -1	THEN 0 ELSE tpm.plan_before_the_day_num END +
      CASE tpm.plan_before_two_days_num WHEN -1  THEN 0 ELSE tpm.plan_before_two_days_num END) END) as plan_monthly_num
    --CASE tpm.plan_monthly_num  WHEN -1 THEN  NULL ELSE tpm.plan_monthly_num END as plan_monthly_num,
    --CASE tpm.plan_zaikan_num WHEN -1  THEN NULL ELSE tpm.plan_zaikan_num END as plan_zaikan_num,
    --CASE tpm.plan_stockout_num WHEN -1	THEN NULL ELSE tpm.plan_stockout_num END as plan_stockout_num
FROM
    /*IF comDateType == 'jikanbetu'*/
    ag_product_mng_hourly tpm
    /*END*/
    /*IF comDateType == 'nitiji'*/
    ag_product_mng_daily tpm
    /*END*/
    /*IF comDateType == 'getuji'*/
    ag_product_mng_monthly tpm
    /*END*/
	/*IF comLnId != null && comProcessId != null*/
    INNER JOIN
        ma_line mlg
    ON (
            tpm.ln_id = mlg.ln_id
        AND	tpm.ln_no = mlg.ln_no
    )
    /*END*/
WHERE
    /*IF comLnId != null && comProcessId != null*/
	    mlg.ln_id = /*comLnId*/
    --ELSE
		tpm.ln_id = -1
    /*END*/
    AND	tpm.st_id = -1
    /*IF buhin_cd != null*/
    AND	tpm.buhin_cd = /*buhin_cd*/
    /*END*/
    /*IF kishugun_name != null*/
    AND	tpm.vtext_info1 = /*kishugun_name*/
    /*END*/
    /*IF series_name != null*/
    AND	tpm.vtext_info2 = /*series_name*/
    /*END*/
    AND	tpm.data_date BETWEEN /*comDataDateFrom*/ AND /*comDataDateTo*/
    AND	tpm.plant_cd = /*comPlantCode*/
) DT
GROUP BY
    DT.data_date
ORDER BY
    DT.data_date
