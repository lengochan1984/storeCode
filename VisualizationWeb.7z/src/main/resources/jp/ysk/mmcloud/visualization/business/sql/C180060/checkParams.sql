
SELECT
    count(mst_user.sid)

FROM
    mst_user

INNER JOIN
    rel_user_group ON mst_user.sid = rel_user_group.user_sid

INNER JOIN
    mst_group ON rel_user_group.group_id = mst_group.group_id AND
    mst_group.tree_path <@
        (SELECT
            mst_group.tree_path
        FROM
            mst_group

        INNER JOIN
            rel_user_group ON mst_group.group_id = rel_user_group.group_id
        WHERE
            rel_user_group.user_sid = /*LoginUserSid*/1)

WHERE
    mst_user.sid = /*sid*/

