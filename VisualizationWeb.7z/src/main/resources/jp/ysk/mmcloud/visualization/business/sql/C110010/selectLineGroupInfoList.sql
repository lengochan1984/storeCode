SELECT
    line_group_data.ln_id,                                                              	 /** ラインID */
    line_group_data.ln_no,                                                              	 /** ライングループ番号 */
    COALESCE(line_group_data.ln_nm, line_group_data.min_line_no) ln_nm,      		/** ライングループ名 */
    line_group_data.plant_cd,                                            					/** 工場コード*/
    process_info.process_cd,                                                                   /** 工程コード */
    process_info.process_seq,                                                                     /** 工程順序 */
    line_group_data.line_status_frame line_status_frame_code,                                    /** ライン状態(枠) */
    line_group_data.line_status_icon line_status_icon_code,                                      /** ライン状態(アイコン) */
    line_group_data.line_retention_before line_retention_before,                                 /** ライン前滞留閾値 */
    line_group_data.line_retention_inside line_retention_inside,                                 /** ライン内滞留閾値 */
    line_group_data.line_retention_after line_retention_after,                                   /** ライン後滞留閾値 */
    line_group_data.schedule_num schedule_num,                                                   /** 予定数 */
    line_group_data.actual_num actual_num,                                                       /** 実績数 */
    line_group_data.plan_num plan_num,                                                           /** 計画数 */
    line_group_data.pre_retention_num pre_retention_num,                                         /** ライン前の滞留数 */
    line_group_data.retention_num retention_num,                                                 /** ライン内の滞留数 */
    line_group_data.after_retention_num after_retention_num,                                     /** ライン後の滞留数 */
    line_group_data.spare_text1,                                                                 /** 文字予備1 **/
    tr_line_layout.hori_frame_pos AS position_x,                                                /** 横フレーム位置 **/
    tr_line_layout.vert_frame_pos AS position_y,                                                /** 縦フレーム位置 **/
    tr_line_layout.vert_page_pos,                                                               /** 縦ページ位置 */
    tr_line_layout.hori_page_pos,                                                               /** 横ページ位置 */
    tr_line_layout.disp_allow1_enable,                                                          /** 矢印表示有効/無効 **/
    tr_line_layout.disp_allow2_enable,                                                          /** 矢印表示有効/無効 **/
    tr_line_layout.disp_allow3_enable,                                                          /** 矢印表示有効/無効 **/
    ma_line_layout.hori_frame_num,                                                              /** 横フレーム数 **/
    ma_line_layout.vert_frame_num                                                               /** 縦フレーム数 **/

FROM
    (SELECT
        line_status_data.ln_id,                                                					/** ライン番号*/
        line_status_data.ln_no,                                                      		   /** ライングループ番号 */
        line_status_data.ln_nm,											  		  			   /** ライングループ名 */
        line_status_data.plant_cd,                                                             /** 工場コード*/
        line_status_data.seizou_ln_id,                                        					/** 製造ラインコード*/
        line_status_data.spare_text1,                                          				   /** 文字予備1 **/
        MIN(line_status_data.ln_no) min_line_no,                                             	/** 最小ラインNo */
        MAX(line_status_data.ln_sts_frame) line_status_frame,                             		/** ライン状態(枠) */
        MAX(line_status_data.ln_sts_icon) line_status_icon,                              		 /** ライン状態(アイコン) */
        SUM(line_status_data.sum_line_retention_before) line_retention_before,                 /** ライン前滞留閾値 */
        SUM(line_status_data.sum_line_retention_inside) line_retention_inside,                 /** ライン内滞留閾値 */
        SUM(line_status_data.sum_line_retention_after) line_retention_after,                   /** ライン後滞留閾値 */
        SUM(line_status_data.sum_schedule_num) schedule_num,                                   /** 予定数 */
        SUM(line_status_data.sum_actual_num) actual_num,                                       /** 実績数 */
        SUM(line_status_data.sum_plan_num) plan_num,                                           /** 計画数 */
        SUM(line_status_data.sum_pre_retention_num) pre_retention_num,                         /** ライン前の滞留数 */
        SUM(line_status_data.sum_retention_num) retention_num,                                 /** ライン内の滞留数 */
        SUM(line_status_data.sum_after_retention_num) after_retention_num                      /** ライン後の滞留数 */
    FROM
        (SELECT
            mst_line_info.ln_id,                                                /** ライン番号*/
            mst_line_info.ln_no,                                                /** ライン番号*/
            ma_seizou_line.plant_cd,                                            /** 工場コード*/
            ma_seizou_line.seizou_ln_id,                                        /** 製造ラインコード*/
            mst_line_info.ln_nm,												/** ライングループ名 */
            mst_line_info.spare_text1,                                          /** 文字予備1 **/
            tr_line_sts.ln_sts_frame,                                   /** ライン状態(枠) */
            tr_line_sts.ln_sts_icon,                                    /** ライン状態(アイコン) */
            CASE mst_line_info.stay_before_th
                WHEN -1 THEN NULL ELSE mst_line_info.stay_before_th
                END sum_line_retention_before,                                   /** サマリ用ライン前滞留閾値 */
            CASE mst_line_info.stay_inside_th
                WHEN -1 THEN NULL ELSE mst_line_info.stay_inside_th
                END sum_line_retention_inside,                                   /** サマリ用ライン内滞留閾値 */
            CASE mst_line_info.stay_after_th
                WHEN -1 THEN NULL ELSE mst_line_info.stay_after_th
                END sum_line_retention_after,                                    /** サマリ用ライン後滞留閾値 */
            CASE ag_line_work_current.schedule_num
                WHEN -1 THEN NULL ELSE ag_line_work_current.schedule_num
                END sum_schedule_num,                                            /** サマリ用予定数 */
            CASE ag_line_work_current.actual_num
                WHEN -1 THEN NULL ELSE ag_line_work_current.actual_num
                END sum_actual_num,                                               /** サマリ用実績数 */
            CASE ag_line_work_current.plan_num
                WHEN -1 THEN NULL ELSE ag_line_work_current.plan_num
                END sum_plan_num,                                                /** サマリ用計画数 */
            CASE ag_line_work_current.pre_retention_num
                WHEN -1 THEN NULL ELSE ag_line_work_current.pre_retention_num
                END sum_pre_retention_num,                                       /** サマリ用ライン前の滞留数 */
            CASE ag_line_work_current.retention_num
                WHEN -1 THEN NULL ELSE ag_line_work_current.retention_num
                END sum_retention_num,                                            /** サマリ用ライン内の滞留数 */
            CASE ag_line_work_current.after_retention_num
                WHEN -1 THEN NULL ELSE ag_line_work_current.after_retention_num
                END sum_after_retention_num                                      /** サマリ用ライン後の滞留数 */
        FROM
            (SELECT
                ln_id,
                process_id,
                ln_no,
                ln_nm,
                spare_text1,
                stay_before_th,
                stay_inside_th,
                stay_after_th
            FROM
                ma_line
            WHERE
                invalid_flag = 0) mst_line_info

        INNER JOIN ma_process
        ON mst_line_info.process_id = ma_process.process_id

        INNER JOIN ma_seizou_line
        ON ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id
        AND ma_seizou_line.plant_cd = /*comPlantCode*/''
        AND ma_seizou_line.seizou_ln_id = /*comSeizouLnId*/''

        LEFT OUTER JOIN
            ag_line_work_current
        ON
            mst_line_info.ln_id = ag_line_work_current.ln_id
        LEFT OUTER JOIN
            tr_line_sts
        ON
            mst_line_info.ln_id = tr_line_sts.ln_id
    ) line_status_data
    GROUP BY line_status_data.ln_id, line_status_data.ln_no, line_status_data.ln_nm, line_status_data.plant_cd, line_status_data.seizou_ln_id, line_status_data.spare_text1) line_group_data

INNER JOIN
    (SELECT
--        ma_process.plant_cd,
        ma_process.process_cd,
        ma_process.process_seq
    FROM
        ma_process
    ) process_info
ON
--  process_info.process_cd = get_process_code(line_group_data.plant_cd, line_group_data.ln_no)
    process_info.process_cd = get_process_code(line_group_data.ln_no)

/** 表示位置情報取得 */
INNER JOIN
    tr_line_layout
ON
    tr_line_layout.ln_id = line_group_data.ln_id
INNER JOIN
    ma_line_layout
ON
    ma_line_layout.layout_id = tr_line_layout.layout_id
--ORDER BY line_group_data.line_group_no
WHERE
    line_group_data.plant_cd = /*comPlantCode*/''
    AND line_group_data.seizou_ln_id = /*comSeizouLnId*/''
/*IF hdnPageExchangeFlag != "1"*/
    AND tr_line_layout.hori_page_pos = /*matrixPageX*/1
    AND tr_line_layout.vert_page_pos = /*matrixPageY*/1
/*END*/
ORDER BY line_group_data.ln_no