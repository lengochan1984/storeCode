update
  rel_device_alarm
set
  mail_send_flag_off = '0',
  mail_send_flag_on = '0',
  mail_template_type_off =null,
  mail_template_type_on= null
where
  (rel_device_alarm.device_sid,rel_device_alarm.alarm_sid)
in(
  select rel_device_alarm.device_sid,rel_device_alarm.alarm_sid
    from rel_device_alarm
    left join mst_alarm_send_address
on
  mst_alarm_send_address.device_sid = rel_device_alarm.device_sid
and
  mst_alarm_send_address.alarm_sid = rel_device_alarm.alarm_sid
where
  mst_alarm_send_address.sid is null
  )

