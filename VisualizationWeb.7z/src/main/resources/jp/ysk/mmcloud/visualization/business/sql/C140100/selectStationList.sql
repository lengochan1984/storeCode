SELECT
    tr_st_work_jsk.st_id,
    tr_st_work_jsk.st_nm,
    tr_st_work_jsk.work_sta_time AS start_date_time,
    tr_st_work_jsk.work_end_time AS end_date_time,
    tr_st_work_jsk.hantei,
    tr_st_work_jsk.repair_kaisu
FROM
    tr_product_trc
INNER JOIN
    tr_st_work_jsk
ON
    tr_product_trc.sasizu_no = tr_st_work_jsk.sasizu_no
AND
    tr_product_trc.sub_no = tr_st_work_jsk.sub_no
AND
    tr_product_trc.sagyo_seq = tr_st_work_jsk.sagyo_seq
INNER JOIN
    ma_station
ON
    ma_station.st_id = tr_st_work_jsk.st_id
WHERE
    tr_st_work_jsk.plant_cd = /*comPlantCode*/''
AND
    tr_product_trc.seihin_sn = /*serialNumber*/''
AND
    ma_station.ln_id = /*lnId*/
ORDER BY
    tr_st_work_jsk.st_nm ASC,
    tr_st_work_jsk.work_sta_time ASC,
    tr_st_work_jsk.work_end_time ASC,
    tr_st_work_jsk.hantei ASC,
    tr_st_work_jsk.repair_kaisu ASC
