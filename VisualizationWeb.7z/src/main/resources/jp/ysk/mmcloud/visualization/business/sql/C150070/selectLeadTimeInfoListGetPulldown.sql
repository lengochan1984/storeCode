/*---------------------　ラインプルダウン選択時 --------*/
WITH keyTable AS (
	SELECT
		tblA.werks,			--工場コード
		tblB.sasizu_no,				--指図番号
		tblB.sub_no,				--副番号
		tblA.end_date	--製品の生産終了実績日時
	FROM
	(
		SELECT
			LL.sasizu_no,	--指図番号
			LL.sub_no		--副番号
		FROM
			tr_line_work_jsk LL
		INNER JOIN
			ma_line LG	--ライングループマスタ
		ON
				LL.ln_id = LG.ln_id				--工場コード
			AND	LG.invalid_flag = 0				--無効フラグ
			AND	LG.ln_nm = LL.ln_nm				--工場コード
			AND	LG.ln_no = LL.ln_no				--ライン番号
			AND	LG.plant_cd = /*comPlantCode*/	--工場コード
			AND	LG.ln_no = /*comLineNo*/		--ライングループ番号
		GROUP BY
			LL.sasizu_no,	--指図番号
			LL.sub_no		--副番号
	) tblB
	INNER JOIN
	(
		SELECT
			A0.werks,	--工場コード
			A1.sasizu_no,	--指図番号
			A1.sub_no,		--副番号
			A1.end_date	--製品の生産終了実績日時
		FROM
			tr_sasizu_info A0
		INNER JOIN
			tr_product_trc A1
		ON
				A0.sasizu_no = A1.sasizu_no
			AND	A0.werks = /*comPlantCode*/
		INNER JOIN
			ma_hinmoku H
		ON
				A1.buhin_cd = H.matnr
			AND	A0.werks = H.werks
			/*IF buhin_cd != null*/
			AND	H.matnr = /*buhin_cd*/
			/*END*/
			/*IF kishugun_name != null*/
			AND	H.vtext_info1 = /*kishugun_name*/	--製品プルダウンで機種群名を選択時
			/*END*/
			/*IF series_name != null*/
			AND	H.vtext_info2 = /*series_name*/	--製品プルダウンでシリーズ名を選択時
			/*END*/
		WHERE
				A1.end_date >= /*comDataDateFrom*/
			AND	A1.end_date <= /*comDataDateTo*/
			AND	A1.end_date is not null
			AND	A1.seisan_jyotai = /*statusCompletion*/	--生産状態
	) tblA
	ON
		tblA.sasizu_no = tblB.sasizu_no
		AND tblA.sub_no = tblB.sub_no
)
--工程リードタイム
SELECT
	lt.process_nm,						--工程名
	lt.process_no,						--工程順序
	lt.process_cd,						--工程コード
	avg(lt.lead_time) AS av_lead_time,	--リードタイム平均
	max(lt.lead_time) AS mx_lead_time,	--リードタイム最大
	min(lt.lead_time) AS mi_lead_time,	--リードタイム最小
	lt.end_date
FROM
(
	SELECT
		lt1.sasizu_no,		--指図番号
		lt1.sub_no,			--副番号
		lt1.process_cd,		--工程コード
		lt1.lead_time,		--リードタイム
		pc1.process_nm,		--工程名称
		pc1.process_no,		--工程順序
		/*IF comDateType == 'jikanbetu'*/
		date_trunc('hour', key1.end_date + cast(/*zoneOffset*/ AS interval)) AS end_date
		/*END*/
		/*IF comDateType == 'nitiji'*/
		date_trunc('day', key1.end_date + cast(/*zoneOffset*/ AS interval) - cast(/*searchDateShiftTime*/ AS interval)) AS end_date
		/*END*/
		/*IF comDateType == 'getuji'*/
		date_trunc('month', key1.end_date + cast(/*zoneOffset*/ AS interval) - cast(/*searchDateShiftTime*/ AS interval) + interval '15 days') AS end_date
		/*END*/
	FROM
		/*IF comDateType == 'jikanbetu'*/
		ag_line_lead_time_hourly lt1	--時間別テーブルは存在しないので、エラーとなる
		/*END*/
		/*IF comDateType == 'nitiji'*/
		ag_line_lead_time_daily lt1
		/*END*/
		/*IF comDateType == 'getuji'*/
		ag_line_lead_time_monthly lt1
		/*END*/
	INNER JOIN
		ma_process pc1
	ON
			lt1.process_cd = pc1.process_cd	--工程コード
		AND	pc1.invalid_flag = 0
	,keyTable key1
	WHERE
			lt1.plant_cd = key1.plant_cd
		AND	lt1.sasizu_no = key1.sasizu_no
		AND	lt1.sub_no = key1.sub_no
		AND	lt1.seizou_ln_cd = /*comSeizouLineCd*/
		/*IF comProcessCode != null */
		AND	lt1.process_cd = /*comProcessCode*/
		/*END*/
	UNION
	--工程間リードタイム
	SELECT
		lt2.sasizu_no,															--指図番号
		lt2.sub_no,																--副番号
		lt2.pre_process_cd || '-' || lt2.next_process_cd AS process_cd,	--工程コード(前後)
		lt2.lead_time,															--リードタイム
		pc2.process_nm || '～' || pc3.process_nm AS process_nm,			--工程名称
		pc2.process_no,															--工程順序
		/*IF comDateType == 'jikanbetu'*/
		date_trunc('hour', key2.end_date + cast(/*zoneOffset*/ AS interval)) AS end_date
		/*END*/
		/*IF comDateType == 'nitiji'*/
		date_trunc('day', key2.end_date + cast(/*zoneOffset*/ AS interval) - cast(/*searchDateShiftTime*/ AS interval)) AS end_date
		/*END*/
		/*IF comDateType == 'getuji'*/
		date_trunc('month', key2.end_date + cast(/*zoneOffset*/ AS interval) - cast(/*searchDateShiftTime*/ AS interval) + interval '15 days') AS end_date
		/*END*/
	FROM
		/*IF comDateType == 'jikanbetu'*/
		ag_line_tm_lead_time_hourly lt2	--時間別テーブルは存在しないので、エラーとなる
		/*END*/
		/*IF comDateType == 'nitiji'*/
		ag_line_tm_lead_time_daily lt2
		/*END*/
		/*IF comDateType == 'getuji'*/
		ag_line_tm_lead_time_monthly lt2
		/*END*/
	INNER JOIN
		ma_process pc2
	ON
			lt2.process_cd = pc2.process_cd
		AND	pc2.invalid_flag = 0	--工程コード
	INNER JOIN
		ma_process pc3
	ON
			lt2.n_process_cd = pc3.process_cd
		AND	pc3.invalid_flag = 0	--工程コード
	,keyTable key2
	WHERE
			lt2.plant_cd = key2.plant_cd
		AND	lt2.sasizu_no = key2.sasizu_no
		AND	lt2.sub_no = key2.sub_no
		AND	lt2.seizou_ln_cd = /*comSeizouLineCd*/
		/*IF comProcessCode != null */
		AND	lt2.n_process_cd = /*comProcessCode*/
		/*END*/
) lt
GROUP BY
	lt.process_nm,		--工程名称
	lt.process_no,			--工程順序
	lt.process_cd,		--工程コード
	lt.end_date	--完成日
ORDER BY
	lt.end_date,
	lt.process_no,			--工程順序
	lt.process_nm
