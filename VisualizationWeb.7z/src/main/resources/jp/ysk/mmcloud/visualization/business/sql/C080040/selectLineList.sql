SELECT
  ma_seizou_line.plant_cd as plant_code,
  ma_line.ln_no as ln_no,
  ma_line.stay_inside_th as line_retention_number,
  ma_line.ln_nm as line_name_jp,
  tr_line_sts.ln_sts as line_status,
  ag_line_work_current.retention_num as retention_number,
  to_char(ag_line_work_current.prediction_completion_time,'HH24:MI') as prediction_completion_time,
  to_char(ag_line_work_current.plan_completion_time,'HH24:MI') as plan_completion_time,
  ma_line.ln_nm as display_order
FROM
  ma_line
INNER JOIN ma_process
	ON ma_line.process_id = ma_process.process_id
INNER JOIN ma_seizou_line
	ON ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id
LEFT OUTER JOIN
  tr_line_sts
ON
  tr_line_sts.ln_id = ma_line.ln_id
LEFT OUTER JOIN
  ag_line_work_current
ON
  ag_line_work_current.ln_id = ma_line.ln_id
WHERE
  ma_seizou_line.plant_cd = /*plantCode*/''
ORDER BY display_order asc
