DELETE
FROM
    mst_user_clock_disp
WHERE
    user_sid = /*userSid*/
