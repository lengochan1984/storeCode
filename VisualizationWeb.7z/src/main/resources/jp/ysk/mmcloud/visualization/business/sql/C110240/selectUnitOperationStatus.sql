SELECT
    to_char(t0.upd_date, 'MM/DD') upd_date,
    t0.sts_ratio,
    t1.name1,
    t1.name2
FROM
    ag_unit_work  t0
INNER JOIN
    sys_name t1
ON
    t0.sts_cd = t1.item_cd
    AND t1.name_type = /*nameType*/
    AND t1.lang_cd = /*loginUserLangCd*/''
INNER JOIN
    ma_station
ON
    ma_station.st_id = t0.st_id
    AND ma_station.invalid_flag = 0
INNER JOIN
    ma_line
ON
    ma_station.ln_id = ma_line.ln_id
    AND ma_line.invalid_flag = 0
INNER JOIN
    ma_process
ON
    ma_line.process_id = ma_process.process_id
    AND ma_process.invalid_flag = 0
INNER JOIN
    ma_seizou_line
ON
    ma_process.seizou_ln_id = ma_seizou_line.seizou_ln_id
    AND ma_seizou_line.invalid_flag = 0
INNER JOIN
    ma_plant
ON
    ma_plant.invalid_flag = 0
    AND ma_seizou_line.plant_cd = ma_plant.plant_cd

WHERE
        t0.upd_date >= /*weekDatetime*/
    /*IF comStId != null*/
    AND ma_station.st_id = /*comStId*/1
    /*END*/
    /*IF comSeizouLnId != null*/
    AND ma_seizou_line.seizou_ln_id = /*comSeizouLnId*/1
    /*END*/
    /*IF comProcessId != null*/
    AND ma_process.process_id = /*comProcessId*/1
    /*END*/
    /*IF comLnId != null*/
    AND ma_line.ln_id = /*comLnId*/1
    /*END*/

ORDER BY
    t0.upd_date ASC