SELECT
    MAX(tr_line_sts.modified_on)
FROM
    tr_line_sts
INNER JOIN
    ma_line
ON
    tr_line_sts.ln_id = ma_line.ln_id
INNER JOIN ma_process
        ON ma_line.process_id = ma_process.process_id
INNER JOIN ma_seizou_line
        ON ma_seizou_line.seizou_ln_id = ma_process.seizou_ln_id
WHERE
        ma_seizou_line.plant_cd = /*comPlantCode*/