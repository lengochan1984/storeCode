DELETE
FROM tbl_api_auth_accesstoken
WHERE
     tbl_api_auth_accesstoken.user_id = /*userSid*/
