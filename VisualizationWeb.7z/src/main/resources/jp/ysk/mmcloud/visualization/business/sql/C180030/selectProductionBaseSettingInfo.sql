SELECT
    ma_plant_mieruka.plant_cd AS plant_code,
    ma_plant_mieruka.mes_db_connect_info,
    ma_plant_mieruka.mes_db_user_id,
    ma_plant_mieruka.mes_db_password,
    ma_plant.running_start_datetime
--    ma_plant.latitude,
--    ma_plant.longitude
FROM
    ma_plant_mieruka
LEFT JOIN
    ma_plant
ON
--      ma_plant_mieruka.invalid_flag = 0
   ma_plant_mieruka.plant_cd = ma_plant.plant_cd
WHERE
    ma_plant_mieruka.invalid_flag = 0
ORDER BY
    ma_plant_mieruka.plant_cd
