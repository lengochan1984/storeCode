SELECT
  ma_plant.plant_cd   as plant_code,
  ma_plant.plant_nm   as facility_name,
  ma_plant.invalid_flag as invalid_flag,
  ma_sig_disp_order_plant.display_order as display_order
FROM
  ma_plant
INNER JOIN
  ma_plant_mieruka
ON
      ma_plant_mieruka.invalid_flag = 0
  AND ma_plant_mieruka.plant_cd = ma_plant.plant_cd
INNER JOIN
  ma_sig_disp_order_plant
ON
  ma_sig_disp_order_plant.plant_cd = ma_plant.plant_cd
WHERE
  ma_sig_disp_order_plant.signage_id = /*signageId*/''
ORDER BY ma_sig_disp_order_plant.display_order
