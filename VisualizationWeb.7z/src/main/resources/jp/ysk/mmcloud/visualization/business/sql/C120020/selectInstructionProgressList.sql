SELECT
    line_group_data.line_group_no,                                                               /** ライングループ番号 */
    COALESCE(mst_line_group_name.line_group_name, line_group_data.min_line_no) line_group_name,  /** ライングループ名 */
    process_info.process_code,                                                                   /** 工程コード */
    process_info.process_no,                                                                     /** 工程順序 */
    line_group_data.line_status_frame line_status_frame_code,                                    /** ライン状態(枠) */
    line_group_data.line_status_icon line_status_icon_code,                                      /** ライン状態(アイコン) */
    line_group_data.line_retention_before line_retention_before,                                 /** ライン前滞留閾値 */
    line_group_data.line_retention_inside line_retention_inside,                                 /** ライン内滞留閾値 */
    line_group_data.schedule_num schedule_num,                                                   /** 予定数 */
    line_group_data.actual_num actual_num,                                                       /** 実績数 */
    line_group_data.plan_num plan_num,                                                           /** 計画数 */
    line_group_data.pre_retention_num pre_retention_num,                                         /** ライン前の滞留数 */
    line_group_data.retention_num retention_num,                                                 /** ライン内の滞留数 */
    mst_line_group.spare1,                                                                        /** 予備１ **/

    line_group_data.plant_code,																/**工場コード**/
    line_group_data.min_line_no as line_no,												/**ラインコード**/
    /*progressDateFrom*/'' as progress_date_from,									/**表示期間FROM**/
    /*progressDateTo*/''		as progress_date_to										/**表示期間TO**/

FROM
    (SELECT
        line_status_data.line_group_no,                                                        /** ライングループ番号 */
        MIN(line_status_data.line_no) min_line_no,                                             /** 最小ラインNo */
        line_status_data.plant_code,                                                           /** 工場コード*/
        MAX(line_status_data.line_status_frame) line_status_frame,                             /** ライン状態(枠) */
        MAX(line_status_data.line_status_icon) line_status_icon,                               /** ライン状態(アイコン) */
        SUM(line_status_data.sum_line_retention_before) line_retention_before,                 /** ライン前滞留閾値 */
        SUM(line_status_data.sum_line_retention_inside) line_retention_inside,                 /** ライン内滞留閾値 */
        SUM(line_status_data.sum_schedule_num) schedule_num,                                   /** 予定数 */
        SUM(line_status_data.sum_actual_num) actual_num,                                       /** 実績数 */
        SUM(line_status_data.sum_plan_num) plan_num,                                           /** 計画数 */
        SUM(line_status_data.sum_pre_retention_num) pre_retention_num,                         /** ライン前の滞留数 */
        SUM(line_status_data.sum_retention_num) retention_num                                  /** ライン内の滞留数 */
    FROM
        (SELECT
            mst_line_info.line_no,                                               /** ライン番号*/
            mst_line_info.plant_code,                                            /** 工場コード*/
            mst_line_group.line_group_no,                                        /** ライングループ番号 */
            tbl_line_status.line_status_frame,                                   /** ライン状態(枠) */
            tbl_line_status.line_status_icon,                                    /** ライン状態(アイコン) */
            tbl_line_work_current.sagyoku,                                       /** 作業区 */
            CASE mst_line_info.line_retention_before
                WHEN -1 THEN NULL ELSE mst_line_info.line_retention_before
                END sum_line_retention_before,                                   /** サマリ用ライン前滞留閾値 */
            CASE mst_line_info.line_retention_inside
                WHEN -1 THEN NULL ELSE mst_line_info.line_retention_inside
                END sum_line_retention_inside,                                   /** サマリ用ライン内滞留閾値 */
            CASE tbl_line_work_current.schedule_num
                WHEN -1 THEN NULL ELSE tbl_line_work_current.schedule_num
                END sum_schedule_num,                                            /** サマリ用予定数 */
            CASE tbl_line_work_current.actual_num
                WHEN -1 THEN NULL ELSE tbl_line_work_current.actual_num
                END sum_actual_num,                                               /** サマリ用実績数 */
            CASE tbl_line_work_current.plan_num
                WHEN -1 THEN NULL ELSE tbl_line_work_current.plan_num
                END sum_plan_num,                                                /** サマリ用計画数 */
            CASE tbl_line_work_current.pre_retention_num
                WHEN -1 THEN NULL ELSE tbl_line_work_current.pre_retention_num
                END sum_pre_retention_num,                                       /** サマリ用ライン前の滞留数 */
            CASE tbl_line_work_current.retention_num
                WHEN -1 THEN NULL ELSE tbl_line_work_current.retention_num
                END sum_retention_num                                            /** サマリ用ライン内の滞留数 */
        FROM
            (SELECT
                a.line_no,
                a.seizou_line_cd,
                a.plant_code,
                a.line_retention_before,
                a.line_retention_inside
            FROM
                mst_line	a,
                mst_station	b
            WHERE
                    a.plant_code		=	/*comPlantCode*/''
                AND	a.plant_code		=	b.plant_code
                AND	a.line_no			=	b.line_no
                /*IF comSeizouLineCd != null*/
                AND a.seizou_line_cd	=	/*comSeizouLineCd*/''
                /*END*/
                /*IF comProcessCode != null*/
                AND	a.process_code		=	/*comProcessCode*/''
                /*END*/
                /*IF comLineNo != null*/
                AND	a.line_no			=	/*comLineNo*/''
                /*END*/
                AND a.invalid_flag = 0

            GROUP BY a.line_no, a.seizou_line_cd, a.plant_code, a.line_retention_before, a.line_retention_inside
        ) mst_line_info
        INNER JOIN
            mst_line_group
        ON
                mst_line_group.invalid_flag = 0
            AND mst_line_info.plant_code = mst_line_group.plant_code
            AND mst_line_info.line_no = mst_line_group.line_no
        LEFT OUTER JOIN
            tbl_line_work_current
        ON
                mst_line_info.plant_code = tbl_line_work_current.plant_code
            AND mst_line_info.seizou_line_cd = tbl_line_work_current.seizou_line_cd
            AND mst_line_info.line_no = tbl_line_work_current.line_no
        LEFT OUTER JOIN
            tbl_line_status
        ON
                mst_line_info.plant_code = tbl_line_status.plant_code
            AND mst_line_info.line_no = tbl_line_status.line_no
    ) line_status_data
    GROUP BY line_status_data.line_group_no, line_status_data.plant_code) line_group_data
INNER JOIN
    (SELECT
        mst_process.plant_code,
        mst_process.process_code,
        mst_process.process_no
    FROM
        mst_process

    ) process_info
ON
        process_info.plant_code = line_group_data.plant_code
    AND process_info.process_code = get_process_code(line_group_data.plant_code, line_group_data.line_group_no)
INNER JOIN
    mst_line_group
ON
        mst_line_group.invalid_flag = 0
    AND line_group_data.plant_code = mst_line_group.plant_code
    AND line_group_data.line_group_no = mst_line_group.line_group_no
LEFT JOIN
    mst_line_group_name
ON
        mst_line_group_name.invalid_flag = 0
    AND line_group_data.line_group_no = mst_line_group_name.line_group_no

ORDER BY
    process_code,
    line_group_name
