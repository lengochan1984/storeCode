SELECT
    item_cd as status_cd,
    name1	as status_name,
    name2	as status_color
FROM
    sys_name
WHERE
    name_type = /*namType*/'line_operation_sts'
AND lang_cd = /*langCd*/'JPN'
ORDER BY
    item_cd ASC