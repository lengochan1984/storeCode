select
    mst_alarm_send_address.sid
from
    mst_alarm_send_address
left outer join
    mst_device
on
    mst_alarm_send_address.device_sid = mst_device.sid
where
    mst_device.delete_flag = false
and
   mst_alarm_send_address.mail_address_sid = /*mailAddressSid*/

