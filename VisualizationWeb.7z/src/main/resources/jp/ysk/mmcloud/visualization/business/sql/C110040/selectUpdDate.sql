SELECT
    MAX(tr_equip_sts.modified_on) AS add_date
    --    , MAX(tr_equip_sts.line_upd_datetime) AS add_date

FROM
    tr_equip_sts
INNER JOIN
    ma_equip
ON
  --  tr_equip_sts.st_id = ma_equip.st_id
     tr_equip_sts.main_res_no = ma_equip.main_res_no
AND tr_equip_sts.plant_cd = ma_equip.plant_cd
INNER JOIN
    ma_station
ON
 --   tr_equip_sts.st_id = ma_station.st_id
 ma_equip.st_id = ma_station.st_id
INNER JOIN
    ma_line

ON (
        ma_line.invalid_flag = 0
        AND
        ma_station.ln_id = ma_line.ln_id
--        tr_equip_sts.ln_no = ma_line.ln_no
--		AND
--		tr_equip_sts.ln_nm = ma_line.ln_nm
    )
WHERE
    ma_equip.plant_cd = /*comPlantCode*/'D0'
/*IF comLnId != null*/
    AND
    ma_line.ln_id = /*comLnId*/1
/*END*/
