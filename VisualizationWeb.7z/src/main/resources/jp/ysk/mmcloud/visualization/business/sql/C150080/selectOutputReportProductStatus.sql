SELECT
	tpm.vtext_info1,
	tpm.vtext_info2,
	SUM(tpm.plan_the_day_num) AS total_plan_the_day_num,
	SUM(tpm.actual_the_day_num) AS total_actual_the_day_num
FROM
	/*IF comDateType == 'jikanbetu'*/
	ag_product_mng_hourly tpm
	/*END*/
	/*IF comDateType == 'shuji'*/
	ag_product_mng_daily tpm
	/*END*/
	/*IF comDateType == 'nitiji'*/
	ag_product_mng_monthly tpm
	/*END*/
WHERE
	tpm.plant_cd = /*comPlantCode*/
AND
	tpm.seizou_ln_id = /*comSeizouLnId*/
AND
	tpm.data_date >= /*comDataDateFrom*/
AND
	tpm.data_date <= /*comDataDateTo*/
/*IF comLnId != null*/
AND
	tpm.ln_id = /*comLnId*/
/*END*/
/*IF comStId != null*/
AND
	tpm.st_id = /*comStId*/
/*END*/
/*IF kishugun_name != null*/
AND
	tpm.vtext_info1 = /*kishugun_name*/
/*END*/
GROUP BY
	tpm.vtext_info1,
	tpm.vtext_info2
ORDER BY
	tpm.vtext_info1,
	tpm.vtext_info2
