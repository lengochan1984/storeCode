SELECT
  to_char(data_date,'YYYY/MM/DD HH24:MI:SS') as data_date,
  plan_num as plan_number,
  actual_num as actual_number
FROM
  ag_line_work_hourly
WHERE
  plant_cd = /*plantCode*/''
AND
  ln_no    = /*lineNo*/''
AND
  data_date between (to_timestamp(/*startDate*/,'YYYY-MM-DD HH24:MI:SS.MS')) and (to_timestamp(/*endDate*/,'YYYY-MM-DD HH24:MI:SS.MS'))
ORDER BY data_date asc
