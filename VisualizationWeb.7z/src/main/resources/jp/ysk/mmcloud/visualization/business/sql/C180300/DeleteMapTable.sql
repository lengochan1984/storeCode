DELETE
FROM
    ma_map
WHERE
    ma_map.plant_cd = /*plantCd*/
    AND ma_map.map_cd = /*mapCd*/