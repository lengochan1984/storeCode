SELECT
    syori_date,
    sousu,
    zaikan_zentai AS zaikanDaisu,
    zaikan_buhin,
    zaikan_hansei,
    zaikan_zentai,
    ROUND(zaikan_buhin  / sousu * 100, 2) AS ritu_buhin,
    ROUND(zaikan_hansei / sousu * 100, 2) AS ritu_hansei,
    ROUND(zaikan_zentai / sousu * 100, 2) AS ritu_zentai
FROM
    tbl_erp_zaikan_rating_details
WHERE
        plant_code = /*comPlantCode*/
/*IF ctgrKubun == "01"*/
    AND	 kishu_ctgr01 = /*kisyuCtgr*/
/*END*/
/*IF ctgrKubun == "02"*/
    AND kishu_ctgr02 = /*kisyuCtgr*/
/*END*/
/*IF ctgrKubun == "00"*/
    AND (kishu_ctgr01 = '' AND kishu_ctgr02 = '')
/*END*/
    AND syori_date BETWEEN /*searchDateFrom*/ AND /*searchDateTo*/
ORDER BY
    syori_date
