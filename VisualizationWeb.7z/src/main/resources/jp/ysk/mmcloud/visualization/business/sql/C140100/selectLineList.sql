SELECT
    tr_line_work_jsk.ln_id,
    tr_line_work_jsk.ln_nm,
    tr_line_work_jsk.start_time AS start_date_time,
    tr_line_work_jsk.end_time AS end_date_time,
    tr_line_work_jsk.hantei,
    tr_line_work_jsk.repair_kaisu

FROM
    tr_product_trc
INNER JOIN
    tr_line_work_jsk
ON
    tr_product_trc.sasizu_no = tr_line_work_jsk.sasizu_no
AND
    tr_product_trc.sub_no = tr_line_work_jsk.sub_no
AND
    tr_product_trc.sagyo_seq = tr_line_work_jsk.sagyo_seq

WHERE
    tr_line_work_jsk.plant_cd = /*comPlantCode*/''
AND
    tr_product_trc.seihin_sn = /*serialNumber*/''
ORDER BY
/*IF fw0114SortKey == null*/
    tr_line_work_jsk.ln_nm ASC, tr_line_work_jsk.start_time ASC, tr_line_work_jsk.end_time ASC, tr_line_work_jsk.hantei ASC, tr_line_work_jsk.repair_kaisu ASC
/*END*/
/*IF fw0114SortKey == "lnNm"*/
    /*IF fw0114SortOrder == "asc"*/
    tr_line_work_jsk.ln_nm ASC, tr_line_work_jsk.start_time ASC, tr_line_work_jsk.end_time ASC, tr_line_work_jsk.hantei ASC, tr_line_work_jsk.repair_kaisu ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    tr_line_work_jsk.ln_nm DESC, tr_line_work_jsk.start_time DESC, tr_line_work_jsk.end_time DESC, tr_line_work_jsk.hantei DESC, tr_line_work_jsk.repair_kaisu DESC
    /*END*/
/*END*/
/*IF fw0114SortKey == "startDateTime"*/
    /*IF fw0114SortOrder == "asc"*/
    tr_line_work_jsk.start_time ASC, tr_line_work_jsk.ln_nm ASC, tr_line_work_jsk.end_time ASC, tr_line_work_jsk.hantei ASC, tr_line_work_jsk.repair_kaisu ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    tr_line_work_jsk.start_time DESC, tr_line_work_jsk.ln_nm DESC, tr_line_work_jsk.end_time DESC, tr_line_work_jsk.hantei DESC, tr_line_work_jsk.repair_kaisu DESC
    /*END*/
/*END*/
/*IF fw0114SortKey == "endDateTime"*/
    /*IF fw0114SortOrder == "asc"*/
    tr_line_work_jsk.end_time ASC, tr_line_work_jsk.ln_nm ASC, tr_line_work_jsk.start_time ASC, tr_line_work_jsk.hantei ASC, tr_line_work_jsk.repair_kaisu ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    tr_line_work_jsk.end_time DESC, tr_line_work_jsk.ln_nm DESC, tr_line_work_jsk.start_time DESC, tr_line_work_jsk.hantei DESC, tr_line_work_jsk.repair_kaisu DESC
    /*END*/
/*END*/
/*IF fw0114SortKey == "hantei"*/
    /*IF fw0114SortOrder == "asc"*/
    tr_line_work_jsk.hantei ASC, tr_line_work_jsk.ln_nm ASC, tr_line_work_jsk.start_time ASC, tr_line_work_jsk.end_time ASC, tr_line_work_jsk.repair_kaisu ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    tr_line_work_jsk.hantei DESC, tr_line_work_jsk.ln_nm DESC, tr_line_work_jsk.start_time DESC, tr_line_work_jsk.end_time DESC, tr_line_work_jsk.repair_kaisu DESC
    /*END*/
/*END*/
/*IF fw0114SortKey == "repairKaisu"*/
    /*IF fw0114SortOrder == "asc"*/
    tr_line_work_jsk.repair_kaisu ASC, tr_line_work_jsk.ln_nm ASC, tr_line_work_jsk.start_time ASC, tr_line_work_jsk.end_time ASC, tr_line_work_jsk.hantei ASC
    /*END*/
    /*IF fw0114SortOrder == "desc"*/
    tr_line_work_jsk.repair_kaisu DESC, tr_line_work_jsk.ln_nm DESC, tr_line_work_jsk.start_time DESC, tr_line_work_jsk.end_time DESC, tr_line_work_jsk.hantei DESC
    /*END*/
/*END*/
