/**
 * @desc base
 */
var MMCloud = MMCloud || {};

MMCloud.List = {};

/* ---------------------------
 定数
--------------------------- */
// カラム種別毎のクラス定義
MMCloud.List.CLASS_BY_COL_TYPE = {
        "systemlocaltime": "objC",
        "systemlocaltimeWarning": "objC",
        "num": "objR",
        "deviceId": "objL",
        "str": "objL",
        "isAlarm": "objC icon",
        "monitor": "objC icon",
        "analyzer": "objC icon",
        "warningLevel": "objC bg",
        "warningType": "objC warnMsg",
        "status": "objC icon",
        "isDeath": "icon"
};

// 警告種別毎のクラス定義
MMCloud.List.CLASS_BY_IS_ALARM = {
        "": "icon_noAlarm",
        "0": "icon_noAlarm",
        "1": "icon_alarm"
};

// 警告レベル毎のクラス定義
MMCloud.List.CLASS_BY_WARNING_LEVEL = {
        "-": "",
        "1": "bg_warning_level1",
        "2": "bg_warning_level2",
        "3": "bg_warning_level3",
        "4": "bg_warning_level4",
        "5": "bg_warning_level5"
};

// 稼働ステータス毎のクラス定義
MMCloud.List.CLASS_BY_STATUS = {
        "-": "icon_statusOperating",
        "statusOperating": "icon_statusOperating", // 運転中
        "statusSuspension": "icon_statusSuspension", // 異常停止中（仕様にはないが念のため）
        "statusUnder": "icon_statusUnder", // 停止中（仕様にはないが念のため）
        "statusMaintenance": "icon_statusMaintenance", // メンテ中
        "statusTesting": "icon_statusTesting", // テスト中
        "statusCommissioning": "icon_statusCommissioning" ,// 試験運用中（仕様にはないが念のため
        "statusAwaiting":"icon_statusAwaiting"
};

// 死活状況毎のクラス定義
MMCloud.List.CLASS_BY_IS_DEATH = {
    "0": "icon_aliveLife", // 正常
    "1": "icon_aliveDeath" // 異常
};


/* トレンドモニタ No.13,26 Add Start 2014/04/03 YSK */
/* ---------------------------
  Ui
--------------------------- */
MMCloud.Ui = {};

// 日付選択用オプション
MMCloud.Ui.DATEPICKER_OPT = {
    dateFormat: 'yy-mm-dd',
    changeMonth: true,
    changeYear: true,
    minDate: '-10y',
    maxDate: '+2y',
    beforeShowDay: function(date) {
        //日曜日
        if(date.getDay() == 0) {
            return [true,"ui-datepicker-sunday"];
        //土曜日
        } else if(date.getDay() == 6){
            return [true,"ui-datepicker-saturday"];
        //平日
        } else {
            return [true];
        }
    }
};
/* トレンドモニタ No.13,26 Add End   2014/04/03 YSK */


/* ---------------------------
 Util
--------------------------- */
// Debug
//isDebug = false;
isDebug = true;

// console log
var p = function(){
    if(! isDebug) return;
    if (typeof console === 'object' && 'log' in window.console) {
        try {
            return window.console.log.apply(window.console, arguments);
        } catch (err) {// For IE
            var args = Array.prototype.slice.apply(arguments);
            return window.console.log(args.join(' '));
        }
    }
}

// consoleオブジェクトの無効化
// ※デバッグモードでない場合、または、consoleオブジェクトを持たない環境(IE8＋開発ツール未起動時など)の場合
try {
    if(!isDebug || !window.console) {
        var FakeConsole = function(){};
        FakeConsole.prototype = {
            log: function(){}
        };
        var console = new FakeConsole();
    }
} catch(err) {
    ;
}


// ブラウザ判別
var userAgent = (function(){
    return {
        ltIE6:typeof window.addEventListener == "undefined" && typeof document.documentElement.style.maxHeight == "undefined",
        ltIE7:typeof window.addEventListener == "undefined" && typeof document.querySelectorAll == "undefined",
        ltIE8:typeof window.addEventListener == "undefined" && typeof document.getElementsByClassName == "undefined",
        ltIE9:document.uniqueID && !window.matchMedia,
        gtIE10:document.uniqueID && document.documentMode >= 10,
        Trident:document.uniqueID,
        Gecko:'MozAppearance' in document.documentElement.style,
        Presto:window.opera,
        Blink:window.chrome,
        Webkit:!window.chrome && 'WebkitAppearance' in document.documentElement.style,
        Touch:typeof document.ontouchstart != "undefined",
        Mobile:typeof window.orientation != "undefined",
        Pointer:window.navigator.pointerEnabled,
        MSPoniter:window.navigator.msPointerEnabled
    }
})();

// ローカル判定
var isLocal = (location.href.split("/")[0] == "file:") ? true : false;

/* ---------------------------
  折りたたみ
--------------------------- */
// ヘッダ折りたたみ
function spreadMenu() {
  if ($("div.wrapUpper:first").is(":hidden")) {
    $("div.wrapUpper").slideDown(360);
    $("#btn_openHeader").hide();
    $("#btn_closeHeader").show();
    // 開閉状態を開に設定
    $("#hdnIsHeaderOpened").val("1");

  } else {
    $("div.wrapUpper").slideUp(360);
    $("#btn_openHeader").show();
    $("#btn_closeHeader").hide();
    // 開閉状態を閉に設定
    $("#hdnIsHeaderOpened").val("0");
}
  setTimeout("resizeWindow()",360);
//  setTimeout(function(){$(window).resize();},360);
}

// グラフ
function toggleGraph(mode) {
    if(mode) {
        $("#graph_open").hide();
        $("#graph_wrap").show();
    } else {
        $("#graph_wrap").hide();
        $("#graph_open").show();
    }
}
// 地図
function toggleMap(mode) {
    if(mode) {
        $("#map_open").hide();
        $("#map_wrap").show();
    } else {
        $("#map_wrap").hide();
        $("#map_open").show();
    }
}

// 一覧
function toggleList(mode) {
    if(mode) {
        $("#list_open").hide();
        $("#list_wrap").show();
    } else {
        $("#list_wrap").hide();
        $("#list_open").show();
    }
}


/* ---------------------------
  検索拡張
--------------------------- */

var afterOpenCondFunc = null;	// 後処理用コールバックfunc
function openCond() {
    $(".open_cond").hide();
    $(".closed_cond").show();
    if(y2) {
        $(".open_cond_y2").hide();
        $(".closed_cond_y2").show();
    } else {
        $(".closed_cond_y2").hide();
        $(".open_cond_y2").show();
    }
    $("#maskLayer").fadeIn(200);

    // 後処理
    if(afterOpenCondFunc) {
        afterOpenCondFunc();
    }
}
function closeCond() {
    $(".closed_cond").hide();
    $(".open_cond_y2").hide();
    $(".closed_cond_y2").hide();
    $(".open_cond").show();
    $("#maskLayer").fadeOut(200);
}



/* ---------------------------
  高さ自動調整
--------------------------- */
var MARGIN_SCROLL_BAR = 17;

var marginFooter = 16;
var marginAreaTop = 28;
var marginBoxBottom = 7;
var heightButtonArea = 33;
var marginIE8 = 50;

function resizeWindow() {
    var resizeAreaHeight = 0;
    if($('#resizeArea').size() > 0) {
        resizeAreaHeight = $(window).height() - $('#resizeArea').offset().top - marginFooter - marginAreaTop - marginBoxBottom - (userAgent.ltIE8 ? marginIE8 : 0);
    }

    var tmpBoxHeight;
    if($('#boxArea').css('display') == 'none') {
        tmpBoxHeight = $("#boxButtonArea").height();
    } else {
        tmpBoxHeight = Math.floor(resizeAreaHeight * 0.6);
    }

    $('#boxArea').css('height', tmpBoxHeight + 'px');
    $('#buttonArea').css('height', heightButtonArea + 'px');
    $('#tableArea').css('height', (resizeAreaHeight - tmpBoxHeight - heightButtonArea) + 'px');
}

function fitSize(target, opt) {
    if(target.attr('id') == 'resizeArea') {
//		target.css('background-color', '#0f0');
    }

    // opt: {base, othersW, othersH, marginW, marginH}
    if(! opt.base) opt.base = target.parent();
    if(! opt.marginW) opt.marginW = 0;
    if(! opt.marginH) opt.marginH = 0;

    // 基準コンテナのサイズ
    var baseWidth = opt.base.width();
    var baseHeight = opt.base.height();
    // 基準コンテナが wrapAll の場合は、最小サイズを下回っていないかをチェック
    if(opt.base.attr('id') == 'wrapAll'){
        var minWidth = parseInt($('#wrapAll').css('min-width'));
        var minHeight = parseInt($('#wrapAll').css('min-height'));
        baseWidth = ($(window).width() < minWidth ?
            minWidth :
            ($(window).width() < $(document).width() ?
                $(window).width() + MARGIN_SCROLL_BAR :
                $(window).width()));
        baseHeight = ($(window).height() < minHeight ?
            minHeight :
            ($(window).height() < $(document).height() ?
                $(window).height() + MARGIN_SCROLL_BAR :
                $(window).height()));
    }

    // (サイズから減算すべき)他のコンテンツのサイズを取得
    var othersHeight = 0;
    var othersWidth = 0;
    if(opt.othersW) opt.othersW.each(function(){
        othersWidth += $(this).outerWidth(true);
    });
    if(opt.othersH) opt.othersH.each(function(){
        othersHeight += $(this).outerHeight(true);
    });

    // 新サイズ
    var newW = (baseWidth - othersWidth - parseInt(target.css('margin-left')) - parseInt(target.css('margin-right')) - parseInt(target.css('padding-left')) - parseInt(target.css('padding-right')) - parseInt('0' + target.css('border-width'))*2  - opt.marginW);
    var newH = (baseHeight - othersHeight - parseInt(target.css('margin-top')) - parseInt(target.css('margin-bottom')) - parseInt(target.css('padding-top')) - parseInt(target.css('padding-bottom')) - parseInt('0' + target.css('border-Height'))*2  - opt.marginH);

    // サイズ設定
    target.css('width', newW + 'px');
    target.css('height', newH + 'px');
}

// サイズ調整
function adjustBlockSize(target, opt) {
    // オプション: width:{(null)|fit|min|max}
    if(! opt.width) opt.width = null;
    if(! opt.height) opt.height = null;

    if(target.attr('id') == 'resizeArea') {
//		target.css('background-color', '#0f0');
    }

    // opt: {base, othersW, othersH, marginW, marginH}
    if(! opt.base) opt.base = target.parent();
    if(! opt.marginW) opt.marginW = 0;
    if(! opt.marginH) opt.marginH = 0;

    // 基準コンテナのサイズ
    var baseWidth = opt.base.width();
    var baseHeight = opt.base.height();
    // 基準コンテナが wrapAll の場合は、最小サイズを下回っていないかをチェック
    if(opt.base.attr('id') == 'wrapAll'){
        var minWidth = parseInt($('#wrapAll').css('min-width'));
        var minHeight = parseInt($('#wrapAll').css('min-height'));
        baseWidth = ($(window).width() < minWidth ?
            minWidth :
            ($(window).width() < $(document).width() ?
                $(window).width() + MARGIN_SCROLL_BAR :
                $(window).width()));
        baseHeight = ($(window).height() < minHeight ?
            minHeight :
            ($(window).height() < $(document).height() ?
                $(window).height() + MARGIN_SCROLL_BAR :
                $(window).height()));
    }

    // (サイズから減算すべき)他のコンテンツのサイズを取得
    var othersHeight = 0;
    var othersWidth = 0;
    if(opt.othersW) opt.othersW.each(function(){
        othersWidth += $(this).outerWidth(true);
    });
    if(opt.othersH) opt.othersH.each(function(){
        othersHeight += $(this).outerHeight(true);
    });

    // 新サイズ
    var newW = (baseWidth - othersWidth - parseInt(target.css('margin-left')) - parseInt(target.css('margin-right')) - parseInt(target.css('padding-left')) - parseInt(target.css('padding-right')) - parseInt('0' + target.css('border-width'))*2  - opt.marginW);
    var newH = (baseHeight - othersHeight - parseInt(target.css('margin-top')) - parseInt(target.css('margin-bottom')) - parseInt(target.css('padding-top')) - parseInt(target.css('padding-bottom')) - parseInt('0' + target.css('border-Height'))*2  - opt.marginH);

    // サイズ設定
    if(opt.width)
        target.css((opt.width == 'fit' ? 'width' : opt.width == 'max' ? 'max-width' : opt.width == 'min' ? 'min-width' : 'invalid-opt'), newW + 'px');
    if(opt.height)
        target.css((opt.height == 'fit' ? 'height' : opt.height == 'max' ? 'max-height' : opt.height == 'min' ? 'min-height' : 'invalid-opt'), newH + 'px');

}

function initHeaderTabIndex() {
    // ヘッダ初期化
    $('.wrapUpper').find('h1').find('a').attr('tabindex', 1);
    $('.wrapUpper').find('.btn_logout').find('a').attr('tabindex', 4);
    $('.wrapUpper').find('.btn_help').find('a').attr('tabindex', 3);
    $('.wrapUpper').find('.btn_userSetting').find('a').attr('tabindex', 2);
}

// 日時項目の入力を制限する（"yyyy-MM-dd hh:mm"形式のに有力のみ許可する）
// ※使用方法：
//   対象項目オブジェクト.change(formatDatetime(対象項目オブジェクト));
//   の形式で使用
//   例：$(".fromDateTextbox").change(formatDatetime($(".fromDateTextbox")));
function formatDatetime(targetObj){
    var obj = targetObj;
    var old = v=$(obj).val();
    return function(){
        v=$(this).val();
        if(old != v){
            var dateObj = str2Date(v);
            if (dateObj == null) {
                dateObj = str2Date(old);
                $(this).val(date2Str(dateObj));
            } else {
                old = v;
                isChange = true;
                $(this).val(date2Str(dateObj));
            }
        }
    };
}
// "yyyy-MM-dd hh:mm"形式の文字列を日付型に変換する
function str2Date(dateStr) {
    var objDate = null;
    try {
        if (dateStr != null && dateStr !='') {
            dateStr = dateStr.replace("/", "-").replace("/", "-");
            var splObj = dateStr.split("-");
            if (splObj.length < 3) {
                return null;
            }
            var year = toInteger(splObj[0]);
            var month = toInteger(splObj[1]);
            splObj = splObj[2].split(" ");
            var day = toInteger(splObj[0]);
            var hours = 0;
            var minutes = 0;
            if (splObj.length >= 2) {
                splObj = splObj[1].split(":");
                hours = toInteger(splObj[0]);
                if (splObj.length >= 2) {
                    minutes = toInteger(splObj[1]);
                }
            }

            if(year != null && month != null && day != null && hours != null && minutes != null) {
                if (hours > 23) {
                    // 24時以降は23時とする
                    hours = 23;
                }
                if (minutes > 59) {
                    // 60分以降は59分とする
                    minutes = 59;
                }
                objDate = new Date(year, month - 1, day, hours, minutes);
            }
        }
    } catch(exception) {}
    return objDate;
}
// Date型Objectを"yyyy-MM-dd hh:mm"形式の文字列に変換する
function date2Str(objDate) {
    var str = null;
    if (objDate != null) {
        var year = zeroPadding(objDate.getFullYear(),4);
        var month = zeroPadding(objDate.getMonth()+1, 2);
        var day = zeroPadding(objDate.getDate(),2);
        var hours = zeroPadding(objDate.getHours(),2);
        var minutes = zeroPadding(objDate.getMinutes(),2);
        str = year + "-" + month + "-" + day + " " + hours + ":" + minutes;
    }
    return str;
}
// 文字列を数値型に変換する
function toInteger(val) {
    if (val == null || val =='') {
        return null;
    }
    var res = null;
    try {
        res = parseInt(val);
    } catch(e) {}
    return res;
}
// ゼロパディング
function zeroPadding(value, length){
    return new Array(length - ('' + value).length + 1).join('0') + value;
}

// スクリプトファイルの読み込み
// ※src:外部スクリプトファイル、callback:読み込み後コールバック
function loadScript(src, callback) {
    var done = false;
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.src = src;
    head.appendChild(script);
    // Attach handlers for all browsers
    script.onload = script.onreadystatechange = function() {
        if ( !done && (!this.readyState ||
                this.readyState === "loaded" || this.readyState === "complete") ) {
            done = true;
            callback();
            // Handle memory leak in IE
            script.onload = script.onreadystatechange = null;
            if ( head && script.parentNode ) {
                head.removeChild( script );
            }
        }
    };
}

function toogleSearch() {

  if ($("div#search .box:first").is(":hidden")) {
    $("div#search .box").slideDown(360);
    $("#btn_open").hide();
    $("#btn_close").show();
    $("#hdnSearchAreaOpen").val("1");

  } else {
    $("div#search .box").slideUp(360);
    $("#btn_open").show();
    $("#btn_close").hide();
    $("#hdnSearchAreaOpen").val("0");
  }
  setTimeout("resizeWindow()",360);
}
