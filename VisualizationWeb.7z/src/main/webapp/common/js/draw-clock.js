/**
 * @desc 時計描画
 */
MMCloud.DrawClock={};
(function() {
	//==============================================
	// const
	//==============================================
	MMCloud.DrawClock.CLOCK_TYPE_ANALOG = 1;
	MMCloud.DrawClock.CLOCK_TYPE_DEGITAL = 2;

	//==============================================
	// public
	//==============================================
	function drawClock(clockName, clockType, isEnabled, todate, timeDiff){
		// 指定タイムゾーンの時刻取得
		var date = calcTime(todate, timeDiff);

		if(clockType == MMCloud.DrawClock.CLOCK_TYPE_ANALOG) {
			drawAnalogClock(clockName, isEnabled, date);
		} else if(clockType == MMCloud.DrawClock.CLOCK_TYPE_DEGITAL) {
			drawDegitalClock(clockName, isEnabled, date);
		}
	}
	MMCloud.DrawClock.drawClock = drawClock;

	//==============================================
	// private
	//==============================================
	// アナログ時計描画
	function drawAnalogClock(clockName, isEnabled, date){
		var hour = date.getHours();
		var minute = date.getMinutes();
		var second = date.getSeconds();

		// 針
		$('#'+clockName+'_hoursHand').rotate((hour)*30+minute/2);
		$('#'+clockName+'_minutesHand').rotate(minute*6+second/10);
		$('#'+clockName+'_secondsHand').rotate(second*6);

		// AM/PM
		$('#'+clockName+'_face').removeClass('am');
		$('#'+clockName+'_face').removeClass('pm');
		$('#'+clockName+'_face').addClass(hour<12 ? 'am' : 'pm');

		// 日付表示
		$('#'+clockName+'_date').html(date.getFullYear() + '/' + getDec2(date.getMonth()+1) + '/' + getDec2(date.getDate()));
	}

	// デジタル時計描画
	function drawDegitalClock(clockName, isEnabled, date){
		// 時刻
		$('#'+clockName+'_time').html(getDec2(date.getHours()) + ':' + getDec2(date.getMinutes()));

		// 日付表示
		$('#'+clockName+'_date').html(date.getFullYear() + '/' + getDec2(date.getMonth()+1) + '/' + getDec2(date.getDate()));
	}

	// 指定タイムゾーンの時刻取得
	function calcTime(date, offset){
		var utc = date.getTime() + (date.getTimezoneOffset() * 60000);
		var newdate = new Date(utc + (3600000 * offset));
		return newdate;
	}
	
	// 2桁数字文字列を返す
	function getDec2(num){
		return ('0' + num).slice(-2);
	}

})();
