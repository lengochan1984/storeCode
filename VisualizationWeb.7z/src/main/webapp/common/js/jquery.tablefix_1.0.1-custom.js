/*
 * jQuery TableFix plugin ver 1.0.1 (customize:2014/01/08 YSK)
 * Copyright (c) 2010 Otchy
 * This source file is subject to the MIT license.
 * http://www.otchy.net
 */
(function($){
    $.fn.tablefix = function(options) {
        return this.each(function(index){
            // 処理継続の判定
            var opts = $.extend({}, options);
            var baseTable = $(this);

            // NOTE:
            // 位置計算を簡単にするため、
            // 常にスクロールバーが表示される状態（スクロールバーがいらない場合でも無効で表示）に変更している
            // また、リサイズを外部から行うため、各DIVにクラス名を追加している。

            // スクロールバーサイズを取得
            var barSize = getBarWidth();
            var sizW = barSize;
            var sizH = barSize;

            var divBorderSize = 1;

            // スクロール領域分表示サイズを減らす
            opts.height -= sizH;
            opts.width -= sizW;

            // テーブルが指定した高さより小さい場合は、高さをテーブルにあわせる。（余白を作らない）
            if (baseTable.height() < opts.height) {
                opts.height -= (opts.height - baseTable.height() - divBorderSize * 2);
            }

            // 外部 div の設定
            baseTable.wrap("<div class='baseDiv'></div>");
            var div = baseTable.parent();
            div.css({position: "relative",
                zIndex: '0'
                });

            // スクロール部オフセットの取得
            var fixRows = (opts.fixRows > 0) ? opts.fixRows : 0;
            var fixCols = (opts.fixCols > 0) ? opts.fixCols : 0;
            var offsetX = 0;
            var offsetY = 0;
            baseTable.find('tr').each(function(indexY) {
                $(this).find('td,th').each(function(indexX){
                    if (indexY == fixRows && indexX == fixCols) {
                        var cell = $(this);
                        offsetX = cell.position().left;
                        offsetY = cell.parent('tr').position().top;
                        return false;
                    }
                });
                if (indexY == fixRows) {
                    return false;
                }
            });

            // テーブルの分割と初期化
            var crossTable = baseTable.wrap('<div></div>');
            var rowTable = baseTable.clone().wrap('<div class="rowDiv"></div>');
            var colTable = baseTable.clone().wrap('<div class="colDiv"></div>');
            var bodyTable = baseTable.clone().wrap('<div class="bodyDiv"></div>');
            var crossDiv = crossTable.parent().css({position: "absolute", overflow: "hidden", zIndex: "200"});
            var rowDiv = rowTable.parent().css({position: "absolute", overflow: "hidden", zIndex: "100"});
            var colDiv = colTable.parent().css({position: "absolute", overflow: "hidden", zIndex: "99"});
            var bodyDiv = bodyTable.parent().css({position: "absolute", overflow: "scroll", zIndex: "1"});
            div.append(rowDiv).append(colDiv).append(bodyDiv);

            // クリップ領域の設定
            var bodyWidth = opts.width - offsetX;
            var bodyHeight = opts.height - offsetY;

            if (baseTable.width() < opts.width) {
                bodyWidth = baseTable.width() - offsetX + divBorderSize * 2;
            }

            crossDiv.width(offsetX + (opts.fixCols > 0 ? divBorderSize : 0))
                .height(offsetY + (opts.fixRows > 0 ? divBorderSize : 0));

            // タイトル行
            rowDiv
                .width(bodyWidth + sizH)
                .height(offsetY + divBorderSize)
                .css({left: offsetX + 'px'});
            rowTable.css({
                marginLeft: -offsetX + 'px',
                marginRight: sizH + 'px'
                , boxSizing: 'border-box'
            });

            // タイトル列
            colDiv
                .width(offsetX + (opts.fixCols > 0 ? divBorderSize : 0))
                .height(bodyHeight)
                .css({top: offsetY + 'px'});
            colTable.css({
                marginTop: -offsetY + 'px',
                marginBottom: sizW + 'px'
                , boxSizing: 'border-box'
            });

            // データ表示部
            bodyDiv
                .width(bodyWidth + sizH)
                .height(bodyHeight + sizW)
                .css({left: offsetX + 'px', top: offsetY + 'px'});
            bodyTable.css({
                marginLeft: -offsetX + 'px',
                marginTop: -offsetY + 'px',
                marginRight: sizH + 'px'
                , boxSizing: 'border-box'
            });

            if (barSize > 0) {
                rowTable.width(bodyTable.width());
                rowDiv.width(rowDiv.width() - barSize);

                //※ベースが100%指定なので明示的に指定しないとIE10などで0.5の誤差が生じる
                bodyTable.width(rowTable.width());
            }

            // スクロール連動
            bodyDiv.scroll(function() {
                rowDiv.scrollLeft(bodyDiv.scrollLeft());
                colDiv.scrollTop(bodyDiv.scrollTop());
            });

            // 外部 div の設定
            div
                .width(opts.width + sizH)
                .height(opts.height + sizW);
        });
    };
})(jQuery);

//スクロールバーの幅を取得
function getBarWidth(){
    var body = document.body;
    var outer = document.createElement("div");
    var style = outer.style;
    style.width = "100px";
    style.height = "100px";
    style.overflow = "scroll";
    style.border = "none";
    style.visibility = "hidden";
    var inner = outer.cloneNode(false);
    outer.appendChild(inner);
    document.body.appendChild(outer);
    outer.scrollTop = 200;
    var barWidth = outer.scrollTop;
    body.removeChild(outer);
    return barWidth;
}
