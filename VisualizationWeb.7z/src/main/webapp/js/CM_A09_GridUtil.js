//******************************************************************************
//タイトル：一覧共通処理
//ファイル名：CM_A09_GridUtil.js
//Copyright(C) YASKAWA Information Systems

//変更日付		変更者        	Rev.		変更内容
//-----------------------------------------------------------------------------
// 2014/06/22	YSK)中田   		1.00.00		新規作成
// 2014/08/19   YSK)中田        1.02.00     <10101-002> STEP1残件-002
// 2014/09/22   YSK)中田        1.02.00     <10101-015> 機器詳細、点検保守、報告書画面追加
// 2014/12/11   US)馬           3.00.00     <20000-002> 仕様変更No.21
// 2014/12/26   US)苗           3.00.00     <20000-002> 変更仕様No.21
// 2014/12/26   US)苗           3.00.00     <20000-002> 仕様変更No.2　障害対応
// 2015/06/18   US)楢崎         3.01.00     <30003-030> 故障苦情No.30003-027
// 2015/07/22   YSK)中田        3.01.00     <30003-045> 故障苦情No.30003-048
// 2015/12/18   US)清水         4.00.00     <40000-014> 変更仕様No.14
//******************************************************************************

/**
 * @desc grid util
 * 使用する画面で必ず以下の実装を行うこと
 * ・resizeGrid関数を実装する。
 * ・java側のActionでsort関数を実装する
 * ・Ajax用にJSON形式でデータを生成するjspを実装する。
 * 　→JSONデータは内部に"header"と"body"オブジェクトを持たせること。
 * ・java側のActionFormクラスは、FW01_14_ListFormを継承すること
 * 　継承しない場合は、fw0114SortKey、fw0114SortOrderを自クラス内で定義すること
 * ・画面への表示のために、CM_A09_GridArea.tagを表示したい箇所に埋め込むこと
 *
 * なお、以下の点にも注意する。
 * ・ソート対象のキー名（fw0114SortKey）はheader用データのsortkeyが格納される
 * ・ソート順はfw0114SortOrderには"asc"か"desc"が格納される。
 *
 */

// Gridオブジェクト
var myGrid;

// Grid用データ
var gridHeaderData;
var gridBodyData;
var gridDeletedData;

// スクロール位置
var lastScrollTop = 0;
var lastScrollLeft = 0;

var MAX_COLUMN_WIDTH = 500;		// 最大カラム幅サイズ
var MIN_COLUMN_WIDTH = 36;		// 最小カラム幅サイズ

var COL_SIZE_COOKIE_NAME = 'grid_col.size';		// カラムサイズ退避用Cookie名

var numFixedRows = 1;			// 行固定数
var numFixedColumns = 0;		// 列固定数
var page_id = "";
var noResultMsg = "No results returnd.";

var sortGridCallBack = updateGrid;	// ソート時コールバック関数デフォルト登録


// ページID設定（Cookieファイル名用）
function setPageId(_page_id)
{
    page_id = _page_id;
}

// 表示データがない場合の文字列の設定
function setNoResultMessage(_mes)
{
    noResultMsg  = _mes;
}

// ソート時コールバック関数登録
function setSortGridCallBack(_func) {
    sortGridCallBack = _func;
}

//Grid描画用HTML生成処理
function makeGridHtml()
{
    var tableSource = '';

    ////////////////////////////////////////////////////////////
    // テーブル ヘッダ
    tableSource = makeGridHeaderHtml(tableSource);

    ////////////////////////////////////////////////////////////
    // テーブル ボディ
    tableSource = makeGridBodyHtml(tableSource);

    $('#divGrid,#divGridSS').remove();
    $('#tableArea').append('<div id="divGrid"></div>');
    $('#divGrid').html('<table class="sortable tbl2" id="tableGrid" border="1">' + tableSource + '</table>');

}

function makeGridDataHtml(src)
{
    var dest = '';
    var type = src['disp_type'];
    var deleteFlag = src['deleted'];
    var deleteItemClass = "";

    if(deleteFlag == "true") {
        deleteItemClass = 'deleteItem ';
    }

    if( type == "label") {
        dest += ('<span class="' + deleteItemClass + src['disp_align'] + '">');
        if(src['name'] != null) {
            dest += src['name'];
        }
        dest += '</span>';

    }
    else if( type == "bg_label"){
        dest += ('<div class="' + src['param1'] + '">');
        dest += ('<span class="' + deleteItemClass + src['disp_align'] + '">');
        if(src['name'] != null) {
            dest += src['name'];
        }
        dest += '</span>';
        dest += '</div>';

    }
    else if( type == "color_label"){
        if(src['param2'] != null){
            dest += ('<div class="' + src['param1'] + '" style="color:'+ src['param2'] + '">');
        }else{
            dest += ('<div class="' + src['param1'] + '">');
        }
        dest += ('<span class="' + deleteItemClass + src['disp_align'] + '">');
        if(src['name'] != null) {
            dest += src['name'];
        }
        dest += '</span>';
        dest += '</div>';

    }
    else if( type == "bg_labelColor"){
        if(src['name'] == '-'){
            dest += ('<div class="' + src['param1'] + '">');
        }else{
            dest += ('<div class="' + src['param1'] + '" style="background-color:'+ src['param2'] +'; color:#FFFFFF">');
        }
        dest += ('<span class="' + deleteItemClass + src['disp_align'] + '">');
        if(src['name'] != null) {
            dest += src['name'];
        }
        dest += '</span>';
        dest += '</div>';

    }
    else if( type == "bg_link"){
        if(src['disabled'] == 'true') {
            dest += ('<a href="javascript:void(0);" >');
        }else{
            dest += ('<a href="javascript:void(0);" onclick="'+ src['param2'] + '">');
        }

        dest += ('<div class="' + src['param1'] + ' ' + src['disp_align'] + '">');
        dest += ('<span class="' + deleteItemClass + '">');

        if(src['name'] != null) {
            dest += src['name'];
        }
        dest += '</span>';
        dest += '</div>';
        dest += ('</a>');

    }
    else if( type == "button"){
        dest += ('<span class="icon ' + deleteItemClass + src['disp_align'] + '">');
        if(src['disabled'] == 'true') {
            dest += ('<div class="' + src['param2'] + ' disable">');
            dest += ('<a class="disable" href="javascript:void(0);" >');

        } else {
            var title = '';
            if (src['title'] != null && src['title'] != undefined) {
                title = ' title="' + src['title'] + '"';
            }
            dest += ('<div class="' + src['param2'] + '">');
            dest += ('<a ');
            dest += ('href="javascript:void(0);" onclick="'+ src['param1'] + '"' + title + '>');

        }
        dest += ('<span>' + src['name'] + '</span>');
        dest += '</a>';
        dest += '</div>';
        dest += '</span>';

    }
    else if( type == "icon_link"){
        dest += ('<span class="' + src['disp_align'] + ' icon">');
        if(src['disabled'] == 'true') {
            dest += ('<a class="disable icon_grid ' + deleteItemClass + src['param2'] + '" ' );
            dest += ('href="javascript:void(0);" ></a>');
        }else{
            dest += ('<a class="icon_grid '  + deleteItemClass + src['param2'] + '" ');
            dest += ('href="javascript:void(0);" onclick="'+ src['param1'] + '"></a>');
        }
        dest += '</span>';

    }
    else if( type == "link"){
        dest += ('<span class="' + deleteItemClass + src['disp_align'] + '">');
        if(src['disabled'] == 'true') {
            dest += '<a href="javascript:void(0);" class="disable">';

        } else {
            dest += ('<a href="javascript:void(0);" onclick="' + src['param1'] + '">');

        }
        dest += src['name'];
        dest += '</a>';
        dest += '</span>';

    }
    else if((type == "checkbtn")||((type == "labelcheckbtn"))){

        dest += ('<span class="' + src['disp_align'] + '">');
        dest += '<input type="checkbox" ';
        dest += ('name="'+ src['name'] + '" ');
        dest += ('id="'+ src['db_id'] + '" ');

        if(src['param1'] != null) {
            dest += ('onChange="'+ src['param1'] + '" ');
        }

        if(src['param2'] == 'checked') {
            dest += 'checked="checked" ';
        }

        if(src['param3'] != null) {
            dest += ('value="'+ src['param3'] + '" ');
        }

        if(src['param4'] != null) {
            dest += ('class="'+ src['param4'] + '" ');
        }

        if(src['disabled'] == 'true') {
            dest += 'disabled="disabled" ';
        }

        dest += '></input>';

        if(type == "labelcheckbtn"){
            dest += ('<label for="' + src['name'] + '" '  + 'class="' + deleteItemClass +  '">');
            dest += src['name'];
            dest += '</label>';
        }
        dest += '</span>';

    }
    else if( type == "icon"){
        var title = '';
        if (src['title'] != null && src['title'] != undefined) {
            title = ' title="' + src['title'] + '"';
        }
        dest += ('<span class="' + deleteItemClass + src['disp_align'] + ' icon ');
        if(src['disabled'] == 'true') {
            dest += ('disable icon_grid ' + src['param1'] + '" ' + title + '>' );
        }else{
            dest += ('icon_grid '  + src['param1'] + '" ' + title + '>');
        }
        dest += '</span>';

    }
    else if( type == "img"){
        dest += ('<div class="' + src['param1'] + '">');
        dest += ('<img class="' + deleteItemClass + src['param2'] + '" src="' + src['param3'] +'">');
        dest += '</div>';

    }
    /*NhungDTN update begin*/
    else if (type == "icon2") {
        var title = '';
        if (src['title'] != null && src['title'] != undefined) {
            title = ' title="' + src['title'] + '"';
        }
        if (src['param1'] =='yellowss') {
            dest += ('<span class="objL icon2 icon_grid blackss"></span>');
            dest += ('<span class="objC icon2 icon_grid yellowss"></span>');
            dest += ('<span class="objR icon2 icon_grid blackss"></span>');

        }else if (src['param1'] =='greenss') {
            dest += ('<span class="objL icon2 icon_grid greenss"></span>');
            dest += ('<span class="objC icon2 icon_grid blackss"></span>');
            dest += ('<span class="objR icon2 icon_grid blackss"></span>');
        }else if (src['param1'] =='redss') {
            dest += ('<span class="objL icon2 icon_grid blackss"></span>');
            dest += ('<span class="objC icon2 icon_grid blackss"></span>');
            dest += ('<span class="objR icon2 icon_grid redss"></span>');
        }else {
            dest += ('<span class="objL icon2 icon_grid blackss"></span>');
            dest += ('<span class="objC icon2 icon_grid blackss"></span>');
            dest += ('<span class="objR icon2 icon_grid blackss"></span>');
        }
    }
    /*NhungDTN update end*/
    else if ( type == "statusGraph"){
        var data = src['name'];
        var statusArr = data.split(",");

        dest += ('<table class="statusGraph">');
        dest += ('<tr>');
        for (var i=0; i<statusArr.length; i++ ) {
            dest += ('<td class="' + statusArr[i] + '"></td>');
        }
        dest += ('</tr>');
        dest += ('</table>');
    }
    else if ( type == "tooltip") {
        dest += ('<div class="' + src['disp_align'] + '">');
        dest += ('<span class="' + deleteItemClass + '" onmouseover="' + src['param1'] + '" onmouseout="' + src['param2'] +  '" >' + src['name'] + '</span>');
        dest += ('</div>');
    }
    else if (type == "multi") {
        var records = src['records'];
        dest += '<table style="border:0px; padding:0px;"><tr>';
        for (var i = 0; i < records.length; i++) {
            var record = records[i];

            dest += ('<td style="border:0px; padding: 0px 2px 0px 2px;">');
            dest += (makeGridDataHtml(record));
            dest += ('</td>');
        }
        dest += '</tr></table>';
    }
    else {
        dest += ('<span class="' + deleteItemClass + src['disp_align'] + '">');
        if(src['name'] != null) {
            dest += src['name'];
        }
        dest += '</span>';

    }


    return dest;
}

//Grid Header用HTML生成処理
function makeGridHeaderHtml(tableSource)
{
    var formObj = getFormObject('');
    var nowSortColName = $(formObj).find('#fw0114SortKey').val();
    var nowSortColOrder = $(formObj).find('#fw0114SortOrder').val();

    tableSource += '<thead><tr>';

    var drawColCount = 0;
    for (var i = 0 ; i < gridHeaderData.length ; i++) {

        if ((gridHeaderData[i]['hidden'] != null)&&(gridHeaderData[i]['hidden']=='true')) {
            // 列が非表示指定のため、読み飛ばす。
            continue;
        }

        var tmpStr = '';

        tmpStr += ('<th><div id="headCol_' + drawColCount + '" ');

        if ((gridHeaderData[i]['sortable'] != null)&&(gridHeaderData[i]['sortable']=='true')) {
            // ソート対象列の場合

            if (nowSortColName == gridHeaderData[i]['sortkey']) {
                // ソート中の列
                tmpStr += ('class="' + nowSortColOrder + '" ');

            }
            else{
                // ソート中ではない列
                // TODO:クラス名変更要
                tmpStr += 'class="sort" ';
            }

            // クリック時のイベント
            tmpStr += ('onclick=\"sortGrid(' + drawColCount + ', \'' + gridHeaderData[i]['sortkey'] + '\')"');
        }
        else {
            // ソート中ではない列
            // TODO:専用クラス名設定要
            //tmpStr += 'class="sort" ';

        }

        tmpStr +=  '>';

        // カラム名設定
        tmpStr += makeGridDataHtml(gridHeaderData[i]);

        tmpStr += '</div></th>';

        tableSource += tmpStr;

        drawColCount++;
    }

    tableSource += '</tr></thead>';

    return tableSource;
}

//Grid Body用HTML生成処理
function makeGridBodyHtml(tableSource)
{
    tableSource += '<tbody>';

    for ( var i = 0; i < gridBodyData.length; i++) {
        tableSource += '<tr>';

        // 行ごと削除指定の確認
        if( gridDeletedData != null && gridDeletedData[i] != null) {
            deleteFlag = gridDeletedData[i];
        } else {
            deleteFlag = "false";
        }

        for ( var j = 0; j < gridBodyData[i].length; j++) {

            if( ( gridHeaderData[j]['hidden'] != null )&&( gridHeaderData[j]['hidden']=='true' ) ){
                // 列が非表示指定のため、読み飛ばす。
                continue;
            }

            var tmpStr = '';

            tmpStr += '<td>';

            if ( gridBodyData[i][j]['disp_align'] == null ){
                gridBodyData[i][j]['disp_align'] = gridHeaderData[j]['col_align'];
            }

            if ( gridBodyData[i][j]['disp_type'] == null ){
                gridBodyData[i][j]['disp_type'] = gridHeaderData[j]['col_type'];
            }

            // 削除表示の個別指定の確認
            if (gridBodyData[i][j]['deleted'] == null) {
                // 削除表示の個別指定がないので、
                // 行ごとの削除指定を使用する。
                gridBodyData[i][j]['deleted'] = deleteFlag;
            }

            tmpStr += makeGridDataHtml( gridBodyData[i][j]);

            tmpStr += '</td>';

            tableSource += tmpStr;
        }

        tableSource += '</tr>';
    }

    tableSource += '</tbody>';

    return tableSource;
}

//Grid描画処理
function drawGrid() {
    myGrid = new Grid('divGrid', { srcType : 'dom',
                                    srcData : 'tableGrid',
                                    allowColumnResize : true,
                                    supportMultipleGridsInView: true,
                                    onResizeColumnEnd : function(num, width) { saveColumnSize(num, width); },
                                    onLoad : (function() {restoreColumnSize(); restoreScroll(); resizeGrid();}),
                                    fixedCols : numFixedColumns,    // 列固定数
                                    fixedRows : numFixedRows,     	// 行固定数
                                    noResultMsg : noResultMsg
                                  } );
}

//カラムサイズ保存処理
function saveColumnSize(num, width) {

    // widthが大き過ぎたら、強制的に幅補正
    if (width > MAX_COLUMN_WIDTH) {
        width = MAX_COLUMN_WIDTH;
        resizeColumnWidth(num, width);
    }

    // widthが小さ過ぎたら、強制的に幅補正
    if(width < MIN_COLUMN_WIDTH) {
        width = MIN_COLUMN_WIDTH;
        resizeColumnWidth(num, width);
    }

    // カラムサイズ取得
    var str = '';
    for (var i = 0; i < myGrid.columns; i++) {
        str = str + parseInt(myGrid.css.rules['.g_Cl' + i]['width']) + ',';
    }

    // cookie保存
    var cookieName = (page_id + "_"+ COL_SIZE_COOKIE_NAME );
    $.cookie(cookieName, str, { expires : 30, path : '/' });
}

// カラムサイズ復元処理
function restoreColumnSize() {
    // cookie取得
    var cookieName = (page_id + "_"+ COL_SIZE_COOKIE_NAME );
    var str = $.cookie(cookieName);

    if (!str) {
        return;
    }

    // カラムサイズ設定
    var size = str.split(",");
    for(var i = 0 ; i < myGrid.columns ; i++) {
        var s = parseInt(size[i]);
        if(s > 0){
            if(s > MAX_COLUMN_WIDTH) {
                s = MAX_COLUMN_WIDTH;
            }

            if(s < MIN_COLUMN_WIDTH) {
                s = MIN_COLUMN_WIDTH;
            }

            resizeColumnWidth(i, s);
        }
    }

}

// カラム幅サイズ変更処理
function resizeColumnWidth(num, width) {

    myGrid.css.rules['.g_Cl' + num]['width'] = width + 'px';
    myGrid.css.rules['.g_RS' + num]['margin-left'] = (width - 2) + 'px';
    myGrid.columnWidths[num] = width - 0;
    myGrid.setRules();
    myGrid.syncScrolls();

}

// スクロール位置保存処理
function saveScroll() {

    lastScrollTop = myGrid.body.scrollTop || 0;
    lastScrollLeft = myGrid.body.scrollLeft || 0;

}

// スクロール位置復元処理
function restoreScroll() {

    myGrid.body.scrollTop = lastScrollTop;
    myGrid.body.scrollLeft = lastScrollLeft;

}

// スクロール位置のリセット
function resetScroll() {
    myGrid.body.scrollTop = 0;
    myGrid.body.scrollLeft = 0;
}

// ソート処理
function sortGrid(idx, dbField) {

    // formオブジェクト取得
    var formObj = getFormObject('');

    // 現地日時チェックボックスが存在する場合は、チェックを外す
    if ($('#displayLocaltime')) {
        $('#displayLocaltime').prop('checked', '');
    }

    // ソート種別
    var sortType;

    for (var i = 0; i < myGrid.columns; i++) {
        if (i == idx) {
            if ($('#headCol_' + i).hasClass('asc')) {
                $('#headCol_' + i).removeClass('asc');
                $('#headCol_' + i).addClass('desc');
                sortType = 'desc';
            }
            else {
                $('#headCol_' + i).removeClass('sort');
                $('#headCol_' + i).removeClass('desc');
                $('#headCol_' + i).addClass('asc');
                sortType = 'asc';
            }

            $('#sortCol').val(idx);
            $('#sortType').val(sortType);

            $(formObj).find('#fw0114SortKey').val(dbField);
            $(formObj).find('#fw0114SortOrder').val(sortType);

        }
        else {
            if ($('#headCol_'+i).hasClass('sort')||$('#headCol_'+i).hasClass('asc')||$('#headCol_'+i).hasClass('desc')) {
                $('#headCol_' + i).removeClass('sort');
                $('#headCol_' + i).removeClass('asc');
                $('#headCol_' + i).removeClass('desc');
                $('#headCol_' + i).addClass('sort');
            }
        }
    }

    var url = $(formObj).attr('action') + 'sort';
    linkSubmitAjax(url, $(formObj).serialize(), sortGridCallBack);

}

function fillLastColumn() {
    var sum = 0;

    for (var i = 0; i < myGrid.columns; i++) {
        sum += parseInt(myGrid.css.rules['.g_Cl' + i]['width']);
    }

    if(sum < $('#divGrid').width() - MARGIN_SCROLL_BAR) {
        resizeColumnWidth(myGrid.columns - 1, parseInt(myGrid.css.rules[".g_Cl" + (myGrid.columns - 1)]["width"]) + ($('#divGrid').width()) - MARGIN_SCROLL_BAR - sum);
        myGrid.body.scrollLeft = 0;
    }
}

function updateGrid(_json)
{
    try{
        var jsondata = JSON.parse(_json);

        // トータルページ数の更新
        updatePageArea(jsondata.totalPage);

        // ページ数更新
        updatePageCnt(jsondata);


        // Gridデータの更新
        gridHeaderData = jsondata.header;
        gridBodyData = jsondata.body;
        gridDeletedData = jsondata.deletedData;

        ////////////////////////////////////////////////////////////
        // 設定したデータでGrid用HTML生成
        makeGridHtml();

        ////////////////////////////////////////////////////////////
        // Grid描画
        drawGrid();
    }catch(e){
        alert(e);
    }
}

// parse済みJSONデータによる一覧更新処理
function updateGridWithParsedData(_parsedJsonData)
{
    try{
        // トータルページ数の更新
        updatePageArea(_parsedJsonData.totalPage);

        // ページ数更新
        updatePageCnt(_parsedJsonData);

        // Gridデータの更新
        gridHeaderData = _parsedJsonData.header;
        gridBodyData = _parsedJsonData.body;
        gridDeletedData = _parsedJsonData.deletedData;

        ////////////////////////////////////////////////////////////
        // 設定したデータでGrid用HTML生成
        makeGridHtml();

        ////////////////////////////////////////////////////////////
        // Grid描画
        drawGrid();
    }catch(e){
        alert(e);
    }
}

//parse済みJSONデータによる一覧更新処理（スクロール位置を維持）
function updateGridWithParsedDataKeepingScroll(_parsedJsonData)
{
    try{
        // トータルページ数の更新
        updatePageArea(_parsedJsonData.totalPage);

        // ページ数更新
        updatePageCnt(_parsedJsonData);

        // Gridデータの更新
        gridHeaderData = _parsedJsonData.header;
        gridBodyData = _parsedJsonData.body;
        gridDeletedData = _parsedJsonData.deletedData;

        ////////////////////////////////////////////////////////////
        // Gridスクロール位置の保存
        if (myGrid) {
            saveScroll();
        }

        ////////////////////////////////////////////////////////////
        // 設定したデータでGrid用HTML生成
        makeGridHtml();

        ////////////////////////////////////////////////////////////
        // Grid描画
        drawGrid();

        ////////////////////////////////////////////////////////////
        // スクロール位置復元
        restoreScroll();
    }catch(e){
        alert(e);
    }
}
