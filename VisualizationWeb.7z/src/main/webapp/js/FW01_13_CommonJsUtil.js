//******************************************************************************
//タイトル：画面制御ユーティリティ
//ファイル名：FW01_13_CommonJsUtil.js
//Copyright(C) YASKAWA Information Systems

//変更日付		変更者        	Rev.		変更内容
//-----------------------------------------------------------------------------
// 2009/08/26	YSK)西田　浩二	1.00.00  	新規作成
// 2014/06/22	YSK)中田   		1.00.00		<10000-012> 不具合対応(PT前No.55)
// 2014/06/25   YSK)森山        1.00.00     <10000-060> 不具合対応(回帰試験No.22)
// 2014/08/04   YSK)植山        1.02.00     <demo-001> リリース後不具合対応
// 2014/12/01   US)楢崎         3.00.00     <20000-005> 変更仕様No.11
// 2014/12/17   US)萩尾         3.00.00     <20000-020> 変更仕様No.8
// 2016/03/12   US)甲斐         4.00.00     <40000-028> 変更仕様No.28
// 2016/08/15   US)萩尾         C1.01.00    画面リサイズ共通対応
// 2017/03/03   US)楢崎         C1.01.00    グラフ横軸の共通関数作成（前詰負荷平準対応）
//******************************************************************************

/**
 * 最上位のフレームを確認し、トップ画面のターゲットを取得する。
 */
function getTopFrame() {
    if (window.top.fw0135 == undefined) {
        return '_top';
    } else {
        return 'fw0135';
    }
}

/**
 *　フォーカスセット
 *　@param focusCtl:コントロールID
 *	@return
 */
function setErrorFocus(focusCtl) {
    $('input,select,textarea').removeClass('c_error');
    $('#' + focusCtl).focus();
    var type = $('#' + focusCtl).prop("tagName");
    if("SELECT" == type.toUpperCase()){
        $('#' + focusCtl).addClass('c_error');
//        $('#' + focusCtl).combobox("set_texterror",'c_error');
    }else{
        $('#' + focusCtl).addClass('c_error');
    }
     $('#' + focusCtl).select();
}

/**
 *　エラー背景色クリア
 *	@return
 */
function clearError() {
    //エラースタイルの初期化
    $('input,select,textarea').removeClass('c_error');
}

/**
 * ダウンロード用サブミット処理
 * 画面遷移しないため、submit後に2重クリック防止画面解除する。
 * @param methodName：アクションメソッド名
 */
function downloadSubmit(id,methodName) {
    // 二重クリック防止
    MaskPage();

    //var frmElement = $('#' + id).parents('form').get(0);
    var frmElement = getFormObject(id);
    var semicolIdx = frmElement.action.indexOf(';');
    var actionName = frmElement.action;
    if (semicolIdx != -1) {
        actionName = actionName.substring(0,semicolIdx);
    }
    frmElement.action = actionName + methodName;
    frmElement.submit();

    // 画面遷移しないので、actionプロパティ値を元に戻す
    frmElement.action = actionName;

    // 二重クリック防止解除
    UnMaskPage();
}

/**
 * <a>タグ用サブミット処理
 * ActionFormにパラメータが設定されない為、Aタグによる画面遷移は
 * 必ず本メソッドで実行する事。
 * @param methodName：アクションメソッド名
 */
function linkSubmit(id,methodName) {
    // 二重クリック防止
    MaskPage();

    //var frmElement = $('#' + id).parents('form').get(0);
    var frmElement = getFormObject(id);
    var semicolIdx = frmElement.action.indexOf(';');
    var actionName = frmElement.action;
    if (semicolIdx != -1) {
        actionName = actionName.substring(0,semicolIdx);
    }
    frmElement.action = actionName + methodName;
    frmElement.submit();
}

/**
 * <a>タグ用サブミット処理
 * ActionFormにパラメータが設定されない為、Aタグによる画面遷移は
 * 必ず本メソッドで実行する事。
 * @param methodName：アクションメソッド名
 */
function linkSubmitTarget(targetName,actionName) {
    var frmElement = getFormObject('');
    frmElement.target = targetName;
    frmElement.action = actionName;
    frmElement.submit();
}


/**
 * フォームオブジェクト取得
 * @param divId
 * @return
 */
function getFormObject(divId) {
    var formObj = null;
    $('form').each(function () {
        if (divId == null || divId == '') {
            if ($(this).parent('div').size() == 0) {
                formObj = this;
            }
        } else {
            if ($(this).parent('div[id=' + divId + ']').size() != 0) {
                formObj = this;
            }
        }
    });
    return formObj;
}

/**
 * Windowクローズ
 * @param winobj:Windowオブジェクト
 * @return
 */
function closeWin(winobj) {
    if(winobj != undefined){
        if (winobj.closed == false) {
            winobj.close();
        }
    }
}

/**
 * ソート実行
 * @param sortKey
 * @return
 */
function sortList(lnkId,sortKey,order,divId) {
    var formObj = getFormObject(divId);
    $(formObj).find('#fw0114PageNo').val(1);
    $(formObj).find('#fw0114SortKey').val(sortKey);
    $(formObj).find('#fw0114SortOrder').val(order);
    if (divId == '') {
        formObj.submit();
    } else {
        alert($(formObj).attr('action'));
    }
}
/**
 * ページ切替ボタンスタイル変更
 * @param nowPage：現在ページ
 * @param totalPage：合計ページ
 */
function pageCtlStyle(nowPage,totalPage,divId) {
    if (totalPage == 1) {
        changeBtnStyle(divId, ['btnTop','btnAhead','btnNext','btnLast'], false);
    } else if(nowPage == 1) {
        changeBtnStyle(divId, ['btnTop','btnAhead'], false);
    } else if (nowPage == totalPage) {
        changeBtnStyle(divId, ['btnNext','btnLast'], false);
    }
}

/**
 * ページ切替ボタン押下時イベント
 * @param nextFlg：{top:先頭、ahead:前頁、next:次頁、last:最終、pulldown:件数切替}
 * @param totalPage：合計ページ数
 * @return
 */
function pageChange(nextFlg,totalPage,divId,callback) {
    var formObj = getFormObject(divId);
    var ctlName = '';
    switch (nextFlg) {
    case 'top':
        ctlName = 'btnTop';
        $(formObj).find('#fw0114PageNo').val(1);
        break;
    case 'ahead':
        ctlName = 'btnAhead';
        var now = parseInt($('#fw0114PageNo').val());
        $(formObj).find('#fw0114PageNo').val(now - 1);
        break;
    case 'next':
        ctlName = 'btnNext';
        var now = parseInt($('#fw0114PageNo').val());
        $(formObj).find('#fw0114PageNo').val(now + 1);
        break;
    case 'last':
        ctlName = 'btnLast';
        $(formObj).find('#fw0114PageNo').val(totalPage);
        break;
    case 'pulldown':
        ctlName = 'fw0114ListSize';
        $(formObj).find('#fw0114PageNo').val(1);
        break;
    default:
        break;
    }
    if (divId == '') {
        linkSubmit('','');
    } else {
        linkSubmitAjax($(formObj).attr('action'),$(formObj).serialize(),callback);
    }
}

/**
 * ページ切替ボタン押下時イベント
 * @param nextFlg：{top:先頭、ahead:前頁、next:次頁、last:最終、pulldown:件数切替}
 * @param actionFunc : アクションメソッド名
 * @return
 */
function pageChangeEx(nextFlg,divId,callback,actionFunc) {
    var formObj = getFormObject(divId);
    var totalPage = parseInt($('#totalPage').text());
    // 画面にチェック関数が実装されていれば実行
    try {
        if (pageChangePreCheck) {
            if (!pageChangePreCheck()) {
                return;
            }
        }
    } catch(e) {
    }
    switch (nextFlg) {
    case 'top':
        $(formObj).find('#fw0114PageNo').val(1);
        $('select[name="fw0114PageNo"]').val(1);
        $('.pager .tdRectLine input').val(1); //HanLN add
//        $('#fw0114PageNo').combobox("change_select",1);
        break;

    case 'ahead':
       var now = parseInt($('#fw0114PageNo').val());
       $('select[name="fw0114PageNo"]').val(now - 1);
       $('.pager .tdRectLine input').val(now - 1); //HanLN add
//        $('#fw0114PageNo').combobox("change_select",now - 1);
        break;

    case 'next':
        var now = parseInt($('#fw0114PageNo').val());
        $('select[name="fw0114PageNo"]').val(now + 1);
        $('.pager .tdRectLine input').val(now + 1); //HanLN add
//        $('#fw0114PageNo').combobox("change_select",now + 1);
        break;

    case 'last':
        $('select[name="fw0114PageNo"]').val(totalPage);
        $('.pager .tdRectLine input').val(totalPage); //HanLN add
//        $('#fw0114PageNo').combobox("change_select",totalPage);
        break;

    case 'pulldown':
        $('select[name="fw0114PageNo"]').val(1);
        $('.pager .tdRectLine input').val(1); //HanLN add
//        $('#fw0114PageNo').combobox("change_select",1);
        break;

    case 'editNo':
        var now = parseInt($('#fw0114PageNo').val());

        if ( totalPage < now ) {
            $('select[name="fw0114PageNo"]').val(totalPage);
//            $('#fw0114PageNo').combobox("change_select",totalPage);
        } else if ( now < 1 ) {
            $('select[name="fw0114PageNo"]').val(1);
//            $('#fw0114PageNo').combobox("change_select",1);
        }

        break;

    default:
        break;
    }

    updatePagerButtons(divId);

    if (divId == null) {
        if( actionFunc == '' )
        {
            linkSubmit('','');
        } else {
            linkSubmit('',actionFunc);
        }

    } else {

        if( actionFunc == null || actionFunc == '' ) {
            linkSubmitAjax($(formObj).attr('action'),$(formObj).serialize(),callback);

        } else {
            linkSubmitAjax(actionFunc,$(formObj).serialize(),callback);

        }
    }
}

/**
 * ページエリアボタン更新処理
 * @param totalPage：合計ページ数
 * @return
 */
function updatePagerButtons(divId) {
    var formObj = getFormObject(divId);
    var totalPage = parseInt($('#totalPage').text());
    var nowPage = $(formObj).find('#fw0114PageNo').val();

    if(totalPage == 1){
        $('#pager_last_back_btn').addClass('disable');
        $('#pager_back_btn').addClass('disable');
        $('#pager_forward_btn').addClass('disable');
        $('#pager_last_forward_btn').addClass('disable');

        disableAnchorTag($('#pager_last_back_btn').find('a'));
        disableAnchorTag($('#pager_back_btn').find('a'));
        disableAnchorTag($('#pager_forward_btn').find('a'));
        disableAnchorTag($('#pager_last_forward_btn').find('a'));

    }
    else if(nowPage == 1){
        $('#pager_last_back_btn').addClass('disable');
        $('#pager_back_btn').addClass('disable');
        $('#pager_forward_btn').removeClass('disable');
        $('#pager_last_forward_btn').removeClass('disable');

        disableAnchorTag($('#pager_last_back_btn').find('a'));
        disableAnchorTag($('#pager_back_btn').find('a'));
        enableAnchorTag($('#pager_forward_btn').find('a'));
        enableAnchorTag($('#pager_last_forward_btn').find('a'));

    }
    else if(nowPage == totalPage){
        $('#pager_last_back_btn').removeClass('disable');
        $('#pager_back_btn').removeClass('disable');
        $('#pager_forward_btn').addClass('disable');
        $('#pager_last_forward_btn').addClass('disable');

        enableAnchorTag($('#pager_last_back_btn').find('a'));
        enableAnchorTag($('#pager_back_btn').find('a'));
        disableAnchorTag($('#pager_forward_btn').find('a'));
        disableAnchorTag($('#pager_last_forward_btn').find('a'));

    }
    else{
        $('#pager_last_back_btn').removeClass('disable');
        $('#pager_back_btn').removeClass('disable');
        $('#pager_forward_btn').removeClass('disable');
        $('#pager_last_forward_btn').removeClass('disable');

        enableAnchorTag($('#pager_last_back_btn').find('a'));
        enableAnchorTag($('#pager_back_btn').find('a'));
        enableAnchorTag($('#pager_forward_btn').find('a'));
        enableAnchorTag($('#pager_last_forward_btn').find('a'));

    }
}

function enableAnchorTag(selector) {

    selector.removeClass('disable');

    var onclick_back_attr = selector.attr("onclick_back");

    if (onclick_back_attr) {
        selector.attr("onclick",onclick_back_attr);
        selector.removeAttr("onclick_back");
    }
}

function disableAnchorTag(selector) {

    selector.addClass('disable');

    var onclick_attr = selector.attr("onclick");

    if (onclick_attr) {
        selector.attr("onclick_back",onclick_attr);
        selector.removeAttr("onclick");
    }
}


/**
 * ページエリアタグ更新処理
 * @param totalPage：合計ページ数
 * @return
 */
function updatePageArea(totalPage) {

    // ページ数の更新
    $('#totalPage').text(totalPage);

    if (totalPage!=$('#fw0114PageNo').children().length) {
        // トータルページ数が変わっているので、プルダウンを作り直し。
        // 合計ページ数が変わっている場合は、
        // プルダウンの選択は1番目に戻る

        // ページ数（プルダウン）の更新
        $('#fw0114PageNo > option').remove();
        var count = 0;
        for ( count = 1; count <= totalPage; count++) {
            $('#fw0114PageNo').append($('<option>').html(count).val(count));
        }
    }

    // ボタン状態の更新
    updatePagerButtons('');
}

/**
 * ページエリアタグ更新処理
 * @param totalPage：合計ページ数
 * @return
 */
function updatePageCnt(jsondata) {
    if($('#spanSearchResultCount').size() <= 0){
        return ;
    }
    var allSize = parseInt(jsondata.allSize);
    var maxSize = parseInt(jsondata.searchResultMax);
    var msg = jsondata.pageCntMsg;
    $("#spanSearchResultCount").html(msg);
    $('#spanSearchResultCount').removeClass();
    if(allSize >= maxSize){
        $("#spanSearchResultCount").attr("class","searchResultCountOverMax w10");
    } else {
        $("#spanSearchResultCount").attr("class","w10");
    }

}

/**
 * ページ切替ボタン押下時イベント
 * @param divId : divタグのID
 * @param callback : コールバックメソッド名
 * @param actionFunc : アクションメソッド名
 * @return
 */
function matrixPageChange(divId,callback,actionFunc) {
    var formObj = getFormObject(divId);

    if (divId == null || divId == '') {
        if(actionFunc == null || actionFunc == '')
        {
            linkSubmit('','');
        } else {
            linkSubmit('',actionFunc);
        }

    } else {

        if( actionFunc == null || actionFunc == '' ) {
            linkSubmitAjax($(formObj).attr('action'),$(formObj).serialize(),callback);

        } else {
            linkSubmitAjax(actionFunc,$(formObj).serialize(),callback);
        }
    }
}


/**
 * 表示中のソートキーリンク非活性化
 * @return
 */
function headerLinkStyle(divId) {
    var formObj = getFormObject(divId);
    var sortKey = $(formObj).find('#fw0114SortKey').val();
    var sortOrder = $(formObj).find('#fw0114SortOrder').val();

    if (sortKey != null && sortKey != '') {
        var lnkId = 'lnk';
        lnkId = lnkId.concat(sortKey);
        if (sortOrder == 'A') {
            lnkId = lnkId.concat('_asc');
        } else {
            lnkId = lnkId.concat('_desc');
        }
        $(formObj).find('#' + lnkId).attr('disabled','true');
        $(formObj).find('#' + lnkId).removeAttr('href');
    }
}

/**
 * <a>サブミット処理(Ajax)
 * ActionFormにパラメータが設定されない為、Aタグによる画面遷移は
 * 必ず本メソッドで実行する事。
 * get送信によるAjax通信だが、別Window時の対応ができていないため
 * 今後使用する場合はlinkSubmitForAjaxを使用すること。
 * 既存アプリとの整合性をとるために残している
 */
function linkSubmitAjax(_url, _params, _func) {
    // 二重クリック防止
    MaskPage();

     linkSubmitForAjax(_url, "post", _params, _func, null);

}

 /**
  * Ajax送信(get送信)
  * ActionFormにパラメータが設定されない為、Aタグによる画面遷移は
  * 必ず本メソッドで実行する事。
  * ※エラーメッセージ時のコールバックは「error_callback(fnc)」
  * @param _url:遷移先URL
  * @param _type:送信タイプ 'post' or 'get'
  * @param _params：送信パラメーア
  * @param _func：コールバック関数
  * @param _winMode：Window区分'popwin' Window.openで開いた別Window null->メイン画面
  * @return
  */
function linkSubmitForAjax(_url, _type, _params, _func, _winMode) {

     var queryStr = '';

     queryStr = createParamForAjax(_params);

    $.ajax(
        {
            ifModified : false,
            cache : false,
            url : _url,
            data : queryStr,
            type : _type,
            error : function (req, status, throwable) {
                AjaxErrorCallBack(null, null, null, null, false);
            },
            success  : function(xml) {
                AjaxSuccessCallBack(xml, null, null, null, null, _func, _winMode, false);
            }
        }
    );

}

/**
 * Ajax送信(get送信)
 * ActionFormにパラメータが設定されない為、Aタグによる画面遷移は
 * Ajaxが複数回通信を行う必要なときには、マスク表示・非表示処理が画面JSでコントロールするため、
 * マスクを表示しない関数です。
 * 注意：マスクを消す処理をコールコールバック関数で記述しなければならない
 * @param _url:遷移先URL
 * @param _type:送信タイプ 'post' or 'get'
 * @param _params：送信パラメーア
 * @param _func：コールバック関数
 * @return
 */
function linkSubmitForAjaxNoMask(_url, _type, _params, _func) {

    var queryStr = '';
    queryStr = createParamForAjax(_params);
   $.ajax(
       {
           ifModified : false,
           cache : false,
           url : _url,
           data : queryStr,
           type : _type,
           error : function (req, status, throwable) {
               AjaxErrorCallBack(null, null, null, null, false);
           },
           success  : function(xml) {
               _func(xml);
           }
       }
   );

}

/**
 * Ajax送信時のパラメータ生成
 * @param _params	パラメータ
 * @return	生成したパラメータ
 */
function createParamForAjax(_params) {
         var queryStr = '';

        if (!isString(_params)) {
            queryStr = jQuery.param(_params);
        } else {
            queryStr = _params;
        }
        if (queryStr != '') {
            queryStr = queryStr.concat('&');
        }
        queryStr = queryStr.concat(jQuery.param({fw0117RequestKbn:'ajax'}));

        return queryStr;
}


/**
 * Ajaxエラー時のCallBack処理
 * @param _frmObj:Formオブジェクト
 * @param _btnDisabled：非活性化するボタンオブジェクト
 * @param _divId：非活性化するDivタグID
 * @param _overlayFlg true:オーバーレイあり	false:オーバーレイなし
 * @return
 */
function AjaxErrorCallBack(_frmObj, _btnDisabled, _ctlDisabled, _divId, _overlayFlg) {
    // 二重クリック防止
    UnMaskPage();

    alert('Connection to server failed.');
    if (_overlayFlg) {
        overlayReset(_frmObj, _btnDisabled, _divId, _ctlDisabled);
    }
}

/**
 * Ajax通信のSuccess時のコールバック処理
 * @param _xml	サーバから返却されたXML
 * @param _frmObj　ブラウザのフォームオブジェクト
 * @param _btnDisabled　非活性化しているボタンオブジェクト
 * @param _ctlDisabled	非活性化しているコントロール項目
 * @param _divId	非活性化しているDivID
 * @param _func		成功時実行する関数名
 * @param _winMode	Window区分
 * @param _overlayFlg	true：オーバーレイあり false:オーバーレイなし
 * @return
 */
function AjaxSuccessCallBack(_xml, _frmObj, _btnDisabled, _ctlDisabled, _divId, _func, _winMode, _overlayFlg) {
    // 二重クリック防止
    UnMaskPage();

    /*処理成功時の処理*/
    var isXml = false;

    /* 構文チェック */
    try {
        if ($(_xml).find('root').text() != null && $(_xml).find('root').text() != '') {
            isXml= true;
        }
        else {
            isXml= false;
        }

    } catch(e) {
        isXml= false;
    }

    if (isXml == true) {

        var cnt = $(_xml).find('root msg').size()
                + $(_xml).find('root ctl').size()
                + $(_xml).find('root redirect').size();
        if (cnt > 0) {
            var redirect = $(_xml).find('redirect').text();

            if (redirect != null && redirect != '') {
                if (_winMode == 'popwin') {
                    //別Window上の場合
                    if (confirm($(_xml).find('msg').text() + '\r\nClose Window ？')) {
                        window.close();
                    } else {
                        if (_overlayFlg) {
                            overlayReset(_frmObj, _btnDisabled, _divId, _ctlDisabled);
                        }
                    }
                } else {
                    alert($(_xml).find('errorMsg').text());

//                    if (confirm($(_xml).find('msg').text() + '\r\nログアウトしますか？')) {
//                        linkSubmitTarget(getTopFrame(),redirect);
//                    } else {
//                        if (_overlayFlg) {
//                            overlayReset(_frmObj, _btnDisabled, _divId, _ctlDisabled);
//                        }
//                    }
                }
            } else {
                alert($(_xml).find('msg').text());

                var ctl = $(_xml).find('ctl').text();

                if (ctl != null && ctl != '') {
                    $('#' + ctl).focus();
                    $('#' + ctl).addClass('c_error');
                    $('#' + ctl).select();
                }

                // エラーメッセージ後の関数呼び出し
                var fnc = $(_xml).find('fnc').text();
                if(typeof error_callback == "function") {
                    error_callback(fnc);
                }

                if (_overlayFlg) {
                    overlayReset(_frmObj, _btnDisabled, _divId, _ctlDisabled);
                }
            }
        } else {
            _func(_xml);
            if (_overlayFlg) {
                overlayReset(_frmObj, _btnDisabled, _divId, _ctlDisabled);
            }
        }
    } else {
        _func(_xml);
        if (_overlayFlg) {
            overlayReset(_frmObj, _btnDisabled, _divId, _ctlDisabled);
        }
    }
}


/**
 * オーバーレイの解除
 * @param _frmObj：フォームオブジェクト
 * @param _btnDisabled：非活性化ボタン
 * @param _divId：DivID
 * @param _ctlDisabled：非活性化コントロール
 * @return
 */
function overlayReset(_frmObj, _btnDisabled, _divId, _ctlDisabled) {

    $(_frmObj).find('.overlay').remove();
    if (_btnDisabled != null && jQuery.isArray(_btnDisabled)) {
        changeBtnStyle(_divId, _btnDisabled, true);
    }
    if (_ctlDisabled != null && jQuery.isArray(_ctlDisabled)) {
        jQuery.each(_ctlDisabled, function () {
            if (!ctlDisabled[this]) {
                $(_frmObj).find('.wrap #' + this).attr('disabled','');
            }
        });
    }

}

/**
 * ボタンスタイル変更
 * @param _divId:ボタンの存在するDIVid
 * @param _aryCtlId:ボタンID配列
 * @param _enabled:活性フラグ(true:活性に変更、false:非活性に変更)
 * @return
 */
function changeBtnStyle(_divId, _aryCtlId, _enabled) {
    var frmObj = getFormObject(_divId);
    var disable = '';
    var delCls = '';
    var addCls = '';
    if (!_enabled) {
        disable = 'disabled';
    }
    jQuery.each(_aryCtlId,function () {
        var btnCtl = $(frmObj).find('#' + this);

        if ($(btnCtl).size() > 0) {
            if (!_enabled) {
                // 活性⇒非活性切替時
                if ($(btnCtl).hasClass('button')) {
                    delCls = 'button';
                    addCls = 'button_disabled';
                } else if ($(btnCtl).hasClass('button_large')) {
                    delCls = 'button_large';
                    addCls = 'button_large_disabled';
                } else if ($(btnCtl).hasClass('button_small')) {
                    delCls = 'button_small';
                    addCls = 'button_small_disabled';
                }
            } else {
                // 非活性⇒活性切替時
                if ($(btnCtl).hasClass('button_disabled')) {
                    delCls = 'button_disabled';
                    addCls = 'button';
                } else if ($(btnCtl).hasClass('button_large_disabled')) {
                    delCls = 'button_large_disabled';
                    addCls = 'button_large';
                } else if ($(btnCtl).hasClass('button_small_disabled')) {
                    delCls = 'button_small_disabled';
                    addCls = 'button_small';
                }
            }
            $(btnCtl).attr('disabled',disable);
            $(btnCtl).removeClass(delCls);
            $(btnCtl).addClass(addCls);
        }
    });
}

/**
 * 文字列型判別
 * @param obj
 * @return
 */
function isString(obj) {
    if (obj == null) {
        return false;
    }
    return (typeof(obj) == "string" || obj instanceof String);
}

/**
 * 二重クリック防止対策
 *
 */
function MaskPage()
{
    try
    {
        document.getElementById('ComProcessingMask').style.width = "100%";
        document.getElementById('ComProcessingMask').style.height = "100%";
        document.getElementById('ComProcessingMask').style.visibility = "visible";
        document.getElementById('ComSubProcessingMask').style.visibility = "visible";
        setTimeout('UnMaskPage()', 60000);
    }
    catch(e)
    {
    }
}

function UnMaskPage()
{
    try
    {
        document.getElementById('ComProcessingMask').style.visibility = "hidden";
        document.getElementById('ComSubProcessingMask').style.visibility = "hidden";
        document.getElementById('ComProcessingMask').style.width = "100px";
        document.getElementById('ComProcessingMask').style.height = "50px";
    }
    catch(e)
    {
    }
}

/**
 * 地図APIカウントアップ更新
 *
 */
function countUpMapApiAccessCount(count)
{
    // 共通のカウント保持項目へカウント数をセット
    $('#hdnMapAccessCountNum').val(count);

    var formObj = getFormObject('');
    var url = $(formObj).attr('action') + 'countUpMapAccess';
    linkSubmitAjax(url, $(formObj).serialize(), afterCountUpMapApiAccessCount);
}

function afterCountUpMapApiAccessCount(count)
{
    // 共通のカウント保持項目に0をセット
    $('#hdnMapAccessCountNum').val(0);
}

function linkSubmitDoc(_url, _type, _params, _func, _winMode) {
    MaskPage();
    fd = new FormData(_params[0]);
    $.ajax( {
           url : _url,
           data : fd,
           type : _type,
           processData: false,
           contentType: false,
           error : function (req, status, throwable) {
               AjaxErrorCallBack(null, null, null, null, false);
           },
           success  : function(xml) {
               AjaxSuccessCallBack(xml, null, null, null, null, _func, _winMode, false);
           }
       }
   );
}

function linkSubmitCsv(_url, _type, _params, _func, _winMode) {
     MaskPage();
   fd = new FormData(_params[0]);
  $.ajax( {
          url : _url,
          data : fd,
          type : _type,
          dataType: 'html',
          processData: false,
          contentType: false,
          error : function (req, status, throwable) {
              AjaxErrorCallBack(null, null, null, null, false);
          },
          success  : function(xml) {
              AjaxSuccessCallBack(xml, null, null, null, null, _func, _winMode, false);
          }
      }
  );

}

//文字列置換
function replaceMessage(message, params) {
    for (var i=0; i<params.length; i++) {
        var targetStr = "{" + i + "}";
        if (message.indexOf(targetStr) != -1) {
            message = message.replace(targetStr, params[i]);
        }
    };
    return message;
}

// 指定されたバイト数以上の内容を「…」で切替って表示する
function getDispShortName(originalText, cutFigure) {
    var afterTxt = '…';
    var textLength = 0;
    for (var i = 0; i < originalText.length; i++) {
        textLength += getCharLength(originalText.charAt(i));
    }

    if (textLength <= cutFigure) {
        return originalText;
    } else {
        var textTrim = "";
        var count = 0;
        for (var i = 0; i < originalText.length; i++) {
            count += getCharLength(originalText.charAt(i));
            if (count <= cutFigure - 3) {
                textTrim += originalText.charAt(i);
            } else {
                return textTrim + afterTxt;
            }
        }
    }
}

// バイト数を取得する
function getCharLength(c) {
    // 半角英数字
    var alphabet = "^[A-Za-z0-9]*$";
    // 半角英数記号
    var numberSign = "^[\\x20-\\x7F]*$";
    // 半角カタカナ
    var hankakuKana = "^[ｧ-ﾝﾞﾟ]*$/";

    if (c.match(alphabet) || c.match(numberSign) || c.match(hankakuKana)) {
        // 半角
        return 1;
    } else {
        // 全角
        return 2;
    }
}

function resizeResizeArea_withLegend(resizeId) {
    var marginFooter = 16;
    var marginAreaTop = 8;
//    var marginSide = 12;
    var marginSide = 250;
    var marginIE8 = 20;    var wrapAll = $('#wrapAll');
    var tmpMinWidth = $(wrapAll).css('min-width');
    var minWidth = parseInt(tmpMinWidth.replace('px', ''));
    var tmpMinHeight = $(wrapAll).css('min-height');
    var minHeight = parseInt(tmpMinHeight.replace('px', ''));

    var resizeAreaHeight = 0;
    var windowHeight = ($(window).height() < minHeight ? minHeight : $(window).height());
    var windowWidth = ($(window).width() < minWidth ? minWidth : ($(window).width() < $(document).width() ? $(window).width() + MARGIN_SCROLL_BAR : $(window).width())) - (userAgent.ltIE8 ? marginSide : 0);

    var targetArea = $(wrapAll).find('#' + resizeId);
    if($('#resizeArea').size() > 0) {
        var tmpTopBorderSize = $(targetArea).css('border-top-width');
        var tmpBottomBorderSize = $(targetArea).css('border-bottom-width');
        var topBorderSize = parseInt(tmpTopBorderSize.replace('px', ''));
        topBorderSize = isNaN(topBorderSize) ? 0 : topBorderSize;
        var topBottomSize = parseInt(tmpBottomBorderSize.replace('px', ''));
        topBottomSize = isNaN(topBottomSize) ? 0 : topBottomSize;
        resizeAreaHeight = windowHeight - $('.main').offset().top - marginFooter - marginAreaTop - (userAgent.ltIE8 ? marginIE8 : 0) - topBorderSize - topBottomSize;
    }

    $(targetArea).css('margin-bottom', '16px');
    $(targetArea).height(resizeAreaHeight);

    var areaWidth = windowWidth - $('.bar').outerWidth() - marginSide;
    $(targetArea).width(areaWidth);
    }

function resizeResizeArea(resizeId) {
    var marginFooter = 16;
    var marginAreaTop = 8;
    var marginSide = 19;
    var marginIE8 = 20;    var wrapAll = $('#wrapAll');
    var tmpMinWidth = $(wrapAll).css('min-width');
    var minWidth = parseInt(tmpMinWidth.replace('px', ''));
    var tmpMinHeight = $(wrapAll).css('min-height');
    var minHeight = parseInt(tmpMinHeight.replace('px', ''));

    var resizeAreaHeight = 0;
    var windowHeight = ($(window).height() < minHeight ? minHeight : $(window).height());
    var windowWidth = ($(window).width() < minWidth ? minWidth : ($(window).width() < $(document).width() ? $(window).width() + MARGIN_SCROLL_BAR : $(window).width())) - (userAgent.ltIE8 ? marginSide : 0);

    var targetArea = $(wrapAll).find('#' + resizeId);
    if($('#resizeArea').size() > 0) {
        var tmpTopBorderSize = $(targetArea).css('border-top-width');
        var tmpBottomBorderSize = $(targetArea).css('border-bottom-width');
        var topBorderSize = parseInt(tmpTopBorderSize.replace('px', ''));
        topBorderSize = isNaN(topBorderSize) ? 0 : topBorderSize;
        var topBottomSize = parseInt(tmpBottomBorderSize.replace('px', ''));
        topBottomSize = isNaN(topBottomSize) ? 0 : topBottomSize;
        resizeAreaHeight = windowHeight - $(targetArea).offset().top - marginFooter - marginAreaTop - (userAgent.ltIE8 ? marginIE8 : 0) - topBorderSize - topBottomSize;
        var searchArea = $("#search");
        if ($(searchArea).size() > 0) {
            if ($(searchArea).hasClass("close")) {
                $(targetArea).css('min-height', resizeAreaHeight);
            }
        }
    }

    $(targetArea).css('margin-bottom', '16px');
    $(targetArea).height(resizeAreaHeight);

    var areaWidth = windowWidth - marginSide * 2;
    $(targetArea).width(areaWidth);
}
function resizeResizeArea_withAndon(resizeId) {
    var marginFooter = 16;
    var marginAreaTop = 8;
    var marginSide = 23;
    var marginIE8 = 20;    var wrapAll = $('#wrapAll');
    var tmpMinWidth = $(wrapAll).css('min-width');
    var minWidth = parseInt(tmpMinWidth.replace('px', ''));
    var tmpMinHeight = $(wrapAll).css('min-height');
    var minHeight = parseInt(tmpMinHeight.replace('px', ''));

    var resizeAreaHeight = 0;
    var windowHeight = ($(window).height() < minHeight ? minHeight : $(window).height());
    var windowWidth = ($(window).width() < minWidth ? minWidth : ($(window).width() < $(document).width() ? $(window).width() + MARGIN_SCROLL_BAR : $(window).width())) - (userAgent.ltIE8 ? marginSide : 0);

    var targetArea = $(wrapAll).find('#' + resizeId);
    if($('#resizeArea').size() > 0) {
        var tmpTopBorderSize = $(targetArea).css('border-top-width');
        var tmpBottomBorderSize = $(targetArea).css('border-bottom-width');
        var topBorderSize = parseInt(tmpTopBorderSize.replace('px', ''));
        topBorderSize = isNaN(topBorderSize) ? 0 : topBorderSize;
        var topBottomSize = parseInt(tmpBottomBorderSize.replace('px', ''));
        topBottomSize = isNaN(topBottomSize) ? 0 : topBottomSize;
        resizeAreaHeight = windowHeight - $(targetArea).offset().top - marginFooter - marginAreaTop - (userAgent.ltIE8 ? marginIE8 : 0) - topBorderSize - topBottomSize;
        var searchArea = $("#search");
        if ($(searchArea).size() > 0) {
            if ($(searchArea).hasClass("close")) {
                $(targetArea).css('min-height', resizeAreaHeight);
            }
        }
    }

    $(targetArea).css('margin-bottom', '16px');
    $(targetArea).height(resizeAreaHeight);

    var areaWidth = windowWidth - $('.bar').outerWidth() - marginSide;
    $(targetArea).width(areaWidth);
}

/**
 * 次画面遷移実行.
 * @param formObj formオブジェクト(getFormObject('')より取得)
 * @param pageId 画面ID
 */
function redirectPage(formObj, pageId) {
    var nextPageObj = $(formObj).find('#hdnNextPageId');
    if (nextPageObj) {
        $(nextPageObj).val(pageId);
    } else {
        $(formObj).append('<input type="hidden" name="nextPageObj" value="' + pageId + '"/>');
    }

    linkSubmit('','redirectPage');
}
/**
 * リダイレクト用パラメータ追加.
 * @param formObj formオブジェクト(getFormObject('')より取得)
 * @param name 項目名
 * @param value 値
 */
function addRedirectParam(formObj, name, value) {
    $(formObj).append('<input type="hidden" name="hdnRedirectParamMap.' + name + '" value="' + value + '"/>');
}

/**
 * グラフ横軸範囲の左端取得.
 * @param fromVal　From日時
 * @return 横軸左端の値
 */
function getGraphRangeFrom(fromVal, dateType) {
    // グラフ横軸範囲指定
    var fromValTmp = "";
    var conv = "";

    // 日時データを変換
    if(dateType == 'jikanbetu') {
        // 時間別なら時分秒まで
        fromValTmp = fromVal.slice(0, 19);
    } else {
        // 時間別以外なら年月日まで
        fromValTmp = fromVal.slice(0, 10);
    }
    conv = fromValTmp.replace(/-/g, "/");
    var dateFrom = new Date(conv);
    // タイプごとに日付を調整
    if(dateType == 'getuji') {
        // 月次の場合、おしりは開始日の15日後の月の1日とする
        dateFrom.setDate(dateFrom.getDate() + 15);
        dateFrom.setDate(1);
    }

    return dateFrom.getTime();
}

/**
 * グラフ横軸範囲の右端取得.
 * @param toVal　To日時
 * @return 横軸右端の値
 */
function getGraphRangeTo(toVal, dateType) {
    // グラフ横軸範囲指定
    var toValTmp = "";
    var conv = "";

    // 日時データを変換
    if(dateType == 'jikanbetu') {
        // 時間別なら時分秒まで
        toValTmp = toVal.slice(0, 19);
    } else {
        // 時間別以外なら年月日まで
        toValTmp = toVal.slice(0, 10);
    }
    conv = toValTmp.replace(/-/g, "/");
    var dateTo = new Date(conv);
    // タイプごとに日付を調整
    if(dateType == 'nitiji') {
        // 日時の場合、おしりは前日にする
        dateTo.setDate(dateTo.getDate() - 1);
    } else if(dateType == 'jikanbetu'){
        // 時間別の場合、おしりの時刻は終了時刻の00分にする
        dateTo.setSeconds(dateTo.getSeconds() + 1);
        dateTo.setHours(dateTo.getHours() - 1);
    } else {
        // 月次の場合、おしりは開始日の15日前の月の1日とする
        dateTo.setDate(dateTo.getDate() - 15);
        dateTo.setDate(1);
    }

   return dateTo.getTime();
}

/**
 * アンドン表示の更新.
 * @param jsonMap　アンドン更新データ
 */
function editAndonDataFromJSON(jsonMap) {
    $("#currentRetention").html(jsonMap.retentionNum + "(" + jsonMap.lineRetentionInside +")");
    $("#currentActual").html(jsonMap.actualNum);
    $("#currentActualDiff").html("[" + jsonMap.diffValue + "]");
    $("#currentSchedule").html(jsonMap.scheduleNum);
    $("#currentPlan").html(jsonMap.planNum);
    $("#currentPredictionCompletionTime").html(jsonMap.predictionCompletionTime);
    $("#currentCompletionTime").html(jsonMap.completionTime);
}

/**
 * 検索エリア、アンドンエリアのOPEN/CLOSE.
 */
function comAreaDisplay() {
    var target;

    if($("#hdnAndonAreaOpen").val() == "1") {
        target = $("#andonArea");
        if(target.size()) {
            target.removeClass("close", 0, "linear");
        }
    }
    resizeWindow();
    if($("#hdnSearchAreaOpen").val() == "1") {
        target = $("#search");
        if(target.size()) {
            target.removeClass("close", 0, "linear");
        }
    }
}

/**
 * グラフの横軸用日付リストを生成する
 * @param from グラフ表示範囲From
 * @param to グラフ表示範囲To
 * @param interval 間隔（日）
 * @returns グラフの横軸用日付リスト
 */
function getTimeGridDateList(from, to, interval) {
    var gridList=[];
    var toDate = new Date(to);
    var tmpDate = new Date(from);

    while (tmpDate <= toDate){
        gridList.push(tmpDate.getTime());
        tmpDate.setDate(tmpDate.getDate() + interval);
    }

    return gridList;
}

/**
 * 引数で指定された桁で四捨五入する
 *
 * @param originalDecimal 元の数値
 * @param digits 小数点以下の桁数
 * @returns 指定された桁で四捨五入した数値
 */
function getRoundDecimal(originalDecimal, digits) {

    var tmpDecimal = Number(originalDecimal);
    var newDecimal = '';

    if (digits > 0) {
        var multipleNum = Math.pow(10, digits);
        tmpDecimal = tmpDecimal * multipleNum;
        tmpDecimal = Math.round(tmpDecimal);
        tmpDecimal = tmpDecimal / multipleNum;

        newDecimal += tmpDecimal.toFixed(digits);
    } else {
        newDecimal += Math.round(tmpDecimal);
    }

    return newDecimal;
}

//ピン止め再設定
function resetPinSetting() {
    if ($('#searchPin').is(':checked')) {
        // 検索エリアOPENを設定
        $("#hdnSearchAreaOpen").val("1");
    } else {
        // 検索エリアCLOSEを設定
        $("#hdnSearchAreaOpen").val("0");
    }
}
