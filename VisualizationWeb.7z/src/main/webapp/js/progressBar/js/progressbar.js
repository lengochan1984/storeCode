/******************************************************************************
 * タイトル：プログレスバーユーティリティ
 * ファイル名：FW01_13_CommonJsUtil.js
 * Copyright(C) YASKAWA Information Systems
 *
 * 変更日付		変更者        	Rev.		変更内容
 *-----------------------------------------------------------------------------
 * 2016/07/29   (US)萩尾        C1.01       新規作成
 ******************************************************************************/
; (function ($, document, window) {
    var progressBar = 'progressBar';

    if ($.progressBar) {
        return;
    }

    publicMethod = $.fn[progressBar] = $[progressBar] = function (options) {
        var settings = options;

        return this.each(function (i, obj) {
            initializeProgressBar(obj, settings);
        });
    };

    function setSettings(options) {
        var settings = $.extend({
            initializing: true,
            percent: 0,
            normalMaxPercent: 100,
            maxPercent: 150,
            width: 150,
            height: 10,
            split: 5,
            markPosition: 0,
            minMarkSize: 5,
            markColor: "#FF7700",
            barColor:"#208F27",
            backLineColor: "#000000",
            normalBackgroundColor: "#FFFFFF",
            overBackgroundColor: "#808080",
            //Events:
            onPercentChanged: false
        }, options);

        return settings;
    }

    function getSettings(internalElement) {
        return internalElement.closest('.ProgressBar').data('settings');
    }

    function initializeProgressBar(obj, settings) {
        var setting = setSettings({});
        settings = $.extend(setting, settings);

        $(obj).addClass("ProgressBar");

        var content = '';
        content += '<div class="AdditionalArea">';
        content += '<canvas class="AdditionalCanvas"></canvas>';
        content += '</div>';
        content += '<div class="ProgressBarArea">';
        content += '<canvas class="BaseCanvas"></canvas>';
        content += '<canvas class="Bar"></canvas>';
        content += '<canvas class="Split"></canvas>';
        content += '</div>';

        $(obj).append(content);
        $(obj).data("settings", settings);

        var progressBarWidth = $(obj).width();
        var progressBarHeight = $(obj).height();

        if (settings.width != false) {
            progressBarWidth = settings.width;
            $(obj).width(progressBarWidth);
        } else if ($(obj).width() == 0) {
            progressBarWidth = 200;
            $(obj).width(progressBarWidth);
        }

        if (settings.height != false) {
            progressBarHeight = settings.height;
            $(obj).height(progressBarHeight);
        } else if ($(obj).height() == 0) {
            progressBarHeight = 20;
            $(obj).height(progressBarHeight);
        }
        var markHeight = progressBarHeight * 0.5;
        if ( markHeight < settings.minMarkSize ) {
            markHeight = settings.minMarkSize;
        }

        var progressBarArea = $(obj).children(".ProgressBarArea");
        $(progressBarArea).height(progressBarHeight + 2);
        $(progressBarArea).width(progressBarWidth + 2);
        $(progressBarArea).css("margin-top", markHeight + "px");
        $(progressBarArea).find("canvas").prop('height', progressBarHeight);
        $(progressBarArea).find("canvas").prop('width', progressBarWidth);
        var additionalArea = $(obj).children(".AdditionalArea");
        $(additionalArea).height(markHeight);
        $(additionalArea).find("canvas").prop('height', markHeight);
        $(additionalArea).find("canvas").prop('width', progressBarWidth + settings.minMarkSize);

        settings.height = progressBarHeight;
        settings.width = progressBarWidth;

        drawProgressBar($(progressBarArea), settings);
        changePercentValue($(progressBarArea), settings.percent, settings);
        drawSplitLines($(progressBarArea).children(".Split"), settings);
        drawMark($(obj).find(".AdditionalCanvas"), settings);

        settings.initializing = undefined;
        $(obj).data("settings", settings);


    }

    function drawProgressBar(element, settings) {

        var maxWidth = settings.width;
        var height = settings.height;
        var normalWidth = maxWidth * (parseInt(settings.normalMaxPercent) / parseInt(settings.maxPercent));

        var c = $(element).children(".BaseCanvas").get(0);
        var ctx = c.getContext("2d");
        /* ベース */
        ctx.strokeStyle = settings.backLineColor;
        ctx.fillStyle = settings.overBackgroundColor;
        ctx.fillRect(0, 0, maxWidth, height);

        /* 正常 */
        ctx.fillStyle = settings.normalBackgroundColor;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(0, height);
        ctx.lineTo(normalWidth, height);
        ctx.lineTo(normalWidth, 0);
        ctx.closePath();
        ctx.stroke();
        ctx.fill();
    }

    function changePercentValue(element, newPercent, settings) {

        if ($(element).hasClass('ProgressBarArea')) {
            var percent = Math.min(Math.max(newPercent, 0), settings.maxPercent).toString();
            percent = percent * (parseInt(settings.normalMaxPercent) / parseInt(settings.maxPercent)) / 100;
            var width = parseInt(settings.width) * percent ;
            var c = $(element).children(".Bar").get(0);
            var ctx = c.getContext("2d");
            ctx.fillStyle = settings.barColor;
            ctx.fillRect(0, 0, width, parseInt(settings.height));

            if (settings.initializing == undefined) {
                settings.percent = newPercent;
                $(element).parent().data("settings", settings);
                trigger(settings.onPercentChanged, newPercent, element);
            }
        }
    }

    function drawSplitLines(canvas, settings) {
        if (settings.split > 1) {
            var c = canvas.get(0);
            var ctx = c.getContext("2d");
            var width = settings.width * (parseInt(settings.normalMaxPercent) / parseInt(settings.maxPercent));
            ctx.clearRect(0, 0, width, settings.height);
            ctx.strokeStyle = settings.color;
            ctx.lineWidth = 1;

            for (var i = 1; i < settings.split; i++) {
                ctx.beginPath();
                ctx.moveTo(width / settings.split * i, 0);
                ctx.lineTo(width / settings.split * i, c.height);
                ctx.stroke();
                ctx.closePath();
            }
            ctx.moveTo(width, 0);
            ctx.lineTo(width, c.height);
            ctx.stroke();
        }
    }

    function drawMark(element, settings) {

        if (settings.markPosition) {
            var width = settings.width;
            var markPosition = parseInt(width) * settings.markPosition * (parseInt(settings.normalMaxPercent) / parseInt(settings.maxPercent)) / 100;
            var c = $(element).get(0);
            var ctx = c.getContext("2d");
            var triangleWidth = c.height / 1.732;
            ctx.fillStyle = settings.markColor;
            ctx.strokeStyle = settings.markColor;
            ctx.lineWidth = 1;
            ctx.beginPath();

            ctx.moveTo(markPosition + 1, c.height -1);
            ctx.lineTo(markPosition + 1 + triangleWidth, 0);
            ctx.lineTo(markPosition + 1 - triangleWidth, 0);
            ctx.closePath();
            ctx.stroke();
            ctx.fill();
        }
    }

    $.fn.changePercent = function (newPercent) {
        var currentSetting = getSettings($(this));
        var progressBarArea = $(this).children(".ProgressBarArea");
        changePercentValue($(progressBarArea), newPercent, currentSetting);
    };

    $.fn.getPercent = function () {
        return ('.ProgressBar').first().data('settings').percent;
    };

    publicMethod.getSettings = function (internalElement) {
        return internalElement.closest('.ProgressBar').data('settings');
    };

    publicMethod.percentChanged = function (value, caller) {
        trigger(getSettings(caller).onPercentChanged, value, caller);
    };

    function trigger(callback, value, caller) {
        if ($.isFunction(callback)) {
            callback.call(undefined, value, caller);
        }
    }
}(jQuery, document, window));