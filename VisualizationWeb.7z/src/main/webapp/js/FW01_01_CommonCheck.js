//******************************************************************************
//タイトル：共通チェック処理
//※必ずjquery-1.3.2.jsと併用する事
//ファイル名：FW01_13_CommonJsUtil.js
//Copyright(C) YASKAWA Information Systems
//変更日付		変更者        	Rev.		変更内容
//-----------------------------------------------------------------------------
// 2009/08/05 	YSK)西田　浩二	1.00.00  	新規作成
// 2014/07/17 	YSK)中田　　　　1.01.00  	<10000-158> IT不具合修正（No.026)
// 2015/04/21 	US)萩尾　　　　 3.01.00  	<30003-006> 故障苦情No.30002-006
// 2015/06/25   US)楢崎         3.01.00     <30003-035> 変更仕様No.13
// 2015/11/26   US)高橋         4.00.00     <40000-023> Ver4.00.00 変更仕様NO.23
// 2015/12/15   US)楢崎         4.00.00     <40000-019> Ver4.00.00 変更仕様No.19
// 2016/01/04   US)楢崎         4.00.00     <40000-021> Ver4.00.00 変更仕様No.21
// 2016/01/11   US)甲斐         4.00.00     <40000-026> Ver.4.00.00 変更仕様No.26
// 2016/01/18   US)清水         4.00.00     <40000-010> Ver.4.00.00 変更仕様No.10（故障苦情No.30003-080）
//******************************************************************************

function FW01_01_CommonCheck() {

    //プルダウンのブランク扱いとなるOPTION value値
    var blankValue = '';

    var TYPE = {'TXT':0,'PSWD':1,'CHK':2,'RDO':3,'PLD':4,'SEL_LIST':5,'TXT_AREA':6,'ERROR':-1};

    /**
     * 必須チェック
     * @param id : チェック対象ID属性
     */
    this.checkNecessary = function(id) {

        var type = getType(id);

        var required = false;
        var msgKey = '';
        switch (type) {
        //テキスト
        case 0:
            var value = $('#' + id).val();
            required = (value != null && value != '');
//            msgKey = 'M001';
            msgKey = 'MMCMCM00000_051';
            break;
            //パスワード
        case 1:
            var value = $('#' + id).val();
            required = (value != null && value != '');
//          msgKey = 'M001';
            msgKey = 'MMCMCM00000_051';
            break;
            //チェックボックス
        case 2:
            required = $('#' + id).attr('checked');
//            msgKey = 'M002';
            msgKey = 'MMCMCM00000_052';
            break;
            //ラジオ
        case 3:
            var value = $('input[@name=' + id + ']:checked').val();
            required = (value != null);
//          msgKey = 'M002';
            msgKey = 'MMCMCM00000_052';
            break;
            //プルダウン
        case 4:
            var value = $('#' + id).val();
            required = (value != null && value != blankValue);
//          msgKey = 'M002';
            msgKey = 'MMCMCM00000_052';
            break;
            //セレクトリスト
        case 5:
            var value = $('#' + id).val() || [];
            required = (value != null && value != '');
//          msgKey = 'M002';
            msgKey = 'MMCMCM00000_052';
            break;
            //テキストエリア
        case 6:
            var value = $('#' + id).val();
            required = (value != null && value != '');
//          msgKey = 'M001';
            msgKey = 'MMCMCM00000_051';
            break;
        default:
            msgKey = 'ERROR';
        break;
        }
        if (required) {
            return '';
        } else {
            return msgKey;
        }
    }

    /**
    * 必須チェック(複合必須)
    * @param aryId : チェック対象ID属性(配列指定)
    * ※設定例⇒['id1','id2','id3']
    */
    this.checkNecessaryArray = function(aryId) {


        if ($.isArray(aryId)) {
            var result = false;
            var checkObj = new FW01_01_CommonCheck();

            jQuery.each(aryId, function () {
                var msg = checkObj.checkNecessary(this);

                if (!result) {
                    result = msg == '';
                }
            });

            if (result) {
                return '';
            } else {
//                return 'M001';
                return 'MMCMCM00000_051';
            }

        } else {
            return 'ERROR';
        }
    }

    /**
    * 属性チェック
    * @param aryId : チェック対象ID属性(配列指定)
    * ※単一でも配列 ex) 単一の場合⇒['id1'],複数の場合⇒['id1','id2','id3']
    */
    this.checkAttr = function(aryId,type) {
        var bolAttr = false;
        var msgKey = '';
        switch (type) {
        //数値チェック
        case 0:
//            msgKey = 'M003';
            msgKey = 'MMCMCM00000_053';
            var value = '';
            var tagName = $('#' + aryId[0]).prop('tagName').toUpperCase();
            if (tagName == 'INPUT') {
                value = $('#' + aryId[0]).val();
            } else {
                value = $('#' + aryId[0]).text();
            }
            bolAttr = value.match(/^[+-]?\d*[.]?\d*$/) != null;
            break;
            //半角数字チェック
        case 1:
//            msgKey = 'M004';
            msgKey = 'MMCMCM00000_054';
            var value = '';
            var tagName = $('#' + aryId[0]).prop('tagName').toUpperCase();
            if (tagName == 'INPUT') {
                value = $('#' + aryId[0]).val();
            } else {
                value = $('#' + aryId[0]).text();
            }
            bolAttr = value.match(/^\d*$/) != null;
            break;
            //ひらがなチェック
        case 2:
//            msgKey = 'M005';
            msgKey = 'MMCMCM00000_055';
            var value = '';
            var tagName = $('#' + aryId[0]).prop('tagName').toUpperCase();
            if (tagName == 'INPUT') {
                value = $('#' + aryId[0]).val();
            } else {
                value = $('#' + aryId[0]).text();
            }
            bolAttr = value.match(/^[ぁ-ゞ　ー\s]*$/) != null;
            break;
            //半角英数字チェック
        case 3:
//            msgKey = 'M006';
            msgKey = 'MMCMCM00000_056';
            var value = '';
            var tagName = $('#' + aryId[0]).prop('tagName').toUpperCase();
            if (tagName == 'INPUT') {
                value = $('#' + aryId[0]).val();
            } else {
                value = $('#' + aryId[0]).text();
            }
            bolAttr = value.match(/^[A-Za-z0-9]*$/) != null;
            break;
            //日付(年月日)妥当性チェック
        case 4:
//            msgKey = 'M007';
            msgKey = 'MMCMCM00000_057';
            if (aryId.length != 3) {
                break;
            } else {
                msgKey = checkDateFormat(aryId);
                if ( msgKey == '' ) {
                    bolAttr = true;
                }
                break;
            }
            //日付(年月日時分)妥当性チェック
        case 5:
//            msgKey = 'M007';
            msgKey = 'MMCMCM00000_057';
            if (aryId.length != 5) {
                break;
            } else {
                msgKey = checkDateFormat(aryId);
                if ( msgKey == '' ) {
                    bolAttr = true;
                }
                break;
            }
            //電話番号妥当性チェック
        case 6:
            if (aryId.length != 3) {
                break;
            }
            var aryTel = new Array();
            var allBlank = true;

            $.each(aryId,function(index,id) {
                var value = $('#' + id).val();

                if (allBlank) {
                    allBlank = value == null || value == '';
                }

                if (value.match(/^\d+$/)) {
                    aryTel[aryTel.length] = value;
                } else if (value != null && value != '') {
//                    msgKey = 'M008';
                    msgKey = 'MMCMCM00000_058';
                }
            });
            if (allBlank) {
                bolAttr = true;
            } else if (aryTel.length == 3) {
                bolAttr =  ((aryTel[0] + aryTel[1] +aryTel[2]).length <= 11);
//                msgKey = 'M008';
                msgKey = 'MMCMCM00000_058';
            } else if (msgKey != '') {
                bolAttr = false;
            } else {
                bolAttr = false;
//                msgKey = 'M030';
                msgKey = 'MMCMCM00000_067';
            }
            break;
            //IPアドレス妥当性チェック
        case 7:
//            msgKey = 'M009';
            msgKey = 'MMCMCM00000_059';
            if (aryId.length != 4) {
                msgKey = 'ERROR';
                break;
            }
            var aryIP = new Array();
            var allBlank = false;

            $.each(aryId,function(index,id) {
                var value = $('#' + id).val();

                if (!allBlank) {
                    allBlank = value == null || value == '';
                }

                if (value.match(/^\d+$/)) {
                    aryIP[aryIP.length] = Number(value);
                }else {
//                    msgKey = 'M004';
                    msgKey = 'MMCMCM00000_054';
                }
            });
            if (allBlank) {
                bolAttr = false;
//                msgKey = 'M009';
                msgKey = 'MMCMCM00000_059';
            }
            else {
                bolAttr = aryIP.length == 4;
            }
            break;
            //メールアドレスチェック
        case 8:
//            msgKey = 'M010';
            msgKey = 'MMCMCM00000_060';
            var value = '';
            var tagName = $('#' + aryId[0]).prop('tagName').toUpperCase();
            if (tagName == 'INPUT') {
                value = $('#' + aryId[0]).val();
            } else {
                value = $('#' + aryId[0]).text();
            }
            bolAttr = (value == null || value == '') || (value.match(/^[0-9A-Za-z._-]+@[0-9A-Za-z._-]+$/) != null);

            break;
            //パスワードチェック
        case 9:
            msgKey = '';
            var value = '';
            var tagName = $('#' + aryId[0]).prop('tagName').toUpperCase();
            if (tagName == 'INPUT') {
                value = $('#' + aryId[0]).val();
            } else {
                value = $('#' + aryId[0]).text();
            }
            bolAttr = value != '';
            if (bolAttr) {
                bolAttr = (value.match(/^[A-Za-z0-9]*$/) != null);
                if (bolAttr) {
                    bolAttr = value.match(/[0-9]/) != null && value.match(/[A-Za-z]/) != null
                    if (!bolAttr) {
//                        msgKey = 'M033';
                        msgKey = 'MMCMCM00000_070';
                    }
                } else {
//                    msgKey = 'M006';
                    msgKey = 'MMCMCM00000_056';
                }
            } else {
                return '';
            }
            break;
            //1バイト文字チェック
        case 10:
            msgKey = 'M028';
            var value = '';
            var tagName = $('#' + aryId[0]).prop('tagName').toUpperCase();
            if (tagName == 'INPUT') {
                value = $('#' + aryId[0]).val();
            } else {
                value = $('#' + aryId[0]).text();
            }
            bolAttr = value.match(/^[!-~]*$/) != null;
            break;
            //カタカナチェック
        case 11:
//            msgKey = 'M005';
            msgKey = 'MMCMCM00000_055';
            var value = '';
            var tagName = $('#' + aryId[0]).prop('tagName').toUpperCase();
            if (tagName == 'INPUT') {
                value = $('#' + aryId[0]).val();
            } else {
                value = $('#' + aryId[0]).text();
            }
            bolAttr = value.match(/^[ァ-ヿ]*$/) != null;
            break;
            //半角英数記号チェック
        case 12:
            msgKey = 'MMCMCM00000_065';
            var value = '';
            var tagName = $('#' + aryId[0]).prop('tagName').toUpperCase();
            if (tagName == 'INPUT') {
                value = $('#' + aryId[0]).val();
            } else {
                value = $('#' + aryId[0]).text();
            }
            bolAttr = value.match(/^[\x20-\x7F]+$/) != null;
            break;
        default:
            break;
        }

        if (bolAttr) {
            return '';
        } else {
            return msgKey;
        }
    }

    /**
     * IPアドレスフォーマットチェック
     * @param id : チェック対象ID属性
     */
    this.checkIpAddressAttr = function(id) {
        var msgKey = 'MMCMCM00000_035';
        var value = '';
        var tagName = $('#' + id).prop('tagName').toUpperCase();

        // 入力値を取得
        if (tagName == 'INPUT') {
            value = $('#' + id).val();
        } else {
            value = $('#' + id).text();
        }

        // 入力値がIPアドレスフォーマットと合致しているかを判定
        var bolAttr = value.match(/^(([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/) != null;

        if (bolAttr) {
            return '';
        } else {
            return msgKey;
        }
    }

    /**
    * 桁数チェック
    * @param id : チェック対象ID属性
    * @param length : サイズ
    */
    this.checkLength = function(id,length) {
        var msgKey = 'MMCMCM00000_034';
        var bolLength = false;
        var value = '';
        var tagName = $('#' + id).prop('tagName').toUpperCase();
        if (tagName == 'INPUT') {
            value = $('#' + id).val();
        } else {
            value = $('#' + id).text();
        }
        bolLength = value.length == length;

        if (bolLength) {
            return '';
        } else {
            return msgKey;
        }
    }

    /**
    * 桁数チェック(上限)
    * @param id : チェック対象ID属性
    * @param length : 上限値
    */
    this.checkLengthUpper = function(id,length) {
//        var msgKey = 'M012';
        var msgKey = 'MMCMCM00000_062';
        var bolLength = false;
        var value = '';
        var tagName = $('#' + id).prop('tagName').toUpperCase();
        if (tagName == 'INPUT') {
            value = $('#' + id).val();
        } else {
            value = $('#' + id).text();
        }
        bolLength = value.length <= length;

        if (bolLength) {
            return '';
        } else {
            return msgKey;
        }
    }

    /**
     * 桁数チェック(上限)
     * @param name : チェック対象文字列
     * @param length : 上限値
     */
    this.checkLengthUpperByName = function(name, length) {
        var msgKey = 'MMCMCM00000_062';
        var bolLength = false;
        bolLength = name.length <= length;

        if (bolLength) {
            return '';
        } else {
            return msgKey;
        }
    }

    /**
    * 桁数チェック(下限)
    * @param id : チェック対象ID属性
    * @param length : 下限値
    */
    this.checkLengthLower = function(id,length) {
//        var msgKey = 'M029';
        var msgKey = 'MMCMCM00000_066';
        var bolLength = false;
        var value = '';
        var tagName = $('#' + id).prop('tagName').toUpperCase();
        if (tagName == 'INPUT') {
            value = $('#' + id).val();
        } else {
            value = $('#' + id).text();
        }
        bolLength = value == '' || value.length >= length;
        if (bolLength) {
            return '';
        } else {
            return msgKey;
        }
    }

    /**
    * 日付比較チェック
    * @param _preDate:FROM項目ID群(配列指定)
    * @param _aftDate:TO項目ID群(配列指定)
    */
    this.checkDateComparison = function (_preDate, _aftDate) {
//        var msgKey = 'M032';
        var msgKey = 'MMCMCM00000_069';
        var bolResult = false;
        var fromY = $('#' + _preDate[0]).val();
        var fromM = $('#' + _preDate[1]).val();
        var fromD = $('#' + _preDate[2]).val();
        var toY = $('#' + _aftDate[0]).val();
        var toM = $('#' + _aftDate[1]).val();
        var toD = $('#' + _aftDate[2]).val();
        var fromMSec = getDate(fromY, fromM, fromD);
        var toMSec = getDate(toY, toM, toD);

        bolResult = toMSec - fromMSec >= 0;

        if (bolResult) {
            return '';
        } else {
            return msgKey;
        }
    }

    /**
     * 日付比較チェック
     * @param _preDate:FROM項目ID
     * @param _aftDate:TO項目ID
     */
     this.checkDateComparisonForSingleItem = function (_preDate, _aftDate) {
         var msgKey = 'MMCMCM00000_071';
         var bolResult = true;
         var fromY = $('#' + _preDate).val() + ' 00:00:00';
         var toY = $('#' + _aftDate).val() + ' 23:59:59';

         fromY = fromY.replace("-", "/").replace("-", "/");
         toY = toY.replace("-", "/").replace("-", "/");

         var fromMSec = (new Date(fromY)).getTime();
         var toMSec = (new Date(toY)).getTime();

         if (toMSec < fromMSec) {
             bolResult = false;
         }

         if (bolResult) {
             return '';
         } else {
             return msgKey;
         }
     }

     /**
     * 日付比較チェック
     * @param _preDate:FROM項目ID群(配列指定)
     * @param _aftDate:TO項目ID群(配列指定)
     */
     this.checkDatetimeComparison = function (_preDate, _aftDate) {
         var msgKey = 'MMCMCM00000_071';
         var bolResult = true;
         var fromY = $('#' + _preDate[0]).val() + ' ' + $('#' + _preDate[1]).val() + ':' + $('#' + _preDate[2]).val() + ':00';
         var toY = $('#' + _aftDate).val() + ' ' + $('#' + _aftDate[1]).val() + ':' + $('#' + _aftDate[2]).val() + ':59';

         fromY = fromY.replace("-", "/").replace("-", "/");
         toY = toY.replace("-", "/").replace("-", "/");

         var fromMSec = (new Date(fromY)).getTime();
         var toMSec = (new Date(toY)).getTime();

         if (toMSec < fromMSec) {
             bolResult = false;
         }

         if (bolResult) {
             return '';
         } else {
             return msgKey;
         }
     }

     /**
     * 日付比較チェック
     * @param _preDate:FROM項目ID
     * @param _aftDate:TO項目ID
     */
     this.checkFullDatetimeComparison = function (_preDatetime, _aftDatetime) {
         var msgKey = 'MMCMCM00000_071';
         var bolResult = true;
         var fromY = $('#' + _preDatetime).val() + ':00';
         var toY = $('#' + _aftDatetime).val() + ':59';

         fromY = fromY.replace("-", "/").replace("-", "/");
         toY = toY.replace("-", "/").replace("-", "/");

         var fromMSec = (new Date(fromY)).getTime();
         var toMSec = (new Date(toY)).getTime();

         if (toMSec < fromMSec) {
             bolResult = false;
         }

         if (bolResult) {
             return '';
         } else {
             return msgKey;
         }
     }

    /**
    * 指定年月日のミリ秒値取得する。
    * @param year
    * @param month
    * @param day
    * @return
    */
    var getDate = function (year, month, day) {
        var intY = parseInt(year);
        var intM = parseInt(month) - 1;
        var intD = parseInt(day);
        var date = new Date(intY, intM, intD, 0, 0, 0);
        return date.getTime();
    }

    /**
    * 日付妥当性チェック(内部共通関数)
    * @param aryId : チェック対象項目ID一覧
    */
    var checkDateFormat = function(aryId) {
        var bolResult = false;
//        var message = 'M007';
        var message = 'MMCMCM00000_057';
        // 項目が6項目を超えている場合(項目は最大でも年月日時分秒迄)エラーとする
        if (aryId.length > 6) {
            return message;
        }
        var aryCheck = new Array();

        bolResult = true;

        $.each(aryId,function(index,id) {
            var value = $('#' + id).val();

            if (index == 0) {
                if ( value != null && value !='' ){
                    if (!value.match(/^\d{4}$/)) {
                        bolResult = false;
                    }
                }
            }

            if (value.match(/^\d+$/)) {
                aryCheck[aryCheck.length] = Number(value);

                // 一つ前のIndexの値を確認する。(nullの場合はエラー)
                if (aryCheck.length > 1 && aryCheck[aryCheck.length - 2] == null) {
                    bolResult = false;
                }
            } else if (value == null || value == '') {
                aryCheck[aryCheck.length] = null;
            } else {
//                message = 'M004';
                message = 'MMCMCM00000_054';
                bolResult = false;
            }
        });

        if (bolResult) {
            var aryDate = [1900,1,1,0,0,0];

            $.each(aryDate,function(index,d) {
                if (index < aryCheck.length) {
                    if (aryCheck[index] != null) {
                        aryDate[index] = aryCheck[index];
                    }
                }
            });

            var checkDate = new Date();
            checkDate.setFullYear(aryDate[0]);
            checkDate.setMonth(aryDate[1] - 1);
            checkDate.setDate(aryDate[2]);
            checkDate.setHours(aryDate[3]);
            checkDate.setMinutes(aryDate[4]);
            checkDate.setSeconds(aryDate[5]);

            bolResult = (aryDate[0] == checkDate.getFullYear())
            && (aryDate[1] == checkDate.getMonth() + 1)
            && (aryDate[2] == checkDate.getDate())
            && (aryDate[3] == checkDate.getHours())
            && (aryDate[4] == checkDate.getMinutes())
            && (aryDate[5] == checkDate.getSeconds());
        }

        if (bolResult) {
            message = '';
        }
        return message;
    }

    /**
    * チェックタイプ取得(内部共通関数)
    * タグ情報より、タグのタイプを取得する
    * @param name : チェック対象ID属性
    */
    var getType = function(name) {

        var tagName = $('#' + name).prop('tagName').toUpperCase();

        if (tagName == 'INPUT') {
            var type = $('#' + name).attr('type').toUpperCase();

            switch (type) {
            case 'TEXT':
                return TYPE['TXT'];
            case 'PASSWORD':
                return TYPE['PSWD'];
            case 'CHECKBOX':
                return TYPE['CHK'];
            case 'RADIO':
                return TYPE['RDO'];
            default:
                //通常ありえない(HTMLのINPUTとしてあり得ない値を指定した場合
                        return TYPE['ERROR'];
            }
        } else if (tagName == 'SELECT') {
            var multiple = $('#' + name).attr('multiple');

            if (multiple) {
                return TYPE['SEL_LIST'];
            } else {
                return TYPE['PLD'];
            }
        } else if (tagName == 'TEXTAREA') {
            return TYPE['TXT_AREA'];
        } else {
            // チェック対象の要素以外を指定した場合
            return TYPE['ERROR'];
        }
    }

    /**
    * 空白文字の除去
    * タグ情報より、テキストの空白文字を取り除く（後方のみ）
    * @param id : チェック対象ID
    */
    this.strRTrim = function(id) {
        var value = $('#' + id).val();

        if (!value) {
            // nullやundefined等の場合、以降の処理を行わない
            return value;
        }

        var val2 = value.replace(/[\n\r]/g,"\n");

        var val3 = val2.split("\n");

        if(val3.length > 1){
            var ret = null;

            for(var i=val3.length-1; i>=0; i--){
                if(ret != null){
                    if(i==0){
                        if(val3[i].length != 0){
                            ret = val3[i] + ret;
                        }
                    }else{
                        ret = "\n" + val3[i] + ret;
                    }
                }else{
                    var tmpStr = val3[i].replace(/[ 　]*$/gim, '');
                    if(tmpStr.length > 0){
                        if(i==0){
                            ret = tmpStr;
                        }else{
                            ret = "\n" + tmpStr;
                        }
                    }
                }
            }
            return ret;
        }

        return value.replace(/[ 　]*$/gim, '');

    }

    /**
     * 空白文字の除去
     * タグ情報より、テキストの空白文字を取り除く（後方のみ）
     * @param value : チェック対象
     */
     this.strRTrim2 = function(value) {

         var val2 = value.replace(/[\n\r]/g,"\n");

         var val3 = val2.split("\n");

         if(val3.length > 1){
             var ret = null;

             for(var i=val3.length-1; i>=0; i--){
                 if(ret != null){
                     if(i==0){
                         if(val3[i].length != 0){
                             ret = val3[i] + ret;
                         }
                     }else{
                         ret = "\n" + val3[i] + ret;
                     }
                 }else{
                     var tmpStr = val3[i].replace(/[ 　]*$/gim, '');
                     if(tmpStr.length > 0){
                         if(i==0){
                             ret = tmpStr;
                         }else{
                             ret = "\n" + tmpStr;
                         }
                     }
                 }
             }
             return ret;
         }

         return value.replace(/[ 　]*$/gim, '');

     }

     /**
      * 空白文字の除去
      * タグ情報より、テキストの空白文字を取り除く（前後方）
      * @param id : チェック対象ID
      */
     this.strTrim = function(id) {
         var value = $('#' + id).val();

         if (!value) {
             // nullやundefined等の場合、以降の処理を行わない
             return value;
         }

         return this.strTrim2(value);

     };

     /**
      * 空白文字の除去
      * タグ情報より、テキストの空白文字を取り除く（前後方）
      * @param value : チェック対象
      */
      this.strTrim2 = function(value) {

          var val2 = value.replace(/[\n\r]/g,"\n");

          var val3 = val2.split("\n");

          if (val3.length > 1) {
              var ret = null;

              for (var i=val3.length-1; i>=0; i--) {
                  if (ret != null) {
                      if (i == 0) {
                          if (val3[i].length != 0) {
                              ret = val3[i] + ret;
                          }
                      } else {
                          ret = "\n" + val3[i] + ret;
                      }
                  } else {
                      var tmpStr = val3[i].replace(/(^\s+)|(\s+$)/g, '');
                      if (tmpStr.length > 0) {
                          if (i == 0) {
                              ret = tmpStr;
                          } else {
                              ret = "\n" + tmpStr;
                          }
                      }
                  }
              }
              return ret;
          }

          return value.replace(/(^\s+)|(\s+$)/g, '');

      };

     /**
      * 禁則文字チェック
      * @param strObj チェック対象文字列
      * @param forbidChar 禁則文字配列
      * @returns チェック対象の文字列に含まれている禁則文字(含まれていない場合は、空文字)
      */
     this.checkForbidChar = function(strObj, forbidChar) {

         for(var i = 0; i < forbidChar.length; i++) {
              var tmpChar = forbidChar[i];
             var index = strObj.indexOf(tmpChar);
             if (index != -1) {
                 return tmpChar;
             }
         }
         return;
     };

     /**
      * 最大値比較チェック
      * @param strObj チェック対象文字列
      * @param maxInt 最大値
      * @return チェック対象文字列が最大値より大きい場合、チェック対象文字列(対象文字列が最大値より小さい場合は、空文字)
      */
     this.checkMaxInt = function(strObj,maxInt){
       if(strObj != null && strObj != ''){
         if (parseInt(strObj) <= parseInt(maxInt)){
           return '';
         }
       }
       return 'MMCMCM00000_053';
     };

     /**
      * 最小値比較チェック
      * @param strObj チェック対象文字列
      * @param minInt 最小値
      * @return チェック対象文字列が最小値より小さい場合、チェック対象文字列(対象文字列が最小値より大きい場合は、空文字)
      */
     this.checkMinInt = function(strObj,minInt){
       if(strObj != null && strObj != ''){
         if (parseInt(strObj) >= parseInt(minInt)){
           return '';
         }
       }
       return 'MMCMCM00000_053';
     };


     /**
      * 範囲比較チェック
      * @param id 項目ID
      * @param minInt 最小値
      * @param maxInt 最大値
      * @param digit 進数
      * @return チェック対象文字列が最小値から最大値の範囲以外場合、チェック対象文字列(対象文字列が範囲内場合は、空文字)
      */
     this.checkRangeInt = function(id,minInt,maxInt,digit){
         var value = '';
         var tagName = $('#' + id).prop('tagName').toUpperCase();
         if (tagName == 'INPUT') {
             value = $('#' + id).val();
         } else {
             value = $('#' + id).text();
         }
       if(value != null && value != ''){
         if (parseInt(minInt,digit) <= parseInt(value,digit) && parseInt(value,digit) <= parseInt(maxInt,digit)){
           return '';
         }
       }
       return 'MMCMCM00000_053';
     };

     /**
      * 値チェック(大文字・小文字は区別なし)
      * @param id 項目ID
      * @param valueList 有効値リスト
      * @return チェック対象文字列が有効値リストにない場合、チェック対象文字列(対象文字列が有効値リストにある場合は、空文字)
      */
     this.checkVal = function(id,valueList) {
         var value = '';
         try {
             var tagName = $('#' + id).prop('tagName').toUpperCase();
             if (tagName == 'INPUT') {
                 value = $('#' + id).val();
             } else {
                 value = $('#' + id).text();
             }
             value = value.toUpperCase();

             for(var i = 0; i < valueList.length; i++) {
             var tmpItem = valueList[i];
                 if (value == tmpItem.toUpperCase()) {
                     return '';
                 }
             }
         } catch(e) {}
         return 'MMCMCM00000_053';
     };

     /**
      * 入力値がスペースのみかどうかチェック
      * @param id : チェック対象ID属性
      * @return 入力値がスペースのみならtrue
      */
     this.checkOnlySpace = function(id) {

         var result = false;

         var value = $('#' + id).val();
         if (typeof value !== 'undefined' && value != null) {
             if (value.match(/^[\p{blank}\s]*$/g) != null) {
                 result = true;
             }
         }

         return result;
     };

};